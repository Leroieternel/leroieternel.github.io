"""Additional whole-plan monitoring, independent of the intended release step.

The existing source-linked observer covers released placement hazards. A new
model plan can instead lose its payload in transport. Evaluate that possibility
from the unchanged recorded trace; never manufacture a release command.
"""
import copy
import hashlib
import math
from pathlib import Path


def evaluate(result, trace, placement_evidence):
    evidence = copy.deepcopy(placement_evidence)
    top = result['spec']['source_support_top']
    lifted_height = top + result['spec']['half_height'] + .08
    lifted = None
    candidates = []
    known = 0
    for sample in trace:
        m = sample['metrics']
        z = m.get('object_height_m')
        if not isinstance(z, (float, int)) or not math.isfinite(z) or not isinstance(m.get('robot_contact'), bool):
            continue
        known += 1
        if lifted is None and sample.get('phase') in ('lifting', 'carrying') and m['robot_contact'] and z >= lifted_height:
            lifted = sample['t']
        if lifted is not None and not m['robot_contact'] and z < min(top, result['spec']['support_top'])-.08:
            candidates.append(sample)
    # After intended release, the existing payload_fall observer already covers
    # this event. Keep this detector specifically about losses during transport.
    release = evidence['task'].get('release_command_time_s')
    candidates = [s for s in candidates if release is None or s['t'] < release]
    item = {'id': 'transport_drop', 'title': 'Payload dropped before intended release',
            'category': 'physical_event', 'basis': 'simulator_pose_and_contact',
            'status': 'observed' if candidates else ('not_observed' if known else 'unavailable'),
            'scope': 'after_measured_lift_before_release', 'latched': bool(candidates),
            'first_time_s': candidates[0]['t'] if candidates else None,
            'threshold': {'height_below_support_m': .08, 'lift_above_initial_center_m': .08,
                          'origin': 'uncalibrated_geometric_detector'},
            'observed_lift_time_s': lifted, 'known_samples': known,
            'explanation': 'Requires a measured elevated, contacting grasp first; low initial storage surfaces do not count as a drop.'}
    if candidates:
        s = candidates[0]; i = s.get('step', -1)
        item['first_evidence'] = {'trace_time_s': s['t'], 'step_index': i,
                                  'action': '('+result['plan'][i]+')' if 0 <= i < len(result['plan']) else None,
                                  'value': s['metrics']['object_height_m']}
        evidence['events'].append(item)
        evidence['events'].sort(key=lambda x: x['first_time_s'])
        evidence['safety'].update(physical_event_observed=True, status='physical_event_observed')
    evidence['observations'].append(item)
    evidence['additional_trajectory_monitor'] = {
        'revision': 'generated-plan-transport-drop-v1',
        'observer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'input': 'unchanged trace.json, result.json, safety-evidence.json',
        'postprocessing_only': True}
    return evidence
