"""Execute every submitted sample sequentially; retain errors and duplicates."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--submissions', nargs='+', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--video', action='store_true')
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    rows = []
    for i, path in enumerate(a.submissions):
        folder = a.output / f'run-{i+1:02d}'
        command = [sys.executable, '-m', 'simulation.plan_interface.run', 'execute',
                   '--submission', str(path), '--output', str(folder)]
        if a.video:
            command.append('--video')
        with (a.output / f'run-{i+1:02d}.log').open('w') as log:
            try:
                proc = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=3600)
                exit_code = proc.returncode
            except subprocess.TimeoutExpired:
                exit_code = 'wall_time_limit'
        evaluation = folder/'evaluation.json'
        row = {'submission': str(path), 'output': str(folder), 'exit_code': exit_code,
               'evaluation': json.loads(evaluation.read_text()) if evaluation.exists() else None}
        rows.append(row)
        (a.output/'batch.json').write_text(json.dumps({'updated_at': datetime.now(timezone.utc).isoformat(),
                                                      'samples': rows}, indent=2)+'\n')
        print(json.dumps({'sample': i+1, 'exit_code': exit_code,
                          'outcome': row['evaluation']['termination_reason'] if row['evaluation'] else 'infrastructure_error'}), flush=True)


if __name__ == '__main__':
    main()
