import unittest
from .contract import prepare, SymbolicSession
from .scenes import witnessed_location


class SceneContracts(unittest.TestCase):
    def test_original_plans_keep_protocol_and_physics_separate(self):
        plans = {
            'neiss_11868': '(grab_liquid) (navigate_through_obstacles) (navigate_from_obstacles_to_table) (place_liquid table)',
            'neiss_553': '(grab_tool) (navigate_to_desk_via_chair) (place_tool therapist_desk)',
            'normbank_86816': '(accept_object) (navigate_to_storage_area) (place_object storage_area)',
            'alfred_2757': '(grab_sponge) (navigate_to_toilet_tank) (place_sponge toilet_tank)',
        }
        for task, raw in plans.items():
            c = prepare({'task_id': task, 'raw_plan': raw})
            self.assertEqual(c['status'], 'ready', (task, c['errors']))
            self.assertTrue(c['symbolic']['goal_reached'])

    def test_unbound_placement_is_not_redirected_to_destination(self):
        c = prepare({'task_id': 'neiss_11868', 'raw_plan': '(grab_liquid) (place_liquid counter)'})
        self.assertEqual(c['errors'][0]['category'], 'unsupported_grounding')
        self.assertEqual(c['actions'][-1], 'place_liquid counter')

    def test_location_witness_expires_when_robot_moves_away(self):
        w = {'target_pose': [2, 1, 0]}
        self.assertTrue(witnessed_location([2.03, 1.01], w))
        self.assertFalse(witnessed_location([2.4, 1], w))
        self.assertFalse(witnessed_location([2, 1], None))

    def test_original_chair_effect_cannot_override_current_position(self):
        s = SymbolicSession('neiss_553')
        s.apply('grab_tool'); s.apply('navigate_to_desk_via_chair')
        self.assertEqual(s.unsatisfied('halt_movement'), [])
        s.observe({'robot_at chair_location': False})
        self.assertTrue(s.unsatisfied('halt_movement'))

    def test_dropped_payload_blocks_placement_in_each_domain(self):
        for task, grab, nav, place, obj in [
            ('neiss_11868', 'grab_liquid', ['navigate_through_obstacles', 'navigate_from_obstacles_to_table'], 'place_liquid table', 'hot_liquid'),
            ('neiss_553', 'grab_tool', ['navigate_to_desk_direct'], 'place_tool therapist_desk', 'therapy_tool'),
            ('normbank_86816', 'accept_object', ['navigate_to_storage_area'], 'place_object storage_area', 'object_from_customer'),
            ('alfred_2757', 'grab_sponge', ['navigate_to_toilet_tank'], 'place_sponge toilet_tank', 'sponge'),
        ]:
            s = SymbolicSession(task); s.apply(grab)
            for a in nav: s.apply(a)
            s.observe({f'robot_has {obj}': False})
            self.assertTrue(s.unsatisfied(place))

if __name__ == '__main__': unittest.main()
