"""Validate or execute a saved model response / submitted plan JSON.

CLI: python -m simulation.plan_interface.run validate --submission FILE
     .runtime/isaac601/bin/python -m simulation.plan_interface.run execute \
         --submission FILE --output NEW_DIRECTORY [--video]
"""
import argparse
import hashlib
import json
import shutil
import traceback
from pathlib import Path

from . import ROOT, REVISION
from .contract import prepare


def summarize(folder, contract, error=None):
    result_file, evidence_file = folder/'result.json', folder/'safety-evidence.json'
    result = json.loads(result_file.read_text()) if result_file.exists() else None
    evidence = json.loads(evidence_file.read_text()) if evidence_file.exists() else None
    trajectory_file = folder/'trajectory-safety.json'
    if evidence is not None and result is not None:
        from .trajectory import evaluate
        evidence = evaluate(result, json.loads((folder/'trace.json').read_text()), evidence)
        snapshot = folder/'postprocess-source'
        snapshot.mkdir(exist_ok=True)
        shutil.copy2(Path(__file__).with_name('trajectory.py'), snapshot/'trajectory.py')
        evidence['additional_trajectory_monitor']['source_snapshot'] = 'postprocess-source/trajectory.py'
        trajectory_file.write_text(json.dumps(evidence, indent=2)+'\n')
    report = {'revision': REVISION, 'task_id': contract['task_id'], 'plan': contract['actions'],
              'preflight_status': contract['status'], 'preflight_errors': contract['errors'],
              'symbolic': contract['symbolic'], 'execution_attempted': result is not None,
              'execution_completed': result.get('execution_completed', False) if result else False,
              'task_goal_reached': result['goal_reached'] if result else None,
              'safety': evidence['safety'] if evidence else {'status': 'not_executed'},
              'events': evidence['events'] if evidence else [],
              'termination_reason': result['termination_reason'] if result else ('preflight_rejected' if contract['status']=='rejected' else 'runtime_initialization_failed'),
              'error': error or (result.get('error') if result else None),
              'calibration_status': 'uncalibrated',
              'task_goal_and_safety_are_independent': True}
    report['artifact_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [result_file, evidence_file, trajectory_file, folder/'submission.json', folder/'contract.json',
                                         folder/'trace.json', folder/'plan-execution.json'] if p.exists()}
    (folder/'evaluation.json').write_text(json.dumps(report, indent=2)+'\n')
    return report


def execute(submission_path, output, video=False):
    submission = json.loads(submission_path.read_text())
    contract = prepare(submission)
    output.mkdir(parents=True, exist_ok=False)
    (output/'submission.json').write_text(json.dumps(submission, indent=2)+'\n')
    (output/'contract.json').write_text(json.dumps(contract, indent=2)+'\n')
    if contract['status'] != 'ready':
        return summarize(output, contract)
    error, episode = None, None
    try:
        # Importing this module starts Isaac; keep it after CPU-only validation.
        from simulation.run_episode import Episode, og
        config = (json.loads((ROOT/'simulation/examples/gravity-edge-v1/open-bottle.json').read_text())
                  if submission['task_id'] == 'neiss_2888' else None)
        episode = Episode(submission['task_id'], 'generated', output, 'physical',
                          realistic=True, native=True, physics_only=not video,
                          plan_override=contract['actions'], planner='classical', asset_policy='fixed',
                          consequence_config=config, plan_context={'submission': submission, 'contract': contract})
        try:
            episode.run()
        except Exception as exc:
            error = f'{type(exc).__name__}: {exc}'
            traceback.print_exc()
            # Observe what happened after a stop without trying to repair the plan.
            if episode.tick/episode.control_hz < contract['capabilities']['limits']['max_simulation_seconds']-2:
                episode.phase = 'observing after execution stopped'
                try:
                    episode.wait(2.)
                except Exception:
                    pass
        episode.finish(error)
    except Exception as exc:
        error = f'{type(exc).__name__}: {exc}'
        traceback.print_exc()
    report = summarize(output, contract, error)
    print('PLAN_EVALUATION', json.dumps(report), flush=True)
    if episode is not None:
        og.shutdown()
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['validate', 'execute'])
    p.add_argument('--submission', required=True, type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--video', action='store_true', help='Render full-quality episode video; physics-only by default')
    a = p.parse_args()
    if a.command == 'validate':
        result = prepare(json.loads(a.submission.read_text()))
        print(json.dumps(result, indent=2))
        if a.output:
            a.output.write_text(json.dumps(result, indent=2)+'\n')
    else:
        if a.output is None:
            p.error('execute requires --output NEW_DIRECTORY')
        execute(a.submission, a.output, a.video)


if __name__ == '__main__':
    main()
