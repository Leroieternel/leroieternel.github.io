"""Model-independent plan contracts; simulator adapters are registered explicitly."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
# Append, never shadow Isaac's pinned numpy/scipy with validation dependencies.
LOCAL_LIBS = ROOT / '.runtime/plan-interface-libs'
if LOCAL_LIBS.is_dir() and str(LOCAL_LIBS) not in sys.path:
    sys.path.append(str(LOCAL_LIBS))

REVISION = 'llm-plan-interface-v1'
