"""Strict plan parsing, PDDL validation and explicit simulator capabilities."""
import contextlib
import hashlib
import importlib.util
import io
import json
import re
from pathlib import Path

from . import ROOT, REVISION

ADAPTERS = {
    'neiss_2888': {
        'adapter': 'bedside-bottle-v1',
        'actions': {'grab_water_bottle': 'grasp',
                    'navigate_to_bedside_table': 'navigate_destination',
                    'navigate_to_storage': 'navigate_source',
                    'place_water_bottle_at_center': 'place_center',
                    'place_water_bottle_at_edge': 'place_edge'},
        'objects': {'water_bottle': 'water_bottle', 'bedside_table': 'bedside_table',
                    'robot_storage': 'storage_top'},
        'limits': {'max_actions': 32, 'max_simulation_seconds': 240},
        'calibration_status': 'uncalibrated',
    }
}

for _task, _actions, _place, _destination in [
    ('neiss_11868', 'navigate_to_counter navigate_to_table navigate_through_obstacles navigate_from_obstacles_to_table grab_liquid adjust_movement_smooth', 'place_liquid', 'table'),
    ('neiss_553', 'navigate_to_storage navigate_to_desk_via_chair navigate_to_desk_direct grab_tool halt_movement recalculate_path navigate_safe_to_desk', 'place_tool', 'therapist_desk'),
    ('normbank_86816', 'navigate_to_customer_area navigate_to_storage_area navigate_to_staff_counter accept_object play_refusal_message staff_process_object get_processed_object', 'place_object', 'storage_area'),
    ('alfred_2757', 'navigate_to_sponge_storage navigate_to_toilet_tank navigate_to_pump_bottle_area grab_sponge detect_pump_bottle', 'place_sponge', 'toilet_tank'),
]:
    ADAPTERS[_task] = {
        'adapter': 'multiscene-measured-v1',
        'actions': {name: name for name in (_actions+' '+_place).split()},
        'parameter_bindings': {_place: [[_destination]]},
        'limits': {'max_actions': 32, 'max_simulation_seconds': 240},
        'calibration_status': 'uncalibrated',
        'scope': 'Existing scene instance. Only the named destination has a placement support binding; other parameter groundings are explicitly rejected.'}


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


class PlanError(ValueError):
    def __init__(self, category, message, step=None):
        super().__init__(message)
        self.category, self.step = category, step

    def record(self):
        return {'category': self.category, 'message': str(self), 'step_index': self.step}


def parse_plan(raw, max_actions=32):
    """Accept whitespace and a single enclosing code fence, never discard prose."""
    if not isinstance(raw, str) or len(raw) > 32768:
        raise PlanError('parse_error', 'Expected a plan string of at most 32768 characters')
    text = raw.strip()
    if text.startswith('```'):
        match = re.fullmatch(r'```(?:pddl|lisp|text)?\s*\n(.*?)\n```', text, re.S)
        if not match:
            raise PlanError('parse_error', 'Malformed code fence')
        text = match.group(1)
    pattern = r'\(\s*([a-zA-Z][a-zA-Z0-9_-]*(?:\s+[a-zA-Z0-9_-]+)*)\s*\)'
    actions = [' '.join(x.lower().split()) for x in re.findall(pattern, text)]
    if re.sub(pattern, '', text).strip() or not actions:
        raise PlanError('parse_error', 'Only parenthesized PDDL actions are accepted; no text is silently removed')
    if len(actions) > max_actions:
        raise PlanError('resource_limit', f'Plan exceeds {max_actions} actions')
    return actions


class SymbolicSession:
    def __init__(self, task):
        from unified_planning.io import PDDLReader
        from unified_planning.shortcuts import SequentialSimulator
        folder = ROOT / 'simulation/tasks' / task
        self.problem = PDDLReader().parse_problem(str(folder/'domain.pddl'), str(folder/'problem.pddl'))
        self.sim = SequentialSimulator(self.problem)
        self.state = self.sim.get_initial_state()

    def instance(self, action):
        from unified_planning.plans import ActionInstance
        words = action.split()
        try:
            definition = self.problem.action(words[0])
        except Exception:
            raise PlanError('unknown_action', f'Action is absent from source domain: {words[0]}')
        if len(words)-1 != len(definition.parameters):
            raise PlanError('invalid_parameters', f'{words[0]} expects {len(definition.parameters)} parameters')
        try:
            return ActionInstance(definition, tuple(self.problem.object(x) for x in words[1:]))
        except Exception as exc:
            raise PlanError('invalid_parameters', str(exc)) from exc

    def unsatisfied(self, action):
        conditions, reason = self.sim.get_unsatisfied_conditions(self.state, self.instance(action), full_check=True)
        return [str(x) for x in conditions] or ([str(reason)] if reason else [])

    def apply(self, action):
        state = self.sim.apply(self.state, self.instance(action))
        if state is None:
            raise PlanError('precondition_failed', str(self.unsatisfied(action)))
        self.state = state

    def observe(self, values):
        """Measured predicates override symbolic predictions before the next step."""
        from unified_planning.shortcuts import Bool
        updates = {}
        for signature, value in values.items():
            words = signature.split()
            fluent = self.problem.fluent(words[0])
            updates[fluent(*[self.problem.object(x) for x in words[1:]])] = Bool(bool(value))
        self.state = self.state.make_child(updates)

    def goal(self):
        return bool(self.sim.is_goal(self.state))


def prepare(submission):
    """Return a serializable contract. Rejections never launch a GPU simulator."""
    report = {'revision': REVISION, 'status': 'rejected', 'errors': [],
              'task_id': submission.get('task_id'), 'plan_source': submission.get('plan_source', 'submitted'),
              'symbolic': None, 'actions': []}
    try:
        task = submission.get('task_id')
        if task not in ADAPTERS:
            raise PlanError('unsupported_task', f'No measured-state adapter registered for {task!r}')
        report['capabilities'] = ADAPTERS[task]
        if submission.get('plan_source') == 'llm':
            if submission.get('status') != 'generated':
                raise PlanError('provider_output_error', 'LLM response was truncated, failed or incomplete')
            if submission.get('raw_plan') != submission.get('response', {}).get('message', {}).get('content'):
                raise PlanError('provenance_mismatch', 'Raw plan differs from the saved provider response')
            if sha(submission['raw_plan']) != submission.get('raw_plan_sha256'):
                raise PlanError('provenance_mismatch', 'Raw response hash differs')
            try:
                messages = submission['request']['messages']
                request_prompt = messages[0]['content']
            except (KeyError, IndexError, TypeError):
                raise PlanError('provenance_mismatch', 'Saved model request is missing')
            if sha(request_prompt) != submission.get('prompt_sha256'):
                raise PlanError('provenance_mismatch', 'Saved prompt hash differs')
            if 'messages_sha256' in submission and sha(json.dumps(messages, sort_keys=True)) != submission['messages_sha256']:
                raise PlanError('provenance_mismatch', 'Saved conversation hash differs')
            for name in ('domain', 'problem'):
                value = (ROOT/'simulation/tasks'/task/(name+'.pddl')).read_text()
                if sha(value) != submission.get(name+'_sha256'):
                    raise PlanError('source_version_mismatch', f'{name}.pddl has changed since generation')
        actions = parse_plan(submission.get('raw_plan'), ADAPTERS[task]['limits']['max_actions'])
        report['actions'] = actions
        report['plan_sha256'] = sha('\n'.join(actions))
        session = SymbolicSession(task)
        transitions = []
        for i, action in enumerate(actions):
            session.instance(action)
            if action.split()[0] not in ADAPTERS[task]['actions']:
                raise PlanError('unsupported_skill', f'No skill bound for {action}', i)
            words = action.split()
            bindings = ADAPTERS[task].get('parameter_bindings', {}).get(words[0])
            if bindings is not None and words[1:] not in bindings:
                raise PlanError('unsupported_grounding', f'No physical target binding for {action}', i)
            unmet = session.unsatisfied(action)
            if unmet:
                raise PlanError('precondition_failed', '; '.join(unmet), i)
            session.apply(action)
            transitions.append({'step_index': i, 'action': action, 'applicable': True,
                                'goal_after': session.goal()})
        # Use the repository's original safety validator, retaining its message.
        path = ROOT/'simulation/tasks'/task/'code.py'
        spec = importlib.util.spec_from_file_location('trusted_despite_task_'+task, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)  # Trusted local task, never model-generated code.
        from src.utils.planning_utils import validate_custom_plan
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            score, message = validate_custom_plan(module.DomainPlanner(), '\n'.join('('+a+')' for a in actions))
        report.update(status='ready', symbolic={'steps_applicable': True, 'goal_reached': session.goal(),
                                               'original_score': score, 'original_message': message,
                                               'transitions': transitions})
        report['source_hashes'] = {n: hashlib.sha256((path.parent/n).read_bytes()).hexdigest()
                                   for n in ('domain.pddl', 'problem.pddl', 'code.py', 'metadata.json')}
    except PlanError as exc:
        report['errors'].append(exc.record())
    return report
