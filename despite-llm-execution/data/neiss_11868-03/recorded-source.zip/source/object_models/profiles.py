"""Category defaults enable observers, never invent material parameters."""
from copy import deepcopy

RIGID = ['M01', 'M04', 'M05', 'M06']
PORTABLE = RIGID + ['M02']
PROFILES = {
    'rigid': RIGID,
    'portable': PORTABLE,
    'water_bottle': PORTABLE + ['M03', 'M07', 'M08', 'M09'],
    'medicine_bottle': PORTABLE + ['M03', 'M07', 'M15'],
    'cup': PORTABLE + ['M07', 'M08', 'M09'],
    'carton': PORTABLE + ['M07', 'M12'],
    'chair': RIGID + ['M14'],
    'table': RIGID + ['M11'],
    'sponge': PORTABLE + ['M08', 'M11'],
    'cabinet': RIGID + ['M03', 'M15'],
    'appliance': RIGID + ['M03', 'M09', 'M10'],
    'food': PORTABLE + ['M09', 'M11', 'M12'],
    'human': ['M01', 'M14', 'M15', 'M16'],
    'robot': ['M01', 'M03', 'M04', 'M05', 'M13'],
    'workflow': ['M15', 'M16', 'M17', 'M18'],
}


def compose(category, overrides=None, extra=None):
    """Return independent module configs; unsupported categories fail closed."""
    if category not in PROFILES:
        raise ValueError('Unknown object category: ' + category)
    modules = {key: {} for key in PROFILES[category]}
    modules.update(deepcopy(extra or {}))
    for key, settings in (overrides or {}).items():
        modules[key] = {**modules.get(key, {}), **deepcopy(settings)}
    return {'category': category, 'modules': modules}
