"""18 reusable mechanisms; unsupported measurements remain explicitly unknown.

All units are SI except the named ml / mg channels. Parameters are declared
assumptions until calibrated. No method accepts a safe/unsafe reference label.
"""
import math
from dataclasses import dataclass


def reading(value=None, basis='observation', unit=None, source=None):
    return {'value': value, 'basis': basis if value is not None else 'unknown',
            'unit': unit, 'source': source, 'calibration_status': 'uncalibrated'}


def obs(o, key, unit=None):
    return reading(o.get(key), o.get('_basis', 'simulator_measurement'), unit, key)


def predicted(value, unit=None, source=None):
    return reading(value, 'reduced_order_prediction', unit, source)


def number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def norm(v):
    return math.sqrt(sum(x*x for x in v))


def require(c, *names):
    for name in names:
        if not number(c.get(name)) or c[name] < 0:
            raise ValueError('Missing nonnegative finite parameter: ' + name)


@dataclass(frozen=True)
class Module:
    name: str
    evaluate: object
    validator: object = None
    modes: tuple = ('observe',)

    def validate(self, c):
        if c.get('mode', 'observe') not in self.modes:
            raise ValueError('Unsupported mode for ' + self.name)
        if self.validator:
            self.validator(c)


def spatial(c, m, o, e, t, dt):
    r = {'position': obs(o, 'position_m', 'm'), 'orientation': obs(o, 'quaternion_xyzw')}
    bounds = o.get('aabb_m')
    for name, region in c.get('regions', {}).items():
        inside = None if bounds is None else all(region[0][i] <= bounds[0][i] and bounds[1][i] <= region[1][i] for i in range(3))
        r['inside.'+name] = reading(inside, 'derived_geometry', source='full AABB inside declared region')
    return r


def grasp(c, m, o, e, t, dt):
    contacts, relative = o.get('finger_contacts'), o.get('eef_relative_position_m')
    held, slip = None, None
    if contacts is not None and relative is not None and 'gripper_closing' in o:
        bilateral = len(contacts) >= 2 and all(contacts)
        if bilateral and o['gripper_closing']:
            m.setdefault('origin', list(relative))
            slip = norm([a-b for a,b in zip(relative, m['origin'])])
        else:
            m.pop('origin', None)
        shift = norm([a-b for a, b in zip(relative, m.get('relative', relative))])
        # Accumulated seating/shift is reported separately: it must not latch
        # "not held" forever while both fingers still carry the object.
        stable = shift <= c.get('relative_motion_tolerance_m', .005)
        if bilateral and stable and o['gripper_closing']:
            m.setdefault('since', t)
        else:
            m.pop('since', None)
        held = 'since' in m and t-m['since'] >= c.get('dwell_s', .15)
        m['relative'] = list(relative)
    else:
        m.pop('since', None)
        m.pop('relative', None)
        m.pop('origin', None)
    return {'held': reading(held, 'contact_and_relative_motion_inference', source='bilateral fingers + closing command + relative-pose dwell'),
            'constraint_attached': obs(o, 'constraint_attached'),
            'slip_m': obs(o, 'slip_m', 'm') if 'slip_m' in o else reading(slip, 'relative_pose_displacement', 'm'),
            'grip_shift_exceeds_threshold': reading(slip > c.get('maximum_slip_m', .01) if slip is not None else None,
                                                   'declared_relative_pose_threshold')}


def articulation(c, m, o, e, t, dt):
    q, lo, hi = o.get('joint_position'), c.get('closed_position'), c.get('open_position')
    f = max(0, min(1, (q-lo)/(hi-lo))) if all(number(x) for x in (q, lo, hi)) and hi != lo else None
    return {'joint_position': obs(o, 'joint_position'), 'open_fraction': reading(f, 'joint_geometry'),
            'open': reading(f >= c.get('open_threshold', .9) if f is not None else None, 'joint_geometry'),
            'locked': obs(o, 'locked')}


def motion(c, m, o, e, t, dt):
    v = o.get('linear_velocity_m_s')
    a = [(v[i]-m['v'][i])/dt for i in range(3)] if v is not None and 'v' in m and dt > 0 else None
    if v is not None:
        m['v'] = v
    else:
        m.pop('v', None)
    mass = o.get('mass_kg', c.get('mass_kg'))
    energy = .5*mass*norm(v)**2 if v is not None and number(mass) else None
    return {'velocity': obs(o, 'linear_velocity_m_s', 'm/s'), 'angular_velocity': obs(o, 'angular_velocity_rad_s', 'rad/s'),
            'acceleration': reading(a, 'finite_difference', 'm/s^2'),
            'translational_energy': reading(energy, 'derived_dynamics', 'J'),
            'contact_force': obs(o, 'contact_force_n', 'N')}


def collision(c, m, o, e, t, dt):
    d, threshold = o.get('clearance_m'), c.get('minimum_clearance_m')
    violation = d < threshold if number(d) and number(threshold) else None
    return {'contact': obs(o, 'contact'), 'clearance': obs(o, 'clearance_m', 'm'),
            'impulse': obs(o, 'contact_impulse_ns', 'N s'),
            'clearance_violation': reading(violation, 'declared_distance_threshold')}


def support(c, m, o, e, t, dt):
    fields = [o.get(k) for k in ('support_contact', 'edge_margin_m', 'support_height_error_m')]
    supported = bool(fields[0] and fields[1] >= 0 and abs(fields[2]) <= c.get('height_tolerance_m', .035)) if all(x is not None for x in fields) else None
    speed = norm(o['linear_velocity_m_s']) if 'linear_velocity_m_s' in o else None
    w = norm(o['angular_velocity_rad_s']) if 'angular_velocity_rad_s' in o else None
    stable = None
    if supported is not None and speed is not None and w is not None:
        still = supported and speed <= c.get('linear_tolerance_m_s', .01) and w <= c.get('angular_tolerance_rad_s', .05)
        if still:
            m.setdefault('since', t)
        else:
            m.pop('since', None)
        stable = still and t-m['since'] >= c.get('stable_dwell_s', .5)
    else:
        m.pop('since', None)
    falling = None
    if 'constrained' in o and 'linear_velocity_m_s' in o and 'any_support_contact' in o:
        falling = not o['constrained'] and not o['any_support_contact'] and o['linear_velocity_m_s'][2] < -c.get('fall_velocity_m_s', .1)
    scope = c.get('support_name', 'supplied support observation')
    return {'supported': reading(supported, 'contact_and_geometry', source=scope),
            'stable': reading(stable, 'contact_geometry_velocity_dwell', source=scope), 'falling': reading(falling, 'derived_dynamics'),
            'tilt': obs(o, 'tilt_deg', 'deg'), 'edge_margin': obs(o, 'edge_margin_m', 'm')}


def damage_config(c):
    if c.get('mode') == 'energy_threshold':
        require(c, 'fracture_energy_j')
        if c['fracture_energy_j'] == 0:
            raise ValueError('Fracture threshold must be positive')


def damage(c, m, o, e, t, dt):
    if 'broken' in o:
        return {'broken': obs(o, 'broken')}
    broken = None
    if c.get('mode') == 'energy_threshold':
        # No contact measurement means no conclusion, including no false claim
        # of an intact object. This is a trigger model, not a fracture solver.
        energy = o.get('impact_energy_j')
        if number(energy):
            m['broken'] = m.get('broken', False) or energy >= c['fracture_energy_j']
            broken = m['broken']
        elif m.get('broken'):
            broken = True
    return {'broken': predicted(broken, source='declared impact-energy threshold; no fragments generated')}


def liquid_config(c):
    if c.get('mode') == 'ledger':
        require(c, 'initial_volume_ml', 'capacity_ml')
        if c['initial_volume_ml'] > c['capacity_ml']:
            raise ValueError('Initial liquid exceeds capacity')


def liquid(c, m, o, e, t, dt):
    if c.get('mode') == 'ledger':
        if any(k in o for k in ('liquid_volume_ml', 'escaped_volume_ml')):
            raise ValueError('Do not mix measured PBD volume and ledger evolution on one object')
        m.setdefault('volume_ml', c['initial_volume_ml'])
        return {'volume': predicted(m['volume_ml'], 'ml', 'conservative transfer ledger'),
                'fill_fraction': predicted(m['volume_ml']/c['capacity_ml'] if c['capacity_ml'] else 0)}
    escaped, threshold = o.get('escaped_volume_ml'), c.get('spill_threshold_ml')
    return {'volume': obs(o, 'liquid_volume_ml', 'ml'), 'escaped_volume': obs(o, 'escaped_volume_ml', 'ml'),
            'floor_volume': obs(o, 'floor_liquid_volume_ml', 'ml'), 'wet_area': obs(o, 'wet_area_m2', 'm^2'),
            'spilled': reading(escaped >= threshold if number(escaped) and number(threshold) else None, 'measured_volume_threshold')}


def thermal_config(c):
    if c.get('mode') == 'lumped':
        require(c, 'mass_kg', 'specific_heat_j_kg_k', 'conductance_w_k')
        if c['mass_kg'] * c['specific_heat_j_kg_k'] <= 0 or not number(c.get('initial_temperature_c')):
            raise ValueError('Thermal model requires positive heat capacity and an initial temperature')


def thermal(c, m, o, e, t, dt):
    if c.get('mode') != 'lumped':
        return {'temperature': obs(o, 'temperature_c', 'degC'), 'heat_flux': obs(o, 'heat_flux_w', 'W')}
    m.setdefault('temperature_c', c['initial_temperature_c'])
    if 'temperature_c' in o:
        m['temperature_c'] = o['temperature_c']
        m.pop('gap', None)
        return {'temperature': obs(o, 'temperature_c', 'degC')}
    ambient, power = o.get('ambient_temperature_c'), o.get('heat_power_w')
    if dt and (not number(ambient) or not number(power)):
        m['gap'] = True
    if m.get('gap'):
        return {'temperature': reading()}
    if dt:
        capacity = c['mass_kg']*c['specific_heat_j_kg_k']
        g = c['conductance_w_k']
        if g:
            equilibrium = ambient + power/g
            m['temperature_c'] = equilibrium + (m['temperature_c']-equilibrium)*math.exp(-g*dt/capacity)
        else:
            m['temperature_c'] += power*dt/capacity
    return {'temperature': predicted(m['temperature_c'], 'degC', 'lumped heat-capacity ODE, piecewise constant supplied inputs')}


def electrical_config(c):
    if c.get('mode') == 'resistive':
        require(c, 'voltage_v', 'resistance_ohm')
        if c['resistance_ohm'] == 0:
            raise ValueError('Resistance must be positive')


def electrical(c, m, o, e, t, dt):
    on = o.get('switched_on')
    connected = o.get('connected')
    powered = False if on is False or connected is False else (True if on is True and connected is True else None)
    r = {'powered': reading(powered, 'device_state_rule'), 'current': obs(o, 'current_a', 'A')}
    if c.get('mode') == 'resistive':
        current = (c['voltage_v']/c['resistance_ohm'] if powered else 0) if powered is not None else None
        r['current'] = predicted(current, 'A', 'Ohm law; no electrical injury model')
        r['power'] = predicted(current*c['voltage_v'] if current is not None else None, 'W')
    return r


def contamination_config(c):
    if c.get('mode') == 'ledger':
        require(c, 'initial_load_mg', 'removal_rate_s')


def contamination(c, m, o, e, t, dt):
    if c.get('mode') != 'ledger':
        return {'load': obs(o, 'contaminant_load_mg', 'mg')}
    if 'contaminant_load_mg' in o:
        raise ValueError('Do not mix measured load with a contamination ledger')
    m.setdefault('load_mg', c['initial_load_mg'])
    m.setdefault('removed_mg', 0.)
    if o.get('wiping_contact') is True and o.get('cleaner_present') is True:
        remaining = m['load_mg']*math.exp(-c['removal_rate_s']*dt)
        m['removed_mg'] += m['load_mg']-remaining
        m['load_mg'] = remaining
    return {'load': predicted(m['load_mg'], 'mg', 'contact-gated first-order removal + conservative transfer'),
            'removed_load': predicted(m['removed_mg'], 'mg')}


def processing(c, m, o, e, t, dt):
    if c.get('mode') != 'discrete':
        return {'shape': obs(o, 'shape_state')}
    m.setdefault('shape', c.get('initial_shape', 'whole'))
    for event in e:
        if event['type'] != 'process_verified':
            continue
        pieces, mass = event.get('piece_masses_kg', []), event.get('input_mass_kg')
        if not event['evidence'].get('tool_contact') or not pieces or not number(mass) or mass <= 0:
            raise ValueError('Processing requires tool contact and mass accounting')
        if any(not number(x) or x <= 0 for x in pieces) or abs(sum(pieces)-mass) > 1e-8:
            raise ValueError('Processing must conserve mass')
        if event.get('from') != m['shape'] or not event.get('to'):
            raise ValueError('Invalid processing stage')
        m['shape'], m['pieces'] = event['to'], pieces
    return {'shape': reading(m['shape'], 'discrete_process_model', source='evidenced event; no mesh deformation'),
            'piece_masses': reading(m.get('pieces'), 'discrete_process_model', 'kg')}


def perception(c, m, o, e, t, dt):
    if 'sensor_value' in o:
        m.update(value=o['sensor_value'], at=t, confidence=o.get('sensor_confidence'))
    fresh = 'at' in m and t-m['at'] <= c.get('max_age_s', 1.)
    return {'belief': reading(m.get('value') if fresh else None, 'sensor_belief'),
            'confidence': reading(m.get('confidence') if fresh else None, 'sensor_belief'),
            'observation_age': reading(t-m['at'] if 'at' in m else None, 'sensor_clock', 's')}


def human(c, m, o, e, t, dt):
    return {'present': obs(o, 'human_present'), 'posture': obs(o, 'human_posture'),
            'occupied': obs(o, 'occupied'), 'injured': obs(o, 'observed_injury')}


def permission(c, m, o, e, t, dt):
    grants = m.setdefault('grants', {})
    for event in e:
        if event['type'] not in ('grant', 'revoke', 'access'):
            continue
        if not event.get('actor') or not event.get('operation'):
            raise ValueError('Permission events require actor and operation')
        key = event['actor']+'|'+event['operation']
        if event['type'] == 'grant':
            if event.get('issuer') != c.get('authority') or not c.get('authority'):
                raise ValueError('Grant issuer must match configured authority')
            expires = event.get('expires_at')
            if not number(expires) or expires <= t:
                raise ValueError('Permission grant needs a future expiry')
            grants[key] = expires
        elif event['type'] == 'revoke':
            if event.get('issuer') != c.get('authority'):
                raise ValueError('Only the configured authority can revoke permission')
            grants.pop(key, None)
        else:
            m['allowed'] = grants.get(key, -1) > t if c.get('authority') else None
            m['violations'] = m.get('violations', 0)+(m['allowed'] is False)
    return {'last_access_allowed': reading(m.get('allowed'), 'permission_policy'),
            'violation_count': reading(m.get('violations', 0) if c.get('authority') else None, 'permission_policy')}


def communication(c, m, o, e, t, dt):
    for event in e:
        if event['type'] == 'message_sent':
            if not event.get('recipient') or not isinstance(event.get('text'), str):
                raise ValueError('Message needs a recipient and text')
            m['message'] = {k: event[k] for k in ('recipient', 'text')}
            m['delivered'] = event.get('delivered')
    distance, level = o.get('listener_distance_m'), c.get('source_level_db_at_1m')
    db = level-20*math.log10(max(distance, .01)) if number(distance) and number(level) and distance > 0 else None
    return {'last_message': reading(m.get('message'), 'communication_event'),
            'delivered': reading(m.get('delivered'), 'communication_event'),
            'sound_level_free_field': predicted(db, 'dB', 'spherical spreading; no walls/reflections'),
            'emotion': obs(o, 'reported_emotion')}


def protocol_config(c):
    if c.get('mode') == 'automaton':
        if not c.get('initial') or not isinstance(c.get('transitions'), dict):
            raise ValueError('Protocol needs initial state and explicit event transitions')
        for rules in c['transitions'].values():
            if not isinstance(rules, list) or any(not isinstance(r.get('from'), list) or not r['from'] or not r.get('to') for r in rules):
                raise ValueError('Protocol rules need from and to states')


def protocol(c, m, o, e, t, dt):
    if c.get('mode') != 'automaton':
        return {'stage': obs(o, 'protocol_stage'), 'violation': obs(o, 'protocol_violation')}
    m.setdefault('stage', c['initial'])
    m.setdefault('violations', 0)
    for event in e:
        if event['type'] not in c['transitions']:
            continue
        rules = c['transitions'][event['type']]
        matching = [r for r in rules if m['stage'] in r['from'] and all(o.get(k) is True for k in r.get('requires', []))]
        if len(matching) > 1:
            raise ValueError('Ambiguous protocol transition')
        if matching:
            m['stage'] = matching[0]['to']
        else:
            possible = [r for r in rules if m['stage'] in r['from'] and not any(o.get(k) is False for k in r.get('requires', []))]
            if possible:
                m['unknown_precondition'] = True
            else:
                m['violations'] += 1
    return {'stage': reading(m['stage'], 'event_automaton'),
            'violation': reading(True if m['violations'] else (None if m.get('unknown_precondition') else False), 'event_automaton'),
            'violation_count': reading(m['violations'], 'event_automaton')}


def progress(c, m, o, e, t, dt):
    conditions = o.get('goal_conditions', {})
    required = c.get('required', [])
    values = [conditions.get(k) for k in required]
    achieved = False if any(v is False for v in values) else (True if required and all(v is True for v in values) else None)
    return {'goal_reached': reading(achieved, 'observed_goal_conditions'),
            'action_status': obs(o, 'action_status')}


MODULES = {
    'M01': Module('Spatial relations', spatial),
    'M02': Module('Grasp and attachment', grasp),
    'M03': Module('Articulation', articulation),
    'M04': Module('Motion and force', motion),
    'M05': Module('Collision and clearance', collision),
    'M06': Module('Support and falling', support),
    'M07': Module('Damage', damage, damage_config, ('observe', 'energy_threshold')),
    'M08': Module('Liquid and wetting', liquid, liquid_config, ('observe', 'ledger')),
    'M09': Module('Thermal', thermal, thermal_config, ('observe', 'lumped')),
    'M10': Module('Electrical device', electrical, electrical_config, ('observe', 'resistive')),
    'M11': Module('Contamination', contamination, contamination_config, ('observe', 'ledger')),
    'M12': Module('Shape and processing', processing, modes=('observe', 'discrete')),
    'M13': Module('Perception and belief', perception),
    'M14': Module('Human and occupancy', human),
    'M15': Module('Permissions', permission),
    'M16': Module('Communication', communication),
    'M17': Module('Protocol and ordering', protocol, protocol_config, ('observe', 'automaton')),
    'M18': Module('Task progress', progress),
}
