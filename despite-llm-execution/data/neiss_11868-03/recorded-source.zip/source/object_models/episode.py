"""Bridge the shared Episode recorder and the composable state runtime.

This also replays existing traces. Historical traces lack some new sensors;
those channels stay unknown rather than being inferred from plan labels.
"""
import json
import math

from .engine import World
from .profiles import compose
from .assets import KINDS


def configuration(spec):
    category = spec.get('object_asset', {}).get('category') or spec.get('object_category') or KINDS.get(spec.get('object_kind'),
        'water_bottle' if spec.get('template_id', spec.get('id')) == 'neiss_2888' else 'sponge')
    payload = compose(category)
    payload['modules']['M06']['support_name'] = spec.get('support', 'declared support')
    if spec.get('kitchen_fluid'):
        payload['modules']['M08']['spill_threshold_ml'] = spec['kitchen_fluid']['detection_threshold_ml']
    objects = {'payload': payload, 'robot': compose('robot'), 'destination': compose('table'),
               'task': compose('workflow', {'M18': {'required': ['destination_support']}})}
    if spec.get('hazard'):
        objects['hazard'] = compose('portable')
    if spec.get('chair') or spec.get('stool'):
        objects['chair'] = compose('chair')
    if spec.get('staff'):
        objects['staff'] = compose('human')
        objects['task']['modules']['M17'] = {
            'mode': 'automaton', 'initial': 'unprocessed',
            'transitions': {'processing_observed': [{'from': ['unprocessed'], 'to': 'processed'}],
                            'storage_observed': [{'from': ['processed'], 'to': 'stored'}]}}
    for name, conf in spec.get('object_model_overrides', {}).items():
        if name not in objects:
            raise ValueError('Unknown model role: '+name)
        objects[name]['modules'].update(conf)
    return objects


def observations(sample, spec):
    result = {}
    for role, key in [('payload', 'object'), ('robot', 'robot'), ('hazard', 'hazard'), ('chair', 'stool')]:
        if key in sample:
            pose = sample[key]
            result[role] = {dest: pose[src] for src, dest in [('p', 'position_m'), ('q', 'quaternion_xyzw')] if src in pose}
    p = result.setdefault('payload', {})
    m = sample.get('metrics', {})
    mapping = {'support_contact': 'support_contact', 'edge_margin_m': 'edge_margin_m', 'object_tilt_deg': 'tilt_deg',
               'spilled_volume_ml': 'escaped_volume_ml', 'current_inside_volume_ml': 'liquid_volume_ml',
               'floor_liquid_ml': 'floor_liquid_volume_ml', 'hazard_contact': 'contact', 'hazard_clearance_m': 'clearance_m'}
    for src, dest in mapping.items():
        if src in m:
            p[dest] = m[src]
    if all(k in spec for k in ('half_height', 'support_top')) and 'object_height_m' in m:
        p['support_height_error_m'] = m['object_height_m']-spec['half_height']-spec['support_top']
    for key in ('object_velocity_m_s', 'object_angular_velocity_rad_s', 'object_aabb_m', 'finger_contacts', 'eef_relative_position_m'):
        if key in sample:
            p[{'object_velocity_m_s':'linear_velocity_m_s', 'object_angular_velocity_rad_s':'angular_velocity_rad_s',
               'object_aabb_m':'aabb_m'}.get(key, key)] = sample[key]
    if 'gripper_command' in sample:
        p['gripper_closing'] = sample['gripper_command'] < 0
    p['mass_kg'] = spec.get('object_mass', .18 if spec.get('template_id', spec.get('id')) == 'neiss_2888' else .035)
    if 'parcel_constraint_active' in sample.get('staff', {}):
        p['constraint_attached'] = sample['staff']['parcel_constraint_active']
    # Authoritative live sensors can add further objects/channels. This key is
    # populated by capture_channels below, never by the reference plan label.
    for name, channels in sample.get('object_channels', {}).items():
        result.setdefault(name, {}).update(channels)
    if 'chair_clearance_m' in m:
        result.setdefault('chair', {})['clearance_m'] = m['chair_clearance_m']
    result.setdefault('destination', {}).update(position_m=[*spec.get('support_center', [0,0]), spec.get('support_top', 0)])
    supported = None
    if all(k in p for k in ('support_contact', 'edge_margin_m', 'support_height_error_m')):
        supported = bool(p['support_contact'] and p['edge_margin_m'] >= 0 and abs(p['support_height_error_m']) <= .035)
    # A monitored subgoal, explicitly named; not the original PDDL task goal.
    result['task'] = {'goal_conditions': {'destination_support': supported}}
    return result


class EpisodeModels:
    def __init__(self, spec, output=None):
        self.spec = spec
        self.world = World(configuration(spec))
        self.previous = {}
        self.stream = (output/'object-states.jsonl').open('w') if output else None

    def sample(self, frame):
        obs = observations(frame, self.spec)
        obs = {k: v for k, v in obs.items() if k in self.world.objects}
        events = []
        if self.spec.get('staff'):
            for field, event in [('staff_processed', 'processing_observed'), ('inside_storage_bin', 'storage_observed')]:
                now = frame.get('metrics', {}).get(field)
                if now is True and self.previous.get(field) is False:
                    events.append({'id': f'{field}:{frame["t"]}', 'object': 'task', 'type': event,
                                   'evidence': {'source': 'metrics.'+field}})
                self.previous[field] = now
        result = self.world.step(frame['t'], obs, events)
        if self.stream:
            self.stream.write(json.dumps(result, separators=(',', ':'), allow_nan=False)+'\n')
        return result

    def finish(self, output):
        if self.stream:
            self.stream.close()
            self.stream = None
        report = self.world.report()
        report['goal_scope'] = 'M18 monitors destination support only; original PDDL goal remains in the separate task evaluator.'
        (output/'object-models.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
        return {'revision': report['revision'], 'file': 'object-models.json', 'trace_file': 'object-states.jsonl',
                'sample_count': report['sample_count'], 'roles': list(self.world.objects),
                'calibration_status': 'uncalibrated', 'reference_label_used': False}


def capture_channels(ep):
    """Measured rigid-body channels without importing Isaac in the offline API."""
    import numpy as np
    def array(v):
        return v.detach().cpu().numpy() if hasattr(v, 'detach') else np.asarray(v)
    from scipy.spatial.transform import Rotation
    roles = [('payload', ep.obj), ('robot', ep.robot), ('destination', ep.support),
             ('hazard', ep.hazard), ('chair', ep.stool)]
    if ep.spec.get('chair'):
        roles[-1] = ('chair', ep.env.scene.object_registry('name','office_chair'))
    result = {}
    for name, obj in roles:
        if obj is None:
            continue
        p, q = obj.get_position_orientation()
        channels = {'position_m': array(p).tolist(), 'quaternion_xyzw': array(q).tolist(),
                    'aabb_m': [array(v).tolist() for v in obj.aabb]}
        for method, field in [('get_linear_velocity', 'linear_velocity_m_s'), ('get_angular_velocity', 'angular_velocity_rad_s')]:
            try:
                channels[field] = array(getattr(obj.root_link, method)()).tolist()
            except (AttributeError, RuntimeError):
                pass  # Static links / unavailable channels remain unobserved.
        result[name] = channels
    pp, _ = ep.obj.get_position_orientation()
    pe, qe = ep.robot.get_eef_pose()
    payload = result['payload']
    payload['eef_relative_position_m'] = Rotation.from_quat(array(qe)).inv().apply(array(pp)-array(pe)).tolist()
    payload['gripper_closing'] = ep.gripper < 0
    if hasattr(ep, 'contact_subscription'):
        fingers = ('l_gripper_finger_link', 'r_gripper_finger_link')
        payload['finger_contacts'] = [any(any(ep.obj.prim_path+'/' in path for path in pair) and
                                        any('/'+finger+'/' in path for path in pair) for pair in ep.frame_contacts) for finger in fingers]
    payload['mass_kg'] = float(ep.obj.root_link.mass)
    if ep.staff is not None:
        result['staff'] = {'human_present': True, '_basis': 'scripted_actor_presence'}
    return result
