"""Mechanism / invariant tests independent of GPU rendering."""
import json
import math
from pathlib import Path
import tempfile
import unittest

from .engine import World
from .modules import MODULES
from .profiles import compose
from .assets import select, bind, apply_geometry
from .episode import EpisodeModels


def value(frame, obj, module, state):
    return frame['objects'][obj][module][state]['value']


def event(kind, obj='x', ident='e1', **kwargs):
    return {'id': ident, 'object': obj, 'type': kind, 'evidence': {'source': 'test measurement', 'tool_contact': True}, **kwargs}


class CapabilitiesTest(unittest.TestCase):
    def test_all_18_modules_unknown_without_observations(self):
        self.assertEqual(set(MODULES), {f'M{i:02}' for i in range(1,19)})
        world = World({'x': {'modules': {m: {} for m in MODULES}}})
        frame = world.step(0)
        self.assertTrue(all(s['value'] is None for states in frame['objects']['x'].values() for s in states.values()))

    def test_profiles_are_composable_and_independent(self):
        cup, chair = compose('cup'), compose('chair')
        self.assertIn('M08', cup['modules'])
        self.assertIn('M14', chair['modules'])
        cup['modules']['M09']['mode'] = 'lumped'
        self.assertEqual(compose('cup')['modules']['M09'], {})

    def test_spatial_full_object_not_just_center(self):
        w = World({'x': {'modules': {'M01': {'regions': {'box': [[0,0,0],[1,1,1]]}}, 'M03': {'closed_position': 0, 'open_position': 1}}}})
        f = w.step(0, {'x': {'aabb_m': [[.4,.4,.4],[1.1,.6,.6]], 'joint_position': .95}})
        self.assertFalse(value(f,'x','M01','inside.box'))
        self.assertTrue(value(f,'x','M03','open'))

    def test_grasp_requires_bilateral_contact_dwell_and_relative_motion(self):
        w = World({'x': compose('portable')})
        o = {'finger_contacts': [True, False], 'gripper_closing': True, 'eef_relative_position_m': [0,0,.05]}
        self.assertFalse(value(w.step(0, {'x':o}),'x','M02','held'))
        o['finger_contacts'] = [True,True]
        self.assertFalse(value(w.step(.1, {'x':o}),'x','M02','held'))
        self.assertFalse(value(w.step(.2, {'x':o}),'x','M02','held'))
        self.assertTrue(value(w.step(.26, {'x':o}),'x','M02','held'))
        o['eef_relative_position_m'] = [0,0,.10]
        self.assertFalse(value(w.step(.3, {'x':o}),'x','M02','held'))
        self.assertIsNone(value(w.step(.4),'x','M02','held'))

    def test_stability_needs_velocity_and_dwell(self):
        w = World({'x': compose('portable')})
        o = {'support_contact': True, 'edge_margin_m': .05, 'support_height_error_m': .001}
        self.assertIsNone(value(w.step(0, {'x':o}),'x','M06','stable'))
        o.update(linear_velocity_m_s=[0,0,0], angular_velocity_rad_s=[0,0,0])
        self.assertFalse(value(w.step(.2, {'x':o}),'x','M06','stable'))
        self.assertTrue(value(w.step(.8, {'x':o}),'x','M06','stable'))
        o['edge_margin_m'] = -.01
        self.assertFalse(value(w.step(.9, {'x':o}),'x','M06','stable'))

    def test_grip_seating_is_not_latched_as_permanent_release(self):
        w=World({'x':compose('portable')})
        for i in range(10):
            f=w.step(i*.1,{'x':{'finger_contacts':[True,True],'gripper_closing':True,
                               'eef_relative_position_m':[0,0,.1+i*.002]}})
        self.assertTrue(value(f,'x','M02','held'))
        self.assertTrue(value(f,'x','M02','grip_shift_exceeds_threshold'))

    def test_motion_collision_and_fall_are_not_injury(self):
        w = World({'x': compose('portable', {'M05': {'minimum_clearance_m': .2}}, extra={'M14': {}})})
        w.step(0, {'x': {'linear_velocity_m_s': [0,0,0]}})
        f = w.step(1, {'x': {'linear_velocity_m_s': [0,0,-1], 'mass_kg': 2,
                              'clearance_m': .1, 'constrained': False, 'any_support_contact': False}})
        self.assertEqual(value(f,'x','M04','translational_energy'),1)
        self.assertTrue(value(f,'x','M05','clearance_violation'))
        self.assertTrue(value(f,'x','M06','falling'))
        self.assertIsNone(value(f,'x','M14','injured'))

    def test_liquid_transfer_conserves_and_overflow_rolls_back(self):
        cfg = lambda n: {'modules': {'M08': {'mode':'ledger','initial_volume_ml':n,'capacity_ml':100}}}
        w = World({'x':cfg(80), 'floor':cfg(0)})
        w.step(0)
        f = w.step(1, events=[event('liquid_transfer', target='floor', amount=20)])
        self.assertEqual(value(f,'x','M08','volume')+value(f,'floor','M08','volume'),80)
        before = w.report()
        with self.assertRaises(ValueError):
            w.step(2, events=[event('liquid_transfer',ident='e2',target='floor',amount=70)])
        self.assertEqual(w.report(),before)
        with self.assertRaises(ValueError):
            w.step(2, {'x':{'liquid_volume_ml':40}})

    def test_particle_spill_is_observed_not_label(self):
        w = World({'x':compose('cup', {'M08':{'spill_threshold_ml':1}})})
        w.step(0, {'x':{'escaped_volume_ml':0}})
        f = w.step(1, {'x':{'escaped_volume_ml':2.3}})
        self.assertTrue(value(f,'x','M08','spilled'))
        self.assertEqual(f['transitions'][0]['t'],1)
        self.assertIsNone(value(w.step(2),'x','M08','spilled'))

    def test_instantaneous_liquid_volume_is_not_never_escaped_history(self):
        model = EpisodeModels({'id':'neiss_11868', 'object_kind':'cup',
                               'kitchen_fluid':{'detection_threshold_ml':1}})
        old = model.sample({'t':0, 'metrics':{'spilled_volume_ml':2, 'unspilled_volume_ml':98}})
        self.assertIsNone(value(old,'payload','M08','volume'))
        # A drop can return to the cavity; the cumulative escape event stays
        # true while actual occupancy increases independently.
        now = model.sample({'t':1, 'metrics':{'spilled_volume_ml':2, 'unspilled_volume_ml':98,
                                            'current_inside_volume_ml':99}})
        self.assertEqual(value(now,'payload','M08','volume'),99)
        self.assertTrue(value(now,'payload','M08','spilled'))

    def test_cooling_closed_form_and_observation_gap(self):
        w = World({'x':{'modules':{'M09':{'mode':'lumped','initial_temperature_c':80,
            'mass_kg':1,'specific_heat_j_kg_k':100,'conductance_w_k':10}}}})
        w.step(0)
        f = w.step(10, {'x':{'ambient_temperature_c':20,'heat_power_w':0}})
        self.assertAlmostEqual(value(f,'x','M09','temperature'),20+60/math.e)
        self.assertIsNone(value(w.step(11),'x','M09','temperature'))
        self.assertIsNone(value(w.step(12, {'x':{'ambient_temperature_c':20,'heat_power_w':0}}),'x','M09','temperature'))
        self.assertEqual(value(w.step(13, {'x':{'temperature_c':35}}),'x','M09','temperature'),35)

    def test_switch_state_gates_electrical_power(self):
        w = World({'x':{'modules':{'M10':{'mode':'resistive','voltage_v':12,'resistance_ohm':6}}}})
        self.assertIsNone(value(w.step(0),'x','M10','current'))
        self.assertEqual(value(w.step(1,{'x':{'connected':True,'switched_on':True}}),'x','M10','power'),24)
        self.assertEqual(value(w.step(2,{'x':{'connected':False}}),'x','M10','current'),0)

    def test_cleaning_transfer_and_removal_mass_accounting(self):
        cfg = lambda n: {'modules':{'M11':{'mode':'ledger','initial_load_mg':n,'removal_rate_s':1}}}
        w = World({'x':cfg(10),'cloth':cfg(0)})
        w.step(0)
        w.step(1,events=[event('contaminant_transfer',target='cloth',amount=4)])
        f=w.step(2,{'cloth':{'wiping_contact':True,'cleaner_present':True}})
        self.assertAlmostEqual(value(f,'x','M11','load')+value(f,'cloth','M11','load')+value(f,'cloth','M11','removed_load'),10)

    def test_fracture_prediction_is_explicit_and_processing_mass_conserves(self):
        w=World({'x':{'modules':{'M07':{'mode':'energy_threshold','fracture_energy_j':2}, 'M12':{'mode':'discrete'}}}})
        f=w.step(0,{'x':{'impact_energy_j':3}},[event('process_verified', **{'from':'whole','to':'two_pieces','input_mass_kg':1,'piece_masses_kg':[.4,.6]})])
        self.assertTrue(value(f,'x','M07','broken'))
        self.assertEqual(f['objects']['x']['M07']['broken']['basis'],'reduced_order_prediction')
        self.assertEqual(value(f,'x','M12','shape'),'two_pieces')

    def test_belief_expires_without_changing_truth(self):
        w=World({'x':compose('robot')})
        self.assertEqual(value(w.step(0,{'x':{'sensor_value':'cup','sensor_confidence':.8}}),'x','M13','belief'),'cup')
        self.assertIsNone(value(w.step(2),'x','M13','belief'))

    def test_permission_expiry_and_messages_are_not_emotions(self):
        w=World({'x':compose('workflow',{'M15':{'authority':'owner'}})})
        w.step(0,events=[event('grant',actor='robot',operation='open',issuer='owner',expires_at=1)])
        self.assertTrue(value(w.step(.5,events=[event('access',ident='a1',actor='robot',operation='open')]),'x','M15','last_access_allowed'))
        f=w.step(2,events=[event('access',ident='a2',actor='robot',operation='open'),event('message_sent',ident='m1',recipient='person',text='Delivery ready')])
        self.assertFalse(value(f,'x','M15','last_access_allowed'))
        self.assertIsNone(value(f,'x','M16','emotion'))
        self.assertIsNone(value(f,'x','M16','delivered'))

    def test_protocol_violation_independent_of_goal_success(self):
        w=World({'x':compose('workflow',{'M17':{'mode':'automaton','initial':'raw','transitions':{
            'process':[{'from':['raw'],'to':'processed'}], 'store':[{'from':['processed'],'to':'stored'}]}},
            'M18':{'required':['in_bin']}})})
        f=w.step(0, {'x':{'goal_conditions':{'in_bin':True}}},[event('store')])
        self.assertTrue(value(f,'x','M17','violation'))
        self.assertTrue(value(f,'x','M18','goal_reached'))

    def test_duplicate_event_nonfinite_and_time_regression_fail_atomically(self):
        w=World({'x':compose('workflow')})
        e=event('message_sent',recipient='p',text='Hi')
        w.step(1,events=[e])
        for t, obs, ev in [(0,{},[]),(2,{},[e]),(2,{'x':{'temperature_c':float('nan')}},[])]:
            with self.assertRaises(ValueError):w.step(t,obs,ev)
        self.assertEqual(w.time,1)

    def test_unobserved_protocol_precondition_is_unknown_not_violation(self):
        w=World({'x':{'modules':{'M17':{'mode':'automaton','initial':'raw','transitions':{
            'store':[{'from':['raw'],'to':'stored','requires':['checked']}]
        }}}}})
        f=w.step(0,events=[event('store')])
        self.assertIsNone(value(f,'x','M17','violation'))
        self.assertEqual(value(f,'x','M17','stage'),'raw')

    def test_reception_bridge_uses_observed_events_not_plan_label(self):
        spec={'id':'normbank_86816','scene_id':'lobby','object_kind':'carton','staff':True,
              'support_center':[1,2],'support_top':1,'half_height':.05}
        for processed, expected in [(True,False),(False,True)]:
            model=EpisodeModels(spec)
            for t,stored in [(0,False),(1,False),(2,True)]:
                model.sample({'t':t,'metrics':{'staff_processed':processed and t>=1,'inside_storage_bin':stored}})
            self.assertEqual(model.world.states['task']['M17']['violation']['value'],expected)

    def test_nonfinite_parameter_is_rejected_before_execution(self):
        with self.assertRaises(ValueError):
            World({'x':{'modules':{'M09':{'conductance_w_k':float('nan')}}}})

    def test_assets_are_semantic_and_pair_deterministic(self):
        self.assertEqual(select('water_bottle','scene-A',3),select('water_bottle','scene-A',3))
        choices={select('water_bottle',f'scene-{i}')['id'] for i in range(30)}
        self.assertEqual(len(choices),2)
        self.assertEqual(select('water_bottle','scene',asset_id='behavior-water-ackxiy')['id'],'behavior-water-ackxiy')
        with self.assertRaises(ValueError): select('water_bottle','scene',asset_id='genie-medicine-000')
        with self.assertRaises(ValueError): select('water_bottle','scene',required=['fluid_vessel_cup105'])

    def test_asset_geometry_updates_grasp_support_mass_and_footprint(self):
        spec={'id':'neiss_2888','source':[0,0,0],'target':[1,1,0],'source_support_top':.6,'support_top':.7}
        bind(spec,asset_id='behavior-water-lzdzkk')
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'asset.usda';f.write_text('test derived geometry')
            apply_geometry(spec,[.08,.09,.25],str(f))
        self.assertAlmostEqual(spec['source'][2],.726)
        self.assertAlmostEqual(spec['target'][2],.825)
        self.assertAlmostEqual(spec['grasp_height_offset'],.1)
        self.assertEqual(spec['object_mass'],.34)
        self.assertEqual(spec['object_half_xy'],[.04,.045])

    def test_source_task_key_is_preserved_for_shared_engine_aliases(self):
        spec={'id':'neiss_2888'}
        bind(spec,scene_key='neiss_9506')
        self.assertEqual(spec['object_asset']['selection']['scene_key'],'neiss_9506')
        self.assertEqual(spec['object_asset']['id'],select('water_bottle','neiss_9506')['id'])
        original={'id':'neiss_2888'}
        self.assertIsNone(bind(original,policy='fixed'))
        self.assertNotIn('object_asset',original)


if __name__=='__main__':
    unittest.main()
