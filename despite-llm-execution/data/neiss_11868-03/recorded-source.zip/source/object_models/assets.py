"""Semantic asset selection shared across plan variants, with physical recipes.

Selection never takes a reference label. Assets with the same broad shape
are not automatically interchangeable: a medicine bottle is not drinking water,
and an arbitrary mug cannot use another cup's fluid collision vessel.
"""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path

from simulation.runtime import ROOT, RUNTIME

CATALOG = Path(__file__).with_name('assets.json')
KINDS = {'water': 'water_bottle', 'medicine': 'medicine_bottle', 'cup': 'cup', 'carton': 'carton'}


def catalog():
    data = json.loads(CATALOG.read_text())
    if len({a['id'] for a in data['assets']}) != len(data['assets']):
        raise ValueError('Duplicate asset id')
    return data


def get_asset(asset_id):
    return deepcopy(next(a for a in catalog()['assets'] if a['id'] == asset_id))


def source_path(asset):
    path = (RUNTIME / asset['source_path']).resolve()
    if not path.is_relative_to(RUNTIME.resolve()):
        raise ValueError('Asset path leaves runtime directory')
    return path


def select(category, scene_key, seed=0, asset_id=None, required=()):
    candidates = sorted((a for a in catalog()['assets'] if a['category'] == category
                         and set(required) <= set(a['features'])
                         and (asset_id or a.get('selection_status') != 'experimental')), key=lambda a: a['id'])
    if asset_id:
        candidates = [a for a in candidates if a['id'] == asset_id]
    if not candidates:
        raise ValueError(f'No compatible {category} asset for {asset_id or list(required)}')
    # Do not filter by locally available files: that silently changes the draw
    # across machines. Missing dependencies are explicit errors.
    digest = hashlib.sha256(f'{scene_key}\0{seed}\0{category}'.encode()).digest()
    asset = deepcopy(candidates[int.from_bytes(digest[:8], 'big') % len(candidates)])
    if not source_path(asset).is_file():
        raise FileNotFoundError(source_path(asset))
    digest = hashlib.sha256(source_path(asset).read_bytes()).hexdigest()
    if asset.get('source_sha256') and asset['source_sha256'] != digest:
        raise ValueError('Pinned asset checksum mismatch: ' + asset['id'])
    return asset


def bind(spec, *, policy='scene', seed=0, asset_id=None, scene_key=None):
    """Bind the task payload. Fixed policy exactly reproduces legacy assets."""
    if policy not in ('fixed', 'scene'):
        raise ValueError('Asset policy must be fixed or scene')
    kind = spec.get('object_kind', 'water' if spec.get('template_id', spec['id']) == 'neiss_2888' else None)
    category = spec.get('object_category') or KINDS.get(kind)
    if category is None:
        if asset_id:
            raise ValueError('This task has no interchangeable payload category')
        return None
    if policy == 'fixed' and not asset_id:
        return None
    required = ['fluid_vessel_cup105'] if spec.get('kitchen_fluid') else spec.get('asset_requirements', ['transport'])
    scene_key = scene_key or spec['id']
    asset = select(category, scene_key, seed, asset_id, required)
    spec['object_asset'] = {**asset, 'selection': {'policy': policy, 'seed': seed, 'scene_key': scene_key,
                                                'paired_variants_share_asset': True},
                            'source_sha256': hashlib.sha256(source_path(asset).read_bytes()).hexdigest(),
                            'calibration_status': 'uncalibrated'}
    return asset


def apply_geometry(spec, dimensions, path):
    """Update all payload-dependent geometry after baking the selected mesh."""
    asset = spec.get('object_asset')
    if not asset:
        return
    dims = [float(x) for x in dimensions]
    if len(dims) != 3 or any(not math.isfinite(x) or x <= 0 for x in dims):
        raise ValueError('Asset has invalid metric geometry')
    if max(dims) > .5:
        raise ValueError('Selected payload exceeds supported Fetch transport envelope')
    grasp = asset['grasp']
    offset = grasp['height_offset_m'] if 'height_offset_m' in grasp else dims[2] * grasp['height_fraction_from_center']
    if abs(offset) > dims[2]/2 or asset['grasp']['maximum_width_m'] > .10:
        raise ValueError('Grasp recipe exceeds object or Fetch gripper envelope')
    spec.update(half_height=dims[2]/2, object_half_xy=[dims[0]/2, dims[1]/2],
                object_radius=math.hypot(dims[0]/2, dims[1]/2), grasp_height_offset=offset)
    if asset.get('total_mass_kg') is not None:
        spec['object_mass'] = asset['total_mass_kg']
    if asset.get('transport_upright'):
        spec['transport_upright'] = True
    # Support tops are measured separately from the actual scene geometry.
    if 'source_support_top' in spec:
        spec['source'][2] = spec['source_support_top'] + dims[2]/2 + .001
    if 'support_top' in spec:
        spec['target'][2] = spec['support_top'] + dims[2]/2
    asset.update(baked_dimensions_m=dims, baked_path=path,
                 baked_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                 effective_mass_kg=spec.get('object_mass', .18),
                 effective_grasp_height_offset_m=offset,
                 physics_validation='requires_episode_validation')


def material(spec):
    return spec.get('object_asset', {}).get('friction', {'static_friction': 1., 'dynamic_friction': .8, 'restitution': 0.})
