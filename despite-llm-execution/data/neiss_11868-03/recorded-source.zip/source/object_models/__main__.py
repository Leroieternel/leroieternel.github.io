"""Run capability models, replay recorded episodes, or inspect asset choices."""
import argparse
import json
from pathlib import Path

from .engine import World
from .episode import EpisodeModels
from .assets import catalog, source_path
from .modules import MODULES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--replay-run', type=Path)
    mode.add_argument('--config', type=Path, help='JSON object configuration; observations and events supplied as JSONL')
    mode.add_argument('--inventory', action='store_true')
    parser.add_argument('--input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.inventory:
        assets = catalog()
        for asset in assets['assets']:
            asset['installed'] = source_path(asset).is_file()
        (args.output/'assets.json').write_text(json.dumps(assets, indent=2)+'\n')
        (args.output/'modules.json').write_text(json.dumps({k: {'name': v.name, 'modes': v.modes} for k, v in MODULES.items()}, indent=2)+'\n')
    elif args.replay_run:
        # Source results/videos are immutable. Replay output is a new artifact.
        if args.output.resolve() == args.replay_run.resolve():
            raise ValueError('Replay must use a separate output directory')
        result = json.loads((args.replay_run/'result.json').read_text())
        model = EpisodeModels(result['spec'], args.output)
        for frame in json.loads((args.replay_run/'trace.json').read_text()):
            model.sample(frame)
        model.finish(args.output)
    else:
        if not args.input:
            parser.error('--config requires --input')
        world = World(json.loads(args.config.read_text())['objects'])
        with args.input.open() as inputs, (args.output/'object-states.jsonl').open('w') as out:
            for line in inputs:
                frame = json.loads(line)
                state = world.step(frame['t'], frame.get('observations'), frame.get('events'))
                out.write(json.dumps(state, allow_nan=False)+'\n')
        (args.output/'object-models.json').write_text(json.dumps(world.report(), indent=2, allow_nan=False)+'\n')
    print(str(args.output))


if __name__ == '__main__':
    main()
