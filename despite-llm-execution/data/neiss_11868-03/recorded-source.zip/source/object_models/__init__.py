"""Composable, evidence-bearing object capabilities. No reference-label input."""

REVISION = 'despite-object-capabilities-v1'

from .engine import World
from .profiles import compose

__all__ = ['REVISION', 'World', 'compose']
