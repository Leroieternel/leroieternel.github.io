"""Small world-state runtime with explicit observation and event contracts.

Dynamics stay in Isaac/PhysX. Optional lumped models and protocol automata
are explicitly labelled, uncalibrated, and do not silently change USD geometry.
Inputs are measured channels or evidenced events, not action names or labels.
"""
from copy import deepcopy
import math

from . import REVISION
from .modules import MODULES


def finite(value):
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, dict):
        return all(finite(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return all(finite(v) for v in value)
    return True


class World:
    def __init__(self, objects):
        if not finite(objects):
            raise ValueError('Nonfinite object configuration')
        self.objects = deepcopy(objects)
        self.memory = {name: {} for name in objects}
        self.time = None
        self.states = {}
        self.transitions = []
        self.events_seen = set()
        self.event_log = []
        self.samples = 0
        for name, obj in self.objects.items():
            if not name or not isinstance(obj.get('modules'), dict):
                raise ValueError('Objects need names and a module configuration map')
            for module, config in obj['modules'].items():
                if module not in MODULES:
                    raise ValueError('Unknown module: ' + module)
                MODULES[module].validate(config)

    def step(self, t, observations=None, events=None):
        if not isinstance(t, (int, float)) or not math.isfinite(t) or t < 0:
            raise ValueError('Time must be finite and nonnegative')
        if self.time is not None and t <= self.time:
            raise ValueError('Time must strictly increase; reset for another episode')
        observations, events = observations or {}, deepcopy(events or [])
        if not finite(observations) or not finite(events):
            raise ValueError('Nonfinite observation or event')
        if set(observations) - set(self.objects):
            raise ValueError('Observations reference unknown objects')
        ids = set()
        for event in events:
            if not event.get('id') or event['id'] in self.events_seen or event['id'] in ids:
                raise ValueError('Every event needs a unique id; duplicate delivery rejected')
            if event.get('object') not in self.objects or not event.get('type'):
                raise ValueError('Event needs a known object and a type')
            if not isinstance(event.get('evidence'), dict) or not event['evidence'].get('source'):
                raise ValueError('Events need an explicit evidence source')
            if 't' in event and event['t'] != t:
                raise ValueError('Deliver events at their observation timestamp')
            ids.add(event['id'])
        # Transactional: one invalid model/event must not partly mutate a world.
        memory = deepcopy(self.memory)
        self._transfers(events, memory)
        dt = 0.0 if self.time is None else t - self.time
        states = {}
        for name, obj in self.objects.items():
            states[name] = {}
            own_events = [e for e in events if e['object'] == name]
            for mid, config in obj['modules'].items():
                mem = memory[name].setdefault(mid, {})
                out = MODULES[mid].evaluate(config, mem, observations.get(name, {}), own_events, t, dt)
                states[name][mid] = out
                if not finite(out):
                    raise ValueError('Nonfinite model output: ' + name + '.' + mid)
        transitions = []
        for name, modules in states.items():
            for mid, values in modules.items():
                for key, new in values.items():
                    old = self.states.get(name, {}).get(mid, {}).get(key)
                    # No unknown->false transition; retain evidence and time of
                    # first observation without pretending it was a transition.
                    if old and old['value'] is not None and new['value'] is not None and old['value'] != new['value']:
                        if isinstance(new['value'], (bool, str)):
                            transitions.append({'t': t, 'object': name, 'module': mid, 'state': key,
                                                'before': old, 'after': new})
        self.memory, self.states, self.time = memory, states, t
        self.transitions.extend(transitions)
        self.events_seen.update(ids)
        self.event_log.extend({**e, 't': t} for e in events)
        self.samples += 1
        return {'t': t, 'objects': deepcopy(states), 'transitions': transitions}

    def _transfers(self, events, memory):
        """Conservative transfers, shared by fluids and contamination.

        Ledger mode is opt-in. A transfer moves quantity between two objects;
        it never both decrements and estimates the same PBD particle volume.
        """
        for e in events:
            if e['type'] not in ('liquid_transfer', 'contaminant_transfer'):
                continue
            mid, initial, field = ('M08', 'initial_volume_ml', 'volume_ml') if e['type'] == 'liquid_transfer' else ('M11', 'initial_load_mg', 'load_mg')
            source, target, amount = e['object'], e.get('target'), e.get('amount')
            if target not in self.objects or source == target or not isinstance(amount, (int, float)) or amount <= 0:
                raise ValueError('Transfer needs a distinct target and positive finite amount')
            for name in (source, target):
                cfg = self.objects[name]['modules'].get(mid, {})
                if cfg.get('mode') != 'ledger':
                    raise ValueError('Both transfer objects must explicitly use ledger mode')
                memory[name].setdefault(mid, {}).setdefault(field, cfg[initial])
            src, dst = memory[source][mid], memory[target][mid]
            if amount > src[field] + 1e-9:
                raise ValueError('Transfer exceeds available quantity')
            target_cfg = self.objects[target]['modules'][mid]
            if mid == 'M08' and dst[field] + amount > target_cfg['capacity_ml'] + 1e-9:
                raise ValueError('Transfer exceeds capacity; route overflow to another explicit reservoir')
            src[field] -= amount
            dst[field] += amount

    def report(self):
        return {'revision': REVISION, 'sample_count': self.samples, 'last_t': self.time,
                'objects': self.objects, 'final_states': self.states, 'transitions': self.transitions,
                'events': self.event_log, 'calibration_status': 'uncalibrated',
                'reference_label_used': False,
                'limits': ['Only supplied channels are observed; missing state remains unknown.',
                           'Lumped models are predictions, not measured injury or full multiphysics.',
                           'Discrete damage/processing states do not render fractures or deform meshes.',
                           'The state layer does not override the motion planner or force unsafe outcomes.']}
