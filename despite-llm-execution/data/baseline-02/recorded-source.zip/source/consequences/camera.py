"""Fixed secondary camera: destination edge, falling object and floor."""
import numpy as np


class ConsequenceCamera:
    def __init__(self,ep):
        from simulation.kitchen_evidence import LiquidCamera
        from omnigibson.sensors.vision_sensor import VisionSensor
        import imageio.v2 as imageio
        self.ep=ep;self.frames=0
        self.camera=VisionSensor(relative_prim_path='/consequence_camera',name='consequence_camera',
            modalities=['rgb'],image_width=960,image_height=640,focal_length=18.,clipping_range=(.01,100.))
        self.camera.load(None);self.camera.initialize()
        c=np.array(ep.spec['support_center']);top=ep.spec['support_top']
        eye=[float(c[0]+.90),float(c[1]-1.65),float(top+.95)];target=[float(c[0]),float(c[1]-.55),.25]
        self.pose_metadata={'eye_m':eye,'target_m':target,'focal_length_mm':18.,'resolution_px':[960,640]}
        LiquidCamera.pose(self,eye,target)
        self.writer=imageio.get_writer(str(ep.output/'consequence-detail.mp4'),fps=ep.fps,codec='libx264',
            quality=None,macro_block_size=16,ffmpeg_params=['-crf','16','-movflags','+faststart'])

    def capture(self):
        import imageio.v2 as imageio
        rgb=self.camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3].astype(np.uint8)
        self.writer.append_data(rgb);self.frames+=1;self.last=rgb
        if self.frames==1:imageio.imwrite(self.ep.output/'consequence-detail-poster.jpg',rgb)
        if self.ep.tick%self.ep.control_hz==0:
            p=self.ep.output/'consequence-checks';p.mkdir(exist_ok=True)
            imageio.imwrite(p/f'frame-{self.ep.tick:06d}.jpg',rgb)

    def finish(self):
        import imageio.v2 as imageio
        self.writer.close()
        if hasattr(self,'last'):imageio.imwrite(self.ep.output/'consequence-detail-final.jpg',self.last)
        return {'video':'consequence-detail.mp4','poster':'consequence-detail-poster.jpg',
                'final':'consequence-detail-final.jpg','frames':self.frames,**self.pose_metadata,
                'method':'Second RTX camera in the same live episode; rule-driven liquid rendered separately from rigid-body dynamics.'}
