"""Explicit, opt-in consequence interventions, separate from baseline physics."""

REVISION = 'physical-release-consequences-v2'
