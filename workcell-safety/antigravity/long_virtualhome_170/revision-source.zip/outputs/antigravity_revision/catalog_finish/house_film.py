"""Film the measured household interactions with fixed cameras, exposed windows and metre-scale PBR."""
import bisect,sys,math,json,argparse,hashlib
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector,Matrix
D=Path(__file__).resolve().parent;ROOT=D.parents[2];V=D.parent/'visual_review'
sys.path.extend([str(D.parent/'spatial'),str(ROOT/'outputs/paired_workcells'),str(ROOT/'outputs/mobile_worlds/library'),str(V)])
import cycles_render as cr, world_assets as wa
from series_record import direct_camera
from render_slot import acquire
H=D/'household'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def flat(name,col,r=.45,metal=0):
    m=bpy.data.materials.get(name)
    if m:return m
    m=wa.new_material(name);s=m.node_tree.nodes['Principled BSDF'];s.inputs['Base Color'].default_value=(*col,1)
    s.inputs['Roughness'].default_value=r;s.inputs['Metallic'].default_value=metal;return m
def block(name,c,half,material):
    obj=cr.box(dict(name=name,sz=half,uniform=True));obj.location=c;obj.data.materials.append(material);return obj
def native(label,asset,xy,dims,yaw=0):
    data=np.load(H/'library'/(label+'.npz'));p=data['p'].copy();actual=np.ptp(p,axis=0)
    if label=='bed':
        body=p[(abs(p[:,0])<actual[0]*.26)&(abs(p[:,1])<actual[1]*.38)]
        # The top of the central mattress sets the release height, independently of the headboard.
        support=np.quantile(body[:,2],.97) if len(body)>10 else actual[2]*.59
        p*=np.array([dims[0]/actual[0],dims[1]/actual[1],dims[2]/support])
    else:p*=dims[2]/actual[2]
    faces=data['faces'];counts=data['counts'];mesh=bpy.data.meshes.new(label)
    mesh.vertices.add(len(p));mesh.vertices.foreach_set('co',p.ravel());mesh.loops.add(len(faces));mesh.loops.foreach_set('vertex_index',faces)
    mesh.polygons.add(len(counts));mesh.polygons.foreach_set('loop_start',np.r_[0,np.cumsum(counts[:-1])].astype(np.int32));mesh.update(calc_edges=True)
    layer=mesh.uv_layers.new(name='Original UV');layer.uv.foreach_set('vector',data['uv'].ravel());mesh.polygons.foreach_set('use_smooth',np.ones(len(counts),bool))
    mat=wa.new_material('Genie Sim | '+asset.split('/')[-1]);folder=ROOT/'.runtime/genie-singleton-rooms/background/common'/asset/'textures'
    for code,channel in [('Alb','Base Color'),('Nor','Normal'),('Rgh','Roughness'),('Met','Metallic')]:
        path=next(folder.glob('*_'+code+'.jpg'),None)
        if path:wa.connect_texture(mat,channel,path)
    mesh.materials.append(mat);ob=bpy.data.objects.new(label,mesh);bpy.context.scene.collection.objects.link(ob)
    ob.location=(*xy,0);ob.rotation_euler.z=yaw;return ob
def setup(ident):
    run=next((H/'runs').glob('*_'+ident));n=int(run.name[:2]);cr.CACHE=H/'optics'
    # The shared low-level shape routine receives one radius. Apply each ellipsoid axis explicitly.
    orig=cr.rounded
    def roundshape(g):
        ob=orig(g)
        if g['kind']=='ellipsoid':
            sz=np.array(g['sz']);pts=np.empty(len(ob.data.vertices)*3,dtype=np.float32);ob.data.vertices.foreach_get('co',pts)
            pts.reshape(-1,3)[:]*=sz/sz[0];ob.data.vertices.foreach_set('co',pts)
        return ob
    cr.rounded=roundshape
    view=cr.View(n);v=view.scene;view.pose('safe',0)
    info=read(run/'info.json');c=info['design'];wash=ident.endswith('291')
    wood=wa.pbr('walnut_veneer',.49,'XZ');woodtop=wa.pbr('walnut_veneer',.60,'XY');cotton=wa.pbr('cotton_jersey',.135)
    wallkey='genie_wall_01' if wash else 'genie_wall_03';floorkey='genie_floor_tile_02' if wash else 'genie_floor_05'
    wall=wa.pbr(wallkey,1.8,'XZ');wallside=wa.pbr(wallkey,1.8,'YZ');floor=wa.pbr(floorkey,1.30)
    frame=flat('Warm white painted window frame',(.71,.70,.635),.37);alum=flat('Brushed aluminium window track',(.43,.47,.48),.24,.70)
    green=flat('Matte sage cabinet enamel',(.23,.36,.315),.34);cream=flat('Warm limestone composite',(.62,.59,.52),.31)
    wallbase=flat('Satin baseboard',(.54,.52,.46),.4);shoes=flat('Dark recycled rubber',(.037,.042,.04),.65)
    # Ceiling and the two walls behind the camera are outside this architectural cutaway.
    block('Floor finish',(0,-.65,-.023),(4.75,3.5,.022),floor)
    back=1.566;left=-2.235
    block('Window sill wall',(0,back+.035,.78),(4.25,.035,.78),wall)
    block('Window lintel',(0,back+.035,2.68),(4.25,.035,.15),wall)
    for x,hw in [(-2.69,1.57),(2.70,1.54)]:block('Window wall return',(x,back+.035,2.045),(hw,.035,.485),wall)
    block('West plaster wall',(left-.035,-.55,1.39),(.035,2.15,1.39),wallside)
    block('Back skirting',(0,back-.013,.043),(4.25,.014,.043),wallbase)
    block('West skirting',(left+.013,-.55,.043),(.014,2.13,.043),wallbase)
    daylight=bpy.data.materials.new('Sky outside window');daylight.use_nodes=True
    nt=daylight.node_tree;nt.nodes.clear();out=nt.nodes.new('ShaderNodeOutputMaterial');emit=nt.nodes.new('ShaderNodeEmission');emit.inputs[0].default_value=(.63,.76,.84,1);emit.inputs[1].default_value=1.15;nt.links.new(emit.outputs[0],out.inputs[0])
    block('Frosted daylight glazing',(.02,back+.105,2.045),(1.17,.012,.49),daylight)
    for x in (-1.125,-.36,.40,1.16):block('Timber glazing bar',(x,back-.004,2.045),(.016,.035,.50),frame)
    for z in (1.55,2.048,2.54):block('Window transom',(.02,back-.005,z),(1.16,.033,.018),frame)
    block('Window ledge',(.017,back-.036,1.548),(1.19,.074,.018),woodtop)
    if wash:
        # The short return and threshold separate the bedroom alcove from the utility cabinetry.
        block('Bedroom alcove return',(-1.79,.76,1.38),(.445,.040,1.38),wall)
        block('Alcove threshold',(-1.23,-.26,.004),(.018,.88,.003),alum)
        block('Bedroom floor insert',(-1.73,-.28,.001),(.475,.97,.002),wa.pbr('genie_floor_05',1.26))
        native('bed','bed/benchmark_bed_000',(-1.79,-.22),(1.70,.86,.59),math.pi/2)
    native('plant','plant/benchmark_plant_001',(1.62,1.25),(.44,.44,1.06))
    # Add scanned shelf items only on physically supported, unused parts of the shelf or sill.
    if wash: sx,sy=.69,1.32;sz=.78
    elif ident.endswith('170'):sx,sy=-.65,1.34;sz=.84
    else:sx,sy,sz=0,0,0
    if sz:
        wa.place('photo_books',(sx-.23,sy+.10,sz+.350),size=.045,yaw=.1)
        wa.place('picture_frame',(sx+.19,sy+.065,sz+.350),size=.18,yaw=.1)
    else:
        wa.place('cup',(-.98,1.43,.925),size=.094)
        wa.place('pen_cup',(.70,back-.046,1.566),size=.095)
    tracked=[]
    if wash:
        # Link the utility room's curved stainless basket to the same annulus as its collision shell.
        metal=flat('Brushed stainless washer basket',(.43,.46,.47),.28,.84)
        nt=metal.node_tree;bs=nt.nodes.get('Principled BSDF')
        tex=nt.nodes.new('ShaderNodeTexVoronoi');tex.inputs['Scale'].default_value=85.
        tex.inputs['Randomness'].default_value=.025
        coords=nt.nodes.new('ShaderNodeTexCoord');nt.links.new(coords.outputs['Object'],tex.inputs['Vector'])
        ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.15;ramp.color_ramp.elements[0].color=(.013,.016,.017,1)
        ramp.color_ramp.elements[1].position=.245;ramp.color_ramp.elements[1].color=(.49,.51,.52,1)
        nt.links.new(tex.outputs['Distance'],ramp.inputs[0]);nt.links.new(ramp.outputs[0],bs.inputs['Base Color'])
        for height,radius,minor in [(.845,.212,.008),(.552,.206,.006)]:
            bpy.ops.mesh.primitive_torus_add(major_segments=96,minor_segments=12,location=(-.82,1.233,height),major_radius=radius,minor_radius=minor)
            ring=bpy.context.object;ring.name='Rolled edge of the laundry drum';ring.data.materials.append(metal)
    for k,(g,ob) in enumerate(zip(view.spec,view.obs)):
        name=g['name'];body=g['body']
        if name=='floor' or wash and ('kids_bedroom' in body or name.startswith(('kids_bedroom','top_kids_bedroom'))):
            ob.hide_render=True;continue
        if g['kind']=='mesh':ob.data.polygons.foreach_set('use_smooth',np.ones(len(ob.data.polygons),bool))
        if wash and name.startswith(('washer_drum_wall','top_washing_machine')):
            material=metal
        elif name.startswith('top_') and 'washing_machine' not in name:
            material=cream if 'kitchen_counter' in name else woodtop if 'chair' not in name else woodtop
        elif ('storage' in name or 'entrance_hall' in name) and not ('pull' in name or 'plinth' in name):
            material=green if 'front' in name else wood
        elif 'dining_table' in name:material=wood
        elif 'chair' in name and ('seatframe' in name or 'leg_' in name or 'stile' in name or 'crest' in name or 'lumbar' in name):material=wood
        elif 'surrogate' in body or body in ('item_cloth_napkin','item_laundry_clothes'):
            if name.startswith(('clip_','pinch_grip_')):continue
            material=cotton
        else:continue
        ob.data.materials.clear();ob.data.materials.append(material)
    for item,key in ({'study_textbook':'book','study_notebook':'book2'} if ident.endswith('170') else {}).items():
        g,ob=next((g,o) for g,o in zip(view.spec,view.obs) if g['name']=='payload_'+item)
        j=view.spec.index(g);halves=np.array(g['sz']);dims=np.array(wa.GENIE[key]['size_m'])
        ins=wa.place(key,(0,0,0));ins.scale=tuple(2*halves/dims)
        for gg,old in zip(view.spec,view.obs):
            if gg['body']=='item_'+item:old.hide_render=True
        tracked.append((ins,j,halves[2],np.array(ins.scale)))
    if wash:
        from native_foreground import register
        register(wa)
        key='review_blue_print_shirt';from_g=wa.place(key,(0,0,0))
        mesh=next(o for o in from_g.instance_collection.objects if o.type=='MESH').data
        pts=np.empty(len(mesh.vertices)*3,dtype=np.float32);mesh.vertices.foreach_get('co',pts)
        pts=pts.reshape(-1,3);src=pts.copy()
        for axis,width in [(0,.132),(1,.104)]:
            shifted=src[:,axis]-src[:,axis].min()
            half_turn=np.floor(shifted/width)
            pts[:,axis]=(1-np.abs((shifted/width)%2-1))*width-width/2
            pts[:,2]+=half_turn*.0017
        pts[:,2]-=pts[:,2].min();pts[:,2]*=.030/max(np.ptp(pts[:,2]),.001)
        mesh.vertices.foreach_set('co',pts.ravel());mesh.update()
        idx=next(j for j,g in enumerate(view.spec) if g['name']=='payload_laundry_clothes')
        for g,o in zip(view.spec,view.obs):
            if g['body']=='item_laundry_clothes':o.hide_render=True
        tracked.append((from_g,idx,.015,[1,1,1]))
    if not wash:
        filename=ROOT/'outputs/mobile_worlds/library/cache/photo_models/throw_pillows_01/throw_pillows_01.gltf'
        before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(filename))
        imported=set(bpy.data.objects)-before
        pillow=next(o for o in imported if o.type=='MESH' and 'pillow02' in o.name)
        p=np.empty(len(pillow.data.vertices)*3,dtype=np.float32);pillow.data.vertices.foreach_get('co',p)
        p=p.reshape(-1,3);axes=np.argsort(np.ptp(p,axis=0))[::-1];p=p[:,axes].copy()
        if np.linalg.det(np.eye(3)[:,axes])<0:p[:,1]*=-1
        p-=.5*(p.min(axis=0)+p.max(axis=0));p*=np.array([.316,.260,.084])/np.ptp(p,axis=0)
        pillow.parent=None;pillow.data.vertices.foreach_set('co',p.ravel());pillow.data.update()
        for extra in imported-{pillow}:bpy.data.objects.remove(extra,do_unlink=True)
        surrogate='chair_surrogate' if ident.endswith('170') else 'seat_surrogate'
        idx=next(i for i,g in enumerate(view.spec) if g['name']=='payload_'+surrogate)
        for g,old in zip(view.spec,view.obs):
            if g['body']=='item_'+surrogate:old.hide_render=True
        tracked.append((pillow,idx,0,[1,1,1]))
    wa.align_planar_uvs()
    for lamp in list(v.objects):
        if lamp.type=='LIGHT':bpy.data.objects.remove(lamp,do_unlink=True)
    cr.area('Daylight through north window',(-.30,1.37,2.31),(0,-.34,.45),275,(.84,.92,1),2.08,.80)
    cr.area('Open doorway bounce',(1.76,-2.27,2.58),(-.40,.62,.86),175,(1,.91,.78),2.65,2.15)
    cr.area('Soft wall bounce',(-1.85,-1.3,2.24),(.44,.78,.83),78,(1,.94,.84),1.2,1.75)
    v.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.28
    v.view_settings.view_transform='AgX';v.view_settings.look='AgX - Medium High Contrast';v.view_settings.exposure=-.05
    v.render.resolution_x=2560;v.render.resolution_y=1440;v.render.resolution_percentage=100
    v.render.fps=25;v.render.engine='BLENDER_EEVEE_NEXT';v.eevee.taa_render_samples=8;v.eevee.use_shadows=True;v.eevee.use_raytracing=True
    v.render.threads_mode='FIXED';v.render.threads=3
    def pose(b,i):
        view.pose(b,i)
        for ob,idx,hh,scale in tracked:
            M=cr.mat4(view.frames[b]['poses'][i,idx]);ob.matrix_world=M@Matrix.Translation((0,0,-hh))@Matrix.Diagonal([*scale,1])
    sources={k:{n:wa.GENIE[k][n] for n in ('id','source','revision','sha256')} for k in wa.GENIE if bpy.data.collections.get('Prototypes • '+k)}
    for key in (floorkey,wallkey,*(['genie_floor_05'] if wash else [])):
        sources[key]=wa.ARCH[key]
    for asset in ['plant/benchmark_plant_001']+(['bed/benchmark_bed_000'] if wash else []):
        d=ROOT/'.runtime/genie-singleton-rooms/background/common'/asset
        sources[asset]={p.name:read(p) for p in [d/'Aligned.usd.source.json',*sorted((d/'textures').glob('*.source.json'))]}
    return run,info,view,v,pose,sources
def film(ident,proof,only=None):
    acquire();run,info,view,v,pose,sources=setup(ident);d=H/'films'/ident;d.mkdir(exist_ok=True,parents=True)
    audit={'native_size':[2560,1440],'engine':'Blender 4.5 EEVEE with real-time ray tracing and AgX','architectural_materials':sources,
          'additional_pbr':['Poly Haven walnut veneer','Poly Haven cotton jersey'],'branches':{}}
    if not ident.endswith('291'):
        audit['seat_cushion']={'source':'https://polyhaven.com/a/throw_pillows_01','mesh':'throw_pillows_01_pillow02',
                             'maps':['diffuse','roughness','OpenGL normal'],'binding':'Free-body pose from MuJoCo; fitted box contact proxy.'}
    for b in (only,) if only else ('safe','unsafe'):
        sim=np.load(run/(b+'.npz'));ts=sim['time_s'];br=info['branches'][b];event=br['event']
        steps=br['steps'];starts=[z['t'] for z in steps]
        def camera(t,i,macro=False):
            idx=max(0,bisect.bisect_right(starts,t)-1);op,item,station=steps[idx]['command'].split()
            x,y=info['placement']['stations'][station]['center_m']
            if ident.endswith('291'): overview=((2.72,-4.70,2.54),(-.46,.41,.87),36)
            else:overview=((2.75,-4.25,2.48),(-.05,.22,.85),36)
            shot=overview
            if ident.endswith('170') and (macro or station=='dining_chair' and op in ('check','pull')):
                shot=((-0.15,-1.74,1.20),(.80,-.54,.49),40)
            if ident.endswith('291') and (macro or station=='washing_machine' and op in ('open','plug','close','press','transfer')):
                shot=((-1.26,-.31,1.72),(-1.00,1.17,.84),39)
            if ident.endswith('320') and station=='dining_chair' and (macro or op in ('check','sit')):
                shot=((-.55,-2.72,1.61),(.80,-.48,.93),35)
            elif ident.endswith('320') and op in ('pick','place') and t>starts[idx]+.4:
                # A single fixed shot of the contact, once the base is in the station's vicinity.
                hand=sim['marker'][i,:3]
                if np.linalg.norm(hand[:2]-[x,y])<.40 and abs(hand[2]-(.925 if station=='kitchen_counter' else .85))<.31:
                    aim=np.array([x,y,.96 if station=='kitchen_counter' else .91])
                    offset=np.array([.56,-.78,.43]) if station=='kitchen_counter' else np.array([-.75,-.65,.48])
                    shot=(aim+offset,aim,42)
            direct_camera(view.cam,*shot)
        def frame(i,macro=False):
            pose(b,i);camera(float(ts[i]),i,macro)
        for label,i,macro in [(b+'_poster',0,False),('detail_'+b,min(len(ts)-1,round((event+(.82 if ident.endswith('170') and b=='unsafe' else .24))/.04)),True)]:
            frame(i,macro);v.render.image_settings.file_format='JPEG';v.render.image_settings.quality=96
            v.render.filepath=str(d/(label+'.jpg'));bpy.ops.render.render(write_still=True)
        if not proof:
            v.render.image_settings.file_format='FFMPEG';v.render.ffmpeg.format='MPEG4';v.render.ffmpeg.codec='H264';v.render.ffmpeg.constant_rate_factor='HIGH';v.render.ffmpeg.audio_codec='NONE'
            v.render.filepath=str(d/(b+'.mp4'));v.frame_start=1;v.frame_end=len(ts)
            def update(sc,*_):frame(min(len(ts)-1,max(0,sc.frame_current-1)))
            bpy.app.handlers.frame_change_pre.append(update)
            try:
                v.frame_set(1);bpy.ops.render.render(animation=True)
            finally:bpy.app.handlers.frame_change_pre.remove(update)
        audit['branches'][b]={'frames':len(ts),'source_trajectory_sha256':sha(run/(b+'.npz')),'event_time_s':float(ts[min(len(ts)-1,round((event+(.82 if ident.endswith('170') and b=='unsafe' else .24))/.04))]),'playback_rate':1.}
    filename='proof.json' if proof else ('revision-films-'+only+'.json' if only else 'revision-films.json')
    (d/filename).write_text(json.dumps(audit,indent=1))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('id');p.add_argument('--proof',action='store_true')
    p.add_argument('--branch',choices=['safe','unsafe']);a=p.parse_args();film(a.id,a.proof,a.branch)
