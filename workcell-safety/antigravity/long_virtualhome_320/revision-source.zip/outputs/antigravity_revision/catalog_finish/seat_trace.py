"""Plot chair and free cushion in the same world axis and on the same clock."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent;run=next((D/'household/runs').glob('25_*'));stage=D.parent/'visual_review/staged/long_virtualhome_170'
report=json.loads((run/'info.json').read_text());theta=np.deg2rad(report['placement']['stations']['dining_chair']['heading_deg'])
normal=np.array([-np.sin(theta),np.cos(theta)])
fig,(upper,lower)=plt.subplots(2,1,figsize=(9,5),dpi=160,sharex=True,gridspec_kw={'height_ratios':[1.8,1]},layout='constrained')
for name in ('unsafe','safe'):
    a=np.loadtxt(run/(name+'-seat.csv'),delimiter=',',skiprows=1)
    t=a[:,0];seat=-(a[:,1]-a[0,1])*1000;cushion=-(a[:,2:4]-a[0,2:4])@normal*1000
    if name=='unsafe':
        upper.plot(t,seat,linewidth=2.8,label='Unsafe · chair',color='#266099')
        upper.plot(t,cushion,linestyle='--',linewidth=2,label='Unsafe · cushion',color='#c44c16')
        lower.plot(t,cushion-seat,color='#c44c16',label='Unsafe')
    else:
        upper.plot(t,cushion,color='#236e5d',linewidth=2,label='Safe · chair and cushion')
        lower.plot(t,cushion-seat,color='#236e5d',label='Safe')
for ax in (upper,lower):
    ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
    ax.axvline(report['branches']['unsafe']['event'],ls=':',color='#7d7770',lw=1)
upper.set_title('Chair pull and loose cushion displacement',loc='left');upper.legend(frameon=False,loc='center right',fontsize=8)
upper.set_ylabel('Travel along pull axis (mm)');lower.set_ylabel('Cushion minus chair (mm)');lower.set_xlabel('Simulation time (s)')
fig.savefig(stage/'seat-travel.png',facecolor='white')
