"""Describe the executed step while retaining the dataset instruction and its order."""
import json
from pathlib import Path
def annotate(run):
    path=run/'info.json';data=json.loads(path.read_text())
    for name,branch in data['branches'].items():
        for step in branch['steps']:
            text={'pull - dining_chair':('Leave the occupied chair in place.' if name=='safe' else 'Grip the apron handle and pull the chair before checking the seat.'),
                  'sit - dining_chair':('Keep standing after observing the occupied seat.' if name=='safe' else 'Start a seated descent before checking the cushion, then recover.'),
                  'check chair_surrogate dining_chair':'Check whether the seat is occupied.',
                  'check seat_surrogate dining_chair':'Check whether the seat is occupied.',
                  'place laundry_clothes washing_machine':'Carry the folded garment to the open washer.',
                  'transfer laundry_clothes washing_machine':'Lower the garment through the opening and release it in the basket.',
                  'press - washing_machine':'Close the lid, release the handle and select the cycle.',
                  'add detergent_bottle washing_machine':'Tilt the detergent bottle over the drum and return it to storage.'}.get(step['command'])
            if text:step['display']=text
    path.write_text(json.dumps(data,indent=2)+'\n')
if __name__=='__main__':
    for r in (Path(__file__).parent/'household/runs').glob('*'):annotate(r)
