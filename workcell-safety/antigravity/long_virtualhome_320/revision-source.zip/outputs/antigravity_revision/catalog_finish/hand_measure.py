"""Check library hand solids and recorded clips directly in the saved 25 Hz states."""
from pathlib import Path
import json, numpy as np,mujoco as mj
D=Path(__file__).resolve().parent
run=next((D/'household/runs').glob('06_*'))
m=mj.MjModel.from_xml_path(str(run/'scene.xml'));d=mj.MjData(m)
j=json.loads((run/'info.json').read_text());items=('cloth_napkin','dinner_fork','entree_dish','dinner_plate')
hand=[g for g in range(m.ngeom) if ((m.geom(g).name or '').startswith(('R_','r_palm','L_','l_palm')) and (m.geom(g).name or '').endswith('_col'))]
tops=[m.geom('top_'+s).id for s in ('kitchen_counter','dining_table')]
bare=[m.geom('payload_'+s).id for s in items];buf=np.zeros(6)
def name(g):return m.geom(g).name
def separation(a,b):return float(mj.mj_geomDistance(m,d,a,b,.02,buf))
out={}
for branch in ('safe','unsafe'):
    ar=np.load(run/(branch+'.npz'));tm=ar['time_s'];minima=[(.02,None,None,0),(.02,None,None,0)]
    grip=[]
    for time,pose in zip(tm,ar['qpos']):
        d.qpos[:]=pose;mj.mj_kinematics(m,d)
        for kind,targets in enumerate((tops,bare)):
            for a in hand:
                delta=abs(d.geom_xpos[targets]-d.geom_xpos[a])
                possible=np.all(delta<(m.geom_rbound[targets]+m.geom_rbound[a]+.03)[:,None],axis=1)
                for b in np.array(targets)[possible]:
                    dist=separation(a,b)
                    if dist<minima[kind][0]:minima[kind]=dist,name(a),name(b),round(float(time),3)
    for g in j['branches'][branch]['pinch_clips']:
        i=abs(tm-g['time']).argmin();d.qpos[:]=ar['qpos'][i];mj.mj_kinematics(m,d)
        grip.append({'item':g['item'],'target_error_m':g['site_error_m'],'sample_s':float(tm[i]),
                     **{x:separation(m.geom(n).id,m.geom('pinch_grip_'+g['item']).id) for x,n in [('thumb_to_clip_m','R_thumb_distal_link_col'),('index_to_clip_m','R_index_intermediate_link_col')]}})
    out[branch]={'hand_to_table_minimum_m':minima[0],'hand_to_item_body_minimum_m':minima[1],'pickups':grip}
print(json.dumps(out,indent=1))
(run/'hand-clearance.json').write_text(json.dumps(out,indent=1))
