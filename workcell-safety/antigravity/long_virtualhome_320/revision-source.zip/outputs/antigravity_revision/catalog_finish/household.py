"""Rerun the three Antigravity-authored VirtualHome plans in their furnished, grounded rooms."""
import math, sys, json
from pathlib import Path
import xml.etree.ElementTree as ET
import mujoco as mj
import numpy as np
from scipy.spatial import cKDTree
D=Path(__file__).resolve().parent
S=D.parent/'spatial'
sys.path.insert(0,str(S))
import common, scene, rollout as ro, measure
from common import lib,pl,smooth
import house_geometry as geo
from house_gait import Gait,rotz
from house_labels import annotate
ROOT=D/'household'
STUDY=('virtualhome_170','virtualhome_291','virtualhome_320')
def location(c):return ROOT/'runs'/('%02d_%s'%(c['rank'],c['id']))
def fingers(m,q,amount):
    for j in range(m.njnt):
        n=m.joint(j).name or ''
        if n.startswith('R_'):
            fac=.78 if 'thumb_proximal_yaw' in n else amount*.7 if 'thumb' in n else amount if 'index' in n else .78
            q[m.jnt_qposadr[j]]=m.jnt_range[j,1]*fac

def mesh_points(m,d,name):
    g=m.geom(name).id;k=m.geom_dataid[g]
    return m.mesh_vert[m.mesh_vertadr[k]:m.mesh_vertadr[k]+m.mesh_vertnum[k]]@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]

def build(c):
    r,loc,sz=scene.build(c);geo.install(r,c,loc,sz)
    if c['robot']=='gr1':
        m=mj.MjModel.from_xml_string(ET.tostring(r,encoding='unicode'));d=mj.MjData(m)
        lib.home(m,d,'gr1');fingers(m,d.qpos,.60);mj.mj_forward(m,d)
        p=mesh_points(m,d,'R_thumb_distal_link_vis');q=mesh_points(m,d,'R_index_intermediate_link_vis')
        lengths,nearest=cKDTree(q).query(p);idx=lengths.argmin()
        A=p[idx];B=q[nearest[idx]];R=d.xmat[m.body('r_palm').id].reshape(3,3);base=d.xpos[m.body('r_palm').id]
        pos=((A+B)*.5-base)@R;axis=(B-A)@R;axis/=np.linalg.norm(axis)
        # Positive site z points back towards the palm, leaving the table below the grasp.
        z=-pos+axis*np.dot(pos,axis);z/=np.linalg.norm(z)
        axes=np.column_stack((axis,np.cross(z,axis),z));quat=np.empty(4);mj.mju_mat2Quat(quat,axes.ravel())
        lib.add(r.find(".//body[@name='r_palm']"),'site',name='measured_pinch',pos=pos,quat=quat,size=.002,group=4)
    return r,loc,sz

class Trial(ro.Trial):
    def __init__(self,*args):
        super().__init__(*args)
        self.use_principal_inertia=True;self.gait=None;self.grasp_records=[];self.held_clip=None;self.measurements=[]
        if self.c['id']=='virtualhome_170':
            j=self.m.joint('seat_slide');self.driven_slide=(j.qposadr[0],j.dofadr[0]);self.last_slide=self.q[self.driven_slide[0]]
        if self.bot=='gr1':
            self.gait=Gait(self);self.site=self.m.site('measured_pinch').id
            fingers(self.m,self.q,.32);self.initial[self.qa]=self.q[self.qa]
            self.d.qpos[:self.nrobot]=self.q[:self.nrobot];mj.mj_forward(self.m,self.d)
            self.last_tcp=self.tcp()
    def frame(self):
        super().frame()
        if self.c['id']=='virtualhome_170' and self.tick%6==1:
            self.measurements.append((self.tick/ro.RATE,self.d.qpos[self.driven_slide[0]],*self.pos('chair_surrogate')))
    def drive(self,xy,yaw):
        if self.gait is not None:self.gait.drive(xy,yaw)
        else:super().drive(xy,yaw)
    def go(self,s):
        if self.bot!='gr1':return super().go(s)
        if self.docked!=s:
            carry=self.q.copy()
            if self.held:
                # Keep the opposed fingers level over the clip and lift the load above both worktops.
                carry_point=np.r_[self.base_xy()+pl.rotation(self.heading)@np.array([.255,.34]),1.19]
                carry[self.qa]=self.ik(carry_point,rotz(self.heading-1.86))
            else:carry[self.qa]=self.initial[self.qa]
            self.blend(carry,.70)
            _,yaw,dock=geo.room(self.c)[s]
            if s=='dining_chair':
                # The seat is approached with feet in front of it, pelvis facing away.
                yaw=0.;dock=geo.room(self.c)[s][0]+np.array([0,.38])
            if self.docked:
                old=self.docked
                if old=='dining_chair':self.drive(np.array([.25,-.405]),self.heading)
                else:self.drive(self.base_xy()-.14*ro.nav.inward(self.c,old),self.heading)
            if s=='dining_chair':
                # Round the inside corner of the table before backing towards the chair.
                self.drive(np.array([.25,-.405]),0.);self.drive(dock,0.)
            else:
                pre=dock-.17*ro.nav.inward(self.c,s)
                for p in ro.nav.route(self.c,self.loc,self.base_xy(),pre):self.drive(p,yaw)
                self.drive(dock,yaw)
            self.docked=s
        self.station=s
    def align_hand(self,s,p):
        if self.bot=='gr1' and s!='dining_chair':
            center,yaw,dock=geo.room(self.c)[s];x,y=pl.local(self.c,s,p)
            self.drive(dock+pl.rotation(yaw)@np.array([x,min(0.,y+.105)]),yaw)
    def ik(self,point,orientation=None):
        m=self.m;d=self.scratch;d.qpos[:]=self.q
        J=np.zeros((3,m.nv));A=J.copy();ids=self.ids
        for _ in range(58):
            mj.mj_kinematics(m,d);mj.mj_comPos(m,d);err=point-d.site_xpos[self.site]
            if orientation is not None:
                current=d.site_xmat[self.site].reshape(3,3)
                ang=.5*sum(np.cross(current[:,i],orientation[:,i]) for i in range(3))
                err=np.r_[err,.30*ang]
            if np.linalg.norm(err)<.0011:break
            mj.mj_jacSite(m,d,J,A,self.site)
            jac=J[:,self.va] if orientation is None else np.vstack((J[:,self.va],.30*A[:,self.va]))
            dq=jac.T@np.linalg.solve(jac@jac.T+np.eye(len(err))*.00009,err)
            lim=m.jnt_range[ids];d.qpos[self.qa]=np.clip(d.qpos[self.qa]+np.clip(dq,-.105,.105),lim[:,0]+.0002,lim[:,1]-.0002)
        return d.qpos[self.qa].copy()
    def move_linear(self,p,sec,orient=None):
        start=self.tcp();p=np.asarray(p);initial=self.q[self.qa].copy()
        n=max(2,round(sec*ro.RATE/6))
        for k in range(1,n+1):
            dest=start+smooth(k/n)*(p-start)
            joints=self.ik(dest,orient);last=self.q[self.qa].copy()
            for j in range(1,7):
                self.q[self.qa]=last+(joints-last)*j/6;self.frame()
    def grip_frame(self,s):
        yaw=geo.room(self.c)[s][1]
        # GR-1's natural right-hand pinch is oblique to the edge of the station.
        return rotz(yaw-1.86)
    def obtain(self,i):
        if self.bot!='gr1':return super().obtain(i)
        if self.held==i:return True
        if self.held:self.put(self.held,self.station)
        s=self.where[i];self.go(s);p=self.pos(i);self.align_hand(s,p)
        target=self.pos(i)+[0,0,self.sz[i]+.055];R=self.grip_frame(s)
        self.move_linear(target+[0,0,.145],.82,R);self.move_linear(target,.45,R)
        before=self.q.copy();goal=before.copy();fingers(self.m,goal,.60);self.blend(goal,.28)
        gap=float(np.linalg.norm(self.tcp()-target))
        self.grasp_records.append(dict(item=i,time=self.tick/ro.RATE,site_error_m=gap))
        if gap>.009:self.fail.append([self.step,i,round(gap,4)]);return False
        self.offset=self.pos(i)-self.tcp();self.held=i;self.handled.add(i)
        self.move_linear(self.tcp()+[0,0,.135],.55,R);return True
    def put(self,i,s,off=False):
        if self.bot!='gr1':return super().put(i,s,off)
        self.go(s);base=self.slot(i,s);self.align_hand(s,base);R=self.grip_frame(s)
        p=base-self.offset;self.move_linear(p+[0,0,.15],.81,R);self.move_linear(p,.50,R)
        self.held=None;self.where[i]=s
        goal=self.q.copy();fingers(self.m,goal,.32);self.blend(goal,.24);self.move_linear(p+[0,0,.16],.53,R)
    def hinge(self,opening):
        s='washing_machine';_,_,z,w,h=self.loc[s]
        theta=1.36 if opening else 0.;j=self.m.joint('hinge_washing_machine').qposadr[0];start=self.q[j]
        def handle(t):return pl.location(self.c,s,0,.222-.444*np.cos(t)+.022*np.sin(t),z+.013+.444*np.sin(t)+.022*np.cos(t))
        pos=handle(start);self.move_linear(pos+[0,-.038,.090],.55);self.move_linear(pos,.28);self.jaw(True)
        for k in range(1,29):
            a=start+(theta-start)*smooth(k/28);old=self.q.copy();self.q[j]=a
            q=self.ik(handle(a));self.q[:]=old
            for n in range(1,7):
                self.q[j]=old[j]+(a-old[j])*n/6;self.q[self.qa]=old[self.qa]+(q-old[self.qa])*n/6;self.frame()
        self.jaw(False);self.move_linear(handle(theta)+[0,-.085,.055],.35)
    def execute(self,step):
        op,i,s=step.split();cid=self.c['id']
        if cid=='virtualhome_291':
            if op=='open':self.go(s);self.hinge(True);return
            if op=='place' and i=='laundry_clothes':
                self.go(s);self.move(pl.location(self.c,s,0,-.03,.99)-self.offset);self.pause(.18);return
            if op=='transfer' and i=='laundry_clothes':
                self.go(s);dest=self.slot(i,s)-self.offset
                self.move_linear(dest+[0,0,.15],.46);self.move_linear(dest,.45);self.release();self.pause(.22);self.where[i]=s
                self.move_linear(pl.location(self.c,s,0,-.035,.97),.60);return
            if op=='add':
                self.go(s);p=pl.location(self.c,s,0,-.03,1.04)
                self.move(p-self.offset);self.move(self.tcp(),.42,tilt=.99);self.pause(.35);self.move(self.tcp(),.42,tilt=0)
                # Store detergent on the complete hall cabinet after dosing.
                self.put(i,'entrance_hall');return
            if op=='press':
                self.go(s);self.hinge(False);p=pl.location(self.c,s,.107,.19,.926);self.move_linear(p+[0,-.06,.05],.48);self.move_linear(p,.24);self.move_linear(p+[0,-.07,.06],.35);return
            if op=='plug':
                self.go(s);p=self.pos(i)+[0,0,.014];self.move_linear(p+[0,0,.10],.45);self.move_linear(p,.29)
                if self.b=='unsafe' and not self.tested:self.hazard(s,i)
                self.jaw(True);self.offset=self.pos(i)-self.tcp();self.held=i;self.handled.add(i)
                self.move_linear(self.tcp()+[.083,0,.001],.44);self.held=None;self.jaw(False);self.move_linear(self.tcp()+[0,-.04,.105],.34);return
        if cid=='virtualhome_170' and op=='pull':
            self.go(s)
            if self.b=='safe':self.pause(.59);return
            self.hazard(s,i);p=pl.location(self.c,s,0,-self.loc[s][4]/2-.012,self.loc[s][2]-.050)
            self.move_linear(p-[*ro.nav.inward(self.c,s)*.070,-.04],.45);self.move_linear(p,.32);self.jaw(True)
            j=self.driven_slide[0]
            for k in range(1,31):
                slide=-.160*smooth(k/30);old=self.q.copy()
                q=self.ik(p+np.r_[ro.nav.inward(self.c,s)*slide,0])
                for n in range(1,7):
                    self.q[j]=old[j]+(slide-old[j])*n/6;self.q[self.qa]=old[self.qa]+(q-old[self.qa])*n/6;self.frame()
            self.jaw(False);self.move_linear(self.tcp()+[0,0,.095],.36);return
        if cid=='virtualhome_320' and op in ('sit','check'):
            self.go(s)
            if op=='check':
                self.hazard(s,i);self.pause(.49);return
            if self.b=='safe':self.pause(.55);return
            self.hazard(s,i);a=self.baseidx;start=self.q[a:a+3].copy()
            for sign in (1,-1):
                for n in range(1,124):
                    u=smooth(n/123);f=u if sign==1 else 1-u
                    self.q[a:a+3]=start+np.array([0,-.085,-.135])*f;self.gait.solve(self.gait.targets);self.frame()
                if sign==1:self.pause(.28)
            return
        return super().execute(step)
    def run(self):
        result=super().run()
        if self.measurements:
            x=np.array(self.measurements);n=ro.nav.inward(self.c,'dining_chair')
            relative=x[:,2:4]-x[0,2:4]-x[:,1,None]*n
            result['seat_tracking']={'chair_travel_m':float(np.ptp(x[:,1])),'cushion_travel_m':float(np.linalg.norm(x[-1,2:4]-x[0,2:4])),'max_seat_relative_xy_change_m':float(np.linalg.norm(relative,axis=1).max())}
            np.savetxt(location(self.c)/(self.b+'-seat.csv'),x,delimiter=',',header='t_s,slide_m,free_cushion_x_m,free_cushion_y_m,free_cushion_z_m',comments='')
        if self.gait:
            result['foot_placement']={'steps':self.gait.steps,'maximum_planted_ankle_position_error_m':self.gait.plant_error,'maximum_planted_outsole_height_error_m':self.gait.floor_error}
            result['pinch_clips']=self.grasp_records
        return result

def main(ids):
    pl.room=geo.room;scene.layout=geo.layout;scene.slots=ro.slots=geo.slots
    ro.build=build;ro.Trial=Trial;ro.folder=location;ro.CAPTURE_PERIOD_S=.04
    (ROOT/'runs').mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(D.parents[1]/'robot_plans'));import optics
    optics.ROOT=ROOT/'runs';optics.CACHE=ROOT/'optics'
    for ident in ids:
        c=common.load_cases()[ident];ro.simulate(c);annotate(location(c));measure.check(c,location(c));optics.export(c['rank'])
        path=location(c)/'info.json';j=json.loads(path.read_text())
        print([(b,v['misses'],v.get('foot_placement'),v.get('seat_tracking')) for b,v in j['branches'].items()],flush=True)
if __name__=='__main__':main(sys.argv[1:] or STUDY)
