"""Three connected rooms, physical furniture, and named manipulation surfaces in metres."""
import math
import numpy as np
from common import lib, pl

# center x,y, front-to-rear heading, work height, width, depth, dock distance
ROOMS = {
 'virtualhome_291': {
    'washing_machine':(-.82,1.24,0,.87,.69,.62,.70),
    'entrance_hall':(.69,1.32,0,.78,.92,.46,.63),
    'kids_bedroom':(-1.79,-.22,90,.59,1.70,.86,.73)},
 'virtualhome_170':{
    'study_storage':(-.65,1.34,0,.84,1.04,.44,.59),
    'dining_table':(1.08,.48,-90,.765,1.18,.66,.65),
    'dining_chair':(.97,-.55,-90,.46,.46,.45,.55)},
 'virtualhome_320':{
    'kitchen_counter':(-.55,1.28,0,.925,1.12,.56,.50),
    'dining_table':(.95,.48,-90,.85,1.06,.62,.515),
    'dining_chair':(.89,-.81,180,.49,.46,.45,.60)}
}

def room(c):
    result={}
    for name,(x,y,degrees,h,w,depth,reach) in ROOMS[c['id']].items():
        yaw=math.radians(degrees); pos=np.array([x,y])
        lateral=.225 if c['robot']=='gr1' and name!='dining_chair' else 0
        dock=pos-pl.rotation(yaw)@np.array([lateral,reach])
        result[name]=pos,yaw,dock
    return result

def layout(c):
    return {s:(x,y,z,w,dep) for s,(x,y,a,z,w,dep,dist) in ROOMS[c['id']].items()}

def slots(c,loc,s,i):
    z=loc[s][2]
    if i in ('chair_surrogate','seat_surrogate'):return pl.location(c,s,0,-.015,z)
    if c['id']=='virtualhome_291':
        a,b={'washer_plug':(-.495,-.13),'laundry_clothes':(.07,-.16),'detergent_bottle':(-.045,-.115)}[i]
        if i=='washer_plug':z=.753
        if s=='washing_machine' and i=='laundry_clothes':a,b,z=0,-.02,.55
    elif c['id']=='virtualhome_170':
        a,b={'wooden_pencil':(.237,-.095),'study_notebook':(0,-.10),'study_textbook':(-.19,-.105)}[i]
    else:
        a,b={'cloth_napkin':(-.22,-.11),'dinner_fork':(.223,-.15),'entree_dish':(.095,-.048),'dinner_plate':(-.065,-.18)}[i]
    return pl.location(c,s,a,b,z)

WOOD=(.44,.255,.133,1);EDGE=(.30,.155,.078,1);STEEL=(.54,.58,.60,1);WHITE=(.71,.76,.74,1)

def box(body,name,center,half,color=WOOD,solid=True):
    return lib.geom(body,name,'box',center,half,color,contype=int(solid),conaffinity=2 if solid else 0,group=1,
                    friction=[.87,.013,.002],mass=.12)

def shelf(mount,s,z,w,h):
    b=mount.find('body')
    for obj in list(b): b.remove(obj)
    # Full lower cabinet, two routed fronts, solid toe kick and an open upper bookcase.
    box(b,s+'_plinth',(0,.015,.048),(w/2-.034,h/2-.035,.048),EDGE)
    for side in [-1,1]:
        box(b,s+'_lower_side_'+str(side),(side*(w/2-.012),0,(z+.085)/2),(.012,h/2,(z-.085)/2))
        box(b,s+'_front_'+str(side),(side*w*.247,-h/2-.005,(z+.09)/2),(w*.242,.009,(z-.13)/2))
        box(b,s+'_pull_'+str(side),(side*.055,-h/2-.025,z*.86),(.034,.010,.008),STEEL)
    box(b,s+'_lower_back',(0,h/2-.01,z/2),(w/2-.022,.010,z/2))
    box(b,'top_'+s,(0,0,z-.012),(w/2,h/2,.012))
    for side in [-1,1]:
        box(b,s+'_upper_side_'+str(side),(side*(w/2-.012),0,z+.30),(.012,h/2,.30))
    box(b,s+'_upper_back',(0,h/2-.007,z+.30),(w/2,.007,.30))
    box(b,s+'_crown',(0,0,z+.60),(w/2,h/2,.013))
    box(b,s+'_fixed_shelf',(0,.047,z+.34),(w/2-.024,h/2-.047,.009))

def washer(mount,s,z,w,h):
    b=mount.find('body')
    for obj in list(b):b.remove(obj)
    # A domestic top loader. Its opening contains no hidden worktop collision plane.
    steel=(.66,.68,.69,1);dark=(.13,.155,.15,1)
    for sign in [-1,1]:
        box(b,'washer_enamel_side_'+str(sign),(sign*(w/2-.012),0,.446),(.012,h/2,.414),WHITE)
        box(b,'washer_enamel_face_'+str(sign),(0,sign*(h/2-.012),.446),(w/2-.024,.012,.414),WHITE)
        box(b,'washer_deck_side_'+str(sign),(sign*.290,0,z-.011),(.053,h/2,.011),WHITE)
        box(b,'washer_deck_end_'+str(sign),(0,sign*.266,z-.011),(.24,.044,.011),WHITE)
    box(b,'top_'+s,(0,0,.539),(.238,.224,.011),steel)
    for k in range(32):
        angle=math.tau*k/32
        radius=.212
        lib.geom(b,'washer_drum_wall_%02d'%k,'box',[radius*math.cos(angle),radius*math.sin(angle)-.007,.697],
                 [.003,.021,.147],steel,euler=[0,0,angle],mass=.014,group=1,contype=1,conaffinity=2)
    for side in [-1,1]:
        box(b,'basket_side_'+str(side),(side*.24,0,.70),(.006,.227,.15),steel)
        box(b,'basket_end_'+str(side),(0,side*.224,.70),(.239,.006,.15),steel)
        for end in [-1,1]:box(b,'washer_foot_%d_%d'%(side,end),(side*.274,end*.243,.017),(.032,.036,.017),dark)
    box(b,'washer_console',(0,.253,z+.048),(w/2,.049,.048),dark)
    box(b,'washer_display',(.109,.199,z+.045),(.058,.005,.021),(.10,.24,.25,1))
    lib.geom(b,'washer_program_dial','cylinder',[-.135,.207,z+.055],[.034,.012],steel,euler=[math.pi/2,0,0],group=1)
    lid=lib.add(b,'body',name='washer_lid',pos=[0,.222,z+.013])
    lib.add(lid,'joint',name='hinge_washing_machine',axis=[-1,0,0],range=[0,1.48],damping=1)
    box(lid,'washer_lid_glazing',(0,-.224,.004),(.244,.218,.012),(.21,.31,.30,1))
    for side in [-1,1]:
        box(lid,'washer_lid_trim_'+str(side),(side*.244,-.224,.004),(.012,.226,.014),WHITE)
    box(lid,'washer_lid_handle',(0,-.444,.022),(.093,.013,.012),dark)
    box(b,'washer_service_ledge',(-.45,-.13,.741),(.113,.075,.012),WHITE)
    box(b,'washer_socket_plate',(-.365,-.13,.776),(.005,.037,.023),dark)

def install(r,c,loc,sz):
    w=r.find('worldbody')
    for s,kind in c['stations'].items():
        mount=w.find(".//body[@name='placement_"+s+"']")
        _,_,z,width,depth=loc[s]
        if kind=='shelf':shelf(mount,s,z,width,depth)
        elif kind=='washer':washer(mount,s,z,width,depth)
        elif kind=='chair':
            frame=mount.find('body');hs=z-.036
            for side in (-1,1):
                lx=side*(width/2-.035);ly=depth/2-.035
                lib.geom(frame,'chair_side_stretcher_'+str(side),'cylinder',None,[.010],EDGE,
                         fromto=[lx,-ly,.24*hs,lx,ly,.24*hs],mass=.015,group=1,contype=0,conaffinity=0)
            if c['id']=='virtualhome_170':
                box(frame,'chair_pull_grip',(0,-depth/2-.012,z-.053),(.085,.013,.013),EDGE)
            cushion='chair_surrogate' if c['id']=='virtualhome_170' else 'seat_surrogate'
            body=w.find("body[@name='item_"+cushion+"']");shape=body.find("geom[@name='payload_"+cushion+"']")
            shape.set('size','.158 .130 .042');sz[cushion]=.042
            p=slots(c,loc,s,cushion);p[2]+=.043;body.set('pos',lib.string(p))
    if c['id']=='virtualhome_320':
        # Rigid, reusable pinch clips make a thin textile/fork or plate accessible from above.
        for name in ('cloth_napkin','dinner_fork','entree_dish','dinner_plate'):
            body=w.find("body[@name='item_"+name+"']")
            z=sz[name]
            lib.geom(body,'clip_post_'+name,'cylinder',[0,0,z+.024],[.004,.024],STEEL,mass=.002,group=1,contype=2,conaffinity=5)
            lib.geom(body,'pinch_grip_'+name,'sphere',[0,0,z+.055],[.007],(.22,.32,.30,1),mass=.003,group=1,contype=2,conaffinity=5)
    if c['id']=='virtualhome_291':
        for name in ('laundry_clothes','washer_plug','detergent_bottle'):
            st=c['props'][name][1];p=slots(c,loc,st,name);p[2]+=sz[name]+.001
            if name=='washer_plug':p[2]+=.002
            w.find(f"body[@name='item_{name}']").set('pos',lib.string(p))
    if c['id']=='virtualhome_170':
        g=w.find(".//geom[@name='top_dining_chair']")
        g.set('friction','1.1 .02 .002');g.set('condim','6')
