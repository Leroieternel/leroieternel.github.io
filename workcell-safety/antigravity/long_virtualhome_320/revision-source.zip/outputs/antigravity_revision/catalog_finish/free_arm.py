"""Relax the unused GR-1 arm in the measured gait without changing the working arm or the payload poses."""
import math,shutil,sys,json
from pathlib import Path
import mujoco as mj
import numpy as np
D=Path(__file__).resolve().parent;H=D/'household'
sys.path.insert(0,str(D.parent/'spatial'))
from common import lib
def apply():
    run=next((H/'runs').glob('06_*'));m=mj.MjModel.from_xml_path(str(run/'scene.xml'));d=mj.MjData(m)
    j,_=lib.arm(m,'gr1','left');qa=m.jnt_qposadr[j]
    foot=[m.body(x).id for x in ('left_foot','right_foot')];base=m.body('base').id
    hand=[g for g in range(m.ngeom) if (m.geom(g).name or '').startswith(('l_palm','L_')) and (m.geom(g).name or '').endswith('_col')]
    scene=[g for g in range(m.ngeom) if (m.geom(g).name or '').startswith(('top_','payload_','dining_chair_crest','dining_chair_lumbar'))]
    buf=np.zeros(6);report={}
    for b in ('safe','unsafe'):
        source=run/(b+'.npz');original=run/(b+'-before-free-arm.npz')
        if not original.exists():shutil.copy2(source,original)
        ar=dict(np.load(original));q=ar['qpos'];rest=q[:,qa].copy();goals=np.zeros_like(rest)
        weights=np.ones(len(q));time=ar['time_s'];speeds=np.linalg.norm(np.gradient(q[:,:2],time,axis=0),axis=1)
        for i,pose in enumerate(q):
            d.qpos[:]=pose;mj.mj_kinematics(m,d)
            delta=(d.xpos[foot[0]]-d.xpos[foot[1]])@d.xmat[base].reshape(3,3)
            stride=np.clip(delta[0],-.26,.26);moving=np.clip(speeds[i]/.25,0,1)
            goals[i]=[.09+stride*.85,.10+.025*moving,.06,-.42-.12*moving+.30*stride,.05,.04,.02]
            # Preserve a clear path for the idle arm as the body turns past the counter.
            amount=0.
            for test_amount in np.linspace(.05,1.,20):
                d.qpos[qa]=rest[i]+test_amount*(goals[i]-rest[i]);mj.mj_kinematics(m,d);clear=True
                for a in hand:
                    nearby=np.flatnonzero(np.all(abs(d.geom_xpos[scene]-d.geom_xpos[a])<(m.geom_rbound[scene]+m.geom_rbound[a]+.035)[:,None],axis=1))
                    for k in nearby:
                        if mj.mj_geomDistance(m,d,a,scene[k],.035,buf)<.03:clear=False;break
                    if not clear:break
                if not clear:break
                amount=test_amount
            weights[i]=amount
        for i in range(1,len(q)):weights[i]=min(weights[i],weights[i-1]+.08)
        for i in reversed(range(len(q)-1)):weights[i]=min(weights[i],weights[i+1]+.08)
        q[:,qa]=rest+weights[:,None]*(goals-rest)
        np.savez_compressed(source,**ar)
        report[b]={'changed_joint_names':[m.joint(x).name for x in j],'fully_relaxed_fraction':float((weights==1).mean()),
                   'moving_arm':'Right arm and objects retain their exact recorded trajectories.'}
    (run/'free-arm.json').write_text(json.dumps(report,indent=1))
    sys.path.insert(0,str(D.parents[1]/'robot_plans'));import optics
    optics.ROOT=H/'runs';optics.CACHE=H/'optics';optics.export(6)
if __name__=='__main__':apply()
