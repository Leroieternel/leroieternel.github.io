"""Flat-foot turning and stepping for the library Fourier GR-1 with a floating pelvis."""
import math
import mujoco as mj
import numpy as np
from common import pl,smooth

def rotz(a):
    r=np.eye(3);r[:2,:2]=pl.rotation(a);return r

class Gait:
    def __init__(self,trial):
        self.t=trial;m=trial.m;self.d=mj.MjData(m);self.legs=[];self.targets=[]
        self.turn=1
        for side in ('l','r'):
            js=[m.joint(side+'_leg_'+name).id for name in ('hip_roll','hip_yaw','hip_pitch','knee_pitch','ankle_pitch','ankle_roll')]
            self.legs.append((m.body(side+'_foot_roll').id,m.jnt_qposadr[js],m.jnt_dofadr[js],m.jnt_range[js]))
        self.d.qpos[:]=trial.q;mj.mj_forward(m,self.d)
        foot=m.geom('r_foot_1').id
        bottom=self.d.geom_xpos[foot,2]-abs(self.d.geom_xmat[foot].reshape(3,3)[2])@m.geom_size[foot]
        # Contact height from the visual outsole vertices. Collision boxes include a wider ankle shell.
        b=self.legs[1][0];gid=next(g for g in range(m.ngeom) if m.geom_bodyid[g]==b and m.geom_type[g]==mj.mjtGeom.mjGEOM_MESH)
        mesh=m.geom_dataid[gid];vs=m.mesh_vert[m.mesh_vertadr[mesh]:m.mesh_vertadr[mesh]+m.mesh_vertnum[mesh]]
        visual_bottom=float((vs@self.d.geom_xmat[gid].reshape(3,3).T+self.d.geom_xpos[gid])[:,2].min())
        self.ankle_height=self.d.xpos[b,2]-visual_bottom
        self.targets=[(self.d.xpos[b].copy(),trial.heading+math.pi/2) for b,qa,va,limits in self.legs]
        for pos,a in self.targets:pos[2]=self.ankle_height
        self.rest_z=trial.q[trial.baseidx+2]-.045
        trial.q[trial.baseidx+2]=self.rest_z
        for _,qa,_,_ in self.legs:trial.q[qa[[2,3,4]]]=[-.28,.59,-.31]
        self.jpos=np.zeros((3,m.nv));self.jang=self.jpos.copy()
        self.plant_error=0.;self.floor_error=0.;self.steps=0
        self.solve(self.targets)
    def solve(self,feet):
        t=self.t;m=t.m;d=self.d;d.qpos[:]=t.q
        for j,(b,qa,va,lim) in enumerate(self.legs):
            p,a=feet[j];rt=rotz(a)
            for _ in range(11):
                mj.mj_kinematics(m,d);mj.mj_comPos(m,d)
                current=d.xmat[b].reshape(3,3)
                err=np.r_[p-d.xpos[b],.36*.5*sum(np.cross(current[:,i],rt[:,i]) for i in range(3))]
                if np.linalg.norm(err)<.00015:break
                mj.mj_jacBody(m,d,self.jpos,self.jang,b);J=np.vstack((self.jpos[:,va],.36*self.jang[:,va]))
                dq=J.T@np.linalg.solve(J@J.T+np.eye(6)*.000035,err)
                d.qpos[qa]=np.clip(d.qpos[qa]+np.clip(dq,-.16,.16),lim[:,0]+.0001,lim[:,1]-.0001)
            t.q[qa]=d.qpos[qa]
        mj.mj_kinematics(m,d)
        for j,(b,_,_,_) in enumerate(self.legs):
            p,a=feet[j]
            if p[2]<=self.ankle_height+.0001:
                self.plant_error=max(self.plant_error,float(np.linalg.norm(d.xpos[b]-p)))
                self.floor_error=max(self.floor_error,float(abs(d.xpos[b,2]-self.ankle_height)))
    def desired(self,xy,h,j):
        return xy+pl.rotation(h)@np.array([-.105 if j==0 else .105,0.])
    def drive(self,xy,heading):
        t=self.t;xy=np.asarray(xy);origin=t.base_xy();h0=t.heading
        arc=pl.angle_diff(heading-h0);dist=np.linalg.norm(xy-origin)
        if dist<.001 and abs(arc)<.007:return
        phases=max(2,int(math.ceil(dist/.14)),int(math.ceil(abs(arc)/.27)))
        for k in range(phases+1):
            j=self.turn;self.turn=1-j
            amount=min(1.,(k+1)/phases);h=h0+arc*amount
            dest=self.desired(origin+(xy-origin)*amount,h,j)
            old,y0=self.targets[j];land=np.r_[dest,self.ankle_height];dy=pl.angle_diff(h+math.pi/2-y0)
            if np.linalg.norm(old-land)<.001 and abs(dy)<.008:continue
            stand=self.targets[1-j][0]
            pelvis0=t.base_xy().copy();a0=t.heading
            pelvis1=(land[:2]+stand[:2])*.5
            h1=h if k==phases else (h+float(self.targets[1-j][1]-math.pi/2))*.5
            h1=a0+pl.angle_diff(h1-a0)
            n=max(45,round(150*max(.40,np.linalg.norm(land-old)/.47,abs(dy)/1.15)))
            for tick in range(1,n+1):
                u=tick/n;v=smooth(u);window=math.sin(math.pi*u)**2
                swing=old+(land-old)*v;swing[2]+=.042*window
                feet=list(self.targets);feet[j]=(swing,y0+dy*v)
                a=t.baseidx;t.heading=a0+(h1-a0)*v;angle=t.heading+math.pi/2
                mid=pelvis0+(pelvis1-pelvis0)*v
                t.q[a:a+2]=mid+.22*(stand[:2]-mid)*window
                t.q[a+2]=self.rest_z+.006*window
                t.q[a+3:a+7]=[math.cos(angle/2),0,0,math.sin(angle/2)]
                self.solve(feet);t.frame()
            self.targets[j]=(land,y0+dy);self.steps+=1
        t.turn+=abs(arc)
