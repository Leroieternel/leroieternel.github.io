"""Export two native 4K photographs of the same scene and stored state used for each film."""
import math,sys,json
from pathlib import Path
import bpy,numpy as np
from house_film import setup,acquire,direct_camera,H
def render(ident):
    acquire();run,info,view,scene,pose,sources=setup(ident)
    scene.render.engine='CYCLES';scene.cycles.samples=36;scene.cycles.use_denoising=True
    scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=96
    d=H/'photographs'/ident;d.mkdir(parents=True,exist_ok=True)
    if ident.endswith('291'):
        wide=((2.68,-4.70,2.60),(-.49,.41,.84),35)
        detail=((-1.28,-.37,1.64),(-.98,1.18,.82),39)
        t=info['branches']['unsafe']['event']+.54
    elif ident.endswith('170'):
        wide=((2.71,-4.24,2.46),(-.08,.22,.80),34)
        detail=((-0.17,-1.83,1.22),(.73,-.56,.53),38)
        t=info['branches']['unsafe']['event']+1.55
    else:
        wide=((2.65,-4.26,2.30),(-.08,.24,.91),34)
        detail=((.43,.10,1.57),(-.60,1.10,1.02),62)
        t=next(x['time'] for x in info['branches']['unsafe']['pinch_clips'] if x['item']=='dinner_plate')
    ar=np.load(run/'unsafe.npz')
    for file,time,cam in [('room-4k.jpg',.44,wide),('action-4k.jpg',t,detail)]:
        pose('unsafe',np.abs(ar['time_s']-time).argmin());direct_camera(view.cam,*cam)
        scene.render.filepath=str(d/file);bpy.ops.render.render(write_still=True)
    print(ident,flush=True)
if __name__=='__main__':render(sys.argv[1])
