"""Preserve UVs and composed poses of the two Genie Sim room furnishings."""
from pathlib import Path
import json
import numpy as np
from pxr import Usd,UsdGeom
D=Path(__file__).resolve().parent
cache=D/'household/library';cache.mkdir(parents=True,exist_ok=True)
for label,asset in [('bed','bed/benchmark_bed_000'),('plant','plant/benchmark_plant_001')]:
    directory=D.parents[2]/'.runtime/genie-singleton-rooms/background/common'/asset
    stage=Usd.Stage.Open(str(directory/'Aligned.usda'));mesh=next(UsdGeom.Mesh(p) for p in stage.Traverse() if p.IsA(UsdGeom.Mesh))
    trans=np.array(UsdGeom.Xformable(mesh).ComputeLocalToWorldTransform(Usd.TimeCode.Default()))
    p=np.asarray(mesh.GetPointsAttr().Get());p=p@trans[:3,:3]+trans[3,:3]
    indices=np.asarray(mesh.GetFaceVertexIndicesAttr().Get(),np.int32);counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get(),np.int32)
    st=UsdGeom.PrimvarsAPI(mesh).GetPrimvar('st');uv=np.asarray(st.ComputeFlattened())
    if str(st.GetInterpolation()) in ('vertex','varying'):uv=uv[indices]
    assert len(uv)==len(indices)
    p-=np.array([*(p.min(0)[:2]+p.max(0)[:2])/2,p.min(0)[2]])
    if label=='bed' and np.ptp(p[:,1])>np.ptp(p[:,0]):p=p[:,[1,0,2]]*[-1,1,1]
    np.savez_compressed(cache/(label+'.npz'),p=p.astype(np.float32),faces=indices,counts=counts,uv=uv.astype(np.float32))
    print(label,np.ptp(p,axis=0),flush=True)
