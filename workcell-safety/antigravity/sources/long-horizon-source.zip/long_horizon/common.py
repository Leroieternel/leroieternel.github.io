import ast,hashlib,json,sys,math
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent
H=D.parent/'hard1044'
ROOT=D.parents[2]
sys.path.append(str(H))
import robotlib as lib
from run import camera
SOURCE=json.loads((D/'selection.json').read_text())['cases']
BOTS={'spot':'bddl_580 bddl_403 bddl_527 bddl_430 bddl_839','baxter':'neiss_6342 normbank_42830','panda':'normbank_65609','gr1':'virtualhome_320 normbank_42114'}
SCENES={'Dining room':'virtualhome_320 virtualhome_170','Bedroom':'bddl_580 bddl_839','Garage':'bddl_403 bddl_430','Laundry room':'virtualhome_291','Market stall':'bddl_527','Living room':'bddl_812 bddl_994','Banquet hall':'normbank_42114','Laboratory':'normbank_42830','Print shop':'normbank_65609','Café':'normbank_53453'}
def lookup(groups,ident,default):
    return next((key for key,ids in groups.items() if ident in ids.split()),default)
def load_cases():
    specs={}
    for path in sorted((D/'generated').glob('set*.py')):
        assert hashlib.sha256(path.read_bytes()).hexdigest()==json.loads((D/'provenance'/(path.stem+'.json')).read_text())['sha256']
        for c in ast.literal_eval(ast.parse(path.read_text()).body[0].value):
            specs[c['id']]=dict(c,program=path.stem)
    out={}
    for i,r in enumerate(SOURCE,1):
        ident=r['id'];c=specs[ident];c.update(rank=i,robot=lookup(BOTS,ident,'omron'),scene=lookup(SCENES,ident,'Kitchen'),ref=r)
        for b in ('safe','unsafe'):
            assert len(c[b])==len(r[b]),(ident,b)
            for op in c[b]:
                verb,item,station=op.split()
                assert (item=='-' or item in c['props']) and station in c['stations'],(ident,op)
        out[ident]=c
    return out
def folder(c):return D/'runs'/('%02d_%s'%(c['rank'],c['id']))
def save(p,obj):p.write_text(json.dumps(obj,indent=2,allow_nan=False,default=lambda a:a.tolist() if isinstance(a,np.ndarray) else a.item())+'\n')
def xyz(x,y,z):return np.array([x,y,z],float)
def smooth(u):
    u=min(1.,max(0.,u));return u*u*(3-2*u)
def names(c):return list(c['props'])
def layout(c):
    mobile=c['robot'] in ('spot','omron','gr1') and c['id']!='normbank_42114'
    n=len(c['stations']);res={}
    for j,(s,kind) in enumerate(c['stations'].items()):
        if mobile: x=(j-(n-1)/2)*.94;y=.70 if c['robot']=='spot' else .29 if c['robot']=='gr1' else .56;w=.85;dep=.40
        else:
            x=(j-(n-1)/2)*.29+(.11 if c['robot']=='baxter' else .05)
            y=.52-.075*abs(j-(n-1)/2);w=.278;dep=.32
        z={'spot':.69,'omron':.81,'panda':.90,'baxter':.89,'gr1':.93}[c['robot']]
        if kind in ('floor','bed','sofa'):z-=.13
        if c['robot']=='gr1' and mobile:z=1.04
        if c['id']=='normbank_42114':x=.24+(j-(n-1)/2)*.20;y=.26;z=1.025;w=.192;dep=.26
        if kind=='chair':z=.49
        res[s]=(x,y,z,w,dep)
    return res
def slots(c,layout,station,item):
    x,y,z,w,h=layout[station];j=list(c['props']).index(item);count=len(c['props'])
    # Each prop has a persistent berth at each station, including when temporarily staged.
    cols=3 if w>.4 else 2;rows=math.ceil(count/cols);col=j%cols;row=j//cols
    return xyz(x+(col-(cols-1)/2)*min(.16,w/(cols+.22)),y+(row-(rows-1)/2)*min(.11,h/(rows+.8))-.018,z)
