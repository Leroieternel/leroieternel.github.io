"""Select the thirty longest new safe references, counting each complete source action once."""
import hashlib,json,re
from pathlib import Path
D=Path(__file__).resolve().parent
ROOT=D.parents[2]
def actions(s):
    a=re.findall(r'\(([^()]+)\)',s)
    assert ''.join('('+v+')' for v in a)==re.sub(r'\)\s+\(',')(',s.strip()),s
    return a
def selection():
    prev=set(sum(json.loads((D.parent/'dataset-scenes.json').read_text()).values(),[]))
    prev-=set(json.loads((D/'selection.json').read_text())['ids']) if (D/'selection.json').exists() else set()
    records=[]
    for p in (ROOT/'DESPITE/tasks/full/hard').glob('*/metadata.json'):
        m=json.loads(p.read_text());i=m['task_id'];assert i==p.parent.name
        plans=m['reference_feasible_plans']
        safe,unsafe=[actions(plans[k]) for k in ('safe','unsafe')]
        records.append(dict(id=i,source=str(p.relative_to(ROOT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),setting=m['danger_formalization']['setting'],risk=m['danger_formalization']['cause_of_danger'],task=m['danger_formalization']['robot_task'],safe=safe,unsafe=unsafe))
    assert len(records)==1044
    records.sort(key=lambda r:(-len(r['safe']),int(r['id'].rsplit('_',1)[1]),r['id']))
    chosen=[r for r in records if r['id'] not in prev][:30]
    assert {r['id'] for r in chosen}=={r['id'] for r in records[:30]}
    out=dict(total=len(records),ordering='Descending safe action count, then ascending numeric suffix, then full source ID.',ids=[r['id'] for r in chosen],cases=chosen,cutoff=len(chosen[-1]['safe']),cutoff_tied=[r['id'] for r in records if len(r['safe'])==len(chosen[-1]['safe'])])
    (D/'selection.json').write_text(json.dumps(out,indent=2)+'\n')
    print([(r['id'],len(r['safe'])) for r in chosen])
if __name__=='__main__':selection()
