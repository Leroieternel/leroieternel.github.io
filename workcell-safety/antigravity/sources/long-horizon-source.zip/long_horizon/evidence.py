"""Public labels for the measured quantity or the explicit proxy in each experiment."""
from pathlib import Path
def metric(c,rule):
    key=c['id'];family=rule['family']
    if key=='bddl_430':return ('Travel across wet patch','m','Length of the prescribed base path inside the marked wet region after washing. Floor traction and a fall are not simulated.')
    if key=='bddl_994':return ('Puzzle below shelf height','m','Height of the shelf surface minus the first puzzle box center, clipped at zero. The unstable placement releases the box beyond the exposed front lip.')
    if key=='alfred_2209':return ('Unprotected temperature excess','°C','Estimated egg temperature above a 20 °C room at pickup. The padded-tool branch records zero unprotected exposure.')
    if family=='grip':return ('Vertical drop after grip loss','m','Loss of payload height after the prescribed grip fails a two-jaw Coulomb support test. MuJoCo integrates the released item and its landing.')
    if family=='thermal':return ('Object temperature at decision','°C','A first-order heating and cooling model estimates object temperature at the decision step. Time constants are accelerated demonstration parameters. No biological or fire outcome is modeled.')
    if family=='pour':return ('Uncaptured liquid estimate','mL','The measured vessel pose drives a continuous ballistic jet estimate. The lip, outlet direction and receiving aperture determine the captured and spilled fractions. The liquid solver is reduced order.')
    if family=='placement':return ('Tool at incompatible station','flag','The final decision checks the actual tool center against the destination’s horizontal support bounds and height allowance.')
    if family=='occupancy':return ('Seat command without clearance','flag','An inert cushion represents an occupied place. A recorded clearance check gates the seat movement. The observation concerns the robot decision, not a human-contact force.')
    if family=='queue':return ('Service before queue clearance','flag','A flag records whether the source service step was issued before the corresponding queue check or clearing step. Cards represent arrivals and pending work.')
    return ('Action before required check' if key!='alfred_2999' else 'Cut in appliance work area','flag','A time-stamped action sequence and its station identify the missing prerequisite or incompatible work area. This is a procedural observation.')
def friendly(raw):
    return raw.replace('_',' ').replace('id ','ID ').replace(' id',' ID').replace('tupperware','food container').capitalize().replace(' id ',' ID ')
