"""Paired, compliant hand contact for guiding the trailing end of an empty transfer dolly."""
import math
import numpy as np
from scipy.signal import savgol_filter
from shared import S, T
from world import add, cyl
from generated import handling
from motion_review.generated import handler

BAR_Y = -1.20
BAR_Z = 1.065
GRIP_RADIUS = .021
PAD_RADIUS = .023
SIDES = ('L', 'R')
GRIP_X = np.array([-.189, .189])
# The solver pad sits inside the heel of the palm. Its lower/front surface meets the grip.
PAD_OFFSET = np.array([0., -.020, .0375])
RIG_ORIGIN = np.array([.26, -2.56 + BAR_Y - .355])
ACTOR_PATH = np.load(S/'runs/hospital/human.npz')
HIP = ACTOR_PATH['names'].tolist().index('Hip')
WALK_Y = savgol_filter(ACTOR_PATH['joints'][:, HIP, 1].astype(float), 29, 2)
DISTANCE = np.maximum.accumulate(WALK_Y-WALK_Y[0])
DISTANCE[T>=7.16] = DISTANCE[np.flatnonzero(T>=7.16)[0]]
INITIAL_VELOCITY = (DISTANCE[3]-DISTANCE[0])/.12

def fit(cart,w):
    for key,x in zip(SIDES,(-.296,.296)):
        add(cart,'geom',name='push_post_'+key,type='cylinder',
            fromto=[x,-.61,.25,x,BAR_Y,.52],size='.015',group='1',rgba='.45 .50 .52 1',
            contype='1',conaffinity='4',mass='.13')
        add(cart,'geom',name='handle_upright_'+key,type='cylinder',fromto=[x,BAR_Y,.52,x,BAR_Y,BAR_Z],
            size='.015',group='1',rgba='.45 .50 .52 1',contype='1',conaffinity='4',mass='.12')
    carrier=add(cart,'body',name='push_bar',pos=[0,BAR_Y,BAR_Z])
    add(carrier,'joint',name='bar_compression',type='slide',axis='0 0 1',limited='true',
        range='-.009 .003',stiffness='6500',damping='33',springref='0')
    rail=cyl(carrier,'push_crossbar',[0,0,0],.014,.62,'steel',False,
             euler=[0,math.pi/2,0],mass='.40')
    for s,x in zip(SIDES,GRIP_X):
        grip=cyl(carrier,'push_grip_'+s,[x,0,0],GRIP_RADIUS,.155,'navy',True,
                 euler=[0,math.pi/2,0],mass='.08')
        grip.attrib.update(contype='8',conaffinity='16',solref='.012 1',solimp='.76 .97 .004',
                           friction='.52 .003 .0001')
        pad=add(w,'body',name='clinician_palm_'+s,gravcomp='1',pos=np.array([.26+x,-2.56+BAR_Y,BAR_Z])+PAD_OFFSET)
        for index,axis in enumerate(np.eye(3)):
            add(pad,'joint',name='hand_'+s+str(index),type='slide',axis=axis,limited='false',damping='0.02')
        add(pad,'inertial',pos='0 0 0',mass='.19',diaginertia='.00004 .00004 .00004')
        add(pad,'geom',name='palm_pad_'+s,type='sphere',size=PAD_RADIUS,group='4',rgba='0 0 0 0',
            contype='16',conaffinity='8',solref='.012 1',solimp='.76 .97 .004',friction='.52 .003 .0001')
    return carrier

def recovery_steps(elapsed):
    def step(start, duration):
        f=np.clip((elapsed-start)/duration,0.,1.)
        return f*f*(3.-2.*f)
    return step(.15,.56),step(.71,.60)

def retreat_distance(elapsed):
    first,second=recovery_steps(elapsed)
    return .57*(first+second)*.5

class Hands:
    def __init__(self,model):
        self.bar=model.body('push_bar').id
        self.body=model.body('gurney_dolly').id
        self.hand_bodies=[model.body('clinician_palm_'+s).id for s in SIDES]
        self.dofs=np.array([[model.joint('hand_'+s+str(i)).dofadr[0] for i in range(3)] for s in SIDES])
        self.prev_goal=None
        self.grip_ids=[model.geom('push_grip_'+s).id for s in SIDES]
        self.pads=[model.geom('palm_pad_'+s).id for s in SIDES]
        self.released=None
        self.held_seconds=0.
        self.last_touch=-10.
        self.last_loads=np.zeros(2)
        self.liftoff=None
        self.attitude=None
        self.goal=np.zeros((2,3))
        self.at_release=None

    def input(self,d,t,dt):
        # The clinician's independent gait is the forward reference. The hands follow the
        # lateral bar orientation while in reach and yield to resistance in the travel direction.
        local_forward=d.xmat[self.body].reshape(3,3)[:,1]
        local_right=d.xmat[self.body].reshape(3,3)[:,0]
        planned=-2.56+float(np.interp(t,T,DISTANCE))+BAR_Y
        center=d.xpos[self.body]+np.array([0.,0.,BAR_Z])+BAR_Y*local_forward
        following_error=planned-center[1]
        local_normal_y=np.clip(-.0025-.48*following_error,-.024,.024)
        # Maintain a light grasp around each sleeve even when the coasting dolly runs
        # slightly ahead of the operator's stride. The pad compliance resolves the load.
        radial_setpoint=.0385
        above=math.sqrt(radial_setpoint**2-local_normal_y**2)
        self.goal=center+np.outer(GRIP_X,local_right)+local_normal_y*local_forward
        self.goal[:,2]=d.xpos[self.bar,2]+above
        if self.released is not None:
            _,fraction,_=handling.handling_pose(t-self.released)
            y=float(np.mean(self.at_release[:,1]))
            guarded=np.column_stack((.26+GRIP_X,[y+.005]*2,[1.235]*2))
            resting=np.column_stack((.26+1.18*GRIP_X,[y-.10]*2,[.91]*2))
            rest=np.clip((t-self.released-.68)/.92,0.,1.)
            rest=rest*rest*(3.-2.*rest)
            self.goal=(1.-fraction)*self.at_release+fraction*((1.-rest)*guarded+rest*resting)
            self.goal[:,1]-=retreat_distance(t-self.released)
            if self.liftoff is not None:
                for k,side in enumerate(SIDES):
                    outward,forward=handler.clearance_after_release(t-self.released,side)
                    self.goal[k,0]+=(1 if side=='R' else -1)*outward
                    self.goal[k,1]+=forward
        velocity=np.broadcast_to([0.,INITIAL_VELOCITY,0.],(2,3)) if self.prev_goal is None else (self.goal-self.prev_goal)/dt
        # Dynamic palm pads carry their true velocity into the contact solver.
        force=1800.*(self.goal-d.xpos[self.hand_bodies])+31.*(velocity-d.qvel[self.dofs])
        d.qfrc_applied[self.dofs]=np.clip(force,-42.,42.)
        self.prev_goal=self.goal.copy()

    def observe(self,t,dt,forces,tilt,support):
        if min(forces)>.04:
            self.held_seconds+=dt
            self.last_touch=t
        if self.released is None and handling.release_due(self.held_seconds>.14 and t-self.last_touch<.16,tilt,support):
            self.released=float(t)
            self.at_release=self.goal.copy()
            self.attitude=float(tilt)
        if self.released is not None and self.liftoff is None and max(forces)<.015 and t>self.released:
            self.liftoff=float(t)
