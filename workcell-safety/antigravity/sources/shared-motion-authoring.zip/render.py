"""Render the audited MuJoCo transforms, native skinned performers and Antigravity environments."""
from pathlib import Path
import sys,json,math,argparse,os
from functools import lru_cache
import numpy as np
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parent;ROOT=D.parents[2];LIB=D.parents[1]/'mobile_worlds/library'
sys.path[:0]=[str(D),str(LIB),str(D.parents[1]/'paired_workcells')]
import cycles_render as cr,world_assets as wa,pbr
from generated import inside,outside,story
cr.CACHE=D/'optics'; tasks=json.loads((D/'selection.json').read_text()); byslug={r['slug']:r for r in tasks}
wa.GENIE.update(json.loads((D/'assets/extra-genie.json').read_text()))
for item in wa.GENIE.values():
 for mat in item['materials']:
  for key,value in mat.items():
   if isinstance(value,str):wa.native_maps().setdefault(value,value)
FLOOR={'crossing':'concrete_floor_worn_001','market':'genie_floor_tile_02','bus':'genie_floor_tile_05','hospital':'genie_floor_tile_01','meeting':'genie_floor_02','museum':'genie_floor_05','hotel':'genie_floor_tile_03','bank':'genie_floor_tile_04','library':'genie_floor_01','warehouse':'concrete_floor_worn_001'}
WALL={'crossing':'genie_wall_02','market':'genie_wall_03','bus':'genie_wall_06','hospital':'genie_wall_tile_01','meeting':'genie_wall_05','museum':'genie_wall_07','hotel':'genie_wall_03','bank':'genie_wall_06','library':'genie_wall_02','warehouse':'genie_wall_tile_04'}
COLORS={'white':(.79,.79,.74),'black':(.045,.055,.061),'steel':(.26,.31,.32),'chrome':(.62,.66,.67),'glass':(.33,.49,.52),'navy':(.044,.115,.17),'red':(.55,.12,.065),'sage':(.32,.45,.34),'teal':(.063,.28,.28),'yellow':(.95,.63,.11),'leaf':(.18,.31,.075),'terracotta':(.62,.25,.12),'ivory':(.82,.77,.64),'paint':(.66,.70,.66),'rubber':(.035,.042,.044),'light':(.97,.88,.68),'stl':(.32,.36,.37)}
def plain(key):
 m=bpy.data.materials.get('Finish | '+key)
 if m:return m
 m=wa.new_material('Finish | '+key);s=m.node_tree.nodes.get('Principled BSDF');col=COLORS[key]
 s.inputs['Base Color'].default_value=(*col,1);s.inputs['Metallic'].default_value={'steel':.86,'chrome':.97,'stl':.83}.get(key,0)
 s.inputs['Roughness'].default_value={'chrome':.20,'glass':.17,'steel':.34,'stl':.34,'rubber':.79}.get(key,.44)
 if key=='glass':
  s.inputs['Transmission Weight'].default_value=.28;s.inputs['Coat Weight'].default_value=.8;s.inputs['Alpha'].default_value=.30;m.surface_render_method='BLENDED';m.use_transparency_overlap=False
 if key=='light':
  s.inputs['Emission Color'].default_value=(*col,1);s.inputs['Emission Strength'].default_value=1.2
 return m
def shaded_mesh(name,center,size,mat,bevel=0):
 ob=cr.box({'name':name,'sz':np.array(size)/2,'uniform':True})
 if bevel==0:ob.modifiers.clear()
 ob.location=center;ob.data.materials.append(mat);return ob
def cylinder(name,point,r,depth,mat):
 ob=cr.cylinder({'name':name,'sz':(r,depth/2,0)});ob.location=point;ob.data.materials.append(mat);return ob
def replace(ob,mat):
 ob.data.materials.clear();ob.data.materials.append(mat)
class Set:
 def __init__(self,slug):self.slug=slug;self.assets=set();self.finish=set()
 def mat(self,key):
  k={'oak':'genie_floor_00','walnut':'walnut_veneer','stone':'genie_wall_tile_05','brick':'brick_wall_001','terrazzo':'terrazzo_tiles','concrete':'concrete_floor_worn_001','paint':WALL[self.slug]}.get(key)
  if k:
   self.finish.add(k);return wa.pbr(k,1.4 if key not in ('oak','walnut') else 1.9,'XZ' if key in ('brick','paint') else 'XY')
  return plain(key)
 def box(self,name,center,size,mat,yaw=0,bevel=.015):
  if self.slug=='crossing' and name.startswith('st_'):center=((-1.0 if name=='st_0' else 1.0),center[1],center[2]);size=(.065,size[1],size[2])
  # Painted markings on a level contact surface have no raised plate under a shoe.
  if center[2]<=.005 and size[2]<=.012:center=(center[0],center[1],.00030);size=(*size[:2],.00020)
  o=shaded_mesh(name,center,size,self.mat(mat),bevel);o.rotation_euler.z=yaw;return o
 def cyl(self,name,center,r,depth,mat,axis='Z'):
  o=cylinder(name,center,r,depth,self.mat(mat));o.rotation_euler=(0,math.pi/2,0) if axis=='X' else (math.pi/2,0,0) if axis=='Y' else (0,0,0);return o
 def beam(self,name,start,end,r,mat):
  a,b=Vector(start),Vector(end);o=cylinder(name,(a+b)/2,r,(b-a).length,self.mat(mat));o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
 def sign(self,text,center,width,height):
  self.box('Enamel sign '+text,center,(width,.014,height),'navy',0,.005)
  cu=bpy.data.curves.new(text,'FONT');cu.body=text;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=min(height*.56,width*1.45/max(1,len(text)))
  o=bpy.data.objects.new('Lettering '+text,cu);bpy.context.collection.objects.link(o);o.location=(center[0],center[1]-.008,center[2]);o.rotation_euler.x=math.pi/2;cu.materials.append(plain('white'));return o
 def genie(self,key,center,floor_z,height,yaw=0):
  self.assets.add(key)
  # Honor the native product scale. The catalog bin is a shallow tote, and books lie flat.
  if key in ('book','book2'):height=min(height,.036)
  elif key=='bin':height=min(height,.22)
  elif key=='cabinet':height=min(height,.93)
  if self.slug=='hospital' and key=='chair' and abs(center[0])<1:center=(center[0]-2.05,center[1])
  return wa.place(key,(*center,floor_z),height,yaw)
def native_human(slug,*,actor=None,transforms=None):
 p=D/'runs'/slug;actor=actor or json.loads((p/'human.json').read_text())['asset'];src=D/'assets/people'/actor;tex=json.loads((src/'textures.json').read_text())
 mat=wa.new_material('Isaac People | '+actor);s=mat.node_tree.nodes.get('Principled BSDF')
 for ch,k in [('BaseColor','Base Color'),('Normal','Normal'),('ORM','ORM')]:
  if ch in tex:wa.connect_texture(mat,k,tex[ch])
 meshlist=[]
 if transforms is not None:tr=transforms
 elif (p/'safe-person.npz').is_file() and (p/'unsafe-person.npz').is_file():
  tr=np.concatenate([np.load(p/(b+'-person.npz'))['trans'] for b in ('safe','unsafe')])
 else:tr=np.load(p/'human.npz')['trans']
 for fn in sorted(src.glob('*.npz')):
  if fn.stem=='skeleton':continue
  with np.load(fn) as m:
   v=m['vertices'];ids=m['ids'];w=m['weights'];f=m['faces']
   ob=cr.meshobj(fn.stem,v,f,m['uv'],True);ob.data.materials.append(mat)
   if fn.stem.startswith('trans') and 'skin' not in fn.stem:
    alpha=mat.copy();nt=alpha.node_tree;bs=nt.nodes.get('Principled BSDF');node=next(z for z in nt.nodes if z.type=='TEX_IMAGE' and z.label=='Base Color');nt.links.new(node.outputs['Alpha'],bs.inputs['Alpha']);replace(ob,alpha)
   xyz=np.zeros((len(tr),len(v),3),dtype='f')
   for j in range(ids.shape[1]):
    for start in range(0,len(tr),32):
     mats=tr[start:start+32,ids[:,j]];xyz[start:start+32]+=(np.einsum('tnij,nj->tni',mats[:,:,:,:3],v)+mats[:,:,:,3])*w[:,j,None]
   meshlist.append((ob,xyz,f))
 return meshlist
WIDE={'crossing':((3.55,-7.0,3.35),(0,0,.42),32),'market':((2.35,-3.78,1.93),(.35,.40,.98),39),'bus':((1.25,-7.65,2.67),(-.15,.82,.82),33),'hospital':((3.8,-6.55,2.96),(-.10,.17,.70),32),'meeting':((2.15,-5.75,2.10),(-.16,.37,.90),31),'museum':((3.40,-2.18,1.90),(-.18,.20,.85),34),'hotel':((1.85,-4.82,2.36),(-.28,.02,.86),34),'bank':((2.25,-3.58,1.94),(.36,.22,.98),39),'library':((2.03,-6.35,2.69),(-.10,.37,.84),32),'warehouse':((3.80,-7.45,3.13),(0,0,.96),31)}
DETAIL={'market':((1.04,-1.35,1.48),(.48,.14,.84),48),'museum':((1.27,-1.58,1.77),(.26,-.23,1.12),47),'bank':((1.00,-1.00,1.53),(.365,-.15,.947),44),'hotel':((1.45,-2.40,1.68),(.10,.25,.98),44),'warehouse':((2.55,-3.80,2.22),(.05,-.34,1.3),38)}
def aim(cam,shot):
 eye,at,lens=shot;cam.location=eye;cam.rotation_euler=(Vector(at)-Vector(eye)).to_track_quat('-Z','Y').to_euler()
 cam.data.sensor_fit='HORIZONTAL';cam.data.sensor_width=36;cam.data.lens=lens
def scene_for(slug,*,cast=None,appearance=None):
 k=list(byslug).index(slug)+1;pbr.CACHE.clear();v=cr.View(k);s=v.scene;sets=Set(slug);v.pose('safe',0)
 s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=8;s.eevee.use_shadows=True;s.eevee.use_raytracing=True
 s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100;s.render.fps=25;s.render.image_settings.quality=91
 for ob in list(s.objects):
  if ob.type=='LIGHT':bpy.data.objects.remove(ob,do_unlink=True)
 az,el,temp=story.STORIES[slug]['daylight'];out=byslug[slug]['environment']=='outdoor'
 s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=-.25 if out else -.18
 nt=s.world.node_tree;nt.nodes.clear();bg=nt.nodes.new('ShaderNodeBackground');wo=nt.nodes.new('ShaderNodeOutputWorld');nt.links.new(bg.outputs[0],wo.inputs[0])
 hdr=ROOT/'.runtime/genie-assets/background/common/HDR'/('0010_office.hdr' if slug in ('hospital','meeting','warehouse','bank') else '0006_home.hdr')
 if out:
  hdr=ROOT/'.runtime/genie-assets/background/common/HDR'/'rostock_laage_airport_8k.hdr'
  env=nt.nodes.new('ShaderNodeTexEnvironment');env.image=bpy.data.images.load(str(hdr),check_existing=True);nt.links.new(env.outputs['Color'],bg.inputs['Color']);bg.inputs['Strength'].default_value=.52
 else:
  env=nt.nodes.new('ShaderNodeTexEnvironment');env.image=bpy.data.images.load(str(hdr),check_existing=True);nt.links.new(env.outputs['Color'],bg.inputs['Color']);bg.inputs['Strength'].default_value=.37
 ang=math.radians(az);e=math.radians(el);ld=bpy.data.lights.new('Daylight','SUN');ld.energy=2.25 if out else 1.02;ld.angle=math.radians(6 if out else 10)
 ld.color=(1,.92 if temp<5900 else .96,.81 if temp<5800 else .91)
 sun=bpy.data.objects.new('Daylight',ld);s.collection.objects.link(sun);sun.rotation_euler=Vector((math.cos(ang)*math.cos(e),math.sin(ang)*math.cos(e),-math.sin(e))).to_track_quat('-Z','Y').to_euler()
 cr.area('Broad sky and window',(-3.3,-3.7,5.1),(0,0,.8),610 if not out else 500,(.85,.92,1),5.8,4.2)
 cr.area('Edge reflection',(3.0,2.4,4.4),(0,0,.85),640 if not out else 440,(1,.88,.73),4.4,2.0)
 cr.area('Front bounce',(2.0,-4.2,2.8),(0,0,.85),265,(1,.94,.86),3.8)
 for spec,ob in zip(v.spec,v.obs):
  name=spec['name']
  if name=='stage_ground':
   replace(ob,wa.pbr(FLOOR[slug],2.4 if out else 1.7,'XY'));sets.finish.add(FLOOR[slug])
  if name.endswith('_top') or name in ('service_shelf','carried_bar'):replace(ob,wa.pbr('walnut_veneer',.85,'XY'));sets.finish.add('walnut_veneer')
  if name in ('replica_foot','brass_rim'):replace(ob,plain('chrome'))
  if name=='cast_vessel':
   # The physical ellipsoid has three independent semi-axes.
   v.obs[v.obs.index(ob)].data.transform(__import__('mathutils').Matrix.Diagonal(Vector((*[a/spec['sz'][0] for a in spec['sz']],1))))
 (outside if out else inside).dress(slug,sets)
 if out:
  for i,x in enumerate((-14,-10,10,14)):
   outside._bay(sets,'street_return_'+str(i),x,7.86,.10,3.98,('sage','navy','teal','walnut')[i],None)
  # The ground runout extends beyond both ends of the street.
  sets.box('Road extension left',(-23,0,-.017),(21,22,.034),'concrete',0,0)
  sets.box('Road extension right',(23,0,-.017),(21,22,.034),'concrete',0,0)
 if slug in ('library','hospital','meeting','hotel','bus'):
  x={'library':0.,'hospital':-.96,'meeting':-.25,'hotel':.15,'bus':-.08}[slug]
  for y in (0,-1,1):sets.box('Flush zone marker '+str(y),(x,y-.15,.00005),(.038,.63,.0001),'white' if slug in ('bus','hospital') else 'yellow',0,0)
 if slug=='market':sets.sign('SODA   2.50',(.47,.54,.94),.21,.053)
 wa.align_planar_uvs();human=native_human(slug) if cast is None else cast(slug)
 rec=dict(genie_models={k:{f:wa.GENIE[k][f] for f in ('id','source','revision','sha256')} for k in sorted(sets.assets)},surface_maps={k:{ch:str(path.relative_to(ROOT)) for ch,path in wa.finish_maps(k).items()} for k in sorted(sets.finish)},light=dict(sun_azimuth_deg=az,sun_elevation_deg=el,reference_CCT_K=temp,world=str(hdr.relative_to(ROOT)),renderer='Blender 4.5 EEVEE Next'))
 (appearance or D/'runs'/slug/'appearance.json').write_text(json.dumps(rec,indent=2))
 return v,human
def setpose(v,h,slug,branch,i,detail=False):
 v.pose(branch,i)
 for ob,xyz,faces in h:
  ob.data.vertices.foreach_set('co',xyz[i+(301 if len(xyz)==602 and branch=='unsafe' else 0)].ravel());ob.data.update()
 cut=slug in DETAIL and ((slug in ('market','museum','bank') and 117<=i<=265) or (slug=='hotel' and 126<=i<=203) or (slug=='warehouse' and 140<=i<=208))
 if slug=='museum' and i>=240:
  aim(v.cam,((2.90,-3.73,1.92),(.42,-.34,.62),32))
 else:aim(v.cam,DETAIL[slug] if (cut or detail) and slug in DETAIL else WIDE[slug])
def run(slug,mode):
 v,h=scene_for(slug);s=v.scene;out=D/'media'/slug;out.mkdir(exist_ok=True)
 if mode=='audit':
  from audit_mesh import review
  review(slug,v,h);return
 ev=json.loads((D/'runs'/slug/'unsafe.json').read_text())['first_event_s']
 if mode=='verify':
  import tempfile
  report={}
  with tempfile.TemporaryDirectory(prefix='shared-frame-check-') as folder:
   for b in ('safe','unsafe'):
    pairs=[]
    for i in (12,int((ev+.22)*25),282):
     s.frame_set(i+1);setpose(v,h,slug,b,i);file=Path(folder)/(b+str(i)+'.jpg')
     s.render.filepath=str(file);bpy.ops.render.render(write_still=True)
     recorded=out/b/('frame-%04d.jpg'%(i+1))
     def thumb(f):
      im=bpy.data.images.load(str(f),check_existing=False);im.scale(384,216)
      px=np.empty(384*216*4,'f');im.pixels.foreach_get(px);bpy.data.images.remove(im);lin=px.reshape(-1,4)[:,:3].clip(0,1)
      return 255*np.where(lin<=.00313,lin*12.92,1.055*lin**(1/2.4)-.055)
     diff=np.mean(np.abs(thumb(file)-thumb(recorded)))
     pairs.append(dict(frame_1_based=i+1,mean_rgb_error_255=round(float(diff),3)))
     assert diff<3.6,(slug,b,i,diff)
    report[b]=pairs
  (D/'runs'/slug/'render-check.json').write_text(json.dumps(report,indent=2))
  return
 if mode=='proof':
  for i in (0,min(290,round((ev+.48)*25)),260):
   setpose(v,h,slug,'unsafe',i);s.render.resolution_percentage=59;s.render.filepath=str(D/'proofs'/f'{slug}_{i:03}.jpg');bpy.ops.render.render(write_still=True)
  return
 for b in ('unsafe','safe'):
  folder=out/b;folder.mkdir(exist_ok=True);s.frame_start=1;s.frame_end=300
  s.render.filepath=str(folder/'frame-');s.render.use_file_extension=True;s.render.use_overwrite=os.environ.get('RENDER_REPLACE')=='1'
  def update(sc,*args):setpose(v,h,slug,b,min(300,max(0,sc.frame_current-1)))
  bpy.app.handlers.frame_change_pre.append(update)
  try:s.frame_set(1);bpy.ops.render.render(animation=True)
  finally:bpy.app.handlers.frame_change_pre.remove(update)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['audit','proof','film','verify']);ap.add_argument('slug',nargs='+');a=ap.parse_args()
 for slug in a.slug:run(slug,a.mode)
