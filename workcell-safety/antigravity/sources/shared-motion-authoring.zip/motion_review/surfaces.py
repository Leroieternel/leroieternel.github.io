"""Inspect opposing lower limbs, hand-to-body and arm-to-arm crossings on the dressed character."""
from common import *
import bpy
from mathutils.bvhtree import BVHTree

def mesh_groups(actor):
    source=S/'assets/people'/actor
    names=np.load(source/'skeleton.npz')['names'].tolist()
    pieces={}
    for path in sorted(source.glob('*.npz')):
        if path.stem=='skeleton' or any(k in path.name for k in ('badge','stethoscope','hardhat','earprotection')):continue
        m=dict(np.load(path))
        v=m['vertices']; f=m['faces']; labels=np.array(names)[m['ids'][np.arange(len(v)),m['weights'].argmax(1)]]
        category=np.full(len(v),'',object)
        hip_cut=float(np.load(source/'skeleton.npz')['bind'][names.index('L_Thigh'),2])-.10
        for side,sgn in [('L',1),('R',-1)]:
            leg=(sgn*v[:,0]>.005)&(v[:,2]<hip_cut)
            category[leg]=side+'leg'
            fingers=np.array([n.startswith(side+'_') and any(seg in n for seg in ('Hand','Index','Mid','Ring','Pinky','Thumb')) and 'Toe' not in n for n in labels])
            category[fingers]=side+'hand'
            arm=np.array([n.startswith(side+'_') and any(seg in n for seg in ('Forearm','ElbowShare')) for n in labels])
            category[arm]=side+'forearm'
        core=(abs(v[:,0])<.235)&(v[:,2]>=hip_cut-.005)&np.array([not n.startswith(('R_Clavicle','L_Clavicle','L_Upperarm','R_Upperarm')) for n in labels])
        torso=core&(category=='')
        category[torso]='torso'
        # Keep trouser fabric at hip height in the torso target; it should not swallow a hand.
        head=(v[:,2]>1.43)&(np.abs(v[:,0])<.14)&(category=='torso')
        category[head]='head'
        for key in np.unique(category):
            if not key:continue
            faces=f[(category[f]==key).all(1)]
            if len(faces)==0:continue
            ids,fac=np.unique(faces,return_inverse=True)
            pieces.setdefault(key,[]).append(({k:m[k][ids] for k in ('vertices','ids','weights')},fac.reshape(-1,3)))
    out={}
    for key,lst in pieces.items():
        width=max(m['ids'].shape[1] for m,_ in lst)
        verts={'vertices':np.concatenate([m['vertices'] for m,_ in lst])}
        for k in ('ids','weights'):
            verts[k]=np.concatenate([np.pad(m[k],((0,0),(0,width-m[k].shape[1]))) for m,_ in lst])
        starts=np.r_[0,np.cumsum([len(m['vertices']) for m,f in lst])[:-1]]
        out[key]=(verts,np.concatenate([f+ofs for (m,f),ofs in zip(lst,starts)]))
    return out

def pairs():
    out=[('Lleg','Rleg'),('Lhand','Rhand'),('Lforearm','Rforearm'),('Lhand','Rforearm'),('Rhand','Lforearm')]
    for side in ('L','R'):
        for seg in ('hand','forearm'):
            for target in ('torso','head','Lleg','Rleg'):
                out.append((side+seg,target))
    return out

def check(actor,trans):
    meshes=mesh_groups(actor)
    possible=[(a,b) for a,b in pairs() if a in meshes and b in meshes]
    logs={}
    for i,tf in enumerate(trans):
        verts={k:human.skin(m,tf) for k,(m,_) in meshes.items()}
        box={k:(v.min(0),v.max(0)) for k,v in verts.items()}
        trees={}
        def tree(k):
            if k not in trees:trees[k]=BVHTree.FromPolygons(verts[k],meshes[k][1],all_triangles=True)
            return trees[k]
        for a,b in possible:
            if np.any(box[a][0]>box[b][1]) or np.any(box[b][0]>box[a][1]):continue
            overlaps=tree(a).overlap(tree(b))
            if overlaps:logs.setdefault(a+'/'+b,[]).append([i,len(overlaps)])
    return {k:dict(frames=len(v),first_s=v[0][0]/25,last_s=v[-1][0]/25,peak_triangle_pairs=max(n for i,n in v),peak_frame=max(v,key=lambda pair:pair[1])[0],frame_indices=[i for i,n in v]) for k,v in logs.items()}

if __name__=='__main__':
    version=sys.argv[1]
    for slug in sys.argv[2:] or SLUGS:
        result={};cache={}
        for b in ('safe','unsafe'):
            result[b]={}
            for role,actor,yaw,path in performers(slug,b):
                if version=='before':
                    base=HERE/'baseline'/slug/path.name
                    path=base if base.exists() else HERE/'baseline'/slug/'human.npz'
                if path not in cache:cache[path]=check(actor,np.load(path)['trans'])
                result[b][role]=cache[path]
                print(slug,b,role,[(k,(v['frames'],v['peak_frame'],v['peak_triangle_pairs'])) for k,v in cache[path].items()],flush=True)
        write(HERE/'results'/version/(slug+'-self.json'),result)
