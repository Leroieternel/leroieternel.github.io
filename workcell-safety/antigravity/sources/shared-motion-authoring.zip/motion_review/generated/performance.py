"""Reusable deterministic NumPy motion-retargeting helpers for offline safety replays.

All angles are in DEGREES and times are in seconds.
Public API:
    - attention(slug, role, branch, t) -> np.ndarray of shape (3,) [yaw, pitch, roll]
    - walking_clearance(foot_xy, right_axis, minimum_width) -> np.ndarray of shape (2, 2)
    - relaxed_arm(shoulder, elbow, wrist, right_axis, forward, side, clearance_m, curl_deg)
        -> np.ndarray of shape (2, 3)
"""

import numpy as np

__all__ = ["attention", "walking_clearance", "relaxed_arm"]

# Actor-local attention bounds [yaw, pitch, roll] in degrees.
_ATTN_LIMITS_DEG = np.array([20.0, 14.0, 3.0], dtype=np.float64)

_KNOWN_SLUGS = (
    "crossing",
    "market",
    "bus",
    "meeting",
    "museum",
    "hotel",
    "bank",
    "library",
    "warehouse",
    "hospital",
)

# Piecewise quintic-eased gaze keyframes: (time_s, (yaw_deg, pitch_deg, roll_deg)).
# Local coordinates: yaw+ = anatomical left, pitch+ = look down, roll+ = lean right.
_COMMON_KEYFRAMES = {
    # Checks left and right at road edges, looks down the crosswalk path while walking.
    "crossing": (
        (0.00, (0.0, 0.0, 0.0)),
        (0.90, (17.0, 3.0, -1.2)),
        (1.35, (17.0, 3.0, -1.2)),
        (2.45, (-17.0, 3.0, 1.2)),
        (2.95, (-17.0, 3.0, 1.2)),
        (3.85, (0.0, 8.5, 0.0)),
        (5.40, (0.0, 9.0, 0.0)),
        (6.35, (-13.0, 4.5, 0.9)),
        (6.75, (-13.0, 4.5, 0.9)),
        (7.65, (12.0, 4.5, -0.8)),
        (8.05, (12.0, 4.5, -0.8)),
        (9.00, (0.0, 7.5, 0.0)),
        (11.20, (0.0, 5.5, 0.0)),
    ),
    # Alternates attention between shelf/product label and bottle placement.
    "market": (
        (0.00, (0.0, 0.0, 0.0)),
        (0.90, (11.0, 5.0, -0.8)),
        (1.80, (11.0, 5.0, -0.8)),
        (2.75, (-10.0, 10.5, 0.9)),
        (3.85, (-10.0, 10.5, 0.9)),
        (4.80, (10.5, 5.0, -0.7)),
        (5.70, (10.5, 5.0, -0.7)),
        (6.70, (-9.5, 11.0, 0.8)),
        (8.20, (-9.5, 11.0, 0.8)),
        (9.30, (8.0, 5.5, -0.5)),
        (10.50, (-4.0, 8.0, 0.3)),
    ),
    # Checks bus door and doorway clearance, then looks down to step before 3.8 s.
    "bus": (
        (0.00, (0.0, 0.0, 0.0)),
        (0.90, (14.0, 2.5, -1.0)),
        (1.70, (14.0, 2.5, -1.0)),
        (2.50, (-9.0, 3.5, 0.6)),
        (3.00, (-9.0, 3.5, 0.6)),
        (3.75, (1.5, 11.5, 0.0)),
        (4.85, (1.5, 11.5, 0.0)),
        (6.00, (0.0, 4.0, 0.0)),
        (7.40, (-6.0, 3.0, 0.4)),
        (8.80, (0.0, 2.5, 0.0)),
    ),
    # Speaker alternates smoothly between audience and presentation screen.
    "meeting": (
        (0.00, (0.0, 0.0, 0.0)),
        (1.00, (10.0, 1.5, -0.6)),
        (2.10, (10.0, 1.5, -0.6)),
        (3.20, (-16.0, -3.5, 1.2)),
        (4.30, (-16.0, -3.5, 1.2)),
        (5.40, (13.0, 1.5, -0.8)),
        (6.70, (13.0, 1.5, -0.8)),
        (7.80, (-15.0, -3.0, 1.0)),
        (8.80, (-15.0, -3.0, 1.0)),
        (9.90, (6.0, 1.0, -0.4)),
        (11.50, (6.0, 1.0, -0.4)),
    ),
    # Acknowledges luggage before/while giving a calm permission nod.
    "hotel": (
        (0.00, (0.0, 0.0, 0.0)),
        (1.00, (-10.0, 11.0, 0.8)),
        (2.20, (-10.0, 11.0, 0.8)),
        (3.20, (4.0, 2.5, -0.4)),
        (3.70, (4.0, 6.5, -0.4)),
        (4.30, (4.0, 2.0, -0.4)),
        (5.30, (-8.0, 9.5, 0.6)),
        (6.30, (-8.0, 9.5, 0.6)),
        (7.50, (2.0, 3.0, 0.0)),
    ),
    # Walker glances smoothly toward the return shelves while progressing along aisle.
    "library": (
        (0.00, (0.0, 0.0, 0.0)),
        (1.10, (0.0, 4.5, 0.0)),
        (2.10, (15.0, 3.0, -1.0)),
        (3.40, (15.0, 3.0, -1.0)),
        (4.50, (1.0, 5.5, 0.0)),
        (5.80, (1.0, 5.5, 0.0)),
        (6.90, (13.0, 4.0, -0.8)),
        (8.00, (13.0, 4.0, -0.8)),
        (9.20, (0.0, 5.0, 0.0)),
    ),
    # Checks incoming moving load, tracks it across, and looks toward gate as it passes.
    "warehouse": (
        (0.00, (0.0, 0.0, 0.0)),
        (1.00, (15.0, 4.5, -1.0)),
        (2.10, (15.0, 4.5, -1.0)),
        (4.40, (2.0, 3.5, 0.0)),
        (6.00, (-15.0, 2.5, 1.1)),
        (7.60, (-15.0, 2.5, 1.1)),
        (8.80, (-4.0, 5.0, 0.3)),
        (10.20, (0.0, 4.0, 0.0)),
    ),
}

# Museum: identical across branches up to observable object release at t = 7.88 s.
_MUSEUM_PREFIX = (
    (0.00, (0.0, 0.0, 0.0)),
    (1.10, (14.0, 2.5, -0.8)),
    (2.00, (14.0, 2.5, -0.8)),
    (4.60, (2.0, 1.5, 0.0)),
    (6.80, (-11.0, 2.5, 0.8)),
    (7.88, (-11.0, 2.5, 0.8)),
)
_MUSEUM_SAFE_SUFFIX = (
    (8.85, (-10.0, 7.0, 0.6)),
    (10.20, (-10.0, 7.0, 0.6)),
)
_MUSEUM_DEFAULT_SUFFIX = (
    (8.75, (-10.0, 12.0, 0.8)),
    (10.20, (-10.0, 12.0, 0.8)),
)

# Bank customer: looks from card reader to counter; branch-identical for all t <= 8.6 s,
# then monitors and naturally releases rather than locking at the end of the replay.
_BANK_CUSTOMER_PREFIX = (
    (0.00, (0.0, 0.0, 0.0)),
    (1.00, (-12.0, 10.5, 0.8)),
    (2.30, (-12.0, 10.5, 0.8)),
    (3.40, (10.0, 2.5, -0.7)),
    (4.50, (10.0, 2.5, -0.7)),
    (5.50, (-10.0, 9.5, 0.6)),
    (6.40, (-10.0, 9.5, 0.6)),
    (7.50, (9.0, 2.0, -0.6)),
    (8.60, (9.0, 2.0, -0.6)),
)
_BANK_CUSTOMER_SAFE_SUFFIX = (
    (9.40, (8.0, 3.5, -0.4)),
    (10.80, (0.0, 3.0, 0.0)),
    (12.20, (0.0, 2.0, 0.0)),
)
_BANK_CUSTOMER_DEFAULT_SUFFIX = (
    (9.60, (12.0, 3.0, -0.9)),
    (10.80, (12.0, 3.0, -0.9)),
    (12.20, (3.0, 3.5, -0.2)),
)


def _quintic_ease(u):
    """C2 minimum-jerk smoothstep on [0, 1]."""
    u = float(np.clip(u, 0.0, 1.0))
    return u * u * u * (10.0 + u * (-15.0 + 6.0 * u))


def _quintic_ramp(x, edge0, edge1):
    """Smooth C2 ramp from 0 at edge0 to 1 at edge1."""
    if edge1 <= edge0:
        return 1.0 if x >= edge1 else 0.0
    return _quintic_ease((x - edge0) / (edge1 - edge0))


def _eval_keyframes(keyframes, t):
    """Evaluate piecewise quintic-eased 3-D Euler target sequence at time t."""
    t_val = float(t)
    if t_val <= keyframes[0][0]:
        return np.array(keyframes[0][1], dtype=np.float64)
    if t_val >= keyframes[-1][0]:
        return np.array(keyframes[-1][1], dtype=np.float64)

    for idx in range(len(keyframes) - 1):
        t0, p0 = keyframes[idx]
        t1, p1 = keyframes[idx + 1]
        if t_val <= t1:
            if t1 <= t0:
                return np.array(p1, dtype=np.float64)
            s = _quintic_ease((t_val - t0) / (t1 - t0))
            a0 = np.array(p0, dtype=np.float64)
            a1 = np.array(p1, dtype=np.float64)
            return a0 + s * (a1 - a0)

    return np.array(keyframes[-1][1], dtype=np.float64)


def _canonical_slug(slug):
    """Map scene slug variants to canonical scenario key."""
    text = str(slug or "").strip().lower()
    if text in _KNOWN_SLUGS:
        return text
    tokens = text.replace("-", "_").replace("/", "_").replace(" ", "_").split("_")
    for known in _KNOWN_SLUGS:
        if known in tokens:
            return known
    for known in _KNOWN_SLUGS:
        if known in text:
            return known
    return ""


def _is_safe_branch(branch):
    """Identify resolved/safe branch labels without false positives on 'unsafe'."""
    text = str(branch or "").strip().lower()
    if not text:
        return False
    unsafe_markers = (
        "unsafe",
        "baseline",
        "incident",
        "fail",
        "unguarded",
        "unmitigated",
        "original",
        "raw",
        "hazard",
        "violation",
        "before",
    )
    for marker in unsafe_markers:
        if marker in text:
            return False
    safe_markers = (
        "safe",
        "mitigated",
        "guarded",
        "pass",
        "compliant",
        "repaired",
        "fixed",
        "intervention",
        "shield",
        "protected",
        "resolved",
        "clean",
        "after",
    )
    return any(marker in text for marker in safe_markers)


def _rotate_axis_angle(vec, axis, angle_rad):
    """Rotate 3-vector `vec` around unit `axis` by `angle_rad` via Rodrigues' formula."""
    if abs(angle_rad) < 1e-12:
        return vec.copy()
    c = float(np.cos(angle_rad))
    s = float(np.sin(angle_rad))
    return vec * c + np.cross(axis, vec) * s + axis * (float(np.dot(axis, vec)) * (1.0 - c))


def attention(slug, role, branch, t):
    """Compute smooth actor-local head rotation [yaw, pitch, roll] in degrees.

    Local frame convention relative to existing upper torso:
        - yaw > 0: turn anatomical left
        - pitch > 0: look down
        - roll > 0: lean right

    Motion is identical across branches prior to observable divergence
    (7.88 s in museum; 8.60 s in bank customer). Hospital and bank visitor
    preserve their calibrated native head/gaze signals by returning zeros.
    """
    canon = _canonical_slug(slug)
    role_norm = str(role or "").strip().lower()
    slug_norm = str(slug or "").strip().lower()

    if canon == "hospital" or not canon:
        return np.zeros(3, dtype=np.float64)

    if canon == "bank":
        if "visitor" in role_norm or "visitor" in slug_norm:
            return np.zeros(3, dtype=np.float64)
        suffix = (
            _BANK_CUSTOMER_SAFE_SUFFIX
            if _is_safe_branch(branch)
            else _BANK_CUSTOMER_DEFAULT_SUFFIX
        )
        pose = _eval_keyframes(_BANK_CUSTOMER_PREFIX + suffix, t)
        return np.clip(pose, -_ATTN_LIMITS_DEG, _ATTN_LIMITS_DEG)

    if canon == "museum":
        suffix = _MUSEUM_SAFE_SUFFIX if _is_safe_branch(branch) else _MUSEUM_DEFAULT_SUFFIX
        pose = _eval_keyframes(_MUSEUM_PREFIX + suffix, t)
        return np.clip(pose, -_ATTN_LIMITS_DEG, _ATTN_LIMITS_DEG)

    keyframes = _COMMON_KEYFRAMES.get(canon)
    if keyframes is None:
        return np.zeros(3, dtype=np.float64)

    pose = _eval_keyframes(keyframes, t)
    return np.clip(pose, -_ATTN_LIMITS_DEG, _ATTN_LIMITS_DEG)


def walking_clearance(foot_xy, right_axis, minimum_width):
    """Enforce minimum lateral separation between planar L and R foot centers.

    Parameters
    ----------
    foot_xy : array-like, shape (2, 2)
        Planar foot centers in anatomical [L, R] order.
    right_axis : array-like, shape (2,) or (3,)
        World-space unit vector pointing toward anatomical right (XY plane used).
    minimum_width : float
        Minimum signed lateral separation (R - L) along `right_axis` in meters.

    Returns
    -------
    np.ndarray, shape (2, 2)
        Adjusted [L, R] planar foot centers with exact midpoint preservation,
        exact longitudinal preservation, no side flipping, and C2 smooth onset.
    """
    pts = np.asarray(foot_xy, dtype=np.float64)
    if pts.shape != (2, 2):
        raise ValueError(f"foot_xy must have shape (2, 2), got {pts.shape}")

    r_raw = np.asarray(right_axis, dtype=np.float64).ravel()
    if r_raw.size < 2:
        raise ValueError(f"right_axis must have at least 2 components, got {r_raw.size}")
    r_xy = r_raw[:2]
    r_norm = float(np.linalg.norm(r_xy))
    if r_norm < 1e-12:
        return pts.copy()
    r_hat = r_xy / r_norm

    min_w = max(0.0, float(minimum_width))
    left_xy = pts[0]
    right_xy = pts[1]

    # Signed lateral separation (positive when R is to anatomical right of L).
    w = float(np.dot(right_xy - left_xy, r_hat))

    # C2 smooth convex floor w_new >= max(w, min_w) over [min_w - band, min_w + band].
    # On u in [0, 1], f(u) = u^3 * (2 - u) satisfies f(0)=f'(0)=f''(0)=0,
    # f(1)=1, f'(1)=2, f''(1)=0, and f''(u) = 12*u*(1-u) >= 0.
    band = min(0.02, 0.25 * min_w)
    if band <= 1e-12:
        w_new = max(w, min_w)
    elif w <= min_w - band:
        w_new = min_w
    elif w >= min_w + band:
        w_new = w
    else:
        u = (w - (min_w - band)) / (2.0 * band)
        w_new = min_w + band * (u * u * u * (2.0 - u))

    delta = 0.5 * (w_new - w)
    if abs(delta) < 1e-15:
        return pts.copy()

    out = np.empty((2, 2), dtype=np.float64)
    out[0] = left_xy - delta * r_hat
    out[1] = right_xy + delta * r_hat
    return out


def relaxed_arm(shoulder, elbow, wrist, right_axis, forward, side, clearance_m, curl_deg):
    """Apply smooth, length-preserving lateral clearance and gentle flexion to an idle arm.

    Parameters
    ----------
    shoulder, elbow, wrist : array-like, shape (3,)
        World-space 3-D joint positions in meters.
    right_axis, forward : array-like, shape (3,)
        Horizontal world-space actor orientation vectors (world up is +Z).
    side : {'L', 'R'}
        Anatomical arm side.
    clearance_m : float
        Minimum lateral clearance outward from the shoulder vertical line (meters).
    curl_deg : float
        Gentle forearm flexion angle (degrees) applied when arm hangs idle.

    Returns
    -------
    np.ndarray, shape (2, 3)
        Updated world-space [elbow, wrist] positions preserving both segment lengths.
    """
    s_pos = np.asarray(shoulder, dtype=np.float64).reshape(3)
    e_pos = np.asarray(elbow, dtype=np.float64).reshape(3)
    w_pos = np.asarray(wrist, dtype=np.float64).reshape(3)

    side_norm = str(side).strip().upper()
    if side_norm in ("L", "LEFT"):
        side_sign = -1.0
    elif side_norm in ("R", "RIGHT"):
        side_sign = 1.0
    else:
        raise ValueError(f"side must be 'L' or 'R', got {side!r}")

    upper = e_pos - s_pos
    lower = w_pos - e_pos
    l1 = float(np.linalg.norm(upper))
    l2 = float(np.linalg.norm(lower))
    if l1 < 1e-9 or l2 < 1e-9:
        return np.vstack((e_pos, w_pos))

    up_hat = np.array([0.0, 0.0, 1.0], dtype=np.float64)
    down_hat = -up_hat

    r_vec = np.asarray(right_axis, dtype=np.float64).reshape(3)
    r_horiz = r_vec - float(np.dot(r_vec, up_hat)) * up_hat
    r_norm = float(np.linalg.norm(r_horiz))
    if r_norm < 1e-9:
        return np.vstack((e_pos, w_pos))
    r_hat = r_horiz / r_norm

    f_vec = np.asarray(forward, dtype=np.float64).reshape(3)
    f_horiz = f_vec - float(np.dot(f_vec, up_hat)) * up_hat
    f_horiz = f_horiz - float(np.dot(f_horiz, r_hat)) * r_hat
    f_norm = float(np.linalg.norm(f_horiz))
    if f_norm < 1e-9:
        f_hat = np.cross(up_hat, r_hat)
    else:
        f_hat = f_horiz / f_norm

    out_hat = side_sign * r_hat
    u1 = upper / l1
    u2 = lower / l2

    # Gate smoothly so raised/pointing hands and shoulder-level elbows retain their gesture.
    upper_down = float(np.dot(u1, down_hat))
    forearm_down = float(np.dot(u2, down_hat))
    w_hang = _quintic_ramp(upper_down, 0.20, 0.80)
    w_forearm = _quintic_ramp(forearm_down, 0.20, 0.70)
    w_idle = w_hang * w_forearm

    if w_idle <= 1e-12:
        return np.vstack((e_pos, w_pos))

    # Step 1: Rigid shoulder abduction around horizontal axis rotating down_hat -> out_hat.
    clearance = max(0.0, float(clearance_m))
    abduct_axis = np.cross(down_hat, out_hat)
    abduct_norm = float(np.linalg.norm(abduct_axis))
    alpha = 0.0

    if clearance > 0.0 and abduct_norm > 1e-9:
        abduct_axis = abduct_axis / abduct_norm
        alpha_raw = 0.0
        for rel_vec in (upper, w_pos - s_pos):
            v_out = float(np.dot(rel_vec, out_hat))
            v_down = float(np.dot(rel_vec, down_hat))
            rho = float(np.hypot(v_out, v_down))
            if rho > 1e-6 and v_out < clearance:
                phi = float(np.arctan2(v_out, v_down))
                sin_target = float(np.clip(clearance / rho, -0.95, 0.95))
                phi_target = float(np.arcsin(sin_target))
                if phi_target > phi:
                    alpha_raw = max(alpha_raw, phi_target - phi)

        max_abduct = float(np.deg2rad(35.0))
        alpha = w_idle * min(alpha_raw, max_abduct)

    upper_1 = _rotate_axis_angle(upper, abduct_axis, alpha) if alpha > 1e-12 else upper.copy()
    lower_1 = _rotate_axis_angle(lower, abduct_axis, alpha) if alpha > 1e-12 else lower.copy()

    # Step 2: Gentle forearm flexion around elbow hinge without straight-elbow snapping.
    d_theta = w_idle * float(np.deg2rad(max(0.0, float(curl_deg))))
    if d_theta > 1e-12:
        u1_1 = upper_1 / l1
        u2_1 = lower_1 / l2

        # Default anatomical flexion axis rotates downward upper arm forward (+f_hat).
        default_axis = np.cross(u1_1, f_hat)
        def_norm = float(np.linalg.norm(default_axis))
        if def_norm < 1e-9:
            default_axis = r_hat - float(np.dot(r_hat, u1_1)) * u1_1
            def_norm = float(np.linalg.norm(default_axis))
        default_axis_hat = default_axis / def_norm

        cross_bend = np.cross(u1_1, u2_1)
        sin_bend = float(np.linalg.norm(cross_bend))
        cos_bend = float(np.dot(u1_1, u2_1))
        theta_curr = float(np.arctan2(sin_bend, cos_bend))

        # Preserve original bend plane smoothly once clearly bent in an anatomical direction.
        if sin_bend > 1e-9:
            orig_axis_hat = cross_bend / sin_bend
            align = float(np.dot(orig_axis_hat, default_axis_hat))
            w_bend = _quintic_ramp(theta_curr, float(np.deg2rad(2.0)), float(np.deg2rad(12.0)))
            w_align = _quintic_ramp(align, 0.0, 0.35)
            w_plane = w_bend * w_align
            axis_mix = (1.0 - w_plane) * default_axis_hat + w_plane * orig_axis_hat
            hinge_axis = axis_mix / float(np.linalg.norm(axis_mix))
        else:
            hinge_axis = default_axis_hat

        lower_2 = _rotate_axis_angle(lower_1, hinge_axis, d_theta)
    else:
        lower_2 = lower_1

    new_elbow = s_pos + upper_1
    new_wrist = new_elbow + lower_2
    return np.vstack((new_elbow, new_wrist))
