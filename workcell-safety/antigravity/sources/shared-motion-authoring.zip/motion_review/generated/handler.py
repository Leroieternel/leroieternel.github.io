import numpy as np

_UP = np.array([0.0, 0.0, 1.0])
_PEAK = {"L": np.array([0.090, 0.055]), "R": np.array([0.035, 0.055])}
_REST = {"L": np.array([0.055, 0.030]), "R": np.array([0.028, 0.030])}


def _smoothstep(u: float) -> float:
    u = 0.0 if u <= 0.0 else (1.0 if u >= 1.0 else u)
    return u * u * (3.0 - 2.0 * u)


def elbow_pole(right, forward, side: str) -> np.ndarray:
    if not isinstance(side, str) or side not in ("L", "R"):
        raise ValueError("side must be 'L' or 'R'")
    r = np.asarray(right, dtype=float)
    f = np.asarray(forward, dtype=float)
    if r.shape != (3,) or f.shape != (3,) or not (np.all(np.isfinite(r)) and np.all(np.isfinite(f))):
        raise ValueError("right and forward must be finite (3,) vectors")
    rn, fn = float(np.linalg.norm(r)), float(np.linalg.norm(f))
    if rn == 0.0 or fn == 0.0 or not (np.isfinite(rn) and np.isfinite(fn)):
        raise ValueError("right and forward must be non-zero finite vectors")
    sign = 1.0 if side == "R" else -1.0
    v = 0.88 * sign * (r / rn) - 0.35 * _UP + 0.22 * (f / fn)
    vn = float(np.linalg.norm(v))
    if vn == 0.0 or not np.isfinite(vn):
        raise ValueError("degenerate elbow pole direction")
    return v / vn


def clearance_after_release(elapsed: float, side: str) -> np.ndarray:
    if not isinstance(side, str) or side not in ("L", "R"):
        raise ValueError("side must be 'L' or 'R'")
    t = float(elapsed)
    if not np.isfinite(t):
        raise ValueError("elapsed must be finite")
    if t <= 0.10:
        return np.zeros(2, dtype=float)
    if t <= 0.45:
        return _smoothstep((t - 0.10) / 0.35) * _PEAK[side]
    if t >= 1.15:
        return _REST[side].copy()
    w = _smoothstep((t - 0.45) / 0.70)
    return (1.0 - w) * _PEAK[side] + w * _REST[side]
