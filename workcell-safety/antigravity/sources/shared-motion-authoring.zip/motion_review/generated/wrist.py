import numpy as np


def _normalize(q, fallback=None):
    norms = np.linalg.norm(q, axis=1, keepdims=True)
    valid = np.isfinite(norms[:, 0]) & (norms[:, 0] > 1e-12)
    safe = np.where(valid[:, None], norms, 1.0)
    fb = np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64) if fallback is None else fallback
    return np.where(valid[:, None], q / safe, fb)


def _align_signs(q):
    if len(q) < 2:
        return q.copy()
    dots = np.einsum("ij,ij->i", q[:-1], q[1:])
    flips = np.cumprod(np.where(dots < 0.0, -1.0, 1.0))
    out = q.copy()
    out[1:] *= flips[:, None]
    return out


def smooth_wrist(quaternions_xyzw, sigma_frames=2.5):
    """Smooth forearm-relative palm xyzw quaternions over a caller-sliced gesture after a common pre-cue pose."""
    q = np.asarray(quaternions_xyzw, dtype=np.float64)
    if q.ndim != 2 or q.shape[1] != 4:
        raise ValueError("quaternions_xyzw must have shape (N, 4)")
    if not np.isfinite(sigma_frames) or sigma_frames < 0.0:
        raise ValueError("sigma_frames must be finite and non-negative")
    if len(q) == 0:
        return q.copy()
    q = _align_signs(_normalize(q))
    if sigma_frames == 0.0 or len(q) == 1:
        return q
    radius = int(np.ceil(3.0 * sigma_frames))
    offsets = np.arange(-radius, radius + 1, dtype=np.float64)
    weights = np.exp(-0.5 * (offsets / sigma_frames) ** 2)
    weights /= weights.sum()
    padded = np.pad(q, ((radius, radius), (0, 0)), mode="edge")
    filtered = np.column_stack(
        [np.convolve(padded[:, i], weights, mode="valid") for i in range(4)]
    )
    return _align_signs(_normalize(filtered, fallback=q))
