"""Verify byte-for-byte delivery of the current films and reviewed evidence on the custom domain."""
from common import *
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import time
import requests

def checksum(path):
    with path.open('rb') as f:
        return sha256(f.read()).hexdigest()

def verify(resource):
    url,expected=resource
    for attempt in range(6):
        try:
            h=sha256()
            with requests.get(url,stream=True,timeout=(12,45)) as r:
                r.raise_for_status()
                for part in r.iter_content(262144):h.update(part)
            assert h.hexdigest()==expected,url
            return
        except (requests.RequestException,AssertionError):
            if attempt==5:raise
            time.sleep(3)

if __name__=='__main__':
    release=read(S/'deployment.json');pin=release['films'];rev=release['site']
    prefix='https://mcxiangalds.com/workcell-safety/'
    for i in range(100):
        try:
            r=requests.get(prefix+'antigravity/catalog.json',params={'v':rev[:16],'check':i},timeout=15)
            r.raise_for_status();entries={e['id']:e for e in r.json()}
            g=requests.get(prefix+'everyday-catalog.js',params={'v':rev[:16],'check':i},timeout=15)
            g.raise_for_status()
            if pin in g.text and all(entries['shared_'+s].get('motionReview') and pin in entries['shared_'+s]['film'] for s in SLUGS):
                break
        except (requests.RequestException,ValueError,KeyError):pass
        if i%8==0:print('Waiting for the new catalog on the public domain',flush=True)
        time.sleep(6)
    else:raise TimeoutError('Public catalog still serves an earlier release')
    movies=[];evidence=[]
    for slug in SLUGS:
        entry=entries['shared_'+slug]
        for b in (('unsafe','safe','event') if slug in ('bank','hospital') else ('unsafe','safe')):
            movies.append((entry['film']+'/'+b+'.mp4',checksum(stage(slug)/'media'/slug/(b+'.mp4'))))
        for name in ('human-motion.json','motion-comparison.jpg','physics-audit.json','video-verification.json','metric.png','force.png'):
            evidence.append((prefix+'antigravity/'+entry['id']+'/'+name+'?v='+rev[:16],checksum(S/'release'/entry['id']/name)))
    for name in ('shared-motion-review.html','shared-motion-authoring.zip','shared-spaces-validation.json'):
        evidence.append((prefix+'antigravity/sources/'+name+'?v='+rev[:16],checksum(S/'release/sources'/name)))
    with ThreadPoolExecutor(max_workers=4) as workers:
        list(workers.map(verify,movies));list(workers.map(verify,evidence))
    write(HERE/'results/publication.json',dict(website_commit=rev,film_commit=pin,verified_movies=len(movies),verified_evidence_files=len(evidence)))
    print('Public delivery verified for',len(movies),'movies and',len(evidence),'evidence files.',flush=True)
