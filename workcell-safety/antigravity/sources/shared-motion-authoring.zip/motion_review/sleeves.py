"""Fit the least shoulder abduction which clears each character's actual shirt, coat and trousers."""
from surfaces import mesh_groups, BVHTree
from common import *

def rotation(axis,angle):
    x,y,z=axis
    K=np.array([[0,-z,y],[z,0,-x],[-y,x,0.]])
    theta=np.deg2rad(angle)
    return np.eye(3)+np.sin(theta)*K+(1-np.cos(theta))*(K@K)

def candidate_axis(right, forward,side):
    away=(1 if side=='R' else -1)*right
    return human.unit(np.cross([0,0,-1],away+.15*forward))

def angles(actor, yaw, path):
    a=np.load(path);names=a['names'].tolist(); joints=a['joints'];trans=a['trans'];mesh=mesh_groups(actor)
    result=np.zeros((len(T),2))
    heading=np.deg2rad(yaw);front=np.array([np.sin(heading),-np.cos(heading),0.]);right=np.cross(front,[0,0,1])
    targets=('torso','head','Lleg','Rleg')
    for i,tf in enumerate(trans):
        coords={k:human.skin(m,tf) for k,(m,_) in mesh.items()};surfaces={}
        bounds={k:(v.min(0),v.max(0)) for k,v in coords.items()}
        for n,side in enumerate(('L','R')):
            sh=joints[i,names.index(side+'_Upperarm')]
            axis=candidate_axis(right,front,side)
            for degree in np.arange(0.,38.,1.5):
                test=rotation(axis,degree)
                overlap=False
                for seg in [side+'hand',side+'forearm']:
                    v=(coords[seg]-sh)@test.T+sh
                    lo=v.min(0);hi=v.max(0);bv=None
                    for other in targets:
                        b=bounds[other]
                        if (hi+.001<b[0]).any() or (lo-.001>b[1]).any():continue
                        if bv is None:bv=BVHTree.FromPolygons(v,mesh[seg][1],all_triangles=True,epsilon=.001)
                        if other not in surfaces:surfaces[other]=BVHTree.FromPolygons(coords[other],mesh[other][1],all_triangles=True,epsilon=.001)
                        if bv.overlap(surfaces[other]):overlap=True;break
                    if overlap:break
                if not overlap:break
            else:raise ValueError(('shoulder clearance',actor,i,side))
            result[i,n]=degree
    # Round the onset over 0.5 s and hold a small clearance envelope around the required angle.
    # A weighted maximum keeps the smoothed trajectory on the feasible side of each sample.
    original=result.copy()
    for i in range(len(T)):
        d=(np.arange(len(T))-i)/5.
        result[i]=np.max((original+.6*(original>0))*np.exp(-.5*d*d)[:,None],axis=0)
    return result

if __name__=='__main__':
    for slug in sys.argv[1:] or [s for s in SLUGS if s!='hospital']:
        cache={}
        for b in ('safe','unsafe'):
            for role,actor,yaw,path in performers(slug,b):
                if path not in cache:cache[path]=angles(actor,yaw,path)
                values=cache[path];write(HERE/'results/fit'/slug/(b+'-'+role+'.json'),values.round(5).tolist())
                print(slug,b,role,'extra degrees',values.max(0).round(2),flush=True)
