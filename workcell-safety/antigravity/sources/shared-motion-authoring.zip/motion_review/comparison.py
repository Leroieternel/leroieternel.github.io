"""Make matched, actor-centred stills from both generations of the encoded films."""
from common import HERE, S, ROOT, SLUGS, performers, read, stage
from film_review import crop_actor, shot
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from pathlib import Path
import hashlib
import subprocess
import sys
import tempfile
import imageio_ffmpeg
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FRAMES = {
    'crossing': (90, 200), 'bus': (153, 191), 'library': (49, 179),
    'hospital': (106, 161), 'market': (89, 111), 'museum': (75, 276),
    'meeting': (36, 89), 'hotel': (147, 211), 'bank': (241, 295),
    'warehouse': (30, 135)
}
def capture(movie, index):
    args=[imageio_ffmpeg.get_ffmpeg_exe(),'-loglevel','error','-threads','1','-ss',
          f'{index / 25:.3f}','-i',str(movie),'-frames:v','1','-threads','1',
          '-f','image2pipe','-c:v','png','-']
    return Image.open(BytesIO(subprocess.check_output(args))).convert('RGB')

def sheet(slug):
    originals=read(HERE/'results/before/film-origins.json')
    checksum=read(HERE/'results/before'/(slug+'-video.json'))['unsafe']['sha256']
    current=stage(slug)/'media'/slug/'unsafe.mp4'
    assert hashlib.sha256(current.read_bytes()).hexdigest()==read(HERE/'results/after'/(slug+'-video.json'))['unsafe']['sha256']
    role,actor,yaw,path=performers(slug,'unsafe')[0]
    pose=HERE/'baseline'/slug/path.name
    if not pose.exists():pose=pose.with_name('human.npz')
    with np.load(pose) as p:
        js=p['joints']; names=p['names'].tolist()
    canvas=Image.new('RGB',(936,644),'#172629')
    draw=ImageDraw.Draw(canvas)
    face='/usr/share/fonts/truetype/dejavu/DejaVuSans'
    def font(size,bold=False):return ImageFont.truetype(face+('-Bold' if bold else '')+'.ttf',size)
    draw.text((22,15),'Earlier replay',font=font(21,True),fill='#edf0e9')
    draw.text((482,15),'Updated replay',font=font(21,True),fill='#bef1d8')
    with tempfile.TemporaryDirectory(prefix='shared-previous-film-') as tmp:
        old=Path(tmp)/'previous.mp4'
        with old.open('wb') as out:
            subprocess.run(['git','-C',str(ROOT/'.runtime/mobile-mission-films'),'show',
                originals[slug]+':media/antigravity/shared_'+slug+'/unsafe.mp4'],check=True,stdout=out)
        assert hashlib.sha256(old.read_bytes()).hexdigest()==checksum
        for row,i in enumerate(FRAMES[slug]):
            cam=shot(slug,i)
            assert cam is not None
            for col,movie in enumerate((old,current)):
                im=crop_actor(capture(movie,i),cam,js[i],names)
                im.thumbnail((446,258), Image.Resampling.LANCZOS)
                x=15+col*460; y=52+row*291
                canvas.paste(im,(x+(446-im.width)//2,y+(258-im.height)//2))
                draw.text((x+8,y+259),f'{i/25:.2f} s',font=font(17),fill='#cfdbd5')
    out=S/'release'/('shared_'+slug)/'motion-comparison.jpg'
    canvas.save(out, quality=91, optimize=True)
    return slug

if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:
        for name in pool.map(sheet,sys.argv[1:] or SLUGS):print('Matched frames',name,flush=True)
