"""Check complete pose records independently of the retargeter and film captions."""
from common import *
from scipy.spatial.transform import Rotation
import shutil, hashlib

def round_float(v):
    return round(float(v),4)

def measure(actor,yaw,path):
    a=np.load(path);j=a['joints'].astype(float);tf=a['trans'];rot=tf[:,:,:,:3];names=a['names'].tolist();ix=names.index
    assert j.shape[0]==len(T) and np.isfinite(j).all() and np.isfinite(rot).all()
    yaw=np.deg2rad(yaw);forward=np.array([np.sin(yaw),-np.cos(yaw),0.]);right=np.cross(forward,[0,0,1])
    hip=j[:,ix('Hip')];head=j[:,ix('Head')];torso=j[:,ix('NeckTwist01')]-hip
    kneeflex={};elbows={};length_err=0.
    for side in ('L','R'):
        for kind,chain in [('knee',('Thigh','Calf','Foot')),('elbow',('Upperarm','Forearm','Hand'))]:
            top,mid,end=[j[:,ix(side+'_'+k)] for k in chain]
            upper,lower=mid-top,end-mid;axis=human.unit(end-top)
            flex=np.degrees(np.arctan2(np.linalg.norm(np.cross(upper,lower),axis=1),np.sum(upper*lower,axis=1)))
            for segment in (upper,lower):length_err=max(length_err,np.ptp(np.linalg.norm(segment,axis=1)))
            if kind=='knee':
                pole=upper-axis*np.sum(upper*axis,axis=1)[:,None]
                flex*=np.sign(pole@forward)
                kneeflex[side]=dict(min_deg=round_float(flex.min()),max_deg=round_float(flex.max()),end_deg=round_float(flex[-1]),
                                    backward_frames=int(np.sum(flex<-.5)),max_step_deg=round_float(abs(np.diff(flex)).max()))
            else:elbows[side]=dict(min_deg=round_float(flex.min()),max_deg=round_float(flex.max()),max_step_deg=round_float(abs(np.diff(flex)).max()))
    # Use displacement of all major joints relative to the pelvis; a translating rigid figure is still detected.
    body=j[:,[ix(k) for k in ['Head','Spine02','L_Hand','R_Hand','L_Forearm','R_Forearm','L_Calf','R_Calf','L_Foot','R_Foot']]]-hip[:,None]
    sp=np.linalg.norm(np.diff(body,axis=0),axis=2).max(1)
    threshold=.00025; slow=sp<threshold
    changes=np.diff(np.r_[False,slow,False].astype(int))
    freezes=[[round(t/25,2),round(z/25,2)] for t,z in zip(np.flatnonzero(changes==1),np.flatnonzero(changes==-1)) if (z-t)>=25]
    chest=rot[:,ix('Spine02')];neck=rot[:,ix('Head')]
    rel=chest.transpose(0,2,1)@neck
    relspan=Rotation.from_matrix(rel[0].T@rel).magnitude()*180/np.pi
    # Check the foot touching the ground. Heel-to-toe rocking may move the contact patch to a different vertex.
    folder=S/'assets/people'/actor
    shoe=dict(np.load(next(x for x in folder.glob('*.npz') if any(tag in x.name for tag in ('boots','shoes','sneakers')))))
    vs=np.array([human.skin(shoe,tt) for tt in tf]);split=shoe['vertices'][:,0]>0
    soles=np.column_stack([vs[:,mask,2].min(1) for mask in (split,~split)])
    # For each pair of frames, test material vertices which are within 2 mm of the floor in both.
    near=(vs[:,:,2]<.0028);persistent=near[1:]&near[:-1]
    disp=np.linalg.norm(np.diff(vs[:,:,:2],axis=0),axis=2);disp[~persistent]=np.inf
    slip=disp.min(1);valid=np.isfinite(slip)
    wrist_rates={}
    for side in ('L','R'):
        parent=rot[:,ix(side+'_Forearm')];hand=rot[:,ix(side+'_Hand')]
        relative=parent.transpose(0,2,1)@hand
        rate=np.rad2deg(Rotation.from_matrix(relative[:-1].transpose(0,2,1)@relative[1:]).magnitude())
        wrist_rates[side]=round_float(rate.max())
    return dict(poses=len(T),hip_height_range_m=[round_float(hip[:,2].min()),round_float(hip[:,2].max())],
        min_head_m=round_float(head[:,2].min()),max_trunk_lean_deg=round_float(np.degrees(np.arccos(np.clip(human.unit(torso)[:,2],-1,1))).max()),
        one_frame_max_hip_drop_mm=round_float(1000*max(0,-np.diff(hip[:,2]).min())),max_two_tenths_hip_drop_m=round_float(max(0,-(hip[5:,2]-hip[:-5,2]).min())),
        knees=kneeflex,elbows=elbows,wrist_max_relative_rotation_per_frame_deg=wrist_rates,ankle_width_min_mm=round_float(1000*((j[:,ix('R_Foot')]-j[:,ix('L_Foot')])@right).min()),
        longest_freezes_1s=freezes,head_turn_relative_to_chest_deg=round_float(relspan.max()),end_wrist_motion_cm=[round_float(100*np.linalg.norm(np.ptp(body[-75:,v],axis=0))) for v in [2,3]],
        shoe_floor_min_mm=round_float(1000*soles.min()),worst_lower_sole_mm=round_float(1000*soles.min(1).max()),both_soles_above_5mm_frames=int(np.sum(soles.min(1)>.005)),
        successive_floor_samples=int(valid.sum()),worst_best_ground_vertex_drift_per_frame_mm=round_float(1000*slip[valid].max()) if valid.any() else None,
        bone_length_range_mm=round_float(1000*length_err),trajectory_sha256=hashlib.sha256(path.read_bytes()).hexdigest())

if __name__=='__main__':
    version=sys.argv[1]
    for slug in sys.argv[2:] or SLUGS:
        res={};cache={}
        for b in ('safe','unsafe'):
            res[b]={}
            for role,actor,yaw,path in performers(slug,b):
                if version=='before' and (HERE/'baseline'/slug).exists():
                    prior=HERE/'baseline'/slug/path.name
                    if not prior.exists():prior=prior.with_name('human.npz')
                    if prior.exists():path=prior
                if path not in cache:cache[path]=measure(actor,yaw,path)
                res[b][role]=cache[path]
                if version=='before':
                    store=HERE/'baseline'/slug/path.name;store.parent.mkdir(exist_ok=True,parents=True)
                    if not store.exists():shutil.copy2(path,store)
                z=res[b][role]
                print(slug,b,role,'neck',z['head_turn_relative_to_chest_deg'],'freeze',z['longest_freezes_1s'],'slip',z['worst_best_ground_vertex_drift_per_frame_mm'],'ankle',z['ankle_width_min_mm'],'lean',z['max_trunk_lean_deg'],flush=True)
        write(HERE/'results'/version/(slug+'-pose.json'),res)
