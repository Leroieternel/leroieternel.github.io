from pathlib import Path
import sys
d=Path(__file__).resolve().parent
sys.path.insert(0,str(d.parents[1]/'hard1044'))
import author
author.HERE=d
if __name__=='__main__':author.request(sys.argv[1] if len(sys.argv)>1 else 'performance', mode='auto')
