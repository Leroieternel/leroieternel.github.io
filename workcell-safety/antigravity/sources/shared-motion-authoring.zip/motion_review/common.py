"""Paths, animation bindings and source selections for the ten currently published pairs."""
import json
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
S=HERE.parent
C=S/'consequences'
ROOT=S.parents[2]
sys.path.insert(0,str(S))
import human
T=human.T

def read(p):
    return json.loads(p.read_text())

def write(p,data):
    p.parent.mkdir(exist_ok=True,parents=True)
    p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

def performers(slug,branch):
    actor,_,yaw,_,_=human.CAST[slug]
    if slug=='bank':
        return [('customer',actor,yaw,C/'runs/bank'/(branch+'-person.npz')),('visitor','doctor',-164,C/'runs/bank/visitor.npz')]
    if slug=='hospital':
        return [('clinician',actor,yaw,C/'runs/hospital'/(branch+'-person.npz'))]
    branch_path=S/'runs'/slug/(branch+'-person.npz')
    return [('primary',actor,yaw,branch_path if branch_path.exists() else S/'runs'/slug/'human.npz')]

def stage(slug):
    return C if slug in ('bank','hospital') else S

SLUGS=[r['slug'] for r in read(S/'selection.json')]
