"""Decode every frame of the shipped films; make pose sheets from actual video pixels."""
from common import *
from PIL import Image,ImageDraw,ImageFont,ImageOps
import ast,hashlib,subprocess,tempfile
import imageio_ffmpeg as ff
from concurrent.futures import ThreadPoolExecutor

constants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse((S/'render.py').read_text()).body
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('WIDE','DETAIL')}
def shot(slug,i):
    t=i/25
    if slug=='bank':
        if 7.62<=t<9.08 or 10.45<=t<11.25:return None
        if 1.98<=t<4.32:return ((.73,-.53,1.47),(.295,-.37,.955),42)
        if t>=9.08:return ((-1.86,-3.18,1.75),(.53,-.06,1.04),42)
        return ((-2.15,-3.68,2.07),(.52,-.13,1.05),40)
    if slug=='hospital':
        if t<2.36:return ((4.50,-3.85,2.77),(-.32,-1.62,.77),29)
        if t<5.32:return ((-2.53,-3.87,2.29),(.12,-.28,.75),30)
        return ((4.27,-3.53,2.11),(.40,.50,.73),32)
    if slug=='museum' and i>=240:return ((2.90,-3.73,1.92),(.42,-.34,.62),32)
    cuts={'market':(117,265),'museum':(117,265),'hotel':(126,203),'warehouse':(140,208)}
    if slug in cuts and cuts[slug][0]<=i<=cuts[slug][1]:return constants['DETAIL'][slug]
    return constants['WIDE'][slug]

def crop_actor(im,cam,j,n):
    if cam is None:return im
    eye,aim,mm=cam;eye=np.array(eye);f=human.unit(np.asarray(aim)-eye);right=human.unit(np.cross(f,[0,0,1]));up=np.cross(right,f)
    points=j[[n.index(k) for k in ('Head','L_Hand','R_Hand','L_Foot','R_Foot','Hip','L_Calf','R_Calf')]].copy()
    points[0,2]+=.19;points[3:5,2]-=.12
    pts=points-eye;w,h=im.size
    if (pts@f).min()<=0:return im
    xy=np.column_stack((w*.5+w*mm/36*(pts@right)/(pts@f),h*.5-w*mm/36*(pts@up)/(pts@f)))
    lo=xy.min(0)-[16,10];hi=xy.max(0)+[16,6]
    if np.any(hi<0) or lo[0]>w or lo[1]>h:return im
    center=(lo+hi)/2;hs=max((hi-lo)[1],(hi-lo)[0]*1.18)
    ww=hs*.85
    return im.crop((int(center[0]-ww/2),int(center[1]-hs/2),int(center[0]+ww/2),int(center[1]+hs/2)))

def review(slug,version,expected,scratch):
    destination=HERE/'results'/version;destination.mkdir(exist_ok=True,parents=True)
    both=[];metrics={}
    samples=(4,47,80,107,152,195,232,283)
    for b in ('unsafe','safe'):
        path=stage(slug)/'media'/slug/(b+'.mp4')
        if expected:
            spec=expected[slug]+':media/antigravity/shared_'+slug+'/'+b+'.mp4'
            path=scratch/(slug+'-'+b+'.mp4')
            with path.open('wb') as out:
                subprocess.run(['git','-C',str(ROOT/'.runtime/mobile-mission-films'),'show',spec],stdout=out,check=True)
        filehash=hashlib.sha256(path.read_bytes()).hexdigest()
        casts=[]
        for role,actor,yaw,p in performers(slug,b):
            if expected:
                old=HERE/'baseline'/slug/p.name
                if not old.exists():old=old.with_name('human.npz')
                if old.exists():p=old
            with np.load(p) as pose:casts.append((pose['joints'],pose['names'].tolist()))
        reader=ff.read_frames(str(path),input_params=['-threads','1'],output_params=['-threads','1','-vf','scale=960:540'])
        meta=next(reader);assert meta['source_size']==(1920,1080) and meta['fps']==25
        row=[];count=0
        for i,raw in enumerate(reader):
            count+=1
            if i not in samples:continue
            im=Image.frombytes('RGB',(960,540),raw)
            role=1 if slug=='bank' and i in (47,152) else 0
            j,n=casts[role];crop=crop_actor(im,shot(slug,i),j[i],n)
            crop.thumbnail((166,176));row.append(crop)
        reader.close();assert count==300
        metrics[b]=dict(frames=count,sha256=filehash,resolution=[1920,1080],fps=25)
        both.append(row)
    sheet=Image.new('RGB',(8*170+12,432),'#203133');draw=ImageDraw.Draw(sheet)
    for row,images in enumerate(both):
        y=7+row*212;draw.text((7,y),slug+'   /   '+('unsafe' if row==0 else 'safe'),fill='white')
        for k,image in enumerate(images):
            x=6+170*k;sheet.paste(image,(x,y+16));draw.text((x,y+192),'%.2f s'%(samples[k]/25),fill='#cfe3d9')
    sheet.save(destination/(slug+'-film.jpg'),quality=89)
    write(destination/(slug+'-video.json'),metrics);print(slug,version,'600 frames decoded',flush=True)

if __name__=='__main__':
    version=sys.argv[1]
    expected=None
    if version=='before':
        origins=HERE/'results/before/film-origins.json'
        if not origins.exists():
            records=read(ROOT/'.runtime/website/workcell-safety/antigravity/catalog.json')
            write(origins,{d['id'][7:]:d['film'].split('/media/')[0].rsplit('/',1)[1] for d in records if d['id'].startswith('shared_')})
        expected=read(origins)
    with tempfile.TemporaryDirectory(prefix='shared-motion-films-') as scratch,ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(lambda slug:review(slug,version,expected,Path(scratch)),sys.argv[2:] or SLUGS))
