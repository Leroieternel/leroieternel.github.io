"""Check actual event timing, true human-solver alignment and causal consistency of the published animation."""
from common import *
import hashlib
import gzip
from scipy.spatial.transform import Rotation

def cue_report(slug):
    location=stage(slug)/'runs'/slug
    summaries={b:read(location/(b+'.json')) for b in ('safe','unsafe')}
    old=HERE/'baseline/hospital'
    result={}
    for branch in ('safe','unsafe'):
        records=np.load(location/(branch+'.npz'))
        a=np.load(performers(slug,branch)[0][3]);j=a['joints'];n=a['names'].tolist()
        if slug=='hospital':
            raw=np.load(location/(branch+'-metrics.npz'))
            ref=np.load(old/(branch+'-metrics.npz'));s=summaries[branch]
            force_keys=['left_palm_grip_N','right_palm_grip_N','bumper_litter_N','saddle_support_N','litter_floor_N','litter_tilt_deg']
            differences={k:float(np.max(abs(raw[k]-ref[k]))) for k in force_keys}
            assert max(differences.values())<1e-7
            if branch=='unsafe':
                assert min(s['at_robot_contact_palm_normal_N'])>0.1 and s['first_contact_s']<s['release_command_s']<=s['hands_clear_s']<s['first_floor_contact_s']
                assert raw['litter_floor_N'].max()>0
            else:assert s['peak_contact_N']==0 and s['first_floor_contact_s'] is None
            result[branch]=dict(contact=s['first_contact_s'],release=s['release_command_s'],hands_clear=s['hands_clear_s'],first_deck_floor_contact=s['first_floor_contact_s'],
                                max_difference_from_previous_recorded_force_or_deck_tilt=differences,
                                human_role='Kinematic walking clinician. MuJoCo solves both hand pads against the handle and the equipment contacts.')
        else:
            import mujoco as mj
            m=mj.MjModel.from_xml_path(str(location/'scene.xml'));coords=records['mocap_pos'];err=0.
            mapping={'torso':('Waist','NeckTwist01'),'head':('NeckTwist02','Head')}
            for side in 'LR':
                for key,u,v in [('upperarm','Upperarm','Forearm'),('forearm','Forearm','Hand'),('thigh','Thigh','Calf'),('shin','Calf','Foot')]:
                    mapping[side+'_'+key]=(side+'_'+u,side+'_'+v)
            for name,(u,v) in mapping.items():
                point=j[:,n.index(v)]+[0,0,.074] if name=='head' else (j[:,n.index(u)]+j[:,n.index(v)])*.5
                err=max(err,float(abs(coords[:,m.body('person_'+name).mocapid[0]]-point).max()))
            assert err<2e-6,(slug,branch,err)
            result[branch]=dict(max_difference_solver_proxy_vs_rendered_joints_m=err,solver_warnings=summaries[branch]['solver_warnings'])
            if slug=='bank':
                s=summaries[branch]
                result[branch].update(card_exposure_s=s['exposure_s'],hold=s['hold_s'],card_visible=s['first_visible_s'])
            else:
                s=summaries[branch];result[branch].update(first_recorded_rule_event_s=s['first_event_s'],
                      named_equipment_force_peak_N=s['force_peak_N'],minimum_robot_human_proxy_gap_m=s['proxy_gap_m'])
                assert s['unsafe_event']==(branch=='unsafe') and s['proxy_gap_m']>0
        assert summaries[branch]['solver_warnings']==0
    first=np.load(performers(slug,'safe')[0][3]);second=np.load(performers(slug,'unsafe')[0][3])
    delta=abs(first['trans']-second['trans']).max(axis=(1,2,3));changes=np.flatnonzero(delta>1e-5)
    diverges=float(T[changes[0]]) if len(changes) else None
    if slug=='hospital':cue=summaries['unsafe']['first_contact_s'];human='Measured guard-to-deck contact, then loaded-hand release and a backward step.'
    elif slug=='bank':cue=summaries['unsafe']['hold_s'];human='The privacy screen is put on hold following visible card exposure. The customer then raises and lowers one hand.'
    elif slug=='museum':cue=7.88;human='Both gaze tracks follow the same lift. They diverge after the release over the plinth or its outer edge.'
    else:cue=None;human='Both plans replay the same person trajectory.'
    assert (cue is None and diverges is None) or (cue is not None and diverges is not None and diverges>=cue-.000001),(slug,cue,diverges)
    return dict(study=slug,branches=result,first_different_person_sample_s=diverges,observable_cue_s=cue,action=human)

if __name__=='__main__':
    for slug in sys.argv[1:] or SLUGS:
        report=cue_report(slug);write(HERE/'results/after'/(slug+'-cues.json'),report);print(slug,'cues and physics OK',flush=True)
