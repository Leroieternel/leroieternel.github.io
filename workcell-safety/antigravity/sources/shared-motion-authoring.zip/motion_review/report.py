"""Record measured performer changes and reconnect them to the existing public task pages."""
from common import *
from html import escape
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil

BRANCHES=('safe','unsafe')
def earlier(slug, kind):return read(HERE/'results/before'/(slug+'-'+kind+'.json'))
def revised(slug, kind):return read(HERE/'results/after'/(slug+'-'+kind+'.json'))
def digest(p):return sha256(p.read_bytes()).hexdigest()
def first(d):return next(iter(d.values()))

NOTES={
 'crossing': 'The pedestrian follows two separate foot tracks, checks the crossing and then looks along the zebra markings.',
 'market': 'The vendor turns between the label and the drinks display. The free hand clears the work clothes throughout the pointing gesture.',
 'bus': 'The commuter looks toward the door before stepping forward. The walking shoes clear one another through the change from standing to walking.',
 'hospital': 'The clinician walks with both hands on the handle. During the unsafe run, the robot strikes the stretcher deck. The clinician releases the loaded handle, takes three recovery steps and stays upright.',
 'meeting': 'The speaker shifts attention between the screen and the audience. The raised wrist turns smoothly during the gesture and the resting forearm clears the jacket.',
 'museum': 'The conservator follows the lift with their eyes and head. After the replica is released, the unsafe gaze follows its descent and the safe gaze remains on the plinth.',
 'hotel': 'The guest looks toward the suitcase and raises a hand to give permission. The wrist eases into and out of the signal.',
 'bank': 'The visitor keeps sight of the counter. After the unsafe return exposes the card and the transaction goes on hold, the customer raises one hand, then lowers it and settles. The safe handoff proceeds normally.',
 'library': 'The reader glances toward the shelves while walking. The planted shoe holds its contact point and the other shoe swings clear.',
 'warehouse': 'The worker stays beside the gate and tracks the load with their head and upper body. Relaxed forearms clear the work clothes.'
}
def update_sources():
    for slug in SLUGS:
        if slug in ('bank','hospital'):continue
        d=S/'runs'/slug; path=d/'human.json'; record=read(path)
        if slug=='museum':shutil.copy2(d/'safe-person.npz',d/'human.npz')
        pose=revised(slug,'pose')
        record.pop('max_support_anchor_slip_mm',None)
        record.update(minimum_shoe_floor_gap_mm=min(first(pose[b])['shoe_floor_min_mm'] for b in BRANCHES),
                      maximum_ground_point_drift_per_40ms_mm=max(first(pose[b])['worst_best_ground_vertex_drift_per_frame_mm'] for b in BRANCHES),
                      movement=NOTES[slug],source='NVIDIA Isaac People native animation and skinning with Google Antigravity motion refinements.',
                      branch_pose_sha256={b:first(pose[b])['trajectory_sha256'] for b in BRANCHES})
        write(path,record)
    p=C/'runs/bank';safe=np.load(p/'safe-person.npz');unsafe=np.load(p/'unsafe-person.npz')
    wrist=unsafe['names'].tolist().index('R_Hand')
    difference=unsafe['joints'][:,wrist,2]-safe['joints'][:,wrist,2]
    cue=revised('bank','cues')
    entry=read(p/'performance.json')
    entry.update(footage=NOTES['bank'],privacy_hold_s=cue['observable_cue_s'],
        first_changed_pose_s=cue['first_different_person_sample_s'],
        maximum_extra_wrist_rise_m=float(difference.max()),peak_wrist_rise_s=float(T[difference.argmax()]),
        final_extra_wrist_rise_m=float(difference[-1]),
        same_pre_event_samples=int(np.sum(T<cue['first_different_person_sample_s'])))
    write(p/'performance.json',entry)

def authoring():
    roles={}
    for module in ('performance','handler','wrist'):
        record=read(HERE/'provenance'/(module+'.json'))
        assert digest(HERE/'generated'/(module+'.py'))==record['sha256']
        assert digest(HERE/'requests'/(module+'.txt'))==record['prompt_sha256']
        roles[module]=record
    return roles

def write_case(slug,authors):
    ident='shared_'+slug; folder=S/'release'/ident
    epath=S/'entries'/(ident+'.json');entry=read(epath)
    evidence={};counts={};poses=0
    for name,loader in [('before',earlier),('after',revised)]:
        pose,overlap,video=(loader(slug,k) for k in ('pose','self','video'))
        evidence[name]={}
        for branch in BRANCHES:
            people={}
            for role,actor in pose[branch].items():
                intersections={k:{kk:vv for kk,vv in vals.items() if kk!='frame_indices'} for k,vals in overlap[branch][role].items()}
                people[role]=dict(poses=actor,surface_intersections=intersections)
                if name=='after':
                    assert actor['poses']==301 and not intersections and actor['both_soles_above_5mm_frames']==0
                    assert max(c['backward_frames'] for c in actor['knees'].values())==0
                    assert not actor['longest_freezes_1s'] and actor['bone_length_range_mm']<.01
                    assert actor['min_head_m']>1.3 and actor['hip_height_range_m'][0]>.8
                    poses+=actor['poses']
            if name=='after':
                f=stage(slug)/'media'/slug/(branch+'.mp4')
                assert video[branch]['frames']==300 and video[branch]['sha256']==digest(f)
            evidence[name][branch]=dict(people=people,film=video[branch])
    cue=revised(slug,'cues'); mesh=read(folder/'mesh-check.json')
    for branch in BRANCHES:
        outside=mesh['branches'][branch]['person_scene'] if 'branches' in mesh else mesh['people_intersections'][branch]
        assert not outside
    audit=dict(task=entry['title'],id=ident,person_action=NOTES[slug],actor_samples=poses,
        skin_sample_rate_Hz=25,solver_rate_Hz=1000,measured_event=cue,versions=evidence,
        scope='The tests sample dressed meshes at every replay pose including the endpoint. They check opposing legs and shoes, hands and forearms against the opposite arm, legs, head and trunk, and the person against the scene. Adjacent skin seams are excluded. A freeze is at least one second with all sampled major joints moving less than 0.25 mm per 40 ms relative to the pelvis. Floor drift uses the least-moving sole point within 2.8 mm of the floor in both neighboring poses. These checks cover the sampled poses of a kinematic animation.',
        authors=authors)
    write(folder/'human-motion.json',audit)
    assert (folder/'motion-comparison.jpg').is_file()
    prod=read(folder/'production.json')
    active={b:{role:pose['poses']['trajectory_sha256'] for role,pose in evidence['after'][b]['people'].items()} for b in BRANCHES}
    prod.update(motion_review=dict(credit='Google Antigravity authored the corrective motions. Codex fitted them to the dressed bodies and checked the MuJoCo recordings and final films.',authoring=authors,documentation='human-motion.json',actors_sha256=active))
    phys=read(folder/'physics-audit.json')
    if slug=='museum':
        prod.pop('common_person_trajectory_sha256',None);phys.pop('human_motion_sha256',None)
        phys['scope']=phys['scope'].replace('a shared skinned animation','a skinned animation shared until the replica is released')
        entry['scope']=phys['scope']
    phys['reviewed_human_trajectory_sha256']=active
    write(folder/'production.json',prod);write(folder/'physics-audit.json',phys)
    entry.update(motionReview=True,assetRevision='shared-human-motion-v5')
    if entry.get('eventReplay'):entry['eventReplay']['poster']='event_poster.jpg?v=human-motion-v5'
    write(epath,entry)
    if slug in ('bank','hospital'):
        for name in ('human-motion.json','motion-comparison.jpg','production.json','physics-audit.json'):
            shutil.copy2(folder/name,C/'release'/ident/name)
        write(C/'entries'/epath.name,entry)
    return audit

def observation(slug,a):
    v=a['versions']
    old=first(v['before']['unsafe']['people']);new=first(v['after']['unsafe']['people'])
    if slug in ('crossing','bus','library'):
        n=old['surface_intersections']['Lleg/Rleg']['frames']
        return f'Opposite trouser legs or shoes intersected in {n} of 301 poses in each take. The updated takes have zero such intersections.'
    if slug=='hospital':
        oldd=first(v['before']['safe']['people'])['poses']['worst_best_ground_vertex_drift_per_frame_mm']
        newd=first(v['after']['safe']['people'])['poses']['worst_best_ground_vertex_drift_per_frame_mm']
        return f'The largest measured shift of a supporting sole point in the safe walk fell from {oldd:.1f} to {newd:.2f} mm per frame. The unsafe deck strikes the floor at 3.716 s.'
    if slug=='bank':
        start,end=old['poses']['longest_freezes_1s'][-1]
        return f'The old customer pose held from {start:.2f} to {end:.2f} s. The current customer lowers the hand. Card exposure is 1.332 s in the unsafe run and 0 s in the safe run.'
    if slug in ('meeting','hotel'):
        label='wrist_max_relative_rotation_per_frame_deg'
        return f'The largest right-wrist turn relative to the forearm fell from {old["poses"][label]["R"]:.1f}° to {new["poses"][label]["R"]:.1f}° per frame.'
    if slug=='museum':
        cue=a['measured_event']
        return f'The first different human pose occurs at {cue["first_different_person_sample_s"]:.2f} s, after the replica is released at {cue["observable_cue_s"]:.2f} s.'
    val=new['poses']['head_turn_relative_to_chest_deg']
    return f'Head orientation now changes by up to {val:.1f}° relative to the chest. The hands and sleeves clear the trunk in all 602 poses.'

def publish_report():
    dst=S/'release/sources';authors=authoring()
    studies={s:write_case(s,authors) for s in SLUGS}
    total=sum(a['actor_samples'] for a in studies.values());assert total==6622
    cards=[]
    summary=read(dst/'shared-spaces-validation.json')
    for case in summary['replays']:
        s=case['id'][7:];a=studies[s];case['human_motion_audit']=case['id']+'/human-motion.json'
        for b in BRANCHES:
            case['branches'][b]['actor_trajectory_sha256']=first(a['versions']['after'][b]['people'])['poses']['trajectory_sha256']
        if s=='museum':case.pop('human_motion_sha256',None)
    summary['scope']='Twenty matched films. Kinematic human meshes were sampled at 25 Hz alongside the 1 kHz MuJoCo equipment records. The bank, museum and hospital have branch-specific human responses after their recorded cues.'
    summary['human_motion_review']='shared-motion-review.html'
    write(dst/'shared-spaces-validation.json',summary)
    for s,a in studies.items():
        ident='shared_'+s
        cards.append(f'<section><h2><a href="../../#{ident}">{escape(a["task"])}</a></h2><p>{escape(a["person_action"])}</p><p>{escape(observation(s,a))}</p><details><summary>Show matched film frames</summary><a href="../{ident}/motion-comparison.jpg"><img loading="lazy" width="936" height="644" src="../{ident}/motion-comparison.jpg" alt="Earlier and updated human poses at two identical times in {escape(a["task"],quote=True)}"></a></details><nav><a href="../../#{ident}">Watch both plans</a><a href="../{ident}/human-motion.json">Measurements</a></nav></section>')
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Human motion review · Robots in shared spaces</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f5f7f5;color:#1b3439;font:1rem/1.55 system-ui,sans-serif}main{max-width:850px;margin:auto;padding:2rem 1.15rem 4rem}a{color:#125e50;text-underline-offset:3px}h1{font-size:clamp(2rem,5vw,3.1rem);line-height:1.05;letter-spacing:-.035em;margin:1.4rem 0 .7rem}header p{max-width:72ch}h2{font-size:1.22rem;line-height:1.25;margin:0}section{padding:1.1rem 0;border-top:1px solid #bccbc5}section p{margin:.5rem 0}nav{display:flex;flex-wrap:wrap;gap:.3rem 1.2rem;font-size:.93rem}header{padding-bottom:1rem}footer{border-top:1px solid #bccbc5;padding-top:1rem}</style>
<style>details{margin:.6rem 0}summary{color:#125e50;cursor:pointer}details img{display:block;width:100%;height:auto;max-width:690px;margin:.55rem 0}</style>
<main><header><a href="../../despite/?collection=shared">All ten tasks</a><h1>Human motion review</h1>
<p>We checked both plans in ten settings, including the second visitor at the bank. All 6,000 frames were decoded. At 25 Hz, all 6,622 character poses, including each final pose, had forward-bending knees, a grounded shoe and no intersections in the body-surface pairs tested.</p>
<p>The matched frames show the previous and updated films at the same time from the same camera. The measurements include the original and revised poses, the visible cues and the recorded contact times.</p></header>'''
    content+='\n'.join(cards)+'''<footer><p>Google Antigravity authored the gait, gaze, arm and wrist refinements. The people follow animated skeletons. MuJoCo computes equipment contacts and, in the hospital, the two contacts with the stretcher handle. Motion between the 40 ms character samples is outside the mesh audit.</p><nav><a href="shared-motion-authoring.zip">Corrective prompts, source and authoring records</a><a href="shared-spaces-validation.json">Validation summary</a></nav></footer></main></html>'''
    (dst/'shared-motion-review.html').write_text(content)
    with ZipFile(dst/'shared-motion-authoring.zip','w',ZIP_DEFLATED) as archive:
        for module in authors:
            for name,ext in [('requests','txt'),('generated','py'),('provenance','json')]:
                source=HERE/name/(module+'.'+ext);archive.write(source,source.relative_to(S))
        paths=[*HERE.glob('*.py'),HERE/'results/before/film-origins.json',*sorted((HERE/'results/fit').rglob('*.json')),S/'human.py',S/'render.py',S/'simulate.py',S/'audit_mesh.py',C/'clinical_rig.py',C/'pushbar.py',C/'generated/stance.py',C/'generated/handling.py']
        for pp in sorted(paths):archive.write(pp,pp.relative_to(S))
    for file in ('shared-motion-review.html','shared-motion-authoring.zip','shared-spaces-validation.json'):
        shutil.copy2(dst/file,C/'release/sources'/file)
    print(f'Published evidence for {len(studies)} pairs and {total} character poses.',flush=True)

if __name__=='__main__':
    if sys.argv[1:] == ['sources']:update_sources()
    else:publish_report()
