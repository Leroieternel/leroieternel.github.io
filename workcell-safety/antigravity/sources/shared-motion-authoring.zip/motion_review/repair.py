"""Apply Antigravity's attention, clearance and arm controls to the actual licensed character rigs."""
from common import *
from scipy.spatial.transform import Rotation
import importlib.util

def module(path):
    spec=importlib.util.spec_from_file_location(path.stem,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result

def helpers():
    return module(HERE/'generated/performance.py'),module(C/'generated/stance.py')

def smooth(x):
    x=np.clip(x,0.,1.);return x*x*x*(10.+x*(-15.+6*x))

def branch_nodes(parent,root):
    nodes={root}
    for i,p in enumerate(parent):
        if p in nodes:nodes.add(i)
    return sorted(nodes)

def fk(bind,parent,rots,hip,hipindex):
    p=np.zeros((len(T),len(bind),3))
    for j,up in enumerate(parent):
        if j==hipindex:p[:,j]=hip
        elif up<0:p[:,j]=hip-bind[hipindex]+bind[j]
        else:p[:,j]=p[:,up]+rots[:,up]@(bind[j]-bind[up])
    trans=np.concatenate((rots,(p-np.einsum('tjab,jb->tja',rots,bind))[:,:,:,None]),axis=3)
    return p,trans

def axis_turn(axis,angles):
    return Rotation.from_rotvec(np.deg2rad(angles)[:,None]*axis).as_matrix()

def move_chain(rots,bind,j,child,destination):
    old=rots[:,j].copy()
    correction=human.align(old@(bind[child]-bind[j]),destination)
    rots[:,j]=correction@old
    return correction

def ease_to_idle(first,second,w):
    qa=Rotation.from_matrix(first.reshape(-1,3,3)).as_quat().reshape(*first.shape[:-2],4)
    qb=Rotation.from_matrix(second.reshape(-1,3,3)).as_quat().reshape(qa.shape)
    qb*=np.where((qa*qb).sum(axis=-1,keepdims=True)<0,-1,1)
    mixed=human.unit((1-w[:,None,None])*qa+w[:,None,None]*qb)
    return Rotation.from_quat(mixed.reshape(-1,4)).as_matrix().reshape(first.shape)

def floor_runs(mask):
    d=np.diff(np.r_[False, mask, False].astype(int));return list(zip(np.flatnonzero(d==1),np.flatnonzero(d==-1)-1))

def support_offsets(shoes, split, until=None):
    """Anchor the same material point throughout a heel/toe roll, transferring the anchor only at lift-off."""
    out=np.zeros((len(T),2,2));end=len(T) if until is None else until
    for k,mask in enumerate((split,~split)):
        vs=shoes[:,mask];z=vs[:,:,2];gap=z.min(1)
        down=gap[:end]<.003
        known=np.zeros(len(T),bool)
        for a,b in floor_runs(down):
            track=np.zeros((b-a+1,2))
            for i in range(a+1,b+1):
                # The same vertex at adjacent samples, including the frame in which heel contact rolls to toe.
                v=np.argmin(np.maximum(z[i-1],z[i]))
                track[i-a]=track[i-a-1]+vs[i-1,v,:2]-vs[i,v,:2]
            anchor=track.mean(0)
            if a==0:anchor=track[0]
            if b==end-1:anchor=track[-1]
            out[a:b+1,k]=track-anchor;known[a:b+1]=True
        if until is not None:
            out[end:,k]=0.;known[end:]=True
        idx=np.flatnonzero(known)
        if not len(idx):continue
        out[:idx[0],k]=out[idx[0],k];out[idx[-1]+1:,k]=out[idx[-1],k]
        for a,b in zip(idx[:-1],idx[1:]):
            if b==a+1:continue
            w=smooth(np.arange(1,b-a)/(b-a))[:,None]
            out[a+1:b,k]=out[a,k]*(1-w)+out[b,k]*w
    return out

def wider_steps(slug,actor,rig,rots,hip,j,tf,right,forward,generated,stance):
    names=rig['names'].tolist();leg=[[names.index(side+'_'+n) for n in ('Thigh','Calf','Foot')] for side in ('L','R')]
    bind=rig['bind'];parent=rig['parent'];hi=names.index('Hip')
    shoe=dict(np.load(next(p for p in (S/'assets/people'/actor).glob('*.npz') if any(k in p.name for k in ('shoes','boots','sneakers')))))
    split=shoe['vertices'][:,0]>0;v=np.array([human.skin(shoe,t) for t in tf])
    soles=np.column_stack([v[:,a,2].min(1) for a in (split,~split)])
    feet=j[:,[x[2] for x in leg]].copy()
    desired=np.array([generated.walking_clearance(x[:,:2],right[:2],.157) for x in feet])
    raw=(desired-feet[:,:,:2])
    # Hold each foot's offset for its entire grounded interval and interpolate through swing.
    for k in range(2):
        grounded=soles[:,k]<.005
        intervals=floor_runs(grounded)
        if not intervals:continue
        offset=np.zeros((len(T),2));sign=1 if k else -1
        for a,b in intervals:
            window=raw[max(0,a-4):min(len(T),b+5),k]
            amount=max(0.,float((window@(sign*right[:2])).max()))
            offset[a:b+1]=amount*sign*right[:2]
        for (_,a),(b,_) in zip(intervals[:-1],intervals[1:]):
            w=smooth(np.linspace(0,1,b-a+1))[:,None]
            offset[a:b+1]=offset[a]*(1-w)+offset[b]*w
        a=intervals[0][0];b=intervals[-1][1];offset[:a]=offset[a];offset[b+1:]=offset[b]
        # If two swing feet pass closely at mid-stride, add clearance in the air only.
        miss=np.maximum(0.,np.sum((raw[:,k]-offset)*(sign*right[:2]),axis=1))
        offset+=sign*right[:2]*((1.-np.exp(-np.maximum(0,soles[:,k]-.005)/.009))*miss)[:,None]
        feet[:,k,:2]+=offset
    # Keep the height and support roll from the actual native shoe meshes.
    feet[:,:,:2]+=support_offsets(v,split)
    return fit_legs(stance,leg,bind,parent,names,rots,hip,j,feet,shoe,split,soles,right,forward,hi)

def fit_legs(stance,leg,bind,parent,names,rots,hip,j,feet,shoe,split,soles,right,forward,hi):
    offsets=j[:,[l[0] for l in leg]]-hip[:,None]
    lengths=np.array([[np.linalg.norm(bind[k]-bind[h]),np.linalg.norm(bind[a]-bind[k])] for h,k,a in leg])
    orig=rots.copy()
    for _ in range(4):
        dx=feet[:,:,:2]-(hip[:,None,:2]+offsets[:,:,:2])
        ceiling=feet[:,:,2]-offsets[:,:,2]+np.sqrt(np.maximum(.001,(lengths.sum(1)-.00055)**2-np.sum(dx**2,axis=2)))
        root=hip.copy();root[:,2]=np.minimum(hip[:,2],ceiling.min(1))
        for i,(side,(h,k,a)) in enumerate(zip(('L','R'),leg)):
            top=root+offsets[:,i]
            knee=np.array([stance.knee_point(x,y,*lengths[i],forward,right,side) for x,y in zip(top,feet[:,i])])
            for bone,child,vec in ((h,k,knee-top),(k,a,feet[:,i]-knee)):
                rots[:,bone]=orig[:,bone]
                move_chain(rots,bind,bone,child,vec)
            for key,bone in [('ThighTwist01',h),('ThighTwist02',h),('KneeShareBone',k),('CalfTwist01',k),('CalfTwist02',k)]:
                rots[:,names.index(side+'_'+key)]=rots[:,bone]
        j,tf=fk(bind,parent,rots,root,hi)
        z=np.array([human.skin(shoe,t)[:,2] for t in tf])
        mismatch=soles-np.column_stack([z[:,s].min(1) for s in (split,~split)])
        if abs(mismatch).max()<.00004:break
        feet[:,:,2]+=mismatch
    return root,j,tf

def body_attention(generated,slug,role,branch,names,parent,rots,right,forward):
    if role in ('clinician','visitor'):return
    angles=np.array([generated.attention(slug,role,branch,float(t)) for t in T])
    assert np.isfinite(angles).all() and np.max(abs(angles))<=26
    for i,name in enumerate(names):
        distribution=0.
        for target,k in [('Spine01',.10),('Spine02',.20),('NeckTwist01',.50),('NeckTwist02',.72),('Head',1.)]:
            if i in branch_nodes(parent,names.index(target)):distribution=k
        if not distribution:continue
        yaw,pitch,roll=(angles*distribution).T
        twist=axis_turn([0,0,1],yaw)@axis_turn(-right,pitch)@axis_turn(forward,roll)
        rots[:,i]=twist@rots[:,i]

def arms(generated,actor,names,rig,rots,j,right,forward,spacing,curl):
    bind=rig['bind'];parent=rig['parent']
    for side in ('L','R'):
        sh,el,wr=[names.index(side+'_'+n) for n in ('Upperarm','Forearm','Hand')]
        result=np.array([generated.relaxed_arm(p[sh],p[el],p[wr],right,forward,side,spacing,curl) for p in j])
        upper,fore=result[:,0]-j[:,sh],result[:,1]-result[:,0]
        cs=move_chain(rots,bind,sh,el,upper);cf=move_chain(rots,bind,el,wr,fore)
        for suffix in ('UpperarmTwist01','UpperarmTwist02'):rots[:,names.index(side+'_'+suffix)]=rots[:,sh]
        for suffix in ('ForearmTwist01','ForearmTwist02','ElbowShareBone'):rots[:,names.index(side+'_'+suffix)]=rots[:,el]
        for idx in branch_nodes(parent,wr):rots[:,idx]=cf@rots[:,idx]

def gesture_wrist(slug,role,branch,rots,rig):
    if slug not in ('meeting','hotel','bank') or (slug=='bank' and (role!='customer' or branch!='unsafe')):return
    wrist_motion=module(HERE/'generated/wrist.py')
    names=rig['names'].tolist();wr=names.index('R_Hand');el=names.index('R_Forearm')
    relative=rots[:,el].transpose(0,2,1)@rots[:,wr]
    quat=Rotation.from_matrix(relative).as_quat()
    filtered=wrist_motion.smooth_wrist(quat,sigma_frames=4.8 if slug=='bank' else 2.65)
    filtered=Rotation.from_quat(filtered).as_matrix()
    if slug=='bank':weight=smooth((T-(read(C/'runs/bank/unsafe.json')['hold_s']+.19))/.32)
    elif slug=='hotel':weight=smooth((T-5.08)/.42)*(1-smooth((T-8.65)/.62))
    else:weight=1-smooth((T-7.85)/.65)
    smooth_rel=ease_to_idle(relative[:,None],filtered[:,None],weight)[:,0]
    change=(rots[:,el]@smooth_rel)@rots[:,wr].transpose(0,2,1)
    for node in branch_nodes(rig['parent'],wr):rots[:,node]=change@rots[:,node]

def apply(slug,branch,role,actor,yaw,path,generated,stance):
    original=HERE/'baseline'/slug/path.name
    if not original.exists() and slug=='museum':original=original.with_name('human.npz')
    a=dict(np.load(original));names=a['names'].tolist();rig=dict(np.load(S/'assets/people'/actor/'skeleton.npz'))
    hipidx=names.index('Hip');parent=rig['parent'];bind=rig['bind']
    tf=a['trans'].astype(float);j=a['joints'].astype(float);rots=tf[:,:,:,:3].copy();hip=j[:,hipidx].copy()
    yaw=np.deg2rad(yaw);forward=np.array([np.sin(yaw),-np.cos(yaw),0.]);right=np.cross(forward,[0,0,1])
    if slug=='bank' and role=='customer' and branch=='unsafe':
        release=read(C/'runs/bank/unsafe.json')['hold_s']+2.27
        safe=dict(np.load(HERE/'baseline/bank/safe-person.npz'))
        w=smooth((T-release)/1.30)
        rots=ease_to_idle(rots,safe['trans'][:,:,:,:3],w)
        hip+=w[:,None]*(safe['joints'][:,hipidx]-hip)
    if slug in ('crossing','bus','library'):
        hip,j,tf=wider_steps(slug,actor,rig,rots,hip,j,tf,right,forward,generated,stance)
    body_attention(generated,slug,role,branch,names,parent,rots,right,forward)
    j,_=fk(bind,parent,rots,hip,hipidx)
    # The clinician's two hands are calibrated to independent physical targets.
    spacing,curl={'business':(.060,11.),'doctor':(.072,15.),'worker':(.074,13.)}[actor]
    arms(generated,actor,names,rig,rots,j,right,forward,spacing,curl)
    gesture_wrist(slug,role,branch,rots,rig)
    fit=HERE/'results/fit'/slug/(branch+'-'+role+'.json')
    if fit.exists() and '--unfitted' not in sys.argv:
        correction=np.asarray(read(fit))
        for k,side in enumerate(('L','R')):
            outward=right*(1 if side=='R' else -1)
            axis=human.unit(np.cross([0,0,-1],outward+.15*forward))
            rot=axis_turn(axis,correction[:,k])
            for bone in branch_nodes(parent,names.index(side+'_Upperarm')):rots[:,bone]=rot@rots[:,bone]
    j,tf=fk(bind,parent,rots,hip,hipidx)
    a['joints']=j.astype('f');a['trans']=tf.astype('f')
    if role=='visitor':
        assert np.allclose(j[:,[names.index('L_Eye'),names.index('R_Eye')]].mean(1),a['eye'],atol=2e-6)
    np.savez_compressed(path,**a)

if __name__=='__main__':
    generated,stance=helpers()
    for slug in [x for x in sys.argv[1:] if not x.startswith('--')] or [s for s in SLUGS if s!='hospital']:
        seen=set()
        for branch in ('safe','unsafe'):
            for role,actor,yaw,path in performers(slug,branch):
                if path not in seen:apply(slug,branch,role,actor,yaw,path,generated,stance);seen.add(path)
        print('Retargeted',slug,flush=True)
