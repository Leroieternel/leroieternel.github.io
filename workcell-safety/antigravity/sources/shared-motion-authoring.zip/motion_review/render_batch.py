"""Render only the published versions of the chosen tasks and verify every complete film."""
from pathlib import Path
import os, subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor
d=Path(__file__).resolve().parent;s=d.parent;c=s/'consequences';root=s.parents[2]
gpu=root/'.runtime/antigravity-blender/bin/python';studio=root/'.runtime/antigravity-studio/bin/python'
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',RENDER_REPLACE='1')
def run(slug,script,mode,python):
    args=[str(python),str(script)]+([mode] if mode else [])+[slug]
    log=d/'logs'/(slug+'-'+(mode or 'encode')+'.log')
    with log.open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)

def finish(slug):
    local=c if slug in ('bank','hospital') else s
    run(slug,local/'encode.py',None,studio)
    print('Encoded',slug,flush=True)

if __name__=='__main__':
    kind=sys.argv[1];slugs=sys.argv[2:];queue=[]
    with ThreadPoolExecutor(max_workers=1) as encoder:
        for slug in slugs:
            local=c if slug in ('bank','hospital') else s
            renderer=local/('film.py' if local==c else 'render.py')
            if kind=='audit':run(slug,renderer,'audit',gpu);continue
            run(slug,renderer,'film',gpu)
            if slug=='hospital':
                run(slug,renderer,'grips',gpu)
                run(slug,renderer,'proof',gpu)
            run(slug,renderer,'verify',gpu)
            queue.append(encoder.submit(finish,slug))
            print('New frames verified',slug,flush=True)
        for job in queue:job.result()
