"""Triangle-level checks on the skinned actors and an independent optical check from the visitor."""
from shared import *
import bpy
from mathutils.bvhtree import BVHTree
from mathutils import Vector
from audit_mesh import extract,corners
from generated import privacy

def bounds_hit(a,b):
    return bool(np.all(a[0]<=b[1]) and np.all(b[0]<=a[1]))

def check(cam):
    v=cam.v;slug=cam.slug;bpy.context.view_layer.update();items=[]
    idx={o:i for i,o in enumerate(v.obs)}
    actor_objs={ob for asm in cam.actors.values() for ob,_,_ in asm}
    def collect(name,mesh,mat,ix=-1):
        xyz,faces=extract(mesh)
        if not len(faces):return
        if ix<0:xyz=xyz@mat[:3,:3].T+mat[:3,3]
        items.append((name,xyz,faces,corners(xyz.min(0),xyz.max(0)),ix))
    for o in v.scene.objects:
        if o in actor_objs or o.name=='stage_ground' or o.get('surface_ink'):continue
        if o.type=='MESH':collect(o.name,o.data,np.array(o.matrix_world),idx.get(o,-1))
        elif o.instance_type=='COLLECTION' and o.instance_collection:
            for part in o.instance_collection.objects:
                if part.type=='MESH':collect(o.name,part.data,np.array(o.matrix_world@part.matrix_world))
    ff={}
    for actor,meshes in cam.actors.items():
        counts=[len(xyz[0]) for _,xyz,_ in meshes]
        ff[actor]=np.vstack([f+offset for (_,_,f),offset in zip(meshes,np.r_[0,np.cumsum(counts)[:-1]])])
    output={};ray_report={}
    for branch in ('safe','unsafe'):
        poses=v.frames[branch]['poses'];bounds=[];fixed={};human_hits={};robot_hits={};min_ground={}
        for k,(_,verts,fa,bb,ix) in enumerate(items):
            if ix<0:bo=np.broadcast_to([bb.min(0),bb.max(0)],(301,2,3))
            else:
                mat=poses[:,ix];x=np.einsum('tij,vj->tvi',mat[:,:9].reshape(-1,3,3),bb)+mat[:,None,9:12]
                bo=np.stack((x.min(1),x.max(1)),axis=1)
            bounds.append(bo)
        allbounds=np.stack(bounds,axis=1)
        gear=[];robot=[]
        for k,(name,_,_,_,ix) in enumerate(items):
            if ix<0:continue
            body=v.spec[ix]['body']
            if slug=='hospital':
                if body in ('gurney_dolly','empty_litter'):gear.append(k)
                elif body!='world':robot.append(k)
            elif body in ('world','privacy_screen_drive','reader_keeper') and name!='stage_ground':gear.append(k)
            elif v.spec[ix]['kind']=='mesh' and body!='payload':robot.append(k)
        differences=[];last_visible=None;first_visible=None;max_diff=0.
        for i in range(301):
            boxes=allbounds[i];cache={};surfaces={}
            def tree(k):
                name,xyz,faces,bb,ix=items[k]
                mem=fixed if ix<0 else cache
                if k not in mem:
                    if ix>=0:
                        mat=poses[i,ix];xyz=xyz@mat[:9].reshape(3,3).T+mat[9:]
                    mem[k]=BVHTree.FromPolygons(xyz,faces,all_triangles=True)
                return mem[k]
            for actor,group in cam.actors.items():
                index=i+(301 if actor=='principal' and branch=='unsafe' else 0)
                h=np.vstack([xyz[index] for _,xyz,_ in group]);b=np.stack((h.min(0),h.max(0)))
                min_ground[actor]=min(min_ground.get(actor,10.),float(b[0,2]))
                hv=BVHTree.FromPolygons(h,ff[actor],all_triangles=True);surfaces[actor]=hv
                candidates=np.flatnonzero(np.all(boxes[:,0]<=b[1],1)&np.all(boxes[:,1]>=b[0],1)&(boxes[:,1,2]>.004))
                for k in candidates:
                    if hv.overlap(tree(k)):human_hits.setdefault(actor+' / '+items[k][0],[]).append(i)
            if len(surfaces)>1 and surfaces['principal'].overlap(surfaces['visitor']):
                human_hits.setdefault('customer / visitor',[]).append(i)
            for k in gear:
                close=[r for r in robot if bounds_hit(boxes[r],boxes[k])]
                for r in close:
                    if tree(k).overlap(tree(r)):robot_hits.setdefault(items[r][0]+' / '+items[k][0],[]).append(i)
            if slug!='bank':continue
            idx_card=next(ii for ii,x in enumerate(v.spec) if x['name']=='privacy_card')
            mat=poses[i,idx_card];basis=mat[:9].reshape(3,3);o=mat[9:]
            eye=cam.visitor['eye'][i];gaze=cam.visitor['gaze'][i];found=0
            for y in (-.013,0,.013):
                for x in (-.032,-.012,.007):
                    point=o+basis@np.array([x,y,.00275]);dv=point-eye;length=np.linalg.norm(dv);direction=Vector(dv/length)
                    rng=np.stack((np.minimum(eye,point),np.maximum(eye,point)));vis=True
                    if privacy.face_in_view(basis[:,2],point,eye,gaze,True):
                        keys=np.flatnonzero(np.all(boxes[:,0]<=rng[1],1)&np.all(boxes[:,1]>=rng[0],1))
                        for k in keys:
                            ix=items[k][4]
                            if ix>=0 and v.spec[ix]['body']=='payload':continue
                            if tree(k).ray_cast(Vector(eye),direction,float(length-.0003))[0] is not None:vis=False;break
                        if surfaces['principal'].ray_cast(Vector(eye),direction,float(length-.0003))[0] is not None:vis=False
                    else:vis=False
                    found+=vis
            ratio=found/9;phys=float(cam.metrics[branch]['witness_visible_fraction'][i*40]);max_diff=max(max_diff,abs(ratio-phys))
            if (ratio>=.6)!=(phys>=.6):differences.append(i/25)
            if ratio>=.6:
                if first_visible is None:first_visible=i/25
                last_visible=i/25
        def intervals(hits):
            return {k:dict(frames=len(a),first_s=a[0]/25,last_s=a[-1]/25) for k,a in hits.items()}
        output[branch]=dict(person_scene=intervals(human_hits),robot_equipment=intervals(robot_hits),
                            minimum_skin_z_mm={a:round(z*1000,3) for a,z in min_ground.items()})
        ray_report[branch]=dict(all_view_frames=301,postrelease_frames=104,observer_threshold_disagreements_s=differences,
              maximum_visibility_fraction_difference=max_diff,first_visible_frame_s=first_visible,last_visible_frame_s=last_visible)
    write(cam.path/'mesh-check.json',{'sample_rate_Hz':25,'poses_per_branch':301,'branches':output,
          'scope':'Original actor triangles against bodies, set, equipment and each other. Floor clearance recorded separately. Robot-to-equipment includes intended contact and reported soft-contact overlap.'})
    if slug=='bank':write(cam.path/'observer-check.json',ray_report)
    print(slug,'SURFACES',output,'OBSERVER',ray_report if slug=='bank' else '',flush=True)
