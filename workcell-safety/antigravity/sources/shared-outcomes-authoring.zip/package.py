from shared import *
from narrative import TITLES,SCOPES,steps,outcome,event
from PIL import Image,ImageDraw,ImageFont,ImageOps
import shutil,zipfile

COL={'unsafe':'#b0502e','safe':'#16725e'}
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans'
META={
 'hospital':dict(description='A clinician pushes an empty transfer stretcher through a corridor junction. A mobile supply robot either yields or enters early. In the early-entry replay its guard catches the removable deck, which tips off its supports and lands on the floor.',
 notes='Both runs start with the same walking clinician holding the trailing bar. The robot’s crossing decision changes the equipment motion. The clinician releases only after handling the bar and sensing the deck tip.',
 criterion='Guard-to-deck contact identifies the equipment strike. Saddle load, deck tilt and deck-to-floor force track the fall of the empty deck. Left and right palm loads record when the clinician is actually handling the bar.',
 metric='Empty stretcher tilt',unit='degrees',force='Guard-to-stretcher normal force',reaction='Left and right hand contact with the push bar',
 sequence='The clinician guides the dolly, releases the bar as the deck tips and remains on her feet. Both columns show the same instant.',
 caption='Watch the hands on the bar, the guard reach the deck and the clinician let go as the deck falls. Both views run at half speed.'),
 'bank':dict(description='A customer waits at a bank counter while a second visitor stands in the adjacent queue. G1 returns a fictional card. A face-up return exposes the DEMO 42 face to the visitor, interrupts the handoff and closes the privacy screen.',
 notes='Both takes start with the screened pickup and the same queue visitor. Compare the detail from the teller side with the later magnified view from the visitor’s eyes.',
 criterion='Visibility requires a forward-facing sample and an unobstructed ray from the visitor. Six of nine visible samples count as exposure. Continuous exposure for 0.28 s puts the transaction on hold. This is a simulated privacy procedure with fictional markings.',
 metric='Printed face visible from the queue',unit='%',force='Card-to-receiver normal force',reaction='Transaction state and customer response',
 sequence='The visitor sees the return, the customer responds, and the counter reaches a different final state. Each row uses the same simulation time.',
 caption='Compare the visitor’s actual sight line, the customer’s hand signal and the physical privacy screen at half speed.')}

def frame(slug,b,t):
    return C/'media'/slug/b/f'frame-{1+min(299,round(t*25)):04d}.jpg'

def resize_image(src,dst,size):
    with Image.open(src) as im:
        im.thumbnail(size,Image.Resampling.LANCZOS);im.save(dst,quality=92,optimize=True)

def sequence(slug,dest):
    rows=([(2.84,'Both hands guide the bar'),(3.72,'Hands clear as the deck reaches the floor'),(6.40,'The clinician stands clear')] if slug=='hospital' else
          [(8.64,'From the queue'),(9.84,'Customer response'),(10.76,'Final sight line')])
    board=Image.new('RGB',(1280,1190),'#15272b');draw=ImageDraw.Draw(board)
    bold=lambda n:ImageFont.truetype(FONT+'-Bold.ttf',n)
    draw.text((24,12),TITLES[slug],font=bold(36),fill='#f5f2e9')
    for col,b in enumerate(('unsafe','safe')):draw.text((24+col*630,65),b.upper(),font=bold(24),fill=('#ffae83','#a4e3d0')[col])
    for row,(t,txt) in enumerate(rows):
        y=105+row*359
        for col,b in enumerate(('unsafe','safe')):
            img=(C/'media'/slug/(b+'-grip')/f'grip-{round(t*25):04d}.jpg') if slug=='hospital' and row==0 else frame(slug,b,t)
            with Image.open(img) as pic:board.paste(ImageOps.fit(pic,(612,314),method=Image.Resampling.LANCZOS),(24+col*630,y))
        draw.text((25,y+318),f'{t:.2f} s   /   {txt}',font=bold(21),fill='#e8eae3')
    board.save(dest/'sequence.jpg',quality=92,optimize=True)
    poster=Image.open(C/'media'/slug/'portrait-background.png')
    for b,y in [('unsafe',56),('safe',652)]:
        t=3.96 if slug=='hospital' else 8.64
        with Image.open(frame(slug,b,t)) as pic:poster.paste(pic.resize((960,540),Image.Resampling.LANCZOS),(0,y))
    poster.save(dest/'event_poster.jpg',quality=90,optimize=True)

def graphs(slug,data,dest,rb):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    is_hospital=slug=='hospital';ev=event(slug)
    def plot_style(ax,title,y):
        ax.set_title(title,loc='left',fontsize=15,weight='semibold');ax.set_ylabel(y);ax.grid(axis='y',alpha=.22)
        ax.spines[['top','right']].set_visible(False)
    def sheet(k,titles):
        fig,axs=plt.subplots(len(titles),1,figsize=(8.8,3.5 if len(titles)==1 else 5.0),dpi=145,sharex=True)
        axs=np.atleast_1d(axs);fig.patch.set_facecolor('#fcfdfb')
        for ax,(title,unit,series,scale) in zip(axs,titles):
            plot_style(ax,title,unit)
            for b in ('unsafe','safe'):
                d=data[b]
                if series=='hip' or series=='hand':
                    tr=np.load(C/'runs'/slug/(b+'-person.npz'));n=tr['names'].tolist()
                    y=tr['joints'][:,n.index('Hip'),2] if series=='hip' else np.maximum(tr['joints'][:,n.index('R_Hand'),2],tr['joints'][:,n.index('L_Hand'),2]);t=T
                else:y=d[series];t=d['time_s']
                ax.plot(t,y*scale,'-' if b=='unsafe' else '--',label=b.capitalize(),color=COL[b],lw=1.8)
            if is_hospital and series in ('left_palm_grip_N','right_palm_grip_N'):
                ax.axvline(rb['unsafe']['release_command_s'],color='#a25036',ls='--',lw=.9)
                ax.text(.99,.95,'dotted = guard contact   /   dashed line = release',transform=ax.transAxes,ha='right',va='top',fontsize=8)
            ax.axvline(ev,color='#75867f',ls=':',lw=1.0);ax.legend(loc='upper left',frameon=False,ncol=2,fontsize=9)
            if series=='state':ax.set_yticks([0,1,2],['Presenting','Released','Privacy hold']);ax.set_ylim(-.25,2.4)
            if series=='witness_visible_fraction' or series=='cover_fraction':ax.set_ylim(-4,108)
        axs[-1].set_xlabel('Simulation time (s)');axs[-1].set_xlim(0,12);fig.tight_layout();fig.savefig(dest/(k+'.png'));plt.close(fig)
    if is_hospital:
        sheet('metric',[('Tilt of the empty removable stretcher','Deck tilt (degrees)','litter_tilt_deg',1)])
        sheet('force',[('Robot guard against the stretcher','Normal force (N)','bumper_litter_N',1),
                        ('Stretcher against the corridor floor','Normal force (N)','litter_floor_N',1)])
        sheet('reaction',[('Left palm on the stretcher handle','Normal force (N)','left_palm_grip_N',1),
                          ('Right palm on the stretcher handle','Normal force (N)','right_palm_grip_N',1)])
    else:
        sheet('metric',[('Card face visible from the visitor’s eyes','Visible samples (%)','witness_visible_fraction',100),
                         ('Opaque screen position','Closure (%)','cover_fraction',100)])
        sheet('force',[('Card support during and after handover','Normal force (N)','card_support_N',1)])
        sheet('reaction',[('Terminal response to exposure','Handoff state','state',1),
                           ('Customer hand signal','Higher wrist (m)','hand',1)])

def checked_optics(slug,b):
    import mujoco as mj
    p=C/'runs'/slug;m=mj.MjModel.from_xml_path(str(p/'scene.xml'));d=mj.MjData(m)
    specs=read(C/'optics'/slug/'meta.json')['objects'];poses=np.load(C/'optics'/slug/(b+'.npz'))['poses']
    state=np.load(p/(b+'.npz'));mp=state.get('mocap_pos');mq=state.get('mocap_quat')
    gids=[];indices=[]
    for name in (('supply_guard','deck_pan','headrest','caster_base','push_grip_L','push_grip_R') if slug=='hospital' else ('privacy_card','opaque_privacy_screen','receiving_pad','screen_edge')):
        gids.append(m.geom(name).id);indices.append(next(i for i,v in enumerate(specs) if v['name']==name))
    worst=0.
    for i,q in enumerate(state['qpos']):
        d.qpos[:]=q
        if mp is not None:d.mocap_pos[:]=mp[i];d.mocap_quat[:]=mq[i]
        mj.mj_forward(m,d)
        values=np.c_[d.geom_xmat[gids],d.geom_xpos[gids]]
        worst=max(worst,float(abs(poses[i,indices]-values).max()))
    assert worst<2e-6,(slug,b,worst)
    return worst

def payload(slug):
    p=C/'runs'/slug;dest=C/'release'/('shared_'+slug);dest.mkdir(exist_ok=True,parents=True)
    old=S/'release'/('shared_'+slug);rb={b:read(p/(b+'.json')) for b in ('safe','unsafe')}
    data={b:dict(np.load(p/(b+'-metrics.npz'))) for b in rb};m=META[slug]
    encoded=read(C/'media'/slug/'encoded.json');images=read(p/'render-check.json');mesh=read(p/'mesh-check.json')
    performance=read(p/'performance.json')
    for b,d in rb.items():
        assert d['solver_warnings']==0 and len(data[b]['time_s'])==12001
        assert mesh['branches'][b]['person_scene']=={} and all(z>=-.01 for z in mesh['branches'][b]['minimum_skin_z_mm'].values())
        allowed={'supply_guard / deck_pan'} if b=='unsafe' and slug=='hospital' else set()
        assert set(mesh['branches'][b]['robot_equipment'])<=allowed
        assert len(images[b])>=4 and all(q['mean_rgb_error_255']<3.5 for q in images[b])
        assert sha(C/'media'/slug/(b+'.mp4'))==encoded[b]['sha256'] and encoded[b]['decoded_frames']==300
        encoded[b]['independent_render_samples']=images[b];encoded[b]['max_optics_pose_error']=read(p/'solver-to-render.json')[b]
        assert encoded[b]['max_optics_pose_error']<2e-6
        shutil.copy2(p/(b+'.csv.gz'),dest/(b+'.csv.gz'))
    extra={}
    if slug=='hospital':
        for b,v in rb.items():
            half=read(p/'half-step'/(b+'.json'))
            assert (v['first_floor_contact_s'] is not None)==(b=='unsafe')==(half['first_floor_contact_s'] is not None)
            if b=='unsafe':assert min(v['peak_tilt_deg'],half['peak_tilt_deg'])>65 and abs(v['first_floor_contact_s']-half['first_floor_contact_s'])<.05
            assert mesh['branches'][b]['equipment_furnishings']=={}
            assert v['first_both_palms_loaded_s']==0 and performance['branches'][b]['min_hip_height_m']>.80
            actor=performance['branches'][b]
            assert actor['min_head_height_m']>actor['min_hip_height_m']+.35 and min(actor['terminal_sole_gaps_mm'])>=0 and max(actor['terminal_sole_gaps_mm'])<2.
            assert performance['maximum_precontact_transform_difference']<.00005
            for hand in performance['branches'][b]['hand_mesh']:
                assert -.35<hand['minimum_loaded_skin_gap_mm'] and hand['maximum_loaded_skin_gap_mm']<1.8,hand
            if b=='unsafe':
                assert min(v['at_robot_contact_palm_normal_N'])>.1 and v['both_palms_loaded_s']>3
                assert v['first_contact_s']<v['release_command_s']<=v['hands_clear_s']<v['first_floor_contact_s']
                assert v['final_palm_normal_N']==half['final_palm_normal_N']==[0.,0.] and half['release_command_s']<=half['hands_clear_s']<half['first_floor_contact_s']
                assert v['final_floor_N']>0 and v['final_height_m']<.28
                assert abs(v['first_contact_s']-half['first_contact_s'])<.015
            else:assert v['release_command_s'] is None and v['final_base_x_m']>2 and v['peak_contact_N']==0 and v['final_support_N']>0 and v['first_floor_contact_s'] is None
            extra.setdefault('half_step',{})[b]=half
        from stance_evidence import stance_sheet
        stance_sheet(dest,performance)
        for b in rb:
            assert encoded[b]['decoded_final_leg_region']['mean_rgb_error_255']<6.
            gait=performance['branches'][b]['gait']
            assert gait['poses']==301 and all(n==0 for n in gait['backward_knee_frames'].values())
            assert all(2 < angle['end_deg'] < 15 for angle in gait['signed_knee_flexion'].values())
            assert 180 < gait['terminal_ankle_spacing_mm'] < 240 and gait['settled_max_shoe_vertex_drift_mm'] < 1
            assert .0<=gait['min_skin_sole_height_mm'] and gait['max_lower_sole_height_mm']<2.
            assert all(step['support_sole_point_xy_excursion_mm']<1 and step['max_support_sole_height_mm']<2. for step in gait['steps'])
            assert mesh['branches'][b]['left_right_leg_mesh_overlap_frames']==[]
        extra['gait_baseline']=read(C/'proofs/previous-stance.json')
        for b in rb:
            prior_hash=extra['gait_baseline'][b]['previous_solver_trace_sha256']
            if sha(p/(b+'.csv.gz'))!=prior_hash:
                previous=S/'motion_review/baseline/hospital'/(b+'.csv.gz')
                assert sha(previous)==prior_hash
                for subdir in ('','half-step'):
                    current=np.load(p/subdir/(b+'-metrics.npz'))
                    reference=np.load(S/'motion_review/baseline/hospital'/subdir/(b+'-metrics.npz'))
                    for channel in current.files:
                        # The revised free hands settle clear of the scrub shirt after liftoff.
                        checked=np.ones(len(current[channel]),bool)
                        if b=='unsafe' and channel in ('left_pad_bar_gap_m','right_pad_bar_gap_m'):
                            cleared=read(p/subdir/(b+'.json'))['hands_clear_s']
                            checked=current['time_s']<=cleared
                        assert np.allclose(current[channel][checked],reference[channel][checked],rtol=0,atol=1e-7),channel
                extra['unchanged_loaded_hand_contact_and_equipment_channels']=True
        from generated import handling
        d=data['unsafe']
        def cue_again(sense_hands):
            held=0.;last=-10.
            for t,left,right,tilt,support in zip(d['time_s'],d['left_palm_grip_N'],d['right_palm_grip_N'],d['litter_tilt_deg'],d['saddle_support_N']):
                if sense_hands and min(left,right)>.04:held+=.001;last=t
                if handling.release_due(held>.14 and t-last<.16,tilt,support):return float(t)
            return None
        measured_cue=cue_again(True);no_touch_cue=cue_again(False)
        assert measured_cue==rb['unsafe']['release_command_s'] and no_touch_cue is None
        extra['handling_replay_check']=dict(input='Recorded unsafe deck angle and saddle loads at 1 kHz',
            release_with_recorded_palm_loads_s=measured_cue,release_with_both_palm_channels_zeroed_s=no_touch_cue,
            scope='Offline controller check on identical equipment measurements.')
        u=rb['unsafe'];other=extra['half_step']['unsafe']
        extra['time_step_comparison']=dict(guard_contact_difference_s=abs(u['first_contact_s']-other['first_contact_s']),
            release_cue_difference_s=abs(u['release_command_s']-other['release_command_s']),
            first_floor_contact_difference_s=abs(u['first_floor_contact_s']-other['first_floor_contact_s']),
            interpretation='Both step sizes give loaded hands at the equipment strike, hand release and a fallen deck. The final resting angle is sensitive to secondary contacts with the dolly.')
    else:
        ray=read(p/'observer-check.json');extra['optical_check']=ray
        for b,d in rb.items():
            assert ray[b]['all_view_frames']==301 and not ray[b]['observer_threshold_disagreements_s']
            assert d['max_pre_handoff_fraction']==0 and d['final_visible_fraction']==0
        assert rb['safe']['exposure_s']==0 and rb['safe']['final_handoff_state']=='handed_over'
        assert rb['unsafe']['exposure_s']>.8 and rb['unsafe']['final_handoff_state']=='privacy_hold'
        shutil.copy2(p/'observer-check.json',dest/'observer-check.json')
    graphs(slug,data,dest,rb);sequence(slug,dest)
    detail_t=5.72 if slug=='hospital' else 8.64
    for b in rb:
        resize_image(frame(slug,b,detail_t),dest/('detail_'+b+'.jpg'),(1600,900))
        resize_image(frame(slug,b,4.72 if slug=='hospital' else 9.96),dest/(b+'_poster.jpg'),(1280,720))
    resize_image(frame(slug,'unsafe',3.40 if slug=='hospital' else 9.96),dest/'thumb.jpg',(600,338))
    module='stance' if slug=='hospital' else 'privacy'
    auth=read(C/'provenance'/(module+'.json'))
    assert auth['sha256']==sha(C/'generated'/(module+'.py')) and auth['prompt_sha256']==sha(C/'requests'/(module+'.txt'))
    shutil.copy2(C/'requests'/(module+'.txt'),dest/'revision-prompt.txt');shutil.copy2(C/'generated'/(module+'.py'),dest/'antigravity.py')
    shutil.copy2(p/'performance.json',dest/'performance.json');shutil.copy2(p/'mesh-check.json',dest/'mesh-check.json')
    prior=read(old/'source-example.json');prior['simulation_adaptation']=m['description'];write(dest/'source-example.json',prior)
    look=read(p/'appearance.json');look['credits']=read(old/'appearance.json')['credits']
    look['credits']['human_performance']=performance
    write(dest/'appearance.json',look);write(dest/'video-verification.json',encoded)
    write(dest/'physics-audit.json',dict(solver='MuJoCo 4.0.1',timestep_s=.001,scope=SCOPES[slug],branches=rb,actor_performance=performance,**extra))
    orig=read(old/'production.json')
    orig.update(revision='consequences-2',revision_author=auth,role='Google Antigravity revised the decision, event-response rules and camera directions. Codex integrated the equipment mechanics, retargeted the human performances and verified the final optical and solver records.',
                actor_performance=performance)
    if slug=='hospital':
        orig.update(revision='stance-4',handling_controller=read(C/'provenance/handling.json'),equipment_controller=read(C/'provenance/hospital.json'),
            role='Google Antigravity authored the crossing and handling policies, the anatomical knee solver, neutral stance targets and swing interpolation. Codex integrated the gait with the native clinician and verified the skinned poses and films against the existing MuJoCo equipment and hand records.')
    orig.pop('common_person_trajectory_sha256',None)
    write(dest/'production.json',orig)
    ent=read(S/'entries'/('shared_'+slug+'.json'))
    ent.update(consequence=True,assetRevision=('hospital-gait-v4' if slug=='hospital' else 'outcomes-v2'),title=TITLES[slug],description=m['description'],notes=m['notes'],scope=SCOPES[slug],
               detail=m['sequence'],criterion=m['criterion'],metric=m['metric'],unit=m['unit'],force=m['force'],hasContact=True,
               event=round(event(slug),3),detailByBranch={b:detail_t for b in rb},sequenceCaption=m['sequence'],
               reactionChart=m['reaction'],eventReplay=dict(title='Compare the outcome at half speed',caption=m['caption'],poster=('event_poster.jpg?v=stance4' if slug=='hospital' else 'event_poster.jpg'),file='event.mp4'))
    for b,d in rb.items():
        ent[b]=dict(steps=steps(slug,b),outcome=outcome(slug,b),completed=b=='safe',peak=round(d['peak_tilt_deg'] if slug=='hospital' else 100*d['max_visible_fraction'],2),
                    force=round(d['peak_contact_N'] if slug=='hospital' else d['force_peak_N'],2))
    if slug=='hospital':
        ent['stanceCaption']='At 11.96 s, compare the earlier and corrected stance from the same camera. The three side views below follow the steps after the clinician releases the bar.'
        ent['terminalMetric']=dict(label='Final stretcher tilt (degrees)',**{b:round(d['final_tilt_deg'],2) for b,d in rb.items()})
        ent['facts']=[['First unsafe equipment contact',f"{event(slug):.3f} s"],['First unsafe floor contact',f"{rb['unsafe']['first_floor_contact_s']:.3f} s"],
                      ['Unsafe guard impulse',f"{rb['unsafe']['contact_impulse_Ns']:.2f} N·s"],['Maximum unsafe deck tilt',f"{rb['unsafe']['peak_tilt_deg']:.1f}°"],
                      ['Safe guard contact','0 N'],['Clinician starts releasing the bar',f"{rb['unsafe']['release_command_s']:.3f} s"],
                      ['Hands unloaded throughout the remaining replay',f"From {rb['unsafe']['hands_clear_s']:.3f} s"],
                      ['Unsafe palms at the equipment strike',' / '.join(f'{q:.1f} N' for q in rb['unsafe']['at_robot_contact_palm_normal_N'])],
                      ['Unsafe final deck tilt (1 ms / 0.5 ms)',f"{rb['unsafe']['final_tilt_deg']:.1f}° / {extra['half_step']['unsafe']['final_tilt_deg']:.1f}°"],['Clinician at the end','Standing clear of the deck']]
    else:
        ent['terminalMetric']=dict(label='Exposure to the queue (s)',**{b:round(d['exposure_s'],3) for b,d in rb.items()})
        ent['facts']=[['Unsafe card-face exposure',f"{rb['unsafe']['exposure_s']:.3f} s"],['Safe card-face exposure','0 s'],
                      ['Unsafe privacy hold',f"{rb['unsafe']['hold_s']:.3f} s"],['Safe handoff released',f"{rb['safe']['complete_s']:.3f} s"],
                      ['End of unsafe run','On hold for a private reissue'],['Eye-view cross-check','602 rendered poses']]
    (C/'entries').mkdir(exist_ok=True);write(C/'entries'/('shared_'+slug+'.json'),ent)

def sources(changed=('hospital','bank')):
    dst=C/'release/sources';dst.mkdir(exist_ok=True,parents=True)
    with zipfile.ZipFile(dst/'shared-outcomes-authoring.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(C.glob('*.py')):z.write(p,p.name)
        for role in ('hospital','handling','stance','privacy'):
            for dr,ext in [('requests','.txt'),('generated','.py'),('provenance','.json')]:
                d=Path(dr)/(role+ext);z.write(C/d,d.as_posix())
        for name in ('previous-stance.json','hospital-before-stance.jpg','hospital-unsafe-legs-091.jpg','hospital-unsafe-legs-100.jpg','hospital-unsafe-legs-114.jpg'):
            z.write(C/'proofs'/name,'proofs/'+name)
        for rel in ('human.py','render.py','simulate.py','world.py'):z.write(S/rel,'integration/'+rel)
        for rel in ('safe.json','unsafe.json','performance.json','mesh-check.json','solver-to-render.json'):
            z.write(C/'runs/hospital'/rel,'hospital-results/'+rel)
    summary=read(S/'release/sources/shared-spaces-validation.json')
    for item in summary['replays']:
        slug=item['id'].removeprefix('shared_')
        if slug not in changed:continue
        p=C/'runs'/slug;r=C/'release'/item['id'];production=read(r/'production.json')
        item.pop('human_motion_sha256',None);item['revision']='stance-4' if slug=='hospital' else 'consequences-2'
        item['actor_performance']=read(r/'performance.json');item['sampled_surfaces']=read(r/'mesh-check.json')['scope']
        item['native_motion']='Native Isaac People walk and quiet stance, anatomically forward knees, planted recovery steps, and measured two-palm handling' if slug=='hospital' else 'Native customer gesture and second queue visitor'
        for b in ('safe','unsafe'):
            record=read(p/(b+'.json'))
            item['branches'][b]=dict(trajectory_sha256=sha(p/(b+'.npz')),actor_trajectory_sha256=sha(p/(b+'-person.npz')),
                                     movie_sha256=sha(C/'media'/slug/(b+'.mp4')),outcome=outcome(slug,b),
                                     evidence='shared_'+slug+'/physics-audit.json',
                                     rule_value=record['final_tilt_deg'] if slug=='hospital' else record['exposure_s'],
                                     unit='degrees' if slug=='hospital' else 's')
    summary.update(sampled_video_frames_checked_independently=66,person_scene_triangle_intersections=0,
                   actor_pose_checks=6622,scope='The ten pairs share their starting scene and human performances up to the relevant decision. Hospital and bank include event-driven reactions. Their linked evidence separates rigid-body dynamics, human animation and geometric observation.',
                   portrait_event_movies=2)
    write(dst/'shared-spaces-validation.json',summary)
    # Keep the gallery overview current without decoding historical movies again.
    dest=Image.open(S/'shared-spaces-preview.jpg')
    order=list(read(S/'selection.json'))
    for slug,tm in [('hospital',4.64),('bank',9.96)]:
        i=next(i for i,e in enumerate(order) if e['slug']==slug);x=29+(i%5)*404;y=111+(i//5)*282
        with Image.open(frame(slug,'unsafe',tm)) as im:dest.paste(ImageOps.fit(im,(392,205),method=Image.Resampling.LANCZOS),(x,y))
    draw=ImageDraw.Draw(dest);draw.rectangle((0,60,dest.width,101),fill='#172728')
    draw.text((30,66),'Ten paired studies  /  Three outdoor settings  /  Six library robot configurations',font=ImageFont.truetype(FONT+'.ttf',20),fill='#b6c9c0')
    dest.save(dst/'shared-spaces-preview.jpg',quality=92)

if __name__=='__main__':
    for slug in sys.argv[1:] or tuple(META):
        if slug=='optics':
            for key in META:write(C/'runs'/key/'solver-to-render.json',{b:checked_optics(key,b) for b in ('safe','unsafe')})
        elif slug=='sources':sources([k for k in sys.argv[1:] if k in META] or tuple(META))
        else:payload(slug)
