from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "hard1044"))
import author

author.HERE = HERE
if __name__ == "__main__":
    for module in sys.argv[1:]:
        author.request(module, mode="auto" if module == "handling" else "plan")
