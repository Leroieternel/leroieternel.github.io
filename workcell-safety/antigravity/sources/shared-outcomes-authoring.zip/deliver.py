"""Update only the two established study routes on the project's existing GitHub Pages host."""
from shared import *
from narrative import TITLES
import re
import shutil
from release import publish,WEB,MOV,MIRROR,SITE
from site_fields import main_fields
from gallery_hooks import main,edition
sys.path.insert(0,str(S.parent))
from scene_directory import write_directory

def films(slugs):
    paths=[]
    for slug in slugs:
        movie=C/'media'/slug
        checks=read(C/'release'/('shared_'+slug)/'video-verification.json')
        for name in ('safe','unsafe','event'):
            f=movie/(name+'.mp4');assert sha(f)==checks[name]['sha256']
            rel=Path('media/antigravity')/('shared_'+slug)/f.name
            (MOV/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,MOV/rel);paths.append(rel.as_posix())
    revision=publish(MOV,paths,'codex/mobile-mission-films','Show the clinician guiding and releasing the stretcher bar' if slugs==['hospital'] else 'Publish updated shared-space replay films')
    write(C/'film-release.json',dict(revision=revision,files=paths));print('Film revision',revision,flush=True)

def prepare(slugs):
    pinned=read(C/'film-release.json')['revision'];changed=set()
    for file in sorted((C/'release').rglob('*')):
        if not file.is_file():continue
        key=file.relative_to(C/'release')
        if key.parts[0]!='sources' and key.parts[0] not in {'shared_'+s for s in slugs}:continue
        dest=SITE/'antigravity'/key
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest)
        master=S/'release'/key;master.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,master)
        changed.add('antigravity/'+key.as_posix())
    updated={}
    for slug in slugs:
        ident='shared_'+slug;entry=read(C/'entries'/(ident+'.json'))
        entry['film']='https://raw.githubusercontent.com/Leroieternel/leroieternel.github.io/'+pinned+'/media/antigravity/'+ident
        write(C/'entries'/(ident+'.json'),entry);write(S/'entries'/(ident+'.json'),entry);updated[ident]=entry
    ed=SITE/'antigravity/catalog.json';records=read(ed)
    assert set(updated)<=set(r['id'] for r in records)
    ed.write_text(json.dumps([updated.get(r['id'],r) for r in records],ensure_ascii=False,separators=(',',':')))
    maincat=SITE/'everyday-catalog.js';label,body=maincat.read_text().split('=',1);rows=json.loads(body.strip().rstrip(';'))
    assert set(updated)<=set(r['id'] for r in rows)
    rows=[main_fields(updated[r['id']]) if r['id'] in updated else r for r in rows]
    maincat.write_text(label+'= '+json.dumps(rows,ensure_ascii=False,separators=(',',':'))+';\n')
    # Re-read the public formats before publishing, including every untouched study.
    re_ed=read(ed);re_main=json.loads(maincat.read_text().split('=',1)[1].strip().rstrip(';'))
    assert [r['id'] for r in re_ed]==[r['id'] for r in records]
    assert all(new==old for old,new in zip(records,re_ed) if old['id'] not in updated)
    before=json.loads(body.strip().rstrip(';'))
    assert [r['id'] for r in re_main]==[r['id'] for r in before]
    assert all(new==old for old,new in zip(before,re_main) if old['id'] not in updated)
    for entry in updated.values():
        assert next(r for r in re_main if r['id']==entry['id'])['filmBase']==entry['film']
    write_directory(SITE,rows)
    for f,hook in [(SITE/'app.js',main),(SITE/'antigravity/app.js',edition),(S.parent/'web/app.js',edition)]:f.write_text(hook(f.read_text()))
    idx=SITE/'index.html';t=idx.read_text()
    for n in ['app.js','everyday-catalog.js']:t=re.sub(re.escape(n)+r'\?v=[\w-]+',n+'?v='+sha(SITE/n)[:12],t)
    idx.write_text(t)
    idx=SITE/'antigravity/index.html';t=idx.read_text();prev=re.search('data-build="([^"]+)"',t)[1]
    idx.write_text(t.replace(prev,sha(ed)[:12]))
    changed.update(['everyday-catalog.js','antigravity/catalog.json','despite/index.html','app.js','antigravity/app.js','index.html','antigravity/index.html'])
    for key in changed:
        dst=MIRROR/key;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SITE/key,dst)
    write(C/'deploy-files.json',sorted(changed));print('Prepared',list(updated),'within',len(rows),'DESPITE entries.',len(changed),'release paths.',flush=True)

def website(slugs):
    paths=['workcell-safety/'+i for i in read(C/'deploy-files.json')]
    rev=publish(WEB,paths,'main','Correct the hospital replay with measured hand contact and a grounded handler' if slugs==['hospital'] else 'Update the shared-space replay evidence')
    write(C/'deployment.json',dict(website=rev,films=read(C/'film-release.json')['revision'],routes=['shared_'+s for s in slugs]));print('Published',rev,flush=True)

if __name__=='__main__':
    slugs=sys.argv[2:] or list(TITLES)
    assert set(slugs)<=set(TITLES)
    {'films':films,'prepare':prepare,'website':website}[sys.argv[1]](slugs)
