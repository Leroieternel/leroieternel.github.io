"""Update only the two established study routes on the project's existing GitHub Pages host."""
from shared import *
from narrative import TITLES
import re
import shutil
from release import publish,WEB,MOV,MIRROR,SITE
from site_fields import main_fields
from gallery_hooks import main,edition
sys.path.insert(0,str(S.parent))
from scene_directory import write_directory

def films():
    paths=[]
    for slug in TITLES:
        movie=C/'media'/slug
        checks=read(C/'release'/('shared_'+slug)/'video-verification.json')
        for name in ('safe','unsafe','event'):
            f=movie/(name+'.mp4');assert sha(f)==checks[name]['sha256']
            rel=Path('media/antigravity')/('shared_'+slug)/f.name
            (MOV/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,MOV/rel);paths.append(rel.as_posix())
    revision=publish(MOV,paths,'codex/mobile-mission-films','Show the stretcher overturn and an interrupted private handoff')
    write(C/'film-release.json',dict(revision=revision,files=paths));print('Film revision',revision,flush=True)

def prepare():
    pinned=read(C/'film-release.json')['revision'];changed=set()
    for file in sorted((C/'release').rglob('*')):
        if not file.is_file():continue
        key=file.relative_to(C/'release');dest=SITE/'antigravity'/key
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest)
        master=S/'release'/key;master.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,master)
        changed.add('antigravity/'+key.as_posix())
    updated={}
    for slug in TITLES:
        ident='shared_'+slug;entry=read(C/'entries'/(ident+'.json'))
        entry['film']='https://raw.githubusercontent.com/Leroieternel/leroieternel.github.io/'+pinned+'/media/antigravity/'+ident
        write(C/'entries'/(ident+'.json'),entry);write(S/'entries'/(ident+'.json'),entry);updated[ident]=entry
    ed=SITE/'antigravity/catalog.json';records=read(ed)
    assert set(updated)<=set(r['id'] for r in records)
    ed.write_text(json.dumps([updated.get(r['id'],r) for r in records],ensure_ascii=False,separators=(',',':')))
    maincat=SITE/'everyday-catalog.js';label,body=maincat.read_text().split('=',1);rows=json.loads(body.strip().rstrip(';'))
    assert set(updated)<=set(r['id'] for r in rows)
    rows=[main_fields(updated[r['id']]) if r['id'] in updated else r for r in rows]
    maincat.write_text(label+'= '+json.dumps(rows,ensure_ascii=False,separators=(',',':'))+';\n')
    write_directory(SITE,rows)
    for f,hook in [(SITE/'app.js',main),(SITE/'antigravity/app.js',edition),(S.parent/'web/app.js',edition)]:f.write_text(hook(f.read_text()))
    idx=SITE/'index.html';t=idx.read_text()
    for n in ['app.js','everyday-catalog.js']:t=re.sub(re.escape(n)+r'\?v=[\w-]+',n+'?v='+sha(SITE/n)[:12],t)
    idx.write_text(t)
    idx=SITE/'antigravity/index.html';t=idx.read_text();prev=re.search('data-build="([^"]+)"',t)[1]
    idx.write_text(t.replace(prev,sha(ed)[:12]))
    changed.update(['everyday-catalog.js','antigravity/catalog.json','despite/index.html','app.js','antigravity/app.js','index.html','antigravity/index.html'])
    for key in changed:
        dst=MIRROR/key;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SITE/key,dst)
    write(C/'deploy-files.json',sorted(changed));print('Prepared the two existing IDs within',len(rows),'DESPITE entries.',len(changed),'release paths.',flush=True)

def website():
    paths=['workcell-safety/'+i for i in read(C/'deploy-files.json')]
    rev=publish(WEB,paths,'main','Update hospital and bank studies with visible, measured consequences')
    write(C/'deployment.json',dict(website=rev,films=read(C/'film-release.json')['revision'],routes=['shared_hospital','shared_bank']));print('Published',rev,flush=True)

if __name__=='__main__':{'films':films,'prepare':prepare,'website':website}[sys.argv[1]]()
