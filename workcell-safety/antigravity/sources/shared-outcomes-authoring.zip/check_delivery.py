"""Confirm that the public website and both independent film pairs match the local release."""
from shared import *
from concurrent.futures import ThreadPoolExecutor
import time
import requests

deployment=read(C/'deployment.json')
site='https://mcxiangalds.com/workcell-safety/'
rev=deployment['website'];pin=deployment['films']
api='https://api.github.com/repos/Leroieternel/leroieternel.github.io/'

def fetch(url,**kw):
    res=requests.get(url,timeout=30,**kw);res.raise_for_status();return res

def media(pair):
    ident,branch=pair
    url='https://raw.githubusercontent.com/Leroieternel/leroieternel.github.io/'+pin+'/media/antigravity/'+ident+'/'+branch+'.mp4'
    expected=read(C/'release'/ident/'video-verification.json')[branch]['sha256']
    assert hashlib.sha256(fetch(url).content).hexdigest()==expected
    return ident+'/'+branch

with ThreadPoolExecutor(max_workers=3) as pool:
    print('Public media verified:',list(pool.map(media,[(i,k) for i in deployment['routes'] for k in ('safe','unsafe','event')])),flush=True)
status=''
for n in range(70):
    try:
        if n%3==0:
            wf=fetch(api+'actions/runs',params={'head_sha':rev,'per_page':4}).json().get('workflow_runs',[])
            if wf:
                state=wf[0]['status'];conclusion=wf[0].get('conclusion')
                if state!=status:print('Pages',state,conclusion or '',flush=True)
                status=state
                if state=='completed' and conclusion not in (None,'success'):raise RuntimeError('Pages '+str(conclusion))
        params=dict(v=rev[:12],probe=n)
        audit=fetch(site+'antigravity/shared_hospital/physics-audit.json',params=params).json()
        deck=audit['branches']['unsafe']['final_tilt_deg']
        catalog=fetch(site+'everyday-catalog.js',params=params).text
        if audit['branches']['unsafe'].get('hands_clear_s') and audit['branches']['unsafe']['final_floor_N']>0 and pin in catalog:break
    except (requests.RequestException,ValueError,KeyError):pass
    time.sleep(6)
else:raise TimeoutError('Public domain did not serve the new revision')

def asset(pair):
    ident,name=pair
    f=C/'release'/ident/name
    for attempt in range(5):
        try:
            response=fetch(site+'antigravity/'+ident+'/'+name,params={'v':rev[:12],'probe':attempt})
            assert hashlib.sha256(response.content).hexdigest()==sha(f)
            return f.name
        except (AssertionError,requests.RequestException):
            if attempt==4:raise
            time.sleep(2)
files=[(i,n) for i in deployment['routes'] for n in ('metric.png','force.png','reaction.png','sequence.jpg','performance.json','physics-audit.json','revision-prompt.txt','mesh-check.json','video-verification.json','source-example.json','event_poster.jpg')]
if 'shared_hospital' in deployment['routes']:files.append(('shared_hospital','stance-comparison.jpg'))
if 'shared_bank' in deployment['routes']:files.append(('shared_bank','observer-check.json'))
with ThreadPoolExecutor(max_workers=5) as pool:list(pool.map(asset,files))
print('Public catalogs,',3*len(deployment['routes']),'films and',len(files),'graphs, images and evidence records verified.',flush=True)
