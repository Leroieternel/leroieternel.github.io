"""Play all six pinned movies through the existing site at a phone viewport."""
from shared import *
from narrative import TITLES,event
from websockets.asyncio.client import connect
from functools import partial
import asyncio
import http.server
import os
import tempfile
import threading
import subprocess
import urllib.request

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*_):pass

async def exercise(live):
    server=None
    if live:base='https://mcxiangalds.com/workcell-safety/'
    else:
        handler=partial(Quiet,directory=str(ROOT/'.runtime/website'))
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        base=f'http://127.0.0.1:{server.server_port}/workcell-safety/'
    with tempfile.TemporaryDirectory(prefix='shared-outcomes-browser-') as tmp:
        proc=subprocess.Popen(['/opt/google/chrome/chrome','--headless','--disable-gpu','--disable-background-networking','--no-first-run','--autoplay-policy=no-user-gesture-required','--remote-debugging-port=0','--user-data-dir='+tmp,'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            fn=Path(tmp)/'DevToolsActivePort'
            for _ in range(120):
                if fn.is_file():break
                await asyncio.sleep(.12)
            port=fn.read_text().splitlines()[0];page=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/json/list'))[0]
            async with connect(page['webSocketDebuggerUrl'],max_size=2**22) as ws:
                uid=0
                async def cmd(method,**params):
                    nonlocal uid
                    uid+=1;await ws.send(json.dumps(dict(id=uid,method=method,params=params)))
                    while True:
                        res=json.loads(await ws.recv())
                        if res.get('id')==uid:
                            assert not res.get('error'),res
                            return res['result']
                async def js(code):
                    r=await cmd('Runtime.evaluate',expression=code,returnByValue=True)
                    assert not r.get('exceptionDetails'),(code,r)
                    return r['result'].get('value')
                async def wait(code):
                    for i in range(220):
                        if await js(code):return
                        await asyncio.sleep(.12)
                    raise AssertionError(code)
                await cmd('Emulation.setDeviceMetricsOverride',width=390,height=844,deviceScaleFactor=1,mobile=True)
                for route in ('','antigravity/'):
                    for slug,title in TITLES.items():
                        ident='shared_'+slug
                        pin=read(C/'entries'/(ident+'.json'))['film'].split('/media/')[0].rsplit('/',1)[1]
                        await cmd('Page.navigate',url=base+route+'#'+ident);await wait("document.querySelector('h1')?.textContent==="+json.dumps(title))
                        await wait("document.querySelectorAll('#players video').length===2 && document.querySelector('#event-replay video')!==null")
                        assert await js("[...document.querySelectorAll('#players source')].every(x=>x.src.includes('/"+pin+"/media/antigravity/"+ident+"/'))")
                        assert await js("document.querySelectorAll('#charts img').length>=3 && document.querySelectorAll('#plans button').length>=10")
                        assert await js("document.querySelector('#players video').getBoundingClientRect().right<=innerWidth+2")
                        assert await js("[...document.links].some(a=>a.href.includes('revision-prompt.txt'))")
                        await js("document.querySelectorAll('#players video').forEach(v=>v.muted=true);document.querySelector('#play').click()")
                        await wait("[...document.querySelectorAll('#players video')].every(v=>v.currentTime>.13 && v.videoWidth===1920)")
                        await js("document.querySelector('#event').click()")
                        await wait("[...document.querySelectorAll('#players video')].every(v=>Math.abs(v.currentTime-"+str(event(slug))+")<.075)")
                        await js("const p=document.querySelector('#event-replay video');p.muted=true;p.play().catch(()=>{})".replace('const p=','var p='))
                        await wait("document.querySelector('#event-replay video').currentTime>.10 && document.querySelector('#event-replay video').videoHeight===1192")
                        await js("document.querySelector('#event-replay video').pause()")
                        if slug=='hospital':
                            await wait("Array.from(document.images).some(img=>img.src.includes('stance-comparison.jpg'))")
                            await js("Array.from(document.images).find(img=>img.src.includes('stance-comparison.jpg')).loading='eager'")
                            await wait("Array.from(document.images).some(img=>img.src.includes('stance-comparison.jpg') && img.complete && img.naturalWidth===1080)")
                            assert await js("document.querySelector('#event-replay video').currentSrc.includes('/"+pin+"/media/antigravity/shared_hospital/event.mp4')")
                            assert await js("Math.abs(document.querySelector('#event-replay video').duration-11.28)<.05")
                            assert await js("document.querySelector('#players').textContent.includes('stays upright')")
                await cmd('Page.navigate',url=base+'despite/?collection=shared')
                await wait("document.querySelector('#shared-cohort')?.getAttribute('aria-current')==='page'")
                assert await js("document.querySelectorAll('li[data-cohort]:not([hidden])').length===10")
                for slug,title in TITLES.items():
                    assert await js("[...document.querySelectorAll('li[data-cohort=shared] a')].some(a=>a.hash==='#shared_"+slug+"' && a.textContent.includes("+json.dumps(title)+"))")
                print(('Public' if live else 'Local')+' two-route phone check passed: six films, both paired players, event seeks, graphs, prompts and the ten-task directory.',flush=True)
        finally:
            proc.terminate();proc.wait(timeout=12)
            if server:server.shutdown()

if __name__=='__main__':asyncio.run(exercise('--live' in sys.argv))
