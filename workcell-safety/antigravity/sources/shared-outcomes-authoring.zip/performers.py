"""Retarget the captured CMU slip onto the original nurse; keep the native clinic visitor and customer rigs."""
from shared import *
import io
from scipy.spatial.transform import Rotation
import human
from generated.hospital import aftermath

def unit(v):
    return v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-12)

def merge_rotation(first,second,weight):
    a=Rotation.from_matrix(first.reshape(-1,3,3)).as_quat().reshape(*first.shape[:-2],4)
    b=Rotation.from_matrix(second.reshape(-1,3,3)).as_quat().reshape(a.shape)
    b*=np.where(np.sum(a*b,axis=-1,keepdims=True)<0,-1,1)
    q=unit(a*(1-weight[:,None,None])+b*weight[:,None,None])
    return Rotation.from_quat(q.reshape(-1,4)).as_matrix().reshape(first.shape)

def pose(bind,parent,rot,hip,hip_index):
    n=len(rot);p=np.zeros((n,len(parent),3))
    for j,up in enumerate(parent):
        if j==hip_index:p[:,j]=hip
        elif up<0:p[:,j]=hip-bind[hip_index]+bind[j]
        else:p[:,j]=p[:,up]+rot[:,up]@(bind[j]-bind[up])
    trans=np.concatenate((rot,(p-np.einsum('tjab,jb->tja',rot,bind))[:,:,:,None]),axis=3)
    return p,trans

def all_skin_min(actor,tf):
    low=np.full(len(tf),np.inf)
    for p in (S/'assets/people'/actor).glob('*.npz'):
        if p.stem=='skeleton':continue
        m=dict(np.load(p))
        for j,x in enumerate(tf):low[j]=min(low[j],human.skin(m,x)[:,2].min())
    return low

def clinical_cast():
    p=C/'runs/hospital';rig=dict(np.load(S/'assets/people/nurse/skeleton.npz'));bind=rig['bind'];parent=rig['parent']
    n=rig['names'].tolist();idx=n.index;actor=dict(np.load(S/'runs/hospital/human.npz'))
    offset=np.array([3.78,-.04,0.])
    safe=actor['trans'].copy();safe[:,:,:,3]+=offset;sj=actor['joints']+offset
    np.savez_compressed(p/'safe-person.npz',trans=safe,joints=sj,names=n)
    when=read(p/'unsafe.json')['first_contact_s'];start=when+.30
    sys.path.insert(0,str(ROOT/'.runtime/c3d-reader'));import c3d
    raw=bytearray((C/'assets/90_18.c3d').read_bytes())
    # This file has zero analog channels and sets the unused samples-per-frame header field to one.
    assert int.from_bytes(raw[4:6],'little')==0
    raw[18:20]=bytes(2)
    reader=c3d.Reader(io.BytesIO(raw));labels=[x.strip().split(':')[-1] for x in reader.point_labels]
    frames=np.stack([q for _,q,_ in reader.read_frames()]);assert np.all(frames[:,:,3]>=0)
    clock=np.array([aftermath(when,t) for t in T])
    local=np.clip(58+clock*reader.point_rate,0,len(frames)-1.001);i=local.astype(int);f=local-i
    points=(frames[i,:,:3]*(1-f[:,None,None])+frames[i+1,:,:3]*f[:,None,None])*.001
    side0=np.mean(points[0,[labels.index('LFWT'),labels.index('LBWT')]],0)-np.mean(points[0,[labels.index('RFWT'),labels.index('RBWT')]],0)
    # Rotate the capture's forward to the same northbound corridor walk.
    angle=np.pi-np.arctan2(side0[1],side0[0])
    points=points@Rotation.from_euler('z',angle).as_matrix().T
    pt={a:points[:,j] for j,a in enumerate(labels)}
    def avg(*names):return np.mean([pt[k] for k in names],0)
    hip=avg('LFWT','RFWT','LBWT','RBWT');shoulder=avg('LSHO','RSHO');head=avg('LFHD','RFHD','LBHD','RBHD')
    def basis(tgtx,tgtz,restx,restz):
        return human.frame(tgtx,tgtz)@human.frame(restx,restz).T
    up=bind[idx('NeckTwist01')]-bind[idx('Hip')]
    pelvis=basis(avg('LFWT','LBWT')-avg('RFWT','RBWT'),pt['T10']-hip,
                 bind[idx('L_Thigh')]-bind[idx('R_Thigh')],up)
    chest=basis(pt['LSHO']-pt['RSHO'],pt['C7']-pt['T10'],
                bind[idx('L_Upperarm')]-bind[idx('R_Upperarm')],up)
    hx=avg('LFHD','LBHD')-avg('RFHD','RBHD');hf=avg('LFHD','RFHD')-avg('LBHD','RBHD')
    skull=basis(hx,np.cross(hf,hx),np.array([1,0,0]),np.array([0,0,1]))
    rots=np.empty((301,len(n),3,3));maps={}
    for sd in 'LR':
        maps.update({sd+'_Upperarm':('Forearm',pt[sd+'ELB']-pt[sd+'SHO']),
            sd+'_Forearm':('Hand',avg(sd+'WRA',sd+'WRB')-pt[sd+'ELB']),
            sd+'_Hand':('Mid1',pt[sd+'FIN']-avg(sd+'WRA',sd+'WRB')),
            sd+'_Thigh':('Calf',pt[sd+'KNE']-avg(sd+'FWT',sd+'BWT')),
            sd+'_Calf':('Foot',pt[sd+'ANK']-pt[sd+'KNE']),
            sd+'_Foot':('ToeBase',pt[sd+'TOE']-pt[sd+'HEE'])})
    for j,name in enumerate(n):
        orig=rots[:,parent[j]] if parent[j]>=0 else np.broadcast_to(np.eye(3),(301,3,3))
        if name in ('Hip','Pelvis'):r=pelvis
        elif name in ('Waist','Spine01','Spine02','NeckTwist01'):r=chest
        elif name in ('NeckTwist02','Head'):r=skull
        elif name in maps:
            child,mapped=maps[name];seg=bind[idx(name[:2]+child)]-bind[j]
            r=human.align(orig@seg,mapped)@orig
        else:r=orig
        rots[:,j]=r
    w=smooth(clock/.28);j0=int(np.ceil(start*25));anchor=sj[j0,idx('Hip')]
    scale=np.linalg.norm(up)/np.linalg.norm(shoulder[0]-hip[0])
    root=anchor+(hip-hip[0])*scale
    # Carry the actor's pre-cue forward velocity through the transition into the capture.
    v=(sj[j0,idx('Hip')]-sj[j0-3,idx('Hip')])/.12
    root[:,:2]+=(.18*(1-np.exp(-clock/.18)))[:,None]*v[None,:2]
    rr=merge_rotation(safe[:,:,:,:3],rots,w)
    center=sj[:,idx('Hip')]*(1-w[:,None])+root*w[:,None]
    joints,tf=pose(bind,parent,rr,center,idx('Hip'))
    low=all_skin_min('nurse',tf)
    dz=np.where(clock>0.,.0008-low,0.)
    tf[:,:,:,3]+=np.stack((np.zeros(301),np.zeros(301),dz),axis=1)[:,None,:]
    joints[:,:,2]+=dz[:,None]
    tf[clock==0]=safe[clock==0];joints[clock==0]=sj[clock==0]
    np.savez_compressed(p/'unsafe-person.npz',trans=tf.astype('f'),joints=joints.astype('f'),names=n)
    write(p/'performance.json',{'actor':'NVIDIA Isaac People F_Medical_01','clip':'Carnegie Mellon Graphics Lab 90_18',
        'source':'http://mocap.cs.cmu.edu/subjects/90/90_18.c3d','capture_sha256':sha(C/'assets/90_18.c3d'),
        'capture_rate_Hz':float(reader.point_rate),'reaction_cue_s':start,'same_pre_event_samples':int(np.sum(clock==0)),
        'safe_final_hip_m':float(sj[-1,idx('Hip'),2]),'unsafe_final_hip_m':float(joints[-1,idx('Hip'),2]),
        'unsafe_final_head_m':float(joints[-1,idx('Head'),2]),'ground_contact_model':'Performance grounded using original skinned mesh, with no human force or injury calculation.'})

def visitor():
    p=C/'runs/bank';p.mkdir(parents=True,exist_ok=True);path=p/'visitor'
    human.build('bank',profile=('doctor',(.77,-1.41),-164,'observe',.80),output=path)
    a=dict(np.load(path/'human.npz'));names=a['names'].tolist();j=a['joints'];tf=a['trans'];neck=names.index('NeckTwist02')
    rig=dict(np.load(S/'assets/people/doctor/skeleton.npz'));par=rig['parent'];children={neck}
    for k,pp in enumerate(par):
        if pp in children:children.add(k)
    eyes=[names.index(v) for v in ('L_Eye','R_Eye')];pivot=j[:,neck].copy();eye=j[:,eyes].mean(1)
    front=tf[:,names.index('Head'),:,:3]@np.array([0.,-1.,0.])
    aim=np.array([.395,-.139,.895])-eye;rot=human.align(front,aim);ix=sorted(children)
    tf[:,ix,:,:3]=rot[:,None]@tf[:,ix,:,:3]
    translations=tf[:,:,:,3]
    translations[:,ix]=np.einsum('tij,tkj->tki',rot,translations[:,ix]-pivot[:,None])+pivot[:,None]
    j[:,ix]=np.einsum('tij,tkj->tki',rot,j[:,ix]-pivot[:,None])+pivot[:,None]
    a['eye']=j[:,eyes].mean(1);a['gaze']=unit(tf[:,names.index('Head'),:,:3]@np.array([0.,-1.,0.]))
    np.savez_compressed(p/'visitor.npz',**a)

def customer():
    p=C/'runs/bank';hold=read(p/'unsafe.json')['hold_s']
    original=dict(np.load(S/'runs/bank/human.npz'))
    np.savez_compressed(p/'safe-person.npz',**original)
    path=p/'intervention'
    human.build('bank',profile=('business',(.92,.75),-57,'consent',.91),output=path,signal_time=hold+.19,hold_gesture=True)
    a=dict(np.load(path/'human.npz'));np.savez_compressed(p/'unsafe-person.npz',**a)
    n=a['names'].tolist();up=max(float((a['joints'][:,n.index(k),2]-original['joints'][:,n.index(k),2]).max()) for k in ('R_Hand','L_Hand'))
    same=np.flatnonzero(T<=hold+.19);assert np.allclose(a['trans'][same],original['trans'][same],atol=2e-6)
    write(p/'performance.json',dict(customer='NVIDIA Isaac People F_Business_02',visitor='NVIDIA Isaac People M_Medical_01',
          footage='Native stand_idle_loop and stand_idle_wave_loop on the customer, native idle with a posed head gaze on the visitor.',
          reaction_cue_s=hold+.19,maximum_extra_wrist_rise_m=up,same_pre_event_samples=len(same)))
    assert up>.17,up

if __name__=='__main__':
    for fn in sys.argv[1:] or ('hospital','visitor','customer'):
        {'hospital':clinical_cast,'visitor':visitor,'customer':customer}[fn]()
