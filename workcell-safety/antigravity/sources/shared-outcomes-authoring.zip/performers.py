"""Prepare the native clinical handling, visitor and customer performances."""
from shared import *
from scipy.spatial.transform import Rotation
import human

def unit(v):
    return v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-12)

def merge_rotation(first,second,weight):
    a=Rotation.from_matrix(first.reshape(-1,3,3)).as_quat().reshape(*first.shape[:-2],4)
    b=Rotation.from_matrix(second.reshape(-1,3,3)).as_quat().reshape(a.shape)
    b*=np.where(np.sum(a*b,axis=-1,keepdims=True)<0,-1,1)
    q=unit(a*(1-weight[:,None,None])+b*weight[:,None,None])
    return Rotation.from_quat(q.reshape(-1,4)).as_matrix().reshape(first.shape)

def pose(bind,parent,rot,hip,hip_index):
    n=len(rot);p=np.zeros((n,len(parent),3))
    for j,up in enumerate(parent):
        if j==hip_index:p[:,j]=hip
        elif up<0:p[:,j]=hip-bind[hip_index]+bind[j]
        else:p[:,j]=p[:,up]+rot[:,up]@(bind[j]-bind[up])
    trans=np.concatenate((rot,(p-np.einsum('tjab,jb->tja',rot,bind))[:,:,:,None]),axis=3)
    return p,trans

def all_skin_min(actor,tf):
    low=np.full(len(tf),np.inf)
    for p in (S/'assets/people'/actor).glob('*.npz'):
        if p.stem=='skeleton':continue
        m=dict(np.load(p))
        for j,x in enumerate(tf):low[j]=min(low[j],human.skin(m,x)[:,2].min())
    return low

def clinical_cast():
    from clinical_rig import build
    build()

def visitor():
    p=C/'runs/bank';p.mkdir(parents=True,exist_ok=True);path=p/'visitor'
    human.build('bank',profile=('doctor',(.77,-1.41),-164,'observe',.80),output=path)
    a=dict(np.load(path/'human.npz'));names=a['names'].tolist();j=a['joints'];tf=a['trans'];neck=names.index('NeckTwist02')
    rig=dict(np.load(S/'assets/people/doctor/skeleton.npz'));par=rig['parent'];children={neck}
    for k,pp in enumerate(par):
        if pp in children:children.add(k)
    eyes=[names.index(v) for v in ('L_Eye','R_Eye')];pivot=j[:,neck].copy();eye=j[:,eyes].mean(1)
    front=tf[:,names.index('Head'),:,:3]@np.array([0.,-1.,0.])
    aim=np.array([.395,-.139,.895])-eye;rot=human.align(front,aim);ix=sorted(children)
    tf[:,ix,:,:3]=rot[:,None]@tf[:,ix,:,:3]
    translations=tf[:,:,:,3]
    translations[:,ix]=np.einsum('tij,tkj->tki',rot,translations[:,ix]-pivot[:,None])+pivot[:,None]
    j[:,ix]=np.einsum('tij,tkj->tki',rot,j[:,ix]-pivot[:,None])+pivot[:,None]
    a['eye']=j[:,eyes].mean(1);a['gaze']=unit(tf[:,names.index('Head'),:,:3]@np.array([0.,-1.,0.]))
    np.savez_compressed(p/'visitor.npz',**a)

def customer():
    p=C/'runs/bank';hold=read(p/'unsafe.json')['hold_s']
    original=dict(np.load(S/'runs/bank/human.npz'))
    np.savez_compressed(p/'safe-person.npz',**original)
    path=p/'intervention'
    human.build('bank',profile=('business',(.92,.75),-57,'consent',.91),output=path,signal_time=hold+.19,hold_gesture=True)
    a=dict(np.load(path/'human.npz'));np.savez_compressed(p/'unsafe-person.npz',**a)
    n=a['names'].tolist();up=max(float((a['joints'][:,n.index(k),2]-original['joints'][:,n.index(k),2]).max()) for k in ('R_Hand','L_Hand'))
    same=np.flatnonzero(T<=hold+.19);assert np.allclose(a['trans'][same],original['trans'][same],atol=2e-6)
    write(p/'performance.json',dict(customer='NVIDIA Isaac People F_Business_02',visitor='NVIDIA Isaac People M_Medical_01',
          footage='Native stand_idle_loop and stand_idle_wave_loop on the customer, native idle with a posed head gaze on the visitor.',
          reaction_cue_s=hold+.19,maximum_extra_wrist_rise_m=up,same_pre_event_samples=len(same)))
    assert up>.17,up

if __name__=='__main__':
    for fn in sys.argv[1:] or ('hospital','visitor','customer'):
        {'hospital':clinical_cast,'visitor':visitor,'customer':customer}[fn]()
