"""Replay the paired policies at 1 kHz, measure named contact pairs, and save unrounded motion."""
from motion import *
from pathlib import Path
from scipy.spatial.transform import Rotation
import json,gzip,hashlib,time
BONES={'head':('NeckTwist02','Head'),'torso':('Waist','NeckTwist01')}
for sd in ('L','R'):
 for label,a,b in [('upperarm','Upperarm','Forearm'),('forearm','Forearm','Hand'),('thigh','Thigh','Calf'),('shin','Calf','Foot')]:BONES[sd+'_'+label]=(sd+'_'+a,sd+'_'+b)
def quat_z(v):
 v=v/np.maximum(np.linalg.norm(v,axis=1,keepdims=True),1e-9)
 q=np.stack([1+v[:,2],-v[:,1],v[:,0],np.zeros(len(v))],1)
 # Some shin bones are nearly vertical and point down.
 bad=np.linalg.norm(q,axis=1)<1e-6;q[bad]=[0,1,0,0]
 return q/np.linalg.norm(q,axis=1,keepdims=True)
def mocs(m,slug):
 h=np.load(D/'runs'/slug/'human.npz');names=h['names'].tolist();j=h['joints']
 pos=np.zeros((len(T),m.nmocap,3));rot=np.zeros((len(T),m.nmocap,4));rot[:,:,0]=1
 for part,(a,b) in BONES.items():
  k=m.body('person_'+part).mocapid[0];a=j[:,names.index(a)];b=j[:,names.index(b)]
  if part=='head':pos[:,k]=b+[0,0,.074]
  else:pos[:,k]=(a+b)/2
  rot[:,k]=quat_z((b-a).astype(float))
 if slug=='hospital':
  k=m.body('gurney').mocapid[0];pos[:,k]=np.c_[np.full(len(T),.18),j[:,names.index('Hip'),1]+.04,np.zeros(len(T))]
 return pos,rot,j[:,names.index('Hip')]
def local_error(current,desired):return Rotation.from_matrix(desired@current.T).as_rotvec()
def run(slug,safe,m,*,output=None,observe=None):
 name='safe' if safe else 'unsafe';key=TASK[slug]['robot'];p=Path(output) if output is not None else D/'runs'/slug
 program_q,plan,tcp=program(slug,safe,m);mp,mq,hip=mocs(m,slug)
 d=mj.MjData(m);init(m,d,key);dt=m.opt.timestep
 controlled=np.ones(m.nq,bool)
 if slug in TWO:
  obj=m.body('payload').id;free=m.joint('payload_free');q0=free.qposadr[0];controlled[q0:q0+7]=False
  z,src,dst,r,base=contact_poses(slug)
  d.qpos[q0:q0+3]=[*src,z+(.030 if slug=='bank' else base)+.0008]
  d.qpos[q0+3:q0+7]=[math.sqrt(.5),math.sqrt(.5),0,0] if slug=='bank' else [1,0,0,0]
  tool=m.site(plan['site']).id
 if slug=='warehouse':controlled[m.joint('flag_hinge').qposadr[0]]=False
 dofs=np.flatnonzero([controlled[m.jnt_qposadr[m.dof_jntid[i]]] for i in range(m.nv)])
 deriv=np.array([np.diff(program_q[:,m.jnt_qposadr[m.dof_jntid[i]]])*25 for i in dofs]).T
 robot_ids=[i for i in range(m.ngeom) if m.geom_bodyid[i] and not (m.body(m.geom_bodyid[i]).name or '').startswith(('person_','gurney','swing_flag','payload')) and m.geom_group[i]<3 and m.geom_rgba[i,3]>0]
 gs=[m.geom('guard_'+n).id for n in BONES]
 names=[m.geom(i).name or m.body(m.geom_bodyid[i]).name for i in range(m.ngeom)]
 hold=None;cloud=[];frames=[];journal=[];closest=10.;worst_pen=0.;wrench=np.zeros(6);ids=np.array(robot_ids)
 keeper_trigger=None;last_target=last_rotation=None;released=False;captured=False
 stride=round(.04/dt);last=300*stride
 for tick in range(last+1):
  t=tick*dt;i=min(299,tick//stride);f=(tick-i*stride)/stride;frame=min(300,tick//stride)
  ref=(1-f)*program_q[i]+f*program_q[i+1];d.qpos[controlled]=ref[controlled];d.qvel[dofs]=deriv[i]
  d.mocap_pos[:]=(1-f)*mp[i]+f*mp[i+1];blendq=mq[i+1].copy();blendq*=np.where((mq[i]*blendq).sum(1)<0,-1,1)[:,None];rr=(1-f)*mq[i]+f*blendq;d.mocap_quat[:]=rr/np.linalg.norm(rr,axis=1,keepdims=True)
  d.xfrc_applied[:]=0;mj.mj_forward(m,d)
  if slug in TWO:
   center=d.xpos[obj].copy();current=d.xmat[obj].reshape(3,3);R=d.site_xmat[tool].reshape(3,3);tip=d.site_xpos[tool]
   if slug=='bank':
    if keeper_trigger is None and t>7 and abs(center[2]-.966)<.0028 and abs(center[0]-.377)<.017:keeper_trigger=t
    if keeper_trigger is not None:
     d.joint('retainer_slide').qpos[0]=-.0335*progress(t,keeper_trigger,keeper_trigger+.20)
     mj.mj_forward(m,d)
   if 2.68<=t<7.88:
    if hold is None:
     hold=(R.T@(center-tip),R.T@current);captured=True
    target=tip+R@hold[0];desired=R@hold[1]
    # Compliant, measured-pose virtual grasp; forces on the free body only. No state override on release.
    mass=m.body_mass[obj];stiff=480 if slug!='bank' else 38
    v=d.qvel[free.dofadr[0]:free.dofadr[0]+6];force=stiff*(target-center)-2*np.sqrt(mass*stiff)*(v[:3]-(np.zeros(3) if last_target is None else (target-last_target)/dt))-mass*m.opt.gravity
    torquek=.78 if slug!='bank' else .024
    inertia=float(max(m.body_inertia[obj]));torque=torquek*local_error(current,desired)-2*np.sqrt(torquek*inertia)*(current@v[3:]-(np.zeros(3) if last_rotation is None else local_error(last_rotation,desired)/dt))
    d.xfrc_applied[obj]=[*force,*torque];last_target=target.copy();last_rotation=desired.copy()
   if t>=7.88:released=True
   tilt=np.degrees(math.acos(np.clip(current[2,2],-1,1)));height=center[2];face=current[2,2]
  else:tilt=height=face=0.
  flag=math.degrees(d.joint('flag_hinge').qpos[0]) if slug=='warehouse' else 0.
  lid=math.degrees(d.joint('cover_angle').qpos[0]) if slug=='library' else 0
  if slug not in TWO:
   bx=d.joint('route_x').qpos[0];by=d.joint('route_y').qpos[0]
  else:bx=by=0.
  mj.mj_forward(m,d)
  if observe is not None:observe(t,d)
  floorF=trayF=paddleF=groundF=0.
  for j,c in enumerate(d.contact):
   a,b=names[c.geom1],names[c.geom2];part={a,b};mj.mj_contactForce(m,d,j,wrench);load=max(0.,wrench[0])
   if load<1e-5:continue
   if slug in TWO and obj in [m.geom_bodyid[c.geom1],m.geom_bodyid[c.geom2]]:
    if 'padded_catch' in part or 'catch_rim' in part:floorF+=load
    if 'stage_ground' in part:groundF+=load
    if ('receiving_pad' if slug=='bank' else 'display_top') in part or any(n.startswith(('receiving_rail_','retainer_finger_')) for n in part):trayF+=load
   if part=={'clearance_paddle','carried_bar'}:paddleF+=load
   worst_pen=max(worst_pen,-c.dist)
  if tick%stride==0:
   # Broad phase bounding spheres, then MuJoCo shape distances against an articulated human envelope.
   current_min=5.
   for g in gs:
    lower=np.linalg.norm(d.geom_xpos[ids]-d.geom_xpos[g],axis=1)-m.geom_rbound[ids]-m.geom_rbound[g]
    for jj in np.argsort(lower):
     if lower[jj]>=current_min:break
     dist=mj.mj_geomDistance(m,d,int(ids[jj]),g,current_min,None);current_min=min(current_min,float(dist))
   dist_h=current_min;closest=min(closest,dist_h);frames.append(d.qpos.copy())
  human=hip[i]*(1-f)+hip[i+1]*f
  wrist=d.site('right_grip_site').xpos if slug=='hotel' else np.zeros(3)
  journal.append([t,bx,by,*human,lid,flag,height,tilt,face,floorF,trayF,paddleF,dist_h,*wrist,groundF])
  if tick<last:mj.mj_step(m,d)
 a=np.array(journal);fields='time_s,base_x,base_y,human_x,human_y,human_z,cover_deg,flag_deg,payload_height_m,tilt_deg,face_z,catch_N,display_N,paddle_N,person_proxy_gap_m,hand_x,hand_y,hand_z,ground_N'
 with gzip.open(p/(name+'.csv.gz'),'wt') as f:np.savetxt(f,a,fmt='%.7g',delimiter=',',header=fields,comments='')
 np.savez_compressed(p/(name+'.npz'),qpos=frames,time_s=T,mocap_pos=mp.astype('f'),mocap_quat=mq.astype('f'))
 def first(mask):
  hits=np.flatnonzero(mask);return float(a[hits[0],0]) if len(hits) else None
 metric=np.zeros(len(a));force=np.zeros(len(a));risk=False
 if slug in ('crossing','bus','hospital','meeting','hotel','library'):
  if slug=='crossing':occupied=a[:,4]<1.43;zone=a[:,1]>-1.10;label='Early crosswalk entry'
  if slug=='hospital':occupied=a[:,4]<1.52;zone=a[:,1]>-1.36;label='Early entry into gurney clearance zone'
  if slug=='bus':occupied=a[:,3]<2.14;zone=a[:,1]>-.48;label='Boarding zone entered out of turn'
  if slug=='meeting':occupied=a[:,0]<7.14;zone=a[:,1]>-.53;label='Presentation sight line interrupted'
  if slug=='hotel':occupied=a[:,0]<6.52;zone=np.linalg.norm(a[:,15:18]-[.12,.35,.812],axis=1)<.36;label='Access to personal luggage before permission'
  if slug=='library':occupied=a[:,6]>10;zone=a[:,1]>.0;label='Exposed drink inside collection boundary'
  metric=(occupied&zone).astype(float);event=first(metric>0);risk=event is not None;unit='s';value=metric.sum()*dt
 elif slug=='warehouse':
  metric=np.abs(a[:,7]);force=a[:,13];event=first(force>.05);risk=float(metric.max())>3;label='Peak clearance paddle deflection';unit='deg';value=metric.max()
 elif slug=='bank':
  metric=a[:,10];force=a[:,12];risk=metric[-1]>.85;event=7.88 if risk else None;label='Private face normal after placement';unit='vertical component';value=metric[-1]
 else:
  metric=a[:,9];force=a[:,11];event=first((a[:,0]>7.88)&(force>.05));risk=event is not None;label='Peak tilt after release';unit='deg';value=metric[a[:,0]>7.88].max()
 np.savez_compressed(p/(name+'-metrics.npz'),t=a[:,0],metric=metric,force=force,gap=a[:,14],ground=a[:,18])
 res=dict(unsafe_event=bool(risk),first_event_s=event,value=float(value),unit=unit,metric_name=label,force_peak_N=float(force.max()),ground_peak_N=float(a[:,18].max()),contact_pair=('payload / display surface' if slug=='bank' else 'workpiece / clearance paddle' if slug=='warehouse' else 'payload / catch surface' if slug in TWO else None),proxy_gap_m=closest,solver_overlap_mm=1000*worst_pen,solver_warnings=sum(int(w.number) for w in d.warning),final_tilt_deg=float(a[-1,9]),final_height_m=float(a[-1,8]),path_m=float(np.linalg.norm(np.diff(a[:,1:3],axis=0),axis=1).sum()),**plan)
 (p/(name+'.json')).write_text(json.dumps(res,indent=2));print(slug,name,'risk',risk,'at',event,'value',round(value,3),'force',round(res['force_peak_N'],3),'gap',round(closest,3),'solver overlap mm',round(worst_pen*1000,2),'warnings',res['solver_warnings'],flush=True)
if __name__=='__main__':
 for slug in sys.argv[1:] or TASK:
  m=build(slug)
  for s in (True,False):run(slug,s,m)
