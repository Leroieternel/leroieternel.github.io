"""Retarget native Isaac People clips to each subject at their own proportions and plant the support sole."""
from pathlib import Path
from functools import lru_cache
import json,math,sys
import numpy as np
from scipy.spatial.transform import Rotation
D=Path(__file__).resolve().parent;P=D/'assets/people';T=np.arange(301)/25
# actor, origin, heading in degrees from native forward (-y), performance, playback rate
CAST={
'crossing':('business',(0,-2.52),180,'walking',.80),'market':('business',(.46,1.22),-9,'point',.77),
'bus':('business',(.20,.85),90,'queue',.72),'hospital':('nurse',(-.88,-2.52),180,'walking',.78),
'meeting':('business',(.62,1.32),-19,'talk',.76),'museum':('doctor',(-.75,1.06),35,'observe',.80),
'hotel':('business',(.12,1.04),-15,'consent',.82),'bank':('business',(.92,.75),-57,'observe',.91),
'library':('business',(2.56,1.37),-90,'walking',.79),'warehouse':('worker',(1.12,1.62),-29,'observe',.74)}
S={'idle':'stand_idle_loop','walking':'stand_walk_loop_in_place','point':'push_button','talk':'stand_idle_wave_loop','signal':'stand_idle_wave_loop'}
def ease(x):
 x=np.clip(x,0,1);return x*x*(3-2*x)
@lru_cache(None)
def clip(key):return dict(np.load(P/'Animations'/(S[key]+'.skelanim.npz')))
def sample(key,tm):
 c=clip(key);tm=tm%c['times'][-1];j=np.searchsorted(c['times'],tm,side='right').clip(1,len(c['times'])-1)
 f=((tm-c['times'][j-1])/(c['times'][j]-c['times'][j-1]))[:,None,None]
 return c['pos'][j-1]*(1-f)+c['pos'][j]*f
def unit(x):
 return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-10)
def frame(a,b):
 a=unit(a);c=unit(np.cross(a,b));return np.stack((a,np.cross(c,a),c),axis=-1)
def align(a,b):
 a=unit(a);b=unit(b);v=np.cross(a,b);z=np.zeros_like(v[:,0]);x,y,w=v.T
 K=np.stack((z,-w,y,w,z,-x,-y,x,z),axis=-1).reshape(-1,3,3)
 return np.eye(3)+K+(K@K)/np.maximum(1+(a*b).sum(-1),1e-6)[:,None,None]
mainmap={'Hip':'Pelvis','Pelvis':'Pelvis','Waist':'Spine1','Spine01':'Spine2','Spine02':'Chest','NeckTwist01':'Neck1','NeckTwist02':'Neck2','Head':'Head'}
pairs={'Thigh':'UpLeg','Calf':'LoLeg','Foot':'Ankle','ToeBase':'Ball','Clavicle':'Clavicle','Upperarm':'UpArm','Forearm':'LoArm','Hand':'Wrist'}
for side in 'LR':
 for a,b in pairs.items():mainmap[side+'_'+a]=side+'_'+b
 for digit in ['Thumb','Index','Mid','Ring','Pinky']:
  for k in range(1,4):mainmap[f'{side}_{digit}{k}']=f'{side}_'+('Middle' if digit=='Mid' else digit)+'Finger'+str(k)
def skin(mesh,trans):
 pts=mesh['vertices'];ids=mesh['ids'];w=mesh['weights']
 value=np.zeros(pts.shape,dtype='f')
 for j in range(ids.shape[1]):
  m=trans[ids[:,j]];value+=(np.einsum('nij,nj->ni',m[:,:,:3],pts)+m[:,:,3])*w[:,j,None]
 return value
def build(slug,*,profile=None,output=None,signal_time=5.1,hold_gesture=False,walk_clock=None,walk_mix=None):
 actor,origin,yaw,mode,speed=profile or CAST[slug];rig=dict(np.load(P/actor/'skeleton.npz'));names=rig['names'].tolist();bind=rig['bind'];parent=rig['parent']
 ix={n:q for q,n in enumerate(names)};src=clip('idle')['names'].tolist();si={s:i for i,s in enumerate(src)}
 idle=sample('idle',T*.65+1.1);active={'walking':'walking','queue':'walking','point':'point','talk':'talk','consent':'signal','observe':'idle'}[mode]
 if mode=='queue':clock=np.maximum(T-3.8,0)*speed+.34;mix=ease((T-3.8)/.48)*(1-ease((T-7.4)/.55))
 elif mode=='walking':clock=T*speed+.45;mix=1-ease((T-6.35)/.75)
 elif mode=='consent':
  clock=np.maximum(T-signal_time,0)*speed
  if hold_gesture:clock=np.minimum(clock,1.60)
  mix=ease((T-signal_time)/.62)*(1-ease((T-signal_time-3.3)/.68))
 elif mode in ('point','talk'):clock=T*speed+(1.12 if mode=='point' else .75);mix=1-ease((T-(6.3 if mode=='talk' else 7.4))/.8)
 else:clock=T*.61;mix=np.zeros(len(T))
 if walk_clock is not None:
  assert mode=='walking' and walk_mix is not None
  clock=np.asarray(walk_clock);mix=np.asarray(walk_mix)
 source=idle+(sample(active,clock)-idle)*mix[:,None,None];sp={n:source[:,i] for n,i in si.items()}
 s=lambda name:sp[mainmap[name]]
 rest=lambda name:bind[ix[name]]
 def basis(left,right,up,down):
  restframe=frame(rest(left)-rest(right),rest(up)-rest(down))
  return frame(s(left)-s(right),s(up)-s(down))@restframe.T
 pelvis=basis('L_Thigh','R_Thigh','Waist','Hip');chest=basis('L_Upperarm','R_Upperarm','NeckTwist01','Waist')
 n=len(T);R=np.empty((n,len(names),3,3));pos=np.empty((n,len(names),3));I=np.broadcast_to(np.eye(3),(n,3,3))
 ratio=rest('Hip')[2]/.956
 for j,name in enumerate(names):
  par=parent[j]
  inherited=R[:,par] if par>=0 else I
  pos[:,j]=(pos[:,par]+np.einsum('tij,j->ti',inherited,bind[j]-bind[par])) if par>=0 else np.zeros((n,3))
  rot=inherited
  if name=='Hip':
   pos[:,j]=bind[j]+(sp['Pelvis']-sp['Root']-[0,0,.956])*ratio
   rot=pelvis
  elif name in ('Waist','Spine01','Spine02','NeckTwist01','NeckTwist02','Head'):
   rot=chest
  elif name.startswith(('L_','R_')):
   side,piece=name.split('_',1);side+='_'
   child={'Thigh':'Calf','Calf':'Foot','Clavicle':'Upperarm','Upperarm':'Forearm','Forearm':'Hand'}.get(piece)
   if piece=='Hand':
    a,b,c=(side+k for k in ('Mid1','Index1','Pinky1'))
    rot=frame(s(a)-s(name),s(b)-s(c))@frame(rest(a)-rest(name),rest(b)-rest(c)).T
   elif piece=='Foot':
    toe=side+'ToeBase';base=frame(rest(toe)-rest(name),[1,0,0]);rot=frame(s(toe)-s(name),s('L_Thigh')-s('R_Thigh'))@base.T
   elif (piece.endswith(('1','2')) and name in mainmap and name[:-1]+str(int(name[-1])+1) in mainmap):
    child=piece[:-1]+str(int(piece[-1])+1)
   if child:
    target=side+child;v=np.einsum('tij,j->ti',inherited,rest(target)-rest(name))
    rot=align(v,s(target)-s(name))@inherited
  R[:,j]=rot
 angle=math.radians(yaw);turn=Rotation.from_euler('z',angle).as_matrix()
 R=turn@R;pos=pos@turn.T
 trans=np.concatenate((R,(pos-np.einsum('tbij,bj->tbi',R,bind))[:,:,:,None]),axis=3).astype('f')
 shoe=next(q for q in (P/actor).glob('*.npz') if any(k in q.name for k in ('shoes','boots','sneakers')))
 m=dict(np.load(shoe));soles=np.array([skin(m,t) for t in trans]);left=m['vertices'][:,0]>0
 # Recover root motion from actual planted shoe vertices, including heel-to-toe contact changes.
 drift=[];root=np.zeros((n,3));root[0,:2]=origin;stance=[];anchor=None;prev_side=None
 for i,feet in enumerate(soles):
  zs=feet[:,2];lz=zs[left].min();rz=zs[~left].min()
  side=(lz<=rz) if prev_side is None or abs(lz-rz)>.010 else prev_side
  ixfoot=np.flatnonzero(left==side);low=zs[ixfoot].min()
  if anchor is None or side!=prev_side or zs[anchor]>low+.012:
   anchor=ixfoot[np.argmin(zs[ixfoot])]
  if i:
   shift=soles[i-1,anchor,:2]-feet[anchor,:2]
   root[i,:2]=root[i-1,:2]+shift
   drift.append(np.linalg.norm(feet[anchor,:2]+root[i,:2]-soles[i-1,anchor,:2]-root[i-1,:2]))
  root[i,2]=.0008-zs.min();stance.append(anchor);prev_side=side
 trans[:,:,:,3]+=root[:,None,:];pos+=root[:,None,:]
 out=Path(output) if output is not None else D/'runs'/slug;out.mkdir(parents=True,exist_ok=True)
 np.savez_compressed(out/'human.npz',times=T,trans=trans,names=names,joints=pos.astype('f'),stance=stance)
 metrics=dict(asset=actor,clip=S[active],initial='moving' if slug in ('crossing','hospital','library','meeting','market') else 'initially still',
  distance_m=float(np.linalg.norm(np.diff(root[:,:2],axis=0),axis=1).sum()),initial_root_motion_m=float(np.linalg.norm(root[20,:2]-root[0,:2])),final_root_xy=root[-1,:2].round(3).tolist(),
  minimum_shoe_floor_gap_mm=float(np.min(soles[:,:,2]+root[:,2,None])*1000),max_support_anchor_slip_mm=max(drift)*1000,source='NVIDIA Isaac People, native joint animations retargeted with original skin weights')
 (out/'human.json').write_text(json.dumps(metrics,indent=2));print(slug,np.round(pos[[0,100,200,-1],ix['Hip'],:2],2).tolist(),flush=True)
if __name__=='__main__':
 for k in sys.argv[1:] or CAST:build(k)
