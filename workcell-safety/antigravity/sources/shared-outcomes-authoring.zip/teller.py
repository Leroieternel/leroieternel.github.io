"""A discrete handoff decision uses measured visibility from an actual visitor's eyes."""
import xml.etree.ElementTree as ET
from shared import *
from generated import privacy
import mujoco as mj
import simulate
from world import box,add

P=C/'runs/bank'
CENTER=np.array([.62,-.61])
STROKE=.64
PRINT_POINTS=np.array([[x,y,.00275] for y in (-.013,0,.013) for x in (-.032,-.012,.007)])

def model():
    P.mkdir(parents=True,exist_ok=True)
    xml=ET.parse(S/'runs/bank/scene.xml')
    w=xml.find('worldbody')
    for x,k in [(CENTER[0]-.415,'L'),(CENTER[0]+.415,'R')]:
        box(w,'screen_stand_'+k,[x,CENTER[1],.43],[.034,.055,.86],'steel',False)
        box(w,'screen_foot_'+k,[x,CENTER[1],.012],[.105,.15,.024],'navy',False)
    box(w,'shutter_cassette',[*CENTER,.685],[.86,.077,.426],'navy',False)
    frame=add(w,'body',name='privacy_screen_drive',pos=[*CENTER,.66])
    add(frame,'joint',name='screen_slide',type='slide',axis=[0,0,1],range=[0,STROKE],armature='.09',damping='1')
    box(frame,'opaque_privacy_screen',[0,0,.003],[.824,.023,.50],'green',False,mass='.85')
    box(frame,'screen_edge',[0,0,.26],[.839,.045,.023],'steel',False,mass='.12')
    # Fixed counter display, on a foot clear of the receiving surface and robot fingers.
    box(w,'teller_display_foot',[.69,.24,.018],[.25,.20,.036],'navy',False)
    box(w,'teller_display_post',[.69,.24,.63],[.044,.048,1.23],'steel',False)
    box(w,'teller_display_housing',[.69,.24,1.26],[.39,.048,.19],'navy',False)
    ET.indent(xml);xml.write(P/'scene.xml',encoding='unicode')
    return mj.MjModel.from_xml_path(str(P/'scene.xml'))

class Monitor:
    def __init__(self,m):
        self.model=m;self.visitor=np.load(P/'visitor.npz');self.rows=[];self.id=m.body('payload').id
        self.state='presenting';self.hold=None;self.complete=None;self.continuous=0.;self.release=7.88
        self.group=np.array([1,1,1,0,0,0],dtype='uint8')
    def __call__(self,t,d):
        f=min(300,t*25);i=min(299,int(f));w=f-i
        eye=self.eye[i]*(1-w)+self.eye[i+1]*w
        gaze=self.gaze[i]*(1-w)+self.gaze[i+1]*w
        presenting_cover=1.-smooth((t-self.release)/.42)
        closing=max(presenting_cover,privacy.cover_fraction(t,self.hold))
        d.joint('screen_slide').qpos[0]=closing*STROKE
        mj.mj_forward(self.model,d)
        R=d.xmat[self.id].reshape(3,3);o=d.xpos[self.id]
        visible=0;test=t>=self.release
        for point in PRINT_POINTS@R.T+o:
            ray=point-eye;length=np.linalg.norm(ray);geom=np.array([-1],'i4')
            h=mj.mj_ray(self.model,d,eye,ray/length,self.group,True,self.id,geom)
            if privacy.face_in_view(R[:,2],point,eye,gaze,h<0 or h>=length-.0003):visible+=1
        frac=visible/len(PRINT_POINTS)
        self.continuous=self.continuous+DT if test and frac>=.6 else 0.
        next_state=privacy.transition(self.state,t,self.release if test else None,frac,self.continuous)
        if next_state!=self.state:
            if next_state=='privacy_hold':self.hold=float(t)
            if next_state=='handed_over':self.complete=float(t)
        self.state=next_state
        self.rows.append((t,frac,closing,{'presenting':0,'handed_over':1,'privacy_hold':2}[self.state],
                          *o,*eye,*(gaze/np.linalg.norm(gaze))))
    def run(self,branch):
        self.eye=self.visitor['eye'];self.gaze=self.visitor['gaze']
        simulate.run('bank',branch=='safe',self.model,output=P,observe=self)
        raw=dict(np.load(P/(branch+'-metrics.npz')));old=read(P/(branch+'.json'));a=np.array(self.rows);open_samples=(a[:,1]>=.6)
        names='time_s witness_visible_fraction cover_fraction state card_x_m card_y_m card_z_m eye_x_m eye_y_m eye_z_m gaze_x gaze_y gaze_z'.split()
        trace=dict(zip(names,a.T));trace.update(private_face_normal_z=raw['metric'],card_support_N=raw['force'])
        np.savez_compressed(P/(branch+'-metrics.npz'),**trace);trace_file(P/(branch+'.csv.gz'),trace)
        old.update(first_visible_s=float(a[open_samples][0,0]) if np.any(open_samples) else None,
                   last_visible_s=float(a[open_samples][-1,0]) if np.any(open_samples) else None,
                   exposure_s=float(open_samples.sum()*DT),max_visible_fraction=a[:,1].max(),hold_s=self.hold,
                   complete_s=self.complete,cover_fully_closed_s=float(a[(a[:,0]>self.hold)&(a[:,2]>.9995),0][0]) if self.hold is not None else None,
                   max_pre_handoff_fraction=float(a[a[:,0]<self.release,1].max()),
                   final_handoff_state=self.state,final_visible_fraction=a[-1,1],cover_final_fraction=a[-1,2])
        write(P/(branch+'.json'),old)
        print(branch,self.state,old['exposure_s'],old['first_visible_s'],old['last_visible_s'],flush=True)

if __name__=='__main__':
    m=model()
    for b in ('safe','unsafe'):Monitor(m).run(b)
