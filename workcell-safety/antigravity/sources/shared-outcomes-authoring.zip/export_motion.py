from shared import *
sys.path.insert(0,str(ROOT/'outputs/robot_plans'))
import optics

optics.CACHE=C/'optics'
for slug in sys.argv[1:] or ('hospital','bank'):
    p=C/'runs'/slug
    write(p/'info.json',dict(detail_time_s=3.72 if slug=='hospital' else 8.38))
    index=4 if slug=='hospital' else 8
    optics.paths=lambda k:p
    optics.export(index)
    alias=optics.CACHE/f'{index:02}_{slug}'
    if not alias.exists():alias.symlink_to(slug,target_is_directory=True)
