"""Render measured motion and the event-driven actors into two matched, stable-camera films."""
from shared import *
import math
import bpy
from mathutils import Vector
import render as stage
from generated import hospital,privacy

stage.cr.CACHE=C/'optics'

def label(name,txt,pos,size,mat,*,parent=None,upright=False):
    cu=bpy.data.curves.new(name,'FONT');cu.body=txt;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=size
    ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob)
    ob.parent=parent;ob.location=pos
    if upright:ob.rotation_euler.x=math.pi/2
    cu.materials.append(mat)
    return ob

class Shoot:
    def __init__(self,slug):
        self.slug=slug;self.path=C/'runs'/slug;self.actors={}
        def casts(_):
            actor='nurse' if slug=='hospital' else 'business'
            self.actors['principal']=stage.native_human(slug,actor=actor,transforms=np.concatenate(
                [np.load(self.path/(b+'-person.npz'))['trans'] for b in ('safe','unsafe')]))
            if slug=='bank':
                self.visitor=dict(np.load(self.path/'visitor.npz'))
                self.actors['visitor']=stage.native_human(slug,actor='doctor',transforms=self.visitor['trans'])
            return self.actors
        self.v,_=stage.scene_for(slug,cast=casts,appearance=self.path/'appearance.json')
        self.scene=self.v.scene
        self.obs={meta['name']:ob for meta,ob in zip(self.v.spec,self.v.obs)}
        self.metrics={b:dict(np.load(self.path/(b+'-metrics.npz'))) for b in ('safe','unsafe')}
        self.summary={b:read(self.path/(b+'.json')) for b in self.metrics}
        if slug=='bank':
            card=self.obs['privacy_card']
            face=stage.shaded_mesh('Fictional card print panel',(0,0,0),(.078,.049,.00015),stage.plain('ivory'))
            face.parent=card;face.location=(-.002,0,.00277);face['surface_ink']=True
            for text,y,size in [('DEMO',.011,.011),('42',-.0095,.025)]:
                label('Fictional card ink '+text,text,(-.004,y,.00289),size,stage.plain('navy'),parent=card)
            self.display=label('Transaction signal','PRESENTING',(.69,.2145,1.29),.037,stage.plain('white'),upright=True)
            self.display_sub=label('Transaction instruction','CARD RETURN',(.69,.2145,1.228),.020,stage.plain('white'),upright=True)
            for n in ('opaque_privacy_screen','screen_edge'):stage.replace(self.obs[n],stage.plain('teal' if n=='opaque_privacy_screen' else 'chrome'))
            self.signline=label('Printed shutter mark','PRIVACY', (0,-.0127,.1),.038,stage.plain('white'),parent=self.obs['opaque_privacy_screen'],upright=True)
        self.scene.render.image_settings.quality=94

    def pose(self,b,i,shot=None):
        t=i/25;v=self.v;v.pose(b,i)
        pov=self.slug=='bank' and (7.62<=t<9.08 or 10.45<=t<11.25)
        if shot=='wide':pov=False
        if shot=='eye':pov=True
        for name,items in self.actors.items():
            j=i+(301 if b=='unsafe' and name=='principal' else 0)
            for ob,xyz,_ in items:
                ob.data.vertices.foreach_set('co',xyz[j].ravel());ob.data.update()
                ob.hide_render=bool(name=='visitor' and pov)
        if self.slug=='hospital':
            key='establish' if t<2.72 else 'contact' if t<4.33 else 'aftermath'
            eye,aim,mm=hospital.camera(key)
            if key=='contact':eye=(.75,-4.87,2.59);aim=(1.00,.08,.74);mm=28
            if key=='aftermath':eye=(1.18,-4.66,2.56);aim=(1.18,.40,.59);mm=30
            stage.aim(v.cam,(eye,aim,mm))
        else:
            d=self.metrics[b];state=int(d['state'][i*40])
            self.display.data.body=('PRESENTING','COMPLETE','PRIVACY HOLD')[state]
            self.display_sub.data.body=('CARD RETURN','HANDOFF RELEASED','PRIVATE REISSUE')[state]
            if pov:
                # Both branches look from the same physical eye at the same fixed receiving area.
                # Its longer focal length corresponds to an optical crop, visibly labeled in the film.
                eye=self.visitor['eye'][i];stage.aim(v.cam,(eye,(.390,-.136,.907),176))
            elif 1.98<=t<4.32 and shot!='wide':
                stage.aim(v.cam,((.73,-.53,1.47),(.295,-.37,.955),42))
            elif t>=9.08:stage.aim(v.cam,((-1.86,-3.18,1.75),(.53,-.06,1.04),42))
            else:stage.aim(v.cam,((-2.15,-3.68,2.07),(.52,-.13,1.05),40))

    def image(self,b,i,out,percent=100,shot=None):
        self.scene.frame_set(i+1);self.pose(b,i,shot);self.scene.render.resolution_percentage=percent
        self.scene.render.filepath=str(out);bpy.ops.render.render(write_still=True)
    def run(self,mode):
        slug=self.slug;out=C/'media'/slug;out.mkdir(exist_ok=True)
        if mode=='proof':
            indices=[44,78,91,101,117,225] if slug=='hospital' else [38,87,201,215,229,246,266,289]
            for b in ('unsafe','safe'):
                for i in indices:self.image(b,i,C/'proofs'/f'{slug}-{b}-{i:03}.jpg',50)
            return
        if mode=='audit':
            from scene_check import check
            check(self);return
        if mode=='verify':
            import tempfile
            results={}
            with tempfile.TemporaryDirectory(prefix='paired-replay-check-') as td:
                for b in ('safe','unsafe'):
                    rows=[]
                    for i in ([24,88,130,280] if slug=='hospital' else [32,205,229,267,285]):
                        fn=Path(td)/(b+str(i)+'.jpg');self.image(b,i,fn)
                        def thumb(path):
                            im=bpy.data.images.load(str(path),check_existing=False);im.scale(384,216)
                            px=np.empty(384*216*4,'f');im.pixels.foreach_get(px);bpy.data.images.remove(im)
                            a=px.reshape(-1,4)[:,:3].clip(0,1)
                            return 255*np.where(a<=.00313,12.92*a,1.055*a**(1/2.4)-.055)
                        err=float(np.mean(abs(thumb(fn)-thumb(out/b/f'frame-{i+1:04d}.jpg'))))
                        assert err<3.5,(slug,b,i,err)
                        rows.append(dict(frame_1_based=i+1,mean_rgb_error_255=round(err,4)))
                    results[b]=rows
            write(self.path/'render-check.json',results);return
        for b in ('unsafe','safe'):
            folder=out/b;folder.mkdir(exist_ok=True);sc=self.scene
            sc.frame_start=1;sc.frame_end=300;sc.render.resolution_percentage=100
            sc.render.filepath=str(folder/'frame-');sc.render.use_overwrite=True
            def update(s,*_):self.pose(b,max(0,min(300,s.frame_current-1)))
            bpy.app.handlers.frame_change_pre.append(update)
            try:sc.frame_set(1);bpy.ops.render.render(animation=True)
            finally:bpy.app.handlers.frame_change_pre.remove(update)

if __name__=='__main__':
    for slug in sys.argv[2:]:Shoot(slug).run(sys.argv[1])
