from pathlib import Path
import gzip
import hashlib
import json
import sys
import numpy as np

C = Path(__file__).resolve().parent
S = C.parent
ROOT = S.parents[2]
sys.path.insert(0, str(S))
T = np.arange(301, dtype=float) / 25
DT = .001

def read(path):
    return json.loads(Path(path).read_text())

def write(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def trace_file(path, columns):
    with gzip.open(path, 'wt') as file:
        np.savetxt(file, np.column_stack(list(columns.values())), delimiter=',', fmt='%.8g',
                   header=','.join(columns), comments='')

def smooth(x):
    x=np.clip(x,0.,1.)
    return x*x*(3.-2.*x)

def interpolate(series,t):
    return np.array([np.interp(t,T,series[:,i]) for i in range(series.shape[1])]).T
