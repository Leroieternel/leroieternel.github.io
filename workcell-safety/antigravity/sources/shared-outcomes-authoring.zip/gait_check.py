"""Measure the rendered character's knee directions, support feet and resting pose."""
from shared import T
import human
import numpy as np

def measure(joints, transforms, shoe, left, phases):
    from clinical_rig import LEGS
    vertices = np.stack([human.skin(shoe, t) for t in transforms])
    gaps = np.column_stack([vertices[:, mask, 2].min(1) for mask in (left, ~left)])
    feet = joints[:, [leg[2] for leg in LEGS]]
    flex, incorrect = {}, {}
    for side,(hip,knee,ankle) in zip(('L','R'),LEGS):
        upper = joints[:,knee]-joints[:,hip]
        lower = joints[:,ankle]-joints[:,knee]
        axis = human.unit(upper+lower)
        pole = upper - np.sum(upper*axis,axis=1)[:,None]*axis
        angle = np.rad2deg(np.arctan2(np.linalg.norm(np.cross(upper,lower),axis=1),np.sum(upper*lower,axis=1)))
        signed = np.where(pole[:,1] < 0,-angle,angle)
        flex[side] = dict(min_deg=round(signed.min().item(),2),max_deg=round(signed.max().item(),2),
                          end_deg=round(signed[-1].item(),2),max_change_per_frame_deg=round(np.max(abs(np.diff(signed))).item(),2))
        incorrect[side] = int(np.sum(signed < -.1))
    steps=[]
    for moving, begin, end in phases:
        rows = np.flatnonzero((T>=begin-1e-5)&(T<=end+1e-5))
        support = 1 if moving=='L' else 0
        ref=rows[len(rows)//2]
        ix=np.flatnonzero(left if support==0 else ~left)
        contact=ix[np.argmin(vertices[ref,ix,2])]
        xy=vertices[rows,contact,:2]
        steps.append(dict(swing_foot=moving,from_s=begin,until_s=end,
                          support_ankle_xy_excursion_mm=round(np.linalg.norm(np.ptp(feet[rows,support,:2],axis=0)).item()*1000,3),
                          support_sole_point_xy_excursion_mm=round(np.linalg.norm(np.ptp(xy,axis=0)).item()*1000,3),
                          max_support_sole_height_mm=round(gaps[rows,support].max().item()*1000,3)))
    rest=np.flatnonzero(T>=phases[-1][2]+.12)
    return dict(sample_rate_Hz=25,poses=len(T),signed_knee_flexion=flex,backward_knee_frames=incorrect,
                terminal_ankle_spacing_mm=round(1000*(feet[-1,1,0]-feet[-1,0,0]),2),
                min_ankle_spacing_mm=round(1000*(feet[:,1,0]-feet[:,0,0]).min(),2),
                terminal_fore_aft_stagger_mm=round(1000*abs(feet[-1,1,1]-feet[-1,0,1]),2),
                min_skin_sole_height_mm=round(1000*gaps.min().item(),3),
                max_lower_sole_height_mm=round(1000*gaps.min(1).max().item(),3),
                settled_max_shoe_vertex_drift_mm=round(np.linalg.norm(np.ptp(vertices[rest],axis=0),axis=1).max().item()*1000,3),
                steps=steps)
