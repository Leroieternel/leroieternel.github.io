"""Replay an empty transfer litter on a planar caster dolly, with a free six-DOF deck."""
from shared import *
import math
import xml.etree.ElementTree as ET
import mujoco as mj
from world import add, box, cyl, col, geo, init
from generated import hospital as director

DEST = C/'runs/hospital'
HANDLES = ('side_rail_L','side_rail_R','deck_pan','end_frame_F','end_frame_B','empty_pad','headrest')

def build():
    DEST.mkdir(parents=True, exist_ok=True)
    xml=ET.parse(S/'runs/hospital/scene.xml')
    w=xml.find('worldbody'); w.remove(w.find("body[@name='gurney']"))
    robot=w.find("body[@name='base']")
    # The returnable supply tote has a padded front guard attached to its shelf.
    for y in (-.235,.235):
        box(robot,'guard_stanchion_'+str(y),[.17,y,.54],[.038,.04,.52],'steel',False)
    box(robot,'guard_cross_tube',[.17,0,.794],[.06,.52,.06],'steel',False)
    bumper=box(robot,'supply_guard',[.22,0,.782],[.069,.54,.114],'yellow',True,mass='.8')
    bumper.attrib.update(contype='4',conaffinity='2',priority='2',solref='.012 1',solimp='.75 .97 .006')
    for geom in robot.find(".//body[@name='wheeled_base']").findall('geom'):
        geom.attrib.update(contype='4',conaffinity='3',solref='.008 1')
    cart=add(w,'body',name='gurney_dolly',pos=[.26,-2.56,0])
    for ax,typ,j in [([1,0,0],'slide','x'),([0,1,0],'slide','y'),([0,0,1],'hinge','yaw')]:
        add(cart,'joint',name='dolly_'+j,type=typ,axis=ax,limited='false',damping=.74 if j!='yaw' else 1.1)
    box(cart,'caster_base',[0,0,.24],[.53,1.24,.06],'steel',False,mass='17')
    for side in (-1,1):
        for end in (-1,1):
            x,y=side*.244,end*.63
            cyl(cart,'wheel_'+str((side,end)),[x,y,.102],.100,.048,'black',False,
                euler=[0,math.pi/2,0],mass='.55')
            box(cart,'caster_fork_'+str((side,end)),[x,y,.17],[.034,.039,.145],'steel',False,mass='.08')
        box(cart,'lift_post_'+str(side),[0,side*.49,.47],[.082,.070,.42],'steel',False,mass='2.1')
        box(cart,'saddle_'+str(side),[0,side*.49,.675],[.34,.14,.042],'navy',True,mass='1.2')
    litter=add(w,'body',name='empty_litter',pos=[.26,-2.56,.720])
    add(litter,'freejoint',name='litter_free')
    box(litter,'deck_pan',[0,0,0],[.66,1.68,.048],'steel',True,mass='5.4')
    box(litter,'empty_pad',[0,0,.074],[.644,1.62,.098],'green',True,mass='1.9')
    box(litter,'headrest',[0,.54,.151],[.43,.31,.057],'offwhite',True,mass='.34')
    for side,key in [(-1,'L'),(1,'R')]:
        box(litter,'side_rail_'+key,[side*.342,0,.160],[.027,1.34,.037],'steel',True,mass='.50')
        for y in (-.57,.57):
            box(litter,'rail_post_'+key+str(y),[side*.335,y,.084],[.022,.027,.14],'steel',True,mass='.12')
    for j,n in [(-1,'B'),(1,'F')]:
        box(litter,'end_frame_'+n,[0,j*.851,.038],[.66,.030,.042],'steel',True,mass='.22')
    for g in litter.findall('geom'):
        g.attrib.update(contype='2',conaffinity='5',friction='.22 .002 .0001',solref='.006 1')
    for g in cart.findall('geom'):
        g.attrib.update(contype='1',conaffinity='6',friction='.24 .002 .0001',solref='.006 1')
    ET.indent(xml);xml.write(DEST/'scene.xml',encoding='unicode')
    return mj.MjModel.from_xml_path(str(DEST/'scene.xml'))

def run(m,branch,dt=DT,output=DEST):
    safe=branch=='safe';d=mj.MjData(m);init(m,d,'omron')
    free=m.joint('litter_free');fqi=int(free.qposadr[0]);fvi=int(free.dofadr[0])
    cart=m.body('gurney_dolly').id; litter=m.body('empty_litter').id
    d.joint('dolly_y').qvel[0]=.79;d.qvel[fvi+1]=.79
    robot=m.body('base').id
    dynamic={'litter_free','dolly_x','dolly_y','dolly_yaw'}
    control=[j for j in range(m.njnt) if m.joint(j).name not in dynamic]
    qi=m.jnt_qposadr[control];vi=m.jnt_dofadr[control];neutral=d.qpos.copy()
    x=-2.85;speed=0.;arrival=False;brake=False;event=None;release=None;land=None
    desired=.96;path_y=-.10;last_force=0.;frames=[];rows=[];wrench=np.zeros(6)
    ids={m.geom(i).name:i for i in range(m.ngeom) if m.geom(i).name}
    ground=ids['stage_ground'];guard=ids['supply_guard']
    min_depth=0.;head=m.geom('headrest').id
    prior='yield';transitions=[]
    m.opt.timestep=dt
    times=np.arange(round(12/dt)+1)*dt
    stride=round(.04/dt)
    for tick,t in enumerate(times):
        tail=d.xpos[cart,1]-.86 if tick else -3.42
        if x>=-1.56 and not arrival:arrival=True
        state=director.decide(safe,tail>path_y+.44,last_force>.01,brake) if arrival else 'go'
        if state!=prior:transitions.append([round(t,3),state]);prior=state
        target=0. if state!='go' else desired
        if x>=2.15:target=0.
        if safe and not arrival:
            target=min(target,max(.06,math.sqrt(2*1.35*max(0,-1.53-x))))
        if tick:
            dv=(1.65 if target<speed else 1.15)*dt
            speed+=np.clip(target-speed,-dv,dv);x+=speed*dt
        d.qpos[qi]=neutral[qi];d.qvel[vi]=0.
        d.joint('route_x').qpos[0]=x;d.joint('route_y').qpos[0]=path_y;d.joint('route_x').qvel[0]=speed
        # Caster rolling resistance and a soft stop beyond the junction apply to the dolly only.
        dy=d.joint('dolly_y');d.qfrc_applied[:]=0.
        if dy.qpos[0]>4.40:d.qfrc_applied[m.joint('dolly_y').dofadr[0]]=-65*(dy.qpos[0]-4.40)-49*dy.qvel[0]
        mj.mj_forward(m,d)
        contact=landing=support=0.
        for j,c in enumerate(d.contact):
            mj.mj_contactForce(m,d,j,wrench);force=max(wrench[0],0.)
            if force<1e-5:continue
            a,b=c.geom1,c.geom2;pair={a,b};bodies={m.geom_bodyid[a],m.geom_bodyid[b]}
            if guard in pair and litter in bodies:contact+=force
            if ground in pair and litter in bodies:landing+=force
            if bodies=={cart,litter}:support+=force
            min_depth=min(min_depth,c.dist)
        if contact>.05 and event is None:event=float(t);brake=True
        if landing>.10 and land is None:land=float(t)
        if event is not None and t>event and support<.10 and release is None:release=float(t)
        pose=d.xmat[litter].reshape(3,3);tilt=np.degrees(np.arccos(np.clip(pose[2,2],-1.,1.)))
        rows.append((t,x,speed,*d.xpos[litter],d.xpos[cart,1],tilt,contact,landing,support))
        if tick%stride==0:frames.append(d.qpos.copy())
        if tick+1<len(times):mj.mj_step(m,d)
        last_force=contact
    a=np.asarray(rows);names='time_s base_x_m base_speed_m_s litter_x_m litter_y_m litter_z_m dolly_y_m litter_tilt_deg bumper_litter_N litter_floor_N saddle_support_N'.split()
    tr=dict(zip(names,a.T));output.mkdir(parents=True,exist_ok=True)
    trace_file(output/(branch+'.csv.gz'),tr);np.savez_compressed(output/(branch+'-metrics.npz'),**tr)
    np.savez_compressed(output/(branch+'.npz'),qpos=frames,time_s=T)
    result=dict(first_contact_s=event,first_floor_contact_s=land,first_loss_of_support_s=release,
      peak_tilt_deg=float(a[:,7].max()),final_tilt_deg=float(a[-1,7]),peak_contact_N=float(a[:,8].max()),
      peak_litter_floor_N=float(a[:,9].max()),contact_impulse_Ns=float(np.sum(a[:,8])*dt),
      last_saddle_load_s=float(a[a[:,10]>.1,0][-1]),timestep_s=dt,
      final_height_m=float(a[-1,5]),final_support_N=float(a[-1,10]),final_floor_N=float(a[-1,9]),
      solver_contact_depth_mm=-min_depth*1000,solver_warnings=sum(w.number for w in d.warning),
      controller_transitions=transitions,final_base_x_m=x)
    write(output/(branch+'.json'),result);print(branch,result,flush=True)

if __name__=='__main__':
    model=build()
    half='--half-step' in sys.argv
    for branch in ('safe','unsafe'):run(model,branch,DT/2 if half else DT,DEST/'half-step' if half else DEST)
