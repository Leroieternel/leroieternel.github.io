"""Fit the native clinician's hands to the measured grip trajectory and keep her foot-planted gait."""
from shared import *
import human
from scipy.spatial.transform import Rotation
from generated import handling
from performers import pose,unit,merge_rotation
import pushbar

P=C/'runs/hospital'
RIG=dict(np.load(S/'assets/people/nurse/skeleton.npz'))
N=RIG['names'].tolist()
B=RIG['bind']
PARENT=RIG['parent']
SKIN=dict(np.load(next((S/'assets/people/nurse').glob('*skin.npz'))))

def unitv(a):
    return a/np.maximum(np.linalg.norm(a,axis=-1,keepdims=True),1e-12)

def contact_faces(side):
    mask=(1 if side=='L' else -1)*SKIN['vertices'][:,0]>.635
    faces=SKIN['faces'][mask[SKIN['faces']].all(1)]
    ids,faces=np.unique(faces,return_inverse=True)
    return {k:SKIN[k][ids] for k in ('vertices','ids','weights')},faces.reshape(-1,3)

def closest_radius(vertices, faces, origin, axis, halfspan=.0775):
    # Within the sleeve span, the distance to a triangular skin surface is the distance
    # from the bar axis to its projection into the cross-section, including the edges.
    rel=vertices-origin; forward=np.array([-axis[1],axis[0],0.])
    radial=np.column_stack((rel@forward,rel[:,2]))
    tri=radial[faces]
    along=(rel@axis)[faces]
    tri=tri[(along.min(1)<=halfspan)&(along.max(1)>=-halfspan)]
    if not len(tri):return np.inf
    edges=np.roll(tri,-1,axis=1)-tri
    f=np.clip(-np.sum(tri*edges,axis=2)/np.maximum(1e-16,np.sum(edges*edges,axis=2)),0,1)
    closest=tri+f[:,:,None]*edges
    cross=edges[:,:,0]*(-tri[:,:,1])-edges[:,:,1]*(-tri[:,:,0])
    if np.any(np.all(cross>0,axis=1)|np.all(cross<0,axis=1)):return 0.
    return float(np.sqrt(np.min(np.sum(closest*closest,axis=2)))) if tri.size else np.inf

def arm_pose(native, pos, pads, rest, angles, heights):
    rotations=native[:,:,:,:3].copy()
    reach=[]
    for k,side in enumerate(pushbar.SIDES):
        sign=1 if side=='L' else -1
        ids=[N.index(side+'_'+key) for key in ('Upperarm','Forearm','Hand')]
        upper,fore,hand=ids
        wrist_basis=Rotation.from_euler('x',(-10+12*angles)[:,None],degrees=True).as_matrix()@Rotation.from_euler('z',sign*90,degrees=True).as_matrix()
        wrist_basis=merge_rotation(wrist_basis[:,None],native[:,hand,None,:,:3],rest)[:,0]
        palm_local=np.array([sign*.049,-.001,.002])
        wrist=pads[:,k]-wrist_basis@palm_local
        wrist[:,2]+=heights[:,k]
        a=pos[:,upper];vec=wrist-a;dist=np.linalg.norm(vec,axis=1);u=unitv(vec)
        l1=np.linalg.norm(B[fore]-B[upper]);l2=np.linalg.norm(B[hand]-B[fore])
        reach.append(float(np.max(dist-l1-l2)))
        if reach[-1]>.0005:
            kmax=int(np.argmax(dist))
            print('Reach',side,T[kmax],dist[kmax], 'over',T[dist>l1+l2+.001][[0,-1]],'shoulder',a[kmax], 'wrist',wrist[kmax],flush=True)
        pole=np.broadcast_to([-sign*.53,-.55,-.65],a.shape)
        sideway=unitv(pole-(pole*u).sum(1)[:,None]*u)
        along=(l1*l1-l2*l2+dist*dist)/(2*dist)
        e=a+along[:,None]*u+np.sqrt(np.maximum(0.,l1*l1-along*along))[:,None]*sideway
        for j,child,target in [(upper,fore,e-a),(fore,hand,wrist-e)]:
            original=rotations[:,j]
            rotations[:,j]=human.align(original@(B[child]-B[j]),target)@original
        # This asset puts most sleeve/forearm skin weight on the twist and elbow-share
        # joints, rather than its two main arm joints. Carry those bones with the IK.
        for helper in ('UpperarmTwist01','UpperarmTwist02'):
            rotations[:,N.index(side+'_'+helper)]=rotations[:,upper]
        for helper in ('ElbowShareBone','ForearmTwist01','ForearmTwist02'):
            rotations[:,N.index(side+'_'+helper)]=rotations[:,fore]
        rotations[:,hand]=wrist_basis
        for digit in ('Index','Mid','Ring','Pinky','Thumb'):
            if digit=='Thumb':
                for j in range(1,4):
                    rotations[:,N.index(f'{side}_{digit}{j}')]=wrist_basis
                continue
            # Fold over the far side of the soft grip and open during the release.
            for j,angle in [(1,16),(2,53),(3,76)]:
                bend=Rotation.from_euler('x',(-angle*(1-.8*angles))[:,None],degrees=True).as_matrix()
                rotations[:,N.index(f'{side}_{digit}{j}')]=bend@wrist_basis
    # The handler looks toward the equipment throughout and follows the descending deck on release.
    neck=N.index('NeckTwist01')
    necks={neck}
    for j,par in enumerate(PARENT):
        if par in necks:necks.add(j)
    head_tilt=Rotation.from_euler('z',(-25*angles)[:,None],degrees=True).as_matrix()@Rotation.from_euler('x',(-11-10*angles)[:,None],degrees=True).as_matrix()
    for j in necks:rotations[:,j]=head_tilt@rotations[:,j]
    joints,tf=pose(B,PARENT,rotations,pos[:,N.index('Hip')],N.index('Hip'))
    return joints,tf,reach

def settle_feet(rots,hip,pos,trans,shoe,split,standing,step,retreat):
    soles=np.array([human.skin(shoe,t)[:,2] for t in trans])
    lift=np.maximum(0.,np.column_stack([soles[:,split].min(1),soles[:,~split].min(1)])-.0008)
    final_feet=[pos[-1,N.index(s+'_Foot'),1] for s in pushbar.SIDES]
    trailing=int(np.argmin(final_feet))
    stride=min(.29,max(0.,abs(final_feet[0]-final_feet[1])-.19))
    goals=[]
    drop=np.zeros(len(T))
    for k,side in enumerate(pushbar.SIDES):
        top,knee,ankle=[N.index(side+'_'+n) for n in ('Thigh','Calf','Foot')]
        target=pos[:,ankle].copy();target[:,2]-=standing*lift[:,k]
        target[:,1]=hip[:,1]+.67*(target[:,1]-hip[:,1])
        stage=retreat[k]
        target[:,1]-=.57*stage
        target[:,2]+=.046*np.sin(np.pi*stage)**2
        if k==trailing:
            target[:,1]+=step*stride
            target[:,2]+=.052*np.sin(np.pi*step)**2
        goals.append(target)
        length=np.linalg.norm(B[knee]-B[top])+np.linalg.norm(B[ankle]-B[knee])-.003
        dx=pos[:,top,:2]-target[:,:2];dx[:,1]-=.57*(retreat[0]+retreat[1])*.5
        extension=np.sqrt(np.maximum(.001,length*length-(dx*dx).sum(1)))
        drop=np.maximum(drop,np.maximum(0.,pos[:,top,2]-target[:,2]-extension))
    drop*=standing
    adjusted=hip.copy();adjusted[:,2]-=drop
    adjusted[:,1]-=.57*(retreat[0]+retreat[1])*.5
    for k,side in enumerate(pushbar.SIDES):
        top,knee,ankle=[N.index(side+'_'+n) for n in ('Thigh','Calf','Foot')]
        start=pos[:,top]+adjusted-hip
        target=goals[k]
        u=unitv(target-start);dist=np.linalg.norm(target-start,axis=1)
        l1=np.linalg.norm(B[knee]-B[top]);l2=np.linalg.norm(B[ankle]-B[knee])
        pole=pos[:,knee]-pos[:,top]
        direction=unitv(pole-(pole*u).sum(1)[:,None]*u)
        along=(l1*l1-l2*l2+dist*dist)/(2*dist)
        bent=start+along[:,None]*u+np.sqrt(np.maximum(0.,l1*l1-along*along))[:,None]*direction
        for j,child,vec in [(top,knee,bent-start),(knee,ankle,target-bent)]:
            old=rots[:,j].copy();updated=human.align(old@(B[child]-B[j]),vec)@old
            active=np.ones(len(T),dtype=bool);rots[:,j]=updated
        for helper,bone in [('ThighTwist01',top),('ThighTwist02',top),('KneeShareBone',knee),('CalfTwist01',knee),('CalfTwist02',knee)]:
            rots[active,N.index(side+'_'+helper)]=rots[active,bone]
    return pose(B,PARENT,rots,adjusted,pushbar.HIP)

def build():
    import mujoco as mj
    model=mj.MjModel.from_xml_path(str(P/'scene.xml'));d=mj.MjData(model)
    from scipy.signal import savgol_filter
    reference=P/'handling_reference'
    human.build('hospital',profile=('nurse',pushbar.RIG_ORIGIN,180,'walking',.78),output=reference,
                walk_clock=T*.78+.45,walk_mix=np.ones(len(T)))
    walking=np.load(reference/'human.npz')
    walk_distance=walking['joints'][:,pushbar.HIP,1].astype(float)
    walk_distance=np.maximum.accumulate(savgol_filter(walk_distance,19,2))
    walk_distance-=walk_distance[0]
    perform={};prev={}
    for b in ('safe','unsafe'):
        vals=read(P/(b+'.json')); release=vals['release_command_s']
        factors=np.array([handling.handling_pose(None if release is None else t-release) for t in T])
        angles=factors[:,1]
        signal=np.load(P/(b+'-metrics.npz'))
        cart_y=signal['dolly_y_m'][::40].copy()
        if release is not None:
            split=np.searchsorted(T,release)
            rolling=(cart_y[split-1]-cart_y[split-4])/.12
            for i in range(split,len(T)):
                cart_y[i]=cart_y[i-1]+.02*rolling*(factors[i-1,2]+factors[i,2])
        states=np.load(P/(b+'.npz'));pads=states['palm_pos']
        # The gait responds to a sideways pull through hands that are actually carrying load.
        # Slowing the native walking clock preserves stance points when the handler braces.
        grip_load=np.minimum(signal['left_palm_grip_N'][::40],signal['right_palm_grip_N'][::40])
        shift=np.abs(pads[:,:,0].mean(1)-.26)
        frames=np.flatnonzero((shift>.009)&(grip_load>.1))
        brace=smooth((T-T[frames[0]])/.32) if len(frames) else np.zeros(len(T))
        cart_y-=.15*brace
        travel=np.maximum.accumulate(cart_y-cart_y[0])
        phase=np.interp(travel,.67*walk_distance,T)
        shoe=dict(np.load(next((S/'assets/people/nurse').glob('*sneakers.npz'))))
        split=shoe['vertices'][:,0]>0
        k=np.clip(np.searchsorted(T,phase,side='right')-1,0,len(T)-2)
        w=np.clip((phase-T[k])/.04,0.,1.)
        rots=merge_rotation(walking['trans'][k,:,:,:3],walking['trans'][k+1,:,:,:3],w)
        spine=N.index('Waist')
        upper={spine}
        for i,par in enumerate(PARENT):
            if par in upper:upper.add(i)
        upper=sorted(upper);rest=np.zeros(len(T)) if release is None else smooth((T-release-.68)/.92)
        standing=smooth((T-(7.20 if release is None else release+.65))/.85)
        idle=pushbar.ACTOR_PATH['trans'][np.clip((200+(T*25).astype(int)%96),0,300),:,:,:3]
        rots[:,upper]=merge_rotation(rots[:,upper],idle[:,upper],standing)
        for side in pushbar.SIDES:
            foot=N.index(side+'_Foot');toe={foot}
            for j,par in enumerate(PARENT):
                if par in toe:toe.add(j)
            ids=sorted(toe);rots[:,ids]=merge_rotation(rots[:,ids],idle[:,ids],standing)
        # Lean from the waist as a handler naturally follows the moving bar; return
        # to a neutral posture after releasing. The pelvis and stance feet stay planted.
        side_reach=np.clip((pads[:,:,0].mean(1)-.26)/.20,0.,1.)
        weight=(1.-rest)*(1.-(.57*standing if release is None else 0.))
        lean=Rotation.from_euler('y',(17*side_reach*weight)[:,None],degrees=True).as_matrix()@Rotation.from_euler('x',(-(15+12*brace)*weight)[:,None],degrees=True).as_matrix()
        rots[:,upper]=lean[:,None]@rots[:,upper]
        hip=walking['joints'][k,pushbar.HIP]*(1-w[:,None])+walking['joints'][k+1,pushbar.HIP]*w[:,None]
        hip[:,1]=pushbar.RIG_ORIGIN[1]+.67*(hip[:,1]-pushbar.RIG_ORIGIN[1])
        pos,trans=pose(B,PARENT,rots,hip,pushbar.HIP)
        sole_z=np.array([human.skin(shoe,arr)[:,2].min() for arr in trans])
        dz=.0008-sole_z
        pos[:,:,2]+=dz[:,None];trans[:,:,2,3]+=dz[:,None]
        hip=pos[:,pushbar.HIP].copy()
        step=smooth((T-(7.9 if release is None else release+1.34))/.64)
        retreat=(np.zeros(len(T)),np.zeros(len(T))) if release is None else pushbar.recovery_steps(T-release)
        pos,trans=settle_feet(rots,hip,pos,trans,shoe,split,standing,step,retreat)
        native=dict(joints=pos,trans=trans)
        origins=[];axes=[]
        for q in states['qpos']:
            d.qpos[:]=q;mj.mj_fwdPosition(model,d)
            origins.append([d.geom('push_grip_'+s).xpos.copy() for s in pushbar.SIDES])
            axes.append(d.xmat[model.body('gurney_dolly').id].reshape(3,3)[:,0].copy())
        origins=np.asarray(origins);axes=np.asarray(axes);height=np.zeros((len(T),2))
        nativepos=native['joints'];nativetf=native['trans']
        target_load=signal;gaps=[]
        # Calibrate each skin surface against its own physical sleeve. The last few
        # millimetres depend on forearm skin weights as well as the wrist transform.
        hand_mesh=[contact_faces(s) for s in pushbar.SIDES]
        for iteration in range(4):
            j,tf,reach=arm_pose(nativetf,nativepos,pads,rest,angles,height)
            adjustments=0
            for k,(small,faces) in enumerate(hand_mesh):
                side='left' if k==0 else 'right'; solved=target_load[side+'_pad_bar_gap_m'][::40]
                for i in range(len(T)):
                    verts=human.skin(small,tf[i])
                    def gap(delta):
                        moved=verts+np.array([0.,0.,delta])
                        return min(closest_radius(moved,faces,origins[i,k],axes[i])-pushbar.GRIP_RADIUS,
                                   closest_radius(moved,faces,origins[i,1-k],axes[i])-pushbar.GRIP_RADIUS,
                                   closest_radius(moved,faces,origins[i].mean(0),axes[i],.31)-.014)
                    current=gap(0.)
                    if not np.isfinite(current):continue
                    holding=(release is None or T[i]<=release)
                    target=.00040+min(.018,max(0.,solved[i]))
                    if not holding:
                        target=.0008
                        if current>=target:continue
                    if abs(target-current)<.000045:continue
                    if current<target:
                        lo,hi=0.,.065
                        if gap(hi)<target:raise ValueError(('skin clearance',b,k,i))
                    else:
                        hi=0.;lo=-.003
                        while lo>-.039 and gap(lo)>target:lo-=.003
                        if gap(lo)>target:continue
                    for _ in range(13):
                        mid=(lo+hi)/2
                        if gap(mid)<target:lo=mid
                        else:hi=mid
                    height[i,k]+=hi;adjustments+=1
            if not adjustments:break
        j,tf,reach=arm_pose(nativetf,nativepos,pads,rest,angles,height)
        assert max(reach)<.001,(b,reach)
        for k,s in enumerate(pushbar.SIDES):
            small,faces=contact_faces(s);gg=[]
            for i in range(len(T)):gg.append(closest_radius(human.skin(small,tf[i]),faces,origins[i,k],axes[i])-pushbar.GRIP_RADIUS)
            gg=np.asarray(gg);loaded=target_load[('left' if k==0 else 'right')+'_palm_grip_N'][::40]>.04
            finite=gg[loaded&np.isfinite(gg)];gaps.append(dict(side=s,sampled_loaded_frames=int(loaded.sum()),
              minimum_loaded_skin_gap_mm=float(finite.min()*1000),maximum_loaded_skin_gap_mm=float(finite.max()*1000),
              last_loaded_frame_s=float(T[loaded][-1]),minimum_skin_gap_mm=float(np.min(gg)*1000),
              minimum_fit_z_mm=float(height[:,k].min()*1000),maximum_fit_z_mm=float(height[:,k].max()*1000)))
        np.savez_compressed(P/(b+'-person.npz'),trans=tf.astype('f'),joints=j.astype('f'),names=N)
        hip=j[:,N.index('Hip'),2];head=j[:,N.index('Head'),2]
        final_feet=human.skin(shoe,tf[-1])[:,2]
        perform[b]=dict(hand_mesh=gaps,terminal_sole_gaps_mm=[float(final_feet[split].min()*1000),float(final_feet[~split].min()*1000)],min_hip_height_m=float(hip.min()),final_hip_height_m=float(hip[-1]),
                        min_head_height_m=float(head.min()),final_head_height_m=float(head[-1]),reach_margin_m=-max(reach))
        prev[b]=tf
    cue=read(P/'unsafe.json')['release_command_s']
    # Up to the equipment incident the state and input in both branches are identical.
    incident=read(P/'unsafe.json')['first_contact_s'];same=np.flatnonzero(T<incident)
    common_error=float(np.abs(prev['safe'][same]-prev['unsafe'][same]).max())
    assert common_error<.00005,common_error
    write(P/'performance.json',dict(actor='NVIDIA Isaac People F_Medical_01',source_motion='Native foot-planted walking and idle with two-hand inverse kinematics',
        control='Antigravity releases both hands on measured handling and deck tilt. A sideways pull checks the walking gait. The clinician steps back and settles both feet on the floor.',
        same_pre_equipment_contact_samples=len(same),maximum_precontact_transform_difference=common_error,
        reaction_cue_s=cue,branches=perform,contact_mapping='Two palm pads against real grip sleeves. The optical skin fit is reported independently at rendered frames. The clinician is a kinematic performer.',
        injury_model='No human injury or human knockdown is modeled.'))
    print(json.dumps(perform,indent=2),'precontact diff',common_error,flush=True)

if __name__=='__main__':build()
