"""Fit the native clinician's hands to the measured grip trajectory and keep her foot-planted gait."""
from shared import *
import human
from scipy.spatial.transform import Rotation
from generated import handling, stance
from performers import pose,unit,merge_rotation
import pushbar

P=C/'runs/hospital'
RIG=dict(np.load(S/'assets/people/nurse/skeleton.npz'))
N=RIG['names'].tolist()
B=RIG['bind']
PARENT=RIG['parent']
SKIN=dict(np.load(next((S/'assets/people/nurse').glob('*skin.npz'))))

def unitv(a):
    return a/np.maximum(np.linalg.norm(a,axis=-1,keepdims=True),1e-12)

def contact_faces(side):
    mask=(1 if side=='L' else -1)*SKIN['vertices'][:,0]>.635
    faces=SKIN['faces'][mask[SKIN['faces']].all(1)]
    ids,faces=np.unique(faces,return_inverse=True)
    return {k:SKIN[k][ids] for k in ('vertices','ids','weights')},faces.reshape(-1,3)

def closest_radius(vertices, faces, origin, axis, halfspan=.0775):
    # Within the sleeve span, the distance to a triangular skin surface is the distance
    # from the bar axis to its projection into the cross-section, including the edges.
    rel=vertices-origin; forward=np.array([-axis[1],axis[0],0.])
    radial=np.column_stack((rel@forward,rel[:,2]))
    tri=radial[faces]
    along=(rel@axis)[faces]
    tri=tri[(along.min(1)<=halfspan)&(along.max(1)>=-halfspan)]
    if not len(tri):return np.inf
    edges=np.roll(tri,-1,axis=1)-tri
    f=np.clip(-np.sum(tri*edges,axis=2)/np.maximum(1e-16,np.sum(edges*edges,axis=2)),0,1)
    closest=tri+f[:,:,None]*edges
    cross=edges[:,:,0]*(-tri[:,:,1])-edges[:,:,1]*(-tri[:,:,0])
    if np.any(np.all(cross>0,axis=1)|np.all(cross<0,axis=1)):return 0.
    return float(np.sqrt(np.min(np.sum(closest*closest,axis=2)))) if tri.size else np.inf

def arm_pose(native, pos, pads, rest, angles, heights):
    rotations=native[:,:,:,:3].copy()
    reach=[]
    for k,side in enumerate(pushbar.SIDES):
        sign=1 if side=='L' else -1
        ids=[N.index(side+'_'+key) for key in ('Upperarm','Forearm','Hand')]
        upper,fore,hand=ids
        wrist_basis=Rotation.from_euler('x',(-10+12*angles)[:,None],degrees=True).as_matrix()@Rotation.from_euler('z',sign*90,degrees=True).as_matrix()
        wrist_basis=merge_rotation(wrist_basis[:,None],native[:,hand,None,:,:3],rest)[:,0]
        palm_local=np.array([sign*.049,-.001,.002])
        wrist=pads[:,k]-wrist_basis@palm_local
        wrist[:,2]+=heights[:,k]
        a=pos[:,upper];vec=wrist-a;dist=np.linalg.norm(vec,axis=1);u=unitv(vec)
        l1=np.linalg.norm(B[fore]-B[upper]);l2=np.linalg.norm(B[hand]-B[fore])
        reach.append(float(np.max(dist-l1-l2)))
        if reach[-1]>.0005:
            kmax=int(np.argmax(dist))
            print('Reach',side,T[kmax],dist[kmax], 'over',T[dist>l1+l2+.001][[0,-1]],'shoulder',a[kmax], 'wrist',wrist[kmax],flush=True)
        pole=np.broadcast_to([-sign*.53,-.55,-.65],a.shape)
        sideway=unitv(pole-(pole*u).sum(1)[:,None]*u)
        along=(l1*l1-l2*l2+dist*dist)/(2*dist)
        e=a+along[:,None]*u+np.sqrt(np.maximum(0.,l1*l1-along*along))[:,None]*sideway
        for j,child,target in [(upper,fore,e-a),(fore,hand,wrist-e)]:
            original=rotations[:,j]
            rotations[:,j]=human.align(original@(B[child]-B[j]),target)@original
        # This asset puts most sleeve/forearm skin weight on the twist and elbow-share
        # joints, rather than its two main arm joints. Carry those bones with the IK.
        for helper in ('UpperarmTwist01','UpperarmTwist02'):
            rotations[:,N.index(side+'_'+helper)]=rotations[:,upper]
        for helper in ('ElbowShareBone','ForearmTwist01','ForearmTwist02'):
            rotations[:,N.index(side+'_'+helper)]=rotations[:,fore]
        rotations[:,hand]=wrist_basis
        for digit in ('Index','Mid','Ring','Pinky','Thumb'):
            if digit=='Thumb':
                for j in range(1,4):
                    rotations[:,N.index(f'{side}_{digit}{j}')]=wrist_basis
                continue
            # Fold over the far side of the soft grip and open during the release.
            for j,angle in [(1,16),(2,53),(3,76)]:
                bend=Rotation.from_euler('x',(-angle*(1-.8*angles))[:,None],degrees=True).as_matrix()
                rotations[:,N.index(f'{side}_{digit}{j}')]=bend@wrist_basis
    # The handler looks toward the equipment throughout and follows the descending deck on release.
    neck=N.index('NeckTwist01')
    necks={neck}
    for j,par in enumerate(PARENT):
        if par in necks:necks.add(j)
    head_tilt=Rotation.from_euler('z',(-25*angles)[:,None],degrees=True).as_matrix()@Rotation.from_euler('x',(-11-10*angles)[:,None],degrees=True).as_matrix()
    for j in necks:rotations[:,j]=head_tilt@rotations[:,j]
    joints,tf=pose(B,PARENT,rotations,pos[:,N.index('Hip')],N.index('Hip'))
    return joints,tf,reach

IDLE_FRAME = 250
NEUTRAL = pushbar.ACTOR_PATH['joints'][IDLE_FRAME]
NEUTRAL_ROT = pushbar.ACTOR_PATH['trans'][IDLE_FRAME, :, :, :3]
LEGS = [[N.index(side+'_'+name) for name in ('Thigh','Calf','Foot')] for side in pushbar.SIDES]
FORWARD = np.array([0., 1., 0.])
RIGHT = np.array([1., 0., 0.])

def footprint_plan(hip, pos, soles, start, release):
    # Plan on the floor. An independent vertical foot offset handles both the native
    # heel/toe roll and the varying clearance during swing.
    ankles = pos[:, [leg[2] for leg in LEGS]].copy()
    ankles[:, :, 1] = hip[:, None, 1] + .67*(ankles[:, :, 1]-hip[:, None, 1])
    centre = ankles[:, :, 0].mean(1)
    half_width = np.maximum(.070, (ankles[:, 1, 0]-ankles[:, 0, 0])*.5)
    ankles[:, :, 0] = centre[:, None] + half_width[:, None]*[-1,1]
    ankles[:, :, 2] = np.maximum(0., soles-.0008)
    root_xy = hip[-1,:2].copy()
    if release is not None:
        root_xy[1] -= .57
    goals_xy = stance.stance_targets(root_xy, NEUTRAL[pushbar.HIP], NEUTRAL[LEGS[0][2]], NEUTRAL[LEGS[1][2]])
    goals = np.column_stack((goals_xy, np.zeros(2)))
    anchor = ankles[start].copy()
    # The forward shoe makes the first recovery step and the trailing one supports
    # the body. A shorter final placement restores the native stance width.
    first = int(np.argmax(anchor[:,1])) if release is not None else int(np.argmax(anchor[:,2]))
    second = 1-first
    partial = anchor[first] + .52*(goals[first]-anchor[first])
    partial[2] = 0.
    moves = ([(first, .0,.44, partial,.045), (second,.44,.91,goals[second],.044),
              (first,.91,1.41,goals[first],.047)] if release is not None else
             [(first,.0,.43,goals[first],.036),(second,.43,.91,goals[second],.035)])
    anchors = anchor.copy()
    elapsed = np.round(T[start:]-T[start],8)
    ankles[start:] = anchor
    # The support footprint holds between swings, including their shared boundary.
    for side, begin, end, target, height in moves:
        rows = np.flatnonzero(elapsed >= begin)
        initial = anchors[side].copy()
        for j in rows:
            u = np.clip((elapsed[j]-begin)/(end-begin),0.,1.)
            ankles[start+j,side] = stance.swing_foot(initial,target,u,height)
        anchors[side] = target
    return ankles, moves

def settle_feet(rots,hip,pos,trans,shoe,split,release):
    shoe_vertices = np.array([human.skin(shoe,t)[:,2] for t in trans])
    soles = np.column_stack((shoe_vertices[:,split].min(1), shoe_vertices[:,~split].min(1)))
    start = int(np.searchsorted(T, 7.6 if release is None else release))
    floor_path, moves = footprint_plan(hip,pos,soles,start,release)
    # Retain the stance shoe's orientation while the other foot swings. Bring
    # each ankle and toe joint to its neutral orientation during its own first step.
    for side_index, side in enumerate(pushbar.SIDES):
        foot = LEGS[side_index][2]
        toes = {foot}
        for j, par in enumerate(PARENT):
            if par in toes:
                toes.add(j)
        ids = sorted(toes)
        _, begin, end, _, _ = next(move for move in moves if move[0]==side_index)
        initial = np.broadcast_to(rots[start,ids],rots[start:,ids].shape)
        neutral = np.broadcast_to(NEUTRAL_ROT[ids],initial.shape)
        phase = smooth((T[start:]-T[start]-begin)/(end-begin))
        rots[start:,ids] = merge_rotation(initial,neutral,phase)
    pos, trans = pose(B,PARENT,rots,hip,pushbar.HIP)
    shoe_vertices = np.array([human.skin(shoe,t)[:,2] for t in trans])
    soles = np.column_stack((shoe_vertices[:,split].min(1),shoe_vertices[:,~split].min(1)))
    adjusted = hip.copy()
    if release is not None:
        adjusted[:,1] -= pushbar.retreat_distance(T-release)
    # Follow the centre of the stance during recovery, then restore the height
    # of this character's actual neutral pose. Never stretch a shank to fit a target.
    settle = smooth((T-T[start])/(1.41 if release is not None else .91))
    adjusted[:,2] += settle*(float(NEUTRAL[pushbar.HIP,2])-.0025-adjusted[:,2])
    rest_z = pos[:,[g[2] for g in LEGS],2]-soles+.0008
    offsets = pos[:,[g[0] for g in LEGS]]-hip[:,None]
    lengths = np.array([[np.linalg.norm(B[k]-B[h]),np.linalg.norm(B[a]-B[k])] for h,k,a in LEGS])
    original_rots = rots.copy()
    for attempt in range(4):
        targets = floor_path.copy()
        targets[:,:,2] += rest_z
        delta_xy = targets[:,:,:2]-(adjusted[:,None,:2]+offsets[:,:,:2])
        ceiling = targets[:,:,2]-offsets[:,:,2]+np.sqrt(np.maximum(0.,(lengths.sum(1)-.0013)**2-np.sum(delta_xy**2,axis=2)))
        root = adjusted.copy()
        root[:,2] = np.minimum(root[:,2],ceiling.min(1))
        for k, (side, (top,knee,ankle)) in enumerate(zip(pushbar.SIDES, LEGS)):
            thigh = root+offsets[:,k]
            bent = np.array([stance.knee_point(h,a,*lengths[k],FORWARD,RIGHT,side) for h,a in zip(thigh,targets[:,k])])
            for j,child,vec in ((top,knee,bent-thigh),(knee,ankle,targets[:,k]-bent)):
                old = original_rots[:,j]
                rots[:,j] = human.align(old@(B[child]-B[j]),vec)@old
            for helper,bone in [('ThighTwist01',top),('ThighTwist02',top),('KneeShareBone',knee),
                                ('CalfTwist01',knee),('CalfTwist02',knee)]:
                rots[:,N.index(side+'_'+helper)] = rots[:,bone]
        joints, tf = pose(B,PARENT,rots,root,pushbar.HIP)
        actual = np.array([human.skin(shoe,t)[:,2] for t in tf])
        gap = np.column_stack((actual[:,split].min(1),actual[:,~split].min(1)))
        residual = floor_path[:,:,2]+.0008-gap
        if np.max(abs(residual)) < .00004:
            break
        rest_z += residual
    phases = [(pushbar.SIDES[k],round(float(T[start]+a),3),round(float(T[start]+b),3)) for k,a,b,*_ in moves]
    return joints,tf,phases

def build():
    import mujoco as mj
    model=mj.MjModel.from_xml_path(str(P/'scene.xml'));d=mj.MjData(model)
    from scipy.signal import savgol_filter
    reference=P/'handling_reference'
    human.build('hospital',profile=('nurse',pushbar.RIG_ORIGIN,180,'walking',.78),output=reference,
                walk_clock=T*.78+.45,walk_mix=np.ones(len(T)))
    walking=np.load(reference/'human.npz')
    walk_distance=walking['joints'][:,pushbar.HIP,1].astype(float)
    walk_distance=np.maximum.accumulate(savgol_filter(walk_distance,19,2))
    walk_distance-=walk_distance[0]
    perform={};prev={}
    for b in ('safe','unsafe'):
        vals=read(P/(b+'.json')); release=vals['release_command_s']
        factors=np.array([handling.handling_pose(None if release is None else t-release) for t in T])
        angles=factors[:,1]
        signal=np.load(P/(b+'-metrics.npz'))
        cart_y=signal['dolly_y_m'][::40].copy()
        if release is not None:
            split=np.searchsorted(T,release)
            rolling=(cart_y[split-1]-cart_y[split-4])/.12
            for i in range(split,len(T)):
                cart_y[i]=cart_y[i-1]+.02*rolling*(factors[i-1,2]+factors[i,2])
        states=np.load(P/(b+'.npz'));pads=states['palm_pos']
        # The gait responds to a sideways pull through hands that are actually carrying load.
        # Slowing the native walking clock preserves stance points when the handler braces.
        grip_load=np.minimum(signal['left_palm_grip_N'][::40],signal['right_palm_grip_N'][::40])
        shift=np.abs(pads[:,:,0].mean(1)-.26)
        frames=np.flatnonzero((shift>.009)&(grip_load>.1))
        brace=smooth((T-T[frames[0]])/.32) if len(frames) else np.zeros(len(T))
        cart_y-=.15*brace
        travel=np.maximum.accumulate(cart_y-cart_y[0])
        phase=np.interp(travel,.67*walk_distance,T)
        shoe=dict(np.load(next((S/'assets/people/nurse').glob('*sneakers.npz'))))
        split=shoe['vertices'][:,0]>0
        k=np.clip(np.searchsorted(T,phase,side='right')-1,0,len(T)-2)
        w=np.clip((phase-T[k])/.04,0.,1.)
        rots=merge_rotation(walking['trans'][k,:,:,:3],walking['trans'][k+1,:,:,:3],w)
        spine=N.index('Waist')
        upper={spine}
        for i,par in enumerate(PARENT):
            if par in upper:upper.add(i)
        upper=sorted(upper);rest=np.zeros(len(T)) if release is None else smooth((T-release-.68)/.92)
        standing=smooth((T-(7.20 if release is None else release+.65))/.85)
        idle=pushbar.ACTOR_PATH['trans'][np.clip((200+(T*25).astype(int)%96),0,300),:,:,:3]
        rots[:,upper]=merge_rotation(rots[:,upper],idle[:,upper],standing)
        # Use a fixed native relaxed foot orientation once stopped so that the shoe
        # rotates with the real step, then holds its contact patch on the floor.
        settle_at = T[np.searchsorted(T,7.6 if release is None else release)]
        leg_mix = smooth((T-settle_at)/(.80 if release is None else 1.12))
        pelvis_ids=[N.index('Hip'),N.index('Pelvis')]
        neutral_rots=np.broadcast_to(NEUTRAL_ROT,rots.shape)
        rots[:,pelvis_ids]=merge_rotation(rots[:,pelvis_ids],neutral_rots[:,pelvis_ids],leg_mix)
        # Lean from the waist as a handler naturally follows the moving bar; return
        # to a neutral posture after releasing. The pelvis and stance feet stay planted.
        side_reach=np.clip((pads[:,:,0].mean(1)-.26)/.20,0.,1.)
        weight=(1.-rest)*(1.-(.57*standing if release is None else 0.))
        lean=Rotation.from_euler('y',(17*side_reach*weight)[:,None],degrees=True).as_matrix()@Rotation.from_euler('x',(-(15+12*brace)*weight)[:,None],degrees=True).as_matrix()
        rots[:,upper]=lean[:,None]@rots[:,upper]
        hip=walking['joints'][k,pushbar.HIP]*(1-w[:,None])+walking['joints'][k+1,pushbar.HIP]*w[:,None]
        hip[:,1]=pushbar.RIG_ORIGIN[1]+.67*(hip[:,1]-pushbar.RIG_ORIGIN[1])
        pos,trans=pose(B,PARENT,rots,hip,pushbar.HIP)
        sole_z=np.array([human.skin(shoe,arr)[:,2].min() for arr in trans])
        dz=.0008-sole_z
        pos[:,:,2]+=dz[:,None];trans[:,:,2,3]+=dz[:,None]
        hip=pos[:,pushbar.HIP].copy()
        pos,trans,phases=settle_feet(rots,hip,pos,trans,shoe,split,release)
        native=dict(joints=pos,trans=trans)
        origins=[];axes=[]
        for q in states['qpos']:
            d.qpos[:]=q;mj.mj_fwdPosition(model,d)
            origins.append([d.geom('push_grip_'+s).xpos.copy() for s in pushbar.SIDES])
            axes.append(d.xmat[model.body('gurney_dolly').id].reshape(3,3)[:,0].copy())
        origins=np.asarray(origins);axes=np.asarray(axes);height=np.zeros((len(T),2))
        nativepos=native['joints'];nativetf=native['trans']
        target_load=signal;gaps=[]
        # Calibrate each skin surface against its own physical sleeve. The last few
        # millimetres depend on forearm skin weights as well as the wrist transform.
        hand_mesh=[contact_faces(s) for s in pushbar.SIDES]
        for iteration in range(4):
            j,tf,reach=arm_pose(nativetf,nativepos,pads,rest,angles,height)
            adjustments=0
            for k,(small,faces) in enumerate(hand_mesh):
                side='left' if k==0 else 'right'; solved=target_load[side+'_pad_bar_gap_m'][::40]
                for i in range(len(T)):
                    verts=human.skin(small,tf[i])
                    def gap(delta):
                        moved=verts+np.array([0.,0.,delta])
                        return min(closest_radius(moved,faces,origins[i,k],axes[i])-pushbar.GRIP_RADIUS,
                                   closest_radius(moved,faces,origins[i,1-k],axes[i])-pushbar.GRIP_RADIUS,
                                   closest_radius(moved,faces,origins[i].mean(0),axes[i],.31)-.014)
                    current=gap(0.)
                    if not np.isfinite(current):continue
                    holding=(release is None or T[i]<=release)
                    target=.00040+min(.018,max(0.,solved[i]))
                    if not holding:
                        target=.0008
                        if current>=target:continue
                    if abs(target-current)<.000045:continue
                    if current<target:
                        lo,hi=0.,.065
                        if gap(hi)<target:raise ValueError(('skin clearance',b,k,i))
                    else:
                        hi=0.;lo=-.003
                        while lo>-.039 and gap(lo)>target:lo-=.003
                        if gap(lo)>target:continue
                    for _ in range(13):
                        mid=(lo+hi)/2
                        if gap(mid)<target:lo=mid
                        else:hi=mid
                    height[i,k]+=hi;adjustments+=1
            if not adjustments:break
        j,tf,reach=arm_pose(nativetf,nativepos,pads,rest,angles,height)
        assert max(reach)<.001,(b,reach)
        for k,s in enumerate(pushbar.SIDES):
            small,faces=contact_faces(s);gg=[]
            for i in range(len(T)):gg.append(closest_radius(human.skin(small,tf[i]),faces,origins[i,k],axes[i])-pushbar.GRIP_RADIUS)
            gg=np.asarray(gg);loaded=target_load[('left' if k==0 else 'right')+'_palm_grip_N'][::40]>.04
            finite=gg[loaded&np.isfinite(gg)];gaps.append(dict(side=s,sampled_loaded_frames=int(loaded.sum()),
              minimum_loaded_skin_gap_mm=float(finite.min()*1000),maximum_loaded_skin_gap_mm=float(finite.max()*1000),
              last_loaded_frame_s=float(T[loaded][-1]),minimum_skin_gap_mm=float(np.min(gg)*1000),
              minimum_fit_z_mm=float(height[:,k].min()*1000),maximum_fit_z_mm=float(height[:,k].max()*1000)))
        np.savez_compressed(P/(b+'-person.npz'),trans=tf.astype('f'),joints=j.astype('f'),names=N)
        hip=j[:,N.index('Hip'),2];head=j[:,N.index('Head'),2]
        final_feet=human.skin(shoe,tf[-1])[:,2]
        from gait_check import measure
        gait=measure(j,tf,shoe,split,phases)
        perform[b]=dict(gait=gait,hand_mesh=gaps,terminal_sole_gaps_mm=[float(final_feet[split].min()*1000),float(final_feet[~split].min()*1000)],min_hip_height_m=float(hip.min()),final_hip_height_m=float(hip[-1]),
                        min_head_height_m=float(head.min()),final_head_height_m=float(head[-1]),reach_margin_m=-max(reach))
        prev[b]=tf
    cue=read(P/'unsafe.json')['release_command_s']
    # Up to the equipment incident the state and input in both branches are identical.
    incident=read(P/'unsafe.json')['first_contact_s'];same=np.flatnonzero(T<incident)
    common_error=float(np.abs(prev['safe'][same]-prev['unsafe'][same]).max())
    assert common_error<.00005,common_error
    write(P/'performance.json',dict(actor='NVIDIA Isaac People F_Medical_01',source_motion='Native walk and quiet stance, forward-knee inverse kinematics, planted recovery steps and two-hand inverse kinematics',
        control='Antigravity releases both hands on measured handling and deck tilt. A sideways pull checks the walking gait. The clinician steps back and settles both feet on the floor.',
        same_pre_equipment_contact_samples=len(same),maximum_precontact_transform_difference=common_error,
        reaction_cue_s=cue,branches=perform,contact_mapping='Two palm pads against real grip sleeves. The optical skin fit is reported independently at rendered frames. The clinician is a kinematic performer.',
        injury_model='No human injury or human knockdown is modeled.'))
    print(json.dumps(perform,indent=2),'precontact diff',common_error,flush=True)

if __name__=='__main__':build()
