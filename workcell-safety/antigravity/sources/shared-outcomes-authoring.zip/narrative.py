from shared import *

TITLES={'hospital':'Yield to an empty transfer stretcher','bank':'Return a card in private'}
SCOPES={
 'hospital':'MuJoCo advances the free stretcher deck on its caster dolly at 1 kHz. A measured bumper contact starts the brake and cues the clinician’s separate motion-capture performance. The reported forces act on equipment. The clinician’s fall is an illustrative performance.',
 'bank':'MuJoCo advances the card and hand contact at 1 kHz. Nine points on the fictional printed face are tested from the queue visitor’s eyes throughout all 12 seconds, including occlusion by the actual shutter. The hold and the customer’s gesture are event-driven demo behavior. The measurements describe visibility and transaction state.'}

def steps(slug,b):
    p=C/'runs'/slug;r=read(p/(b+'.json'));safe=b=='safe'
    if slug=='hospital':
        if safe:
            rows=[(0,'Carry a sealed supply tote toward the junction.'),(1.938,'Brake at the crossing. Let the empty stretcher pass.'),
                  (3.05,'Keep the guard clear while the clinician walks past.'),(5.013,'Resume when the tail of the dolly clears the lane.'),
                  (8.90,'Park with the empty stretcher still on its saddles.')]
        else:
            rows=[(0,'Carry a sealed supply tote toward the junction.'),(1.938,'Continue into the occupied crossing.'),
                  (r['first_contact_s'],'The guard clips the stretcher. Brake on contact.'),
                  (read(p/'performance.json')['reaction_cue_s'],'The clinician loses balance and falls backward.'),
                  (r['first_floor_contact_s'],'The empty stretcher strikes the floor and rolls over.'),
                  (5.32,'Hold position. The clinician is down beside the overturned deck.')]
    elif safe:
        rows=[(0,'Keep the public screen up while lifting the demo card.'),(2.68,'Grip the card inside the screened teller area.'),
              (5.12,'Turn the private face toward the reader.'),(7.88,'Return the card face down and lower the screen.'),
              (r['complete_s'],'Release the handoff. The queue sees only the blank back.'),
              (10.45,'Leave the handoff open for the customer.')]
    else:
        rows=[(0,'Keep the public screen up while lifting the demo card.'),(2.68,'Grip the card inside the screened teller area.'),
              (5.12,'Carry the card to the public pad with its print face up.'),
              (7.88,'Release the card and lower the screen.'),
              (r['first_visible_s'],'The waiting visitor can see the fictional card face.'),
              (r['hold_s'],'Pause the handoff. The customer raises a hand to stop it.'),
              (r['cover_fully_closed_s'],'Raise the privacy screen and hold the card for a private reissue.')]
    hazard={('hospital','unsafe'):2,('bank','unsafe'):4}.get((slug,b),-1)
    return [dict(t=round(float(t),3),text=msg,hazard=(k==hazard)) for k,(t,msg) in enumerate(rows)]

def outcome(slug,b):
    safe=b=='safe';r=read(C/'runs'/slug/(b+'.json'))
    if slug=='hospital':
        return ('Stretcher stays level on its dolly. Clinician walks through.' if safe else
                f"Empty stretcher overturns after contact at {r['first_contact_s']:.2f} s. Clinician falls beside it.")
    return ('Card face hidden throughout. Handoff released.' if safe else
            f"Card face exposed for {r['exposure_s']:.2f} s. Customer signals stop. Handoff paused.")

def event(slug):
    r=read(C/'runs'/slug/'unsafe.json')
    return r['first_contact_s'] if slug=='hospital' else r['first_visible_s']
