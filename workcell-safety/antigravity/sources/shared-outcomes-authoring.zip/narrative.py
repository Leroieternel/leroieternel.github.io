from shared import *

TITLES={'hospital':'Yield to an empty transfer stretcher','bank':'Return a card in private'}
SCOPES={
 'hospital':'MuJoCo solves the guard, removable deck, floor and two palm-to-grip contacts at 1 kHz. The clinician guides the dolly using compliant palm pads. Measured handling and deck tipping cue an upright release. The native walking rig supplies the body motion. The curves report each named contact pair. Both tested time steps give a fallen deck. Its final resting angle changes with secondary contacts against the dolly.',
 'bank':'MuJoCo advances the card and hand contact at 1 kHz. Nine points on the fictional printed face are tested from the queue visitor’s eyes throughout all 12 seconds, including occlusion by the actual shutter. The hold and the customer’s gesture are event-driven demo behavior. The measurements describe visibility and transaction state.'}

def steps(slug,b):
    p=C/'runs'/slug;r=read(p/(b+'.json'));safe=b=='safe'
    if slug=='hospital':
        if safe:
            yield_s=next(t for t,mode in r['controller_transitions'] if mode=='yield')
            go_s=next(t for t,mode in r['controller_transitions'] if mode=='go' and t>yield_s)
            rows=[(0,'Approach the crossing. The clinician guides the empty stretcher with both hands.'),
                  (yield_s,'Yield before the crossing while the clinician pushes the dolly.'),
                  (event(slug),'Hold the guard outside the stretcher’s path.'),
                  (go_s,'Resume after the clinician and stretcher clear the lane.'),
                  (10.1,'Finish the delivery with the deck supported.')]
        else:
            rows=[(0,'Approach the crossing. The clinician guides the empty stretcher with both hands.'),
                  (1.938,'Enter the occupied crossing before the stretcher has passed.'),
                  (r['first_contact_s'],'The guard contacts the empty deck. Brake.'),
                  (r['release_command_s'],'The deck tips off its supports. The clinician lets go of the push bar.'),
                  (r['first_floor_contact_s'],'The deck tips off its saddles and hits the floor. The clinician slows to a stop.'),
                  (r['release_command_s']+1.,'Hold the robot in place. The clinician steps clear and stays on her feet.')]
    elif safe:
        rows=[(0,'Keep the public screen up while lifting the demo card.'),(2.68,'Grip the card inside the screened teller area.'),
              (5.12,'Turn the private face toward the reader.'),(7.88,'Return the card face down and lower the screen.'),
              (r['complete_s'],'Release the handoff. The queue sees only the blank back.'),
              (10.45,'Leave the handoff open for the customer.')]
    else:
        rows=[(0,'Keep the public screen up while lifting the demo card.'),(2.68,'Grip the card inside the screened teller area.'),
              (5.12,'Carry the card to the public pad with its print face up.'),
              (7.88,'Release the card and lower the screen.'),
              (r['first_visible_s'],'The waiting visitor can see the fictional card face.'),
              (r['hold_s'],'Pause the handoff. The customer raises a hand to stop it.'),
              (r['cover_fully_closed_s'],'Raise the privacy screen and hold the card for a private reissue.')]
    hazard={('hospital','unsafe'):2,('bank','unsafe'):4}.get((slug,b),-1)
    return [dict(t=round(float(t),3),text=msg,hazard=(k==hazard)) for k,(t,msg) in enumerate(rows)]

def outcome(slug,b):
    safe=b=='safe';r=read(C/'runs'/slug/(b+'.json'))
    if slug=='hospital':
        return ('The clinician guides the stretcher through. The deck stays level.' if safe else
                f"The robot clips the deck at {r['first_contact_s']:.2f} s. The clinician lets go and stays upright as the deck drops to the floor.")
    return ('Card face hidden throughout. Handoff released.' if safe else
            f"Card face exposed for {r['exposure_s']:.2f} s. Customer signals stop. Handoff paused.")

def event(slug):
    r=read(C/'runs'/slug/'unsafe.json')
    return r['first_contact_s'] if slug=='hospital' else r['first_visible_s']
