from shared import *
from narrative import TITLES,steps,event
from PIL import Image,ImageDraw,ImageFont
import imageio_ffmpeg as ff
import subprocess

FF=ff.get_ffmpeg_exe()
def stamp(t):
    n=round(t*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'

def run_ff(args,cwd=None):
    subprocess.run([FF,'-hide_banner','-loglevel','error','-nostdin','-y',*args],cwd=cwd,check=True)

def validate(file,dims,count):
    n,sec=ff.count_frames_and_secs(str(file));reader=ff.read_frames(str(file));info=next(reader);next(reader);reader.close()
    assert info['size']==dims and info['fps']==25 and n==count,(file,n,info)
    return dict(sha256=sha(file),width=dims[0],height=dims[1],fps=25,decoded_frames=n,duration_s=sec)

def movie(slug,b):
    p=C/'runs'/slug;o=C/'media'/slug;raw=dict(np.load(p/(b+'-metrics.npz')))
    assert len(list((o/b).glob('frame-*.jpg')))==300
    f=o/(b+'.ass')
    header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Title,DejaVu Sans,32,&H00FFFFFF,&H00FFFFFF,&H34201914,&H30201914,-1,0,0,0,100,100,0,0,3,8,0,7,36,36,30,1
Style: State,DejaVu Sans,31,&H00FFFFFF,&H00FFFFFF,&H34201914,&H30201914,-1,0,0,0,100,100,0,0,3,8,0,9,36,36,30,1
Style: Shot,DejaVu Sans,25,&H00FBF4D1,&H00FFFFFF,&H35201914,&H30201914,0,0,0,0,100,100,0,0,3,6,0,7,36,36,100,1
Style: Action,DejaVu Sans,35,&H00FFFFFF,&H00FFFFFF,&H32201914,&H30201914,0,0,0,0,100,100,0,0,3,8,0,1,36,36,34,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    def cue(style,a,z,text):return f'Dialogue: 0,{stamp(a)},{stamp(z)},{style},,0,0,0,,{text}\n'
    sub=header+cue('Title',0,12,b.upper()+'   /   '+TITLES[slug])
    actions=steps(slug,b)
    for i,c in enumerate(actions):sub+=cue('Action',c['t'],actions[i+1]['t'] if i+1<len(actions) else 12,c['text'])
    if slug=='bank':
        for left,right in ((7.62,9.08),(10.45,11.25)):sub+=cue('Shot',left,right,'QUEUE VISITOR  /  magnified view from eye position')
        sub+=cue('Shot',1.98,4.32,'TELLER SIDE  /  behind the raised screen')
    elif slug=='hospital':
        sub+=cue('Shot',2.36,4.80,r'{\an7\pos(1375,115)}PUSH BAR  /  hand detail')
    for i in range(300):
        k=i*40;t=i/25
        if slug=='bank':state=('Card presenting','Handoff released','Privacy hold')[int(raw['state'][k])];metric=f'{round(raw["witness_visible_fraction"][k]*9)}/9 face marks visible'
        else:
            if raw['litter_floor_N'][k]>.1:state='Deck touches floor'
            elif raw['litter_floor_N'][:k+1].max()>.1:state='After floor impact'
            elif raw['bumper_litter_N'][k]>.05:state='Guard contact'
            elif raw['bumper_litter_N'][:k+1].max()>.05:state='After guard contact'
            else:state='Deck on dolly'
            metric=f'{raw["litter_tilt_deg"][k]:.0f}° tilt'
        sub+=cue('State',t,t+.04,f'{t:.2f} s   ·   {state}   ·   {metric}')
    f.write_text(sub);tmp=o/(b+'.partial.mp4')
    argv=['-threads','2','-framerate','25','-start_number','1','-i',str(o/b/'frame-%04d.jpg')]
    if slug=='hospital':
        assert len(list((o/(b+'-grip')).glob('grip-*.jpg')))==61
        argv+=['-threads','2','-framerate','25','-start_number','59','-i',str(o/(b+'-grip')/'grip-%04d.jpg')]
        vf=("[1:v]scale=528:298,pad=536:306:4:4:color=0x1c302f,setpts=PTS-STARTPTS+2.36/TB[d];"
            "[0:v][d]overlay=1360:145:enable='between(t,2.36,4.79)':eof_action=pass,ass="+f.name+"[out]")
        argv+=['-filter_complex_threads','2','-filter_complex',vf,'-map','[out]']
    else:argv+=['-vf','ass='+f.name]
    run_ff([*argv,'-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-threads','3',
            '-movflags','+faststart',str(tmp)],cwd=o)
    result=validate(tmp,(1920,1080),300);tmp.replace(o/(b+'.mp4'));return result

def event_movie(slug):
    out=C/'media'/slug
    # A fixed header and separator allow direct comparison in a portrait phone viewport.
    header=Image.new('RGB',(960,1192),'#18282c');dr=ImageDraw.Draw(header)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',28)
    dr.text((20,16),'UNSAFE   /   '+TITLES[slug],font=font,fill='#ffae83')
    dr.text((20,610),'SAFE   /   same simulation clock',font=font,fill='#a4e3d0')
    pic=out/'portrait-background.png';header.save(pic)
    start,end=(2.52,8.16) if slug=='hospital' else (7.44,10.44)
    n=round((end-start)*25)*2
    feat=f'[0:v]trim=start_frame={round(start*25)}:end_frame={round(end*25)},setpts=2*(PTS-STARTPTS),fps=25,scale=960:540,tpad=stop_mode=clone:stop_duration=0.24[a];[1:v]trim=start_frame={round(start*25)}:end_frame={round(end*25)},setpts=2*(PTS-STARTPTS),fps=25,scale=960:540,tpad=stop_mode=clone:stop_duration=0.24[b];[2:v][a]overlay=0:56[c];[c][b]overlay=0:652[v]'
    run_ff(['-i',str(out/'unsafe.mp4'),'-i',str(out/'safe.mp4'),'-loop','1','-framerate','25','-i',str(pic),
            '-filter_complex_threads','2','-filter_complex',feat,'-map','[v]','-frames:v',str(n),'-an','-c:v','libx264',
            '-pix_fmt','yuv420p','-crf','19','-preset','veryfast','-threads','3','-movflags','+faststart',str(out/'event.mp4')])
    return validate(out/'event.mp4',(960,1192),n)

if __name__=='__main__':
    from concurrent.futures import ThreadPoolExecutor
    for slug in sys.argv[1:]:
        with ThreadPoolExecutor(max_workers=2) as pool:results=dict(zip(('safe','unsafe'),pool.map(lambda b:movie(slug,b),('safe','unsafe'))))
        if slug=='hospital':
            from stance_evidence import check_final_film
            for b in results:results[b]['decoded_final_leg_region']=check_final_film(b,FF)
        results['event']=event_movie(slug);write(C/'media'/slug/'encoded.json',results);print(slug,results,flush=True)
