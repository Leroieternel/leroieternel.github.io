"""Compare the published baseline and corrected standing pose at the same camera and time."""
from shared import C, read, sha
from PIL import Image, ImageDraw, ImageFont, ImageOps

FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans'
def typeface(size,bold=False):
    return ImageFont.truetype(FONT+('-Bold' if bold else '')+'.ttf',size)

def stance_sheet(dest,performance):
    prior=read(C/'proofs/previous-stance.json')
    before=C/'proofs/hospital-before-stance.jpg'
    assert sha(before)==prior['prior_still_sha256']
    now=performance['branches']['unsafe']['gait']
    sheet=Image.new('RGB',(1080,980),'#17282c')
    ink=ImageDraw.Draw(sheet)
    ink.text((28,15),'Clinician recovery stance',font=typeface(38,True),fill='#f5f6f0')
    ink.text((30,67),'Unsafe replay at 11.96 s  /  same camera and crop',font=typeface(24),fill='#c5d8d5')
    after=C/'media/hospital/unsafe/frame-0300.jpg'
    panels=[(before,'Previous replay','#ffc5ac'),(after,'Corrected replay','#b1ecd5')]
    for i,(filename,label,tint) in enumerate(panels):
        x=28+522*i
        ink.text((x,117),label,font=typeface(25,True),fill=tint)
        with Image.open(filename) as image:
            crop=image.crop((80,237,765,1001))
            sheet.paste(ImageOps.fit(crop,(504,505),method=Image.Resampling.LANCZOS),(x,159))
        left=prior['unsafe']['terminal_signed_knee_flexion_deg']['L'] if i==0 else now['signed_knee_flexion']['L']['end_deg']
        width=prior['unsafe']['terminal_ankle_spacing_mm'] if i==0 else now['terminal_ankle_spacing_mm']
        direction='backward' if left<0 else 'forward'
        ink.text((x,675),f'Left knee: {abs(left):.1f}° {direction}',font=typeface(24,True),fill=tint)
        ink.text((x,714),f'Ankle spacing: {width/10:.1f} cm',font=typeface(22),fill='#e6ece8')
    for i,(frame,label) in enumerate([(91,'Right foot steps back'),(100,'Left foot follows'),(114,'Right foot returns')]):
        x=28+347*i
        with Image.open(C/'proofs'/f'hospital-unsafe-legs-{frame:03}.jpg') as im:
            w,h=im.size; crop=im.crop((w*.16,h*.33,w*.90,h*.98))
            sheet.paste(ImageOps.fit(crop,(328,162),method=Image.Resampling.LANCZOS),(x,770))
        ink.text((x,943),f'{frame/25:.2f} s  {label}',font=typeface(18),fill='#e6ece8')
    sheet.save(dest/'stance-comparison.jpg',quality=93,optimize=True)

def check_final_film(branch, ffmpeg):
    import numpy as np
    import subprocess
    folder=C/'media/hospital'
    data=subprocess.check_output([ffmpeg,'-v','error','-ss','11.96','-i',str(folder/(branch+'.mp4')),
                                  '-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-threads','1','pipe:1'])
    image=np.frombuffer(data,np.uint8).reshape(1080,1920,3)
    bounds=(170,525,510,945) if branch=='unsafe' else (1030,420,1175,660)
    x,y,r,b=bounds
    def difference(path):
        with Image.open(path) as source:
            return float(abs(image[y:b,x:r].astype('i2')-np.asarray(source.convert('RGB').crop(bounds)).astype('i2')).mean())
    current=difference(folder/branch/'frame-0300.jpg')
    assert current<6.,(branch,current)
    result=dict(time_s=11.96,pixel_crop=list(bounds),mean_rgb_error_255=round(current,3))
    if branch=='unsafe':
        previous=difference(C/'proofs/hospital-before-stance.jpg')
        assert previous>2*current,(current,previous)
        result['mean_rgb_error_from_previous_replay_255']=round(previous,3)
    return result
