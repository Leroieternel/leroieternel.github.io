import ast,hashlib,json,math,sys
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent;BASE=D.parents[1]/'mobile_worlds';sys.path.extend([str(BASE/'physics'),str(BASE),str(D.parent)])
import world
from generated.layouts import DATA
assert hashlib.sha256((D/'generated/layouts.py').read_bytes()).hexdigest()==json.loads((D/'provenance/layouts.json').read_text())['sha256']
def rot(a):return np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])
def state(k):
    slug=world.SLUGS[k][3:];p,a,q,b,way=DATA[slug];return np.array(p),np.radians(a),np.array(q),np.radians(b),np.array(way)
def course(k):
    p,a,q,b,way=state(k)
    start=p+rot(a)@[-1.55,0];inward=rot(b)@[0,1]
    knots=[(0,start,a),(.4,start,a),(4.8,p,a),(11.,p,a)]
    def leg(nextpt,yaw,min_s=.85):
        t,last,prev=knots[-1];duration=max(min_s,np.linalg.norm(nextpt-last)*3.25,abs(yaw-prev)*3.5)
        knots.append((t+duration,nextpt,yaw))
    leg(p-rot(a)@[0,.53],a)
    for i,pt in enumerate(way):
        d=pt-knots[-1][1];head=math.atan2(d[1],d[0])
        leg(pt,head);knots.append((knots[-1][0]+(.85 if i==1 else .32),pt,head))
        if i==1:arrival=knots[-2][0]
    pre=q-.69*inward
    leg(pre,b);leg(q,b,2.4);dock=knots[-1][0]
    knots.append((dock+9.,q,b));leg(q-.72*inward,b,2.4)
    parking=q-1.15*inward+rot(b)@[.65,0];leg(parking,b,3.3);knots.append((knots[-1][0]+1.75,parking,b))
    return knots,dock,arrival
def refs(k,t):
    knots,_,_=course(k);times=[r[0] for r in knots];i=np.clip(np.searchsorted(times,t,'right')-1,0,len(knots)-2)
    f=np.clip((t-np.array(times)[i])/(np.diff(times)[i]),0,1);f=f**3*(10+f*(-15+6*f))
    xy=np.array([p for _,p,_ in knots]);head=np.unwrap([ang for _,_,ang in knots])
    h=head[i]+f*(head[i+1]-head[i]);point=xy[i]+f[:,None]*(xy[i+1]-xy[i]);pivot=np.array([-.21,0.])
    commanded=point-pivot+np.column_stack((-.21*np.cos(h),-.21*np.sin(h)))
    return commanded,h
def xml(k,out):
    import xml.etree.ElementTree as e
    p,a,q,b,way=state(k);r=e.parse(D.parent/'mobile/physics'/world.SLUGS[k]/'scene.xml');w=r.find('worldbody')
    oldsrc=np.array([world.PICK_X,0]);olddst=np.array([world.DEST_X,0])
    src=e.Element('body',name='source_installation',pos=world.vec([*(p-rot(a)@oldsrc),0]),euler=world.vec([0,0,a]))
    dst=e.Element('body',name='receiving_installation',pos=world.vec([*(q-rot(b)@olddst),0]),euler=world.vec([0,0,b]))
    for ob in list(w):
        n=ob.get('name','')
        if n=='payload':
            pos=np.fromstring(ob.get('pos'),sep=' ');ob.set('pos',world.vec([*(p+rot(a)@(pos[:2]-oldsrc)),pos[2]]));ob.set('quat',world.vec([math.cos(a/2),0,0,math.sin(a/2)]))
        elif ob.tag in ('body','geom') and n not in ('floor','base'):
            w.remove(ob);(src if n.startswith(('source_','pickup_')) else dst).append(ob)
    w.append(src);w.append(dst)
    if k==3:
        # The vertical flag has a passive detent so it stays upright until loaded.
        r.find(".//joint[@name='flag_pitch']").set('frictionloss','.0018')
    r.write(out/'scene.xml')
