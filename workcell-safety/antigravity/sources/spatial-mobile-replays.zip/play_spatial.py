import sys,time
from pathlib import Path
import mujoco as mj,mujoco.viewer,numpy as np
p=Path(__file__).resolve().parent/sys.argv[1];q=np.load(p/(sys.argv[2]+'.npz'))
m=mj.MjModel.from_xml_path(str(p/'scene.xml'));d=mj.MjData(m)
with mj.viewer.launch_passive(m,d) as v:
    start=time.monotonic()
    for t,x in zip(q['time_s'],q['qpos']):
        if not v.is_running():break
        d.qpos[:]=x;mj.mj_forward(m,d);v.sync();time.sleep(max(0,start+float(t)+.04-time.monotonic()))
