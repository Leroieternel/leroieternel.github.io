"""Render-space surface intersections, measured on both 25 Hz branches."""
import json
from pathlib import Path
import numpy as np
import bpy
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parent
def extract(mesh):
 pts=np.empty((len(mesh.vertices),3),'f');mesh.vertices.foreach_get('co',pts.ravel())
 mesh.calc_loop_triangles();faces=np.empty((len(mesh.loop_triangles),3),'i');mesh.loop_triangles.foreach_get('vertices',faces.ravel())
 return pts,faces
def corners(lo,hi):return np.array([[x,y,z] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
def review(slug,v,h):
 bpy.context.view_layer.update(); idx={o:i for i,o in enumerate(v.obs)};skin={o for o,_,_ in h};entries=[]
 def store(name,mesh,mat,ix=-1):
  a,f=extract(mesh)
  if not len(a) or not len(f):return
  if ix<0:a=a@mat[:3,:3].T+mat[:3,3]
  entries.append((name,a,f,corners(a.min(0),a.max(0)),ix))
 for o in v.scene.objects:
  if o in skin or o.name=='stage_ground':continue
  if o.type=='MESH':store(o.name,o.data,np.array(o.matrix_world),idx.get(o,-1))
  elif o.instance_type=='COLLECTION' and o.instance_collection:
   for item in o.instance_collection.objects:
    if item.type=='MESH':store(o.name,item.data,np.array(o.matrix_world@item.matrix_world))
 nv=[len(x) for o,xyz,f in h for x in [xyz[0]]];faces=np.concatenate([f+n for (o,xyz,f),n in zip(h,np.r_[0,np.cumsum(nv)[:-1]])])
 poses={b:np.asarray(v.frames[b]['poses']) for b in ['safe','unsafe']}
 audit={};robot_table={}
 for b in ['safe','unsafe']:
  logs={};fixed={};pairs={};bounds={};branch=poses[b]
  for ei,(name,xyz,fa,box,ix) in enumerate(entries):
   if ix<0:bounds[ei]=np.array([box.min(0),box.max(0)])
   else:
    mats=branch[:,ix];vo=np.einsum('tij,vj->tvi',mats[:,:9].reshape(-1,3,3),box)+mats[:,None,9:12];bounds[ei]=np.stack([vo.min(1),vo.max(1)],axis=1)
  lo=np.stack([np.broadcast_to(bounds[k],(301,2,3))[:,0] for k in range(len(entries))],axis=1);hi=np.stack([np.broadcast_to(bounds[k],(301,2,3))[:,1] for k in range(len(entries))],axis=1)
  tables=[k for k,e in enumerate(entries) if e[0].startswith(('receiving_rail_','retainer_finger_','reader_housing','catch_strut')) or e[0] in ('source_top','display_top','pickup_stem','pickup_pad','card_guide1','card_guide-1','receiving_stem','receiving_pad','padded_catch','suitcase','bed_frame','bed_mattress','bed_rail1','bed_rail-1','gantry_post1.48','gantry_post-1.48')]
  robot=[k for k,(_,_,_,_,ix) in enumerate(entries) if ix>=0 and v.spec[ix]['body'] not in ('world','payload','swing_flag','gurney') and v.spec[ix]['kind']=='mesh']
  for i in range(301):
   hp=np.concatenate([xyz[i] for _,xyz,_ in h]);bm=hp.min(0);bx=hp.max(0);sel=np.flatnonzero(np.all((lo[i]<=bx)&(hi[i]>=bm),axis=1)&(hi[i,:,2]>.005))
   def worldpts(k):
    name,xy,fc,box,ix=entries[k]
    if ix<0:return xy
    m=branch[i,ix];return xy@m[:9].reshape(3,3).T+m[9:12]
   def tree(e):
    ix=entries[e][4]
    if ix<0 and e in fixed:return fixed[e]
    bv=BVHTree.FromPolygons(worldpts(e),entries[e][2],all_triangles=True)
    if ix<0:fixed[e]=bv
    return bv
   if len(sel):
    hv=BVHTree.FromPolygons(hp,faces,all_triangles=True)
    for e in sel:
     if hv.overlap(tree(e)):logs.setdefault(entries[e][0],[]).append(i)
   for k in tables:
    for r in robot:
     if np.any(lo[i,r]>hi[i,k]) or np.any(hi[i,r]<lo[i,k]):continue
     if not tree(k).overlap(tree(r)):continue
     name=entries[k][0]+' / '+entries[r][0]
     pos=worldpts(r);inside=np.minimum(pos-lo[i,k],hi[i,k]-pos).min(1).max()
     pairs.setdefault(name,[]).append((i,round(max(0,float(inside))*1000,2)))
  audit[b]={k:{'frames':len(z),'first_s':z[0]/25,'last_s':z[-1]/25} for k,z in logs.items()}
  robot_table[b]={k:{'frames':len(z),'first_s':z[0][0]/25,'last_s':z[-1][0]/25,'max_depth_mm':max(a[1] for a in z)} for k,z in pairs.items()}
 out=dict(people_intersections=audit,robot_and_furniture=robot_table,samples_per_branch=301,frequency_Hz=25,original_rig_vertices=sum(nv),scope='Triangle surface crossings of original skinned person against visible robot, foreground props and set meshes at every replay sample. Also cross-check visible robot surfaces against working tables, suitcase, gurney and gantry uprights. Printed markings and the floor under planted feet are excluded. Intentional prop contacts are handled separately by MuJoCo.')
 (D/'runs'/slug/'mesh-check.json').write_text(json.dumps(out,indent=2));print('MESH AUDIT',slug,audit,robot_table,flush=True)
