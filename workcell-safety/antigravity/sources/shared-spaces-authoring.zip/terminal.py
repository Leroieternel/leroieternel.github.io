"""Identify the supporting surfaces at the last recorded pose of each free object."""
from world import *
def verify(slug):
 p=D/'runs'/slug;m=mj.MjModel.from_xml_path(str(p/'scene.xml'));obj=m.body('payload').id;rows={}
 for b in ('safe','unsafe'):
  a=np.load(p/(b+'.npz'));d=mj.MjData(m);q=a['qpos'];centers=[]
  for pose in q[-13:]:
   d.qpos[:]=pose;mj.mj_forward(m,d);centers.append(d.xpos[obj].copy())
  names={};w=np.zeros(6)
  for j,c in enumerate(d.contact):
   pair=[c.geom1,c.geom2]
   if obj not in m.geom_bodyid[pair]:continue
   ix=pair[1] if m.geom_bodyid[pair[0]]==obj else pair[0]
   mj.mj_contactForce(m,d,j,w)
   if w[0]>.004:names[m.geom(ix).name]=names.get(m.geom(ix).name,0)+float(w[0])
  final=readout=d.xmat[obj].reshape(3,3)[2,2]
  assert names,(slug,b)
  if slug=='bank':
   assert (final<-.98 if b=='safe' else final>.98) and any(n.startswith(('retainer_','receiving_')) for n in names),(b,final,names)
  elif b=='safe':assert 'display_top' in names
  elif slug=='museum':assert 'stage_ground' in names
  else:assert 'padded_catch' in names or 'catch_rim' in names
  rows[b]=dict(supports_at_last_pose=names,centre_xyz_m=centers[-1].tolist(),stripe_or_vertical_axis_z=final,centre_range_over_last_480ms_mm=float(np.linalg.norm(np.ptp(centers,axis=0))*1000))
 (p/'terminal.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':
 for s in sys.argv[1:] or ['bank','market','museum']:verify(s)
