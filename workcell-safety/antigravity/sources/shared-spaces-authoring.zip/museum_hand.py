"""Calibrate a spherical handling knob to the original Fourier hand surfaces."""
from world import *
from scipy.optimize import least_squares
m=build('museum');d=mj.MjData(m);init(m,d,'gr1');keys=['R_thumb_proximal_yaw_joint','R_thumb_proximal_pitch_joint','R_thumb_distal_joint','R_index_proximal_joint','R_index_intermediate_joint'];js=np.array([m.joint(n).qposadr[0] for n in keys]);hi=np.array([m.joint(k).range[1] for k in keys])
gids=[m.geom(k).id for k in ('R_thumb_distal_link_vis','R_index_intermediate_link_vis')]
def pair(q):
 d.qpos[js]=q;mj.mj_fwdPosition(m,d);pts=np.empty(6);dist=mj.mj_geomDistance(m,d,*gids,.5,pts)
 palm=d.body('r_palm');c=(pts.reshape(2,3).mean(0)-palm.xpos)@palm.xmat.reshape(3,3)
 return c,dist
def err(q):
 c,dist=pair(q);return np.r_[dist-.0284,(c-np.array([.049,.039,-.109]))*.27,.001*(q-[.65,.45,.40,.58,.38])]
seed=np.random.default_rng(78);best=None
for i in range(12):
 x=least_squares(err,seed.uniform(.03,hi-.03),bounds=(np.zeros(5),hi),max_nfev=150,ftol=1e-12,xtol=1e-12)
 c,dist=pair(x.x);score=abs(dist-.0284)*10+np.linalg.norm(err(x.x))
 if best is None or best[0]>score:best=(score,x.x.copy(),c.copy(),dist)
_,q,c,dist=best
res=dict(site=c.tolist(),radius=float(dist/2-.00006),closed=q.tolist(),open=(q*.72).tolist(),joints=keys,distal_gap_m=dist)
(D/'assets/gr1-pinch.json').write_text(json.dumps(res,indent=2));print(res)
