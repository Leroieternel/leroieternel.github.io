"""Acquire original NVIDIA Isaac People assets for local rendering, including native motion."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
from urllib.request import Request,urlopen
from xml.etree import ElementTree as ET
import hashlib,json
D=Path(__file__).resolve().parent
base='https://omniverse-content-production.s3-us-west-2.amazonaws.com/'
prefix='Assets/Isaac/6.0/Isaac/People/'
dest=D/'assets/people'
def fetch(u):
    with urlopen(Request(u,headers={'User-Agent':'DESPITE-motion-authoring'}),timeout=55) as r:return r.read()
keys=['Animations/'+n+'.skelanim.usd' for n in ['stand_walk_loop','stand_walk_loop_in_place','stand_idle_loop','stand_idle_wave_loop','stand_idle_wave_loop_mirror','push_button','type_keyboard','LookAround']]
for char in ['F_Medical_01','male_adult_construction_03','M_Medical_01']:
    raw=ET.fromstring(fetch(base+'?list-type=2&prefix='+quote(prefix+'Characters/'+char+'/')))
    keys.extend(k.text[len(prefix):] for k in raw.findall('.//{*}Key') if '/.thumbs/' not in k.text and (k.text.endswith('.usd') or (k.text.endswith(('.png','.jpg')) and '/textures/' in k.text)))
def download(key):
    p=dest/key;p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists():p.write_bytes(fetch(base+quote(prefix+key)))
    return (key,hashlib.sha256(p.read_bytes()).hexdigest())
with ThreadPoolExecutor(max_workers=6) as pool: receipts=dict(pool.map(download,keys))
(dest/'assets.json').write_text(json.dumps({'origin':base+prefix,'sha256':receipts},indent=2));print(list(receipts),flush=True)
