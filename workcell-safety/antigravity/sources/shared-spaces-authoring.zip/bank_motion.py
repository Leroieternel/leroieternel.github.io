"""Plan a native G1 fingertip pinch against the actual exchange fixtures."""
import json
import numpy as np
from scipy.optimize import least_squares
def plan(m,d,safe):
 from motion import T,progress,blend,chain,mj,D
 cfg=json.loads((D/'assets/g1-pinch.json').read_text());ids,site=chain(m,'g1');qi=m.jnt_qposadr[ids];lo,hi=m.jnt_range[ids].T
 # The two stands are on the working side of G1. Their decks are lower than the exchange pads.
 src=np.array([.285,-.38,.935]);dst=np.array([.365,-.125,.966]);home=src+np.array([-.012,-.009,.153])
 normal=np.array(cfg['jaw_normal']);random=np.random.default_rng(246)
 def fingers(f):
  arr=np.array(cfg['closed'])+(1-f)*.48*(np.array(cfg['open'])-np.array(cfg['closed']))
  for j,a in zip(cfg['parts'],arr):d.joint('right_hand_'+j+'_joint').qpos[0]=a
  for k in ('middle_0','middle_1'):d.joint('right_hand_'+k+'_joint').qpos[0]=.62
 fingers(1);mj.mj_kinematics(m,d)
 # Low and outer vertices of each optical link provide a guard around the tables during fit.
 samples=[]
 for g in range(m.ngeom):
  body=m.body(m.geom_bodyid[g]).name
  if not body.startswith(('right_wrist','right_hand','right_elbow')) or m.geom_group[g]!=2:continue
  me=m.geom_dataid[g];a=m.mesh_vertadr[me];pts=m.mesh_vert[a:a+m.mesh_vertnum[me]]
  directions=random.normal(size=(35,3));sel=np.unique(np.argmax(pts@directions.T,axis=0))
  samples.append((g,pts[sel]))
 def cloud():
  return np.concatenate([vs@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g] for g,vs in samples])
 fixtures=[(src[:2],np.array([.048,.025]),.897),(dst[:2],np.array([.098,.083]),.88),
           (src[:2],np.array([.13,.13]),.755),(dst[:2],np.array([.151,.151]),.80)]
 def deficit():
  pts=cloud();return [max(0.,np.minimum(np.min(half-abs(pts[:,:2]-xy),axis=1),z+.010-pts[:,2]).max()) for xy,half,z in fixtures]
 homeq=d.qpos[qi].copy()
 def fit(p,n,seed):
  def err(q):
   d.qpos[qi]=q;mj.mj_kinematics(m,d);s=d.site(site);norm=s.xmat.reshape(3,3)@normal
   return np.r_[s.xpos-p,.16*(norm-n),np.array(deficit())*4,.00022*(q-seed)]
  starts=[seed,homeq]+[random.uniform(lo+.01,hi-.01) for _ in range(14)]
  best=None
  for st in starts:
   sol=least_squares(err,np.clip(st,lo+.0002,hi-.0002),bounds=(lo+.0001,hi-.0001),max_nfev=160,ftol=1e-9,xtol=1e-9,gtol=1e-9)
   rr=err(sol.x);score=np.linalg.norm(rr[:10])+np.linalg.norm(sol.x-seed)*.0002
   if best is None or score<best[0]:best=(score,sol.x.copy())
   if np.linalg.norm(rr[:10])<.00036 and np.linalg.norm(sol.x-seed)<2.8:break
  return best[1]
 startnorm=np.array([0.,-1.,0.]);endnorm=np.array([0.,0.,-1. if safe else 1.])
 face=lambda v:v/np.linalg.norm(v)
 angle=np.deg2rad(238 if safe else 120)
 away=np.array([np.cos(angle),np.sin(angle),0.0]);withdraw=dst+away*(.157 if safe else .084)
 nodes=[(0,home,startnorm),(1.25,src+[0,0,.085],startnorm),(1.80,src+[0,0,.043],startnorm),(2.30,src,startnorm),(2.74,src,startnorm),
        (3.90,src+[0,0,.14],startnorm),(5.12,(src+dst)/2+[0,0,.17],face(startnorm+endnorm)),
        (6.55,dst+[0,0,.09],endnorm),(7.62,dst,endnorm),(7.91,dst,endnorm),(8.40,dst+away*.064,endnorm),
        (8.98,withdraw,endnorm),(9.82,withdraw+[0,0,.10],endnorm),(10.95,withdraw+[0,0,.14],endnorm),(11.75,withdraw+[0,0,.14],endnorm)]
 # Solve backward from pickup to the elevated ready pose, preserving the same elbow branch.
 seed=fit(src,startnorm,homeq)
 prev=fit(home,startnorm,seed);qs=[]
 for i,(t,p,n) in enumerate(nodes):
  if i and np.all(p==nodes[i-1][1]) and np.all(n==nodes[i-1][2]):q=prev
  else:q=fit(p,n,prev)
  qs.append((t,q));prev=q
 result=[];tips=[];peak=0.
 for t in T:
  d.qpos[qi]=blend(qs,t);fingers(progress(t,2.27,2.67)*(1-.12*progress(t,7.74,7.88)-.88*progress(t,8.88,9.30)))
  mj.mj_kinematics(m,d);tips.append(d.site(site).xpos.copy());result.append(d.qpos.copy())
 for (t,p,n),(_,q) in zip(nodes,qs):
  d.qpos[qi]=q;mj.mj_kinematics(m,d);peak=max(peak,np.linalg.norm(d.site(site).xpos-p))
 return np.array(result),dict(dispatch_s=2.68,release_s=7.88,steps=[0.,2.68,5.12,7.88],site=site,max_command_position_error_m=peak,acquire_error_m=float(np.linalg.norm(tips[67]-src)),release_error_m=float(np.linalg.norm(tips[197]-dst)),fingertip_calibration=cfg),np.array(tips)
