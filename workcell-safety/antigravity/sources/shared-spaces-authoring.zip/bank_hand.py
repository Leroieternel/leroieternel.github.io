"""Calibrate the G1 pinch point from the two native distal fingertip meshes."""
from pathlib import Path
import json,sys
import numpy as np
import mujoco as mj
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
from world import D,build,init
m=build('bank');d=mj.MjData(m);init(m,d,'g1')
parts=['thumb_0','thumb_1','thumb_2','index_0','index_1'];joint=[m.joint('right_hand_'+p+'_joint') for p in parts]
ids=np.array([x.qposadr[0] for x in joint]);lo,hi=np.array([j.range for j in joint]).T
def pose(q):
 d.qpos[ids]=q;mj.mj_kinematics(m,d)
 u=d.body('right_wrist_yaw_link');rot=u.xmat.reshape(3,3);xyz=u.xpos
 def wp(body,off):
  b=d.body('right_hand_'+body+'_link');return (b.xpos+b.xmat.reshape(3,3)@off-xyz)@rot
 return wp('thumb_2',np.array([0,.049,0])),wp('index_1',np.array([.049,0,0]))
def residual(q):
 thumb,index=pose(q);return np.r_[thumb-index-[0,.012,-.004],.0008*(q-[.08,.05,-.67,.62,.70])]
q=least_squares(residual,[.15,-.3,-1,.6,.65],bounds=(lo+.001,hi-.001),gtol=1e-13,xtol=1e-13,ftol=1e-13).x
def points(part):
 body=d.body('right_hand_'+part+'_link');g=next(i for i in range(m.ngeom) if m.geom_bodyid[i]==body.id and m.geom_group[i]==2);j=m.geom_dataid[g];a=m.mesh_vertadr[j];v=m.mesh_vert[a:a+m.mesh_vertnum[j]]
 u=d.body('right_wrist_yaw_link');return (v@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]-u.xpos)@u.xmat.reshape(3,3)
def pair(q):
 pose(q);a,b=points('thumb_2'),points('index_1');dist,j=cKDTree(a).query(b);i=np.argmin(dist);return a[j[i]],b[i],dist[i]
# Obtain a 4.4 mm pad clearance around the 4 mm printed card.
from scipy.optimize import minimize_scalar
best=None
for k in np.linspace(0,.50,121):
 q0=q.copy();q0[2]+=k;q0[3]-=k*.45;p,i,dist=pair(q0)
 if best is None or abs(dist-.0044)<best[0]:best=(abs(dist-.0044),q0.copy(),p,i,dist)
_,q,p,i,dist=best;normal=(i-p)/dist
res=dict(pinch=((p+i)*.5).tolist(),jaw_normal=normal.tolist(),closed=q.tolist(),open=(np.clip(q+[0,0,.32,-.50,-.32],lo+.001,hi-.001)).tolist(),parts=parts,distal_gap_m=dist)
(D/'assets/g1-pinch.json').write_text(json.dumps(res,indent=2));print(res)
