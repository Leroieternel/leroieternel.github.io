"""Preserve the original USD skin weights and sample all joints of each licensed motion clip."""
from pathlib import Path
import json, numpy as np
from pxr import Usd,UsdGeom,UsdSkel
D=Path(__file__).resolve().parent;P=D/'assets/people'
files={'business':D.parents[2]/'.runtime/staff-assets/F_Business_02/F_Business_02.usd', 'nurse':P/'Characters/F_Medical_01/F_Medical_01.usd','doctor':P/'Characters/M_Medical_01/M_Medical_01.usd','worker':P/'Characters/male_adult_construction_03/male_adult_construction_03.usd'}
for name,path in files.items():
 d=P/name;d.mkdir(exist_ok=True)
 stage=Usd.Stage.Open(str(path));sk=next(UsdSkel.Skeleton(p) for p in stage.Traverse() if p.IsA(UsdSkel.Skeleton))
 chain=list(map(str,sk.GetJointsAttr().Get()));names=[s.split('/')[-1] for s in chain]
 pos=np.asarray(sk.GetBindTransformsAttr().Get())[:,3,:3]
 np.savez(d/'skeleton.npz',names=names,bind=pos,parent=UsdSkel.Topology(chain).GetParentIndices())
 mats={}
 for m in stage.Traverse():
  if not m.IsA(UsdGeom.Mesh):continue
  mesh=UsdGeom.Mesh(m);xyz=np.array(mesh.GetPointsAttr().Get());faces=np.array(mesh.GetFaceVertexIndicesAttr().Get());assert np.all(np.array(mesh.GetFaceVertexCountsAttr().Get())==3)
  uv=UsdGeom.PrimvarsAPI(m).GetPrimvar('st0');uvd=np.array(uv.Get());uvi=np.array(uv.GetIndices()) if uv.IsIndexed() else (faces if len(uvd)==len(xyz) else np.arange(len(faces)))
  b=UsdSkel.BindingAPI(m);ids=np.asarray(b.GetJointIndicesPrimvar().Get()).reshape(len(xyz),-1);w=np.asarray(b.GetJointWeightsPrimvar().Get()).reshape(ids.shape);w=w/np.maximum(w.sum(1,keepdims=True),1e-9)
  subset=b.GetJointsAttr().Get()
  if subset:ids=np.array([chain.index(str(s)) for s in subset])[ids]
  # Retain individual meshes, UV seams and skinning for face, clothing, fingers and footwear.
  np.savez_compressed(d/(m.GetName()+'.npz'),vertices=xyz,faces=faces.reshape(-1,3),uv=uvd[uvi],ids=ids.astype('i2'),weights=w)
 (d/'textures.json').write_text(json.dumps({p.stem.split('_')[-1]:str(p) for p in (path.parent/'textures').glob('*')},indent=2))
for path in (P/'Animations').glob('*.usd'):
 s=Usd.Stage.Open(str(path));a=next(UsdSkel.Animation(p) for p in s.Traverse() if p.IsA(UsdSkel.Animation))
 times=sorted(set(a.GetRotationsAttr().GetTimeSamples())|set(a.GetTranslationsAttr().GetTimeSamples()))
 if len(times)<2:continue
 topo=UsdSkel.Topology(a.GetJointsAttr().Get());mat=np.array([np.array(UsdSkel.ConcatJointTransforms(topo,a.GetTransforms(t))) for t in times])
 np.savez_compressed(path.with_suffix('.npz'),names=[str(x).split('/')[-1] for x in a.GetJointsAttr().Get()],pos=mat[:,:,3,:3][:,:,:][:,:,[0,2,1]]*[1,-1,1],rot=mat[:,:,:3,:3].astype('f'),times=(np.array(times)-times[0])/s.GetTimeCodesPerSecond())
print('Converted four skinned characters and',len(list((P/'Animations').glob('*.npz'))),'native motion clips')
