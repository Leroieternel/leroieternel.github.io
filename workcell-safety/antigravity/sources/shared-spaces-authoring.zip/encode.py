from evidence import *
import argparse,subprocess,os,shutil
from concurrent.futures import ThreadPoolExecutor
from PIL import Image
import imageio_ffmpeg as ff
def time(t):
 n=round(t*100);return f'{n//360000}:{(n//6000)%60:02}:{n//100%60:02}.{n%100:02}'
def encode(s,b):
 p=D/'runs'/s;o=D/'media'/s;frames=sorted((o/b).glob('frame-*.jpg'));assert len(frames)==300,(s,b,len(frames))
 r=read(p/(b+'.json'));cy=plan(s,b,r);raw=np.load(p/(b+'-metrics.npz'))
 title=TITLE[s];sub=o/(b+'.ass');dst=o/(b+'.mp4')
 hdr='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
[Fonts]
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Title,DejaVu Sans,32,&H00FFFFFF,&H00FFFFFF,&H34221A12,&H30221A12,-1,0,0,0,100,100,0,0,3,8,0,7,33,33,30,1
Style: Action,DejaVu Sans,35,&H00FFFFFF,&H00FFFFFF,&H3625160F,&H3025160F,-1,0,0,0,100,100,0,0,3,9,0,1,36,40,40,1
Style: Measure,DejaVu Sans,29,&H00FFFFFF,&H00FFFFFF,&H3625160F,&H3025160F,0,0,0,0,100,100,0,0,3,7,0,9,36,36,30,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 def line(style,start,end,txt):return f'Dialogue: 0,{time(start)},{time(end)},{style},,0,0,0,,{txt}\n'
 hdr+=line('Title',0,12,('SAFE PLAN' if b=='safe' else 'UNSAFE PLAN')+'    /    '+title)
 for n,c in enumerate(cy):hdr+=line('Action',c['t'],(cy[n+1]['t'] if n+1<len(cy) else 12),c['text'])
 for i in range(300):
  t=i/25;k=i*40;met=raw['metric'][k];force=raw['force'][max(0,k-39):k+1].max()
  if s in ('market','museum','warehouse'):measure=f"{met:.1f}°   |   {force:.1f} N"
  if s=='museum':
   ground=raw['ground'][max(0,k-39):k+1].max()
   measure=f"{met:.1f}°   |   "+(f"Floor {ground:.1f} N" if ground>.005 else f"Catch {force:.1f} N")
  elif s=='bank':measure=('Stripe up' if met>.80 else 'Stripe down' if met<-.80 else 'Turning')+f'   |   {force:.1f} N'
  elif s not in ('market','warehouse'):measure=('Violation' if met>.5 else 'No violation')+f"   |   person gap {raw['gap'][k]:.2f} m"
  hdr+=line('Measure',t,t+.04,f'{t:.2f} s   ·   {measure}')
 sub.write_text(hdr);tmp=o/(b+'.partial.mp4')
 cmd=[ff.get_ffmpeg_exe(),'-nostdin','-y','-hide_banner','-loglevel','error','-framerate','25','-start_number','1','-i',str((o/b)/'frame-%04d.jpg'),'-vf','ass='+sub.name,'-an','-c:v','libx264','-crf','19','-preset','veryfast','-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',str(tmp)]
 subprocess.run(cmd,cwd=o,check=True)
 n,seconds=ff.count_frames_and_secs(str(tmp));reader=ff.read_frames(str(tmp));meta=next(reader);next(reader);reader.close();assert (n,seconds,meta['size'],meta['fps'])==(300,12.,(1920,1080),25.);tmp.replace(dst)
 verification=dict(width=1920,height=1080,duration_s=12,fps=25,decoded_frames=n,sha256=sha(dst))
 write(o/(b+'-video.json'),verification);print(s,b,dst.stat().st_size,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('slugs',nargs='+');args=ap.parse_args()
 with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda x:encode(*x),[(s,b) for s in args.slugs for b in ('safe','unsafe')]))
