"""Plan actuator coordinates in library joint limits, gate dispatch on the shared human performance."""
import numpy as np,math
from scipy.spatial.transform import Rotation
from world import *
from generated.policy import dispatch,progress
T=np.arange(301)/25
def travel(t,a,b):
 # Smooth acceleration to a constant cruise, and symmetric deceleration. Integral of cubic smoothstep.
 u=np.clip((t-a)/max(.01,b-a),0,1);k=.20
 def cap(v):return k*(v**3-.5*v**4)
 if u<k:s=cap(u/k)
 elif u>1-k:s=1-k-cap((1-u)/k)
 else:s=u-k/2
 return s/(1-k)
def yawq(R):return np.roll(Rotation.from_matrix(R).as_quat(),1)
def blend(points,t,easing=progress):
 for (a,x),(b,y) in zip(points,points[1:]):
  if t<=b:return np.asarray(x)+(np.asarray(y)-x)*easing(t,a,b)
 return np.asarray(points[-1][1])
def chain(m,k,side='right'):
 if k in ('panda','omron','gr1'):return lib.arm(m,k,side)
 if k=='tiago':return [m.joint(f'arm_{side}_{i}_joint').id for i in range(1,7)],side+'_grip_site'
 if k=='g1':
  return [m.joint(side+'_'+j+'_joint').id for j in ('shoulder_pitch','shoulder_roll','shoulder_yaw','elbow','wrist_roll','wrist_pitch','wrist_yaw')],'work_tcp'
def ik(m,d,ids,site,p,rot=None,normal=None):
 ids=np.asarray(ids);qi=m.jnt_qposadr[ids];vi=m.jnt_dofadr[ids];n=m.site(site).id;J=np.zeros((3,m.nv));W=J.copy()
 lo,hi=m.jnt_range[ids].T; ref=d.qpos[qi].copy()
 for it in range(70):
  mj.mj_kinematics(m,d);mj.mj_comPos(m,d);err=p-d.site_xpos[n];mj.mj_jacSite(m,d,J,W,n);A=J[:,vi]
  if rot is not None:
   dr=Rotation.from_matrix(rot@d.site_xmat[n].reshape(3,3).T).as_rotvec()
   err=np.r_[err,.17*dr];A=np.vstack([A,.17*W[:,vi]])
  if normal is not None:
   local,goal=normal;axis=d.site_xmat[n].reshape(3,3)@local
   err=np.r_[err,.19*(goal-axis)];A=np.vstack([A,.19*np.cross(W[:,vi].T,axis).T])
  if np.linalg.norm(err)<.00045:break
  h=np.linalg.solve(A@A.T+.00024*np.eye(len(err)),err)
  dq=A.T@h
  d.qpos[qi]=np.clip(d.qpos[qi]+np.clip(dq,-.12,.12),lo+.0001,hi-.0001)
 mj.mj_kinematics(m,d)
 return float(np.linalg.norm(p-d.site_xpos[n]))
def qhome(m,key):
 d=mj.MjData(m);init(m,d,key);return d
def observations(slug,t,joints,names,cover):
 hip=joints[names.index('Hip')]
 return {'clear':hip[1]>(1.43 if slug=='crossing' else 1.52),'boarded':hip[0]>2.14,'break':t>=7.14,'permission':t>=6.52,'sealed':cover<.055}
def parked(safe,slug,t,when):
 if slug=='hotel':
  nodes=[(0,[-2.98,-.83]),(2.85,[-1.22,-.65]),(when,[-1.22,-.65]),(when+2.20,[-.13,-.56]),(when+3.85,[-.13,-.56]),(12,[-.59,-.60])]
 elif slug=='warehouse':
  yy=-2.10 if safe else -.16
  nodes=[(0,[-3.48,-.38]),(1.3,[-2.85,-.38]),(4.55,[-1.58,yy]),(8.40,[1.65,yy]),(11.94,[3.05,-.65])]
 else:
  ly={'crossing':-.25,'bus':-.34,'hospital':-.58,'meeting':-.30,'library':-.36}[slug]
  start=-3.12;st=-1.65 if slug=='hospital' else -1.43;end=1.92 if slug=='bus' else 2.36
  stage=2.56
  nodes=[(0,[start,ly-.12]),(stage,[st,ly]),(when,[st,ly]),(min(11.9,when+5.05),[end,ly+.08])]
 return blend(nodes,t,travel)
def contact_poses(slug):
 return {'market':(.77,[.43,-.14],[.47,.25],.139,.0865),
         'museum':(1.04,[.20,-.51],[.24,-.18],.103,.0715),
         'bank':(.88,[.285,-.38],[.365,-.125],.148,.002)}[slug]
def program(slug,safe,m):
 k=TASK[slug]['robot'];d=qhome(m,k);original=d.qpos.copy();human=np.load(D/'runs'/slug/'human.npz');hj=human['joints'];names=human['names'].tolist()
 if slug=='bank':
  from bank_motion import plan
  return plan(m,d,safe)
 mobile=slug not in TWO
 contact_j={};peakerr=0;allqs=[];targets=[];when=None
 if mobile:
  observe=[]
  for i,t in enumerate(T):
   cover=1.55*(1-progress(t,2.85,4.45)) if safe else 1.55
   obs=observations(slug,t,hj[i],names,cover);observe.append(obs)
   if when is None and t>=(2.85 if slug=='hotel' else 2.56) and dispatch(slug,safe,t,obs):when=t
  assert when is not None
  xy=np.array([parked(safe,slug,t,when) for t in T])
  diff=np.diff(xy,axis=0);head=np.arctan2(diff[:,1],diff[:,0]);cur=head[0];heading=[]
  for i,v in enumerate(np.vstack([diff,diff[-1]])):
   angle=math.atan2(v[1],v[0]) if np.linalg.norm(v)>1e-6 else cur
   if slug=='hotel':angle=1.22*progress(T[i],when,when+2.12)
   # Holonomic carriers can approach laterally while aligning. Husky follows its tangent.
   step=math.atan2(math.sin(angle-cur),math.cos(angle-cur));cur+=np.clip(step,-.035,.035);heading.append(cur)
  if k=='tiago':
   rids,rs=chain(m,k);lids,ls=chain(m,k,'left')
   center=d.body('torso_lift_link').xpos.copy()
   # Keep the tray and forward sight line free; hands sit beside its handles in transport.
   homeR=center+[.35,-.25,.32];homeL=center+[.35,.25,.32]
   ik(m,d,rids,rs,homeR);ik(m,d,lids,ls,homeL);original=d.qpos.copy()
  wheel=[j for j in range(m.njnt) if 'wheel' in m.joint(j).name and m.jnt_type[j]==3];dist=0.
  for i,t in enumerate(T):
   d.qpos[:]=original
   if i:dist+=np.linalg.norm(xy[i]-xy[i-1])
   for j in wheel:d.qpos[m.jnt_qposadr[j]]=dist/(.165 if k=='husky' else .0985)
   for v,val in zip(('x','y','yaw'),[*xy[i],heading[i]]):d.joint('route_'+v).qpos[0]=val
   if slug=='library':d.joint('cover_angle').qpos[0]=np.clip(1.55*(1-progress(t,2.85,4.45)) if safe else 1.55,0,1.55)
   mj.mj_forward(m,d)
   if slug=='hotel':
    expand=progress(t,when+1.98,when+2.93)*(1-progress(t,when+3.48,when+4.25))
    basepoint=d.site(rs).xpos.copy();target=basepoint*(1-expand)+np.array([.12,.24,.852])*expand
    ik(m,d,rids,rs,target)
   allqs.append(d.qpos.copy())
  return np.asarray(allqs),dict(dispatch_s=when,steps=[0.,2.56,when,min(11.9,when+4.2)],staging_check='Original Antigravity policy evaluated on shared actor or task-state samples.'),None
 z,src,dst,h,base=contact_poses(slug);ids,site=chain(m,k);jids=np.array(ids);qids=m.jnt_qposadr[jids]
 if slug=='museum':
  site='replica_pinch'
  cal=json.loads((D/'assets/gr1-pinch.json').read_text())
  for n,q in zip(cal['joints'],cal['open']):d.joint(n).qpos[0]=q
  mj.mj_forward(m,d)
 hand0=d.site(site).xpos.copy();homeR=d.site(site).xmat.reshape(3,3).copy()
 if k=='panda':contactrot=homeR
 else:contactrot=None
 # A held prop starts supported by the pickup pad. Transfer is relative to the actual TCP after acquisition.
 grip=base+(.222 if slug=='museum' else .021) if slug!='bank' else .053
 hit=np.r_[src,z+grip];out=np.r_[dst,z+grip+.009]
 if not safe and slug in ('museum','market'):out[0]+=h+(.021 if slug=='market' else .029)
 if slug=='bank':out[2]=z+.027
 posnodes=[(0,hand0),(1.28,hit+[0,0,.105]),(2.30,hit),(2.74,hit),(3.8,hit+[0,0,.14]),(5.12,(hit+out)/2+[0,0,.17]),(6.48,out+[0,0,.115]),(7.62,out),(8.05,out),(9.18,out+[0,0,.136]),(11.42,hand0)]
 if slug=='museum':
  # Start and finish in an above-counter ready pose; never sweep a wrist through the occupied plinth.
  park=hit+[0,-.035,.16]
  ik(m,d,ids,site,park)
  posnodes[0]=(0,park);posnodes[-1]=(11.42,out+[0,-.060,.20])
 if slug=='museum':
  for t in T[:68]:ik(m,d,ids,site,blend(posnodes,t))
  q_acquired=d.qpos.copy();R_acquired=d.site(site).xmat.reshape(3,3).copy()
  pre={}
  for i in reversed(range(68)):
   ik(m,d,ids,site,blend(posnodes,T[i]),rot=R_acquired);pre[i]=d.qpos[qids].copy()
  d.qpos[:]=q_acquired
 for i,t in enumerate(T):
  goal=blend(posnodes,t);normal=None
  if slug=='museum' and i<68:
   d.qpos[qids]=pre[i];contactrot=R_acquired
  elif slug=='museum' and t<=8.05:
   contactrot=None;normal=(R_acquired.T@np.array([0.,0.,1.]),np.array([0.,0.,1.]))
  elif slug=='museum':contactrot=None
  err=ik(m,d,ids,site,goal,contactrot,normal);peakerr=max(peakerr,err)
  close=progress(t,2.27,2.67)*(1-progress(t,7.87,8.22))
  if k=='panda':
   width=.03995-.00270*close
   d.joint('finger_joint1').qpos[0]=width;d.joint('finger_joint2').qpos[0]=-width
  elif k=='gr1':
   for n,val in zip(cal['joints'],(1-close)*np.array(cal['open'])+close*np.array(cal['closed'])):d.joint(n).qpos[0]=val
  elif k=='g1':
   for part in ('index','middle'):
    for j in (0,1):
     jj=m.joint('right_hand_'+part+'_'+str(j)+'_joint');lo,hi=jj.range;d.qpos[jj.qposadr[0]]=(lo+(.16+.42*close)*(hi-lo)) if lo>=0 else hi-(.16+.42*close)*(hi-lo)
  mj.mj_kinematics(m,d);allqs.append(d.qpos.copy());targets.append(d.site(site).xpos.copy())
 return np.array(allqs),dict(dispatch_s=2.68,release_s=7.88,steps=[0.,2.68,5.12,7.88],max_command_position_error_m=peakerr,acquire_error_m=float(np.linalg.norm(np.array(targets)[67]-hit)),release_error_m=float(np.linalg.norm(np.array(targets)[197]-out)),grip_height=grip,site=site),np.array(targets)
