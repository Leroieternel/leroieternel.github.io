"""Check hand-to-payload distances on each recorded optical pose using MuJoCo's convex surfaces."""
from world import *
def check(slug):
 p=D/'runs'/slug;m=mj.MjModel.from_xml_path(str(p/'scene.xml'));d=mj.MjData(m)
 targets=[i for i in range(m.ngeom) if m.geom_bodyid[i]==m.body('payload').id and m.geom_contype[i]]
 def ishand(i):
  name=m.body(m.geom_bodyid[i]).name.lower()
  return m.geom_group[i]<3 and m.geom_rgba[i,3]>0 and any(k in name for k in ('finger','r_palm','r_hand','r_thumb','r_index','r_middle','r_ring','r_pinky','right_hand','right_wrist'))
 ids=[i for i in range(m.ngeom) if ishand(i)];out={}
 for b in ('safe','unsafe'):
  qs=np.load(p/(b+'.npz'))['qpos'];worst={};grip=[]
  for frame,q in enumerate(qs):
   d.qpos[:]=q;mj.mj_forward(m,d);dist=[]
   for g in ids:
    for other in targets:
     if np.linalg.norm(d.geom_xpos[g]-d.geom_xpos[other])-m.geom_rbound[g]-m.geom_rbound[other]>.010:continue
     val=mj.mj_geomDistance(m,d,g,other,.012,None);key=(m.body(m.geom_bodyid[g]).name,m.geom(other).name)
     if val<0 and (key not in worst or val<worst[key][0]):worst[key]=(val,frame)
     dist.append(val)
   if 67<=frame<197:grip.append(min(dist) if dist else .012)
  items=sorted(worst.items(),key=lambda x:x[1][0]);out[b]=dict(max_overlap_mm=round(-1000*items[0][1][0],3) if items else 0,held_gap_at_worst_mm=round(1000*max(grip),3),pairs=[dict(hand=k[0],part=k[1],depth_mm=round(-1000*v[0],3),time_s=v[1]/25) for k,v in items[:12]])
  print(slug,b,out[b]['max_overlap_mm'],out[b]['held_gap_at_worst_mm'],out[b]['pairs'][:3],flush=True)
 (p/'grip-check.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':
 for s in sys.argv[1:] or ['bank','market','museum']:check(s)
