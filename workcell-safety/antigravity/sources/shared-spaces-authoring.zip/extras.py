from pathlib import Path
import sys,json
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parents[1]/'mobile_worlds/library'))
import prepare_genie as a
# Extend the native geometry cache, without touching the established model list.
spec={k:a.encode(k,model) for k,model in [('plant','benchmark_plant_001'),('shelf','benchmark_shelf_000')]}
(D/'assets/extra-genie.json').write_text(json.dumps(spec,indent=2))
