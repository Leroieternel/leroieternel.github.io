import math


def _wheel(b, tag, cx, cy, r, w):
    b.cyl(f"{tag}_t", (cx, cy, r), r, w, "rubber", "Y")
    b.cyl(f"{tag}_r", (cx, cy, r), r * 0.62, w + 0.016, "chrome", "Y")
    b.cyl(f"{tag}_h", (cx, cy, r), r * 0.25, w + 0.032, "steel", "Y")


def _lamp(b, tag, x, y, fz, dx):
    b.cyl(f"{tag}_b", (x, y, fz + 0.22), 0.10, 0.44, "steel", "Z")
    b.beam(f"{tag}_p", (x, y, fz + 0.40), (x, y, fz + 3.85), 0.048, "steel")
    b.beam(f"{tag}_a", (x, y, fz + 3.80), (x + dx, y, fz + 3.92), 0.035, "steel")
    b.box(f"{tag}_h", (x + dx, y, fz + 3.92), (0.44, 0.22, 0.09), "black")
    b.box(f"{tag}_l", (x + dx, y, fz + 3.86), (0.34, 0.14, 0.04), "light", 0, 0.005)


def _bay(b, tag, cx, yf, fz, w, frame, awning=None, sign=None):
    b.box(f"{tag}_pl", (cx, yf + 0.14, fz + 0.28), (w, 0.30, 0.56), "stone")
    b.box(f"{tag}_bk", (cx, yf + 0.68, fz + 1.65), (w - 0.16, 0.12, 2.25), "ivory")
    b.box(f"{tag}_sh", (cx, yf + 0.46, fz + 0.92), (w - 0.60, 0.34, 0.06), "oak")
    b.box(f"{tag}_gl", (cx, yf + 0.18, fz + 1.56), (w - 0.34, 0.04, 1.88), "glass", 0, 0.004)
    b.box(f"{tag}_hd", (cx, yf + 0.08, fz + 2.66), (w, 0.24, 0.46), frame)
    b.box(f"{tag}_tr", (cx, yf + 0.12, fz + 2.18), (w - 0.22, 0.09, 0.07), frame)
    for i, dx in enumerate((-0.47, -0.16, 0.16, 0.47)):
        b.box(f"{tag}_m{i}", (cx + dx * w, yf + 0.13, fz + 1.52), (0.09, 0.12, 1.96), frame)
    b.box(f"{tag}_up", (cx, yf + 0.22, fz + 3.74), (w + 0.04, 0.44, 1.72), "brick")
    b.box(f"{tag}_c1", (cx, yf + 0.04, fz + 2.91), (w + 0.16, 0.22, 0.10), "stone")
    b.box(f"{tag}_c2", (cx, yf + 0.04, fz + 4.62), (w + 0.20, 0.28, 0.14), "stone")
    for j, ox in enumerate((-0.26 * w, 0.26 * w)):
        b.box(f"{tag}_uw{j}", (cx + ox, yf + 0.03, fz + 3.76), (0.96, 0.05, 1.06), "glass", 0, 0.004)
        b.box(f"{tag}_us{j}", (cx + ox, yf - 0.01, fz + 3.19), (1.08, 0.14, 0.08), "stone")
        b.box(f"{tag}_ul{j}", (cx + ox, yf - 0.01, fz + 4.33), (1.08, 0.12, 0.09), "stone")
        b.box(f"{tag}_um{j}", (cx + ox, yf + 0.01, fz + 3.76), (0.05, 0.07, 1.04), "ivory")
    if awning:
        for k in range(3):
            b.box(f"{tag}_aw{k}", (cx, yf - 0.22 - k * 0.28, fz + 2.40 - k * 0.08), (w - 0.30, 0.32, 0.04), awning, 0, 0.006)
        for s in (-1, 1):
            b.beam(f"{tag}_ar{s}", (cx + s * (w * 0.44), yf, fz + 2.04), (cx + s * (w * 0.44), yf - 0.86, fz + 2.24), 0.022, "steel")
    if sign:
        b.sign(sign, (cx, yf - 0.06, fz + 2.66), min(w - 0.9, 2.3), 0.38)


def _crate(b, tag, cx, cy, fz, yaw, goods_mat, bottles=False):
    c, s = math.cos(yaw), math.sin(yaw)
    b.box(f"{tag}_bt", (cx, cy, fz + 0.015), (0.56, 0.42, 0.03), "oak", yaw, 0.004)
    for i, (lx, ly, sx, sy) in enumerate(((0, -0.195, 0.56, 0.03), (0, 0.195, 0.56, 0.03), (-0.265, 0, 0.03, 0.36), (0.265, 0, 0.03, 0.36))):
        b.box(f"{tag}_w{i}", (cx + lx * c - ly * s, cy + lx * s + ly * c, fz + 0.145), (sx, sy, 0.23), "oak", yaw, 0.004)
    for ix, ox in enumerate((-0.15, 0.0, 0.15)):
        for iy, oy in enumerate((-0.09, 0.09)):
            gx, gy = cx + ox * c - oy * s, cy + ox * s + oy * c
            if bottles:
                b.cyl(f"{tag}_b{ix}{iy}", (gx, gy, fz + 0.14), 0.036, 0.22, goods_mat, "Z")
                b.cyl(f"{tag}_c{ix}{iy}", (gx, gy, fz + 0.265), 0.017, 0.03, "white", "Z")
            else:
                b.cyl(f"{tag}_g{ix}{iy}", (gx, gy, fz + 0.10), 0.058, 0.13, goods_mat, "Z")


def _stall(b, tag, cx, cy, w, d, stripe, sign, bottles=False):
    x0, x1, y0, y1 = cx - w * 0.5, cx + w * 0.5, cy - d * 0.5, cy + d * 0.5
    for i, (px, py, ph) in enumerate(((x0, y0, 2.52), (x1, y0, 2.52), (x0, y1, 2.34), (x1, y1, 2.34))):
        b.beam(f"{tag}_p{i}", (px, py, 0.0), (px, py, ph), 0.036, "steel")
    b.beam(f"{tag}_ef", (x0, y0, 2.50), (x1, y0, 2.50), 0.03, "steel")
    b.beam(f"{tag}_er", (x0, y1, 2.32), (x1, y1, 2.32), 0.03, "steel")
    for i, rx in enumerate((x0, cx, x1)):
        b.beam(f"{tag}_rf{i}", (rx, y0, 2.52), (rx, y1, 2.34), 0.028, "steel")
    for i in range(5):
        sy = y0 + (i + 0.5) * (d / 5.0)
        sz = 2.54 - i * 0.045
        for j in range(4):
            sx = x0 + (j + 0.5) * (w / 4.0)
            b.box(f"{tag}_cv{i}{j}", (sx, sy, sz), (w / 4.0 + 0.01, d / 5.0 + 0.04, 0.035), stripe if j % 2 == 0 else "ivory", 0, 0.004)
    for j in range(6):
        b.box(f"{tag}_vl{j}", (x0 + (j + 0.5) * (w / 6.0), y0 - 0.02, 2.38), (w / 6.0 - 0.02, 0.025, 0.24), stripe if j % 2 == 0 else "ivory", 0, 0.004)
    b.box(f"{tag}_tb", (cx, y0 + 0.72, 0.78), (w - 0.28, 0.78, 0.06), "oak")
    b.box(f"{tag}_ap", (cx, y0 + 0.38, 0.39), (w - 0.34, 0.05, 0.76), "walnut")
    for s in (-1, 1):
        b.box(f"{tag}_lg{s}", (cx + s * (w * 0.42), y0 + 0.72, 0.38), (0.07, 0.72, 0.76), "walnut")
    _crate(b, f"{tag}_c1", cx - 0.48, y0 + 0.70, 0.81, 0.08, "terracotta" if not bottles else "sage", bottles)
    _crate(b, f"{tag}_c2", cx + 0.48, y0 + 0.70, 0.81, -0.06, "leaf" if not bottles else "teal", bottles)
    b.sign(sign, (cx, y0 - 0.05, 2.70), min(w - 0.2, 2.1), 0.34)


def _crossing(b):
    for i in range(8):
        b.box(f"zb_{i}", (0.0, -2.28 + i * (4.56 / 7.0), 0.002), (1.80, 0.34, 0.004), "white", 0, 0.0)
    for i, sx in enumerate((-2.15, 2.15)):
        b.box(f"st_{i}", (sx, 0.0, 0.002), (0.18, 4.90, 0.004), "white", 0, 0.0)
    for i, dx in enumerate((-6.2, -4.0, 4.0, 6.2)):
        b.box(f"ln_{i}", (dx, 0.0, 0.002), (1.15, 0.12, 0.004), "white", 0, 0.0)
    b.box("sw_l", (-4.85, 4.75, 0.05), (6.70, 3.10, 0.10), "concrete", 0, 0.008)
    b.box("kb_l", (-4.85, 3.22, 0.055), (6.70, 0.20, 0.11), "stone", 0, 0.01)
    b.box("sw_rb", (4.85, 5.98, 0.05), (6.70, 0.64, 0.10), "concrete", 0, 0.008)
    b.box("kb_rb", (4.10, 5.68, 0.055), (5.20, 0.18, 0.11), "stone", 0, 0.01)
    b.box("sw_re", (7.40, 4.43, 0.05), (1.60, 2.46, 0.10), "concrete", 0, 0.008)
    b.box("kb_re", (7.40, 3.22, 0.055), (1.60, 0.20, 0.11), "stone", 0, 0.01)
    b.box("kb_rs", (6.62, 4.43, 0.055), (0.18, 2.50, 0.11), "stone", 0, 0.01)
    b.box("rp_fl", (0.0, 3.85, 0.002), (3.00, 1.30, 0.004), "concrete", 0, 0.0)
    b.box("rp_tc", (0.0, 3.35, 0.004), (2.40, 0.42, 0.008), "terracotta", 0, 0.0)
    for i, (ry, rh) in enumerate(((4.70, 0.03), (5.10, 0.06), (5.50, 0.09), (6.00, 0.10))):
        b.box(f"rp_s{i}", (0.0, ry, rh * 0.5), (3.00, 0.48, rh), "concrete", 0, 0.004)
    for s in (-1, 1):
        b.box(f"rp_ck{s}", (s * 1.46, 3.58, 0.025), (0.14, 0.80, 0.05), "stone", 0, 0.008)
    for x in (-7.8, -2.6, 2.6, 7.8):
        b.box(f"pr_{x:.1f}", (x, 6.48, 2.40), (0.64, 0.42, 4.60), "brick")
    _bay(b, "sh1", -5.2, 6.30, 0.10, 4.6, "sage", "terracotta", "CORNER BAKERY")
    _bay(b, "sh2", 0.0, 6.30, 0.10, 4.6, "navy", "ivory", "CITY BOOKS")
    _bay(b, "sh3", 5.2, 6.30, 0.10, 4.6, "walnut", "sage", "OAK GROCER")
    b.beam("bc_p", (-1.70, 3.38, 0.10), (-1.70, 3.38, 2.85), 0.042, "steel")
    b.cyl("bc_g", (-1.70, 3.38, 2.98), 0.14, 0.24, "yellow", "Z")
    b.sign("CROSSING", (-1.70, 3.30, 2.15), 0.72, 0.24)
    for i, bx in enumerate((-3.2, -5.0)):
        b.cyl(f"bl_{i}", (bx, 3.35, 0.52), 0.065, 0.84, "steel", "Z")
        b.cyl(f"blc_{i}", (bx, 3.35, 0.86), 0.068, 0.08, "yellow", "Z")
    _lamp(b, "lm_c", -6.30, 3.40, 0.10, 0.75)
    for i, wx in enumerate((2.68, 5.28)):
        for j, wy in enumerate((3.76, 5.40)):
            _wheel(b, f"vw_{i}{j}", wx, wy, 0.34, 0.24)
    b.box("vn_ch", (4.06, 4.58, 0.36), (4.46, 1.80, 0.24), "black")
    b.box("vn_cg", (4.68, 4.58, 1.38), (3.10, 1.88, 1.78), "white", 0, 0.03)
    b.box("vn_st", (4.68, 4.58, 1.06), (3.12, 1.90, 0.22), "navy", 0, 0.005)
    b.box("vn_cb", (2.55, 4.58, 0.88), (1.18, 1.84, 0.80), "white", 0, 0.03)
    b.box("vn_bp", (1.90, 4.58, 0.44), (0.16, 1.86, 0.24), "black")
    b.box("vn_gr", (1.95, 4.58, 0.80), (0.06, 1.06, 0.32), "black")
    for j, hy in enumerate((3.92, 5.24)):
        b.box(f"vn_hl{j}", (1.95, hy, 0.84), (0.06, 0.24, 0.16), "light", 0, 0.005)
    b.box("vn_in", (2.70, 4.58, 1.66), (0.86, 1.64, 0.72), "black")
    for j, gy in enumerate((3.66, 5.50)):
        b.box(f"vn_sg{j}", (2.72, gy, 1.66), (0.76, 0.04, 0.62), "glass", 0, 0.004)
    b.box("vn_ws", (2.15, 4.58, 1.64), (0.08, 1.68, 0.66), "glass", 0, 0.004)
    b.box("vn_rf", (2.72, 4.58, 2.06), (1.02, 1.82, 0.14), "white", 0, 0.025)
    for j, py in enumerate((3.72, 5.44)):
        b.beam(f"vn_ap{j}", (2.06, py, 1.28), (2.28, py, 2.02), 0.032, "white")
        b.beam(f"vn_rr{j}", (3.25, py, 2.31), (6.10, py, 2.31), 0.022, "steel")
    b.beam("vn_ms", (2.35, 3.66, 1.48), (2.35, 3.59, 1.48), 0.014, "black")
    b.box("vn_mh", (2.35, 3.59, 1.50), (0.09, 0.06, 0.20), "black", 0, 0.008)
    b.sign("CITY EXPRESS", (4.68, 3.62, 1.58), 1.65, 0.34)
    b.genie("bin", (-2.35, 3.55), 0.10, 0.92, 0.0)
    b.genie("table", (-4.35, 4.95), 0.10, 0.76, 0.0)
    b.genie("chair", (-5.10, 4.95), 0.10, 0.84, 1.45)
    b.genie("plant", (-7.10, 5.45), 0.10, 1.35, 0.4)
    b.genie("plant", (7.30, 4.15), 0.10, 1.25, -0.5)


def _market(b):
    for x in (-7.8, -2.6, 2.6, 7.8):
        b.box(f"mp_{x:.1f}", (x, 6.78, 2.30), (0.64, 0.42, 4.60), "brick")
    _bay(b, "mh1", -5.2, 6.60, 0.0, 4.6, "walnut")
    _bay(b, "mh2", 0.0, 6.60, 0.0, 4.6, "sage")
    _bay(b, "mh3", 5.2, 6.60, 0.0, 4.6, "navy")
    for i, (px, py, ph) in enumerate(((-3.3, 3.45, 2.74), (3.3, 3.45, 2.74), (-3.3, 5.75, 2.52), (3.3, 5.75, 2.52))):
        b.beam(f"mc_p{i}", (px, py, 0.0), (px, py, ph), 0.044, "steel")
    b.beam("mc_fe", (-3.3, 3.45, 2.72), (3.3, 3.45, 2.72), 0.036, "steel")
    b.beam("mc_re", (-3.3, 5.75, 2.50), (3.3, 5.75, 2.50), 0.036, "steel")
    b.beam("mc_rg", (-3.3, 4.60, 3.16), (3.3, 4.60, 3.16), 0.038, "steel")
    for i, rx in enumerate((-3.3, -1.65, 0.0, 1.65, 3.3)):
        b.beam(f"mc_f{i}", (rx, 3.45, 2.74), (rx, 4.60, 3.16), 0.028, "steel")
        b.beam(f"mc_r{i}", (rx, 4.60, 3.16), (rx, 5.75, 2.52), 0.028, "steel")
        if i in (0, 2, 4):
            b.beam(f"mc_t{i}", (rx, 3.45, 2.66), (rx, 5.75, 2.52), 0.024, "steel")
            b.beam(f"mc_k{i}", (rx, 4.60, 2.60), (rx, 4.60, 3.16), 0.022, "steel")
    for i in range(6):
        sy = 3.55 + i * 0.42
        sz = 3.16 - abs(sy - 4.60) * 0.44
        for j in range(6):
            b.box(f"mc_c{i}{j}", (-2.75 + j * 1.10, sy, sz), (1.11, 0.46, 0.04), "terracotta" if j % 2 == 0 else "ivory", 0, 0.005)
    for j in range(10):
        b.box(f"mc_v{j}", (-2.97 + j * 0.66, 3.43, 2.58), (0.64, 0.025, 0.26), "terracotta" if j % 2 == 0 else "ivory", 0, 0.004)
    b.sign("FRESH MARKET  DRINKS & PRODUCE", (0.0, 3.40, 2.94), 3.4, 0.42)
    b.box("md_bk", (0.0, 5.48, 1.18), (5.60, 0.08, 2.36), "walnut")
    b.box("md_ct", (0.0, 5.00, 0.78), (5.50, 0.90, 0.06), "oak")
    b.box("md_fr", (0.0, 4.58, 0.39), (5.44, 0.05, 0.76), "walnut")
    for i, lx in enumerate((-2.65, -0.88, 0.88, 2.65)):
        b.box(f"md_l{i}", (lx, 5.00, 0.39), (0.08, 0.84, 0.76), "walnut")
    for i, sz in enumerate((1.34, 1.84)):
        b.box(f"md_s{i}", (0.0, 5.22, sz), (5.40, 0.44, 0.05), "oak")
    _crate(b, "cr1", -2.05, 4.92, 0.81, 0.05, "teal", True)
    _crate(b, "cr2", -0.68, 4.92, 0.81, -0.04, "sage", True)
    _crate(b, "cr3", 0.68, 4.92, 0.81, 0.06, "terracotta", False)
    _crate(b, "cr4", 2.05, 4.92, 0.81, -0.08, "yellow", False)
    _crate(b, "cr5", -1.55, 5.20, 1.365, 0.0, "red", True)
    _crate(b, "cr6", 1.55, 5.20, 1.365, 0.0, "teal", True)
    b.sign("SODA 2.50 | CITRUS 3.00", (0.0, 5.02, 2.16), 2.1, 0.32)
    _stall(b, "stl", -6.75, 3.25, 2.40, 3.60, "navy", "ARTISAN BAKERY", False)
    _stall(b, "str", 6.75, 3.25, 2.40, 3.60, "sage", "MARKET FLOWERS", True)
    b.beam("fs_l", (-5.55, 3.45, 2.74), (-3.30, 3.45, 2.74), 0.012, "black")
    b.beam("fs_r", (3.30, 3.45, 2.74), (5.55, 3.45, 2.74), 0.012, "black")
    for i, lx in enumerate((-4.8, -4.05, 4.05, 4.8)):
        b.cyl(f"fb_{i}", (lx, 3.45, 2.68), 0.045, 0.08, "light", "Z")
    b.genie("carton", (-2.75, 3.95), 0.0, 0.45, 0.2)
    b.genie("carton", (2.75, 3.95), 0.0, 0.42, -0.25)
    b.genie("bin", (-4.35, 4.15), 0.0, 0.88, 0.0)
    b.genie("plant", (4.35, 4.15), 0.0, 1.32, 0.5)
    b.genie("shelf", (-6.85, 4.35), 0.0, 1.65, 0.0)


def _bus(b):
    for i in range(9):
        b.box(f"by_{i}", (-1.4 + i * 1.15, 3.16, 0.002), (0.72, 0.12, 0.004), "yellow", 0, 0.0)
    b.box("bs_sw", (0.0, 6.62, 0.05), (17.2, 0.96, 0.10), "concrete", 0, 0.008)
    b.box("bs_kb", (0.0, 6.16, 0.055), (17.2, 0.18, 0.11), "stone", 0, 0.01)
    for x in (-7.8, -2.6, 2.6, 7.8):
        b.box(f"bp_{x:.1f}", (x, 7.28, 2.40), (0.64, 0.42, 4.60), "brick")
    _bay(b, "bf1", -5.2, 7.10, 0.10, 4.6, "teal", "navy", "STATION PHARMACY")
    _bay(b, "bf2", 0.0, 7.10, 0.10, 4.6, "walnut", "ivory", "METRO CAFE")
    _bay(b, "bf3", 5.2, 7.10, 0.10, 4.6, "navy", None, "TRANSIT HALL")
    for i, sx in enumerate((-6.50, -5.20, -3.90, -2.60)):
        b.beam(f"sh_p{i}", (sx, 4.86, 0.0), (sx, 4.86, 2.52), 0.042, "steel")
    for i, sx in enumerate((-6.50, -4.55, -2.60)):
        b.beam(f"sh_c{i}", (sx, 3.38, 2.52), (sx, 4.92, 2.52), 0.036, "steel")
    b.beam("sh_fb", (-6.54, 3.38, 2.52), (-2.56, 3.38, 2.52), 0.04, "steel")
    b.beam("sh_rb", (-6.54, 4.90, 2.52), (-2.56, 4.90, 2.52), 0.04, "steel")
    b.box("sh_rf", (-4.55, 4.14, 2.57), (4.06, 1.60, 0.04), "glass", 0, 0.005)
    b.box("sh_lt", (-4.55, 4.14, 2.49), (2.60, 0.14, 0.03), "light", 0, 0.004)
    for i, gx in enumerate((-5.85, -4.55, -3.25)):
        b.box(f"sh_g{i}", (gx, 4.86, 1.36), (1.22, 0.03, 2.18), "glass", 0, 0.004)
    b.box("sh_ad", (-6.52, 4.12, 1.30), (0.12, 1.34, 2.16), "steel")
    b.box("sh_ap", (-6.45, 4.12, 1.30), (0.02, 1.16, 1.88), "ivory", 0, 0.004)
    b.box("bn_st", (-4.55, 4.44, 0.46), (2.46, 0.44, 0.06), "oak")
    b.box("bn_bk", (-4.55, 4.66, 0.80), (2.46, 0.05, 0.34), "oak")
    for i, lx in enumerate((-5.55, -4.55, -3.55)):
        b.beam(f"bn_l{i}", (lx, 4.44, 0.0), (lx, 4.44, 0.44), 0.028, "steel")
        b.beam(f"bn_r{i}", (lx, 4.64, 0.44), (lx, 4.66, 0.86), 0.022, "steel")
    b.sign("LINE 42  DOWNTOWN EXPRESS", (-4.55, 3.34, 2.54), 2.5, 0.26)
    b.beam("sp_p", (-2.18, 3.40, 0.0), (-2.18, 3.40, 2.74), 0.04, "steel")
    b.box("sp_tb", (-2.18, 3.36, 1.46), (0.44, 0.06, 0.56), "ivory")
    b.sign("BUS STOP 42", (-2.18, 3.33, 2.46), 0.78, 0.34)
    for i, rx in enumerate((-8.15, -7.55, -6.95)):
        b.beam(f"gr_p{i}", (rx, 3.40, 0.0), (rx, 3.40, 0.96), 0.026, "steel")
    b.beam("gr_t", (-8.15, 3.40, 0.94), (-6.95, 3.40, 0.94), 0.024, "steel")
    b.beam("gr_m", (-8.15, 3.40, 0.52), (-6.95, 3.40, 0.52), 0.02, "steel")
    _lamp(b, "lm_b", -7.45, 3.55, 0.0, 0.75)
    for i, wx in enumerate((0.55, 6.25)):
        for j, wy in enumerate((3.60, 5.76)):
            _wheel(b, f"bw_{i}{j}", wx, wy, 0.50, 0.30)
    b.box("bu_ch", (3.55, 4.68, 0.40), (10.2, 2.38, 0.26), "black")
    for i, (sx, sw) in enumerate(((-1.35, 0.50), (1.58, 3.24), (6.48, 4.44))):
        b.box(f"bu_lb{i}", (sx, 4.68, 0.91), (sw, 2.46, 0.78), "navy", 0, 0.02)
    b.box("bu_sy", (3.55, 4.68, 1.24), (10.32, 2.48, 0.12), "yellow", 0, 0.005)
    b.box("bu_in", (3.55, 4.68, 1.89), (9.96, 2.24, 1.18), "black")
    for j, gy in enumerate((3.46, 5.90)):
        b.box(f"bu_gl{j}", (3.55, gy, 1.89), (10.1, 0.04, 1.14), "glass", 0, 0.004)
    for i in range(10):
        b.box(f"bu_ml{i}", (-1.45 + i * 1.12, 3.45, 1.89), (0.09, 0.06, 1.18), "black", 0, 0.004)
    for i, dx in enumerate((-0.58, 3.72)):
        b.box(f"bu_dr{i}", (dx, 3.47, 1.38), (1.02, 0.06, 2.02), "glass", 0, 0.005)
        b.box(f"bu_df{i}", (dx, 3.45, 1.38), (0.06, 0.08, 2.04), "steel", 0, 0.004)
        b.beam(f"bu_hr{i}", (dx - 0.46, 3.55, 0.42), (dx - 0.46, 3.55, 1.72), 0.018, "yellow")
    b.box("bu_tp", (3.55, 4.68, 2.71), (10.30, 2.46, 0.46), "white", 0, 0.03)
    b.box("bu_ws", (-1.59, 4.68, 1.86), (0.08, 2.28, 1.24), "glass", 0, 0.005)
    b.box("bu_hd", (-1.60, 4.68, 2.68), (0.10, 1.76, 0.30), "black")
    for j, hy in enumerate((3.86, 5.50)):
        b.box(f"bu_hl{j}", (-1.60, hy, 0.76), (0.06, 0.28, 0.16), "light", 0, 0.005)
    b.beam("bu_ms", (-1.48, 3.46, 1.84), (-1.48, 3.39, 1.84), 0.016, "black")
    b.box("bu_mh", (-1.48, 3.39, 1.82), (0.10, 0.06, 0.34), "black", 0, 0.008)
    b.box("bu_ac", (3.45, 4.68, 3.08), (2.90, 1.56, 0.28), "ivory", 0, 0.03)
    b.box("bu_bt", (0.65, 4.68, 3.04), (1.80, 1.48, 0.20), "white", 0, 0.025)
    b.box("bu_vn", (6.95, 4.68, 3.04), (1.50, 1.36, 0.20), "steel", 0, 0.02)
    b.sign("ROUTE 42  CITY CENTER", (-0.45, 3.42, 2.72), 2.15, 0.30)
    b.genie("bin", (-6.95, 4.30), 0.0, 0.94, 0.0)
    b.genie("plant", (-7.95, 5.45), 0.0, 1.35, 0.35)
    b.genie("plant", (-2.15, 5.55), 0.0, 1.25, -0.4)
    b.genie("cabinet", (-8.00, 6.60), 0.10, 1.18, 0.0)


def dress(slug, b):
    if slug == "crossing":
        _crossing(b)
    elif slug == "market":
        _market(b)
    elif slug == "bus":
        _bus(b)
    else:
        raise ValueError(f"Unknown slug: {slug}")
