import math

def _shell(b, p, wm, dm, sm, h=3.6, dh=1.05, ops=()):
    for s, x in (("l", -6.72), ("r", 6.72)):
        sx = -6.585 if s == "l" else 6.585
        if dh > 0.2:
            b.box(f"{p}_{s}d", (x, 0.42, dh / 2), (0.24, 8.04, dh), dm, 0, 0.005)
            b.box(f"{p}_{s}u", (x, 0.42, (dh + h) / 2), (0.24, 8.04, h - dh), wm, 0, 0.005)
            b.box(f"{p}_{s}r", (sx, 0.30, dh), (0.04, 7.80, 0.05), sm, 0, 0.008)
        else:
            b.box(f"{p}_{s}w", (x, 0.42, h / 2), (0.24, 8.04, h), wm, 0, 0.005)
        b.box(f"{p}_{s}k", (sx, 0.30, 0.07), (0.03, 7.80, 0.14), sm, 0, 0.006)
        b.box(f"{p}_{s}c", (sx, 0.30, h - 0.05), (0.05, 7.80, 0.10), sm, 0, 0.006)
    def seg(tag, xa, xb, za, zb, mat):
        if xb - xa > 0.02 and zb - za > 0.02:
            b.box(f"{p}_{tag}", ((xa + xb) / 2, 4.32, (za + zb) / 2), (xb - xa, 0.24, zb - za), mat, 0, 0.005)
    def pier(tag, xa, xb, zm):
        if xb - xa <= 0.02:
            return
        if dh > 0.2 and zm > dh:
            seg(f"{tag}d", xa, xb, 0.0, dh, dm)
            seg(f"{tag}u", xa, xb, dh, zm, wm)
            b.box(f"{p}_{tag}r", ((xa + xb) / 2, 4.18, dh), (xb - xa, 0.04, 0.05), sm, 0, 0.008)
        else:
            seg(f"{tag}w", xa, xb, 0.0, zm, dm if dh > 0.2 else wm)
        b.box(f"{p}_{tag}k", ((xa + xb) / 2, 4.185, 0.07), (xb - xa, 0.03, 0.14), sm, 0, 0.006)
    cx = -6.60
    for i, (x0, x1, z0, z1, kind, fm, cols, rows, bm) in enumerate(sorted(ops)):
        pier(f"p{i}", cx, x0, h)
        if z0 > 0.02:
            pier(f"a{i}", x0, x1, z0)
        seg(f"t{i}", x0, x1, z1, h, wm)
        w, oh, mx, mz = x1 - x0, z1 - z0, (x0 + x1) / 2, (z0 + z1) / 2
        b.box(f"{p}_jl{i}", (x0 + 0.035, 4.30, mz), (0.07, 0.26, oh), fm, 0, 0.006)
        b.box(f"{p}_jr{i}", (x1 - 0.035, 4.30, mz), (0.07, 0.26, oh), fm, 0, 0.006)
        b.box(f"{p}_jh{i}", (mx, 4.30, z1 - 0.035), (w, 0.26, 0.07), fm, 0, 0.006)
        if kind == "win":
            bz0, bz1 = max(0.0, z0 - 0.12), min(h, z1 + 0.12)
            b.box(f"{p}_js{i}", (mx, 4.26, z0 + 0.025), (w + 0.06, 0.30, 0.05), fm, 0, 0.008)
            b.box(f"{p}_gl{i}", (mx, 4.34, mz), (w - 0.10, 0.02, oh - 0.10), "glass", 0, 0.002)
            b.box(f"{p}_bk{i}", (mx, 4.66, (bz0 + bz1) / 2), (w + 0.60, 0.10, bz1 - bz0), bm, 0, 0.005)
            for c in range(1, cols):
                b.box(f"{p}_mc{i}_{c}", (x0 + w * c / cols, 4.31, mz), (0.045, 0.08, oh - 0.08), fm, 0, 0.004)
            for r in range(1, rows + 1):
                b.box(f"{p}_mr{i}_{r}", (mx, 4.31, z0 + oh * r / (rows + 1)), (w - 0.08, 0.08, 0.045), fm, 0, 0.004)
        else:
            b.box(f"{p}_dl{i}", (mx, 4.36, mz), (w - 0.10, 0.06, oh - 0.06), bm, 0, 0.008)
            b.box(f"{p}_dk{i}", (mx, 4.32, 0.16), (w - 0.16, 0.02, 0.28), "chrome", 0, 0.004)
            if cols >= 2:
                b.box(f"{p}_dm{i}", (mx, 4.32, mz), (0.04, 0.08, oh - 0.08), fm, 0, 0.004)
                for sgn in (-1, 1):
                    b.box(f"{p}_dv{i}_{sgn}", (mx + sgn * w * 0.20, 4.325, 1.50), (0.22, 0.02, 0.92), "glass", 0, 0.003)
                    b.box(f"{p}_dh{i}_{sgn}", (mx + sgn * 0.18, 4.27, 1.02), (0.28, 0.04, 0.04), "chrome", 0, 0.006)
            elif cols == 1:
                b.box(f"{p}_dv{i}", (x0 + w * 0.30, 4.325, 1.48), (0.20, 0.02, 0.95), "glass", 0, 0.003)
                b.cyl(f"{p}_dh{i}", (x1 - 0.18, 4.27, 1.02), 0.016, 0.24, "chrome", "Z")
        cx = x1
    pier("pf", cx, 6.60, h)
    b.box(f"{p}_bc", (0.0, 4.18, h - 0.05), (13.20, 0.05, 0.10), sm, 0, 0.006)

def _ceiling(b, p, h, bm):
    for i, x in enumerate((-4.5, -1.5, 1.5, 4.5)):
        b.box(f"{p}_cb{i}", (x, 0.42, h - 0.12), (0.22, 7.80, 0.20), bm, 0, 0.008)
    for j, x in enumerate((-3.0, 0.0, 3.0)):
        b.box(f"{p}_lf{j}", (x, 1.80, h - 0.04), (1.30, 0.26, 0.06), "steel", 0, 0.005)
        b.box(f"{p}_ll{j}", (x, 1.80, h - 0.08), (1.20, 0.18, 0.02), "light", 0, 0.003)

def _desk(b, p, cx, cy, sx, sy, h, bm, tm):
    b.box(f"{p}_k", (cx, cy, 0.05), (sx - 0.08, sy - 0.08, 0.10), "black", 0, 0.005)
    b.box(f"{p}_b", (cx, cy, 0.10 + (h - 0.16) / 2), (sx - 0.02, sy - 0.04, h - 0.16), bm, 0, 0.01)
    b.box(f"{p}_t", (cx, cy, h - 0.03), (sx, sy, 0.06), tm, 0, 0.012)

def _books(b, p, x0, x1, y, z, seed):
    ms = ("navy", "terracotta", "sage", "walnut", "teal", "ivory")
    x, i = x0, 0
    while x < x1 - 0.14:
        w, bh = 0.14 + 0.05 * ((i + seed) % 3), 0.23 + 0.04 * ((i * 2 + seed) % 3)
        b.box(f"{p}_{i}", (x + w / 2, y, z + bh / 2), (w - 0.01, 0.22, bh), ms[(i + seed) % 6], 0, 0.006)
        x += w + (0.04 if (i + seed) % 4 == 2 else 0.008)
        i += 1

def _hospital(b):
    _shell(b, "ho", "ivory", "sage", "rubber", 3.6, 1.10, (
        (-4.6, -1.0, 1.08, 2.58, "win", "steel", 3, 1, "white"),
        (1.1, 3.1, 0.0, 2.35, "door", "steel", 2, 0, "teal"),
    ))
    _ceiling(b, "ho", 3.6, "white")
    for i, (xa, xb) in enumerate(((-6.40, -4.75), (-0.85, 0.95), (5.82, 6.45))):
        b.cyl(f"ho_gr{i}", ((xa + xb) / 2, 4.11, 0.88), 0.022, xb - xa, "chrome", "X")
        b.box(f"ho_gb{i}", ((xa + xb) / 2, 4.17, 0.62), (xb - xa, 0.05, 0.11), "teal", 0, 0.008)
        for j, bx in enumerate((xa + 0.12, xb - 0.12)):
            b.cyl(f"ho_gk{i}_{j}", (bx, 4.155, 0.88), 0.015, 0.09, "steel", "Y")
    for s, x in (("l", -6.51), ("r", 6.51)):
        b.cyl(f"ho_sgr_{s}", (x, 0.30, 0.88), 0.022, 7.40, "chrome", "Y")
        b.box(f"ho_sgb_{s}", (x * 1.009, 0.30, 0.62), (0.05, 7.40, 0.11), "teal", 0, 0.008)
    _desk(b, "ho_sc", 4.80, 3.84, 1.90, 0.58, 0.90, "white", "stone")
    b.box("ho_uc", (4.80, 4.00, 1.85), (1.86, 0.36, 0.78), "steel", 0, 0.01)
    b.box("ho_ug", (4.80, 3.81, 1.85), (1.72, 0.02, 0.66), "glass", 0, 0.003)
    b.box("ho_sb", (2.10, 4.16, 2.48), (0.36, 0.08, 0.11), "black", 0, 0.005)
    b.box("ho_sl", (2.10, 4.115, 2.48), (0.26, 0.02, 0.04), "light", 0, 0.002)
    b.sign("EMERGENCY CORRIDOR", (-2.80, 4.18, 2.92), 2.10, 0.24)
    b.sign("TREATMENT BAY 2", (2.10, 4.18, 2.74), 1.60, 0.24)
    b.sign("MEDICAL SUPPLIES", (4.80, 4.18, 2.48), 1.50, 0.22)
    b.genie("cabinet", (-5.70, 3.74), 0.0, 1.80, 0)
    b.genie("cabinet", (-6.12, 1.20), 0.0, 1.65, math.pi / 2)
    b.genie("chair", (-0.35, 3.64), 0.0, 0.86, 0)
    b.genie("chair", (0.45, 3.64), 0.0, 0.86, 0)
    b.genie("bin", (3.52, 3.78), 0.0, 0.65, 0)
    b.genie("medicine", (4.30, 3.82), 0.90, 0.22, 0)
    b.genie("medicine", (4.70, 3.85), 0.90, 0.26, 0.4)
    b.genie("folder", (5.30, 3.82), 0.90, 0.05, 0.2)

def _meeting(b):
    _shell(b, "mt", "ivory", "walnut", "oak", 3.6, 0.95, (
        (-5.8, -3.0, 0.20, 2.95, "win", "black", 3, 1, "ivory"),
        (3.6, 4.7, 0.0, 2.35, "door", "black", 1, 0, "walnut"),
    ))
    _ceiling(b, "mt", 3.6, "walnut")
    b.box("mt_fb", (-4.40, 4.29, 1.40), (2.68, 0.015, 0.56), "white", 0, 0.002)
    for i, x in enumerate((-2.60, -2.42, -2.24, 2.24, 2.42, 2.60)):
        b.box(f"mt_sl{i}", (x, 4.17, 2.05), (0.08, 0.05, 2.20), "walnut", 0, 0.006)
    b.box("mt_bz", (0.0, 4.14, 2.02), (4.16, 0.08, 1.76), "black", 0, 0.01)
    b.box("mt_sc", (0.0, 4.092, 2.02), (4.00, 0.02, 1.60), "white", 0, 0.003)
    b.box("mt_sh", (0.0, 4.078, 2.62), (3.76, 0.01, 0.24), "navy", 0, 0.002)
    for i, (bx, bh, bm) in enumerate(((-1.45, 0.52, "teal"), (-1.05, 0.78, "sage"), (-0.65, 0.96, "navy"), (-0.25, 0.68, "terracotta"))):
        b.box(f"mt_ch{i}", (bx, 4.076, 1.42 + bh / 2), (0.26, 0.01, bh), bm, 0, 0.002)
    for i, z in enumerate((2.18, 1.88, 1.58)):
        b.box(f"mt_ln{i}", (0.98, 4.076, z), (1.35, 0.01, 0.08), "stone", 0, 0.002)
    _desk(b, "mt_av", 0.0, 3.84, 3.40, 0.52, 0.68, "walnut", "stone")
    _desk(b, "mt_rc", 6.14, 0.60, 0.56, 2.30, 0.82, "walnut", "stone")
    b.sign("Q3 OPERATIONS BRIEFING", (0.0, 4.065, 2.62), 2.30, 0.20)
    b.sign("CONFERENCE ROOM B", (4.15, 4.18, 2.65), 1.60, 0.22)
    for y in (2.40, 1.40, 0.40, -0.60):
        b.genie("chair", (-5.95, y), 0.0, 0.86, math.pi / 2)
    b.genie("chair", (5.25, 3.56), 0.0, 0.86, 0)
    b.genie("chair", (6.00, 3.56), 0.0, 0.86, 0)
    b.genie("plant", (-2.75, 3.70), 0.0, 1.45, 0)
    b.genie("plant", (3.08, 3.70), 0.0, 1.40, 0.5)
    b.genie("cabinet", (6.12, -1.65), 0.0, 1.55, -math.pi / 2)
    b.genie("laptop", (-0.75, 3.82), 0.68, 0.24, 0.15)
    b.genie("water", (6.10, 0.10), 0.82, 0.24, 0)
    b.genie("cup", (6.10, 0.55), 0.82, 0.14, 0)
    b.genie("folder", (6.12, 1.25), 0.82, 0.05, 0.3)

def _museum(b):
    _shell(b, "mu", "stone", "stone", "black", 3.6, 0.0, (
        (-5.6, -4.5, 0.0, 2.38, "door", "black", 1, 0, "oak"),
        (0.6, 3.6, 1.38, 2.82, "win", "black", 3, 1, "ivory"),
    ))
    _ceiling(b, "mu", 3.6, "black")
    b.beam("mu_tr", (-4.4, 3.45, 3.26), (4.4, 3.45, 3.26), 0.025, "black")
    for i, x in enumerate((-2.8, -1.4, 1.4, 2.8)):
        b.cyl(f"mu_sp{i}", (x, 3.45, 3.16), 0.052, 0.16, "black", "Z")
    _desk(b, "mu_vp", -2.10, 3.66, 2.00, 0.84, 0.96, "walnut", "stone")
    b.box("mu_vf", (-2.10, 3.66, 0.98), (1.88, 0.72, 0.04), "navy", 0, 0.005)
    for i, (cx, cy) in enumerate(((-3.08, 3.26), (-1.12, 3.26), (-3.08, 4.06), (-1.12, 4.06))):
        b.box(f"mu_vm{i}", (cx, cy, 1.61), (0.032, 0.032, 1.22), "steel", 0, 0.004)
    b.box("mu_vc", (-2.10, 3.66, 2.26), (2.02, 0.86, 0.08), "walnut", 0, 0.01)
    b.box("mu_vl", (-2.10, 3.66, 2.21), (1.20, 0.12, 0.02), "light", 0, 0.003)
    for i, (cx, cy, sx, sy) in enumerate(((-2.10, 3.26, 1.92, 0.02), (-2.10, 4.06, 1.92, 0.02), (-3.08, 3.66, 0.02, 0.76), (-1.12, 3.66, 0.02, 0.76))):
        b.box(f"mu_vg{i}", (cx, cy, 1.61), (sx, sy, 1.20), "glass", 0, 0.002)
    b.cyl("mu_a1", (-2.45, 3.66, 1.05), 0.12, 0.10, "terracotta", "Z")
    b.cyl("mu_a2", (-2.45, 3.66, 1.26), 0.18, 0.32, "terracotta", "Z")
    b.cyl("mu_a3", (-2.45, 3.66, 1.50), 0.08, 0.16, "terracotta", "Z")
    b.box("mu_st", (-1.68, 3.66, 1.26), (0.36, 0.10, 0.52), "stone", 0, 0.012)
    b.cyl("mu_lp", (-0.76, 3.66, 0.51), 0.024, 1.02, "black", "Z")
    b.box("mu_lb", (-0.76, 3.66, 1.08), (0.62, 0.04, 0.24), "stone", 0, 0.006)
    for i, (lx, ly) in enumerate(((0.70, 3.48), (3.50, 3.48), (0.70, 4.08), (3.50, 4.08))):
        b.box(f"mu_bl{i}", (lx, ly, 0.43), (0.05, 0.05, 0.86), "steel", 0, 0.005)
    b.box("mu_bs", (2.10, 3.78, 0.19), (2.82, 0.62, 0.04), "oak", 0, 0.006)
    b.box("mu_bt", (2.10, 3.78, 0.87), (2.90, 0.68, 0.06), "oak", 0, 0.01)
    b.box("mu_fr", (4.80, 4.17, 1.78), (1.10, 0.05, 1.35), "oak", 0, 0.008)
    b.box("mu_fp", (4.80, 4.14, 1.78), (0.92, 0.02, 1.15), "ivory", 0, 0.003)
    b.sign("CONSERVATION BAY 3", (-2.10, 4.18, 2.95), 2.10, 0.24)
    b.sign("REPLICA VESSEL 14B", (-0.76, 3.62, 1.08), 0.56, 0.18)
    b.sign("ARCHIVE STORAGE", (2.10, 4.18, 3.08), 1.65, 0.22)
    b.genie("cabinet", (5.95, 3.70), 0.0, 1.80, 0)
    b.genie("shelf", (6.10, 1.35), 0.0, 1.85, -math.pi / 2)
    b.genie("table", (-5.98, 1.55), 0.0, 0.76, math.pi / 2)
    b.genie("chair", (-5.98, 0.45), 0.0, 0.86, math.pi / 2)
    b.genie("laptop", (1.25, 3.76), 0.90, 0.24, 0.1)
    b.genie("folder", (2.05, 3.78), 0.90, 0.05, -0.2)
    b.genie("book", (2.85, 3.78), 0.90, 0.26, 0.15)
    b.genie("carton", (1.45, 3.78), 0.21, 0.36, 0)
    b.genie("carton", (2.65, 3.78), 0.21, 0.36, 0.1)

def _hotel(b):
    _shell(b, "ht", "ivory", "terrazzo", "walnut", 3.6, 1.15, ((-5.6, -3.1, 0.45, 3.05, "win", "walnut", 2, 2, "ivory"),))
    _ceiling(b, "ht", 3.6, "walnut")
    _desk(b, "ht_rd", -0.35, 3.56, 4.20, 0.66, 1.06, "walnut", "stone")
    for i in range(11):
        b.box(f"ht_fl{i}", (-2.20 + i * 0.37, 3.23, 0.56), (0.04, 0.03, 0.88), "oak", 0, 0.005)
    b.box("ht_kb", (-0.35, 4.16, 1.90), (3.40, 0.08, 1.32), "black", 0, 0.006)
    for i in range(5):
        b.box(f"ht_kh{i}", (-0.35, 4.10, 1.26 + i * 0.32), (3.44, 0.16, 0.04), "walnut", 0, 0.005)
    for j in range(9):
        b.box(f"ht_kv{j}", (-2.05 + j * 0.425, 4.10, 1.90), (0.04, 0.16, 1.32), "oak", 0, 0.005)
    for i, x in enumerate((2.36, 3.90, 5.44)):
        b.box(f"ht_np{i}", (x, 3.87, 1.38), (0.14, 0.66, 2.76), "walnut", 0, 0.008)
    b.box("ht_nh", (3.90, 3.87, 2.72), (3.22, 0.66, 0.14), "walnut", 0, 0.008)
    b.box("ht_nb", (3.90, 3.86, 0.19), (2.96, 0.62, 0.38), "stone", 0, 0.01)
    b.box("ht_ns", (3.90, 3.92, 1.96), (2.96, 0.50, 0.05), "walnut", 0, 0.008)
    for i, cx in enumerate((3.13, 4.67)):
        b.cyl(f"ht_sr1_{i}", (cx, 4.12, 0.72), 0.018, 1.32, "chrome", "X")
        b.cyl(f"ht_sr2_{i}", (cx, 4.12, 1.04), 0.018, 1.32, "chrome", "X")
        b.box(f"ht_nl{i}", (cx, 3.88, 2.64), (0.90, 0.10, 0.02), "light", 0, 0.003)
    b.sign("RECEPTION", (-0.35, 4.18, 2.94), 1.70, 0.28)
    b.sign("LUGGAGE BAY", (3.90, 4.18, 3.04), 1.75, 0.25)
    b.sign("ROOM KEYS", (-0.35, 4.01, 2.60), 1.15, 0.16)
    b.genie("sofa", (-4.35, 3.62), 0.0, 0.84, 0)
    b.genie("plant", (-5.98, 3.66), 0.0, 1.55, 0)
    b.genie("plant", (5.98, 3.66), 0.0, 1.55, 0.8)
    b.genie("chair", (-5.98, 1.65), 0.0, 0.85, math.pi / 2)
    b.genie("table", (-5.98, 0.45), 0.0, 0.72, math.pi / 2)
    b.genie("cabinet", (6.08, 1.25), 0.0, 1.48, -math.pi / 2)
    b.genie("laptop", (-1.15, 3.58), 1.06, 0.24, 0.1)
    b.genie("folder", (0.55, 3.58), 1.06, 0.05, -0.15)
    b.genie("carton", (3.12, 3.84), 0.38, 0.44, 0.1)
    b.genie("carton", (4.68, 3.88), 1.985, 0.38, -0.1)

def _bank(b):
    _shell(b, "bk", "ivory", "navy", "stone", 3.6, 1.10, (
        (-5.6, -4.5, 0.0, 2.38, "door", "steel", 1, 0, "oak"),
        (-3.8, 3.8, 2.38, 3.18, "win", "steel", 5, 1, "ivory"),
    ))
    _ceiling(b, "bk", 3.6, "white")
    _desk(b, "bk_ct", 0.0, 3.56, 7.36, 0.70, 1.08, "oak", "stone")
    for i, x in enumerate((-2.44, 0.0, 2.44)):
        b.box(f"bk_ap{i}", (x, 3.21, 0.56), (1.95, 0.03, 0.72), "navy", 0, 0.008)
        b.box(f"bk_sh{i}", (x, 3.86, 1.60), (2.32, 0.02, 0.70), "glass", 0, 0.003)
    for i, x in enumerate((-3.66, -1.22, 1.22, 3.66)):
        b.box(f"bk_pf{i}", (x, 3.24, 1.52), (0.04, 0.04, 0.88), "chrome", 0, 0.005)
        b.box(f"bk_pb{i}", (x, 3.88, 1.52), (0.04, 0.04, 0.88), "chrome", 0, 0.005)
        b.box(f"bk_dg{i}", (x, 3.56, 1.52), (0.02, 0.62, 0.84), "glass", 0, 0.002)
        b.box(f"bk_df{i}", (x, 3.56, 1.54), (0.03, 0.58, 0.36), "white", 0, 0.003)
    b.box("bk_hd", (0.0, 3.56, 2.02), (7.40, 0.10, 0.12), "navy", 0, 0.008)
    for s, sx, rx in (("l", -5.62, -4.40), ("r", 5.62, 4.40)):
        pts = ((rx, 3.28), (sx, 3.28), (sx, 1.90), (sx, 0.52), (sx, -0.86))
        for i, (px, py) in enumerate(pts):
            b.cyl(f"bk_qb{s}{i}", (px, py, 0.02), 0.15, 0.04, "black", "Z")
            b.cyl(f"bk_qp{s}{i}", (px, py, 0.48), 0.024, 0.92, "chrome", "Z")
            if i > 0:
                b.beam(f"bk_qr{s}{i}", (pts[i - 1][0], pts[i - 1][1], 0.84), (px, py, 0.84), 0.018, "navy")
    b.sign("TELLER COUNTERS", (0.0, 3.49, 2.02), 1.80, 0.16)
    b.sign("PRIVACY ZONE", (-2.44, 3.49, 2.02), 1.25, 0.16)
    b.sign("PLEASE WAIT HERE", (2.44, 3.49, 2.02), 1.50, 0.16)
    b.genie("plant", (-4.12, 3.74), 0.0, 1.45, 0)
    b.genie("plant", (4.12, 3.74), 0.0, 1.45, 0.6)
    b.genie("cabinet", (5.98, 3.70), 0.0, 1.72, 0)
    b.genie("chair", (5.05, 3.64), 0.0, 0.86, 0)
    b.genie("sofa", (6.05, -2.05), 0.0, 0.82, -math.pi / 2)
    b.genie("laptop", (-2.44, 3.58), 1.08, 0.24, 0)
    b.genie("laptop", (0.0, 3.58), 1.08, 0.24, 0)
    b.genie("folder", (2.44, 3.56), 1.08, 0.05, 0.15)

def _library(b):
    _shell(b, "lb", "ivory", "oak", "walnut", 3.6, 0.95, ((-2.4, 1.0, 0.82, 3.12, "win", "walnut", 3, 2, "ivory"),))
    _ceiling(b, "lb", 3.6, "oak")
    for bi, x0 in enumerate((-5.80, 1.40)):
        b.box(f"lb_bp{bi}", (x0 + 1.50, 4.14, 1.43), (3.00, 0.04, 2.86), "walnut", 0, 0.006)
        b.box(f"lb_cr{bi}", (x0 + 1.50, 3.92, 2.84), (3.08, 0.50, 0.08), "walnut", 0, 0.01)
        for j in range(4):
            b.box(f"lb_st{bi}_{j}", (x0 + j * 1.00, 3.92, 1.42), (0.06, 0.46, 2.80), "oak", 0, 0.006)
        for ti, z in enumerate((0.20, 0.72, 1.24, 1.76, 2.28)):
            b.box(f"lb_sh{bi}_{ti}", (x0 + 1.50, 3.92, z), (2.94, 0.44, 0.04), "oak", 0, 0.006)
            for sb in range(3):
                if not (ti == 2 and sb == 1):
                    _books(b, f"lb_bk{bi}_{ti}_{sb}", x0 + sb + 0.06, x0 + sb + 0.94, 3.88, z + 0.02, bi * 5 + ti + sb)
    _desk(b, "lb_br", 5.30, 3.82, 1.12, 0.62, 1.12, "walnut", "oak")
    b.box("lb_bs", (5.30, 3.50, 0.84), (0.56, 0.03, 0.14), "steel", 0, 0.005)
    b.box("lb_bo", (5.30, 3.485, 0.84), (0.46, 0.01, 0.06), "black", 0, 0.002)
    _desk(b, "lb_sd", 6.22, -0.35, 0.60, 2.10, 0.76, "oak", "walnut")
    b.cyl("lb_ls", (6.22, -1.15, 0.94), 0.016, 0.36, "chrome", "Z")
    b.cyl("lb_la", (6.22, -1.15, 1.14), 0.13, 0.14, "sage", "Z")
    b.sign("READING ROOM", (-0.70, 4.18, 3.34), 1.80, 0.24)
    b.sign("COLLECTION BOUNDARY", (2.90, 4.18, 3.08), 2.10, 0.22)
    b.sign("BOOK RETURN", (5.30, 4.18, 1.56), 1.15, 0.22)
    b.genie("shelf", (-6.12, 2.05), 0.0, 1.95, math.pi / 2)
    b.genie("shelf", (-6.12, 0.35), 0.0, 1.95, math.pi / 2)
    b.genie("shelf", (6.12, 2.10), 0.0, 1.95, -math.pi / 2)
    b.genie("table", (-0.70, 3.58), 0.0, 0.76, 0)
    b.genie("chair", (-1.58, 3.58), 0.0, 0.86, math.pi / 2)
    b.genie("chair", (0.18, 3.58), 0.0, 0.86, -math.pi / 2)
    b.genie("desk_chair", (5.64, -0.35), 0.0, 0.88, math.pi / 2)
    b.genie("plant", (-2.60, 3.74), 0.0, 1.35, 0)
    b.genie("book", (-4.45, 3.84), 1.26, 0.28, 0)
    b.genie("book", (2.75, 3.84), 1.26, 0.28, 0.1)
    b.genie("laptop", (6.18, -0.55), 0.76, 0.24, -math.pi / 2)
    b.genie("book", (6.18, 0.25), 0.76, 0.24, 0.2)

def _warehouse(b):
    _shell(b, "wh", "paint", "concrete", "yellow", 4.6, 1.35, (
        (-5.8, -1.8, 3.35, 4.20, "win", "steel", 4, 1, "ivory"),
        (-1.2, 1.8, 0.0, 3.05, "door", "steel", 0, 0, "steel"),
        (2.2, 5.8, 3.35, 4.20, "win", "steel", 4, 1, "ivory"),
    ))
    for i, y in enumerate((3.5, 1.0, -1.5)):
        b.beam(f"wh_tc{i}", (-6.55, y, 4.28), (6.55, y, 4.28), 0.055, "steel")
        b.beam(f"wh_tu{i}", (-6.55, y, 4.54), (6.55, y, 4.54), 0.055, "steel")
        for j, x in enumerate((-4.4, -2.2, 0.0, 2.2, 4.4)):
            b.beam(f"wh_td{i}_{j}", (x - 1.1, y, 4.28), (x + 1.1, y, 4.54), 0.03, "steel")
    for j, x in enumerate((-3.2, 0.0, 3.2)):
        b.box(f"wh_lp{j}", (x, 1.80, 4.20), (1.40, 0.30, 0.06), "steel", 0, 0.005)
        b.box(f"wh_ll{j}", (x, 1.80, 4.16), (1.30, 0.20, 0.02), "light", 0, 0.003)
    for i, z in enumerate((0.55, 1.05, 1.55, 2.05, 2.55)):
        b.box(f"wh_sr{i}", (0.30, 4.31, z), (2.86, 0.04, 0.05), "steel", 0, 0.004)
    for i, bx in enumerate((-1.38, 1.98)):
        b.cyl(f"wh_bo{i}", (bx, 3.88, 0.48), 0.085, 0.96, "yellow", "Z")
        b.cyl(f"wh_bc{i}", (bx, 3.88, 0.97), 0.088, 0.04, "black", "Z")
    for ri, xs in enumerate(((-5.75, -3.80, -1.85), (2.35, 4.05, 5.75))):
        for ui, ux in enumerate(xs):
            for fy, yp in enumerate((3.30, 4.06)):
                b.box(f"wh_ru{ri}_{ui}_{fy}", (ux, yp, 1.525), (0.09, 0.09, 3.05), "navy", 0, 0.005)
            b.beam(f"wh_rb{ri}_{ui}", (ux, 3.30, 0.40), (ux, 4.06, 2.60), 0.022, "steel")
        span, mx = xs[-1] - xs[0], (xs[0] + xs[-1]) / 2
        for ti, z in enumerate((0.14, 1.24, 2.34)):
            b.box(f"wh_bf{ri}_{ti}", (mx, 3.30, z), (span, 0.08, 0.10), "terracotta", 0, 0.005)
            b.box(f"wh_bb{ri}_{ti}", (mx, 4.06, z), (span, 0.08, 0.10), "terracotta", 0, 0.005)
            b.box(f"wh_pd{ri}_{ti}", (mx, 3.68, z + 0.07), (span - 0.14, 0.80, 0.06), "oak", 0, 0.006)
    for i, (cx, cz, sx, sz, cm) in enumerate((
        (-4.35, 0.24, 0.62, 0.52, "oak"), (-2.55, 0.24, 0.72, 0.56, "white"),
        (-5.05, 1.34, 0.68, 0.54, "navy"), (-2.65, 2.44, 0.70, 0.48, "oak"),
        (3.55, 1.34, 0.66, 0.52, "white"), (4.75, 0.24, 0.64, 0.56, "oak"),
        (3.15, 2.44, 0.68, 0.46, "navy"), (4.95, 2.44, 0.64, 0.50, "terracotta"),
    )):
        b.box(f"wh_cr{i}", (cx, 3.68, cz + sz / 2), (sx, 0.58, sz), cm, 0, 0.01)
    _desk(b, "wh_ib", 6.10, 0.20, 0.72, 2.00, 0.90, "steel", "oak")
    b.sign("LOADING BAY 4", (0.30, 4.18, 3.34), 1.95, 0.28)
    b.sign("RACKING AISLE A", (-3.80, 4.18, 3.16), 1.85, 0.22)
    b.sign("INSPECTION BAY", (4.05, 4.18, 3.16), 1.80, 0.22)
    b.genie("shelf", (-6.10, 1.65), 0.0, 1.95, math.pi / 2)
    b.genie("cabinet", (6.10, 2.15), 0.0, 1.80, -math.pi / 2)
    b.genie("bin", (-6.08, -0.35), 0.0, 0.72, 0)
    b.genie("bin", (6.08, -1.35), 0.0, 0.72, 0)
    b.genie("carton", (-5.10, 3.68), 0.24, 0.48, 0.05)
    b.genie("carton", (-3.15, 3.68), 1.34, 0.46, -0.1)
    b.genie("carton", (-4.80, 3.68), 2.44, 0.42, 0.0)
    b.genie("carton", (2.95, 3.68), 0.24, 0.48, 0.12)
    b.genie("carton", (5.05, 3.68), 1.34, 0.44, -0.05)
    b.genie("laptop", (6.08, 0.55), 0.90, 0.24, -math.pi / 2)
    b.genie("folder", (6.08, -0.25), 0.90, 0.05, 0.2)

_SCENES = {
    "hospital": _hospital, "meeting": _meeting, "museum": _museum,
    "hotel": _hotel, "bank": _bank, "library": _library, "warehouse": _warehouse,
}

def dress(slug, b):
    _SCENES[slug](b)
