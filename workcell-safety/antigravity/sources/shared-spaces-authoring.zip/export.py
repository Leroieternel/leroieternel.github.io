from pathlib import Path
import sys,json
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parents[1]/'robot_plans'))
import optics
tasks=json.loads((D/'selection.json').read_text());optics.CACHE=D/'optics'
for ix,row in enumerate(tasks,1):
 slug=row['slug']
 if len(sys.argv)>1 and slug not in sys.argv[1:]:continue
 p=D/'runs'/slug;info=json.loads((p/'unsafe.json').read_text())
 (p/'info.json').write_text(json.dumps({'detail_time_s':min(11.9,(info['first_event_s'] or 7)+.28)}))
 optics.paths=lambda k:p
 optics.export(ix)
 prefix=optics.CACHE/f'{ix:02d}_{slug}'
 if not prefix.exists():prefix.symlink_to(slug,target_is_directory=True)
