"""Integrate Antigravity-authored policies and persist full-rate audits and film-rate poses."""
import argparse
import csv
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import traceback
import xml.etree.ElementTree as ET

import mujoco as mj
import numpy as np
from robotlib import HERE, add, SOURCES
from select_cases import data

def write_json(path, value):
    def scalar(v):
        if isinstance(v,np.ndarray):return v.tolist()
        if isinstance(v,np.generic):return v.item()
        raise TypeError(type(v).__name__)
    path.write_text(json.dumps(value,indent=2,default=scalar,allow_nan=False)+'\n')
def listing():
    return [(i+1,g,e) for i,(g,e) in enumerate((g,e) for g,rows in data.items() for e in rows)]
def camera(world,name,eye,at,fov):
    z=np.asarray(eye)-at;z/=np.linalg.norm(z)
    x=np.cross([0.,0.,1.],z);x/=np.linalg.norm(x)
    add(world,'camera',name=name,pos=eye,xyaxes=np.r_[x,np.cross(z,x)],fovy=fov)
def view_offset(m,d,aim,focus,wide,detail):
    # Choose a front-side optical axis with line of sight to the manipulation.
    delta=np.asarray(([1.38,-2.1,1.3] if wide else [.60,-.59,.51]) if detail else ([2.1,-4.5,2.2] if wide else [1.88,-2.02,1.05]))
    radius=np.linalg.norm(delta[:2]);angles=[np.arctan2(delta[1],delta[0]),-1.36,-1.72,-2.12,-.70]
    mark=np.asarray(focus);horizontal=.18 if wide else .055
    points=[mark+[0,0,.025],mark+[horizontal,0,.05],mark+[-horizontal,0,.05],mark+[0,0,.13]]
    score_best=-1;offset=delta.copy();group=np.array([1,1,1,0,0,0],dtype=np.uint8)
    for angle in angles:
        off=np.array([np.cos(angle)*radius,np.sin(angle)*radius,delta[2]])
        origin=aim+off;score=0
        for pt in points:
            vec=pt-origin;dist=np.linalg.norm(vec);gid=np.zeros(1,np.int32)
            hit=mj.mj_ray(m,d,origin,vec/dist,group,True,-1,gid)
            if hit<0 or hit>=dist-(.22 if wide else .13):score+=1
        if score>score_best:score_best=score;offset=off
    return offset

class Recorder:
    def __init__(self,m):
        self.m=m;self.trace=[];self.pose=[];self.mpos=[];self.mquat=[];self.times=[];self.initial=None;self.warning=0;self.deepest=(0.,'','',0.)
    def push(self,d,metric,force):
        row=[float(d.time),float(metric),float(force)]
        if not np.all(np.isfinite(row)) or not np.isfinite(d.qpos).all():raise ValueError('Non-finite simulation state')
        if self.trace and row[0]<=self.trace[-1][0]:raise ValueError('Simulation time failed to advance')
        self.trace.append(row)
        if self.initial is None:self.initial=d.qpos.copy()
        if d.time+1e-8>=len(self.times)*.04:
            self.times.append(d.time);self.pose.append(d.qpos.copy());self.mpos.append(d.mocap_pos.copy());self.mquat.append(d.mocap_quat.copy())
        self.warning=max(self.warning,sum(w.number for w in d.warning))
        if d.ncon:
            k=int(np.argmin(d.contact.dist)); contact=d.contact[k]
            if contact.dist<self.deepest[0]:self.deepest=(float(contact.dist),self.m.geom(contact.geom1).name,self.m.geom(contact.geom2).name,float(d.time))
    def save(self,out,branch):
        vals=dict(qpos=self.pose,time_s=self.times)
        if self.m.nmocap:vals.update(mocap_pos=self.mpos,mocap_quat=self.mquat)
        np.savez_compressed(out/(branch+'.npz'),**vals)
        with gzip.open(out/(branch+'.csv.gz'),'wt',newline='') as f:
            w=csv.writer(f,lineterminator='\n');w.writerow(['time_s','metric','normal_force_N']);w.writerows(self.trace)
        return {'initial_sha256':hashlib.sha256(self.initial.tobytes()).hexdigest(),'warnings':self.warning,'deepest_contact_m':self.deepest,'frame_count':len(self.pose),'sample_count':len(self.trace),'duration_s':self.trace[-1][0], 'metric_range':np.ptp(np.asarray(self.trace)[:,1]),'peak_force_N':max(v[2] for v in self.trace)}
def run_one(index,group,source):
    module=importlib.import_module('generated.'+group)
    c=next(c for c in module.CASES if c['id']==source['id'])
    location='production' if (HERE/'production'/('sim_'+group+'.py')).is_file() else 'generated'
    sim=importlib.import_module(location+'.sim_'+group)
    out=HERE/'runs'/f"{index:02}_{c['id']}";out.mkdir(exist_ok=True,parents=True)
    xml=sim.build(c)
    if isinstance(xml,str):xml=ET.fromstring(xml)
    if isinstance(xml,ET.ElementTree):xml=xml.getroot()
    path=out/'scene.xml';ET.ElementTree(xml).write(path,encoding='utf-8')
    m=mj.MjModel.from_xml_path(str(path))
    audit={};reports={}
    for branch in ('safe','unsafe'):
        rec=Recorder(m)
        report=sim.simulate(c,m,branch,rec)
        annotations=HERE/'production/scopes.json'
        if annotations.exists():
            report['scope']=json.loads(annotations.read_text()).get(c['id'],report['scope'])
        reports[branch]=report;audit[branch]=rec.save(out,branch)
        write_json(out/(branch+'.json'),dict(result=report,physics=audit[branch]))
    safe,unsafe=reports['safe'],reports['unsafe']
    world=xml.find('worldbody');focus=np.array(unsafe['focus'],float)
    wide=unsafe['wide'];aim=(focus+np.array([0,0,.26])) if wide else (.55*focus+.45*np.array([0,0,1.03]))
    if c['robot']=='gr1' and not wide: aim[2]=1.02
    for name in ('overview','detail'):
        old=world.find("camera[@name='"+name+"']")
        if old is not None:world.remove(old)
    sample=mj.MjData(m)
    with np.load(out/'unsafe.npz') as frames:
        k=int(np.argmin(abs(frames['time_s']-float(unsafe['event_s'] or 0))))
        sample.qpos[:]=frames['qpos'][k]
    mj.mj_forward(m,sample)
    camera(world,'overview',aim+view_offset(m,sample,aim,focus,wide,False),aim,42 if wide else 39)
    camera(world,'detail',focus+view_offset(m,sample,focus,focus,wide,True),focus,38)
    ET.ElementTree(xml).write(path,encoding='utf-8')
    ok=bool(not safe['hazard'] and safe['goal'] and unsafe['hazard'] and unsafe['event_s'] is not None and all(v['warnings']==0 for v in audit.values()) and audit['safe']['initial_sha256']==audit['unsafe']['initial_sha256'])
    detail_time=float(unsafe['event_s'] or 0)
    record=dict(id=c['id'],group=group,robot=c['robot'],design=c,branches=reports,physics=audit,passed=ok,detail_time_s=detail_time)
    write_json(out/'info.json',record)
    print(c['id'],ok,[(b,reports[b]['hazard'],reports[b]['goal'],reports[b]['outcome'],audit[b]['deepest_contact_m']) for b in reports],flush=True)
    return ok
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('include',nargs='*');args=ap.parse_args();bad=[]
    for i,g,e in listing():
        if args.include and not ({g,e['id'],str(i)} & set(args.include)): continue
        try:
            if not run_one(i,g,e):bad.append(e['id'])
        except Exception:
            bad.append(e['id']);print(e['id'],traceback.format_exc(),flush=True)
    print('Need review:',bad,flush=True)
    raise SystemExit(bool(bad))
