"""Export the original Genie Sim UV meshes, material maps and articulated oven pivot."""
import json
from pathlib import Path
import sys
import numpy as np
from pxr import Usd,UsdGeom,UsdShade,Gf
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'generated'))
from genie_kitchen import DESIGN
ROOT=D.parents[4]/'.runtime/genie-assets'
sources={k:v for k,v in DESIGN.items() if k!='setup'}
sources['table']='background/common/table/benchmark_table_006'
sources['plate']='objects/benchmark/plate/benchmark_plate_000'
sources['knife']='objects/open_world_doc_v1/knife'
sources.update(toaster='objects/iros/toaster/benchmark_toaster_000',stockpot='objects/benchmark/pot/benchmark_pot_000',board='objects/benchmark/cutting_board/benchmark_cutting_board_000',plant='background/common/plant/benchmark_plant_001')
sources['room']='background/kitchen/kitchen_1'
dest=D/'geometry'
dest.mkdir(exist_ok=True)
allmeshes={}
for key,folder in sources.items():
    stage=Usd.Stage.Open(str(ROOT/folder/('background.usda' if key=='room' else 'Aligned.usda')))
    cache=UsdGeom.XformCache()
    meshes=[]
    for p in stage.Traverse():
        if p.GetName()=='RevoluteJoint' and key=='oven':
            ref=stage.GetPrimAtPath(p.GetRelationship('physics:body0').GetTargets()[0])
            pivot=cache.GetLocalToWorldTransform(ref).Transform(Gf.Vec3d(*p.GetAttribute('physics:localPos0').Get()))
            hinge=list(pivot)
        if not p.IsA(UsdGeom.Mesh) or 'collider' in p.GetName().lower():continue
        if key=='room' and '/World/background/' not in str(p.GetPath()):continue
        m=UsdGeom.Mesh(p); coords=np.array(m.GetPointsAttr().Get())
        transform=np.array(cache.GetLocalToWorldTransform(p))
        verts=(np.c_[coords,np.ones(len(coords))]@transform)[:,:3].astype('f4')
        faces=np.array(m.GetFaceVertexIndicesAttr().Get())
        counts=np.array(m.GetFaceVertexCountsAttr().Get()).astype(int)
        offsets=np.cumsum(counts)-counts
        tri=np.concatenate([np.stack([offsets[counts>n],offsets[counts>n]+n-1,offsets[counts>n]+n],axis=1) for n in range(2,max(counts))])
        uvvar=UsdGeom.PrimvarsAPI(p).GetPrimvar('st')
        uv=np.array(uvvar.ComputeFlattened()) if uvvar and uvvar.HasValue() else None
        if uv is not None:
            if uvvar.GetInterpolation() in ['vertex','varying']:uv=uv[faces]
            unique,ind=np.unique(np.column_stack([faces,uv]),axis=0,return_inverse=True)
            vertices=verts[unique[:,0].astype(int)];texcoords=unique[:,1:].astype('f4')
            triangles=ind.ravel()[tri].astype('i4')
        else:
            vertices=verts;texcoords=np.zeros((len(verts),2),'f4');triangles=faces[tri].astype('i4')
        name=key+'_'+('_'.join(str(p.GetPath()).split('/')[3:]) if key=='room' else '_'.join(str(p.GetPath()).split('/')[3:]) if key in ('stockpot','toaster','plant','board') else p.GetName());ms=dest/(name+'.msh');npz=dest/(name+'.npz')
        with ms.open('wb') as f:
            # MuJoCo binary mesh textures use an upper-left image origin; keep USD UVs for Blender.
            mj_uv=texcoords.copy()
            mj_uv[:,1]=1-mj_uv[:,1]
            for arr in (np.array([len(vertices),0,len(texcoords),len(triangles)],'i4'),vertices,mj_uv,triangles):arr.tofile(f)
        np.savez_compressed(npz,v=vertices,uv=texcoords,f=triangles)
        mat=UsdShade.MaterialBindingAPI(p).ComputeBoundMaterial()[0];maps={};rgb=[.66,.67,.67]
        if mat:
            for sh in Usd.PrimRange(mat.GetPrim()):
                if not sh.IsA(UsdShade.Shader):continue
                for a in sh.GetAttributes():
                    field=a.GetName().split(':')[-1];value=a.Get()
                    if field in ('diffuse_texture','normalmap_texture','reflectionroughness_texture','metallic_texture') and value and value.path:
                        ap=Path(value.resolvedPath) if value.resolvedPath else ROOT/folder/value.path
                        if not ap.exists():raise FileNotFoundError(ap)
                        maps[field]=str(ap)
                    if field in ('diffuseColor','diffuse_color_constant') and value is not None: rgb=list(value)[:3]
        meshes.append(dict(name=name,maps=maps,base=rgb,lo=vertices.min(0).tolist(),hi=vertices.max(0).tolist()))
    allmeshes[key]=dict(source=folder,meshes=meshes)
allmeshes['oven']['hinge']=hinge
(D/'assets.json').write_text(json.dumps(allmeshes,indent=2))
