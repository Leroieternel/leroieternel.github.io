"""Make and check the task's Genie Sim fixture layout. The two preview poses are asset tests."""
from pathlib import Path
import json, math, xml.etree.ElementTree as ET
import numpy as np
import mujoco as mj
from PIL import Image
D=Path(__file__).resolve().parent
R=D.parents[4]; OLD=D.parents[1]/'runs/01_alfred_435'
SRC=json.loads((D/'assets.json').read_text())
scene=ET.parse(OLD/'scene.xml').getroot()
world=scene.find('worldbody');assets=scene.find('asset')
# All task dressing is provided by the selected real library geometry.
for obj in list(world):
    if obj.get('name','') in ['kitchen_microwave_root','kitchen_refrigerator_root','prep_counter_root','knife_storage_root']:world.remove(obj)
def vec(v):return ' '.join(f'{a:.9f}' for a in v)
def body(name,pos,parent=world,angle=0):return ET.SubElement(parent,'body',name=name,pos=vec(pos),euler=vec([0,0,angle]))
def collision(parent,name,kind,pos,size):
    return ET.SubElement(parent,'geom',name=name,type=kind,pos=vec(pos),size=vec(size),group='3',contype='1',conaffinity='2',rgba='0 0 0 0')
def add(parent,key,scale=1,subset=None,shift=(0,0,0),yaw=0):
    scale=np.broadcast_to(scale,3)
    for el in SRC[key]['meshes']:
        name=el['name']
        if subset is not None and name not in subset:continue
        mesh='gs_'+name
        if assets.find(f"mesh[@name='{mesh}']") is None:
            ET.SubElement(assets,'mesh',name=mesh,file=str(D/'geometry'/(name+'.msh')),scale=vec(scale),inertia='shell',maxhullvert='64')
            maps=el['maps'];material='mat_'+mesh
            attr=dict(name=material,rgba=vec([*el['base'],1]),specular='.28',shininess='.36')
            if 'diffuse_texture' in maps:
                source=Path(maps['diffuse_texture']); target=D/'geometry'/(name+'_albedo.png')
                if not target.exists():
                    im=Image.open(source).convert('RGB');im.thumbnail((2048,2048));im.save(target)
                ET.SubElement(assets,'texture',type='2d',name='tex_'+mesh,file=str(target))
                attr.update(texture='tex_'+mesh,rgba='1 1 1 1')
            ET.SubElement(assets,'material',**attr)
        ET.SubElement(parent,'geom',name=parent.get('name')+'__'+name,type='mesh',mesh=mesh,material='mat_'+mesh,group='1',contype='0',conaffinity='0',mass='0',pos=vec(shift),euler=vec([0,0,yaw]))
# Preserve robot and free-joint payloads. Use the native apple hull for contact.
for key,item,sc,z in [('apple','apple',.88,0),('cup_one','cup_one',.96,-.0165),('cup_two','cup_two',1.,0),('knife','blunt_knife',.73,-.003)]:
    obj=world.find(f"body[@name='item_{item}']")
    for geo in list(obj.findall('geom')):
        if geo.get('name')=='payload_'+item:
            geo.set('group','3')
            if key=='apple':
                geo.attrib.pop('size');geo.set('type','mesh');geo.set('mesh','gs_apple_visual');geo.set('mass','.181')
        elif key=='apple' or geo.get('contype','0')=='0':obj.remove(geo)
        else:geo.set('group','3')
    add(obj,key,sc,shift=[0,0,z],yaw=-math.pi/2 if key=='knife' else 0)
# A scaled native countertop and shelf give clear independent work stations.
# Reserve the sink counter for washing. Both loading surfaces have solid, uninterrupted tops.
wash=body('wash_counter',[2.57,.71,.53],angle=-math.pi/2);add(wash,'counter')
for x,label in [(-1.41,'prep'),(.47,'oven')]:
    b=body(label+'_counter',[x,.55,.405],angle=-math.pi/2);add(b,'table',[1.0,.64,.405/.43096])
    collision(b,label+'_worktop','box',[0,0,.389],[.315,.443,.016])
shelf=body('storage',[-.47,.56,.574]);add(shelf,'shelf',[.44,.7,.638]);collision(shelf,'storage_board','box',[0,0,.230],[.42,.202,.006])
fridge=body('fridge',[1.46,.63,.90],angle=-math.pi/2);add(fridge,'fridge')
oven=body('genie_oven',[.47,.54,.951],angle=-math.pi/2);door=body('genie_oven_door',[0,0,0],oven)
ET.SubElement(door,'joint',name='genie_oven_hinge',type='hinge',pos=vec(SRC['oven']['hinge']),axis='0 0 1',range='-1.57079633 0',damping='.6',armature='.02')
ET.SubElement(door,'inertial',pos='.155 -.04 0',mass='.63',diaginertia='.007 .006 .009')
add(oven,'oven',subset={'oven_body','oven_part_02','oven_part_03'})
add(door,'oven',subset={'oven_part_00','oven_part_01'})
collision(door,'door_panel','box',[.157,-.04,.003],[.015,.178,.128])
collision(oven,'inside_floor','box',[-.025,-.039,-.105],[.16,.162,.009])
collision(oven,'inside_roof','box',[-.025,-.039,.129],[.16,.162,.009])
collision(oven,'inside_back','box',[-.186,-.041,.008],[.012,.166,.112])
for name,y in [('left',-.202),('right',.128)]:collision(oven,'inside_'+name,'box',[-.023,y,.008],[.17,.006,.112])
# A separate real Genie Sim plate is seated on the measured interior floor.
plate=body('genie_plate',[.017,-.032,-.0863],oven)
add(plate,'plate')
collision(plate,'tray_support','cylinder',[0,0,-.0061],[.062,.0031])
# Enlarge only the room envelope to fit the mobile robot; furniture keeps its native dimensions.
room_shapes={x['name'] for x in SRC['room']['meshes']}
shell={n for n in room_shapes if n.startswith('room_kitchen_')}
lights={n for n in room_shapes if 'ceiling_light' in n}
room_shell=body('gs_room_shell',[0,-.30,0],angle=math.pi/2)
add(room_shell,'room',scale=[2.55,2.55,1.],subset=shell|lights)
room_furniture=body('gs_room_cabinets',[-1.92,1.79,0],angle=math.pi/2)
add(room_furniture,'room',subset=room_shapes-shell-lights)
# Furnish the work surfaces. Heights come from the original counter's mesh.
def counter_height(x,y):
    # Convert from the room cabinet's +90 degree placement back to the native coordinates.
    pt=np.array([y-1.79,-(x+1.92)])
    heights=[]
    for record in SRC['room']['meshes']:
        if 'cabinet_01' not in record['name'] and 'range_hood' not in record['name']:continue
        data=np.load(D/'geometry'/(record['name']+'.npz'))
        tri=data['v'][data['f']]
        a=tri[:,0]; b=tri[:,1]-a; c=tri[:,2]-a
        den=b[:,0]*c[:,1]-c[:,0]*b[:,1];valid=np.abs(den)>1e-8;den[~valid]=1
        off=pt-a[:,:2];u=(off[:,0]*c[:,1]-off[:,1]*c[:,0])/den;v=(b[:,0]*off[:,1]-b[:,1]*off[:,0])/den
        z=a[:,2]+u*b[:,2]+v*c[:,2];hit=valid&(u>=0)&(v>=0)&(u+v<=1)&(z>.78)&(z<1.08)
        if hit.any():heights.append(z[hit].max())
    return float(max(heights))
def on_surface(key,label,x,y,z,scale=1.,yaw=0.):
    low=min(v['lo'][2] for v in SRC[key]['meshes'])
    holder=body(label,[x,y,z-low*scale],angle=yaw);add(holder,key,scale)
for key,x,y,size,angle in [('stockpot',-.86,1.96,1.,0),('toaster',-2.95,2.81,.90,1.57),('plant',-2.73,2.84,.64,.3)]:
    on_surface(key,'back_'+key,x,y,counter_height(x,y),size,angle)
on_surface('board','prep_board',-1.50,.66,.811,.59,0)
on_surface('plate','spare_plate',-.45,.54,.574-.159*.638,1.,0)
# Anchor storage cabinets against the native back and side walls.
for label,pos,sz in [('rear',[0,3.19,1.47],[3.44,.025,1.47]),('west',[-3.51,-.30,1.47],[.025,3.44,1.47]),('east',[3.41,-.30,1.47],[.025,3.44,1.47])]:
    collision(world,'wall_'+label,'box',pos,sz)
floor=world.find("geom[@name='floor']")
floor.set('group','3')
vis=scene.find('visual')
ET.SubElement(vis,'headlight',ambient='.21 .22 .24',diffuse='.22 .22 .23',specular='.18 .18 .18')
for pos,direction,power in [('-2 -2 4','.5 .7 -.9','.46 .43 .39'),('2 -1 2.5','-.6 .7 -.8','.21 .24 .27')]:ET.SubElement(world,'light',pos=pos,dir=direction,diffuse=power,castshadow='false')
def camera(name,eye,target,fovy):
    y=np.asarray(target)-eye;x=np.cross(y,[0,0,1]);x/=np.linalg.norm(x);u=np.cross(x,y);u/=np.linalg.norm(u)
    ET.SubElement(world,'camera',name=name,pos=vec(eye),xyaxes=vec([*x,*u]),fovy=str(fovy))
camera('oven_close',np.array([.635,-.46,1.16]),[.43,.50,.944],25)
camera('peel_close',np.array([.53,.12,.987]),[.438,.519,.90],18)
camera('task_room',np.array([1.72,-3.12,1.82]),[-.05,.83,1.02],45)
ET.indent(scene)
out=D/'kitchen.xml';ET.ElementTree(scene).write(out,encoding='utf-8')
m=mj.MjModel.from_xml_path(str(out));d=mj.MjData(m);orig=mj.MjModel.from_xml_path(str(OLD/'scene.xml'));q0=np.load(OLD/'safe.npz')['qpos'][0]
for j in range(orig.njnt):
    nm=orig.joint(j).name;idx=mj.mj_name2id(m,mj.mjtObj.mjOBJ_JOINT,nm) if nm else -1
    if idx>=0:
        n={0:7,1:4,2:1,3:1}[int(orig.jnt_type[j])];d.qpos[m.jnt_qposadr[idx]:m.jnt_qposadr[idx]+n]=q0[orig.jnt_qposadr[j]:orig.jnt_qposadr[j]+n]
ren=mj.Renderer(m,640,1000); opt=mj.MjvOption();opt.geomgroup[:]=[1,1,1,0,0,0];opt.sitegroup[:]=0
def shot(name,cam):
    mj.mj_forward(m,d);ren.update_scene(d,camera=cam,scene_option=opt)
    Image.fromarray(ren.render()).save(D/(name+'.jpg'),quality=95,subsampling=0)
    transforms={}
    for b in scene.iter('body'):
        if not b.get('name') or not any((g.get('mesh') or '').startswith('gs_') for g in b.findall('geom')):continue
        phys=d.body(b.get('name')); transforms[b.get('name')]=[phys.xpos.tolist(),phys.xquat.tolist()]
    (D/(name+'-poses.json')).write_text(json.dumps(transforms))
shot('room','task_room');shot('closed','oven_close')
d.qpos[m.joint('genie_oven_hinge').qposadr[0]]=math.radians(-84)
mj.mj_forward(m,d);idx=m.joint('item_apple_free').qposadr[0];vi=m.joint('item_apple_free').dofadr[0]
d.qpos[idx:idx+3]=d.geom('tray_support').xpos+[0,0,.07];d.qpos[idx+3:idx+7]=[1,0,0,0];dq=d.qpos.copy()
vq=np.ones(m.nq,bool);vq[idx:idx+7]=False;vv=np.ones(m.nv,bool);vv[vi:vi+6]=False
pair={m.geom('tray_support').id,m.geom('payload_apple').id};forces=[]
for n in range(300):
    d.qpos[vq]=dq[vq];d.qvel[vv]=0;mj.mj_step(m,d);normal=0.
    for j in range(d.ncon):
        c=d.contact[j]
        if {c.geom1,c.geom2}==pair:
            f=np.zeros(6);mj.mj_contactForce(m,d,j,f);normal+=f[0]
    forces.append(normal)
assert min(forces[-30:])>0 and max(abs(d.qvel[vi:vi+3]))<.002
shot('open_apple','oven_close');shot('peel','peel_close');ren.close()
record=dict(revision='12f41e388a953cc2aeb0fe5b8eb516750c8321d9',test='free apple settles on a stationary Genie Sim plate in the open microwave',apple_mass_kg=float(m.body('item_apple').mass[0]),mean_final_normal_force_N=float(np.mean(forces[-30:])),support_samples=30,hinge_deg=-84,sources={k:v['source'] for k,v in SRC.items()},robot='Original Omron / Panda from the evaluated task',apple_pos=d.body('item_apple').xpos.tolist(),apple_quat=d.body('item_apple').xquat.tolist(),note='No old trajectories retimed for this revised geometry.')
(D/'check.json').write_text(json.dumps(record,indent=2))
print(record['mean_final_normal_force_N'],record['apple_pos'])
