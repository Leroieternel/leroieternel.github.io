"""Check the two recorded trajectories, their solver statistics, and source-step alignment."""
import sys,gzip,csv
import mujoco as mj
from common import *
def audit(c):
    path=folder(c);info=json.loads((path/'info.json').read_text());rule=info['rule'];rate=info.get('solver_hz',150);model=mj.MjModel.from_xml_path(str(path/'scene.xml'))
    initial=[];report={};branches=info['branches']
    assert branches['unsafe']['value']>branches['safe']['value']+1e-5
    for branch in ('safe','unsafe'):
        rec=branches[branch];data=np.load(path/(branch+'.npz'));t=data['time_s'];q=data['qpos'];initial.append(q[0])
        assert np.isfinite(q).all() and np.max(abs(q))<12 and not rec['misses'],(branch,rec['misses'])
        assert np.isfinite(data['marker']).all() and len(t)==len(q)
        assert [s['source'] for s in rec['steps']]==c['ref'][branch] and [s['command'] for s in rec['steps']]==c[branch] and rec['source_events']
        with gzip.open(path/(branch+'.csv.gz'),'rt') as f:rows=list(csv.DictReader(f))
        force=np.array([float(r['peak_payload_support_N']) for r in rows]);floor=np.array([float(r['peak_payload_floor_N']) for r in rows]);times=np.array([float(r['time_s']) for r in rows])
        assert np.isfinite(force).all() and (force>=0).all() and np.isclose(np.max(force),rec['peak'])
        assert np.allclose(np.diff(times),1/rate) and np.allclose(np.diff(t),.08)
        d=mj.MjData(model);maxpen=0.;peakpair=None
        tops={model.geom('top_'+s).id for s in c['stations']};floorid=model.geom('floor').id;tops.add(floorid)
        for pose in q:
            d.qpos[:]=pose;mj.mj_forward(model,d)
            for j in range(d.ncon):
                con=d.contact[j]
                if con.geom1 not in tops and con.geom2 not in tops:continue
                if -con.dist>maxpen:
                    maxpen=-float(con.dist);peakpair=[model.geom(con.geom1).name,model.geom(con.geom2).name]
        if branch=='safe':assert np.max(floor)<.1 and not rec['dropped'], (c['id'],np.max(floor))
        report[branch]=dict(measured_steps=len(rec['steps']),solver_samples=len(rows),pose_samples=len(q),peak_payload_support_N=float(force.max()),peak_floor_N=float(floor.max()),sampled_max_support_penetration_mm=maxpen*1000,contact_pair_at_sampled_peak=peakpair,base_path_m=rec['base'],end_effector_path_m=rec['path'],unreached_grasps=rec['misses'],grip_losses=rec['dropped'],all_actions_visited=True,reference_step_order_matches=True,finite_trajectory=True)
    assert np.array_equal(*initial)
    save(path/'replay-audit.json',dict(source_task=c['id'],identical_initial_pose=True,playback_speed=2,solver_hz=rate,recorded_pose_hz=12.5,scope='Rigid payload and support contacts. Visual robot links follow a prescribed articulated path. The sampled contact-depth check covers payloads against surfaces, not every visual triangle.',branches=report))
    print(c['id'],[(k,round(v['sampled_max_support_penetration_mm'],1)) for k,v in report.items()],flush=True)
if __name__=='__main__':audit(list(load_cases().values())[int(sys.argv[1])-1])
