"""Measure navigated paths and workstation separation directly from the recorded model."""
import math,sys,itertools
import mujoco as mj
from common import *

def polygon(center,yaw,hw,hd):
    return np.array([[-hw,-hd],[hw,-hd],[hw,hd],[-hw,hd]])@pl.rotation(yaw).T+center
def separating(a,b):
    gap=[]
    for p in (a,b):
        for n in (p[1]-p[0],p[2]-p[1]):
            n=n/np.linalg.norm(n);x=a@n;y=b@n
            gap.append(max(x.min()-y.max(),y.min()-x.max()))
    return max(gap)
def check(c):
    run=folder(c);info=json.loads((run/'info.json').read_text());m=mj.MjModel.from_xml_path(str(run/'scene.xml'));d=mj.MjData(m);loc=layout(c);stat=pl.room(c)
    surfaces={s:polygon(center,yaw,loc[s][3]/2,loc[s][4]/2) for s,(center,yaw,dock) in stat.items()}
    separation=min(separating(surfaces[a],surfaces[b]) for a,b in itertools.combinations(stat,2))
    def relative(a,b):
        return abs(math.degrees(pl.angle_diff(a-b)))
    report=dict(**info['placement'],smallest_station_separating_axis_gap_m=separation,branches={})
    for b in ('unsafe','safe'):
        ar=np.load(run/(b+'.npz'));t=ar['time_s'];poses=ar['qpos'];br=info['branches'][b]
        if pl.mobile(c):
            root='body' if c['robot']=='spot' else 'base'
            # Omron's three planar joints act on the base_footprint body, below its fixed world root.
            if c['robot']=='omron':base=m.jnt_bodyid[m.joint('joint_mobile_yaw').id]
            else:base=m.body(root).id
            xy=[];yaw=[]
            for pose in poses:
                d.qpos[:]=pose;mj.mj_kinematics(m,d);xy.append(d.xpos[base,:2].copy())
                rot=d.xmat[base].reshape(3,3);yaw.append(math.atan2(rot[1,0],rot[0,0]))
            xy=np.array(xy);yaw=np.unwrap(yaw);travel=np.linalg.norm(np.diff(xy,axis=0),axis=1).sum();angle=float(np.degrees(abs(np.diff(yaw)).sum()))
            close=10.;clearance={}
            for s,(center,ang,dock) in stat.items():
                points=(xy-center)@pl.rotation(ang);sz=np.array(loc[s][3:5])/2
                dist=np.linalg.norm(np.maximum(abs(points)-sz,0.),axis=1);clearance[s]=float(dist.min());close=min(close,dist.min())
            report['branches'][b]=dict(base_travel_m=float(travel),accumulated_heading_change_deg=angle,maximum_station_heading_difference_deg=max(relative(x[1],y[1]) for x,y in itertools.combinations(stat.values(),2)),minimum_root_to_station_footprint_m=float(close),minimum_by_station_m=clearance)
            np.savez_compressed(run/(b+'-path.npz'),xy=xy,heading_rad=yaw,time_s=t)
        else:
            ids,_=lib.arm(m,c['robot']);shoulder=poses[:,m.jnt_qposadr[ids[0]]]
            report['branches'][b]=dict(base_travel_m=0,arm_joint1_range_deg=float(np.degrees(np.ptp(shoulder))))
    report['measurement_scope']='Station footprints are oriented work surfaces. The mobile path is the sampled world-space base origin. The recorded paths are prescribed kinematics. The reported clearance is from that origin to a surface footprint.'
    save(run/'layout.json',report)
    return c['id'],round(separation,3),[(b,round(x['base_travel_m'],2),round(x.get('minimum_root_to_station_footprint_m',0),3)) for b,x in report['branches'].items()]
if __name__=='__main__':
    for c in load_cases().values():print(check(c),flush=True)
