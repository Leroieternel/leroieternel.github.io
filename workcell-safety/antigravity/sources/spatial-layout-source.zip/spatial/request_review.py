"""Send aggregate navigation results back to Antigravity for review, without local file access."""
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'hard1044'))
import author
author.HERE=D
rows=[]
for f in sorted((D/'runs').glob('*/info.json')):
    d=json.loads(f.read_text());c=d['design'];coords=d['placement']['stations']
    rows.append(dict(id=c['id'],robot=c['robot'],stations={k:[*[round(v,3) for v in z['center_m']],round(z['heading_deg'])] for k,z in coords.items()},branches={b:[round(z['base'],2),round(z['turn_deg']),len(z['steps']),len(z['misses'])] for b,z in d['branches'].items()}))
prompt="""No tool use. Independently review the following 30 recomputed paired MuJoCo room routes for an English robotics website. Return only one literal Python dictionary assignment PLANNING_REVIEW, keyed by all 30 task ids, each value a concise English sentence summarizing what the robot needs to do spatially, citing actual station names or clearly equivalent common nouns. Source columns for each branch: base metres, cumulative heading change degrees, source action count, missed grasps. Distinguish accumulated turn from angle between two stations. Fixed robots pivot at shoulder and arm, do not drive. Do not make safety or collision certifications. Use no numbers in the sentence. The site displays measurements taken directly from the final trajectories in a separate table. Describe only the layout and the robot movement. Do not add room props or claim room separation by walls.\n"""+json.dumps(rows)
(D/'requests/route_review.txt').write_text(prompt)
author.request('route_review')
