"""Encode the Blender frames, stamp actual step/clock and verify decoded duration and image dimensions."""
import csv,gzip,sys,subprocess,json,hashlib,bisect
from pathlib import Path
import numpy as np,imageio_ffmpeg as ff
from PIL import Image,ImageDraw,ImageFont
from common import D,load_cases,folder,save
from evidence import metric,friendly
def font(n,b=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if b else '')+'.ttf',n)
BOLD=font(24,True);SM=font(17);SB=font(17,True);BIG=font(26,True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(c):
    run=folder(c);info=json.loads((run/'info.json').read_text());out=D/'media'/c['id'];frames=D/'frames'/c['id'];proof={};label,unit,_=metric(c,info['rule']);end_pair=max(z['elapsed'] for z in info['branches'].values())
    fps=25;expected=round(end_pair*.5*fps)+1
    for b in ('safe','unsafe'):
        ar=np.load(run/(b+'.npz'));times=ar['time_s'];assert np.allclose(np.diff(times),.08)
        z=info['branches'][b];starts=[x['t'] for x in z['steps']];n=len(times)
        assert (frames/(b+f'_{n:04d}.jpg')).is_file(),(b,n)
        with gzip.open(run/(b+'.csv.gz'),'rt') as f:trace=list(csv.DictReader(f))
        temp=out/(b+'.part.mp4')
        cmd=[ff.get_ffmpeg_exe(),'-nostdin','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1600x900','-r','25','-i','-','-an','-c:v','libx264','-threads','3','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(temp)]
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);last=None
        for k in range(expected):
            if k>=n and last is not None:proc.stdin.write(last);continue
            i=min(k,n-1);simt=min(k*.08,z['elapsed']);step=max(0,bisect.bisect_right(starts,simt)-1)
            with Image.open(frames/(b+f'_{i+1:04d}.jpg')) as frame:im=frame.convert('RGB')
            draw=ImageDraw.Draw(im,'RGBA');accent=(159,233,192) if b=='safe' else (255,179,142);row=trace[min(len(trace)-1,round(simt*info.get('solver_hz',150)))]
            draw.rounded_rectangle((22,21,384,65),7,fill=(19,30,30,228));draw.text((36,31),b.upper()+' PLAN',font=SB,fill=accent);draw.text((187,30),f'{simt:05.2f} s    ·    2× replay',font=SM,fill='white')
            draw.rounded_rectangle((22,802,1578,880),9,fill=(19,30,30,228))
            draw.text((39,810),c['title'],font=SM,fill=(217,232,221));title=f"{step+1:02d} / {len(starts):02d}     "+friendly(z['steps'][step]['source']) if k<n else 'Plan ended · final state'
            draw.text((38,839),title,font=BOLD,fill='white')
            val=float(row['indicator']);valstr=('Yes' if val>.5 else 'No') if unit=='flag' else f'{val:.2f} {unit}'
            right=label+'    '+valstr;draw.text((1554-draw.textlength(right,font=SB),812),right,font=SB,fill=accent)
            force=f"Support contact    {float(row['peak_payload_support_N']):.2f} N";draw.text((1554-draw.textlength(force,font=SM),843),force,font=SM,fill=(205,224,224))
            draw.rectangle((30,877,30+1539*(i+1)/n,880),fill=accent)
            payload=im.tobytes();proc.stdin.write(payload)
            if k>=n:last=payload
        proc.stdin.close()
        if proc.wait()!=0:raise RuntimeError('Encoder failed')
        count,_=ff.count_frames_and_secs(str(temp));assert count==expected,(count,expected)
        reader=ff.read_frames(str(temp));fmt=next(reader);assert fmt['size']==(1600,900) and fmt['fps']==25;next(reader);reader.close()
        dest=out/(b+'.mp4');temp.replace(dest)
        proof[b]=dict(frames=count,seconds=count/fps,simulation_seconds=z['elapsed'],size=fmt['size'],fps=25,physics_samples=n,mp4_sha256=sha(dest),trajectory_sha256=sha(run/(b+'.npz')))
    with Image.open(out/'safe_poster.jpg') as im:im.thumbnail((360,203));im.save(out/'thumb.jpg',quality=91)
    save(out/'video-verification.json',dict(**proof,scene_sha256=sha(run/'scene.xml'),appearance_sha256=sha(out/'appearance.json')))
    print(c['id'],expected,flush=True)
if __name__=='__main__':encode(list(load_cases().values())[int(sys.argv[1])-1])
