"""Attach the checked native Genie Sim kitchen assets in the new station-local frames."""
from copy import deepcopy
from pathlib import Path
import xml.etree.ElementTree as ET
D=Path(__file__).resolve().parent
GENIE=D.parent/'long_horizon/appliance435/genie'

def install(r):
    sample=ET.parse(GENIE/'kitchen.xml');w=r.find('worldbody')
    asset=r.find('asset');native=sample.find('asset')
    for tag in ('texture','material','mesh'):
        for obj in native.findall(tag):
            if obj.get('name','').startswith(('gs_','tex_gs_','mat_gs_')):
                name=obj.get('name')
                if any(token in name for token in ('oven_', 'table_visual','shelf_visual','apple_visual','cup_one','cup_two','knife_','plate_visual')):asset.append(deepcopy(obj))
    def graft(st,name,pos):
        mount=w.find(f"body[@name='placement_{st}']")
        ob=deepcopy(sample.find(f"worldbody/body[@name='{name}']"));ob.set('pos',pos);mount.append(ob);return ob
    for st,name,pos in [('prep_counter','prep_counter','0 0 .405'),('knife_storage','storage','0 0 .574'),('kitchen_microwave','oven_counter','0 0 .405')]:
        mount=w.find(f"body[@name='placement_{st}']");mount.remove(mount.find('body'))
        obj=graft(st,name,pos)
        coll=next(g for g in obj.findall('geom') if g.get('type')=='box')
        coll.set('name','top_'+st if st!='kitchen_microwave' else 'oven_bench_support')
    oven=graft('kitchen_microwave','genie_oven','0 0 .951')
    oven.find("geom[@name='inside_floor']").set('name','top_kitchen_microwave')
    j=oven.find('body/joint');j.set('name','hinge_kitchen_microwave');j.set('axis','0 0 -1');j.set('range','0 1.57')
    for item in ('apple','cup_one','cup_two','blunt_knife'):
        name='item_'+item;old=w.find(f"body[@name='{name}']");ob=deepcopy(sample.find(f"worldbody/body[@name='{name}']"));ob.set('pos',old.get('pos'));w.remove(old);w.append(ob)
    # Remove unrelated texture dependencies copied with shared mesh prefixes.
    meshes={g.get('mesh') for g in w.iter('geom')};mats={g.get('material') for g in w.iter('geom')}
    for obj in list(asset):
        if obj.tag=='mesh' and obj.get('name','').startswith('gs_') and obj.get('name') not in meshes:asset.remove(obj)
        if obj.tag=='material' and obj.get('name','').startswith('mat_gs_') and obj.get('name') not in mats:asset.remove(obj)
    textures={v.get('texture') for v in asset.findall('material')}
    for obj in list(asset):
        if obj.tag=='texture' and obj.get('name','').startswith('tex_gs_') and obj.get('name') not in textures:asset.remove(obj)
