"""Resolve Antigravity's room choices to repeatable station frames and clearance-tested routes."""
import ast,hashlib,json,math
from functools import lru_cache
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent
@lru_cache(None)
def designs():
    source=D/'generated/layouts.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==json.loads((D/'provenance/layouts.json').read_text())['sha256']
    value=next(n.value for n in ast.parse(source.read_text()).body if isinstance(n,ast.Assign))
    return ast.literal_eval(value)
def rotation(yaw):
    c,s=math.cos(yaw),math.sin(yaw)
    return np.array([[c,-s],[s,c]])
def variant(c):
    seed=int.from_bytes(hashlib.sha256(('despite-placement-v1:'+c['id']).encode()).digest()[:4],'big')
    return seed,np.random.default_rng(seed)
def mobile(c):return c['robot'] in ('omron','spot','gr1') and c['id']!='normbank_42114'
@lru_cache(None)
def frames(ident,robot,stations):
    label,angles,radii=designs()[ident];assert len(angles)==len(radii)==len(stations)
    seed,rng=variant({'id':ident})
    moving=mobile({'id':ident,'robot':robot})
    out={}
    for j,(st,angle,r) in enumerate(zip(stations,angles,radii)):
        bearing=math.radians(float(angle)+rng.uniform(-1.8,1.8))
        yaw=-bearing
        radius=float(r)+rng.uniform(-.05,.05) if moving else float(r)
        center=np.array([math.sin(bearing),math.cos(bearing)])*radius
        if not moving and robot=='baxter':center[0]+=.13
        if ident=='normbank_42114':
            center=np.array([.25+(-.153 if j==0 else .153),.23+(.04 if j==0 else -.03)])
            yaw=math.radians(14 if j==0 else -12)
        if moving and robot=='gr1':
            # The right hand approaches this chair from the operator's right.
            offset=np.array([.27,.382])
        else:offset=np.array([0.,.70 if robot=='spot' else .56])
        dock=center-rotation(yaw)@offset
        out[st]=(center,yaw,dock)
    return out
def room(c):return frames(c['id'],c['robot'],tuple(c['stations']))
def xy(c,s,dx,dy):return room(c)[s][0]+rotation(room(c)[s][1])@np.array([dx,dy])
def local(c,s,p):return rotation(-room(c)[s][1])@(p[:2]-room(c)[s][0])
def location(c,s,dx,dy,z):return np.r_[xy(c,s,dx,dy),z]
def layout_report(c,loc):
    label=designs()[c['id']][0]
    return dict(seed=variant(c)[0],layout=label,stations={s:dict(center_m=list(center),heading_deg=math.degrees(yaw),dock_m=list(dock),size_m=list(loc[s][3:5])) for s,(center,yaw,dock) in room(c).items()})
def angle_diff(y):return math.atan2(math.sin(y),math.cos(y))
