"""Test oriented native chassis bounding boxes against workstation columns at each recorded pose."""
import mujoco as mj, numpy as np
from common import *
from measure import polygon

def intervals_gap(coords,center,axes,half,station,yaw,sh):
    # Oriented rectangle separating-axis test in the ground plane, vectorized over all poses.
    v=station-center
    fixed=pl.rotation(yaw)
    axes=np.stack([axes[:,:,0],axes[:,:,1],np.broadcast_to(fixed[:,0],v.shape),np.broadcast_to(fixed[:,1],v.shape)],axis=1)
    ra=np.abs(np.einsum('nki,nij->nkj',axes,coords))@half
    rb=abs(axes@fixed)@sh
    return (abs(np.einsum('nki,ni->nk',axes,v))-ra-rb).max(1)
def check(c):
    if c['robot'] not in ('spot','omron'):return
    run=folder(c);info=json.loads((run/'layout.json').read_text());m=mj.MjModel.from_xml_path(str(run/'scene.xml'));d=mj.MjData(m);stat=pl.room(c)
    for b in ('safe','unsafe'):
        p=np.load(run/(b+'.npz'))['qpos'];rot=[];center=[]
        g=m.geom('pedestal_feet_col' if c['robot']=='omron' else 'spot_collision_2').id
        for pose in p:
            d.qpos[:]=pose;mj.mj_kinematics(m,d)
            if c['robot']=='omron':
                center.append(d.geom_xpos[g,:2].copy());rot.append(d.geom_xmat[g].reshape(3,3)[:2,:2].copy())
            else:
                root=m.body('body').id;center.append(d.xpos[root,:2].copy());rot.append(d.xmat[root].reshape(3,3)[:2,:2].copy())
        rot=np.array(rot);center=np.array(center);half=[.35,.25] if c['robot']=='omron' else [.455,.135]
        gap=10.
        for st,(p,y,_) in stat.items():
            val=intervals_gap(rot,center,rot,half,p,y,np.array(info['stations'][st]['size_m'])/2);gap=min(gap,float(val.min()))
        info['branches'][b]['minimum_chassis_separating_axis_gap_m']=gap
    info['chassis_scope']='Oriented planar chassis envelope against each tabletop footprint extruded to the floor at recorded poses; positive gap implies separation. Excludes the manipulating arm.'
    save(run/'layout.json',info);print(c['id'],min(br['minimum_chassis_separating_axis_gap_m'] for br in info['branches'].values()),flush=True)
if __name__=='__main__':
    for c in load_cases().values():check(c)
