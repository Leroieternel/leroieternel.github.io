"""Room design specifications for all 30 Genie Sim scenes.

Camera looks toward +Y with workstations arranged across X:
  - window_side = -1: bounced daylight enters from -X (left), raking toward +X
  - window_side =  1: bounced daylight enters from +X (right), raking toward -X

Schema per task_id:
  [
      floor_key,          # genie_floor_00..07 or genie_floor_tile_00..07
      wall_key,           # genie_wall_00..07 or genie_wall_tile_00..07
      hero_furniture,     # cabinet | chair | desk_chair | sideboard | refrigerator | table | nightstand | sofa
      second_furniture,   # cabinet | chair | desk_chair | sideboard | refrigerator | table | nightstand | sofa
      shelf_prop1,        # soap | medicine | cup | mug | water | book | folder | pen | mouse | picture_frame |
                          # laptop | photo_books | coffee_service | book2 | pen_cup | stapler | carton | bin
      shelf_prop2,        # same allowed shelf_prop keys (distinct from shelf_prop1)
      window_side,        # -1 or 1
      sun_elevation_deg,  # 30..60
      accent_rgb3,        # (r, g, b) muted architectural tone in [0.0, 1.0]
  ]
"""

ROOMS = {
    # Bright tiled residential kitchen: morning cross-light, celadon-sage ceramic accent
    "alfred_435": [
        "genie_floor_tile_00",
        "genie_wall_tile_00",
        "refrigerator",
        "cabinet",
        "mug",
        "cup",
        -1,
        48,
        (0.52, 0.59, 0.56),
    ],
    # Warm residential kitchen: low golden bounce off stone counter, warm biscuit limestone
    "alfred_2999": [
        "genie_floor_01",
        "genie_wall_01",
        "refrigerator",
        "sideboard",
        "coffee_service",
        "water",
        1,
        36,
        (0.66, 0.57, 0.48),
    ],
    # Clean home family kitchen: stove/sink/table layout, muted slate-mist cabinetry tone
    "bddl_829": [
        "genie_floor_tile_01",
        "genie_wall_00",
        "table",
        "cabinet",
        "soap",
        "mug",
        -1,
        44,
        (0.46, 0.53, 0.57),
    ],
    # Sunlit chopping-board kitchen: raking honey daylight across prep and cooling counters
    "alfred_1152": [
        "genie_floor_02",
        "genie_wall_tile_01",
        "refrigerator",
        "sideboard",
        "cup",
        "book",
        1,
        38,
        (0.68, 0.61, 0.47),
    ],
    # Tidy kitchen-dining hybrid: serving and packing tables beside closed fridge, oat putty
    "bddl_71": [
        "genie_floor_00",
        "genie_wall_02",
        "table",
        "refrigerator",
        "carton",
        "cup",
        -1,
        46,
        (0.58, 0.55, 0.49),
    ],
    # Warm wood dining room: late-afternoon pass-through light, muted terracotta sienna
    "virtualhome_320": [
        "genie_floor_03",
        "genie_wall_03",
        "table",
        "chair",
        "coffee_service",
        "picture_frame",
        1,
        34,
        (0.59, 0.44, 0.37),
    ],
    # Bright butcher-block residential kitchen: midday bounce, muted rosemary olive trim
    "alfred_1507": [
        "genie_floor_tile_02",
        "genie_wall_04",
        "cabinet",
        "sideboard",
        "bin",
        "mug",
        -1,
        52,
        (0.49, 0.56, 0.47),
    ],
    # Daylit bedroom adjoining tiled bathroom: soft ceramic washbasin zone, powder slate
    "bddl_580": [
        "genie_floor_tile_03",
        "genie_wall_tile_02",
        "nightstand",
        "cabinet",
        "soap",
        "medicine",
        1,
        45,
        (0.56, 0.61, 0.64),
    ],
    # Modern home kitchen: stone prep counter and wall oven, architectural charcoal basalt
    "bddl_761": [
        "genie_floor_04",
        "genie_wall_tile_03",
        "refrigerator",
        "cabinet",
        "water",
        "book2",
        -1,
        50,
        (0.42, 0.45, 0.48),
    ],
    # Clean galley kitchen: hinged utensil cabinet and stainless sink, eucalyptus grey
    "alfred_1245": [
        "genie_floor_tile_04",
        "genie_wall_tile_04",
        "cabinet",
        "refrigerator",
        "soap",
        "cup",
        1,
        47,
        (0.55, 0.60, 0.59),
    ],
    # Bright domestic tiled kitchen: crisp high-elevation bounce, chalky travertine tone
    "neiss_6342": [
        "genie_floor_tile_05",
        "genie_wall_tile_05",
        "cabinet",
        "table",
        "mug",
        "water",
        -1,
        54,
        (0.64, 0.62, 0.55),
    ],
    # Cafe prep kitchen: glazed backsplash, espresso bar and dining table, roasted umber
    "normbank_53453": [
        "genie_floor_05",
        "genie_wall_tile_06",
        "table",
        "refrigerator",
        "coffee_service",
        "mug",
        1,
        35,
        (0.44, 0.36, 0.32),
    ],
    # Domestic kitchen wash-up zone: scullery sink and soap counter, sea-glass slate
    "virtualhome_275": [
        "genie_floor_tile_06",
        "genie_wall_05",
        "cabinet",
        "sideboard",
        "soap",
        "water",
        -1,
        43,
        (0.48, 0.57, 0.61),
    ],
    # Concrete garage & storage room: utility timber worktable, weathered concrete pewter
    "bddl_403": [
        "genie_floor_06",
        "genie_wall_06",
        "table",
        "cabinet",
        "bin",
        "carton",
        1,
        39,
        (0.47, 0.48, 0.46),
    ],
    # Tiled entrance hall utility nook: washer/detergent alcove, muted lichen grey-green
    "virtualhome_291": [
        "genie_floor_tile_07",
        "genie_wall_07",
        "cabinet",
        "sideboard",
        "soap",
        "bin",
        -1,
        41,
        (0.57, 0.59, 0.54),
    ],
    # Outdoor flea market booth: high open-sky sun, display table, sun-washed canvas ochre
    "bddl_527": [
        "genie_floor_07",
        "genie_wall_01",
        "table",
        "cabinet",
        "carton",
        "picture_frame",
        1,
        58,
        (0.65, 0.53, 0.41),
    ],
    # Bright open-plan living room: sunny window onto sofa and cabinet wall, warm linen sand
    "bddl_812": [
        "genie_floor_01",
        "genie_wall_04",
        "sofa",
        "cabinet",
        "picture_frame",
        "book",
        -1,
        49,
        (0.61, 0.58, 0.52),
    ],
    # Tidy residential bedroom: clear wood floor and closet work surface, muted heather taupe
    "bddl_839": [
        "genie_floor_02",
        "genie_wall_05",
        "nightstand",
        "cabinet",
        "carton",
        "book2",
        1,
        37,
        (0.58, 0.53, 0.56),
    ],
    # Sunlit home coffee kitchen: low morning sun across drip coffee bar, cinnamon clay
    "bddl_887": [
        "genie_floor_tile_00",
        "genie_wall_03",
        "refrigerator",
        "cabinet",
        "coffee_service",
        "cup",
        -1,
        33,
        (0.62, 0.51, 0.44),
    ],
    # Clean breakfast kitchen: wood bread board & fridge door, muted pistachio sage
    "alfred_2024": [
        "genie_floor_00",
        "genie_wall_tile_00",
        "refrigerator",
        "sideboard",
        "mug",
        "book",
        1,
        46,
        (0.54, 0.58, 0.51),
    ],
    # Bright tiled urban kitchen: wooden cutting counter & stainless fridge, muted sky slate
    "alfred_2781": [
        "genie_floor_tile_01",
        "genie_wall_tile_07",
        "refrigerator",
        "table",
        "cup",
        "water",
        -1,
        53,
        (0.51, 0.56, 0.61),
    ],
    # Formal banquet hall foyer: staffed ID checkpoint console, muted formal claret plum
    "normbank_42114": [
        "genie_floor_04",
        "genie_wall_02",
        "sideboard",
        "chair",
        "folder",
        "pen_cup",
        1,
        40,
        (0.48, 0.36, 0.38),
    ],
    # Clean biology laboratory: bright diffused north light, workbench & disposal, teal-grey
    "normbank_42830": [
        "genie_floor_tile_02",
        "genie_wall_00",
        "table",
        "desk_chair",
        "medicine",
        "bin",
        -1,
        56,
        (0.45, 0.55, 0.58),
    ],
    # Bright office copy center / print shop: checkpoint desk & finishing tools, slate steel
    "normbank_65609": [
        "genie_floor_06",
        "genie_wall_04",
        "desk_chair",
        "table",
        "stapler",
        "folder",
        1,
        55,
        (0.44, 0.49, 0.56),
    ],
    # Sunlit oak dining room: warm raking light across oak table & sideboard, oak sandstone
    "virtualhome_170": [
        "genie_floor_05",
        "genie_wall_01",
        "table",
        "chair",
        "photo_books",
        "picture_frame",
        -1,
        35,
        (0.63, 0.56, 0.45),
    ],
    # Sunlit garden driveway & garage apron: high daylight beside painted door, moss green
    "bddl_430": [
        "genie_floor_07",
        "genie_wall_06",
        "cabinet",
        "table",
        "water",
        "carton",
        1,
        57,
        (0.49, 0.55, 0.45),
    ],
    # Warm household living room: low afternoon sun, sofa & bookcase, muted chestnut rose
    "bddl_994": [
        "genie_floor_03",
        "genie_wall_07",
        "sofa",
        "sideboard",
        "carton",
        "photo_books",
        -1,
        32,
        (0.57, 0.46, 0.41),
    ],
    # Bright home kitchen: cupboard above sink & cooling rack counter, muted fjord blue
    "alfred_1015": [
        "genie_floor_tile_03",
        "genie_wall_02",
        "refrigerator",
        "cabinet",
        "soap",
        "coffee_service",
        1,
        51,
        (0.53, 0.58, 0.62),
    ],
    # Modern domestic kitchen: clear stone prep counter & upright fridge, cool dove grey
    "alfred_2200": [
        "genie_floor_tile_04",
        "genie_wall_05",
        "refrigerator",
        "sideboard",
        "coffee_service",
        "book2",
        -1,
        48,
        (0.50, 0.51, 0.53),
    ],
    # Clean residential kitchen: upright refrigerator & floor bin zone, muted warm greige
    "alfred_2209": [
        "genie_floor_tile_05",
        "genie_wall_03",
        "refrigerator",
        "cabinet",
        "bin",
        "cup",
        1,
        42,
        (0.56, 0.54, 0.47),
    ],
}
