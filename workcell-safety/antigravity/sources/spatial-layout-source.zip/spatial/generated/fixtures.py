import math
import xml.etree.ElementTree as ET
import numpy as np


def _f(v):
    return f"{float(v):.5f}"


def _vec(*vals):
    return " ".join(f"{float(v):.5f}" for v in vals)


def _rgba(c):
    arr = np.clip(np.asarray(c, dtype=float), 0.0, 1.0)
    return " ".join(f"{float(v):.4f}" for v in arr)


def _quat_axis_angle(axis, angle):
    a = np.asarray(axis, dtype=float)
    n = float(np.linalg.norm(a))
    if n < 1e-9:
        return (1.0, 0.0, 0.0, 0.0)
    a = a / n
    half = 0.5 * float(angle)
    s = math.sin(half)
    return (math.cos(half), a[0] * s, a[1] * s, a[2] * s)


def _vol(gtype, size):
    s = [max(float(v), 1e-4) for v in size]
    if gtype == "box":
        return 8.0 * s[0] * s[1] * s[2]
    if gtype == "cylinder":
        return math.pi * (s[0] ** 2) * (2.0 * s[1])
    if gtype == "sphere":
        return (4.0 / 3.0) * math.pi * (s[0] ** 3)
    if gtype == "ellipsoid":
        return (4.0 / 3.0) * math.pi * s[0] * s[1] * s[2]
    if gtype == "capsule":
        return (4.0 / 3.0) * math.pi * (s[0] ** 3) + math.pi * (s[0] ** 2) * (2.0 * s[1])
    raise ValueError(f"Unsupported geom type: {gtype}")


def _add_geom(
    parent,
    name,
    gtype,
    rgba,
    pos=None,
    size=None,
    fromto=None,
    quat=None,
    contype=0,
    conaffinity=0,
    friction=None,
    density=None,
    mass=None,
):
    attrib = {
        "name": name,
        "type": gtype,
        "contype": str(int(contype)),
        "conaffinity": str(int(conaffinity)),
        "group": "1",
        "rgba": _rgba(rgba),
    }
    if fromto is not None:
        p1 = np.asarray(fromto[:3], dtype=float)
        p2 = np.asarray(fromto[3:], dtype=float)
        if float(np.linalg.norm(p2 - p1)) < 1e-4:
            p2 = p1 + np.array([0.0, 0.0, 1e-3])
        attrib["fromto"] = _vec(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2])
        r = max(float(size[0] if isinstance(size, (tuple, list, np.ndarray)) else size), 1e-4)
        attrib["size"] = _f(r)
    else:
        p = (0.0, 0.0, 0.0) if pos is None else pos
        attrib["pos"] = _vec(*p)
        sz = [max(float(v), 1e-4) for v in size]
        attrib["size"] = _vec(*sz)
        if quat is not None:
            q = np.asarray(quat, dtype=float)
            qn = float(np.linalg.norm(q))
            if qn > 1e-9:
                q = q / qn
                attrib["quat"] = _vec(*q)
    if friction is not None:
        attrib["friction"] = friction
    if density is not None:
        attrib["density"] = f"{max(float(density), 1.0):.2f}"
    if mass is not None:
        attrib["mass"] = f"{max(float(mass), 0.0):.5f}"
    return ET.SubElement(parent, "geom", attrib)


class _Namer:
    def __init__(self, prefix):
        self.prefix = prefix
        self.idx = 0

    def next(self, tag="g"):
        self.idx += 1
        return f"{self.prefix}_{tag}_{self.idx}"


def _add_ring(parent, namer, center, radius, tube_r, rgba, plane="xy", n=12, mass=None):
    cx, cy, cz = float(center[0]), float(center[1]), float(center[2])
    r = max(float(radius), 2e-3)
    tr = max(float(tube_r), 5e-4)
    for k in range(n):
        a0 = 2.0 * math.pi * k / n
        a1 = 2.0 * math.pi * (k + 1) / n
        if plane == "xy":
            ft = (
                cx + r * math.cos(a0), cy + r * math.sin(a0), cz,
                cx + r * math.cos(a1), cy + r * math.sin(a1), cz,
            )
        elif plane == "xz":
            ft = (
                cx + r * math.cos(a0), cy, cz + r * math.sin(a0),
                cx + r * math.cos(a1), cy, cz + r * math.sin(a1),
            )
        else:
            ft = (
                cx, cy + r * math.cos(a0), cz + r * math.sin(a0),
                cx, cy + r * math.cos(a1), cz + r * math.sin(a1),
            )
        _add_geom(
            parent,
            namer.next("ring"),
            "capsule",
            rgba,
            fromto=ft,
            size=tr,
            contype=0,
            conaffinity=0,
            mass=mass,
        )


def _add_handle_bar(parent, namer, cx, cy, cz, length, axis="x", proj=-0.018, r=0.006, rgba=(0.76, 0.78, 0.81, 1.0)):
    half = max(0.5 * float(length), 0.015)
    off = 0.75 * half
    if axis == "x":
        _add_geom(parent, namer.next("hbar"), "capsule", rgba, fromto=(cx - half, cy + proj, cz, cx + half, cy + proj, cz), size=r)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx - off, cy, cz, cx - off, cy + proj, cz), size=r * 0.75)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx + off, cy, cz, cx + off, cy + proj, cz), size=r * 0.75)
    elif axis == "z":
        _add_geom(parent, namer.next("hbar"), "capsule", rgba, fromto=(cx, cy + proj, cz - half, cx, cy + proj, cz + half), size=r)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx, cy, cz - off, cx, cy + proj, cz - off), size=r * 0.75)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx, cy, cz + off, cx, cy + proj, cz + off), size=r * 0.75)
    else:
        _add_geom(parent, namer.next("hbar"), "capsule", rgba, fromto=(cx + proj, cy - half, cz, cx + proj, cy + half, cz), size=r)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx, cy - off, cz, cx + proj, cy - off, cz), size=r * 0.75)
        _add_geom(parent, namer.next("hpost"), "cylinder", rgba, fromto=(cx, cy + off, cz, cx + proj, cy + off, cz), size=r * 0.75)


def _add_cabinet_base(parent, namer, hw, hd, z_under, body_rgba, front_rgba, trim_rgba, kick_rgba, doors=2, drawers=0):
    toe_h = min(0.085, max(0.04, 0.13 * z_under))
    carcass_h = max(z_under - toe_h, 0.12)
    carcass_zc = toe_h + 0.5 * carcass_h
    cw = max(hw - 0.008, 0.08)
    cd = max(hd - 0.010, 0.08)

    _add_geom(parent, namer.next("kick"), "box", kick_rgba, pos=(0.0, 0.015, 0.5 * toe_h), size=(max(cw - 0.015, 0.05), max(cd - 0.025, 0.05), 0.5 * toe_h))
    _add_geom(parent, namer.next("carcass"), "box", body_rgba, pos=(0.0, 0.0, carcass_zc), size=(cw, cd, 0.5 * carcass_h))
    _add_geom(parent, namer.next("bevel"), "box", trim_rgba, pos=(0.0, 0.0, z_under - 0.006), size=(hw - 0.002, hd - 0.002, 0.006))

    y_front = -cd - 0.007
    rem_h = carcass_h - 0.024
    top_y_cursor = z_under - 0.016

    if drawers > 0:
        dh = min(0.14, rem_h / max(drawers + (1.5 if doors > 0 else 0.0), 1.0))
        for i in range(drawers):
            zc = top_y_cursor - 0.5 * dh
            _add_geom(parent, namer.next("drw"), "box", front_rgba, pos=(0.0, y_front, zc), size=(max(cw - 0.014, 0.05), 0.007, max(0.5 * dh - 0.005, 0.012)))
            _add_handle_bar(parent, namer, 0.0, y_front - 0.007, zc, min(0.16, 0.65 * cw), axis="x", proj=-0.015, r=0.005, rgba=trim_rgba)
            top_y_cursor -= dh
            rem_h -= dh

    if doors > 0 and rem_h > 0.08:
        zc = toe_h + 0.010 + 0.5 * rem_h
        if doors == 2:
            dw = 0.5 * (cw - 0.018)
            for sgn in (-1.0, 1.0):
                xc = sgn * (dw + 0.006)
                _add_geom(parent, namer.next("doorf"), "box", front_rgba, pos=(xc, y_front, zc), size=(max(dw - 0.003, 0.03), 0.007, max(0.5 * rem_h - 0.006, 0.02)))
                _add_geom(parent, namer.next("inset"), "box", body_rgba, pos=(xc, y_front - 0.004, zc), size=(max(dw - 0.024, 0.015), 0.004, max(0.5 * rem_h - 0.028, 0.012)))
                hx = sgn * 0.022
                _add_handle_bar(parent, namer, hx, y_front - 0.007, zc + 0.18 * rem_h, min(0.11, 0.35 * rem_h), axis="z", proj=-0.015, r=0.005, rgba=trim_rgba)
        else:
            _add_geom(parent, namer.next("doorf"), "box", front_rgba, pos=(0.0, y_front, zc), size=(max(cw - 0.014, 0.05), 0.007, max(0.5 * rem_h - 0.006, 0.02)))
            _add_handle_bar(parent, namer, 0.0, y_front - 0.007, zc + 0.32 * rem_h, min(0.22, 0.8 * cw), axis="x", proj=-0.016, r=0.006, rgba=trim_rgba)


def _add_hinged_panel(root, name, namer, kind, hw, hd, z, width, rear_d):
    specs = {
        "refrigerator": (0.56, 0.026, 2.8, (0.76, 0.79, 0.82, 1.0), (0.86, 0.88, 0.90, 1.0), None, "long_bar"),
        "microwave": (0.28, 0.022, 1.2, (0.20, 0.22, 0.25, 1.0), (0.74, 0.77, 0.80, 1.0), (0.14, 0.20, 0.26, 0.45), "bar"),
        "oven": (0.36, 0.026, 2.0, (0.26, 0.28, 0.31, 1.0), (0.76, 0.79, 0.82, 1.0), (0.15, 0.13, 0.13, 0.48), "bar"),
        "shelf": (0.46, 0.020, 1.5, (0.64, 0.46, 0.30, 1.0), (0.80, 0.66, 0.32, 1.0), (0.70, 0.84, 0.92, 0.30), "knob"),
        "cabinet": (0.46, 0.020, 1.5, (0.64, 0.46, 0.30, 1.0), (0.80, 0.66, 0.32, 1.0), (0.70, 0.84, 0.92, 0.30), "knob"),
        "washer": (0.34, 0.024, 1.6, (0.90, 0.92, 0.94, 1.0), (0.74, 0.77, 0.81, 1.0), (0.22, 0.34, 0.44, 0.42), "porthole"),
        "closet": (0.56, 0.024, 2.4, (0.74, 0.62, 0.48, 1.0), (0.78, 0.64, 0.30, 1.0), None, "long_bar"),
        "bookcase": (0.50, 0.020, 1.8, (0.44, 0.28, 0.18, 1.0), (0.78, 0.64, 0.30, 1.0), (0.72, 0.84, 0.92, 0.30), "mullion"),
        "door": (0.58, 0.026, 2.6, (0.62, 0.44, 0.30, 1.0), (0.80, 0.66, 0.30, 1.0), None, "lever"),
    }
    door_h, door_t, mass, frame_c, trim_c, glass_c, style = specs[kind]
    door_w = min(0.72 * width, 0.42)
    pivot_x = hw + 0.010
    pivot_y = hd + rear_d + 0.018
    z_hinge = z + 0.018 + 0.5 * door_h

    for hz_off in (-0.34 * door_h, 0.34 * door_h):
        _add_geom(root, namer.next("knuckle"), "cylinder", trim_c, pos=(pivot_x, pivot_y, z_hinge + hz_off), size=(0.008, 0.018))
        _add_geom(root, namer.next("hleaf"), "box", trim_c, pos=(hw + 0.002, hd + rear_d + 0.004, z_hinge + hz_off), size=(0.012, 0.014, 0.014))

    panel = ET.SubElement(root, "body", {"name": f"panel_{name}", "pos": _vec(pivot_x, pivot_y, z_hinge)})
    dx, dy, dz = door_t, door_w, door_h
    ix = mass * (dy * dy + dz * dz) / 12.0
    iy = mass * (dx * dx + dz * dz) / 12.0
    iz = mass * (dx * dx + dy * dy) / 12.0
    ET.SubElement(
        panel,
        "inertial",
        {"pos": _vec(0.0, 0.5 * door_w, 0.0), "mass": f"{mass:.4f}", "diaginertia": _vec(ix, iy, iz)},
    )
    ET.SubElement(
        panel,
        "joint",
        {
            "name": f"hinge_{name}",
            "type": "hinge",
            "pos": "0 0 0",
            "axis": "0 0 1",
            "limited": "true",
            "range": "0 1.15",
            "damping": "0.8",
            "frictionloss": "0.05",
        },
    )

    pnamer = _Namer(f"{name}_panel")
    ht = 0.5 * door_t
    hh = 0.5 * door_h
    yc = 0.5 * door_w

    if glass_c is not None and style != "porthole":
        rail = min(0.036, 0.14 * door_w, 0.14 * door_h)
        _add_geom(panel, pnamer.next("top"), "box", frame_c, pos=(0.0, yc, hh - 0.5 * rail), size=(ht, 0.5 * door_w, 0.5 * rail))
        _add_geom(panel, pnamer.next("bot"), "box", frame_c, pos=(0.0, yc, -hh + 0.5 * rail), size=(ht, 0.5 * door_w, 0.5 * rail))
        _add_geom(panel, pnamer.next("hingeside"), "box", frame_c, pos=(0.0, 0.5 * rail, 0.0), size=(ht, 0.5 * rail, hh - rail))
        _add_geom(panel, pnamer.next("latchside"), "box", frame_c, pos=(0.0, door_w - 0.5 * rail, 0.0), size=(ht, 0.5 * rail, hh - rail))
        _add_geom(panel, pnamer.next("glass"), "box", glass_c, pos=(0.0, yc, 0.0), size=(max(0.35 * ht, 0.003), max(0.5 * door_w - rail, 0.02), max(hh - rail, 0.02)))
        if style == "mullion":
            _add_geom(panel, pnamer.next("muntin"), "box", frame_c, pos=(0.0, yc, 0.0), size=(0.6 * ht, max(0.5 * door_w - rail, 0.02), 0.007))
            _add_geom(panel, pnamer.next("muntin"), "box", frame_c, pos=(0.0, yc, 0.0), size=(0.6 * ht, 0.007, max(hh - rail, 0.02)))
    else:
        _add_geom(panel, pnamer.next("slab"), "box", frame_c, pos=(0.0, yc, 0.0), size=(ht, 0.5 * door_w, hh))
        if style == "porthole":
            pr = min(0.34 * door_w, 0.34 * door_h)
            _add_ring(panel, pnamer, (ht + 0.005, yc, 0.0), pr, 0.009, trim_c, plane="yz", n=12)
            _add_geom(panel, pnamer.next("portglass"), "cylinder", glass_c, pos=(ht + 0.003, yc, 0.0), size=(max(pr - 0.008, 0.02), 0.004), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi))
        elif kind in ("closet", "door"):
            in_c = tuple(max(c - 0.07, 0.05) for c in frame_c[:3]) + (1.0,)
            for z_off in (-0.24 * door_h, 0.24 * door_h):
                _add_geom(panel, pnamer.next("panel"), "box", in_c, pos=(ht + 0.002, yc, z_off), size=(0.003, max(0.38 * door_w, 0.03), max(0.18 * door_h, 0.03)))
        elif kind == "refrigerator":
            _add_geom(panel, pnamer.next("gasket"), "box", (0.86, 0.87, 0.88, 1.0), pos=(-ht - 0.003, yc, 0.0), size=(0.003, 0.46 * door_w, 0.46 * door_h))
            _add_geom(panel, pnamer.next("binrail"), "box", (0.72, 0.82, 0.88, 0.45), pos=(-ht - 0.014, yc, -0.18 * door_h), size=(0.010, 0.42 * door_w, 0.028))

    hy = max(door_w - 0.038, 0.65 * door_w)
    if style == "long_bar":
        hlen = min(0.30, 0.56 * door_h)
        _add_geom(panel, pnamer.next("hbar"), "capsule", trim_c, fromto=(ht + 0.018, hy, -0.5 * hlen, ht + 0.018, hy, 0.5 * hlen), size=0.0065)
        _add_geom(panel, pnamer.next("hpost"), "cylinder", trim_c, fromto=(ht, hy, -0.38 * hlen, ht + 0.018, hy, -0.38 * hlen), size=0.005)
        _add_geom(panel, pnamer.next("hpost"), "cylinder", trim_c, fromto=(ht, hy, 0.38 * hlen, ht + 0.018, hy, 0.38 * hlen), size=0.005)
    elif style == "bar":
        hlen = min(0.18, 0.55 * door_h)
        _add_geom(panel, pnamer.next("hbar"), "capsule", trim_c, fromto=(ht + 0.017, hy, -0.5 * hlen, ht + 0.017, hy, 0.5 * hlen), size=0.006)
        _add_geom(panel, pnamer.next("hpost"), "cylinder", trim_c, fromto=(ht, hy, -0.38 * hlen, ht + 0.017, hy, -0.38 * hlen), size=0.0045)
        _add_geom(panel, pnamer.next("hpost"), "cylinder", trim_c, fromto=(ht, hy, 0.38 * hlen, ht + 0.017, hy, 0.38 * hlen), size=0.0045)
    elif style == "lever":
        _add_geom(panel, pnamer.next("plate"), "box", trim_c, pos=(ht + 0.002, hy, -0.02), size=(0.003, 0.014, 0.045))
        _add_geom(panel, pnamer.next("stem"), "cylinder", trim_c, fromto=(ht, hy, -0.02, ht + 0.022, hy, -0.02), size=0.006)
        _add_geom(panel, pnamer.next("lever"), "capsule", trim_c, fromto=(ht + 0.022, hy, -0.02, ht + 0.022, hy - 0.062, -0.02), size=0.006)
    else:
        _add_geom(panel, pnamer.next("kstem"), "cylinder", trim_c, fromto=(ht, hy, 0.0, ht + 0.014, hy, 0.0), size=0.0045)
        _add_geom(panel, pnamer.next("knob"), "sphere", trim_c, pos=(ht + 0.018, hy, 0.0), size=(0.010,))


def fixture(world, name, kind, x, y, z, width, depth):
    x = float(x)
    y = float(y)
    z = float(z)
    width = max(float(width), 0.20)
    depth = max(float(depth), 0.20)
    hw = 0.5 * width
    hd = 0.5 * depth
    z_under = max(z - 0.036, 0.15)
    k = str(kind).strip().lower().replace("-", "_").replace(" ", "_")

    top_colors = {
        "counter": (0.84, 0.81, 0.76, 1.0),
        "microwave": (0.76, 0.78, 0.81, 1.0),
        "refrigerator": (0.87, 0.91, 0.94, 1.0),
        "stove": (0.14, 0.15, 0.17, 1.0),
        "sink": (0.75, 0.78, 0.80, 1.0),
        "shelf": (0.68, 0.50, 0.34, 1.0),
        "cabinet": (0.68, 0.50, 0.34, 1.0),
        "bin": (0.30, 0.33, 0.37, 1.0),
        "table": (0.62, 0.44, 0.28, 1.0),
        "chair": (0.36, 0.43, 0.52, 1.0),
        "bed": (0.92, 0.91, 0.88, 1.0),
        "closet": (0.78, 0.67, 0.54, 1.0),
        "copier": (0.84, 0.85, 0.87, 1.0),
        "scanner": (0.20, 0.27, 0.33, 1.0),
        "washer": (0.93, 0.94, 0.95, 1.0),
        "station": (0.45, 0.50, 0.56, 1.0),
        "door": (0.64, 0.48, 0.34, 1.0),
        "oven": (0.28, 0.30, 0.33, 1.0),
        "cart": (0.76, 0.78, 0.81, 1.0),
        "checkpoint": (0.22, 0.24, 0.27, 1.0),
        "window": (0.93, 0.92, 0.89, 1.0),
        "sofa": (0.38, 0.46, 0.52, 1.0),
        "bookcase": (0.48, 0.31, 0.20, 1.0),
        "coffee_machine": (0.72, 0.74, 0.77, 1.0),
        "floor": (0.75, 0.71, 0.65, 1.0),
    }

    root = ET.SubElement(world, "body", {"name": f"{name}_root", "pos": _vec(x, y, 0.0)})
    _add_geom(
        root,
        f"top_{name}",
        "box",
        top_colors.get(k, (0.72, 0.70, 0.67, 1.0)),
        pos=(0.0, 0.0, z - 0.018),
        size=(hw, hd, 0.018),
        contype=1,
        conaffinity=2,
        friction="0.9 0.01 0.001",
    )

    namer = _Namer(name)
    rear_d = 0.044
    y_rear_c = hd + 0.006 + 0.5 * rear_d
    steel = (0.75, 0.78, 0.81, 1.0)
    dark_steel = (0.24, 0.26, 0.29, 1.0)
    chrome = (0.86, 0.88, 0.90, 1.0)
    wood_oak = (0.66, 0.48, 0.32, 1.0)
    wood_walnut = (0.44, 0.29, 0.19, 1.0)
    cream = (0.92, 0.91, 0.88, 1.0)
    charcoal = (0.18, 0.20, 0.23, 1.0)
    glass = (0.68, 0.84, 0.93, 0.32)
    screen_cyan = (0.16, 0.68, 0.84, 1.0)

    if k == "counter":
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.88, 0.87, 0.84, 1.0), (0.93, 0.92, 0.89, 1.0), steel, charcoal, doors=2, drawers=1)
        bh = 0.17
        _add_geom(root, namer.next("backsplash"), "box", (0.86, 0.84, 0.80, 1.0), pos=(0.0, hd + 0.016, z + 0.5 * bh), size=(hw, 0.012, 0.5 * bh))
        _add_geom(root, namer.next("cap"), "box", steel, pos=(0.0, hd + 0.016, z + bh + 0.005), size=(hw + 0.003, 0.015, 0.005))
        _add_geom(root, namer.next("outlet"), "box", cream, pos=(0.38 * hw, hd + 0.003, z + 0.09), size=(0.026, 0.003, 0.036))
        _add_geom(root, namer.next("slot"), "box", charcoal, pos=(0.38 * hw, hd + 0.001, z + 0.102), size=(0.010, 0.002, 0.008))
        _add_geom(root, namer.next("slot"), "box", charcoal, pos=(0.38 * hw, hd + 0.001, z + 0.078), size=(0.010, 0.002, 0.008))

    elif k == "microwave":
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.84, 0.85, 0.87, 1.0), (0.90, 0.91, 0.92, 1.0), steel, charcoal, doors=2, drawers=0)
        mh = 0.31
        _add_geom(root, namer.next("housing"), "box", steel, pos=(0.0, y_rear_c, z + 0.5 * mh), size=(hw, 0.5 * rear_d, 0.5 * mh))
        _add_geom(root, namer.next("cavity"), "box", (0.90, 0.91, 0.92, 1.0), pos=(-0.15 * hw, hd + 0.005, z + 0.5 * mh), size=(0.68 * hw, 0.003, 0.42 * mh))
        ctrl_x = 0.72 * hw
        _add_geom(root, namer.next("ctrl"), "box", charcoal, pos=(ctrl_x, hd + 0.004, z + 0.5 * mh), size=(0.24 * hw, 0.004, 0.44 * mh))
        _add_geom(root, namer.next("led"), "box", (0.18, 0.86, 0.54, 1.0), pos=(ctrl_x, hd + 0.001, z + 0.76 * mh), size=(0.17 * hw, 0.002, 0.022))
        for r_i in range(3):
            for c_i in range(3):
                bx = ctrl_x + (c_i - 1) * (0.055 * hw)
                bz = z + 0.46 * mh - r_i * 0.026
                _add_geom(root, namer.next("btn"), "box", (0.45, 0.48, 0.52, 1.0), pos=(bx, hd + 0.001, bz), size=(0.018 * hw, 0.002, 0.008))
        _add_geom(root, namer.next("toptrim"), "box", dark_steel, pos=(0.0, y_rear_c, z + mh + 0.008), size=(hw + 0.004, 0.5 * rear_d + 0.004, 0.008))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "refrigerator":
        _add_cabinet_base(root, namer, hw, hd, z_under, steel, (0.80, 0.83, 0.86, 1.0), chrome, charcoal, doors=0, drawers=2)
        for s_i in range(3):
            _add_geom(root, namer.next("vent"), "box", (0.10, 0.11, 0.13, 1.0), pos=(0.0, -hd + 0.008, 0.022 + s_i * 0.016), size=(0.78 * hw, 0.006, 0.004))
        rh = 0.60
        _add_geom(root, namer.next("tower"), "box", steel, pos=(0.0, y_rear_c, z + 0.5 * rh), size=(hw, 0.5 * rear_d, 0.5 * rh))
        _add_geom(root, namer.next("liner"), "box", (0.94, 0.96, 0.98, 1.0), pos=(0.0, hd + 0.005, z + 0.48 * rh), size=(0.88 * hw, 0.003, 0.44 * rh))
        _add_geom(root, namer.next("ledbar"), "box", (0.82, 0.95, 1.0, 1.0), pos=(0.0, hd + 0.003, z + 0.50 * rh), size=(0.012, 0.002, 0.36 * rh))
        _add_geom(root, namer.next("crown"), "box", dark_steel, pos=(0.0, y_rear_c, z + rh + 0.016), size=(hw + 0.004, 0.5 * rear_d + 0.006, 0.016))
        _add_geom(root, namer.next("tempdisp"), "box", screen_cyan, pos=(0.0, hd + 0.003, z + rh + 0.016), size=(0.055, 0.003, 0.010))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "stove":
        toe_h = 0.075
        ctrl_h = 0.090
        oven_h = max(z_under - toe_h - ctrl_h, 0.20)
        _add_geom(root, namer.next("body"), "box", steel, pos=(0.0, 0.0, 0.5 * z_under), size=(hw - 0.004, hd - 0.006, 0.5 * z_under))
        _add_geom(root, namer.next("kick"), "box", charcoal, pos=(0.0, 0.01, 0.5 * toe_h), size=(hw - 0.012, hd - 0.016, 0.5 * toe_h))
        ctrl_zc = z_under - 0.5 * ctrl_h
        _add_geom(root, namer.next("fascia"), "box", dark_steel, pos=(0.0, -hd + 0.002, ctrl_zc), size=(hw - 0.004, 0.010, 0.5 * ctrl_h))
        n_knobs = 4
        for i in range(n_knobs):
            kx = (-0.66 + i * (1.32 / (n_knobs - 1))) * hw
            _add_geom(root, namer.next("knob"), "cylinder", chrome, pos=(kx, -hd - 0.012, ctrl_zc), size=(0.017, 0.010), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
            _add_geom(root, namer.next("tick"), "box", charcoal, pos=(kx, -hd - 0.023, ctrl_zc + 0.008), size=(0.0025, 0.002, 0.006))
        ov_zc = toe_h + 0.5 * oven_h
        _add_geom(root, namer.next("ovdoor"), "box", steel, pos=(0.0, -hd - 0.002, ov_zc), size=(0.90 * hw, 0.010, 0.46 * oven_h))
        _add_geom(root, namer.next("ovglass"), "box", (0.12, 0.13, 0.15, 0.85), pos=(0.0, -hd - 0.010, ov_zc - 0.015), size=(0.64 * hw, 0.004, 0.26 * oven_h))
        _add_handle_bar(root, namer, 0.0, -hd - 0.012, ov_zc + 0.34 * oven_h, 1.25 * hw, axis="x", proj=-0.022, r=0.008, rgba=chrome)
        bh = 0.22
        _add_geom(root, namer.next("backguard"), "box", steel, pos=(0.0, hd + 0.022, z + 0.5 * bh), size=(hw, 0.018, 0.5 * bh))
        _add_geom(root, namer.next("clock"), "box", charcoal, pos=(0.0, hd + 0.003, z + 0.62 * bh), size=(min(0.11, 0.45 * hw), 0.004, 0.030))
        _add_geom(root, namer.next("digits"), "box", (0.20, 0.90, 0.55, 1.0), pos=(0.0, hd + 0.001, z + 0.62 * bh), size=(min(0.065, 0.30 * hw), 0.002, 0.012))

    elif k == "sink":
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.90, 0.90, 0.88, 1.0), cream, chrome, charcoal, doors=2, drawers=0)
        apron_h = min(0.15, 0.24 * z_under)
        _add_geom(root, namer.next("apron"), "box", (0.95, 0.95, 0.94, 1.0), pos=(0.0, -hd + 0.004, z_under - 0.5 * apron_h), size=(0.82 * hw, 0.014, 0.5 * apron_h))
        bh = 0.14
        _add_geom(root, namer.next("splash"), "box", (0.86, 0.88, 0.90, 1.0), pos=(0.0, hd + 0.018, z + 0.5 * bh), size=(hw, 0.012, 0.5 * bh))
        fy = hd + 0.036
        _add_geom(root, namer.next("escutcheon"), "box", chrome, pos=(0.0, fy, z + 0.008), size=(0.095, 0.024, 0.008))
        _add_geom(root, namer.next("stem"), "cylinder", chrome, fromto=(0.0, fy, z + 0.012, 0.0, fy, z + 0.23), size=0.011)
        _add_geom(root, namer.next("arch1"), "capsule", chrome, fromto=(0.0, fy, z + 0.23, 0.0, fy - 0.014, z + 0.28), size=0.009)
        _add_geom(root, namer.next("arch2"), "capsule", chrome, fromto=(0.0, fy - 0.014, z + 0.28, 0.0, hd + 0.014, z + 0.25), size=0.009)
        _add_geom(root, namer.next("nozzle"), "cylinder", chrome, fromto=(0.0, hd + 0.014, z + 0.25, 0.0, hd + 0.014, z + 0.215), size=0.010)
        for sgn, dot_c in ((-1.0, (0.85, 0.18, 0.16, 1.0)), (1.0, (0.16, 0.45, 0.85, 1.0))):
            _add_geom(root, namer.next("valve"), "cylinder", chrome, pos=(sgn * 0.068, fy, z + 0.028), size=(0.011, 0.018))
            _add_geom(root, namer.next("lever"), "capsule", chrome, fromto=(sgn * 0.068, fy, z + 0.042, sgn * 0.102, fy, z + 0.048), size=0.005)
            _add_geom(root, namer.next("dot"), "sphere", dot_c, pos=(sgn * 0.068, fy - 0.011, z + 0.038), size=(0.004,))

    elif k in ("shelf", "cabinet"):
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.64, 0.47, 0.31, 1.0), (0.72, 0.54, 0.36, 1.0), (0.78, 0.64, 0.32, 1.0), wood_walnut, doors=2, drawers=0)
        sh = 0.50
        _add_geom(root, namer.next("back"), "box", wood_oak, pos=(0.0, y_rear_c, z + 0.5 * sh), size=(hw, 0.5 * rear_d, 0.5 * sh))
        for sgn in (-1.0, 1.0):
            _add_geom(root, namer.next("stile"), "box", wood_walnut, pos=(sgn * (hw - 0.016), hd + 0.014, z + 0.5 * sh), size=(0.016, 0.010, 0.5 * sh))
        _add_geom(root, namer.next("crown"), "box", wood_walnut, pos=(0.0, y_rear_c, z + sh + 0.014), size=(hw + 0.010, 0.5 * rear_d + 0.008, 0.014))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "bin":
        bin_blue = (0.18, 0.40, 0.64, 1.0)
        bin_dark = (0.14, 0.30, 0.48, 1.0)
        wheel_h = 0.055
        bh = max(z_under - wheel_h, 0.20)
        _add_geom(root, namer.next("tub"), "box", bin_blue, pos=(0.0, 0.0, wheel_h + 0.5 * bh), size=(hw - 0.010, hd - 0.012, 0.5 * bh))
        _add_geom(root, namer.next("rim"), "box", dark_steel, pos=(0.0, 0.0, z_under - 0.016), size=(hw + 0.004, hd + 0.004, 0.016))
        for rx in (-0.55 * hw, 0.0, 0.55 * hw):
            _add_geom(root, namer.next("rib"), "box", bin_dark, pos=(rx, -hd + 0.006, wheel_h + 0.5 * bh), size=(0.012, 0.010, 0.42 * bh))
        _add_geom(root, namer.next("stripe"), "box", (0.20, 0.72, 0.36, 1.0), pos=(0.0, -hd + 0.004, z_under - 0.11), size=(0.76 * hw, 0.008, 0.032))
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("wheel"), "cylinder", charcoal, pos=(sx * (hw - 0.045), sy * (hd - 0.045), 0.5 * wheel_h), size=(0.5 * wheel_h, 0.014), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi))
        lh = 0.24
        _add_geom(root, namer.next("lidback"), "box", bin_dark, pos=(0.0, hd + 0.020, z + 0.5 * lh), size=(hw - 0.006, 0.014, 0.5 * lh))
        _add_geom(root, namer.next("sign"), "box", (0.92, 0.94, 0.95, 1.0), pos=(0.0, hd + 0.005, z + 0.55 * lh), size=(0.68 * hw, 0.003, 0.045))

    elif k == "table":
        apron_h = 0.055
        leg_r = 0.022
        _add_geom(root, namer.next("apron"), "box", wood_walnut, pos=(0.0, 0.0, z_under - 0.5 * apron_h), size=(max(hw - 0.032, 0.06), max(hd - 0.032, 0.06), 0.5 * apron_h))
        lx = max(hw - 0.042, 0.05)
        ly = max(hd - 0.042, 0.05)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("leg"), "cylinder", wood_walnut, pos=(sx * lx, sy * ly, 0.5 * z_under), size=(leg_r, 0.5 * z_under))
                _add_geom(root, namer.next("foot"), "cylinder", charcoal, pos=(sx * lx, sy * ly, 0.008), size=(leg_r + 0.003, 0.008))
        brace_z = 0.22 * z_under
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("sidebrace"), "cylinder", wood_walnut, fromto=(sx * lx, -ly, brace_z, sx * lx, ly, brace_z), size=0.011)
        _add_geom(root, namer.next("midbrace"), "cylinder", wood_walnut, fromto=(-lx, 0.0, brace_z, lx, 0.0, brace_z), size=0.011)

    elif k == "chair":
        frame_c = (0.28, 0.30, 0.34, 1.0)
        cush_c = (0.34, 0.40, 0.48, 1.0)
        _add_geom(root, namer.next("seatframe"), "box", frame_c, pos=(0.0, 0.0, z_under - 0.020), size=(hw - 0.012, hd - 0.012, 0.020))
        lx = max(hw - 0.035, 0.05)
        ly = max(hd - 0.035, 0.05)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("leg"), "cylinder", frame_c, pos=(sx * lx, sy * ly, 0.5 * z_under), size=(0.016, 0.5 * z_under))
                _add_geom(root, namer.next("glide"), "cylinder", charcoal, pos=(sx * lx, sy * ly, 0.007), size=(0.019, 0.007))
        _add_geom(root, namer.next("cross"), "cylinder", frame_c, fromto=(-lx, 0.0, 0.24 * z_under, lx, 0.0, 0.24 * z_under), size=0.010)
        bh = 0.44
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("stile"), "capsule", frame_c, fromto=(sx * (hw - 0.026), hd + 0.020, z - 0.02, sx * (hw - 0.026), hd + 0.034, z + bh), size=0.015)
        _add_geom(root, namer.next("lumbar"), "box", cush_c, pos=(0.0, hd + 0.024, z + 0.42 * bh), size=(hw - 0.020, 0.016, 0.14 * bh))
        _add_geom(root, namer.next("crest"), "box", cush_c, pos=(0.0, hd + 0.030, z + 0.84 * bh), size=(hw - 0.012, 0.018, 0.14 * bh))

    elif k == "bed":
        matt_h = min(0.18, 0.28 * z_under)
        leg_h = 0.12
        frame_h = max(z_under - matt_h - leg_h, 0.14)
        _add_geom(root, namer.next("mattress"), "box", (0.94, 0.93, 0.90, 1.0), pos=(0.0, 0.0, z_under - 0.5 * matt_h), size=(hw - 0.004, hd - 0.004, 0.5 * matt_h))
        _add_geom(root, namer.next("piping"), "box", (0.76, 0.78, 0.82, 1.0), pos=(0.0, 0.0, z_under - matt_h + 0.008), size=(hw + 0.002, hd + 0.002, 0.008))
        _add_geom(root, namer.next("bedframe"), "box", wood_walnut, pos=(0.0, 0.0, leg_h + 0.5 * frame_h), size=(hw + 0.006, hd + 0.006, 0.5 * frame_h))
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("leg"), "box", wood_walnut, pos=(sx * (hw - 0.035), sy * (hd - 0.035), 0.5 * leg_h), size=(0.028, 0.028, 0.5 * leg_h))
        hb_h = 0.48
        _add_geom(root, namer.next("headboard"), "box", wood_walnut, pos=(0.0, hd + 0.028, z + 0.5 * hb_h), size=(hw + 0.012, 0.022, 0.5 * hb_h))
        _add_geom(root, namer.next("tuft"), "box", (0.58, 0.54, 0.50, 1.0), pos=(0.0, hd + 0.008, z + 0.52 * hb_h), size=(hw - 0.028, 0.008, 0.36 * hb_h))
        _add_geom(root, namer.next("cap"), "box", (0.78, 0.64, 0.32, 1.0), pos=(0.0, hd + 0.028, z + hb_h + 0.006), size=(hw + 0.016, 0.025, 0.006))

    elif k == "closet":
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.78, 0.68, 0.55, 1.0), (0.84, 0.74, 0.61, 1.0), (0.78, 0.64, 0.30, 1.0), wood_walnut, doors=0, drawers=2)
        ch = 0.60
        _add_geom(root, namer.next("back"), "box", (0.76, 0.66, 0.53, 1.0), pos=(0.0, y_rear_c, z + 0.5 * ch), size=(hw, 0.5 * rear_d, 0.5 * ch))
        _add_geom(root, namer.next("crown"), "box", wood_oak, pos=(0.0, y_rear_c, z + ch + 0.015), size=(hw + 0.008, 0.5 * rear_d + 0.008, 0.015))
        _add_geom(root, namer.next("rod"), "cylinder", chrome, fromto=(-hw + 0.03, hd + 0.020, z + 0.78 * ch, hw - 0.03, hd + 0.020, z + 0.78 * ch), size=0.010)
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "copier":
        wheel_h = 0.048
        bh = max(z_under - wheel_h, 0.25)
        _add_geom(root, namer.next("tower"), "box", (0.86, 0.87, 0.89, 1.0), pos=(0.0, 0.0, wheel_h + 0.5 * bh), size=(hw - 0.006, hd - 0.008, 0.5 * bh))
        _add_geom(root, namer.next("accent"), "box", dark_steel, pos=(0.0, 0.0, z_under - 0.025), size=(hw - 0.002, hd - 0.004, 0.025))
        n_trays = 3
        th = (bh - 0.08) / n_trays
        for i in range(n_trays):
            tz = wheel_h + 0.03 + (i + 0.5) * th
            _add_geom(root, namer.next("tray"), "box", (0.92, 0.93, 0.94, 1.0), pos=(0.0, -hd + 0.004, tz), size=(0.86 * hw, 0.008, 0.42 * th))
            _add_geom(root, namer.next("pull"), "box", charcoal, pos=(0.0, -hd - 0.004, tz + 0.08 * th), size=(0.24 * hw, 0.006, 0.014))
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("caster"), "cylinder", charcoal, pos=(sx * (hw - 0.04), sy * (hd - 0.04), 0.5 * wheel_h), size=(0.5 * wheel_h, 0.012), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi))
        adf_h = 0.14
        _add_geom(root, namer.next("adf"), "box", (0.82, 0.84, 0.86, 1.0), pos=(-0.10 * hw, hd + 0.036, z + 0.5 * adf_h), size=(0.82 * hw, 0.030, 0.5 * adf_h))
        _add_geom(root, namer.next("console"), "box", charcoal, pos=(0.68 * hw, hd + 0.032, z + 0.12), size=(0.26 * hw, 0.022, 0.065), quat=_quat_axis_angle((1, 0, 0), -0.45))
        _add_geom(root, namer.next("screen"), "box", screen_cyan, pos=(0.68 * hw, hd + 0.015, z + 0.132), size=(0.20 * hw, 0.004, 0.042), quat=_quat_axis_angle((1, 0, 0), -0.45))

    elif k == "scanner":
        scan_h = 0.085
        stand_h = max(z_under - scan_h, 0.25)
        _add_geom(root, namer.next("chassis"), "box", (0.82, 0.84, 0.86, 1.0), pos=(0.0, 0.0, z_under - 0.5 * scan_h), size=(hw + 0.004, hd + 0.004, 0.5 * scan_h))
        _add_geom(root, namer.next("led"), "box", (0.16, 0.84, 0.44, 1.0), pos=(0.62 * hw, -hd - 0.006, z_under - 0.5 * scan_h), size=(0.028, 0.003, 0.008))
        _add_geom(root, namer.next("shelf"), "box", dark_steel, pos=(0.0, 0.0, 0.35 * stand_h), size=(hw - 0.03, hd - 0.03, 0.014))
        lx = max(hw - 0.036, 0.05)
        ly = max(hd - 0.036, 0.05)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("leg"), "cylinder", dark_steel, pos=(sx * lx, sy * ly, 0.5 * stand_h), size=(0.016, 0.5 * stand_h))
        lid_h = min(0.36, 0.85 * depth)
        _add_geom(root, namer.next("lid"), "box", (0.86, 0.88, 0.90, 1.0), pos=(0.0, hd + 0.022, z + 0.5 * lid_h), size=(hw - 0.004, 0.014, 0.5 * lid_h))
        _add_geom(root, namer.next("foam"), "box", (0.96, 0.96, 0.95, 1.0), pos=(0.0, hd + 0.006, z + 0.5 * lid_h), size=(0.86 * hw, 0.004, 0.42 * lid_h))

    elif k == "washer":
        foot_h = 0.032
        bh = max(z_under - foot_h, 0.30)
        _add_geom(root, namer.next("chassis"), "box", (0.93, 0.94, 0.95, 1.0), pos=(0.0, 0.0, foot_h + 0.5 * bh), size=(hw - 0.004, hd - 0.006, 0.5 * bh))
        ctrl_h = min(0.11, 0.18 * bh)
        ctrl_zc = z_under - 0.5 * ctrl_h
        _add_geom(root, namer.next("ctrl"), "box", (0.88, 0.90, 0.92, 1.0), pos=(0.0, -hd + 0.002, ctrl_zc), size=(hw - 0.006, 0.008, 0.5 * ctrl_h))
        _add_geom(root, namer.next("drawer"), "box", (0.96, 0.96, 0.97, 1.0), pos=(-0.55 * hw, -hd - 0.004, ctrl_zc), size=(0.30 * hw, 0.005, 0.34 * ctrl_h))
        _add_geom(root, namer.next("dial"), "cylinder", chrome, pos=(0.0, -hd - 0.010, ctrl_zc), size=(0.024, 0.009), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
        _add_geom(root, namer.next("disp"), "box", charcoal, pos=(0.54 * hw, -hd - 0.004, ctrl_zc), size=(0.26 * hw, 0.004, 0.28 * ctrl_h))
        _add_geom(root, namer.next("led"), "box", screen_cyan, pos=(0.54 * hw, -hd - 0.008, ctrl_zc), size=(0.16 * hw, 0.002, 0.14 * ctrl_h))
        drum_r = min(0.56 * hw, 0.34 * (bh - ctrl_h), 0.16)
        drum_zc = foot_h + 0.48 * (bh - ctrl_h)
        _add_geom(root, namer.next("drum"), "cylinder", (0.18, 0.24, 0.30, 0.92), pos=(0.0, -hd - 0.002, drum_zc), size=(drum_r, 0.008), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
        _add_ring(root, namer, (0.0, -hd - 0.008, drum_zc), drum_r, 0.016, chrome, plane="xz", n=12)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("foot"), "cylinder", charcoal, pos=(sx * (hw - 0.04), sy * (hd - 0.04), 0.5 * foot_h), size=(0.022, 0.5 * foot_h))
        wh = 0.38
        _add_geom(root, namer.next("backpanel"), "box", (0.90, 0.91, 0.93, 1.0), pos=(0.0, y_rear_c, z + 0.5 * wh), size=(hw, 0.5 * rear_d, 0.5 * wh))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "station":
        _add_geom(root, namer.next("apron"), "box", dark_steel, pos=(0.0, 0.0, z_under - 0.032), size=(hw - 0.008, hd - 0.010, 0.032))
        _add_geom(root, namer.next("hazard"), "box", (0.92, 0.68, 0.12, 1.0), pos=(0.0, -hd + 0.006, z_under - 0.032), size=(hw - 0.012, 0.004, 0.012))
        lx = max(hw - 0.028, 0.05)
        ly = max(hd - 0.028, 0.05)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("post"), "box", dark_steel, pos=(sx * lx, sy * ly, 0.5 * z_under), size=(0.022, 0.022, 0.5 * z_under))
        _add_geom(root, namer.next("lowershelf"), "box", (0.34, 0.37, 0.41, 1.0), pos=(0.0, 0.0, 0.22 * z_under), size=(hw - 0.03, hd - 0.03, 0.014))
        ph = 0.42
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("upright"), "box", steel, pos=(sx * (hw - 0.020), hd + 0.022, z + 0.5 * ph), size=(0.018, 0.018, 0.5 * ph))
        _add_geom(root, namer.next("pegboard"), "box", (0.32, 0.36, 0.42, 1.0), pos=(0.0, hd + 0.024, z + 0.46 * ph), size=(hw - 0.038, 0.010, 0.34 * ph))
        _add_geom(root, namer.next("lightbar"), "box", (0.94, 0.96, 0.98, 1.0), pos=(0.0, hd + 0.020, z + ph + 0.012), size=(hw - 0.01, 0.018, 0.012))
        for idx, lc in enumerate(((0.22, 0.84, 0.34, 1.0), (0.94, 0.72, 0.16, 1.0), (0.88, 0.22, 0.20, 1.0))):
            _add_geom(root, namer.next("stack"), "cylinder", lc, pos=(-hw + 0.024, hd + 0.022, z + ph + 0.040 + idx * 0.028), size=(0.014, 0.012))

    elif k == "door":
        _add_geom(root, namer.next("dado"), "box", (0.88, 0.87, 0.84, 1.0), pos=(0.0, 0.0, 0.5 * z_under), size=(hw - 0.004, hd - 0.006, 0.5 * z_under))
        _add_geom(root, namer.next("baseboard"), "box", cream, pos=(0.0, -hd + 0.002, 0.055), size=(hw, 0.010, 0.055))
        _add_geom(root, namer.next("wainscot"), "box", cream, pos=(0.0, -hd + 0.002, 0.52 * z_under), size=(0.78 * hw, 0.008, 0.30 * z_under))
        dh = 0.62
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("jamb"), "box", cream, pos=(sx * (hw - 0.022), y_rear_c, z + 0.5 * dh), size=(0.024, 0.5 * rear_d, 0.5 * dh))
        _add_geom(root, namer.next("lintel"), "box", cream, pos=(0.0, y_rear_c, z + dh + 0.024), size=(hw + 0.020, 0.5 * rear_d + 0.006, 0.024))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "oven":
        _add_cabinet_base(root, namer, hw, hd, z_under, dark_steel, steel, chrome, charcoal, doors=0, drawers=1)
        ctrl_z = z_under - 0.036
        _add_geom(root, namer.next("ctrlbar"), "box", charcoal, pos=(0.0, -hd + 0.002, ctrl_z), size=(hw - 0.006, 0.008, 0.028))
        for kx in (-0.65 * hw, -0.38 * hw, 0.38 * hw, 0.65 * hw):
            _add_geom(root, namer.next("knob"), "cylinder", chrome, pos=(kx, -hd - 0.010, ctrl_z), size=(0.014, 0.008), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
        _add_geom(root, namer.next("temp"), "box", (0.95, 0.52, 0.14, 1.0), pos=(0.0, -hd - 0.004, ctrl_z), size=(0.16 * hw, 0.003, 0.012))
        oh = 0.40
        _add_geom(root, namer.next("back"), "box", dark_steel, pos=(0.0, y_rear_c, z + 0.5 * oh), size=(hw, 0.5 * rear_d, 0.5 * oh))
        _add_geom(root, namer.next("enamel"), "box", (0.14, 0.15, 0.17, 1.0), pos=(0.0, hd + 0.005, z + 0.48 * oh), size=(0.86 * hw, 0.003, 0.42 * oh))
        _add_geom(root, namer.next("lamp"), "sphere", (1.0, 0.82, 0.42, 1.0), pos=(0.0, hd + 0.004, z + 0.80 * oh), size=(0.018,))
        _add_geom(root, namer.next("venthood"), "box", steel, pos=(0.0, y_rear_c, z + oh + 0.014), size=(hw + 0.004, 0.5 * rear_d + 0.006, 0.014))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "cart":
        wheel_h = 0.068
        lx = max(hw - 0.024, 0.05)
        ly = max(hd - 0.024, 0.05)
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("post"), "cylinder", chrome, pos=(sx * lx, sy * ly, wheel_h + 0.5 * (z_under - wheel_h)), size=(0.013, 0.5 * max(z_under - wheel_h, 0.1)))
                _add_geom(root, namer.next("fork"), "box", dark_steel, pos=(sx * lx, sy * ly, 0.72 * wheel_h), size=(0.016, 0.016, 0.24 * wheel_h))
                _add_geom(root, namer.next("wheel"), "cylinder", charcoal, pos=(sx * lx, sy * ly, 0.42 * wheel_h), size=(0.42 * wheel_h, 0.012), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi))
        for frac in (0.18, 0.54):
            sz = wheel_h + frac * (z_under - wheel_h)
            _add_geom(root, namer.next("tray"), "box", steel, pos=(0.0, 0.0, sz), size=(hw - 0.008, hd - 0.008, 0.012))
        ph = 0.15
        py = hd + 0.032
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("hpost"), "capsule", chrome, fromto=(sx * lx, hd + 0.010, z - 0.02, sx * lx, py, z + ph), size=0.012)
        _add_geom(root, namer.next("pushbar"), "capsule", charcoal, fromto=(-lx, py, z + ph, lx, py, z + ph), size=0.015)

    elif k == "checkpoint":
        _add_geom(root, namer.next("housing"), "box", (0.34, 0.37, 0.42, 1.0), pos=(0.0, 0.0, z_under - 0.11), size=(hw, hd - 0.006, 0.11))
        _add_geom(root, namer.next("hazard"), "box", (0.94, 0.72, 0.12, 1.0), pos=(0.0, -hd + 0.004, z_under - 0.036), size=(hw - 0.01, 0.005, 0.016))
        _add_geom(root, namer.next("estop"), "cylinder", (0.88, 0.14, 0.14, 1.0), pos=(0.74 * hw, -hd - 0.010, z_under - 0.10), size=(0.018, 0.010), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
        leg_h = max(z_under - 0.22, 0.16)
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("pedestal"), "box", dark_steel, pos=(sx * 0.62 * hw, 0.0, 0.5 * leg_h), size=(0.055, max(hd - 0.03, 0.06), 0.5 * leg_h))
        ah = 0.46
        _add_geom(root, namer.next("portal"), "box", (0.28, 0.32, 0.38, 1.0), pos=(0.0, hd + 0.028, z + 0.5 * ah), size=(hw, 0.022, 0.5 * ah))
        _add_geom(root, namer.next("monitor"), "box", charcoal, pos=(-0.18 * hw, hd + 0.004, z + 0.60 * ah), size=(0.48 * hw, 0.006, 0.26 * ah))
        _add_geom(root, namer.next("xray"), "box", screen_cyan, pos=(-0.18 * hw, hd + 0.001, z + 0.60 * ah), size=(0.42 * hw, 0.002, 0.20 * ah))
        _add_geom(root, namer.next("beacon"), "cylinder", (0.20, 0.86, 0.38, 1.0), pos=(0.68 * hw, hd + 0.028, z + ah + 0.032), size=(0.024, 0.032))

    elif k == "window":
        _add_geom(root, namer.next("wall"), "box", (0.89, 0.88, 0.85, 1.0), pos=(0.0, 0.0, 0.5 * z_under), size=(hw - 0.006, hd - 0.008, 0.5 * z_under))
        _add_geom(root, namer.next("apron"), "box", cream, pos=(0.0, -hd + 0.004, z_under - 0.028), size=(hw + 0.006, 0.012, 0.028))
        _add_geom(root, namer.next("base"), "box", cream, pos=(0.0, -hd + 0.004, 0.050), size=(hw, 0.010, 0.050))
        wh = 0.56
        fy = hd + 0.026
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("casing"), "box", cream, pos=(sx * (hw - 0.022), fy, z + 0.5 * wh), size=(0.024, 0.020, 0.5 * wh))
        _add_geom(root, namer.next("header"), "box", cream, pos=(0.0, fy, z + wh + 0.022), size=(hw + 0.018, 0.024, 0.022))
        _add_geom(root, namer.next("mullion"), "box", cream, pos=(0.0, fy, z + 0.5 * wh), size=(0.010, 0.014, 0.5 * wh))
        _add_geom(root, namer.next("muntin"), "box", cream, pos=(0.0, fy, z + 0.52 * wh), size=(hw - 0.04, 0.014, 0.010))
        _add_geom(root, namer.next("pane"), "box", glass, pos=(0.0, fy, z + 0.5 * wh), size=(max(hw - 0.044, 0.05), 0.004, 0.48 * wh))

    elif k == "sofa":
        leg_h = 0.14
        base_h = max(z_under - leg_h, 0.16)
        cush_h = min(0.14, 0.34 * base_h)
        sofa_c = (0.36, 0.44, 0.50, 1.0)
        sofa_d = (0.30, 0.37, 0.43, 1.0)
        _add_geom(root, namer.next("cush"), "box", sofa_c, pos=(0.0, 0.0, z_under - 0.5 * cush_h), size=(hw - 0.004, hd - 0.004, 0.5 * cush_h))
        _add_geom(root, namer.next("deck"), "box", sofa_d, pos=(0.0, 0.0, leg_h + 0.5 * (base_h - cush_h)), size=(hw, hd, 0.5 * max(base_h - cush_h, 0.06)))
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("leg"), "cylinder", wood_walnut, pos=(sx * (hw - 0.04), sy * (hd - 0.04), 0.5 * leg_h), size=(0.018, 0.5 * leg_h))
        bh = 0.38
        for sx in (-0.5, 0.5):
            _add_geom(root, namer.next("backcush"), "box", sofa_c, pos=(sx * hw, hd + 0.048, z + 0.5 * bh), size=(0.48 * hw, 0.042, 0.5 * bh))
        _add_geom(root, namer.next("backframe"), "box", sofa_d, pos=(0.0, hd + 0.098, z + 0.48 * bh), size=(hw + 0.016, 0.014, 0.48 * bh))

    elif k == "bookcase":
        bh_u = z_under
        _add_geom(root, namer.next("back"), "box", wood_walnut, pos=(0.0, hd - 0.014, 0.5 * bh_u), size=(hw - 0.004, 0.012, 0.5 * bh_u))
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("side"), "box", wood_walnut, pos=(sx * (hw - 0.014), 0.0, 0.5 * bh_u), size=(0.014, hd - 0.004, 0.5 * bh_u))
        _add_geom(root, namer.next("plinth"), "box", (0.34, 0.22, 0.14, 1.0), pos=(0.0, 0.0, 0.035), size=(hw, hd, 0.035))
        shelves = (0.38 * bh_u, 0.68 * bh_u)
        book_cols = ((0.64, 0.18, 0.16, 1.0), (0.18, 0.34, 0.54, 1.0), (0.22, 0.46, 0.28, 1.0), (0.76, 0.58, 0.20, 1.0), (0.48, 0.26, 0.46, 1.0))
        for sz in shelves:
            _add_geom(root, namer.next("shelf"), "box", wood_walnut, pos=(0.0, 0.0, sz), size=(hw - 0.024, hd - 0.012, 0.012))
            n_books = max(4, int((width - 0.08) / 0.045))
            span = max(width - 0.09, 0.16)
            for bi in range(n_books):
                bx = -0.5 * span + (bi + 0.5) * (span / n_books)
                bht = min(0.14, 0.24 * bh_u) * (0.85 + 0.15 * ((bi * 3) % 2))
                _add_geom(root, namer.next("book"), "box", book_cols[bi % len(book_cols)], pos=(bx, 0.0, sz + 0.012 + 0.5 * bht), size=(0.42 * (span / n_books), max(0.55 * hd, 0.05), 0.5 * bht))
        uh = 0.54
        _add_geom(root, namer.next("upback"), "box", wood_walnut, pos=(0.0, y_rear_c, z + 0.5 * uh), size=(hw, 0.5 * rear_d, 0.5 * uh))
        _add_geom(root, namer.next("cornice"), "box", (0.34, 0.22, 0.14, 1.0), pos=(0.0, y_rear_c, z + uh + 0.018), size=(hw + 0.012, 0.5 * rear_d + 0.010, 0.018))
        _add_hinged_panel(root, name, namer, k, hw, hd, z, width, rear_d)

    elif k == "coffee_machine":
        _add_cabinet_base(root, namer, hw, hd, z_under, wood_walnut, (0.50, 0.34, 0.22, 1.0), steel, charcoal, doors=2, drawers=1)
        eh = 0.34
        ey = hd + 0.075
        _add_geom(root, namer.next("boiler"), "box", steel, pos=(0.0, ey, z + 0.5 * eh), size=(0.86 * hw, 0.065, 0.5 * eh))
        for sx in (-1.0, 1.0):
            _add_geom(root, namer.next("cheek"), "box", (0.72, 0.16, 0.15, 1.0), pos=(sx * 0.86 * hw, ey, z + 0.5 * eh), size=(0.016, 0.068, 0.5 * eh))
        _add_geom(root, namer.next("rail"), "capsule", chrome, fromto=(-0.82 * hw, ey - 0.055, z + eh + 0.022, 0.82 * hw, ey - 0.055, z + eh + 0.022), size=0.005)
        _add_geom(root, namer.next("gauge"), "cylinder", (0.95, 0.95, 0.93, 1.0), pos=(-0.45 * hw, hd + 0.009, z + 0.72 * eh), size=(0.026, 0.006), quat=_quat_axis_angle((1, 0, 0), 0.5 * math.pi))
        _add_geom(root, namer.next("grouphead"), "cylinder", chrome, pos=(0.0, hd + 0.036, z + 0.72 * eh), size=(0.034, 0.028))
        _add_geom(root, namer.next("portafilter"), "capsule", charcoal, fromto=(0.0, hd + 0.036, z + 0.66 * eh, 0.08, hd + 0.014, z + 0.66 * eh), size=0.010)
        _add_geom(root, namer.next("wand"), "capsule", chrome, fromto=(0.56 * hw, hd + 0.024, z + 0.68 * eh, 0.64 * hw, hd + 0.014, z + 0.34 * eh), size=0.005)

    elif k == "floor":
        trim_h = 0.024
        gap_h = 0.032
        rem = max(z_under - trim_h - gap_h, 0.20)
        tier1_h = 0.52 * rem
        tier2_h = rem - tier1_h
        _add_geom(root, namer.next("edgetrim"), "box", (0.52, 0.49, 0.45, 1.0), pos=(0.0, 0.0, z_under - 0.5 * trim_h), size=(hw + 0.004, hd + 0.004, 0.5 * trim_h))
        _add_geom(root, namer.next("shadow"), "box", charcoal, pos=(0.0, 0.0, z_under - trim_h - 0.5 * gap_h), size=(max(hw - 0.026, 0.08), max(hd - 0.026, 0.08), 0.5 * gap_h))
        _add_geom(root, namer.next("plinth1"), "box", (0.64, 0.62, 0.59, 1.0), pos=(0.0, 0.0, tier2_h + 0.5 * tier1_h), size=(hw - 0.006, hd - 0.006, 0.5 * tier1_h))
        _add_geom(root, namer.next("plinth2"), "box", (0.48, 0.47, 0.45, 1.0), pos=(0.0, 0.0, 0.5 * tier2_h), size=(hw + 0.008, hd + 0.008, 0.5 * tier2_h))
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                _add_geom(root, namer.next("corner"), "box", dark_steel, pos=(sx * (hw + 0.006), sy * (hd + 0.006), 0.5 * tier2_h), size=(0.010, 0.010, 0.5 * tier2_h))

    else:
        _add_cabinet_base(root, namer, hw, hd, z_under, (0.80, 0.78, 0.75, 1.0), (0.86, 0.84, 0.81, 1.0), steel, charcoal, doors=2, drawers=0)

    return root


def prop(body, name, kind):
    k = str(kind).strip().lower().replace("-", "_").replace(" ", "_")
    namer = _Namer(name)

    def primary(gtype, size, rgba, target_mass, half_h, quat=None):
        v = _vol(gtype, size)
        dens = float(target_mass) / max(v, 1e-9)
        _add_geom(
            body,
            f"payload_{name}",
            gtype,
            rgba,
            pos=(0.0, 0.0, 0.0),
            size=size,
            quat=quat,
            contype=2,
            conaffinity=3,
            friction="0.8 0.01 0.001",
            density=dens,
        )
        return float(half_h)

    def deco(gtype, rgba, pos=None, size=None, fromto=None, quat=None, tag="d"):
        _add_geom(
            body,
            namer.next(tag),
            gtype,
            rgba,
            pos=pos,
            size=size,
            fromto=fromto,
            quat=quat,
            contype=0,
            conaffinity=0,
            mass=0.0,
        )

    if k == "apple":
        hh = primary("ellipsoid", (0.038, 0.038, 0.036), (0.76, 0.12, 0.10, 1.0), 0.18, 0.036)
        deco("capsule", (0.34, 0.22, 0.12, 1.0), fromto=(0.0, 0.0, 0.031, 0.003, 0.0, 0.048), size=0.0028, tag="stem")
        deco("ellipsoid", (0.20, 0.56, 0.18, 1.0), pos=(0.013, 0.0, 0.043), size=(0.012, 0.006, 0.0025), quat=_quat_axis_angle((0, 1, 0), -0.35), tag="leaf")
        return hh

    if k == "bread":
        hh = primary("box", (0.046, 0.030, 0.022), (0.76, 0.54, 0.28, 1.0), 0.20, 0.022)
        deco("ellipsoid", (0.79, 0.57, 0.30, 1.0), pos=(0.0, 0.0, 0.008), size=(0.047, 0.030, 0.018), tag="dome")
        for sx in (-0.020, 0.0, 0.020):
            deco("box", (0.90, 0.78, 0.56, 1.0), pos=(sx, 0.0, 0.025), size=(0.004, 0.018, 0.002), quat=_quat_axis_angle((0, 0, 1), 0.40), tag="score")
        return hh

    if k == "vegetable":
        hh = primary("ellipsoid", (0.034, 0.034, 0.036), (0.16, 0.56, 0.18, 1.0), 0.16, 0.036)
        for dx, dy in ((0.012, 0.0), (-0.012, 0.0), (0.0, 0.012), (0.0, -0.012)):
            deco("ellipsoid", (0.18, 0.60, 0.20, 1.0), pos=(dx, dy, -0.001), size=(0.024, 0.024, 0.034), tag="lobe")
        deco("capsule", (0.12, 0.36, 0.12, 1.0), fromto=(0.0, 0.0, 0.032, 0.004, 0.0, 0.048), size=0.004, tag="stem")
        return hh

    if k == "egg":
        hh = primary("ellipsoid", (0.030, 0.022, 0.022), (0.93, 0.87, 0.78, 1.0), 0.06, 0.022)
        deco("ellipsoid", (0.95, 0.90, 0.82, 1.0), pos=(0.010, 0.0, 0.0), size=(0.021, 0.017, 0.017), tag="tip")
        return hh

    if k == "plate":
        hh = primary("cylinder", (0.070, 0.007), (0.94, 0.93, 0.90, 1.0), 0.26, 0.007)
        _add_ring(body, namer, (0.0, 0.0, 0.0045), 0.071, 0.0030, (0.26, 0.42, 0.58, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.98, 0.97, 0.95, 1.0), pos=(0.0, 0.0, 0.0064), size=(0.048, 0.0012), tag="dish")
        _add_ring(body, namer, (0.0, 0.0, -0.0052), 0.044, 0.0018, (0.84, 0.82, 0.78, 1.0), plane="xy", n=12, mass=0.0)
        return hh

    if k == "bowl":
        hh = primary("cylinder", (0.046, 0.024), (0.84, 0.80, 0.74, 1.0), 0.24, 0.024)
        _add_ring(body, namer, (0.0, 0.0, 0.0215), 0.047, 0.0030, (0.72, 0.34, 0.22, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.58, 0.54, 0.50, 1.0), pos=(0.0, 0.0, 0.0235), size=(0.041, 0.0012), tag="dish")
        _add_ring(body, namer, (0.0, 0.0, -0.0215), 0.032, 0.0022, (0.74, 0.70, 0.65, 1.0), plane="xy", n=12, mass=0.0)
        return hh

    if k == "pot":
        hh = primary("cylinder", (0.058, 0.036), (0.74, 0.76, 0.79, 1.0), 0.42, 0.036)
        _add_ring(body, namer, (0.0, 0.0, 0.0335), 0.060, 0.0030, (0.86, 0.88, 0.91, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.34, 0.36, 0.40, 1.0), pos=(0.0, 0.0, 0.0355), size=(0.053, 0.0012), tag="dish")
        deco("cylinder", (0.72, 0.44, 0.26, 1.0), pos=(0.0, 0.0, -0.028), size=(0.059, 0.007), tag="base")
        for sgn in (-1.0, 1.0):
            deco("cylinder", (0.20, 0.22, 0.24, 1.0), fromto=(sgn * 0.056, -0.014, 0.018, sgn * 0.072, -0.014, 0.020), size=0.0035, tag="handle")
            deco("cylinder", (0.20, 0.22, 0.24, 1.0), fromto=(sgn * 0.056, 0.014, 0.018, sgn * 0.072, 0.014, 0.020), size=0.0035, tag="handle")
            deco("capsule", (0.18, 0.20, 0.22, 1.0), fromto=(sgn * 0.072, -0.016, 0.020, sgn * 0.072, 0.016, 0.020), size=0.0045, tag="handle")
        return hh

    if k == "knife":
        hh = primary("box", (0.066, 0.0085, 0.005), (0.78, 0.80, 0.83, 1.0), 0.08, 0.005)
        deco("box", (0.38, 0.24, 0.16, 1.0), pos=(-0.032, 0.0, 0.0), size=(0.035, 0.0095, 0.005), tag="handle")
        deco("box", (0.64, 0.66, 0.70, 1.0), pos=(0.004, 0.0, 0.0), size=(0.005, 0.0095, 0.005), tag="bolster")
        deco("cylinder", (0.80, 0.82, 0.85, 1.0), pos=(0.064, 0.0, 0.0), size=(0.0085, 0.0025), tag="blunttip")
        return hh

    if k == "spoon":
        hh = primary("box", (0.064, 0.0085, 0.005), (0.80, 0.82, 0.85, 1.0), 0.06, 0.005)
        deco("ellipsoid", (0.82, 0.84, 0.87, 1.0), pos=(0.048, 0.0, 0.0), size=(0.021, 0.014, 0.0048), tag="bowl")
        deco("ellipsoid", (0.62, 0.65, 0.68, 1.0), pos=(0.048, 0.0, 0.0025), size=(0.016, 0.010, 0.0022), tag="well")
        deco("capsule", (0.74, 0.76, 0.80, 1.0), fromto=(-0.062, 0.0, 0.0, -0.010, 0.0, 0.0), size=0.0048, tag="stem")
        return hh

    if k == "fork":
        hh = primary("box", (0.064, 0.0085, 0.005), (0.80, 0.82, 0.85, 1.0), 0.06, 0.005)
        deco("capsule", (0.74, 0.76, 0.80, 1.0), fromto=(-0.062, 0.0, 0.0, 0.020, 0.0, 0.0), size=0.0048, tag="stem")
        deco("box", (0.80, 0.82, 0.85, 1.0), pos=(0.032, 0.0, 0.0), size=(0.008, 0.011, 0.003), tag="neck")
        for ty in (-0.0075, -0.0025, 0.0025, 0.0075):
            deco("capsule", (0.82, 0.84, 0.87, 1.0), fromto=(0.038, ty, 0.0, 0.067, ty, 0.0), size=0.0017, tag="tine")
        return hh

    if k == "cup":
        hh = primary("cylinder", (0.034, 0.046), (0.88, 0.91, 0.94, 1.0), 0.16, 0.046)
        _add_ring(body, namer, (0.0, 0.0, 0.0445), 0.0345, 0.0022, (0.95, 0.96, 0.97, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.42, 0.48, 0.54, 1.0), pos=(0.0, 0.0, 0.0455), size=(0.030, 0.0010), tag="well")
        deco("cylinder", (0.82, 0.56, 0.36, 1.0), pos=(0.0, 0.0, -0.004), size=(0.035, 0.016), tag="sleeve")
        return hh

    if k == "mug":
        hh = primary("cylinder", (0.036, 0.044), (0.18, 0.36, 0.58, 1.0), 0.28, 0.044)
        _add_ring(body, namer, (0.0, 0.0, 0.0425), 0.0365, 0.0022, (0.92, 0.91, 0.88, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.28, 0.18, 0.12, 1.0), pos=(0.0, 0.0, 0.0435), size=(0.032, 0.0010), tag="coffee")
        deco("capsule", (0.18, 0.36, 0.58, 1.0), fromto=(0.034, 0.0, 0.022, 0.050, 0.0, 0.022), size=0.0045, tag="handle")
        deco("capsule", (0.18, 0.36, 0.58, 1.0), fromto=(0.034, 0.0, -0.020, 0.050, 0.0, -0.020), size=0.0045, tag="handle")
        deco("capsule", (0.18, 0.36, 0.58, 1.0), fromto=(0.050, 0.0, -0.020, 0.050, 0.0, 0.022), size=0.0048, tag="handle")
        return hh

    if k == "bottle":
        hh = primary("cylinder", (0.031, 0.056), (0.16, 0.50, 0.36, 0.88), 0.36, 0.056)
        deco("cylinder", (0.94, 0.92, 0.86, 1.0), pos=(0.0, 0.0, -0.004), size=(0.0318, 0.026), tag="label")
        deco("cylinder", (0.16, 0.50, 0.36, 0.88), pos=(0.0, 0.0, 0.064), size=(0.023, 0.010), tag="shoulder")
        deco("cylinder", (0.16, 0.50, 0.36, 0.88), pos=(0.0, 0.0, 0.078), size=(0.013, 0.012), tag="neck")
        deco("cylinder", (0.84, 0.18, 0.16, 1.0), pos=(0.0, 0.0, 0.092), size=(0.0145, 0.007), tag="cap")
        return hh

    if k == "jar":
        hh = primary("cylinder", (0.036, 0.044), (0.76, 0.36, 0.14, 0.90), 0.32, 0.044)
        deco("cylinder", (0.95, 0.92, 0.84, 1.0), pos=(0.0, 0.0, -0.004), size=(0.0368, 0.020), tag="label")
        deco("cylinder", (0.86, 0.90, 0.92, 0.55), pos=(0.0, 0.0, 0.046), size=(0.030, 0.005), tag="collar")
        deco("cylinder", (0.82, 0.68, 0.28, 1.0), pos=(0.0, 0.0, 0.053), size=(0.033, 0.008), tag="lid")
        return hh

    if k == "carton":
        hh = primary("box", (0.033, 0.033, 0.056), (0.94, 0.95, 0.96, 1.0), 0.34, 0.056)
        deco("box", (0.18, 0.44, 0.78, 1.0), pos=(0.0, 0.0, -0.012), size=(0.0338, 0.0338, 0.022), tag="band")
        deco("box", (0.94, 0.95, 0.96, 1.0), pos=(0.0, -0.014, 0.067), size=(0.032, 0.022, 0.006), quat=_quat_axis_angle((1, 0, 0), 0.65), tag="gable")
        deco("box", (0.94, 0.95, 0.96, 1.0), pos=(0.0, 0.014, 0.067), size=(0.032, 0.022, 0.006), quat=_quat_axis_angle((1, 0, 0), -0.65), tag="gable")
        deco("box", (0.86, 0.88, 0.91, 1.0), pos=(0.0, 0.0, 0.080), size=(0.032, 0.003, 0.006), tag="fin")
        deco("cylinder", (0.96, 0.96, 0.97, 1.0), pos=(0.012, -0.016, 0.072), size=(0.008, 0.005), quat=_quat_axis_angle((1, 0, 0), 0.65), tag="spout")
        return hh

    if k == "bin":
        hh = primary("box", (0.046, 0.038, 0.034), (0.18, 0.42, 0.68, 1.0), 0.16, 0.034)
        deco("box", (0.14, 0.34, 0.56, 1.0), pos=(0.0, 0.0, 0.032), size=(0.049, 0.041, 0.0035), tag="rim")
        deco("box", (0.10, 0.22, 0.36, 1.0), pos=(0.0, 0.0, 0.0348), size=(0.041, 0.033, 0.0012), tag="well")
        deco("box", (0.94, 0.94, 0.92, 1.0), pos=(0.0, -0.0385, 0.004), size=(0.024, 0.0015, 0.012), tag="label")
        return hh

    if k == "soap":
        hh = primary("box", (0.040, 0.026, 0.013), (0.86, 0.92, 0.86, 1.0), 0.11, 0.013)
        deco("ellipsoid", (0.89, 0.94, 0.89, 1.0), pos=(0.0, 0.0, 0.0), size=(0.043, 0.028, 0.013), tag="bevel")
        deco("ellipsoid", (0.78, 0.85, 0.78, 1.0), pos=(0.0, 0.0, 0.0122), size=(0.022, 0.012, 0.0015), tag="stamp")
        return hh

    if k == "sponge":
        hh = primary("box", (0.046, 0.030, 0.015), (0.94, 0.82, 0.22, 1.0), 0.035, 0.015)
        deco("box", (0.16, 0.44, 0.22, 1.0), pos=(0.0, 0.0, 0.0125), size=(0.0465, 0.0305, 0.0035), tag="scour")
        return hh

    if k == "towel":
        hh = primary("box", (0.048, 0.038, 0.015), (0.36, 0.58, 0.56, 1.0), 0.14, 0.015)
        for sx in (-1.0, 1.0):
            deco("capsule", (0.34, 0.56, 0.54, 1.0), fromto=(sx * 0.046, -0.035, 0.0, sx * 0.046, 0.035, 0.0), size=0.014, tag="fold")
        deco("box", (0.86, 0.90, 0.89, 1.0), pos=(0.0, -0.024, 0.0148), size=(0.046, 0.004, 0.001), tag="dobby")
        deco("box", (0.26, 0.44, 0.42, 1.0), pos=(0.0, -0.0385, 0.0), size=(0.044, 0.0015, 0.002), tag="seam")
        return hh

    if k == "rag":
        hh = primary("box", (0.046, 0.040, 0.010), (0.76, 0.28, 0.24, 1.0), 0.05, 0.010)
        deco("box", (0.72, 0.25, 0.21, 1.0), pos=(0.002, 0.002, 0.004), size=(0.043, 0.037, 0.006), quat=_quat_axis_angle((0, 0, 1), 0.14), tag="layer")
        deco("box", (0.86, 0.42, 0.36, 1.0), pos=(0.0, -0.038, 0.0095), size=(0.044, 0.002, 0.001), tag="hem")
        return hh

    if k == "boot":
        hh = primary("box", (0.060, 0.026, 0.020), (0.48, 0.30, 0.18, 1.0), 0.38, 0.020)
        deco("box", (0.16, 0.16, 0.17, 1.0), pos=(0.0, 0.0, -0.016), size=(0.062, 0.027, 0.004), tag="sole")
        deco("ellipsoid", (0.46, 0.28, 0.17, 1.0), pos=(0.044, 0.0, -0.002), size=(0.024, 0.024, 0.017), tag="toe")
        deco("cylinder", (0.48, 0.30, 0.18, 1.0), pos=(-0.022, 0.0, 0.036), size=(0.025, 0.032), tag="shaft")
        _add_ring(body, namer, (-0.022, 0.0, 0.067), 0.025, 0.0045, (0.24, 0.16, 0.11, 1.0), plane="xy", n=10, mass=0.0)
        for lz in (0.022, 0.036, 0.050):
            deco("capsule", (0.84, 0.74, 0.56, 1.0), fromto=(0.004, -0.012, lz, 0.004, 0.012, lz), size=0.0022, tag="lace")
        return hh

    if k == "book":
        hh = primary("box", (0.066, 0.046, 0.014), (0.20, 0.26, 0.44, 1.0), 0.30, 0.014)
        deco("box", (0.95, 0.93, 0.87, 1.0), pos=(0.004, 0.0, 0.0), size=(0.063, 0.043, 0.0105), tag="pages")
        deco("cylinder", (0.18, 0.23, 0.40, 1.0), fromto=(-0.066, -0.045, 0.0, -0.066, 0.045, 0.0), size=0.0138, tag="spine")
        deco("box", (0.82, 0.68, 0.28, 1.0), pos=(0.006, 0.0, 0.0142), size=(0.032, 0.020, 0.0008), tag="title")
        return hh

    if k == "paper":
        hh = primary("box", (0.048, 0.036, 0.004), (0.96, 0.96, 0.94, 1.0), 0.025, 0.004)
        deco("box", (0.24, 0.46, 0.72, 1.0), pos=(0.0, 0.022, 0.0042), size=(0.038, 0.004, 0.0005), tag="hdr")
        for ly in (0.008, -0.002, -0.012, -0.022):
            deco("box", (0.58, 0.60, 0.64, 1.0), pos=(-0.004, ly, 0.0042), size=(0.032, 0.0018, 0.0005), tag="line")
        return hh

    if k == "card":
        hh = primary("box", (0.043, 0.027, 0.003), (0.18, 0.56, 0.62, 1.0), 0.020, 0.003)
        deco("box", (0.86, 0.72, 0.28, 1.0), pos=(-0.022, 0.004, 0.0032), size=(0.007, 0.0055, 0.0005), tag="chip")
        deco("box", (0.94, 0.96, 0.96, 1.0), pos=(0.012, -0.010, 0.0032), size=(0.022, 0.004, 0.0005), tag="bar")
        return hh

    if k == "pen":
        hh = primary("capsule", (0.006, 0.056), (0.14, 0.24, 0.48, 1.0), 0.022, 0.006, quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi))
        deco("cylinder", (0.14, 0.15, 0.17, 1.0), pos=(0.024, 0.0, 0.0), size=(0.0064, 0.018), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi), tag="grip")
        deco("cylinder", (0.82, 0.84, 0.87, 1.0), pos=(0.062, 0.0, 0.0), size=(0.0035, 0.008), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi), tag="tip")
        deco("cylinder", (0.82, 0.84, 0.87, 1.0), pos=(-0.062, 0.0, 0.0), size=(0.0045, 0.005), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi), tag="click")
        deco("box", (0.82, 0.84, 0.87, 1.0), pos=(-0.036, 0.0075, 0.0), size=(0.018, 0.0015, 0.002), tag="clip")
        return hh

    if k == "ball":
        hh = primary("sphere", (0.034,), (0.84, 0.88, 0.24, 1.0), 0.06, 0.034)
        deco("ellipsoid", (0.96, 0.96, 0.94, 1.0), pos=(0.0, 0.0, 0.0), size=(0.0344, 0.0344, 0.003), tag="seam")
        deco("ellipsoid", (0.96, 0.96, 0.94, 1.0), pos=(0.0, 0.0, 0.0), size=(0.003, 0.0344, 0.0344), tag="seam")
        return hh

    if k == "pillow":
        hh = primary("box", (0.066, 0.052, 0.020), (0.86, 0.81, 0.72, 1.0), 0.18, 0.020)
        deco("ellipsoid", (0.88, 0.83, 0.74, 1.0), pos=(0.0, 0.0, 0.0), size=(0.069, 0.055, 0.020), tag="loft")
        deco("sphere", (0.64, 0.56, 0.46, 1.0), pos=(0.0, 0.0, 0.019), size=(0.005,), tag="tuft")
        return hh

    if k == "garment":
        hh = primary("box", (0.066, 0.052, 0.015), (0.26, 0.36, 0.44, 1.0), 0.22, 0.015)
        deco("box", (0.22, 0.31, 0.38, 1.0), pos=(-0.014, 0.036, 0.0155), size=(0.016, 0.009, 0.002), quat=_quat_axis_angle((0, 0, 1), -0.45), tag="collar")
        deco("box", (0.22, 0.31, 0.38, 1.0), pos=(0.014, 0.036, 0.0155), size=(0.016, 0.009, 0.002), quat=_quat_axis_angle((0, 0, 1), 0.45), tag="collar")
        for by in (0.020, 0.004, -0.012):
            deco("cylinder", (0.92, 0.92, 0.90, 1.0), pos=(0.0, by, 0.0155), size=(0.0035, 0.0012), tag="btn")
        return hh

    if k == "lid":
        hh = primary("cylinder", (0.046, 0.006), (0.76, 0.78, 0.81, 1.0), 0.14, 0.006)
        _add_ring(body, namer, (0.0, 0.0, 0.0045), 0.0465, 0.0025, (0.86, 0.88, 0.90, 1.0), plane="xy", n=12, mass=0.0)
        deco("ellipsoid", (0.68, 0.82, 0.88, 0.55), pos=(0.0, 0.0, 0.004), size=(0.040, 0.040, 0.007), tag="dome")
        deco("cylinder", (0.18, 0.20, 0.22, 1.0), pos=(0.0, 0.0, 0.015), size=(0.0055, 0.006), tag="stem")
        deco("cylinder", (0.18, 0.20, 0.22, 1.0), pos=(0.0, 0.0, 0.022), size=(0.012, 0.004), tag="knob")
        return hh

    if k == "tray":
        hh = primary("box", (0.072, 0.050, 0.006), (0.74, 0.58, 0.38, 1.0), 0.20, 0.006)
        deco("box", (0.64, 0.48, 0.30, 1.0), pos=(0.0, 0.0, 0.0058), size=(0.064, 0.042, 0.0008), tag="liner")
        for sy in (-1.0, 1.0):
            deco("box", (0.68, 0.52, 0.34, 1.0), pos=(0.0, sy * 0.048, 0.0075), size=(0.072, 0.0035, 0.0055), tag="rail")
        for sx in (-1.0, 1.0):
            deco("box", (0.68, 0.52, 0.34, 1.0), pos=(sx * 0.070, 0.0, 0.0075), size=(0.0035, 0.050, 0.0055), tag="rail")
            deco("capsule", (0.58, 0.42, 0.26, 1.0), fromto=(sx * 0.071, -0.018, 0.014, sx * 0.071, 0.018, 0.014), size=0.0035, tag="handle")
        return hh

    if k == "dish":
        hh = primary("box", (0.062, 0.044, 0.015), (0.78, 0.24, 0.22, 1.0), 0.30, 0.015)
        for sy in (-1.0, 1.0):
            deco("box", (0.95, 0.94, 0.91, 1.0), pos=(0.0, sy * 0.043, 0.0145), size=(0.063, 0.003, 0.0028), tag="rim")
        for sx in (-1.0, 1.0):
            deco("box", (0.95, 0.94, 0.91, 1.0), pos=(sx * 0.061, 0.0, 0.0145), size=(0.003, 0.045, 0.0028), tag="rim")
            deco("box", (0.78, 0.24, 0.22, 1.0), pos=(sx * 0.069, 0.0, 0.010), size=(0.008, 0.020, 0.004), tag="handle")
        deco("box", (0.94, 0.92, 0.88, 1.0), pos=(0.0, 0.0, 0.0148), size=(0.056, 0.038, 0.0010), tag="well")
        return hh

    if k == "packet":
        hh = primary("box", (0.044, 0.034, 0.009), (0.88, 0.62, 0.16, 1.0), 0.045, 0.009)
        deco("ellipsoid", (0.90, 0.64, 0.18, 1.0), pos=(0.0, 0.0, 0.0), size=(0.040, 0.031, 0.009), tag="puff")
        for sx in (-1.0, 1.0):
            deco("box", (0.80, 0.82, 0.85, 1.0), pos=(sx * 0.046, 0.0, 0.0), size=(0.004, 0.034, 0.002), tag="crimp")
        deco("box", (0.96, 0.95, 0.92, 1.0), pos=(0.0, 0.0, 0.0092), size=(0.024, 0.018, 0.0006), tag="label")
        return hh

    if k == "plug":
        hh = primary("box", (0.024, 0.018, 0.015), (0.18, 0.19, 0.21, 1.0), 0.065, 0.015)
        for sy in (-0.0065, 0.0065):
            deco("box", (0.84, 0.72, 0.28, 1.0), pos=(0.033, sy, 0.003), size=(0.010, 0.0012, 0.0038), tag="prong")
        deco("cylinder", (0.84, 0.72, 0.28, 1.0), pos=(0.034, 0.0, -0.006), size=(0.0024, 0.011), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi), tag="ground")
        deco("cylinder", (0.14, 0.15, 0.17, 1.0), pos=(-0.030, 0.0, 0.0), size=(0.009, 0.009), quat=_quat_axis_angle((0, 1, 0), 0.5 * math.pi), tag="boot")
        deco("capsule", (0.14, 0.15, 0.17, 1.0), fromto=(-0.038, 0.0, 0.0, -0.048, 0.006, 0.0), size=0.0045, tag="cord")
        return hh

    if k == "token":
        hh = primary("cylinder", (0.022, 0.005), (0.84, 0.66, 0.22, 1.0), 0.025, 0.005)
        _add_ring(body, namer, (0.0, 0.0, 0.0032), 0.021, 0.0018, (0.92, 0.76, 0.30, 1.0), plane="xy", n=12, mass=0.0)
        deco("cylinder", (0.68, 0.18, 0.18, 1.0), pos=(0.0, 0.0, 0.0048), size=(0.014, 0.0008), tag="emblem")
        deco("cylinder", (0.68, 0.18, 0.18, 1.0), pos=(0.0, 0.0, -0.0048), size=(0.014, 0.0008), tag="emblem")
        return hh

    if k == "tool":
        hh = primary("box", (0.064, 0.011, 0.008), (0.70, 0.73, 0.77, 1.0), 0.18, 0.008)
        deco("box", (0.80, 0.20, 0.16, 1.0), pos=(-0.028, 0.0, 0.0), size=(0.034, 0.0125, 0.008), tag="grip")
        deco("cylinder", (0.70, 0.73, 0.77, 1.0), pos=(-0.062, 0.0, 0.0), size=(0.013, 0.006), tag="ringend")
        for sy in (-0.010, 0.010):
            deco("box", (0.72, 0.75, 0.79, 1.0), pos=(0.062, sy, 0.0), size=(0.012, 0.0045, 0.0065), tag="jaw")
        return hh

    return primary("box", (0.035, 0.035, 0.035), (0.60, 0.62, 0.66, 1.0), 0.12, 0.035)


if __name__ == "__main__":
    mj = ET.Element("mujoco", {"model": "stations_and_props"})
    ET.SubElement(mj, "compiler", {"angle": "radian"})
    wb = ET.SubElement(mj, "worldbody")
    ET.SubElement(wb, "geom", {"name": "ground", "type": "plane", "size": "20 20 0.1", "rgba": "0.85 0.85 0.85 1"})

    fixture_kinds = [
        "counter", "microwave", "refrigerator", "stove", "sink", "shelf",
        "bin", "table", "chair", "bed", "closet", "copier",
        "scanner", "washer", "station", "door", "oven", "cart",
        "checkpoint", "window", "sofa", "bookcase", "coffee_machine", "floor",
    ]
    prop_kinds = [
        "apple", "bread", "vegetable", "egg", "plate", "bowl", "pot",
        "knife", "spoon", "fork", "cup", "mug", "bottle", "jar",
        "carton", "bin", "soap", "sponge", "towel", "rag", "boot",
        "book", "paper", "card", "pen", "ball", "pillow", "garment",
        "lid", "tray", "dish", "packet", "plug", "token", "tool",
    ]

    for i, fk in enumerate(fixture_kinds):
        col = i % 6
        row = i // 6
        fx = col * 1.4
        fy = row * 1.4
        fz = 0.68 + 0.05 * (i % 6)
        fw = 0.44 + 0.08 * (i % 6)
        fd = 0.45
        fixture(wb, f"fx_{fk}", fk, fx, fy, fz, fw, fd)

    for i, pk in enumerate(prop_kinds):
        col = i % 7
        row = i // 7
        pb = ET.SubElement(wb, "body", {"name": f"prop_body_{pk}", "pos": _vec(col * 0.25, -1.5 - row * 0.25, 0.0)})
        ET.SubElement(pb, "freejoint", {"name": f"fj_{pk}"})
        hh = prop(pb, f"pr_{pk}", pk)
        pb.set("pos", _vec(col * 0.25, -1.5 - row * 0.25, hh))

    xml_str = ET.tostring(mj, encoding="unicode")
    print(f"Generated valid MJCF XML ({len(xml_str)} chars) with {len(fixture_kinds)} fixtures and {len(prop_kinds)} props.")
