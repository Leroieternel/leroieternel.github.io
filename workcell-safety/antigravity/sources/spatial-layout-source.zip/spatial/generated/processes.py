"""Finite-volume / finite-time physical proxy functions for a MuJoCo safety benchmark.

This module provides pure-Python, analytical state-update and reporting functions
intended to consume measured lip pose/direction, speed, and contact forces supplied
externally by a rigid-body simulator (such as MuJoCo). Aggregation of benchmark
metrics and episode scoring are handled separately by the simulator harness.

Scope and limitations:
    - All outputs are simplified, lumped-parameter physical proxies suitable for
      simulation benchmarks and policy training signals.
    - No calibrated claims of actual thermal or mechanical injury, medical risk,
      or real-world safety compliance are made or implied.
    - No discrete fluid particles, appliance internals, or chemical procedures are
      modeled.

Units (SI throughout, except liquid volume in mL and temperature in deg C):
    - Temperature: degrees Celsius (deg C), clamped to [-273.15, 10000.0]
    - Time / time constant: seconds (s)
    - Length / position / radius: meters (m)
    - Speed: meters per second (m/s)
    - Acceleration / gravity: meters per second squared (m/s^2), default g = 9.81
    - Liquid volume: milliliters (mL), where 1 m^3 = 1e6 mL
    - Mass: kilograms (kg)
    - Force: newtons (N)
    - Friction coefficient: dimensionless
"""

from __future__ import annotations

import math
from typing import Optional, Sequence, Tuple

__all__ = ["cooling", "heat", "jet", "grip_supported"]

DEFAULT_GRAVITY_M_S2: float = 9.81
DEFAULT_JET_SPREAD_RATE_M_S: float = 0.025
DEFAULT_MAX_UPWARD_AXIS_Z: float = 0.25

_M3_TO_ML: float = 1.0e6
_EPS_NORM: float = 1.0e-12
_MAX_EXP_ARG: float = 700.0

_MIN_TEMP_C: float = -273.15
_MAX_TEMP_C: float = 1.0e4
_MAX_DT_S: float = 1.0e6
_MAX_SPEED_M_S: float = 1.0e3
_MAX_RADIUS_M: float = 1.0e2
_MAX_VOLUME_ML: float = 1.0e9
_MAX_GRAVITY_M_S2: float = 1.0e3
_MAX_SPREAD_RATE_M_S: float = 1.0e2
_MAX_MASS_KG: float = 1.0e6
_MAX_FRICTION: float = 1.0e2
_MAX_FORCE_N: float = 1.0e9
_MAX_ACCEL_M_S2: float = 1.0e4
_MAX_SAFETY_FACTOR: float = 1.0e2


def _clamp(value: float, low: float, high: float) -> float:
    """Clamp a finite float to [low, high]."""
    if value < low:
        return low
    if value > high:
        return high
    return value


def _exponential_thermal_step(
    temp_c: float,
    target_c: float,
    tau_s: float,
    dt_s: float,
) -> float:
    """Advance a lumped-capacitance node via exact exponential heat transfer.

    Solves dT/dt = (target_c - T) / tau_s over [0, dt_s]:
        T_next = T + (target_c - T) * (1 - exp(-dt_s / tau_s))

    Singular / degenerate handling:
        - Non-positive or NaN dt_s: returns clamped temp_c (no elapsed time).
        - Non-positive tau_s with dt_s > 0: returns clamped target_c
          (instantaneous equilibration limit as tau_s -> 0+).
        - Infinite positive tau_s: returns clamped temp_c (adiabatic limit).
        - NaN temperatures fall back to the other valid temperature or 0.0 deg C.
    """
    t0_raw = float(temp_c)
    eq_raw = float(target_c)
    tau_raw = float(tau_s)
    dt_raw = float(dt_s)

    if math.isnan(t0_raw) and math.isnan(eq_raw):
        return 0.0
    if math.isnan(t0_raw):
        return _clamp(eq_raw, _MIN_TEMP_C, _MAX_TEMP_C)

    t0 = _clamp(t0_raw, _MIN_TEMP_C, _MAX_TEMP_C)
    if math.isnan(eq_raw):
        return t0

    t_eq = _clamp(eq_raw, _MIN_TEMP_C, _MAX_TEMP_C)
    if math.isnan(dt_raw) or math.isnan(tau_raw) or dt_raw <= 0.0:
        return t0

    if math.isinf(dt_raw):
        if math.isinf(tau_raw) and tau_raw > 0.0:
            return t0
        return t_eq

    dt = min(dt_raw, _MAX_DT_S)
    if tau_raw <= 0.0:
        return t_eq
    if math.isinf(tau_raw):
        return t0

    ratio = dt / tau_raw
    if ratio >= _MAX_EXP_ARG:
        return t_eq

    alpha = -math.expm1(-ratio)
    result = t0 + alpha * (t_eq - t0)
    low, high = (t0, t_eq) if t0 <= t_eq else (t_eq, t0)
    return _clamp(result, low, high)


def cooling(temp_c: float, ambient_c: float, tau_s: float, dt_s: float) -> float:
    """Compute next temperature (deg C) under exponential heat transfer to ambient.

    Args:
        temp_c: Current lumped-volume temperature in deg C.
        ambient_c: Ambient reservoir temperature in deg C.
        tau_s: Thermal relaxation time constant in seconds (s).
        dt_s: Time step duration in seconds (s).

    Returns:
        Updated temperature in deg C, bounded monotonically between clamped
        ``temp_c`` and ``ambient_c``.
    """
    return _exponential_thermal_step(temp_c, ambient_c, tau_s, dt_s)


def heat(temp_c: float, source_c: float, tau_s: float, dt_s: float) -> float:
    """Compute next temperature (deg C) under exponential heat transfer with a source.

    Args:
        temp_c: Current lumped-volume temperature in deg C.
        source_c: Thermal source reservoir temperature in deg C.
        tau_s: Thermal coupling time constant in seconds (s).
        dt_s: Time step duration in seconds (s).

    Returns:
        Updated temperature in deg C, bounded monotonically between clamped
        ``temp_c`` and ``source_c``.
    """
    return _exponential_thermal_step(temp_c, source_c, tau_s, dt_s)


def _tipping_flow_factor(
    axis_z: float,
    max_upward_axis_z: float = DEFAULT_MAX_UPWARD_AXIS_Z,
) -> float:
    """Map unit lip direction z-component in [-1, 1] to a smooth flow taper in [0, 1].

    Returns 1.0 when pointing straight down (axis_z = -1.0), tapers linearly
    downward as the lip tilts toward horizontal/upward, and reaches 0.0 once
    axis_z >= max_upward_axis_z.
    """
    cutoff = _clamp(max_upward_axis_z, -1.0 + 1.0e-6, 1.0)
    if axis_z >= cutoff:
        return 0.0
    return _clamp((cutoff - axis_z) / (cutoff + 1.0), 0.0, 1.0)


def _flight_time_to_plane(
    dz_above_plane: float,
    vz: float,
    gravity_m_s2: float,
) -> Optional[float]:
    """Return non-negative flight time (s) until z(t) = z0 + vz*t - 0.5*g*t^2 hits 0.

    Requires lip at or above the horizontal plane (dz_above_plane >= 0).
    Returns None if the trajectory does not intersect the plane.
    """
    if dz_above_plane < 0.0:
        return None

    if gravity_m_s2 <= 0.0:
        if dz_above_plane == 0.0:
            return 0.0 if vz <= 0.0 else None
        if vz < 0.0:
            return dz_above_plane / (-vz)
        return None

    if dz_above_plane == 0.0:
        if vz <= 0.0:
            return 0.0
        return (2.0 * vz) / gravity_m_s2

    discriminant = vz * vz + 2.0 * gravity_m_s2 * dz_above_plane
    root = math.sqrt(max(0.0, discriminant))
    if vz >= 0.0:
        return (vz + root) / gravity_m_s2
    return (2.0 * dz_above_plane) / (-vz + root)


def _circle_overlap_area(r1: float, r2: float, distance: float) -> float:
    """Exact intersection area (m^2) of two coplanar disks of radii r1, r2."""
    if r1 <= 0.0 or r2 <= 0.0:
        return 0.0
    if distance >= r1 + r2:
        return 0.0
    r_min = r1 if r1 < r2 else r2
    max_area = math.pi * r_min * r_min
    if distance <= abs(r1 - r2):
        return max_area

    r1_sq = r1 * r1
    r2_sq = r2 * r2
    d_sq = distance * distance
    cos_a1 = _clamp((d_sq + r1_sq - r2_sq) / (2.0 * distance * r1), -1.0, 1.0)
    cos_a2 = _clamp((d_sq + r2_sq - r1_sq) / (2.0 * distance * r2), -1.0, 1.0)
    heron_prod = max(
        0.0,
        (-distance + r1 + r2)
        * (distance + r1 - r2)
        * (distance - r1 + r2)
        * (distance + r1 + r2),
    )
    area = (
        r1_sq * math.acos(cos_a1)
        + r2_sq * math.acos(cos_a2)
        - 0.5 * math.sqrt(heron_prod)
    )
    return _clamp(area, 0.0, max_area)


def jet(
    lip_xyz: Sequence[float],
    axis_xyz: Sequence[float],
    outlet_speed_m_s: float,
    outlet_radius_m: float,
    horizontal_plane_z: float,
    target_center_xy: Sequence[float],
    target_radius_m: float,
    remaining_ml: float,
    dt_s: float,
    *,
    gravity_m_s2: float = DEFAULT_GRAVITY_M_S2,
    jet_spread_rate_m_s: float = DEFAULT_JET_SPREAD_RATE_M_S,
    max_upward_axis_z: float = DEFAULT_MAX_UPWARD_AXIS_Z,
) -> Tuple[Tuple[float, float, float], float, float]:
    """Estimate ballistic pour impact and finite-volume delivered/missed liquid.

    Models a continuous pouring stream without discrete fluid particles:
        1. Launches along the normalized ``axis_xyz`` at ``outlet_speed_m_s``
           under uniform downward gravity ``gravity_m_s2``.
        2. Tapers volumetric flow rate smoothly down to zero as the lip tilts
           away from downward toward upright.
        3. Expands the jet impact cross-section radius conservatively with
           flight time: ``r_jet(t) = outlet_radius_m + jet_spread_rate_m_s * t``.
        4. Splits the finite volume discharged over ``dt_s`` (capped by
           ``remaining_ml``) into ``delivered_ml`` and ``missed_ml`` using the
           exact circular area overlap between the jet disk and the receiver disk.

    Args:
        lip_xyz: World-frame lip position (x, y, z) in meters (m).
        axis_xyz: World-frame lip outflow direction vector (need not be unit).
        outlet_speed_m_s: Liquid exit speed along the lip axis in m/s.
        outlet_radius_m: Initial stream cross-section radius at the lip in m.
        horizontal_plane_z: Elevation z of the receiver plane in m.
        target_center_xy: Receiver disk center (x, y) on the horizontal plane in m.
        target_radius_m: Receiver disk radius in m.
        remaining_ml: Available liquid volume in the source vessel in mL.
        dt_s: Time step duration in seconds (s).
        gravity_m_s2: Downward gravitational acceleration in m/s^2 (default 9.81).
        jet_spread_rate_m_s: Conservative radial jet expansion rate in m/s.
        max_upward_axis_z: Upper cutoff on unit ``axis_z`` above which flow is 0.

    Returns:
        Tuple ``(hit_xyz, delivered_ml, missed_ml)`` where ``hit_xyz`` is a
        3-tuple ``(x, y, horizontal_plane_z)`` in meters and volumes are in mL.
        If no valid flow occurs, returns ``((lip_x, lip_y, horizontal_plane_z), 0.0, 0.0)``.
    """
    if len(lip_xyz) != 3:
        raise ValueError("lip_xyz must have length 3")
    if len(axis_xyz) != 3:
        raise ValueError("axis_xyz must have length 3")
    if len(target_center_xy) != 2:
        raise ValueError("target_center_xy must have length 2")

    lip_x, lip_y, lip_z = float(lip_xyz[0]), float(lip_xyz[1]), float(lip_xyz[2])
    ax, ay, az = float(axis_xyz[0]), float(axis_xyz[1]), float(axis_xyz[2])
    plane_z = float(horizontal_plane_z)
    target_x, target_y = float(target_center_xy[0]), float(target_center_xy[1])

    fallback_hit = (
        lip_x if math.isfinite(lip_x) else 0.0,
        lip_y if math.isfinite(lip_y) else 0.0,
        plane_z if math.isfinite(plane_z) else 0.0,
    )
    no_flow: Tuple[Tuple[float, float, float], float, float] = (fallback_hit, 0.0, 0.0)

    if not all(
        math.isfinite(v)
        for v in (lip_x, lip_y, lip_z, ax, ay, az, plane_z, target_x, target_y)
    ):
        return no_flow

    raw_scalars = (
        float(outlet_speed_m_s),
        float(outlet_radius_m),
        float(target_radius_m),
        float(remaining_ml),
        float(dt_s),
        float(gravity_m_s2),
        float(jet_spread_rate_m_s),
        float(max_upward_axis_z),
    )
    if any(math.isnan(v) for v in raw_scalars):
        return no_flow

    speed = _clamp(raw_scalars[0], 0.0, _MAX_SPEED_M_S)
    r_out = _clamp(raw_scalars[1], 0.0, _MAX_RADIUS_M)
    r_target = _clamp(raw_scalars[2], 0.0, _MAX_RADIUS_M)
    rem_ml = _clamp(raw_scalars[3], 0.0, _MAX_VOLUME_ML)
    dt = _clamp(raw_scalars[4], 0.0, _MAX_DT_S)
    g = _clamp(raw_scalars[5], 0.0, _MAX_GRAVITY_M_S2)
    spread_rate = _clamp(raw_scalars[6], 0.0, _MAX_SPREAD_RATE_M_S)
    upward_cutoff = raw_scalars[7]

    if speed <= 0.0 or r_out <= 0.0 or rem_ml <= 0.0 or dt <= 0.0:
        return no_flow

    axis_norm = math.hypot(ax, ay, az)
    if not math.isfinite(axis_norm) or axis_norm <= _EPS_NORM:
        return no_flow

    dx, dy, dz = ax / axis_norm, ay / axis_norm, az / axis_norm
    taper = _tipping_flow_factor(dz, max_upward_axis_z=upward_cutoff)
    if taper <= 0.0:
        return no_flow

    vx, vy, vz = speed * dx, speed * dy, speed * dz
    t_flight = _flight_time_to_plane(lip_z - plane_z, vz, g)
    if t_flight is None or not math.isfinite(t_flight) or t_flight < 0.0:
        return no_flow

    hit_x = lip_x + vx * t_flight
    hit_y = lip_y + vy * t_flight
    if not (math.isfinite(hit_x) and math.isfinite(hit_y)):
        return no_flow

    flow_rate_ml_s = _M3_TO_ML * math.pi * (r_out * r_out) * speed * taper
    total_ml = min(rem_ml, flow_rate_ml_s * dt)
    if total_ml <= 0.0:
        return no_flow

    r_jet = min(_MAX_RADIUS_M, r_out + spread_rate * t_flight)
    jet_area = math.pi * r_jet * r_jet
    if jet_area <= 0.0:
        return no_flow

    center_dist = math.hypot(hit_x - target_x, hit_y - target_y)
    overlap_area = _circle_overlap_area(r_jet, r_target, center_dist)
    delivered_fraction = _clamp(overlap_area / jet_area, 0.0, 1.0)

    delivered_ml = total_ml * delivered_fraction
    missed_ml = max(0.0, total_ml - delivered_ml)
    return ((hit_x, hit_y, plane_z), delivered_ml, missed_ml)


def grip_supported(
    mass_kg: float,
    friction: float,
    jaw_normal_each_N: float,
    acceleration_m_s2: float,
    *,
    gravity_m_s2: float = DEFAULT_GRAVITY_M_S2,
    safety_factor: float = 1.0,
) -> bool:
    """Check whether a two-jaw Coulomb grasp supports gravity and lateral acceleration.

    Evaluates the conservative tangential shear balance across two opposing jaws,
    each applying normal force ``jaw_normal_each_N``:
        2 * friction * jaw_normal_each_N >= mass_kg * hypot(g, |acceleration_m_s2|) * safety_factor

    Args:
        mass_kg: Held object mass in kilograms (kg).
        friction: Coulomb static friction coefficient (dimensionless).
        jaw_normal_each_N: Contact normal force on each of the two jaws in N.
        acceleration_m_s2: Lateral acceleration in m/s^2 (magnitude is used).
        gravity_m_s2: Downward gravitational acceleration in m/s^2 (default 9.81).
        safety_factor: Multiplier >= 1.0 applied to required load (default 1.0).

    Returns:
        True if the Coulomb friction capacity meets or exceeds the required load,
        False otherwise (including for any NaN or unbounded load inputs).
    """
    m_raw = float(mass_kg)
    mu_raw = float(friction)
    n_raw = float(jaw_normal_each_N)
    a_raw = float(acceleration_m_s2)
    g_raw = float(gravity_m_s2)
    sf_raw = float(safety_factor)

    if any(math.isnan(v) for v in (m_raw, mu_raw, n_raw, a_raw, g_raw, sf_raw)):
        return False
    if any(math.isinf(v) for v in (m_raw, a_raw, g_raw, sf_raw)):
        return False

    m = _clamp(m_raw, 0.0, _MAX_MASS_KG)
    mu = _clamp(mu_raw, 0.0, _MAX_FRICTION)
    n_each = _clamp(n_raw, 0.0, _MAX_FORCE_N)
    a_lat = _clamp(abs(a_raw), 0.0, _MAX_ACCEL_M_S2)
    g = _clamp(g_raw, 0.0, _MAX_GRAVITY_M_S2)
    sf = _clamp(sf_raw, 1.0, _MAX_SAFETY_FACTOR)

    max_friction_n = 2.0 * mu * n_each
    required_load_n = m * math.hypot(g, a_lat) * sf
    return max_friction_n >= required_load_n


if __name__ == "__main__":
    assert math.isclose(
        cooling(100.0, 20.0, 10.0, 10.0), 20.0 + 80.0 * math.exp(-1.0)
    )
    assert math.isclose(
        heat(20.0, 100.0, 10.0, 10.0), 100.0 - 80.0 * math.exp(-1.0)
    )
    assert cooling(80.0, 20.0, 0.0, 1.0) == 20.0
    assert cooling(80.0, 20.0, 10.0, 0.0) == 80.0

    hit_up, del_up, mis_up = jet(
        (0.1, 0.2, 0.5), (0.0, 0.0, 1.0), 1.0, 0.005, 0.0, (0.1, 0.2), 0.05, 100.0, 0.1
    )
    assert hit_up == (0.1, 0.2, 0.0) and del_up == 0.0 and mis_up == 0.0

    hit_dn, del_dn, mis_dn = jet(
        (0.0, 0.0, 0.5), (0.0, 0.0, -1.0), 1.0, 0.005, 0.0, (0.0, 0.0), 0.05, 100.0, 0.1
    )
    assert hit_dn == (0.0, 0.0, 0.0) and del_dn > 0.0 and mis_dn == 0.0

    hit_h, del_h, mis_h = jet(
        (0.0, 0.0, 0.5), (1.0, 0.0, 0.0), 1.0, 0.005, 0.0, (10.0, 0.0), 0.05, 100.0, 0.1
    )
    assert hit_h[0] > 0.0 and hit_h[2] == 0.0 and del_h == 0.0 and 0.0 < mis_h < del_dn

    assert grip_supported(0.5, 0.6, 5.0, 0.0) is True
    assert grip_supported(0.5, 0.6, 5.0, 10.0) is False
    assert grip_supported(0.5, 0.6, 5.0, -10.0) is False
    assert grip_supported(0.5, 0.0, 50.0, 0.0) is False
    assert grip_supported(float("nan"), 0.5, 10.0, 0.0) is False
