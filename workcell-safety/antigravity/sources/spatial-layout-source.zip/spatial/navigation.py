"""Waypoint routing in the aisle bounded by oriented work surfaces."""
import math
import numpy as np
import placement as pl

def inward(c,s):
    return pl.rotation(pl.room(c)[s][1]) @ np.array([0.,1.])

def accessible(c,loc,a,b):
    points=np.linspace(a,b,max(2,math.ceil(np.linalg.norm(b-a)/.045)+1))
    for s,(_,_,_,w,h) in loc.items():
        center,yaw,_=pl.room(c)[s]
        local=(points-center) @ pl.rotation(yaw)
        outside=np.maximum(abs(local)-[w/2,h/2],0.)
        if np.min(np.linalg.norm(outside,axis=1))<.28:return False
    return True

def route(c,loc,a,b):
    if accessible(c,loc,a,b):return [b]
    center=np.zeros(2)
    if accessible(c,loc,a,center) and accessible(c,loc,center,b):return [center,b]
    raise ValueError(('Blocked mobile route',c['id'],a,b))
