"""Compare every render transform in both camera passes against the saved MuJoCo poses."""
import hashlib,sys
import mujoco as mj
from common import *
def verify(c):
    run=folder(c);ex=D/'optics'/run.name;md=json.loads((ex/'meta.json').read_text());gids=[g['gid'] for g in md['objects']];m=mj.MjModel.from_xml_path(str(run/'scene.xml'));d=mj.MjData(m);counts={}
    for b in ('safe','unsafe'):
        poses=np.load(ex/(b+'.npz'))['poses'];q=np.load(run/(b+'.npz'))['qpos']
        assert len(poses)==len(q)
        for i,qq in enumerate(q):
            d.qpos[:]=qq;mj.mj_kinematics(m,d)
            measured=np.column_stack((d.geom_xmat[gids],d.geom_xpos[gids])).astype(np.float32)
            assert np.array_equal(poses[i],measured),(i,c['id'])
        counts[b]={'transform_frames':len(q),'geometries_per_frame':len(gids),'sha256':hashlib.sha256((run/(b+'.npz')).read_bytes()).hexdigest()}
    save(run/'pose-audit.json',counts);print(c['id'],counts['safe']['transform_frames']+counts['unsafe']['transform_frames'],flush=True)
if __name__=='__main__':verify(list(load_cases().values())[int(sys.argv[1])-1])
