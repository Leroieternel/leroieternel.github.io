"""Film stored MuJoCo poses in the native Genie Sim room designed by Antigravity."""
import sys,os,json,math,hashlib,bisect,csv,gzip
from pathlib import Path
import bpy,numpy as np
from mathutils import Vector, Matrix
D=Path(__file__).resolve().parent;H=D.parent/'hard1044';ROOT=D.parents[2]
sys.path.extend((str(H),str(ROOT/'outputs/paired_workcells'),str(ROOT/'outputs/mobile_worlds/library')))
import cycles_render as cr,world_assets as assets
from production import dressing
from production.dressing import dress
from generated.rooms import ROOMS
cr.CACHE=D/'optics'
base_round=cr.rounded
def rounded(g):
    ob=base_round(g)
    if g['kind']=='ellipsoid':
        dims=np.asarray(g['sz']);p=np.empty(len(ob.data.vertices)*3,dtype='f');ob.data.vertices.foreach_get('co',p);p.reshape(-1,3)[:]*=dims/dims[0];ob.data.vertices.foreach_set('co',p);ob.data.update()
    return ob
cr.rounded=rounded
def setup(rank):
    folder=next((D/'runs').glob(f'{rank:02d}_*'));info=json.loads((folder/'info.json').read_text());c=info['design'];media=D/'media'/c['id'];media.mkdir(exist_ok=True)
    conf=ROOMS[c['id']];floor,wall,a,b,u,v,side,elev,color=conf
    c.update(floor=floor,wall=wall,azimuth=132 if side>0 else 42,elevation=elev,kelvin=4600+rank%5*230,scene_group=c['scene'],furnishing=[a,b,u,v],room_note=c['setting'],light='Soft directional daylight and broad sky fill')
    view=cr.View(rank);view.pose('safe',0);scene=view.scene
    byname={g['name']:(j,g,ob) for j,(g,ob) in enumerate(zip(view.spec,view.obs))}
    for g,ob in zip(view.spec,view.obs):
        if g['name']=='floor':ob.hide_render=True
        elif g['kind']=='mesh':ob.data.polygons.foreach_set('use_smooth',np.ones(len(ob.data.polygons),bool))
    for ob in list(scene.objects):
        if ob.type=='LIGHT':bpy.data.objects.remove(ob,do_unlink=True)
    # Use the source setting explicitly. Text such as "slice" must never select an ice rink.
    sets={'Kitchen':('kitchen','indoor_kitchen',False),'Café':('kitchen','indoor_kitchen',False),'Laundry room':('bathroom','indoor_bathroom',False),'Dining room':('living','indoor_living',False),'Bedroom':('bedroom','indoor_bedroom',False),'Garage':('office','workshop',False),'Market stall':('garden','outdoor_garden',True),'Living room':('living','indoor_living',False),'Banquet hall':('living','indoor_living',False),'Laboratory':('hospital','clinical',False),'Print shop':('office','indoor_office',False)}
    dressing._classify_scene=lambda _case:('garden','outdoor_garden',True) if c['id']=='bddl_430' else sets[c['scene']]
    room=dress(scene,c,[0,.6,.85],True,assets)
    for st,kind in c['stations'].items():
        if kind in ('counter','table','bed','bookcase','shelf','cart','station','floor'):
            if 'top_'+st not in byname:continue
            ob=byname['top_'+st][2]
            key=floor if kind in ('bed','bookcase','shelf','table','floor') else wall
            ob.data.materials.clear();ob.data.materials.append(assets.pbr(key,1.65,'XY'))
    assets.align_planar_uvs()
    moving=[]
    substitute={'cup':'cup','mug':'mug','soap':'soap','carton':'carton','book':'book','pen':'pen','bottle':'water','bin':'bin','paper':'folder'}
    for item,(kind,st) in c['props'].items():
        if rank==1:continue
        key=substitute.get(kind)
        if not key:continue
        j,g,ob=byname['payload_'+item];hh=g['sz'][2] if g['kind'] in ('box','ellipsoid') else g['sz'][1] if g['kind'] in ('cylinder','capsule') else g['sz'][0];dims=assets.GENIE[key]['size_m'];scale=min(2*hh/dims[2],.155/max(dims[:2]))
        if scale<.22 or scale>2.4:continue
        copied=assets.place(key,[0,0,0],size=dims[2]*scale);moving.append((copied,j,hh,scale))
        for gg,proxy in zip(view.spec,view.obs):
            if gg['body']=='item_'+item:proxy.hide_render=True
    geometry={}
    for ob in scene.objects:
        if ob.instance_type=='COLLECTION' and ob.instance_collection:
            key=ob.instance_collection.name.removeprefix('Prototypes • ')
            if key in assets.GENIE:geometry[key]={field:assets.GENIE[key][field] for field in ('id','source','revision','sha256')}
    if rank==1:
        native=json.loads((D.parent/'long_horizon/appliance435/genie/assets.json').read_text())
        for key in ('apple','oven','plate','table','shelf','cup_one','cup_two','knife'):
            geometry[key]={'source':native[key]['source'],'revision':'12f41e388a953cc2aeb0fe5b8eb516750c8321d9'}
    surfaces={}
    for key in (floor,wall):
        assert any(key in m.name and m.users and m.node_tree for m in bpy.data.materials),(c['id'],key)
        surfaces[key]={ch:{'filename':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for ch,p in assets.finish_maps(key).items()}
    assert len(geometry)>=2
    (media/'appearance.json').write_text(json.dumps(dict(room=room,geometry=geometry,surfaces=surfaces,manifest=conf,renderer='Blender EEVEE Next'),indent=2,default=str))
    scene.render.engine='BLENDER_EEVEE_NEXT';scene.eevee.taa_render_samples=8;scene.eevee.use_shadows=True;scene.eevee.use_raytracing=True
    scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.render.fps=25;scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=90;scene.render.threads_mode='FIXED';scene.render.threads=4
    scene.render.use_persistent_data=True
    def colored(name,rgb):
        mat=bpy.data.materials.new(name);mat.diffuse_color=(*rgb,1);mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.17;return mat
    if c['id']=='bddl_430':
        door=info['placement']['stations']['garage_door']; ang=math.radians(door['heading_deg']);wet_center=np.array(door['dock_m'])-.255*np.array([-math.sin(ang),math.cos(ang)])
        bpy.ops.mesh.primitive_uv_sphere_add(segments=36,ring_count=12,location=(*wet_center,-.002));damp=bpy.context.object;damp.name='Wet floor after cleaning';damp.scale=(.16,.135,.003);damp.rotation_euler.z=ang
        damp.data.materials.append(colored('Wet concrete',(.089,.12,.123)))
    else:damp=None
    fluids=info['rule']['family']=='pour';fluid_mat=colored('Liquid film',(.19,.056,.016) if c['id']=='bddl_887' else (.75,.48,.09));dyn=[]
    if fluids:
        for name in ('stream','spill','caught'):
            if name=='stream':bpy.ops.mesh.primitive_cylinder_add(vertices=20,radius=1,depth=1)
            else:bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12)
            ob=bpy.context.object;ob.name=name;ob.data.materials.append(fluid_mat);dyn.append(ob)
    def camera(aim,delta,lens):
        cam=view.cam;cam.location=Vector(aim)+Vector(delta);cam.rotation_euler=(-Vector(delta)).to_track_quat('-Z','Y').to_euler();cam.data.type='PERSP';cam.data.lens=lens
    def branch(branch):
        ar=np.load(folder/(branch+'.npz'));marks=ar['marker'];times=ar['time_s'];steps=info['branches'][branch]['steps'];frames=view.frames[branch]['poses'];assert len(frames)==len(times)
        n=len(times);event=int(np.argmin(abs(times-info['branches'][branch]['event'])));rule=info['rule'];kind=rule['family'];target=rule['target'];detail_at=event+4;detail_focus=None
        if kind=='grip' or c['id']=='bddl_994':
            if branch=='unsafe':
                with gzip.open(folder/(branch+'.csv.gz'),'rt') as log:
                    first=next((float(row['time_s']) for row in csv.DictReader(log) if float(row['peak_payload_floor_N'])>.15),None)
                if first is not None:detail_at=int(np.argmin(abs(times-(first+.10))))
            else:
                concrete=next((z for z in steps if z['command']==rule['event']),None)
                if concrete:detail_at=int(np.argmin(abs(times-(concrete['t']+.85))))
            if 'payload_'+target in byname:detail_focus=frames[min(n-1,detail_at),byname['payload_'+target][0],9:12].tolist()
        if kind=='pour':
            a=np.nonzero((marks[:,6] if branch=='unsafe' else marks[:,7])>2)[0]
            if len(a):
                detail_at=min(n-1,int(a[0])+3);mk=marks[detail_at]
                if len(mk)>11:detail_focus=((mk[3:6]+mk[8:11])/2).tolist()
        detail_at=min(n-1,detail_at)
        keys=list(byname);sp=np.zeros(3);lastcatch=np.zeros(3);pools=[]
        for mm in marks:
            if len(mm)>12 and mm[7]>0 and np.any(mm[11:14]):lastcatch=mm[11:14].copy()
            if np.any(mm[3:6]) and mm[6]>(pools[-1][2] if pools else 0)+.000001:sp=mm[3:6].copy()
            pools.append((sp.copy(),lastcatch.copy(),mm[6],mm[7]))
        def pose(i,detail=False):
            view.pose(branch,i);transforms=frames[i];tcp=marks[i,:3];t=times[i];rootx=tcp[0]
            if c['robot'] in ('omron','spot') or c['id']=='virtualhome_320':rootx=float(ar['qpos'][i,0])
            for ob,j,hh,scale in moving:
                ob.matrix_world=cr.mat4(transforms[j])@Matrix.Translation((0,0,-hh))@Matrix.Scale(scale,4)
            if damp is not None:
                wet_start=next((a['t'] for a in steps if a['command'].startswith('wipe ')),float('inf'))
                damp.hide_render=t<wet_start
            if fluids:
                mm=marks[i];hit=mm[3:6];lip=mm[8:11];on=bool(np.any(hit));jet=dyn[0];jet.hide_render=not on
                if on:
                    delta=Vector(hit)-Vector(lip);jet.location=(Vector(hit)+Vector(lip))*.5;jet.rotation_euler=delta.to_track_quat('Z','Y').to_euler();jet.scale=(.0032,.0032,delta.length)
                for j,(center,vol) in enumerate(zip(pools[i][:2],pools[i][2:])):
                    pool=dyn[j+1];pool.hide_render=vol<.06 or not np.any(center)
                    if not pool.hide_render:
                        rad=min(.049 if j else .16,math.sqrt(vol*1e-6/(math.pi*.0018)));pool.scale=(rad*1.14,rad*.88,.0018);pool.location=Vector(center)+Vector((0,0,.001))
            if detail:
                aim=detail_focus or info['branches'][branch]['focus'] or list(tcp);camera(aim,(.63,-.33,.90) if (kind=='grip' or c['id']=='bddl_994') and branch=='unsafe' else (.62,-.81,.68),48)
            elif c['robot'] in ('omron','spot') or c['id']=='virtualhome_320':
                x,y=ar['qpos'][i,:2]
                if c['robot']=='omron':
                    yaw=ar['qpos'][i,2];x+=.21*(math.cos(yaw)-1);y+=.21*math.sin(yaw)
                camera((x*.45,y*.45,.65),(1.10,-3.90,1.98),29)
            else:camera((.06,.3,.83),(1.08,-2.75,1.48),43)
        return pose,n,detail_at
    return media,view,scene,branch
def render(rank,check=False,details=False,only_unsafe=False):
    media,v,s,branch=setup(rank);frames=D/'frames'/media.name;frames.mkdir(exist_ok=True,parents=True)
    details_meta=json.loads((media/'detail-views.json').read_text()) if (media/'detail-views.json').exists() else {}
    for b in (('unsafe',) if only_unsafe else ('safe','unsafe')):
        pose,n,event=branch(b)
        details_meta[b]=round(.08*event,3)
        for name,i,detail in ((b+'_poster',min(n-1,round(n*.19)),False),('detail_'+b,event,True)):
            if details and not detail:continue
            pose(i,detail);s.render.filepath=str(media/(name+'.jpg'));bpy.ops.render.render(write_still=True)
        if details:continue
        s.render.filepath=str(frames/(b+'_'));s.frame_start=1;s.frame_end=min(12,n) if check else n
        def update(scene,*args):pose(min(n-1,scene.frame_current-1))
        bpy.app.handlers.frame_change_pre.append(update)
        try:
            s.frame_set(1);bpy.ops.render.render(animation=True)
        finally:bpy.app.handlers.frame_change_pre.remove(update)
        if not check:
            run=next((D/'runs').glob(f'{rank:02d}_*'));(media/(b+'-render-hash.txt')).write_text(hashlib.sha256((run/(b+'.npz')).read_bytes()).hexdigest())
        if check:break
    (media/'detail-views.json').write_text(json.dumps(details_meta))
    print('Beauty pass complete:',rank,flush=True)
if __name__=='__main__':render(int(sys.argv[1]),'--check' in sys.argv,'--detail' in sys.argv,'--unsafe' in sys.argv)
