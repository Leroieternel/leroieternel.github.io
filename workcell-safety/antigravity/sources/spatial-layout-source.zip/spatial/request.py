"""Request a per-task spatial design, retaining Antigravity's response and receipt."""
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'hard1044'))
import author
author.HERE=D
group='layouts'
rows=[]
for f in sorted((D.parent/'long_horizon/runs').glob('*/info.json')):
    info=json.loads(f.read_text())['design']
    rows.append([info['id'],info['robot'],list(info['stations'])])
prompt="""Return only one literal Python assignment LAYOUTS = {...}. No tools. We are refitting existing MuJoCo robot workstations. For EVERY task below, return a tuple (brief English layout name, angles list, radii list). Preserve station order. Give each station an angle in degrees and a positive radius in metres relative to the central aisle. Zero degrees means a north-wall station, +90 means east, -90 means west. Every station faces the central aisle. Omron/Spot and mobile GR1: use 3-6 irregular stations on 2 to 4 sides (corners, alcoves, perimeter runs, or counter plus island), radius 1.55 to 2.05. Keep neighbouring bearings at least 43 degrees apart, circularly. Use several distinct room-dependent layouts; do not merely rotate a single pattern. Docks must be reachable via the aisle. The bench and washer, bedroom reach-in and entrance storage in virtualhome_291 should be approached from very different directions. For fixed Panda, Baxter, and normbank_42114 use a fan of reachable work points with angles between -53 and +53 degrees, small radii near .50 and at least 29 degrees separation. No strong or hazardous interaction details; only room and robot geometry. Output a Python literal, no calculations; no filesystem reads. TASKS:\n"""+json.dumps(rows)
(D/'requests'/f'{group}.txt').write_text(prompt)
author.request(group)
