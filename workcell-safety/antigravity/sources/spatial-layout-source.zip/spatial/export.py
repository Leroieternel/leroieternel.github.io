import sys
from pathlib import Path
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parents[1]/'robot_plans'))
import optics
optics.ROOT=D/'runs';optics.CACHE=D/'optics'
optics.export(int(sys.argv[1]))
