"""Plot the actual branch trajectories above their oriented work surfaces."""
import itertools
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import mujoco as mj
from common import *
from measure import polygon
def draw(c):
    run=folder(c);info=json.loads((run/'info.json').read_text());room=pl.room(c);loc=layout(c)
    mobile=pl.mobile(c)
    fig,axes=plt.subplots(1,2,figsize=(10.2,4.7),dpi=138,constrained_layout=True,sharex=True,sharey=True)
    corners=[]
    for s,(xy,a,dock) in room.items():
        corners.extend(polygon(xy,a,loc[s][3]/2,loc[s][4]/2))
    for ax,b,color in zip(axes,('unsafe','safe'),('#aa4a24','#196957')):
        for j,(s,(xy,a,dock)) in enumerate(room.items(),1):
            shape=polygon(xy,a,loc[s][3]/2,loc[s][4]/2)
            ax.add_patch(Polygon(shape,color='#dde2df',ec='#53615b',fill=True,zorder=2,lw=.8))
            ax.text(*xy,str(j),fontsize=8,ha='center',va='center',zorder=4,weight='bold')
        if mobile:
            ar=np.load(run/(b+'-path.npz'));xy=ar['xy']
            ax.plot(*xy.T,color=color,lw=1.7,zorder=3)
            for i in np.linspace(0,len(xy)-2,8,dtype=int):
                for k in range(i,min(len(xy)-2,i+45)):
                    delta=xy[k+1]-xy[k];size=np.linalg.norm(delta)
                    if size>.012:
                        ax.annotate('',xy=xy[k]+.15*delta/size,xytext=xy[k],arrowprops=dict(arrowstyle='-|>',lw=1,color=color));break
            ax.plot(*xy[0],marker='o',mec=color,mfc='white',ms=5,zorder=4)
            br=json.loads((run/'layout.json').read_text())['branches'][b]
            sub=f"{br['base_travel_m']:.2f} m base travel · {br['accumulated_heading_change_deg']:.0f}° total turn"
        else:
            ar=np.load(run/(b+'.npz'));xy=ar['marker'][:,:2]
            ax.plot(*xy.T,color=color,lw=1.15,alpha=.8);ax.plot(0,0,'o',color='#36453f',ms=4);corners.extend(xy)
            br=json.loads((run/'layout.json').read_text())['branches'][b];sub=f"Fixed base · {br['arm_joint1_range_deg']:.0f}° shoulder joint range"
        title=b.capitalize()+' plan';ax.set_title(title+'\n'+sub,loc='left',color=color,fontsize=10)
        ax.set_aspect('equal');ax.grid(alpha=.17);ax.set_xlabel('World x (m)');ax.spines[['top','right']].set_visible(False)
    axes[0].set_ylabel('World y (m)')
    p=np.array(corners);lo=np.minimum(p.min(0),0);hi=np.maximum(p.max(0),0);pad=.19 if mobile else .065
    axes[0].set_xlim(lo[0]-pad,hi[0]+pad);axes[0].set_ylim(lo[1]-pad,hi[1]+pad)
    fig.suptitle('Mobile base path' if mobile else 'Tool path over the workbench',x=.07,ha='left',fontsize=15)
    fig.savefig(run/'layout.png',facecolor='white');plt.close(fig)
if __name__=='__main__':
    for c in load_cases().values():draw(c)
