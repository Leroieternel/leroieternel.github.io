import math,xml.etree.ElementTree as ET
from common import *
from generated import fixtures
def build(c):
    r=lib.make(c['robot']);w=r.find('worldbody');k=c['robot'];bot=w.find("body[@name='%s']"%lib.SOURCES[k][1])
    if k!='omron':bot.set('quat','.70710678 0 0 .70710678')
    if k=='gr1' and c['id']=='virtualhome_320':
        raw=ET.parse(lib.SOURCES[k][0]);orig=raw.find("worldbody/body[@name='base']")
        ET.SubElement(bot,'freejoint',name='floating_pelvis')
        for bb in orig.iter('body'):
            jj=bb.find('joint')
            if jj is not None and '_leg_' in jj.get('name',''):
                bb_new=bot.find(".//body[@name='%s']"%bb.get('name'));bb_new.insert(0,ET.fromstring(ET.tostring(jj)))
    # Robot follows prescribed joint paths. Payload/support contacts are solved independently.
    for g in bot.iter('geom'):
        g.set('contype','0');g.set('conaffinity','0')
    for gg in w.findall('geom'):
        gg.set('contype','0');gg.set('conaffinity','0')
    r.find('option').set('timestep','.006666666666666667')
    r.find('option').set('iterations','30')
    lib.geom(w,'floor','plane',[0,0,-.001],[8,8,.1],(.66,.64,.58,1),contype=1,conaffinity=2)
    loc=layout(c);sizes={}
    for s,v in loc.items():
        parent=w
        if c['id']=='virtualhome_170' and s=='dining_chair':
            parent=lib.add(w,'body',name='chair_carriage')
            lib.add(parent,'joint',name='seat_slide',type='slide',axis=[*pl.rotation(pl.room(c)[s][1])[:,1],0],range=[-.22,0],damping=3)
            lib.add(parent,'inertial',pos=[v[0],v[1],.34],mass=4,diaginertia=[.22,.18,.25])
        center,heading,_=pl.room(c)[s]
        mount=lib.add(parent,'body',name='placement_'+s,pos=[*center,0],euler=[0,0,heading])
        fixtures.fixture(mount,s,c['stations'][s],0,0,*v[2:])
    for item,(kind,s) in c['props'].items():
        body=lib.free(w,'item_'+item,[0,0,0]);half=fixtures.prop(body,item,kind);sizes[item]=float(half)
        primary=body.find("geom[@name='payload_%s']"%item)
        primary.set('conaffinity','1');primary.set('condim','6');primary.set('friction','.91 .022 .013')
        # A thin non-slip base makes rounded food and loose sports balls stable on storage ledges.
        if kind in ('vegetable','apple','ball','egg'):
            shoe=lib.geom(body,item+'_support_patch','cylinder',[0,0,-half+.003],[min(.023,half*.66),.003],(.26,.28,.24,1),mass=.001,group=1,contype=2,conaffinity=1,condim=6,friction=[.9,.02,.023])
        pp=slots(c,loc,s,item);pp[2]+=half+.001
        body.set('pos',lib.string(pp))
    for mode,eye,look in [('overview',[2.7,-4.0,2.35],[0,.52,.72]),('detail',[1.35,-1.1,1.55],[0,.56,.8])]:
        camera(w,mode,np.asarray(eye),np.asarray(look),43)
    if c['id']=='alfred_435':
        from kitchen import install
        install(r)
    return r,loc,sizes
