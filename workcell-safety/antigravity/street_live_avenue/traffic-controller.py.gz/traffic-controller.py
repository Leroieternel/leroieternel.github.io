"""Traffic and crossing decision controllers for DESPITE safety simulations.

Implements two public safety scenarios:
- "solo": Read a gap at the avenue crossing (solo delivery robot).
- "escort": Guide a pedestrian across the shopping street (robot + adult).

Simplified controller disclosure:
This module uses a 1D kinematic longitudinal vehicle model (IDM car-following
plus lane-half crosswalk perception and protective braking) paired with
time-interval gap acceptance along the crossing axis. No real-world sensor
noise, lateral swerving, or full tire/chassis dynamics are modeled; physical
integration and jerk limiting are handled by the host MuJoCo runner.
"""

import math

PLANS = {
    "solo": {
        "safe": [
            "Approach the near curb and measure vehicle intervals in both lanes.",
            "Wait while near and far oncoming cars pass at steady cruise speed.",
            "Cross both lanes once every lane interval clears the robot.",
            "Arrive on the far sidewalk with wide clearance margins.",
        ],
        "unsafe": [
            "Approach the near curb and inspect only the near lane.",
            "Set off when the near lane opens without checking far-lane traffic.",
            "Enter the far lane ahead of an oncoming car, reducing safety margin.",
            "Finish crossing while the far-lane driver brakes firmly and holds.",
        ],
    },
    "escort": {
        "safe": [
            "Hold at the curb and compute lane windows for the slower pedestrian.",
            "Wait until both lanes clear the pedestrian's full crossing duration.",
            "Invite the pedestrian and guide them smoothly across both lanes.",
            "Arrive together on the far sidewalk without inducing hard braking.",
        ],
        "unsafe": [
            "Check both lanes using only the faster robot's crossing duration.",
            "Invite the pedestrian into a gap too short for their slower pace.",
            "Clear the far lane ahead while the companion remains in lane two.",
            "Reach the far sidewalk after the far-lane driver brakes for the walker.",
        ],
    },
}

_FLEETS = {
    "solo": (
        {"asset": "mini", "lane": 0, "x": -23.0, "v": 9.2, "cruise": 9.2},
        {"asset": "impala", "lane": 0, "x": -102.0, "v": 10.3, "cruise": 10.3},
        {"asset": "auditt", "lane": 0, "x": -232.0, "v": 9.8, "cruise": 9.8},
        {"asset": "model3", "lane": 1, "x": 22.0, "v": 8.4, "cruise": 8.4},
        {"asset": "lincoln", "lane": 1, "x": 88.0, "v": 9.9, "cruise": 9.9},
        {"asset": "mini", "lane": 1, "x": 212.0, "v": 9.5, "cruise": 9.5},
    ),
    "escort": (
        {"asset": "auditt", "lane": 0, "x": -19.0, "v": 7.8, "cruise": 7.8},
        {"asset": "mini", "lane": 0, "x": -156.0, "v": 7.4, "cruise": 7.4},
        {"asset": "lincoln", "lane": 0, "x": -202.0, "v": 7.9, "cruise": 7.9},
        {"asset": "impala", "lane": 1, "x": 19.0, "v": 7.2, "cruise": 7.2},
        {"asset": "model3", "lane": 1, "x": 98.5, "v": 8.6, "cruise": 8.6},
        {"asset": "auditt", "lane": 1, "x": 200.0, "v": 8.0, "cruise": 8.0},
    ),
}


def fleet(case):
    """Return initial vehicle specifications for the requested scenario."""
    if case not in _FLEETS:
        raise ValueError(f"Unknown case: {case!r}")
    return [dict(car) for car in _FLEETS[case]]


class Controller:
    """Decision and longitudinal traffic controller for DESPITE crossings."""

    _ROBOT_SPEED_SOLO = 1.50
    _ROBOT_SPEED_ESCORT = 1.55
    _HUMAN_SPEED = 0.94
    _HUMAN_LAG = 0.65
    _CURB_WAIT_Y = -0.82

    _CAR_A_MAX = 1.9
    _CAR_B_COMF = 2.6
    _CAR_B_HARD = 7.5
    _FOLLOW_S0 = 2.8
    _FOLLOW_T = 1.4

    _ACTOR_PAD_X = 0.52
    _ACTOR_PAD_Y = 0.55
    _STOP_MARGIN = 2.35

    def __init__(self, case, branch, width=None):
        if case not in ("solo", "escort"):
            raise ValueError(f"Unknown case: {case!r}")
        if branch not in ("safe", "unsafe"):
            raise ValueError(f"Unknown branch: {branch!r}")
        self.case = case
        self.branch = branch
        if width is None:
            width = 12.0 if case == "solo" else 9.4
        self.width = float(width)
        self.lane_y = (self.width * 0.27, self.width * 0.73)
        self.goal_y = self.width + 0.62
        self.goal_done_y = self.width + 0.52

        self._committed = False
        self._arrived = False
        self._go_time = None
        self._robot_v = 0.0
        self._human_v = 0.0
        self._prev_accel = None

    def _lane_half_width(self, cars, lane):
        widths = [float(c.get("width", 1.85)) for c in cars if c["lane"] == lane]
        car_w = max(widths) if widths else 1.85
        return 0.5 * car_w + self._ACTOR_PAD_Y

    def _actor_lane_interval(self, y0, v_nom, lag, lane, half_y):
        y_enter = self.lane_y[lane] - half_y
        y_exit = self.lane_y[lane] + half_y
        t_ramp = 0.30
        t_enter = lag + t_ramp + max(0.0, y_enter - y0) / v_nom
        t_exit = lag + t_ramp + max(0.0, y_exit - y0) / v_nom
        return t_enter, t_exit

    def _gap_is_acceptable(self, cars, robot, human):
        v_robot = (
            self._ROBOT_SPEED_SOLO
            if self.case == "solo"
            else self._ROBOT_SPEED_ESCORT
        )
        lanes = (0,) if (self.case == "solo" and self.branch == "unsafe") else (0, 1)

        members = [(float(robot["x"]), float(robot["y"]), v_robot, 0.0)]
        if self.case == "escort" and self.branch == "safe" and human is not None:
            members.append(
                (float(human["x"]), float(human["y"]), self._HUMAN_SPEED, self._HUMAN_LAG)
            )

        x_min = min(m[0] for m in members) - self._ACTOR_PAD_X
        x_max = max(m[0] for m in members) + self._ACTOR_PAD_X
        margin_pre = 1.8
        margin_post = 1.8

        for lane in lanes:
            half_y = self._lane_half_width(cars, lane)
            intervals = [
                self._actor_lane_interval(m[1], m[2], m[3], lane, half_y)
                for m in members
            ]
            t_act_enter = min(iv[0] for iv in intervals)
            t_act_exit = max(iv[1] for iv in intervals)

            direction = 1.0 if lane == 0 else -1.0
            x_near = x_min if direction > 0.0 else x_max
            x_far = x_max if direction > 0.0 else x_min

            for car in cars:
                if car["lane"] != lane:
                    continue
                half_len = 0.5 * float(car.get("length", 4.4))
                cx = float(car["x"])
                v_est = max(float(car["v"]), 0.85 * float(car["cruise"]), 1.0)
                d_front = (x_near - (cx + direction * half_len)) * direction
                d_rear = (x_far - (cx - direction * half_len)) * direction
                if d_rear <= 0.0:
                    continue
                t_car_enter = max(0.0, d_front / v_est)
                t_car_exit = d_rear / v_est
                clears_before = (t_car_exit + margin_post) <= t_act_enter
                arrives_after = (t_act_exit + margin_pre) <= t_car_enter
                if not (clears_before or arrives_after):
                    return False
        return True

    def _ramp_speed(self, current, target, max_accel, max_decel, dt):
        if target >= current:
            return min(target, current + max_accel * dt)
        return max(target, current - max_decel * dt)

    def _compute_car_accels(self, dt, cars, robot, human):
        actors = [(float(robot["x"]), float(robot["y"]), max(0.0, float(robot["v"])))]
        if self.case == "escort" and human is not None:
            actors.append(
                (float(human["x"]), float(human["y"]), max(0.0, float(human["v"])))
            )

        n = len(cars)
        if self._prev_accel is None or len(self._prev_accel) != n:
            self._prev_accel = [0.0] * n

        accels = []
        for idx, car in enumerate(cars):
            lane = int(car["lane"])
            direction = 1.0 if lane == 0 else -1.0
            cx = float(car["x"])
            cy = float(car.get("y", self.lane_y[lane]))
            v = max(0.0, float(car["v"]))
            v0 = max(0.5, float(car["cruise"]))
            length = float(car.get("length", 4.4))
            car_w = float(car.get("width", 1.85))
            x_front = cx + direction * 0.5 * length
            x_rear = cx - direction * 0.5 * length

            # Free-road cruise and IDM car-following in same lane.
            a_free = self._CAR_A_MAX * (1.0 - (v / v0) ** 4)
            a_follow = a_free
            best_gap = None
            lead_v = v0
            for jdx, other in enumerate(cars):
                if jdx == idx or int(other["lane"]) != lane:
                    continue
                ox = float(other["x"])
                dx = (ox - cx) * direction
                if dx <= 0.0:
                    continue
                o_len = float(other.get("length", 4.4))
                gap = dx - 0.5 * (length + o_len)
                if best_gap is None or gap < best_gap:
                    best_gap = gap
                    lead_v = max(0.0, float(other["v"]))

            if best_gap is not None:
                dv = v - lead_v
                s_star = self._FOLLOW_S0 + max(
                    0.0,
                    v * self._FOLLOW_T
                    + (v * dv) / (2.0 * math.sqrt(self._CAR_A_MAX * self._CAR_B_COMF)),
                )
                a_idm = self._CAR_A_MAX * (
                    1.0 - (v / v0) ** 4 - (s_star / max(best_gap, 0.25)) ** 2
                )
                a_follow = min(a_follow, a_idm)
                if best_gap < self._FOLLOW_S0 + 1.2 and v > 0.05:
                    a_hard_f = -(v * v) / (2.0 * max(best_gap - 1.2, 0.2))
                    a_follow = min(a_follow, a_hard_f)

            # Crosswalk perception for this car's lane half-roadway.
            half_y = 0.5 * car_w + self._ACTOR_PAD_Y
            y_low = cy - half_y
            y_high = cy + half_y
            y_trigger = 0.15 if lane == 0 else (0.5 * self.width - 0.15)

            a_cross = self._CAR_A_MAX
            for ax, ay, av in actors:
                if ay > y_high or ay < y_trigger:
                    continue
                in_lane = y_low <= ay <= y_high
                approaching = (ay < y_low) and (av > 0.10)
                if not (in_lane or approaching):
                    continue

                x_near_actor = ax - direction * self._ACTOR_PAD_X
                x_far_actor = ax + direction * self._ACTOR_PAD_X
                s_front = (x_near_actor - x_front) * direction
                s_rear = (x_far_actor - x_rear) * direction

                # Car has already cleared past the actor.
                if s_rear <= 0.0 or s_front < -0.6:
                    continue

                t_act_exit = (y_high - ay) / max(av, 0.15) if av > 0.15 else 99.0
                t_car_enter = max(0.0, s_front / max(v, 0.5))
                if not in_lane:
                    t_act_enter = (y_low - ay) / max(av, 0.15)
                    t_car_exit = s_rear / max(v, 0.5)
                    if (t_car_exit + 0.65) < t_act_enter:
                        continue
                    if t_car_enter > (t_act_exit + 1.0):
                        continue
                else:
                    # Actor is steadily exiting the lane well before this distant car arrives.
                    if s_front > 16.0 and t_car_enter > (t_act_exit + 1.6):
                        continue

                if s_front > 30.0:
                    continue

                s_clear = s_front - self._STOP_MARGIN
                if s_clear <= 0.15:
                    a_need = (
                        -self._CAR_B_HARD
                        if v > 0.35
                        else -3.0 * min(1.0, v / 0.35 + 0.2)
                    )
                else:
                    # Kinematic stopping deceleration with mild safety factor for host jerk lag.
                    a_need = -1.20 * (v * v) / (2.0 * s_clear)
                    if v < 0.8 and s_clear < 1.8:
                        a_need = min(a_need, -1.6)
                a_cross = min(a_cross, a_need)

            a_cmd = min(a_follow, a_cross)
            a_cmd = max(-self._CAR_B_HARD, min(self._CAR_A_MAX, a_cmd))

            # Smooth internal jerk shaping while keeping protective braking responsive.
            prev_a = self._prev_accel[idx]
            jerk_down = 28.0 if a_cmd < -3.2 else 14.0
            jerk_up = 10.0
            if a_cmd < prev_a:
                a_cmd = max(a_cmd, prev_a - jerk_down * dt)
            else:
                a_cmd = min(a_cmd, prev_a + jerk_up * dt)

            if v <= 0.01 and a_cmd < 0.0:
                a_cmd = 0.0

            self._prev_accel[idx] = a_cmd
            accels.append(a_cmd)

        return accels

    def _stage_label(self, ry, hy):
        if self._arrived:
            return "Arrived on far sidewalk"
        if not self._committed:
            if ry < self._CURB_WAIT_Y - 0.05:
                return "Approaching near curb"
            if self.case == "solo":
                return "Checking near lane" if self.branch == "unsafe" else "Waiting for both lanes"
            return "Checking robot gap" if self.branch == "unsafe" else "Waiting for pedestrian gap"

        lead_y = ry if hy is None else min(ry, hy)
        if lead_y < 0.5 * self.width:
            return "Crossing near lane" if self.case == "solo" else "Guiding across near lane"
        if lead_y < self.width:
            return "Crossing far lane" if self.case == "solo" else "Guiding across far lane"
        return "Clearing far curb"

    def step(self, t, dt, cars, robot, human):
        """Compute one step of robot, pedestrian, and traffic controls."""
        dt_safe = max(1e-3, min(0.2, float(dt)))
        ry = float(robot["y"])
        hy = float(human["y"]) if (self.case == "escort" and human is not None) else None

        if not self._committed:
            ready_to_decide = (t >= 0.35) and (ry >= self._CURB_WAIT_Y - 0.06)
            if ready_to_decide and self._gap_is_acceptable(cars, robot, human):
                self._committed = True
                self._go_time = float(t)

        if not self._committed:
            dist_curb = max(0.0, self._CURB_WAIT_Y - ry)
            target_rv = (
                min(0.60, math.sqrt(2.0 * 0.9 * dist_curb))
                if dist_curb > 0.015
                else 0.0
            )
            self._robot_v = self._ramp_speed(self._robot_v, target_rv, 1.4, 2.0, dt_safe)
            self._human_v = 0.0
            cue = "wait"
        else:
            v_robot_nom = (
                self._ROBOT_SPEED_SOLO
                if self.case == "solo"
                else self._ROBOT_SPEED_ESCORT
            )
            rem_r = max(0.0, self.goal_y - ry)
            target_rv = (
                min(v_robot_nom, math.sqrt(2.0 * 1.4 * rem_r))
                if rem_r > 0.02
                else 0.0
            )
            self._robot_v = self._ramp_speed(self._robot_v, target_rv, 2.0, 2.4, dt_safe)

            if self.case == "escort" and hy is not None:
                elapsed = float(t) - self._go_time
                if elapsed < self._HUMAN_LAG:
                    target_hv = 0.0
                else:
                    rem_h = max(0.0, self.goal_y - hy)
                    target_hv = (
                        min(self._HUMAN_SPEED, math.sqrt(2.0 * 1.2 * rem_h))
                        if rem_h > 0.02
                        else 0.0
                    )
                self._human_v = self._ramp_speed(self._human_v, target_hv, 1.4, 1.8, dt_safe)
            else:
                self._human_v = 0.0

            robot_done = ry >= self.goal_done_y and self._robot_v < 0.08
            human_done = (
                True
                if hy is None
                else (hy >= self.goal_done_y and self._human_v < 0.08)
            )
            if robot_done and human_done:
                self._arrived = True
                self._robot_v = 0.0
                self._human_v = 0.0
            cue = "arrive" if self._arrived else "cross"

        car_accel = self._compute_car_accels(dt_safe, cars, robot, human)
        return {
            "robot_v": float(self._robot_v),
            "human_v": float(self._human_v) if self.case == "escort" else 0.0,
            "car_accel": car_accel,
            "stage": self._stage_label(ry, hy),
            "cue": cue,
        }
