"""Native robot library assemblies, mechanical workstations, free payloads and cart fixtures."""
from pathlib import Path
from copy import deepcopy
import json,math,sys
import xml.etree.ElementTree as ET
import numpy as np
import mujoco as mj
D=Path(__file__).resolve().parent;ROOT=D.parents[2];H=D.parent/'hard1044';sys.path.insert(0,str(H))
import robotlib as lib
TASK={r['slug']:r for r in json.loads((D/'selection.json').read_text())}
TWO={'market','museum','bank'}
BG={'gr1':'https://github.com/ARISE-Initiative/robosuite/tree/master/robosuite/models/assets/robots/gr1','tiago':'https://github.com/ARISE-Initiative/robosuite/tree/master/robosuite/models/assets/robots/tiago','g1':'https://github.com/google-deepmind/mujoco_menagerie/tree/370c43965323c0944b433b202aac5058b5f907a9/unitree_g1','husky':'https://github.com/husky/husky','omron':'https://github.com/ARISE-Initiative/robosuite/tree/master/robosuite/models/assets','panda':'https://github.com/ARISE-Initiative/robosuite/tree/master/robosuite/models/assets/robots/panda'}
def fmt(v):
 if isinstance(v,(list,tuple,np.ndarray)):return ' '.join(f'{a:.9g}' for a in v)
 return str(v)
def add(p,tag,**attrs):return ET.SubElement(p,tag,{k:fmt(v) for k,v in attrs.items()})
def geo(p,n,ty,pos,size,col,collide=True,**kw):
 return add(p,'geom',name=n,type=ty,pos=pos,size=size,rgba=col,contype=int(collide),conaffinity=int(collide),group=1,friction='0.85 .008 .001',solref='.004 1',solimp='.96 .995 .001',**kw)
col={'steel':[.33,.39,.42,1],'wood':[.55,.34,.19,1],'navy':[.039,.11,.16,1],'red':[.66,.17,.075,1],'paper':[.87,.79,.59,1],'green':[.135,.40,.34,1],'offwhite':[.81,.82,.77,1],'black':[.048,.054,.058,1],'yellow':[.94,.66,.09,1]}
def box(p,n,xyz,full,mat,collide=True,**kw):return geo(p,n,'box',xyz,np.array(full)/2,col[mat],collide,**kw)
def cyl(p,n,xyz,r,h,mat,collide=True,**kw):return geo(p,n,'cylinder',xyz,[r,h/2],col[mat],collide,**kw)
def table(p,n,x,y,z,w,h):
 box(p,n+'_top',[x,y,z-.025],[w,h,.05],'wood')
 for i in (-1,1):
  for j in (-1,1):box(p,n+f'_leg{i}_{j}',[x+i*(w/2-.04),y+j*(h/2-.04),(z-.05)/2],[.045,.045,z-.05],'steel')
def tag_sources(root,src):
 for e in root.findall('asset/*'):
  if e.get('file'):e.set('file',str((src/e.get('file')).resolve()))
def base_robot(key):
 if key not in ('g1','tiago'):root=lib.make(key)
 elif key=='g1':
  src=D/'assets/unitree_g1';root=ET.parse(src/'g1_with_hands.xml').getroot()
  tag_sources(root,src/'assets');root.find('compiler').attrib.pop('meshdir',None)
  for tg in ('actuator','keyframe','sensor'):
   if root.find(tg) is not None:root.remove(root.find(tg))
  body=root.find('worldbody/body')
  body.remove(body.find('freejoint'));body.set('pos','0 0 .7924')
 else:
  src=lib.LIB/'robots/tiago';root=ET.parse(src/'robot.xml').getroot();tag_sources(root,src)
  for tg in ('actuator','sensor','contact'):
   if root.find(tg) is not None:root.remove(root.find(tg))
  gr=ET.parse(lib.LIB/'grippers/robotiq_gripper_85.xml').getroot();tag_sources(gr,lib.LIB/'grippers')
  have={e.get('name') for e in root.findall('asset/*')}
  for e in gr.findall('asset/*'):
   if e.get('name') not in have:root.find('asset').append(deepcopy(e));have.add(e.get('name'))
  for side in ('left','right'):
   hand=deepcopy(gr.find('worldbody/body'))
   for e in hand.iter():
    if e.get('name'):e.set('name',side+'_'+e.get('name'))
   root.find(f".//body[@name='{side}_hand']").append(hand)
  for e in root.findall('.//worldbody//geom'):
   if e.get('group')!='1':e.set('group','3');e.set('rgba','0 0 0 0')
 if root.find('option') is None:add(root,'option')
 root.find('option').attrib.update(timestep='.001',gravity='0 0 -9.81',integrator='implicitfast',iterations='80')
 world=root.find('worldbody');robot=world.find('body');robot.set('gravcomp','1')
 # Prescribed joint trajectories; dedicated paired contact shapes handle the mechanical payloads.
 for e in robot.iter('geom'):
  e.set('contype','0');e.set('conaffinity','0')
 for e in robot.iter('joint'):e.set('damping','0.2');e.set('frictionloss','0')
 if key in ('omron','husky','tiago'):
  for tag in list(robot):
   if tag.tag in ('freejoint','joint'):robot.remove(tag)
  for n,axis,kind in [('x','1 0 0','slide'),('y','0 1 0','slide'),('yaw','0 0 1','hinge')]:
   add(robot,'joint',name='route_'+n,axis=axis,type=kind,limited='false',armature='1')
 return root,world,robot
def build(slug):
 cfg=TASK[slug];key=cfg['robot'];r,w,robot=base_robot(key)
 if key=='gr1' and (D/'assets/gr1-pinch.json').exists():
  cal=json.loads((D/'assets/gr1-pinch.json').read_text())
  add(robot.find(".//body[@name='r_palm']"),'site',name='replica_pinch',pos=cal['site'],size='.003',group='5')
 if key=='g1':
  body=robot.find(".//body[@name='right_wrist_yaw_link']");add(body,'site',name='work_tcp',pos=json.loads((D/'assets/g1-pinch.json').read_text())['pinch'] if (D/'assets/g1-pinch.json').exists() else [.112,-.008,0],size='.005',group='5')
 if key=='tiago':
  for side in ('right','left'):
   body=robot.find(".//body[@name='"+side+"_robotiq_85_base_link']")
   if body is None:body=robot.find(".//body[@name='"+side+"_robotiq_85_adapter_link']")
   add(body,'site',name=side+'_work_tcp',pos='0 0 .156',size='.004',group='5')
 # The stage is level. Native robot meshes and optical export use this same coordinate frame.
 geo(w,'stage_ground','plane',[0,0,0],[13,10,.02],[.35,.35,.34,1])
 for name,pos,z in [('overview',[4,-7.2,3.0],.87),('detail',[2.7,-3.8,2.4],.95)]:
  vect=np.asarray(pos)-[0,.0,z];right=np.cross([0,0,1],vect);right/=np.linalg.norm(right);up=np.cross(vect,right);up/=np.linalg.norm(up)
  add(w,'camera',name=name,pos=pos,xyaxes=np.r_[right,up],fovy=43)
 if slug in ('crossing','bus'):
  box(robot,'secured_parcel',[0,0,.31],[.36,.27,.24],'paper',False);box(robot,'parcel_tape',[0,0,.434],[.054,.273,.006],'navy',False)
 if slug in ('hospital','warehouse'):
  # Cantilever shelf mechanically bolted to the mobile chassis, clear of the arm posture.
  box(robot,'rack_upright',[-.42,0,.52],[.055,.09,.52],'steel',False)
  box(robot,'carrier_rear_rack',[-.50,0,.746],[.39,.53,.045],'navy',False)
  if slug=='hospital':
   box(robot,'lidded_supply_tote',[-.51,0,.895],[.29,.4,.25],'green',False)
   box(robot,'tote_lid',[-.51,0,1.023],[.30,.41,.024],'offwhite',False)
   bed=add(w,'body',name='gurney',mocap='true',pos='.10 -2.45 0')
   box(bed,'bed_frame',[0,0,.58],[.68,1.72,.09],'steel')
   box(bed,'bed_mattress',[0,0,.69],[.65,1.68,.14],'green')
   box(bed,'bed_pillow',[0,.55,.78],[.46,.32,.095],'offwhite')
   for i in (-1,1):
    for j in (-1,1):
     cyl(bed,f'caster{i}_{j}',[i*.247,j*.63,.097],.095,.053,'black',False,euler=[0,math.pi/2,0])
     box(bed,f'bed_upright{i}_{j}',[i*.247,j*.63,.342],[.037,.039,.43],'steel',False)
    box(bed,'bed_rail'+str(i),[i*.343,0,.88],[.034,1.14,.035],'steel')
  else:
   for s in (-1,1):box(robot,'rack_support'+str(s),[-.54,s*.19,.95],[.06,.055,.38],'steel',False)
   box(robot,'carried_bar',[-.54,0,1.165],[.11,1.12,.07],'wood')
   for y in (1.48,-1.48):box(w,'gantry_post'+str(y),[.05,y,1.20],[.095,.095,2.4],'steel')
   box(w,'gantry_beam',[.05,0,2.37],[.10,3.08,.10],'steel')
   flap=add(w,'body',name='swing_flag',pos=[.05,-.30,2.28]);add(flap,'joint',name='flag_hinge',axis=[0,1,0],range=[-1.56,1.56],damping='.09',stiffness='.32')
   box(flap,'clearance_paddle',[0,0,-.60],[.027,.35,1.20],'yellow',True,mass='.18')
 if slug in ('meeting','library'):
  shelf=robot.find(".//body[@name='torso_lift_link']")
  box(shelf,'service_bracket',[.245,0,.215],[.54,.05,.055],'steel',False)
  box(shelf,'service_shelf',[.48,0,.255],[.33,.43,.030],'wood',False)
  cyl(shelf,'cup_body',[.505,0,.34],.044,.14,'green',False)
  cyl(shelf,'drink_surface',[.505,0,.411],.040,.003,'paper',False)
  if slug=='library':
   lid=add(shelf,'body',name='hinged_lid',pos=[.547,0,.416]);add(lid,'joint',name='cover_angle',axis=[0,1,0],range=[0,1.74],damping='.03',armature='.005')
   cyl(lid,'lid_cap',[-.044,0,0],.047,.009,'yellow',False,mass='.035')
 if slug=='hotel':
  box(w,'suitcase',[.12,.33,.33],[.37,.23,.62],'green')
  for x in (-.005,.245):
   cyl(w,'luggage_pole'+str(x),[x,.35,.72],.012,.18,'steel')
  box(w,'luggage_handle',[.12,.35,.812],[.275,.033,.025],'black')
 if slug in TWO:
  if slug=='market':z=.77;source=[.43,-.14];dest=[.47,.25];half=.139
  elif slug=='museum':z=1.04;source=[.20,-.51];dest=[.24,-.18];half=.103
  else:z=.88;source=[.285,-.38];dest=[.365,-.125];half=.148
  table(w,'source',*source,z-(.125 if slug=='bank' else 0),.25,.25);table(w,'display',*dest,z-(.08 if slug=='bank' else 0),2*half,2*half)
  if slug=='bank':
   cyl(w,'pickup_stem',[*source,z-.063],.014,.12,'steel');box(w,'pickup_pad',[*source,z-.005],[.073,.036,.010],'navy')
   cyl(w,'receiving_stem',[*dest,z-.039],.024,.076,'steel');box(w,'receiving_pad',[*dest,z-.006],[.19,.15,.012],'navy')
  if slug!='bank':
   box(w,'padded_catch',[dest[0]+.20,dest[1],z-.26],[.37,.43,.045],'navy')
   for ss in (-1,1):
    box(w,'catch_strut'+str(ss),[dest[0]+.24,dest[1]+ss*.155,(z-.2825)/2],[.030,.030,z-.2825],'steel')
   box(w,'catch_rim',[dest[0]+.374,dest[1],z-.206],[.022,.43,.088],'steel')
  if slug=='bank':
   # The receiving terminal retains the far edge of the card, leaving the hand side open.
   # Two short shelf fingers and a retractable keeper are attached to the terminal's housing.
   box(w,'reader_housing',[.476,-.125,.881],[.058,.163,.162],'navy')
   keeper=add(w,'body',name='reader_keeper',pos=[.46,-.125,.9708])
   add(keeper,'joint',name='retainer_slide',type='slide',axis=[1,0,0],range=[-.035,0],damping='2',armature='.15')
   for k,y in enumerate((-.103,-.137)):
    box(w,'receiving_rail_'+str(k),[.445,y,.9604],[.060,.014,.005],'steel')
    box(keeper,'retainer_finger_'+str(k),[.015,y+.125,.0000],[.052,.014,.004],'black',mass='.02')
   for side in (-1,1):box(w,'card_guide'+str(side),[source[0],source[1]+side*.006,z+.009],[.065,.006,.018],'navy')
  f=add(w,'body',name='payload',pos=[*source,z+.12]);add(f,'freejoint',name='payload_free')
  if slug=='market':
   cyl(f,'bottle',[0,0,0],.037,.173,'green',mass='.27');cyl(f,'bottle_neck',[0,0,.10],.018,.04,'green',mass='.011')
   cyl(f,'bottle_cap',[0,0,.127],.019,.019,'red',mass='.006');cyl(f,'bottle_label',[0,0,-.001],.0373,.068,'paper',False,mass='.001')
  elif slug=='museum':
   cyl(f,'replica_foot',[0,0,-.054],.047,.035,'steel',mass='.12')
   geo(f,'cast_vessel','ellipsoid',[0,0,.009],[.068,.056,.076],col['green'],True,mass='.5');cyl(f,'brass_rim',[0,0,.085],.037,.014,'yellow',mass='.03')
   if (D/'assets/gr1-pinch.json').exists():
    radius=json.loads((D/'assets/gr1-pinch.json').read_text())['radius']
    cyl(f,'handling_stem',[0,0,.155],.004,.132,'steel',mass='.012')
    geo(f,'handling_knob','sphere',[0,0,.222],[radius],col['yellow'],mass='.020')
  else:
   box(f,'privacy_card',[0,0,0],[.091,.060,.004],'green',mass='.013')
   box(f,'confidential_stripe',[.01,0,.00225],[.014,.056,.0006],'yellow',False,mass='.00002')
   for i in range(3):box(f,'private_mark'+str(i),[-.025+i*.008,-.013,.0023],[.004,.012,.0006],'paper',False,mass='.00001')
 # The free payload collides with native hand surfaces even as the prescribed arm opens and withdraws.
 if slug in TWO:
  for body in robot.iter('body'):
   nm=body.get('name','').lower()
   if not nm.startswith(('leftfinger','rightfinger','r_palm','r_hand','r_thumb','r_index','r_middle','r_ring','r_pinky','right_hand','right_wrist')):continue
   for g in body.findall('geom'):
    if g.get('class') not in ('visual',) and (g.get('group') in ('3','4','5') or g.get('class')=='collision'):continue
    g.set('contype','2');g.set('conaffinity','0');g.set('solref','.0025 1');g.set('solimp','.995 .999 .0005')
  for g in f.findall('geom'):
   if g.get('contype')=='1':g.set('conaffinity','3')
 # Placeholder optics info is filled after audit. Collision surrogates for limbs use the identical skinning joints.
 for n in ('head','torso','L_upperarm','L_forearm','R_upperarm','R_forearm','L_thigh','L_shin','R_thigh','R_shin'):
  b=add(w,'body',name='person_'+n,mocap='true',pos='0 0 2')
  rr,half={'head':(.126,.025),'torso':(.17,.14)}.get(n,(.052,.116) if 'arm' in n else (.077,.145))
  add(b,'geom',name='guard_'+n,type='capsule',size=[rr,half],rgba=[0,0,0,0],group=4,contype=0,conaffinity=0)
 out=D/'runs'/slug;out.mkdir(exist_ok=True);ET.indent(r)
 (out/'scene.xml').write_text(ET.tostring(r,encoding='unicode'))
 return mj.MjModel.from_xml_path(str(out/'scene.xml'))
def init(m,d,key):
 if key in ('panda','gr1','omron','husky'):lib.home(m,d,key)
 if key=='tiago':
  for side in ('right','left'):
   for i,val in enumerate([0,-.9,1.45,1.7,-1.5,.5],1):
    joint=d.joint('arm_'+side+'_'+str(i)+'_joint');lo,hi=m.joint(joint.id).range;joint.qpos[0]=np.clip(val,lo+.001,hi-.001)
  d.joint('torso_lift_joint').qpos[0]=.16
 if key=='g1':
  for side,sgn in [('left',1),('right',-1)]:
   for n,v in [('shoulder_pitch',.08),('shoulder_roll',sgn*.2),('elbow',1.12),('wrist_pitch',.10)]:d.joint(side+'_'+n+'_joint').qpos[0]=v
 mj.mj_forward(m,d)
if __name__=='__main__':
 for s in sys.argv[1:] or TASK:
  m=build(s);d=mj.MjData(m);init(m,d,TASK[s]['robot'])
  print(s,m.nq,m.ngeom,[(m.site(i).name,np.round(d.site_xpos[i],3).tolist()) for i in range(m.nsite) if m.site(i).name in ('work_tcp','tcp','right_grip_site','right_work_tcp','left_work_tcp')])
