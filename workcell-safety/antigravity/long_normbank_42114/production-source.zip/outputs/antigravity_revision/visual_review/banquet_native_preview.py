"""Show Antigravity its reception set through the project's existing native UV importer."""
import json
import math
from pathlib import Path
import sys
import os

D = Path(__file__).resolve().parent
ROOT=D.parents[2]
JOB=D/'jobs/banquet'
sys.path[:0]=[str(JOB/'src'),str(ROOT/'outputs/mobile_worlds/library'),str(D)]
import bpy
import render as production
import world_assets as assets
import native_room_inputs


def attach_native_room(repo, maps, index, provenance, placed):
    native_room_inputs.register(assets)
    sources={v['id']:k for k,v in assets.GENIE.items()}
    heights={}
    replacements={'foyer_plant':'review_live_plant'}
    for item in production.GENIE_BANQUET_LAYOUT:
        key=replacements.get(item['key'],sources.get(item['id']))
        if key is None:
            provenance[item['key']]={'id':item['id'],'status':'omitted_unavailable_native_source'};continue
        spec=assets.GENIE[key];height=spec['size_m'][2];x,y,z=item['xyz']
        # Respect the authored model dimensions of side furniture and exact
        # support height of small props. A low TV sideboard is a low sideboard.
        yaw=item['yaw_deg']; support=item['support']
        if key=='review_curtain':yaw+=90
        if key=='sideboard':yaw+=90
        if key=='sofa':yaw-=90
        if support in heights:z=heights[support]
        if support=='ceiling':z-=height
        instance=assets.place(key,(x,y,z),yaw=math.radians(yaw));heights[item['key']]=z+height
        mesh_materials=[m for ob in instance.instance_collection.objects if ob.type=='MESH' for m in ob.data.materials]
        linked={n.label:str(Path(bpy.path.abspath(n.image.filepath)).resolve().relative_to(repo)) for m in mesh_materials if m and m.use_nodes for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image and any(out.is_linked for out in n.outputs)}
        provenance[item['key']]={'id':spec['id'],'revision':spec['revision'],'source':spec['source'],'sha256':spec['sha256'],'native_textures':linked,'input_size_m':spec['size_m']}
        placed.append({'key':item['key'],'is_genie':True,'xyz':[x,y,z],'yaw_deg':yaw,'support':support,'target_height_m':height})


def configure():
    production.import_genie_furniture=attach_native_room
    if os.environ.get('BANQUET_REFERENCE_LIGHT'):
        production.CAMERAS['macro'].update(pos=(.08,-.85,1.49),target=(.405,.012,.887),fovy_deg=33.)
        original_material=production.make_g1_material
        def source_color(name,rgba,roughness,metallic,mesh):
            def linear(x):return x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4
            native=tuple(linear(x) for x in rgba[:3])+(1.,)
            material=original_material(name,native,roughness,metallic,mesh)
            if mesh=='head_link':
                shader=material.node_tree.nodes['Principled BSDF']
                shader.inputs['Base Color'].default_value=native
            return material
        production.make_g1_material=source_color
        original_lights=production.setup_lighting
        def apply_zoned_light():
            info=original_lights();scene=bpy.context.scene
            scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
            scene.view_settings.exposure=-.60
            scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.014
            for light_name,factor in [('Sky_SoftFill',.24),('Ceiling_WarmBounce',.30),('Foyer_BackRim',.44)]:
                bpy.data.lights[light_name].energy*=factor
            info.update(world_strength=.014,exposure_stops=-.60,
                        actual_area_power_W={l.name:l.energy for l in bpy.data.lights if l.users})
            if scene.render.engine=='CYCLES':
                prefs=bpy.context.preferences.addons['cycles'].preferences
                try:
                    prefs.compute_device_type='OPTIX';prefs.get_devices()
                    for device in prefs.devices:device.use=device.type=='OPTIX'
                    if any(d.use for d in prefs.devices):scene.cycles.device='GPU'
                except (RuntimeError,TypeError):pass
            return info
        production.setup_lighting=apply_zoned_light


if __name__=='__main__':
    configure()
    production.main()
