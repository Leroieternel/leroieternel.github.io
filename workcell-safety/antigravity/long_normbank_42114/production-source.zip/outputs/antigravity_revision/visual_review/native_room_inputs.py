"""Stage UV-preserving native Blender inputs and physical asset bounds for the scene producers."""
from pathlib import Path
from contextlib import contextmanager
import json
import sys

D = Path(__file__).resolve().parent
ROOT = D.parents[2]
LIB = ROOT/'outputs/mobile_worlds/library'
DEDICATED = {'review_vanity_000':'benchmark_bathroom_vanity_000','review_vanity_001':'benchmark_bathroom_vanity_001','review_wardrobe':'benchmark_bedroom_wardrobe_002','review_live_plant':'benchmark_plant_001','review_curtain':'benchmark_curtain_000','review_ceiling_fitting':'benchmark_ceiling_light_000'}


def generate():
    from pxr import Usd, UsdGeom, UsdShade
    import numpy as np
    sys.path.insert(0,str(LIB))
    import prepare_genie as prepare
    found={}; parts={}
    for key,identity in DEDICATED.items():
        spec=prepare.encode(key,identity)
        if key.startswith('review_vanity_'):
            spec['revision']=json.loads((D/'genie-search.json').read_text()).get('revision', '34e5a838eaf4a1fa69d947c395bc8f44bc0cda56')
        found[key]=spec
        stage=Usd.Stage.Open(str(prepare.SOURCE/spec['source']))
        rows=[]
        for prim in stage.Traverse():
            if not prepare.readable(prim):continue
            mesh=UsdGeom.Mesh(prim);points=np.asarray(mesh.GetPointsAttr().Get(),float)
            matrix=np.asarray(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0))
            xyz=points@matrix[:3,:3]+matrix[3,:3];xyz=xyz[:,[0,2,1]]*[1,-1,1]
            binding=UsdShade.MaterialBindingAPI(prim).ComputeBoundMaterial()[0]
            rows.append({'mesh_path':str(prim.GetPath()),'vertex_count':len(xyz),'min_z_up':xyz.min(0).round(5).tolist(),'max_z_up':xyz.max(0).round(5).tolist(),'material_name':binding.GetPrim().GetName() if binding else None})
        parts[key]=rows
    (D/'room-native.json').write_text(json.dumps(found,indent=1)+'\n')
    (D/'room-native-parts.json').write_text(json.dumps(parts,indent=1)+'\n')
    print({k:(v['id'],v['size_m'],len(parts[k])) for k,v in found.items()})


def register(assets):
    records=json.loads((D/'room-native.json').read_text())
    assets.GENIE.update(records)
    mapping=assets.native_maps()
    for record in records.values():
        for mat in record['materials']:
            for channel in ('Base Color','Roughness','Metallic','Normal','ORM'):
                if channel in mat:mapping.setdefault(mat[channel],mat[channel])
    return records


@contextmanager
def bedroom_wardrobe(assets, design):
    """Resolve the art director's bedroom cabinet request to the intended native bedroom asset."""
    desc = " ".join(design.get(k, "") for k in ("setting", "scene_group", "room_note")).lower()
    if not any(k in desc for k in ("bedroom", "dormitory", "sleeping room")):
        yield
        return
    register(assets)
    place = assets.place
    def furnished(key, *args, **kwargs):
        return place("review_wardrobe" if key == "cabinet" else key, *args, **kwargs)
    assets.place = furnished
    try:
        yield
    finally:
        assets.place = place


def bind_room_roles(layout):
    """Bedside reading lamps are lighting fixtures in the set's object list."""
    original = layout._category
    def classify(name, key=""):
        if name.lower().startswith(("bed_lamp_", "bed_flamp_")):
            return "lamp"
        return original(name, key)
    layout._category = classify


if __name__=='__main__':generate()
