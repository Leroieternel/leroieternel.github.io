"""Procedural high-DPI 2D graphics generator (Pillow only) for physical desk props:
- Three printed guest ID cards (GUEST 01 / 02 / 03) resting on the badge sleeves
- Queue-clear spring key cap graphic ("QUEUE CLEAR")
- State-driven upright ID reader screen readout (driven solely by measured MuJoCo state)
- Subtle brass desk zone legend strip ("INTAKE | SCAN | RETURN")

All text is strictly English and calibrated for crisp readability under natural lighting
with AgX tone mapping (no clipped whites, high typographic contrast).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence, Tuple

from PIL import Image, ImageDraw, ImageFont

_FONT_CANDIDATES_BOLD = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
)
_FONT_CANDIDATES_REG = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
)
_FONT_CANDIDATES_MONO = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
)


def load_font(size: int, *, bold: bool = False, mono: bool = False) -> ImageFont.ImageFont:
    candidates = _FONT_CANDIDATES_MONO if mono else (
        _FONT_CANDIDATES_BOLD if bold else _FONT_CANDIDATES_REG
    )
    for path in candidates:
        if Path(path).is_file():
            try:
                return ImageFont.truetype(path, size=size)
            except OSError:
                continue
    return ImageFont.load_default()


def generate_guest_card_texture(
    guest_index: int,
    out_path: Path,
    size: Tuple[int, int] = (768, 512),
) -> Path:
    """Render a realistic banquet guest ID card graphic (ivory stock, readable under daylight)."""
    w, h = size
    # Warm satin ivory stock (not pure 255 white so highlights stay readable under AgX)
    img = Image.new("RGB", (w, h), (228, 224, 214))
    draw = ImageDraw.Draw(img)

    accents = {
        1: ((24, 82, 72), "GUEST 01", "A. MERCER", "TABLE 04 · EAST"),
        2: ((28, 72, 96), "GUEST 02", "C. HADDAD", "TABLE 04 · EAST"),
        3: ((88, 62, 34), "GUEST 03", "E. TANAKA", "TABLE 07 · HALL"),
    }
    accent, code, name, seat = accents.get(
        guest_index, ((30, 80, 70), f"GUEST {guest_index:02d}", "BANQUET GUEST", "MAIN HALL")
    )

    # Outer fine rule
    draw.rectangle([16, 16, w - 17, h - 17], outline=(168, 152, 122), width=4)
    # Header banner
    draw.rectangle([22, 22, w - 23, 122], fill=accent)
    draw.rectangle([22, 122, w - 23, 130], fill=(184, 146, 78))

    f_head = load_font(38, bold=True)
    f_sub = load_font(22, bold=True)
    f_code = load_font(48, bold=True)
    f_name = load_font(32, bold=True)
    f_meta = load_font(24, bold=False)
    f_tiny = load_font(18, mono=True)

    draw.text((44, 44), "GRAND BANQUET FOYER", fill=(238, 232, 216), font=f_head)
    draw.text((w - 220, 56), "ID PASS", fill=(214, 182, 118), font=f_sub)

    # Left portrait emblem box (stylized geometric silhouette, non-photographic)
    px0, py0, px1, py1 = 44, 158, 234, 378
    draw.rectangle([px0, py0, px1, py1], fill=(208, 203, 192), outline=(140, 132, 118), width=3)
    cx = (px0 + px1) // 2
    draw.ellipse([cx - 38, py0 + 36, cx + 38, py0 + 112], fill=accent)
    draw.pieslice([cx - 64, py0 + 124, cx + 64, py1 + 48], 180, 360, fill=accent)

    # Guest metadata
    draw.text((268, 162), code, fill=(32, 38, 42), font=f_code)
    draw.text((268, 226), name, fill=(52, 58, 62), font=f_name)
    draw.text((268, 274), seat, fill=(92, 86, 76), font=f_meta)
    draw.line([(268, 316), (w - 46, 316)], fill=(180, 172, 156), width=2)
    draw.text((268, 330), "STATUS: CHECKPOINT ENTRY", fill=(74, 82, 80), font=f_meta)

    # Bottom barcode strip (clean geometric verification bars)
    bx = 48
    pattern = [5, 3, 9, 4, 3, 7, 4, 8, 3, 5, 6, 3, 9, 4, 5, 3, 8, 4, 6, 3, 7, 5, 4, 8, 3, 6]
    shift = guest_index * 3
    for i in range(44):
        bw = pattern[(i + shift) % len(pattern)]
        if i % 2 == 0:
            draw.rectangle([bx, 404, min(bx + bw, w - 48), 458], fill=(38, 42, 46))
        bx += bw + 4
        if bx >= w - 54:
            break
    draw.text((48, 464), f"PASS-42114-G0{guest_index} · VERIFY BEFORE RETURN", fill=(86, 82, 74), font=f_tiny)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path


def generate_queue_key_texture(
    out_path: Path,
    pressed: bool = False,
    size: Tuple[int, int] = (512, 512),
) -> Path:
    """Render top cap graphic for the physical sprung queue acknowledgement key."""
    w, h = size
    bg = (28, 128, 102) if pressed else (22, 86, 74)
    ring = (182, 238, 212) if pressed else (154, 194, 176)
    img = Image.new("RGB", (w, h), bg)
    draw = ImageDraw.Draw(img)

    draw.rounded_rectangle([24, 24, w - 25, h - 25], radius=42, outline=ring, width=10)
    draw.rounded_rectangle([46, 46, w - 47, h - 47], radius=28, outline=(196, 162, 92), width=4)

    f_big = load_font(66, bold=True)
    f_sm = load_font(36, bold=True)
    for text, y_pos, fnt, col in [
        ("QUEUE", 128, f_big, (236, 242, 236)),
        ("CLEAR", 206, f_big, (236, 242, 236)),
        ("ACK KEY" if not pressed else "CLEARED", 322, f_sm, ring),
    ]:
        bbox = draw.textbbox((0, 0), text, font=fnt)
        tw = bbox[2] - bbox[0]
        draw.text(((w - tw) // 2, y_pos), text, fill=col, font=fnt)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path


def generate_reader_screen_texture(
    out_path: Path,
    *,
    scanned_guests: Iterable[str],
    returned_guests: Iterable[str],
    queue_cleared: bool,
    premature_guest: Optional[str] = None,
    sim_time_s: float = 0.0,
    size: Tuple[int, int] = (960, 480),
) -> Path:
    """Render the upright ID reader screen purely from measured MuJoCo physics state."""
    w, h = size
    scanned = set(scanned_guests)
    returned = set(returned_guests)

    img = Image.new("RGB", (w, h), (16, 24, 30))
    draw = ImageDraw.Draw(img)

    # Outer bezel accent
    border_col = (196, 68, 62) if premature_guest else ((62, 168, 134) if queue_cleared else (82, 114, 128))
    draw.rectangle([10, 10, w - 11, h - 11], outline=border_col, width=6)

    f_title = load_font(34, bold=True)
    f_sub = load_font(22, mono=True)
    f_row = load_font(28, bold=True)
    f_pill = load_font(22, bold=True)
    f_banner = load_font(30, bold=True)

    # Header bar
    draw.rectangle([16, 16, w - 17, 86], fill=(24, 36, 44))
    draw.text((34, 32), "ENTRANCE ID CHECKPOINT", fill=(224, 232, 234), font=f_title)
    draw.text((w - 230, 38), f"T = {sim_time_s:5.2f} s", fill=(168, 194, 202), font=f_sub)

    # Three guest rows
    rows = [
        ("guest1_id", "GUEST 01  (RIGHT LANE)"),
        ("guest2_id", "GUEST 02  (CENTER LANE)"),
        ("guest3_id", "GUEST 03  (LEFT LANE)"),
    ]
    y = 112
    for gid, label in rows:
        is_prem = premature_guest == gid
        is_ret = gid in returned
        is_scan = gid in scanned
        row_bg = (68, 28, 30) if is_prem else (26, 38, 46)
        draw.rounded_rectangle([32, y, w - 32, y + 66], radius=10, fill=row_bg, outline=(52, 72, 82), width=2)
        draw.text((52, y + 17), label, fill=(222, 228, 228), font=f_row)

        if is_prem:
            st_text, st_bg, st_fg = "EARLY RETURN", (188, 54, 52), (246, 238, 236)
        elif is_ret:
            st_text, st_bg, st_fg = "RETURNED", (48, 138, 108), (236, 246, 240)
        elif is_scan:
            st_text, st_bg, st_fg = "SCANNED", (44, 114, 136), (232, 244, 248)
        else:
            st_text, st_bg, st_fg = "AT INTAKE", (58, 70, 78), (192, 204, 210)

        px0, px1 = w - 270, w - 48
        draw.rounded_rectangle([px0, y + 12, px1, y + 54], radius=8, fill=st_bg)
        bb = draw.textbbox((0, 0), st_text, font=f_pill)
        draw.text(((px0 + px1 - (bb[2] - bb[0])) // 2, y + 20), st_text, fill=st_fg, font=f_pill)
        y += 80

    # Bottom status banner
    by0, by1 = 368, h - 26
    if premature_guest:
        b_bg = (164, 42, 42)
        b_txt = "ALERT: PREMATURE RETURN BEFORE QUEUE CLEAR"
        b_fg = (248, 238, 236)
    elif queue_cleared:
        b_bg = (32, 116, 90)
        b_txt = "QUEUE CLEARED (3/3 SCANNED) · RETURN PERMITTED"
        b_fg = (234, 246, 240)
    else:
        b_bg = (42, 58, 68)
        b_txt = f"SCANS: {len(scanned)}/3 · QUEUE KEY: PENDING"
        b_fg = (212, 224, 228)

    draw.rounded_rectangle([32, by0, w - 32, by1], radius=12, fill=b_bg)
    bb = draw.textbbox((0, 0), b_txt, font=f_banner)
    draw.text(((w - (bb[2] - bb[0])) // 2, by0 + (by1 - by0 - (bb[3] - bb[1])) // 2 - 2), b_txt, fill=b_fg, font=f_banner)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path


def generate_zone_plaque_texture(out_path: Path, size: Tuple[int, int] = (768, 128)) -> Path:
    """Subtle engraved brass zone strip along the left edge of the oak desk."""
    w, h = size
    img = Image.new("RGB", (w, h), (148, 108, 52))
    draw = ImageDraw.Draw(img)
    draw.rectangle([6, 6, w - 7, h - 7], outline=(92, 64, 28), width=4)
    f = load_font(36, bold=True)
    labels = [("INTAKE", w // 6), ("SCAN", w // 2), ("RETURN", (5 * w) // 6)]
    for txt, cx in labels:
        bb = draw.textbbox((0, 0), txt, font=f)
        draw.text((cx - (bb[2] - bb[0]) // 2, (h - (bb[3] - bb[1])) // 2 - 2), txt, fill=(44, 30, 14), font=f)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path
