"""Shared path discovery, provenance utilities, and source command definitions
for the Antigravity Unitree G1 Banquet Guest ID Verification revision job.

Works cleanly both when invoked inside the visual_review job directory
(pointing at upstream ``outputs/antigravity_revision/spatial/banquet_g1``)
and if integrated directly into the upstream ``banquet_g1`` directory.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

JOB_DIR = Path(__file__).resolve().parents[1]

# Canonical upstream relative paths from repository root (the DESPITE repository)
DEFAULT_REPO_ROOT = Path.cwd()
UPSTREAM_BANQUET_REL = Path("outputs/antigravity_revision/spatial/banquet_g1")
UPSTREAM_OLD_RUN_REL = Path("outputs/antigravity_revision/spatial/runs/22_normbank_42114")
UPSTREAM_SHARED_SPACES_REL = Path("outputs/antigravity_revision/shared_spaces")
GENIE_ASSETS_REL = Path(".runtime/genie-assets")
MOBILE_WORLDS_LIB_REL = Path("outputs/mobile_worlds/library")

RUNTIME_STUDIO_PY = DEFAULT_REPO_ROOT / ".runtime/antigravity-studio/bin/python"
RUNTIME_BLENDER_PY = DEFAULT_REPO_ROOT / ".runtime/antigravity-blender/bin/python"
RUNTIME_USD_PY = DEFAULT_REPO_ROOT / ".runtime/usd-tools/bin/python"

IDENT = "long_normbank_42114"
SOURCE_TASK = "normbank_42114"
RANK = 22
SCENE_GROUP = "Banquet hall"
TITLE = "Verify Guest IDs at Banquet Entrance"
ROBOT_LABEL = "Unitree G1 · articulated three-finger hands"
MENAGERIE_G1_COMMIT = "370c43965323c0944b433b202aac5058b5f907a9"
GENIE_REVISION = "12f41e388a953cc2aeb0fe5b8eb516750c8321d9"

# Exact physical zone thresholds derived from upstream study.py constants
# (INTAKE=0.350, SCAN=0.412, RETURN=0.475, SURFACE=0.820, BADGE_HALF=0.032)
X_SCAN_MIN = 0.397       # badge physically seated inside scan pocket (412 +/- 15 mm)
X_RETURN_CROSS = 0.4435  # midpoint between SCAN (0.412) and RETURN (0.475)
X_RETURN_DONE = 0.460    # badge physically seated inside return pocket (475 +/- 15 mm)
ACK_DEPTH_THRESHOLD_M = -0.0020  # >= 2.0 mm physical depression of sprung queue_key

# Exact English display text for source actions (matching case.json)
SOURCE_TO_DISPLAY = {
    "move_to_checkpoint person1": "Move to checkpoint person1",
    "move_to_checkpoint person2": "Move to checkpoint person2",
    "move_to_checkpoint person3": "Move to checkpoint person3",
    "navigate_to_checkpoint": "Navigate to checkpoint",
    "navigate_to_entrance": "Navigate to entrance",
    "check_id person1": "Check ID person1",
    "check_id person2": "Check ID person2",
    "check_id person3": "Check ID person3",
    "clear_waiting_status": "Clear waiting status",
    "process_person person1": "Process person person1",
    "process_person person2": "Process person person2",
    "process_person person3": "Process person person3",
}

PHYSICS_SCOPE_DISCLOSURE = (
    "MuJoCo 500 Hz elliptic-friction rigid-body simulation (recorded at 25 fps, 1x real-time). "
    "The native Unitree G1 arm and subtle waist-yaw joint trajectories are prescribed via "
    "continuous damped least-squares IK with both feet planted (zero base travel, zero head joint). "
    "No grasp constraints, welds, or teleportation are used: the three 6-DoF rigid badge sleeves "
    "move exclusively through physical finger-to-lip contact inside fixed brass lane guides, and "
    "queue acknowledgement is measured directly from physical depression of the passive sprung "
    "queue_key slide joint (k=350 N/m, c=1.2 N*s/m) under left index finger contact."
)

CONTROL_DISCLOSURE = {
    "paths_prescribed": True,
    "path_generation": (
        "Cartesian fingertip waypoints from upstream generated/concierge.py with quintic ease "
        "interpolation, mapped to native 7-DoF G1 arms and subtle waist yaw (+/-0.18 rad) by "
        "upstream arms.py continuous IK with elbow comfort costs and planted feet."
    ),
    "grasp_uses_constraint": False,
    "grasp_constraint_activation_criteria": (
        "Not applicable — no grasp, weld, or attachment constraint is used anywhere in the task. "
        "All three free badge sleeves move purely through rigid-body frictional contact on their "
        "raised rear lips; queue clearance uses physical contact on a passive spring-loaded slide key."
    ),
    "playback_speed": 1.0,
    "solver_hz": 500,
    "video_fps": 25,
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return path


def resolve_repo_root(explicit: Optional[str] = None) -> Path:
    if explicit:
        return Path(explicit).resolve()
    # Walk up from JOB_DIR looking for .runtime or outputs/antigravity_revision
    for cand in [JOB_DIR, *JOB_DIR.parents, DEFAULT_REPO_ROOT]:
        if (cand / UPSTREAM_BANQUET_REL / "study.py").is_file():
            return cand
    return DEFAULT_REPO_ROOT


def resolve_banquet_dir(
    repo_root: Optional[Path] = None, explicit: Optional[str] = None
) -> Path:
    """Locate upstream banquet_g1 (preferring integrated host path, falling back to job inputs)."""
    if explicit:
        p = Path(explicit).resolve()
        if (p / "study.py").is_file():
            return p
        raise FileNotFoundError(f"study.py not found in --banquet-dir {p}")
    root = repo_root or resolve_repo_root()
    upstream = root / UPSTREAM_BANQUET_REL
    if (upstream / "study.py").is_file():
        return upstream
    staged = JOB_DIR / "inputs/spatial/banquet_g1"
    if (staged / "study.py").is_file():
        return staged
    raise FileNotFoundError(
        f"Could not find study.py in {upstream} or {staged}"
    )


def resolve_old_info_path(repo_root: Optional[Path] = None) -> Path:
    """Locate the original 22_normbank_42114/info.json containing the exact 15/12 commands."""
    root = repo_root or resolve_repo_root()
    candidates = [
        root / UPSTREAM_OLD_RUN_REL / "info.json",
        JOB_DIR / "inputs/spatial/runs/22_normbank_42114/info.json",
    ]
    for cand in candidates:
        if cand.is_file():
            return cand
    raise FileNotFoundError(f"Could not locate 22_normbank_42114/info.json in {candidates}")


def load_source_plan(repo_root: Optional[Path] = None) -> Dict[str, Any]:
    """Load the exact upstream source commands (15 safe, 12 unsafe) and metadata."""
    info = read_json(resolve_old_info_path(repo_root))
    design = info["design"]
    ref = design["ref"]
    assert len(design["safe"]) == 15 and len(ref["safe"]) == 15, "Safe plan must have 15 commands"
    assert len(design["unsafe"]) == 12 and len(ref["unsafe"]) == 12, "Unsafe plan must have 12 commands"
    return {
        "design": design,
        "ref": ref,
        "rule": info["rule"],
        "branches": {
            branch: [
                {
                    "index": idx,
                    "command": cmd,
                    "source": src,
                    "display": SOURCE_TO_DISPLAY.get(src, src.replace("_", " ").capitalize()),
                }
                for idx, (cmd, src) in enumerate(zip(design[branch], ref[branch]))
            ]
            for branch in ("safe", "unsafe")
        },
    }


def load_upstream_modules(banquet_dir: Path) -> Tuple[Any, Any, Any, Any]:
    """Import study.py, desk.py, arms.py, and SHA-verified generated/concierge.py verbatim."""
    bdir_str = str(banquet_dir.resolve())
    if bdir_str not in sys.path:
        sys.path.insert(0, bdir_str)
    import study  # type: ignore
    import desk  # type: ignore
    import arms  # type: ignore

    concierge = study.choreography()
    return study, desk, arms, concierge


def load_concierge_standalone(banquet_dir: Path) -> Tuple[Any, Dict[str, Any]]:
    """Verify concierge.py SHA-256 against provenance/concierge.json and import it."""
    prov_path = banquet_dir / "provenance/concierge.json"
    mod_path = banquet_dir / "generated/concierge.py"
    req_path = banquet_dir / "requests/concierge.txt"
    prov = read_json(prov_path)
    actual_sha = sha256_file(mod_path)
    actual_req_sha = sha256_file(req_path)
    if prov["sha256"] != actual_sha:
        raise ValueError(f"concierge.py SHA mismatch: {actual_sha} != {prov['sha256']}")
    if prov["prompt_sha256"] != actual_req_sha:
        raise ValueError(
            f"concierge.txt SHA mismatch: {actual_req_sha} != {prov['prompt_sha256']}"
        )
    spec = importlib.util.spec_from_file_location("banquet_choreography", mod_path)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod, prov
