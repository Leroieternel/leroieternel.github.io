"""Blender 4.5 (bpy) 1920x1080 PBR production renderer for the Unitree G1 Banquet ID job.

Designed to run under ``the DESPITE repository/.runtime/antigravity-blender/bin/python``.
Does NOT require ``mujoco`` inside Blender Python: reads exact visual meshes and 25 fps
world transforms exported by ``src/solve.py`` (``scene_meshes.npz``, ``poses_safe.npz``,
``poses_unsafe.npz``) for 0.000 mm alignment with the 500 Hz MuJoCo physics simulation.

Production standards:
  - Native Unitree G1 with articulated three-finger hands using UV-independent native base
    colors + artistic PBR (roughness, metallic) directly from ``generated/concierge.py``.
  - Grounded full 3D banquet hall foyer with native Genie Sim floor/wall UV PBR maps
    (``genie_floor_04``, ``genie_wall_02``), recessed sunlit window, wainscoting, and verified
    Genie Sim furniture/props from ``assets-index.json`` + ``native-maps.json``.
  - Broad natural window key + cool soft sky fill + warm ceiling bounce + AgX tone mapping
    leaving readable highlight detail on light ceramics/cards and readable dark G1 joints.
  - Per-mesh and per-texture SHA-256 provenance recorded in ``appearance.json``.
  - Zero interpenetrating cameras: stable ``overview`` (1920x1080) and human-readable
    ``macro`` close-up showing G1 fingers contacting raised badge lips and spring queue key.
"""

from __future__ import annotations

import argparse
import math
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import bpy
import mathutils
import numpy as np

# Ensure sibling src/ imports work when launched via blender standalone python
_SRC_DIR = Path(__file__).resolve().parent
if str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))

from common import (
    GENIE_ASSETS_REL,
    GENIE_REVISION,
    IDENT,
    JOB_DIR,
    MOBILE_WORLDS_LIB_REL,
    SOURCE_TASK,
    TITLE,
    read_json,
    resolve_repo_root,
    sha256_file,
    write_json,
)
from textures import (
    generate_guest_card_texture,
    generate_queue_key_texture,
    generate_reader_screen_texture,
    generate_zone_plaque_texture,
)

# Verified Genie Sim assets (every path verified in assets-index.json, rev 12f41e388a953cc2aeb0fe5b8eb516750c8321d9)
GENIE_BANQUET_LAYOUT: List[Dict[str, Any]] = [
    {
        "key": "sideboard",
        "id": "benchmark_tv_cabinet_001",
        "usd": "background/common/tv_cabinet/benchmark_tv_cabinet_001/Aligned.usd",
        "xyz": [-1.85, 0.35, 0.0],
        "target_height_m": 0.82,
        "yaw_deg": 90.0,
        "support": "floor",
        "required": True,
    },
    {
        "key": "cabinet_accent",
        "id": "benchmark_cabinet_003",
        "usd": "background/common/cabinet/benchmark_cabinet_003/Aligned.usd",
        "xyz": [-1.85, -1.75, 0.0],
        "target_height_m": 0.92,
        "yaw_deg": 90.0,
        "support": "floor",
        "required": False,
    },
    {
        "key": "sofa",
        "id": "benchmark_sofa_002",
        "usd": "background/common/sofa/benchmark_sofa_002/Aligned.usd",
        "xyz": [-0.35, 2.18, 0.0],
        "target_height_m": 0.84,
        "yaw_deg": 0.0,
        "support": "floor",
        "required": True,
    },
    {
        "key": "chair_far",
        "id": "benchmark_chair_010",
        "usd": "background/common/chair/benchmark_chair_010/Aligned.usd",
        "xyz": [-1.42, 1.95, 0.0],
        "target_height_m": 0.84,
        "yaw_deg": 52.0,
        "support": "floor",
        "required": True,
    },
    {
        "key": "chair_left",
        "id": "benchmark_chair_010",
        "usd": "background/common/chair/benchmark_chair_010/Aligned.usd",
        "xyz": [-1.45, -1.05, 0.0],
        "target_height_m": 0.84,
        "yaw_deg": 118.0,
        "support": "floor",
        "required": False,
    },
    {
        "key": "folder",
        "id": "benchmark_folder_000",
        "usd": "objects/benchmark/folder/benchmark_folder_000/Aligned.usd",
        "xyz": [-1.82, -0.05, 0.82],
        "target_height_m": None,
        "yaw_deg": 78.0,
        "support": "sideboard",
        "required": False,
    },
    {
        "key": "pen_cup",
        "id": "iros_pen_cup_000",
        "usd": "objects/iros/pen_cup/iros_pen_cup_000/Aligned.usd",
        "xyz": [-1.82, 0.65, 0.82],
        "target_height_m": None,
        "yaw_deg": 18.0,
        "support": "sideboard",
        "required": False,
    },
    {
        "key": "photo_books",
        "id": "benchmark_desk_decoration_007",
        "usd": "background/common/desk_decoration/benchmark_desk_decoration_007/Aligned.usd",
        "xyz": [-1.84, 0.32, 0.82],
        "target_height_m": None,
        "yaw_deg": 86.0,
        "support": "sideboard",
        "required": False,
    },
    {
        "key": "ceramic_accent",
        "id": "benchmark_desk_decoration_010",
        "usd": "background/common/desk_decoration/benchmark_desk_decoration_010/Aligned.usd",
        "xyz": [-1.82, -1.72, 0.92],
        "target_height_m": None,
        "yaw_deg": 24.0,
        "support": "cabinet_accent",
        "required": False,
    },
    {
        "key": "banquet_door",
        "id": "benchmark_door_000",
        "usd": "background/common/door/benchmark_door_000/Aligned.usd",
        "xyz": [3.02, 0.20, 0.0],
        "target_height_m": 2.25,
        "yaw_deg": -90.0,
        "support": "floor",
        "required": False,
    },
    {
        "key": "window_curtain",
        "id": "benchmark_curtain_000",
        "usd": "background/common/curtain/benchmark_curtain_000/Aligned.usd",
        "xyz": [0.98, 2.72, 0.0],
        "target_height_m": 2.85,
        "yaw_deg": 0.0,
        "support": "floor",
        "required": False,
    },
    {
        "key": "foyer_plant",
        "id": "benchmark_plant_000",
        "usd": "background/common/plant/benchmark_plant_000/Aligned.usd",
        "xyz": [-1.85, 2.38, 0.0],
        "target_height_m": 1.45,
        "yaw_deg": 28.0,
        "support": "floor",
        "required": False,
    },
    {
        "key": "ceiling_fixture",
        "id": "benchmark_ceiling_light_000",
        "usd": "background/common/ceiling_light/benchmark_ceiling_light_000/Aligned.usd",
        "xyz": [0.25, 0.15, 3.22],
        "target_height_m": None,
        "yaw_deg": 0.0,
        "support": "ceiling",
        "required": False,
    },
]

# Stable camera definitions (verified zero fixture interpenetration in verify_local.py)
CAMERAS: Dict[str, Dict[str, Any]] = {
    "overview": {
        "pos": (1.73, -2.32, 1.59),
        "target": (0.22, 0.02, 0.86),
        "fovy_deg": 38.0,
        "description": "3/4 front-right overview showing Unitree G1 visor, torso turn, both arms, oak reception desk, three badge lanes, sprung queue key, reader, stanchions, and sunlit banquet foyer.",
    },
    "macro": {
        "pos": (0.96, -0.68, 1.36),
        "target": (0.39, 0.02, 0.85),
        "fovy_deg": 32.0,
        "description": "Human-readable macro close-up inside the stanchion line showing the articulated three-finger G1 hands contacting raised badge lips and depressing the sprung queue key.",
    },
}


def clear_scene() -> None:
    bpy.ops.wm.read_factory_settings(use_empty=True)


def set_bsdf_input(bsdf: bpy.types.Node, names: Sequence[str], value: Any) -> None:
    for n in names:
        if n in bsdf.inputs:
            bsdf.inputs[n].default_value = value
            return


def link_image_texture(
    nt: bpy.types.NodeTree,
    bsdf: bpy.types.Node,
    img_path: Path,
    socket_name: str,
    *,
    colorspace: str = "sRGB",
    mapping_node: Optional[bpy.types.Node] = None,
    normal_strength: float = 0.7,
) -> Optional[bpy.types.Image]:
    if not img_path.is_file():
        return None
    img = bpy.data.images.load(str(img_path), check_existing=True)
    img.colorspace_settings.name = colorspace
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    if mapping_node is not None:
        nt.links.new(mapping_node.outputs["Vector"], tex.inputs["Vector"])
    if socket_name == "Normal":
        nmap = nt.nodes.new("ShaderNodeNormalMap")
        nmap.inputs["Strength"].default_value = normal_strength
        nt.links.new(tex.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    elif socket_name in bsdf.inputs:
        nt.links.new(tex.outputs["Color"], bsdf.inputs[socket_name])
    return img


def find_surface_maps(
    repo_root: Path, surface_key: str, map_names: Dict[str, str]
) -> Dict[str, Optional[Path]]:
    """Search known Genie architectural surface directories under mobile_worlds/library and .runtime/genie-assets."""
    search_roots = [
        repo_root / MOBILE_WORLDS_LIB_REL / "surfaces",
        repo_root / MOBILE_WORLDS_LIB_REL / "cache",
        repo_root / MOBILE_WORLDS_LIB_REL,
        repo_root / GENIE_ASSETS_REL,
    ]
    found: Dict[str, Optional[Path]] = {role: None for role in map_names}
    for role, filename in map_names.items():
        for root in search_roots:
            if not root.is_dir():
                continue
            direct = root / surface_key / filename
            if direct.is_file():
                found[role] = direct
                break
            hits = list(root.rglob(filename))
            if hits:
                found[role] = hits[0]
                break
    return found


def make_g1_material(
    name: str, rgba: Sequence[float], roughness: float, metallic: float, mesh_name: str
) -> bpy.types.Material:
    """Create UV-independent artistic PBR material for native Unitree G1 parts.

    Preserves native MJCF base color and uses measured (roughness, metallic) from
    upstream generated/concierge.py (no external photographic textures on the robot).
    """
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]

    # Slightly lift ultra-dark charcoal joints so dark joints remain readable in natural light
    r, g, b = float(rgba[0]), float(rgba[1]), float(rgba[2])
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    if lum < 0.05 and "visor" not in (name + mesh_name).lower():
        r, g, b = max(r, 0.045), max(g, 0.048), max(b, 0.052)

    set_bsdf_input(bsdf, ["Base Color"], (r, g, b, 1.0))
    set_bsdf_input(bsdf, ["Metallic"], float(metallic))
    set_bsdf_input(bsdf, ["Roughness"], float(roughness))
    set_bsdf_input(bsdf, ["Specular IOR Level", "Specular"], 0.48)

    if "head" in mesh_name.lower() or "visor" in (name + mesh_name).lower():
        set_bsdf_input(bsdf, ["Coat Weight", "Clearcoat"], 0.22)
        set_bsdf_input(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.14)
    return mat


def make_oak_material(
    name: str,
    native_wood_maps: Dict[str, Optional[Path]],
    provenance_textures: Dict[str, Any],
) -> bpy.types.Material:
    """Warm satin oak reception desk material using native Genie wood maps if cached,
    or deterministic scaled procedural oak grain fallback."""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]

    tex_coord = nt.nodes.new("ShaderNodeTexCoord")
    mapping = nt.nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (1.6, 1.6, 1.6)
    nt.links.new(tex_coord.outputs["Generated"], mapping.inputs["Vector"])

    alb = native_wood_maps.get("Base Color")
    if alb and alb.is_file():
        link_image_texture(nt, bsdf, alb, "Base Color", colorspace="sRGB", mapping_node=mapping)
        rgh = native_wood_maps.get("Roughness")
        if rgh and rgh.is_file():
            link_image_texture(nt, bsdf, rgh, "Roughness", colorspace="Non-Color", mapping_node=mapping)
        else:
            set_bsdf_input(bsdf, ["Roughness"], 0.38)
        nor = native_wood_maps.get("Normal")
        if nor and nor.is_file():
            link_image_texture(nt, bsdf, nor, "Normal", colorspace="Non-Color", mapping_node=mapping, normal_strength=0.45)
        provenance_textures[name] = {
            role: {"path": str(p), "sha256": sha256_file(p)}
            for role, p in native_wood_maps.items()
            if p and p.is_file()
        }
    else:
        # Procedural scaled warm oak wood grain (fallback when wood map absent)
        noise = nt.nodes.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 9.0
        noise.inputs["Detail"].default_value = 8.0
        noise.inputs["Roughness"].default_value = 0.55
        wave = nt.nodes.new("ShaderNodeTexWave")
        wave.wave_type = "BANDS"
        wave.bands_direction = "Y"
        wave.inputs["Scale"].default_value = 4.5
        wave.inputs["Distortion"].default_value = 4.2
        wave.inputs["Detail"].default_value = 5.0
        ramp = nt.nodes.new("ShaderNodeValToRGB")
        ramp.color_ramp.elements[0].position = 0.15
        ramp.color_ramp.elements[0].color = (0.19, 0.092, 0.042, 1.0)
        ramp.color_ramp.elements[1].position = 0.85
        ramp.color_ramp.elements[1].color = (0.34, 0.175, 0.082, 1.0)
        bump = nt.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value = 0.08
        bump.inputs["Distance"].default_value = 0.002

        nt.links.new(mapping.outputs["Vector"], wave.inputs["Vector"])
        nt.links.new(mapping.outputs["Vector"], noise.inputs["Vector"])
        nt.links.new(wave.outputs["Fac"], ramp.inputs["Fac"])
        nt.links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
        nt.links.new(noise.outputs["Fac"], bump.inputs["Height"])
        nt.links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])
        set_bsdf_input(bsdf, ["Roughness"], 0.38)
        set_bsdf_input(bsdf, ["Coat Weight", "Clearcoat"], 0.18)
        set_bsdf_input(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.25)
        provenance_textures[name] = {
            "source": "procedural_satin_oak_fallback",
            "note": "Scaled wood grain procedural shader used because native wood texture was absent.",
        }
    return mat


def make_pbr_solid(
    name: str,
    rgba: Sequence[float],
    roughness: float,
    metallic: float = 0.0,
    *,
    coat: float = 0.0,
    emission_rgba: Optional[Sequence[float]] = None,
    emission_strength: float = 0.0,
) -> bpy.types.Material:
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes["Principled BSDF"]
    set_bsdf_input(bsdf, ["Base Color"], (rgba[0], rgba[1], rgba[2], 1.0))
    set_bsdf_input(bsdf, ["Roughness"], roughness)
    set_bsdf_input(bsdf, ["Metallic"], metallic)
    if coat > 0.0:
        set_bsdf_input(bsdf, ["Coat Weight", "Clearcoat"], coat)
        set_bsdf_input(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.18)
    if emission_rgba is not None and emission_strength > 0.0:
        set_bsdf_input(bsdf, ["Emission Color", "Emission"], (*emission_rgba[:3], 1.0))
        set_bsdf_input(bsdf, ["Emission Strength"], emission_strength)
    return mat


def make_textured_card_material(
    name: str, img_path: Path, *, roughness: float = 0.58, emission_strength: float = 0.0
) -> bpy.types.Material:
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    img = bpy.data.images.load(str(img_path), check_existing=True)
    img.colorspace_settings.name = "sRGB"
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    set_bsdf_input(bsdf, ["Roughness"], roughness)
    set_bsdf_input(bsdf, ["Metallic"], 0.0)
    if emission_strength > 0.0:
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Emission Color"])
        set_bsdf_input(bsdf, ["Emission Strength"], emission_strength)
    return mat


def make_room_surface_material(
    name: str,
    maps: Dict[str, Optional[Path]],
    fallback_rgb: Tuple[float, float, float],
    tile_scale: Tuple[float, float, float],
    fallback_roughness: float,
    provenance_surfaces: Dict[str, Any],
) -> bpy.types.Material:
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]

    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = tile_scale
    nt.links.new(tc.outputs["UV"], mp.inputs["Vector"])

    alb = maps.get("Base Color")
    if alb and alb.is_file():
        link_image_texture(nt, bsdf, alb, "Base Color", colorspace="sRGB", mapping_node=mp)
        rgh = maps.get("Roughness")
        if rgh and rgh.is_file():
            link_image_texture(nt, bsdf, rgh, "Roughness", colorspace="Non-Color", mapping_node=mp)
        else:
            set_bsdf_input(bsdf, ["Roughness"], fallback_roughness)
        nor = maps.get("Normal")
        if nor and nor.is_file():
            link_image_texture(nt, bsdf, nor, "Normal", colorspace="Non-Color", mapping_node=mp, normal_strength=0.65)
        provenance_surfaces[name] = {
            role: {"filename": p.name, "path": str(p), "sha256": sha256_file(p)}
            for role, p in maps.items()
            if p and p.is_file()
        }
    else:
        set_bsdf_input(bsdf, ["Base Color"], (*fallback_rgb, 1.0))
        set_bsdf_input(bsdf, ["Roughness"], fallback_roughness)
        provenance_surfaces[name] = {
            "source": "procedural_fallback",
            "note": f"Native surface maps for {name} not present in local cache.",
        }
    return mat


def add_box_uv_mesh(
    name: str,
    center: Sequence[float],
    half: Sequence[float],
    mat: bpy.types.Material,
    *,
    bevel_m: float = 0.0,
    uv_scale: float = 1.0,
) -> bpy.types.Object:
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=center)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (half[0], half[1], half[2])
    bpy.ops.object.transform_apply(scale=True)
    # Assign clean world-scale box projection UVs
    mesh = obj.data
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    uv_layer = mesh.uv_layers.active.data
    for poly in mesh.polygons:
        n = poly.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
        for li in poly.loop_indices:
            v = mesh.vertices[mesh.loops[li].vertex_index].co
            if az >= ax and az >= ay:
                u, w = v.x * uv_scale, v.y * uv_scale
            elif ax >= ay:
                u, w = v.y * uv_scale, v.z * uv_scale
            else:
                u, w = v.x * uv_scale, v.z * uv_scale
            uv_layer[li].uv = (u, w)
    if bevel_m > 0.0:
        mod = obj.modifiers.new(name="Bevel", type="BEVEL")
        mod.width = bevel_m
        mod.segments = 2
        mod.limit_method = "ANGLE"
    obj.data.materials.append(mat)
    return obj


def add_top_face_uv_plate(
    name: str,
    half: Sequence[float],
    mat: bpy.types.Material,
) -> bpy.types.Object:
    """Create a box whose top face (+Z) maps UV [0,1]x[0,1] cleanly for cards / key cap."""
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 0.0, 0.0))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (half[0], half[1], half[2])
    bpy.ops.object.transform_apply(scale=True)
    mesh = obj.data
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    uv_layer = mesh.uv_layers.active.data
    hx, hy = max(1e-6, half[0]), max(1e-6, half[1])
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            v = mesh.vertices[mesh.loops[li].vertex_index].co
            # Rotate so card text reads upright facing the front-right camera
            u = 0.5 + (v.y / (2.0 * hy))
            w = 0.5 + (v.x / (2.0 * hx))
            uv_layer[li].uv = (u, w)
    obj.data.materials.append(mat)
    return obj


def add_front_face_uv_screen(
    name: str,
    half: Sequence[float],
    mat: bpy.types.Material,
) -> bpy.types.Object:
    """Create reader glass panel whose -X face (facing robot & camera) maps UV [0,1]x[0,1]."""
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 0.0, 0.0))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (half[0], half[1], half[2])
    bpy.ops.object.transform_apply(scale=True)
    mesh = obj.data
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    uv_layer = mesh.uv_layers.active.data
    hy, hz = max(1e-6, half[1]), max(1e-6, half[2])
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            v = mesh.vertices[mesh.loops[li].vertex_index].co
            u = 0.5 + (v.y / (2.0 * hy))
            w = 0.5 + (v.z / (2.0 * hz))
            uv_layer[li].uv = (u, w)
    obj.data.materials.append(mat)
    return obj


def add_velvet_queue_ropes(mat_velvet: bpy.types.Material, mat_brass: bpy.types.Material) -> None:
    """Add realistic catenary velvet ropes hanging between the three desk.py brass stanchions."""
    posts = [(1.20, -0.78, 0.82), (1.20, 0.12, 0.82), (1.20, 1.04, 0.82)]
    for seg_i in range(len(posts) - 1):
        p0 = mathutils.Vector(posts[seg_i])
        p1 = mathutils.Vector(posts[seg_i + 1])
        curve_data = bpy.data.curves.new(f"velvet_rope_{seg_i}", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.bevel_depth = 0.017
        curve_data.bevel_resolution = 8
        spline = curve_data.splines.new("POLY")
        n_pts = 24
        spline.points.add(n_pts - 1)
        for k in range(n_pts):
            t = k / (n_pts - 1)
            pt = p0.lerp(p1, t)
            # Catenary sag of 16 cm in the middle
            sag = 0.16 * (1.0 - (2.0 * t - 1.0) ** 2)
            spline.points[k].co = (pt.x, pt.y, pt.z - sag, 1.0)
        obj = bpy.data.objects.new(f"velvet_rope_{seg_i}", curve_data)
        bpy.context.collection.objects.link(obj)
        obj.data.materials.append(mat_velvet)
        # Brass rope clasps at both ends
        for end_idx, ep in enumerate((p0, p1)):
            bpy.ops.mesh.primitive_cylinder_add(radius=0.022, depth=0.045, location=ep)
            clasp = bpy.context.active_object
            clasp.name = f"rope_clasp_{seg_i}_{end_idx}"
            clasp.data.materials.append(mat_brass)


def build_banquet_room(
    repo_root: Path, provenance_surfaces: Dict[str, Any]
) -> None:
    """Construct a complete enclosed 3D banquet hall foyer with native Genie UV maps,
    wainscoting trim, baseboards, crown molding, woven runner rug, and recessed daylight window."""
    floor_maps = find_surface_maps(
        repo_root,
        "genie_floor_04",
        {"Base Color": "floor_04_Alb.jpg", "Normal": "floor_04_Nor.jpg", "Roughness": "floor_04_Rgh.jpg"},
    )
    wall_maps = find_surface_maps(
        repo_root,
        "genie_wall_02",
        {"Base Color": "wall_02_Alb.jpg", "Normal": "wall_02_Nor.jpg", "Roughness": "wall_02_Rgh.jpg"},
    )

    mat_floor = make_room_surface_material(
        "genie_floor_04", floor_maps, (0.44, 0.31, 0.20), (0.50, 0.50, 1.0), 0.36, provenance_surfaces
    )
    mat_wall = make_room_surface_material(
        "genie_wall_02", wall_maps, (0.64, 0.61, 0.56), (0.50, 0.50, 1.0), 0.72, provenance_surfaces
    )
    mat_trim = make_pbr_solid("banquet_cream_trim", (0.76, 0.74, 0.69), roughness=0.44)
    mat_ceiling = make_pbr_solid("banquet_ceiling", (0.82, 0.80, 0.76), roughness=0.82)
    mat_rug = make_pbr_solid("banquet_runner_rug", (0.52, 0.49, 0.44), roughness=0.90)
    mat_window_frame = make_pbr_solid("window_mullion", (0.20, 0.16, 0.12), roughness=0.38)
    mat_sky_pane = make_pbr_solid(
        "window_daylight_backdrop",
        (0.95, 0.96, 0.98),
        roughness=0.25,
        emission_rgba=(0.98, 0.94, 0.86),
        emission_strength=2.2,
    )

    # Room bounds: X in [-2.45, 3.15], Y in [-3.80, 2.85], Z in [0.0, 3.25]
    # Floor top strictly at z = 0.000 m (where Unitree G1 feet stand)
    add_box_uv_mesh("foyer_floor", (0.35, -0.475, -0.02), (3.10, 3.60, 0.02), mat_floor, uv_scale=0.5)
    add_box_uv_mesh("foyer_ceiling", (0.35, -0.475, 3.28), (3.10, 3.60, 0.03), mat_ceiling, uv_scale=0.5)

    # Subtle woven runner carpet beneath reception zone (very thin 1.5 mm, outside foot-sole plane or flush)
    add_box_uv_mesh("foyer_rug", (0.65, 0.10, 0.0008), (1.35, 1.45, 0.0008), mat_rug, bevel_m=0.0006)

    # Back wall (-X = -2.45) & Entrance wall (+X = 3.15) & Camera-side wall (-Y = -3.80)
    add_box_uv_mesh("wall_back_negX", (-2.50, -0.475, 1.625), (0.05, 3.60, 1.625), mat_wall, uv_scale=0.5)
    add_box_uv_mesh("wall_front_posX", (3.20, -0.475, 1.625), (0.05, 3.60, 1.625), mat_wall, uv_scale=0.5)
    add_box_uv_mesh("wall_right_negY", (0.35, -3.85, 1.625), (3.10, 0.05, 1.625), mat_wall, uv_scale=0.5)

    # +Y Wall (y = 2.85) WITH REAL 3D RECESSED DAYLIGHT WINDOW OPENING at X in [0.25, 2.15], Z in [0.88, 2.68]
    add_box_uv_mesh("wall_posY_left", (-1.10, 2.90, 1.625), (1.35, 0.05, 1.625), mat_wall, uv_scale=0.5)
    add_box_uv_mesh("wall_posY_right", (2.68, 2.90, 1.625), (0.53, 0.05, 1.625), mat_wall, uv_scale=0.5)
    add_box_uv_mesh("wall_posY_below_win", (1.20, 2.90, 0.44), (0.95, 0.05, 0.44), mat_wall, uv_scale=0.5)
    add_box_uv_mesh("wall_posY_above_win", (1.20, 2.90, 2.965), (0.95, 0.05, 0.285), mat_wall, uv_scale=0.5)

    # Window sill, casing, mullions, and luminous exterior sky plane behind window recess
    add_box_uv_mesh("window_sill", (1.20, 2.84, 0.87), (1.02, 0.11, 0.025), mat_trim, bevel_m=0.004)
    add_box_uv_mesh("window_header", (1.20, 2.85, 2.70), (1.02, 0.08, 0.03), mat_trim, bevel_m=0.003)
    for mx in (0.25, 0.88, 1.52, 2.15):
        add_box_uv_mesh(f"window_mullion_v_{mx:.2f}", (mx, 2.92, 1.78), (0.025, 0.03, 0.90), mat_window_frame)
    for mz in (1.48, 2.08):
        add_box_uv_mesh(f"window_mullion_h_{mz:.2f}", (1.20, 2.92, mz), (0.95, 0.025, 0.022), mat_window_frame)
    add_box_uv_mesh("window_exterior_sky", (1.20, 3.18, 1.78), (1.25, 0.02, 1.15), mat_sky_pane)

    # Architectural baseboards, chair-rail wainscoting, and crown molding on visible walls (-X and +Y)
    add_box_uv_mesh("baseboard_negX", (-2.435, -0.475, 0.075), (0.015, 3.55, 0.075), mat_trim)
    add_box_uv_mesh("chairrail_negX", (-2.435, -0.475, 0.96), (0.018, 3.55, 0.022), mat_trim)
    add_box_uv_mesh("crown_negX", (-2.42, -0.475, 3.21), (0.03, 3.55, 0.04), mat_trim)

    add_box_uv_mesh("baseboard_posY", (0.35, 2.835, 0.075), (3.05, 0.015, 0.075), mat_trim)
    add_box_uv_mesh("chairrail_posY_left", (-1.10, 2.835, 0.96), (1.35, 0.018, 0.022), mat_trim)
    add_box_uv_mesh("crown_posY", (0.35, 2.82, 3.21), (3.05, 0.03, 0.04), mat_trim)

    # Subtle recessed wainscoting panel frames along -X wall
    for py in (-2.0, -0.9, 0.2, 1.3, 2.2):
        add_box_uv_mesh(f"panel_frame_{py:.1f}", (-2.44, py, 0.52), (0.008, 0.42, 0.30), mat_trim, bevel_m=0.002)


def resolve_usd_path(repo_root: Path, usd_rel: str) -> Tuple[Optional[Path], List[str]]:
    searched = [
        repo_root / GENIE_ASSETS_REL / usd_rel,
        repo_root / MOBILE_WORLDS_LIB_REL / usd_rel,
    ]
    for cand in searched:
        if cand.is_file():
            return cand, [str(p) for p in searched]
    return None, [str(p) for p in searched]


def relink_imported_textures(
    imported_objs: Sequence[bpy.types.Object],
    native_maps: Dict[str, str],
    repo_root: Path,
) -> List[Dict[str, str]]:
    """Bind native 2K cached PNG/JPG maps from native-maps.json onto imported USD meshes."""
    used_maps: List[Dict[str, str]] = []
    seen = set()
    for obj in imported_objs:
        if obj.type != "MESH":
            continue
        for mat in obj.data.materials:
            if not mat or not mat.use_nodes:
                continue
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image is not None:
                    raw = node.image.filepath or node.image.name
                    fname = Path(raw).name
                    for k_rel, mapped_rel in native_maps.items():
                        if Path(k_rel).name == fname:
                            cand = repo_root / mapped_rel
                            if not cand.is_file():
                                cand = repo_root / k_rel
                            if cand.is_file():
                                node.image = bpy.data.images.load(str(cand), check_existing=True)
                                if any(tok in fname.lower() for tok in ("rgh", "rough", "met", "nor")):
                                    node.image.colorspace_settings.name = "Non-Color"
                                if str(cand) not in seen:
                                    seen.add(str(cand))
                                    used_maps.append({"path": str(cand), "sha256": sha256_file(cand)})
                            break
    return used_maps


def import_genie_furniture(
    repo_root: Path,
    native_maps: Dict[str, str],
    assets_index: set[str],
    provenance_geometry: Dict[str, Any],
    placed_instances: List[Dict[str, Any]],
) -> None:
    """Import verified Genie Sim USD furniture/props, grounding every mesh on its support surface."""
    for item in GENIE_BANQUET_LAYOUT:
        usd_rel = item["usd"]
        assert usd_rel in assets_index, f"Unverified Genie asset not in assets-index.json: {usd_rel}"
        usd_path, searched = resolve_usd_path(repo_root, usd_rel)

        if usd_path is None:
            # Document searched locations cleanly; add subtle procedural fallback ONLY for
            # non-essential decorative foyer plant/curtain so room stays coherent.
            provenance_geometry[item["key"]] = {
                "id": item["id"],
                "source": usd_rel,
                "revision": GENIE_REVISION,
                "status": "absent_from_local_cache",
                "searched_paths": searched,
                "fallback": "omitted" if item["key"] not in ("foyer_plant",) else "procedural_potted_ficus",
            }
            if item["key"] == "foyer_plant":
                px, py, pz = item["xyz"]
                mat_pot = make_pbr_solid("fallback_terracotta_pot", (0.48, 0.25, 0.14), 0.68)
                mat_leaf = make_pbr_solid("fallback_foliage", (0.12, 0.28, 0.13), 0.56)
                bpy.ops.mesh.primitive_cylinder_add(radius=0.19, depth=0.38, location=(px, py, pz + 0.19))
                bpy.context.active_object.data.materials.append(mat_pot)
                bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, radius=0.34, location=(px, py, pz + 0.88))
                bpy.context.active_object.data.materials.append(mat_leaf)
            continue

        before_objs = set(bpy.data.objects)
        bpy.ops.wm.usd_import(filepath=str(usd_path))
        new_objs = [o for o in bpy.data.objects if o not in before_objs]
        meshes = [o for o in new_objs if o.type == "MESH"]
        if not meshes:
            continue

        # Compute world bounding box of imported hierarchy
        parent = bpy.data.objects.new(f"genie_{item['key']}", None)
        bpy.context.collection.objects.link(parent)
        for o in new_objs:
            if o.parent is None:
                o.parent = parent

        bpy.context.view_layer.update()
        corners = [
            o.matrix_world @ mathutils.Vector(c)
            for o in meshes
            for c in o.bound_box
        ]
        xs = [c.x for c in corners]
        ys = [c.y for c in corners]
        zs = [c.z for c in corners]
        h_raw = max(1e-4, max(zs) - min(zs))
        scale_f = (item["target_height_m"] / h_raw) if item["target_height_m"] else 1.0

        cx, cy, zmin = 0.5 * (min(xs) + max(xs)), 0.5 * (min(ys) + max(ys)), min(zs)
        parent.scale = (scale_f, scale_f, scale_f)
        parent.rotation_euler = (0.0, 0.0, math.radians(item["yaw_deg"]))
        bpy.context.view_layer.update()

        # Re-evaluate world bounds after rotation/scale to ground strictly at target z
        corners2 = [
            o.matrix_world @ mathutils.Vector(c)
            for o in meshes
            for c in o.bound_box
        ]
        cx2 = 0.5 * (min(c.x for c in corners2) + max(c.x for c in corners2))
        cy2 = 0.5 * (min(c.y for c in corners2) + max(c.y for c in corners2))
        z_anchor = (
            max(c.z for c in corners2)
            if item["support"] == "ceiling"
            else min(c.z for c in corners2)
        )
        tx, ty, tz = item["xyz"]
        parent.location += mathutils.Vector((tx - cx2, ty - cy2, tz - z_anchor))
        bpy.context.view_layer.update()

        linked_maps = relink_imported_textures(meshes, native_maps, repo_root)
        provenance_geometry[item["key"]] = {
            "id": item["id"],
            "source": usd_rel,
            "local_path": str(usd_path),
            "revision": GENIE_REVISION,
            "sha256": sha256_file(usd_path),
            "native_textures": linked_maps,
        }
        placed_instances.append(
            {
                "key": item["key"],
                "is_genie": True,
                "xyz": item["xyz"],
                "target_height_m": item["target_height_m"],
                "yaw_deg": item["yaw_deg"],
                "support": item["support"],
            }
        )


def setup_lighting() -> Dict[str, Any]:
    """Natural daylight rig: broad window key from +Y sunlit window, cool soft sky fill
    preserving readable dark G1 joints, warm banquet ceiling bounce, and Nishita exterior sky."""
    scene = bpy.context.scene
    world = bpy.data.worlds.new("BanquetDaylightWorld")
    scene.world = world
    world.use_nodes = True
    nt = world.node_tree
    bg = nt.nodes["Background"]
    sky = nt.nodes.new("ShaderNodeTexSky")
    sky.sky_type = "NISHITA"
    sky.sun_disc = False
    sky.sun_elevation = math.radians(34.0)
    sky.sun_rotation = math.radians(145.0)
    nt.links.new(sky.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = 0.08

    def add_area(
        name: str,
        pos: Tuple[float, float, float],
        target: Tuple[float, float, float],
        energy: float,
        color: Tuple[float, float, float],
        size_x: float,
        size_y: float,
    ) -> Dict[str, Any]:
        ld = bpy.data.lights.new(name=name, type="AREA")
        ld.energy = energy
        ld.color = color
        ld.shape = "RECTANGLE"
        ld.size = size_x
        ld.size_y = size_y
        obj = bpy.data.objects.new(name=name, object_data=ld)
        bpy.context.collection.objects.link(obj)
        obj.location = pos
        direction = mathutils.Vector(target) - mathutils.Vector(pos)
        obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
        return {
            "name": name,
            "type": "AREA",
            "xyz": list(pos),
            "target": list(target),
            "energy": energy,
            "color_rgb": list(color),
            "size_xy": [size_x, size_y],
        }

    lights = [
        # Broad sunlit daylight window key pouring from +Y recessed window across G1 & desk
        add_area(
            "Window_BroadKey",
            (1.18, 2.68, 1.82),
            (0.28, -0.05, 0.85),
            360.0,
            (1.0, 0.91, 0.80),
            1.85,
            1.65,
        ),
        # Soft cool sky fill from camera-right-front so dark G1 joints stay readable without flat washout
        add_area(
            "Sky_SoftFill",
            (0.65, -2.85, 2.35),
            (0.25, 0.05, 0.90),
            165.0,
            (0.84, 0.91, 1.0),
            3.20,
            2.20,
        ),
        # Gentle overhead warm banquet ceiling bounce
        add_area(
            "Ceiling_WarmBounce",
            (0.25, 0.05, 3.12),
            (0.25, 0.05, 0.82),
            110.0,
            (1.0, 0.86, 0.70),
            2.80,
            2.40,
        ),
        # Subtle warm rim separating G1 silhouette from the -X wall
        add_area(
            "Foyer_BackRim",
            (-1.45, -1.65, 2.40),
            (0.05, 0.02, 1.05),
            75.0,
            (1.0, 0.88, 0.74),
            1.60,
            1.20,
        ),
    ]
    return {
        "mode": "banquet_natural_window_key_and_sky_fill",
        "world": {"sky_type": "NISHITA", "sun_disc": False, "strength": 0.08},
        "lights": lights,
    }


def create_camera(name: str, spec: Dict[str, Any]) -> bpy.types.Object:
    cam_data = bpy.data.cameras.new(name=name)
    cam_data.lens_unit = "FOV"
    cam_data.sensor_fit = "VERTICAL"
    cam_data.angle_y = math.radians(float(spec["fovy_deg"]))
    cam_data.clip_start = 0.05
    cam_data.clip_end = 50.0
    cam_obj = bpy.data.objects.new(name=name, object_data=cam_data)
    bpy.context.collection.objects.link(cam_obj)
    pos = mathutils.Vector(spec["pos"])
    target = mathutils.Vector(spec["target"])
    cam_obj.location = pos
    cam_obj.rotation_euler = (target - pos).to_track_quat("-Z", "Y").to_euler()
    return cam_obj


def configure_render_engine(engine: str, width: int, height: int, samples: int) -> str:
    scene = bpy.context.scene
    scene.render.resolution_x = width
    scene.render.resolution_y = height
    scene.render.resolution_percentage = 100
    scene.render.fps = 25
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"

    if engine == "cycles":
        scene.render.engine = "CYCLES"
        scene.cycles.samples = samples
        scene.cycles.use_denoising = True
        engine_label = f"Blender {bpy.app.version_string} Cycles ({samples} spp)"
    else:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
        scene.eevee.taa_render_samples = samples
        if hasattr(scene.eevee, "use_raytracing"):
            scene.eevee.use_raytracing = True
        engine_label = f"Blender {bpy.app.version_string} EEVEE Next ({samples} spp)"

    # AgX color management preserves readable highlight detail on light cards/ceramics
    try:
        scene.view_settings.view_transform = "AgX"
        scene.view_settings.look = "AgX - Base Contrast"
    except Exception:
        scene.view_settings.view_transform = "Filmic"
    scene.view_settings.exposure = 0.0
    scene.view_settings.gamma = 1.0
    return engine_label


def build_mujoco_objects(
    mesh_manifest: Dict[str, Any],
    mesh_npz: Any,
    tex_dir: Path,
    native_wood_maps: Dict[str, Optional[Path]],
    provenance_textures: Dict[str, Any],
) -> Tuple[List[Optional[bpy.types.Object]], Dict[str, bpy.types.Material], bpy.types.Object]:
    """Instantiate Blender objects for every exported MuJoCo visual geom."""
    mat_oak = make_oak_material("oak_desk_pbr", native_wood_maps, provenance_textures)
    mat_edge = make_pbr_solid("desk_apron_oak", (0.14, 0.072, 0.036), roughness=0.46)
    mat_brass = make_pbr_solid("brushed_brass", (0.72, 0.53, 0.24), roughness=0.30, metallic=0.88)
    mat_slate = make_pbr_solid("anodized_slate", (0.08, 0.12, 0.15), roughness=0.40, metallic=0.35)
    mat_trim = make_pbr_solid("badge_champagne_lip", (0.64, 0.56, 0.38), roughness=0.36, metallic=0.45)
    mat_sleeve = make_pbr_solid("badge_emerald_sleeve", (0.075, 0.28, 0.23), roughness=0.42, metallic=0.12, coat=0.12)
    mat_velvet = make_pbr_solid("stanchion_velvet_rope", (0.36, 0.045, 0.06), roughness=0.88, metallic=0.0)

    # Generate high-DPI Pillow textures for the 3 guest ID cards, queue key cap, and initial reader screen
    card_mats = {}
    for gi in (1, 2, 3):
        p = generate_guest_card_texture(gi, tex_dir / f"guest_card_{gi}.png")
        card_mats[f"printed_card_{gi}"] = make_textured_card_material(f"mat_card_{gi}", p, roughness=0.56)
    key_tex_idle = generate_queue_key_texture(tex_dir / "queue_key_idle.png", pressed=False)
    key_tex_pressed = generate_queue_key_texture(tex_dir / "queue_key_pressed.png", pressed=True)
    mat_key_idle = make_textured_card_material("mat_key_idle", key_tex_idle, roughness=0.35, emission_strength=0.10)
    mat_key_pressed = make_textured_card_material("mat_key_pressed", key_tex_pressed, roughness=0.30, emission_strength=0.65)

    reader_init = generate_reader_screen_texture(
        tex_dir / "reader_init.png", scanned_guests=(), returned_guests=(), queue_cleared=False
    )
    mat_reader = make_textured_card_material("mat_reader_glass", reader_init, roughness=0.18, emission_strength=0.95)

    # Add decorative velvet ropes & subtle brass zone legend strip (pure visual dressing clear of all contacts)
    add_velvet_queue_ropes(mat_velvet, mat_brass)
    plaque_tex = generate_zone_plaque_texture(tex_dir / "zone_plaque.png")
    mat_plaque = make_textured_card_material("mat_zone_plaque", plaque_tex, roughness=0.38)
    plaque_obj = add_top_face_uv_plate("desk_zone_plaque", (0.095, 0.014, 0.0004), mat_plaque)
    plaque_obj.location = (0.412, -0.312, 0.8204)

    objs: List[Optional[bpy.types.Object]] = []
    reader_obj: Optional[bpy.types.Object] = None
    g1_mat_cache: Dict[Tuple[str, str], bpy.types.Material] = {}

    for g in mesh_manifest["geoms"]:
        idx = int(g["index"])
        gname = str(g["name"])
        gtype = int(g["type"])
        size = g["size"]

        # Skip raw MuJoCo floor plane (replaced by Genie textured banquet foyer floor at z=0.0)
        if gname == "floor":
            objs.append(None)
            continue

        if g["is_robot"] and f"verts_{idx}" in mesh_npz:
            verts = mesh_npz[f"verts_{idx}"].tolist()
            faces = mesh_npz[f"faces_{idx}"].tolist()
            me = bpy.data.meshes.new(f"mj_{gname}_{idx}")
            me.from_pydata(verts, [], faces)
            me.update()
            me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
            obj = bpy.data.objects.new(f"g1_{gname}_{idx}", me)
            bpy.context.collection.objects.link(obj)
            mkey = (g["material_name"], g["mesh_name"])
            if mkey not in g1_mat_cache:
                g1_mat_cache[mkey] = make_g1_material(
                    f"g1_mat_{len(g1_mat_cache)}_{g['material_name'] or 'base'}",
                    g["rgba"],
                    g["finish_roughness"],
                    g["finish_metallic"],
                    g["mesh_name"] or gname,
                )
            obj.data.materials.append(g1_mat_cache[mkey])
            objs.append(obj)
            continue

        # Task & fixture primitives matching exact desk.py geometry
        if gname in card_mats:
            obj = add_top_face_uv_plate(gname, size[:3], card_mats[gname])
        elif gname == "ack_key":
            obj = add_top_face_uv_plate(gname, size[:3], mat_key_idle)
        elif gname == "reader_glass":
            obj = add_front_face_uv_screen(gname, size[:3], mat_reader)
            reader_obj = obj
        elif gtype == 6:  # mjGEOM_BOX
            if gname.startswith("oak_"):
                mat_u, bev = mat_oak, 0.002
            elif gname == "desk_apron":
                mat_u, bev = mat_edge, 0.001
            elif gname.startswith(("brass_", "guide_", "reader_stand")):
                mat_u, bev = mat_brass, 0.0005
            elif gname.startswith(("inlay_", "badge_lip_")):
                mat_u, bev = mat_trim, 0.0003
            elif gname.startswith("badge_"):
                mat_u, bev = mat_sleeve, 0.0005
            elif gname in ("key_mount", "reader_screen"):
                mat_u, bev = mat_slate, 0.001
            else:
                mat_u, bev = make_pbr_solid(f"solid_{gname}", g["rgba"], 0.48), 0.0
            obj = add_box_uv_mesh(gname, (0.0, 0.0, 0.0), size[:3], mat_u, bevel_m=bev)
        elif gtype == 5:  # mjGEOM_CYLINDER
            bpy.ops.mesh.primitive_cylinder_add(radius=size[0], depth=2.0 * size[1], vertices=40)
            obj = bpy.context.active_object
            obj.name = gname
            obj.data.materials.append(mat_brass)
        elif gtype == 2:  # mjGEOM_SPHERE
            bpy.ops.mesh.primitive_uv_sphere_add(radius=size[0], segments=32, ring_count=16)
            obj = bpy.context.active_object
            obj.name = gname
            obj.data.materials.append(mat_brass)
        else:
            objs.append(None)
            continue
        objs.append(obj)

    assert reader_obj is not None, "Expected reader_glass object from desk.py"
    return objs, {"key_idle": mat_key_idle, "key_pressed": mat_key_pressed, "reader": mat_reader}, reader_obj


def apply_frame_transforms(
    objs: Sequence[Optional[bpy.types.Object]],
    xpos: np.ndarray,
    xmat: np.ndarray,
) -> None:
    """Apply exact MuJoCo world positions & 3x3 rotation matrices to every visual geom."""
    for i, obj in enumerate(objs):
        if obj is None:
            continue
        p = xpos[i]
        m3 = mathutils.Matrix(xmat[i].reshape(3, 3).tolist())
        obj.location = (float(p[0]), float(p[1]), float(p[2]))
        obj.rotation_mode = "QUATERNION"
        obj.rotation_quaternion = m3.to_quaternion()


def update_dynamic_props(
    objs: Sequence[Optional[bpy.types.Object]],
    mesh_manifest: Dict[str, Any],
    mats: Dict[str, bpy.types.Material],
    tex_dir: Path,
    state_cache: Dict[Tuple[int, int, int, int, int], bpy.types.Image],
    scanned_mask: int,
    returned_mask: int,
    cleared: int,
    premature_code: int,
    sim_time_s: float,
) -> None:
    """Update queue_key cap highlight & upright reader screen purely from measured MuJoCo state."""
    guest_names = ("guest1_id", "guest2_id", "guest3_id")
    # Update ack_key cap material if physically cleared
    for g in mesh_manifest["geoms"]:
        if g["name"] == "ack_key":
            obj = objs[int(g["index"])]
            if obj is not None:
                target_mat = mats["key_pressed"] if cleared else mats["key_idle"]
                if obj.data.materials[0] != target_mat:
                    obj.data.materials[0] = target_mat
            break

    # Update reader screen texture (cached at 0.2 s clock quantization + exact state masks)
    t_bucket = int(round(sim_time_s * 5.0))
    key = (scanned_mask, returned_mask, cleared, premature_code, t_bucket)
    if key not in state_cache:
        scanned = [guest_names[i] for i in range(3) if scanned_mask & (1 << i)]
        returned = [guest_names[i] for i in range(3) if returned_mask & (1 << i)]
        prem = guest_names[premature_code - 1] if premature_code in (1, 2, 3) else None
        p = generate_reader_screen_texture(
            tex_dir / f"reader_{scanned_mask}_{returned_mask}_{cleared}_{premature_code}_{t_bucket}.png",
            scanned_guests=scanned,
            returned_guests=returned,
            queue_cleared=bool(cleared),
            premature_guest=prem,
            sim_time_s=sim_time_s,
        )
        img = bpy.data.images.load(str(p), check_existing=True)
        img.colorspace_settings.name = "sRGB"
        state_cache[key] = img
    for node in mats["reader"].node_tree.nodes:
        if node.type == "TEX_IMAGE":
            node.image = state_cache[key]
            break


def main() -> None:
    # Support Blender CLI invocation (arguments after '--') or standalone bpy python
    argv = sys.argv
    if "--" in argv:
        argv = argv[argv.index("--") + 1 :]
    else:
        argv = argv[1:]

    parser = argparse.ArgumentParser(description="Render 1920x1080 Unitree G1 banquet scenes in Blender 4.5.")
    parser.add_argument("--repo-root", type=str, default=None)
    parser.add_argument("--sim-dir", type=str, default=str(JOB_DIR / "out/sim"))
    parser.add_argument("--out-dir", type=str, default=str(JOB_DIR / "out/render"))
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--samples", type=int, default=48)
    parser.add_argument("--engine", choices=("eevee_next", "cycles"), default="eevee_next")
    parser.add_argument("--stills-only", action="store_true", help="Render only hero & macro stills for rapid inspection.")
    parser.add_argument("--branches", nargs="+", default=["safe", "unsafe"])
    args = parser.parse_args(argv)

    repo_root = resolve_repo_root(args.repo_root)
    sim_dir = Path(args.sim_dir).resolve()
    out_dir = Path(args.out_dir).resolve()
    tex_dir = out_dir / "generated_textures"
    out_dir.mkdir(parents=True, exist_ok=True)
    tex_dir.mkdir(parents=True, exist_ok=True)

    mesh_manifest = read_json(sim_dir / "scene_meshes.json")
    mesh_npz = np.load(sim_dir / "scene_meshes.npz")
    audit = read_json(sim_dir / "physics-audit.json")
    native_maps = read_json(JOB_DIR / "native-maps.json")
    assets_index = set(read_json(JOB_DIR / "assets-index.json")["objects"])

    clear_scene()
    engine_label = configure_render_engine(args.engine, args.width, args.height, args.samples)

    provenance_surfaces: Dict[str, Any] = {}
    provenance_geometry: Dict[str, Any] = {}
    provenance_textures: Dict[str, Any] = {}
    placed_instances: List[Dict[str, Any]] = []

    build_banquet_room(repo_root, provenance_surfaces)
    import_genie_furniture(repo_root, native_maps, assets_index, provenance_geometry, placed_instances)
    light_cfg = setup_lighting()

    # Resolve native oak wood maps for the oak reception desk (from benchmark_table_011 / tv_cabinet_001)
    wood_key_prefix = ".runtime/genie-assets/background/common/tv_cabinet/benchmark_tv_cabinet_001/textures/benchmark_tea_table_002_"
    native_wood_maps: Dict[str, Optional[Path]] = {}
    for role, suf in [("Base Color", "Alb.jpg"), ("Roughness", "Rgh.jpg"), ("Normal", "Nor.jpg")]:
        rel = native_maps.get(wood_key_prefix + suf)
        cand = (repo_root / rel) if rel else None
        native_wood_maps[role] = cand if (cand and cand.is_file()) else None

    mj_objs, dyn_mats, _ = build_mujoco_objects(
        mesh_manifest, mesh_npz, tex_dir, native_wood_maps, provenance_textures
    )
    cam_overview = create_camera("overview", CAMERAS["overview"])
    cam_macro = create_camera("macro", CAMERAS["macro"])
    scene = bpy.context.scene

    # Record complete visual & material provenance in appearance.json
    appearance = {
        "task_id": SOURCE_TASK,
        "id": IDENT,
        "title": TITLE,
        "renderer": engine_label,
        "resolution": [args.width, args.height],
        "fps": 25,
        "playback_speed": 1.0,
        "robot_materials": {
            "source": "Unitree G1 MuJoCo Menagerie (370c43965323c0944b433b202aac5058b5f907a9) + generated/concierge.py material_finish()",
            "uv_independent_native_base_colors": True,
            "external_photo_textures_on_robot": False,
            "intentional_smooth_satin_finishes": {
                "face_visor": {"roughness": 0.22, "metallic": 0.10, "note": "Smoked optical polymer sheen, non-mirror"},
                "painted_metal_shell": {"roughness": 0.42, "metallic": 0.58, "note": "Bead-blasted satin metallic finish"},
                "articulated_fingers": {"roughness": 0.54, "metallic": 0.04, "note": "Tactile semi-matte grip polymer"},
                "dark_flexible_joints": {"roughness": 0.74, "metallic": 0.14, "note": "Subdued matte finish preserving joint legibility"},
            },
        },
        "cameras": CAMERAS,
        "light_config": light_cfg,
        "surfaces": provenance_surfaces,
        "desk_textures": provenance_textures,
        "geometry": provenance_geometry,
        "placed_instances": placed_instances,
        "robot_meshes": [
            {
                "name": g["name"],
                "mesh_name": g["mesh_name"],
                "source_file": g["source_file"],
                "sha256": g["source_sha256"],
                "roughness": g["finish_roughness"],
                "metallic": g["finish_metallic"],
            }
            for g in mesh_manifest["geoms"]
            if g["is_robot"]
        ],
    }
    write_json(out_dir / "appearance.json", appearance)

    state_cache: Dict[Tuple[int, int, int, int, int], bpy.types.Image] = {}

    for branch in args.branches:
        poses = np.load(sim_dir / f"poses_{branch}.npz")
        times = poses["times"]
        xpos = poses["geom_xpos"]
        xmat = poses["geom_xmat"]
        st_scan = poses["state_scanned"]
        st_ret = poses["state_returned"]
        st_clr = poses["state_cleared"]
        st_prem = poses["state_premature"]
        n_frames = len(times)

        ev_t = float(audit["branches"][branch]["event"])
        ev_idx = int(np.argmin(np.abs(times - ev_t)))

        # 1. Hero poster (overview) & macro close-up at the exact measured key event frame
        apply_frame_transforms(mj_objs, xpos[ev_idx], xmat[ev_idx])
        update_dynamic_props(
            mj_objs, mesh_manifest, dyn_mats, tex_dir, state_cache,
            int(st_scan[ev_idx]), int(st_ret[ev_idx]), int(st_clr[ev_idx]), int(st_prem[ev_idx]), float(times[ev_idx]),
        )
        scene.render.image_settings.file_format = "JPEG"
        scene.render.image_settings.quality = 94

        scene.camera = cam_overview
        scene.render.filepath = str(out_dir / f"{branch}_poster.jpg")
        bpy.ops.render.render(write_still=True)

        scene.camera = cam_macro
        scene.render.filepath = str(out_dir / f"detail_{branch}.jpg")
        bpy.ops.render.render(write_still=True)

        if args.stills_only:
            continue

        # 2. Full 1x real-time 25 fps overview sequence (1920x1080 PNG frames)
        frame_dir = out_dir / f"frames_{branch}"
        frame_dir.mkdir(parents=True, exist_ok=True)
        scene.render.image_settings.file_format = "PNG"
        scene.camera = cam_overview
        for fi in range(n_frames):
            apply_frame_transforms(mj_objs, xpos[fi], xmat[fi])
            update_dynamic_props(
                mj_objs, mesh_manifest, dyn_mats, tex_dir, state_cache,
                int(st_scan[fi]), int(st_ret[fi]), int(st_clr[fi]), int(st_prem[fi]), float(times[fi]),
            )
            scene.render.filepath = str(frame_dir / f"frame_{fi:04d}.png")
            bpy.ops.render.render(write_still=True)

    print(f"[render.py] Rendered 1920x1080 outputs -> {out_dir}")


if __name__ == "__main__":
    main()
