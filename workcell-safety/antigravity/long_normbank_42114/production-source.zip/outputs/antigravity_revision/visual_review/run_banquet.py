"""Wire the returned Antigravity modules together using the project's installed runtimes."""
import argparse
import importlib.util
from pathlib import Path
import sys

D = Path(__file__).resolve().parent


def load_at(name, source):
    spec = importlib.util.spec_from_file_location(name, source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def banquet():
    src = D / 'jobs/banquet/src'
    sys.path.insert(0, str(src))
    pace = load_at('stage_choreography', D / 'choreography/generated/pace.py')
    # Integrate the separately returned time-parameterization at the boundary
    # between authored path solving and MuJoCo dynamics. Keep the raw source intact.
    source = src / 'solve.py'
    body = source.read_text()
    hook = '        for seg_i in range(len(knots) - 1):'
    assert body.count(hook) == 1
    body = body.replace(hook, '        knots = paced_knots(knots, q_knots, HZ)\n' + hook)
    ns = {'__name__': 'banquet_staged', '__file__': str(source), 'paced_knots': pace.paced_knots}
    exec(compile(body, str(source), 'exec'), ns)
    sys.argv = [str(source), '--repo-root', str(D.parents[2]), '--out-dir', str(D / 'host-runs/banquet-paced')]
    ns['main']()



if __name__ == "__main__":
    banquet()
