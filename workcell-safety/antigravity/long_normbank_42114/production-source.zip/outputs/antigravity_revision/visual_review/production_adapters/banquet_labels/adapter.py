"""Fix mirrored badge/screen UVs and improve macro optical readability."""

import math
from typing import Any, Callable, Dict, List, Sequence, Tuple

import bpy
import mathutils

_EXCLUDE = (
    "stand", "base", "foot", "post", "pole", "bracket", "pedestal", "mount", "neck",
    "card", "badge", "guest", "key", "lane", "rail", "guide", "desk", "table",
    "link", "pelvis", "torso", "shoulder", "elbow", "wrist", "hand", "finger",
    "thumb", "palm", "head", "knee", "ankle", "hip", "block", "stanchion",
)
_INCLUDE = ("reader", "screen", "display", "monitor", "bezel", "kiosk", "panel", "checkpoint", "led", "status")
_GENERIC = ("mj", "geom", "mesh", "obj", "body")
_MAX_YAW = math.radians(18.0)


def _make_uv_box(
    name: str, half: Sequence[float], mat: bpy.types.Material, uv_fn: Callable[[Any], Tuple[float, float]]
) -> bpy.types.Object:
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 0.0, 0.0))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (half[0], half[1], half[2])
    bpy.ops.object.transform_apply(scale=True)
    mesh = obj.data
    uv_layer = (mesh.uv_layers.active or mesh.uv_layers.new(name="UVMap")).data
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            uv_layer[li].uv = uv_fn(mesh.vertices[mesh.loops[li].vertex_index].co)
    obj.data.materials.append(mat)
    return obj


def _find_reader_head(objects: Any, screen: bpy.types.Object, half: Sequence[float]) -> List[str]:
    m_s = screen.matrix_basis
    p_s, r_s = m_s.to_translation(), m_s.to_3x3().normalized()
    prefix = screen.name.lower().split("_")[0] if "_" in screen.name else ""
    if prefix in _GENERIC:
        prefix = ""
    hy, hz = max(1e-6, float(half[1])), max(1e-6, float(half[2]))
    head = [screen.name]
    pool = objects.values() if isinstance(objects, dict) else objects
    for ob in pool:
        if not isinstance(ob, bpy.types.Object) or ob.type != "MESH" or ob is screen:
            continue
        lname = ob.name.lower()
        if max(ob.dimensions) > 0.50 or any(tok in lname for tok in _EXCLUDE):
            continue
        m_o = ob.matrix_basis
        d_loc = r_s.transposed() @ (m_o.to_translation() - p_s)
        if not (-0.025 <= d_loc.x <= 0.09 and abs(d_loc.y) <= hy + 0.07 and abs(d_loc.z) <= hz + 0.07):
            continue
        aligned = abs(r_s.col[0].dot(m_o.to_3x3().normalized().col[0])) > 0.98
        named = (len(prefix) >= 3 and lname.startswith(prefix)) or any(tok in lname for tok in _INCLUDE)
        if named or (aligned and abs(d_loc.y) <= 0.04 and abs(d_loc.z) <= 0.04):
            head.append(ob.name)
    return head


def install(production: Any) -> None:
    """Install right-handed card/screen UVs and stable macro/display optics."""
    if getattr(production, "_banquet_labels_installed", False):
        return
    production._banquet_labels_installed = True
    state: Dict[str, Any] = {"name": "", "half": (0.005, 0.1, 0.08), "head": None}

    if "macro" in getattr(production, "CAMERAS", {}):
        production.CAMERAS["macro"].update(pos=(-0.06, -0.82, 1.47), target=(0.415, 0.018, 0.890), fovy_deg=33.0)

    def add_top_face_uv_plate(name: str, half: Sequence[float], mat: bpy.types.Material) -> bpy.types.Object:
        hx, hy = max(1e-6, float(half[0])), max(1e-6, float(half[1]))
        return _make_uv_box(name, half, mat, lambda v: (0.5 - v.y / (2.0 * hy), 0.5 + v.x / (2.0 * hx)))

    def add_front_face_uv_screen(name: str, half: Sequence[float], mat: bpy.types.Material) -> bpy.types.Object:
        hy, hz = max(1e-6, float(half[1])), max(1e-6, float(half[2]))
        obj = _make_uv_box(name, half, mat, lambda v: (0.5 - v.y / (2.0 * hy), 0.5 + v.z / (2.0 * hz)))
        state.update(name=obj.name, half=(float(half[0]), hy, hz), head=None)
        return obj

    orig_apply = production.apply_frame_transforms

    def apply_frame_transforms(objects: Any, *args: Any, **kwargs: Any) -> Any:
        res = orig_apply(objects, *args, **kwargs)
        screen = bpy.data.objects.get(state["name"])
        if screen is None or screen.parent is not None:
            return res
        if state["head"] is None:
            state["head"] = _find_reader_head(objects, screen, state["half"])
        if len(state["head"]) < 2:
            return res
        m_s = screen.matrix_basis.copy()
        p_s, r_s = m_s.to_translation(), m_s.to_3x3().normalized()
        n = r_s @ mathutils.Vector((-1.0, 0.0, 0.0))
        cam = production.CAMERAS.get("macro", {}).get("pos", (-0.06, -0.82, 1.47))
        dx, dy = cam[0] - p_s.x, cam[1] - p_s.y
        yaw = max(-_MAX_YAW, min(_MAX_YAW, 0.45 * math.atan2(n.x * dy - n.y * dx, n.x * dx + n.y * dy)))
        pivot = p_s + r_s @ mathutils.Vector((max(state["half"][0], 0.015), 0.0, 0.0))
        rot = mathutils.Matrix.Translation(pivot) @ mathutils.Matrix.Rotation(yaw, 4, "Z") @ mathutils.Matrix.Translation(-pivot)
        for name in state["head"]:
            ob = bpy.data.objects.get(name)
            if ob is not None and ob.parent is None:
                ob.matrix_world = rot @ ob.matrix_basis
        return res

    production.add_top_face_uv_plate = add_top_face_uv_plate
    production.add_front_face_uv_screen = add_front_face_uv_screen
    production.apply_frame_transforms = apply_frame_transforms
