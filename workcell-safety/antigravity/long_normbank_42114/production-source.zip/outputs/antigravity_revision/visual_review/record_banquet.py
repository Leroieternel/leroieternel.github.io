"""Record Antigravity's geometry and time-stamped replay for the artist's second review."""
import argparse
import json
import os
import sys
from pathlib import Path
import bpy
import numpy as np

from banquet_native_preview import configure, production, D
from host_integrate import load_at


def main():
    p=argparse.ArgumentParser();p.add_argument('--proof',action='store_true');p.add_argument('--out',type=Path,default=D/'host-renders/banquet-candidate');p.add_argument('--samples',type=int,default=16)
    args=p.parse_args();dest=args.out.resolve();sim=D/'host-runs/banquet-paced'
    os.environ['BANQUET_REFERENCE_LIGHT']='1';configure()
    lettering=D/'production_adapters/banquet_labels/adapter.py'
    if lettering.exists():
        load_at('reviewed_reader_lettering',lettering).install(production)
    state={};build=production.build_mujoco_objects
    def remember(*inp):
        objects,materials,reader=build(*inp);state['objects']=objects;state['materials']=materials
        return objects,materials,reader
    production.build_mujoco_objects=remember
    sys.argv=[sys.argv[0],'--sim-dir',str(sim),'--out-dir',str(dest),'--samples',str(args.samples),'--stills-only']
    production.main()
    if args.proof:return
    scene=bpy.context.scene
    manifest=json.loads((sim/'scene_meshes.json').read_text());audit=json.loads((sim/'physics-audit.json').read_text())
    scene.render.fps=25;scene.render.use_persistent_data=True
    scene.render.image_settings.file_format='FFMPEG';scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264'
    scene.render.ffmpeg.constant_rate_factor='HIGH';scene.render.ffmpeg.audio_codec='NONE'
    scene.render.threads_mode='FIXED';scene.render.threads=4
    for branch in ('safe','unsafe'):
        with np.load(sim/f'poses_{branch}.npz') as archive:
            time=archive['times'];positions=archive['geom_xpos'];matrices=archive['geom_xmat']
            indicators=[archive[k] for k in ('state_scanned','state_returned','state_cleared','state_premature')]
        cache={};event=audit['branches'][branch]['event'];texture_dir=dest/'generated_textures'
        def pose(sc,*_):
            i=min(len(time)-1,max(0,sc.frame_current-1));t=float(time[i]);production.apply_frame_transforms(state['objects'],positions[i],matrices[i])
            production.update_dynamic_props(state['objects'],manifest,state['materials'],texture_dir,cache,*[int(field[i]) for field in indicators],t)
            local=(4.0<=t<=event+3.2) or (t>event+8 and t<time[-1]-2)
            sc.camera=bpy.data.objects['macro' if local else 'overview']
        scene.frame_start=1;scene.frame_end=len(time);scene.render.filepath=str(dest/f'{branch}.mp4')
        bpy.app.handlers.frame_change_pre.append(pose)
        try:
            scene.frame_set(1);pose(scene);bpy.ops.render.render(animation=True)
        finally:bpy.app.handlers.frame_change_pre.remove(pose)
    companion={b:dict(event=audit['branches'][b]['event'],frames=audit['branches'][b]['pose_samples'],physics_seconds=audit['branches'][b]['elapsed']) for b in ('safe','unsafe')}
    (dest/'recorded.json').write_text(json.dumps(companion,indent=1)+'\n')


if __name__=='__main__':main()
