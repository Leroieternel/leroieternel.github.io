from __future__ import annotations

from collections.abc import Sequence
import math
import numbers

_DWELL_DQ_TOL = 1e-6
_DWELL_SPEED_TOL = 1e-3
_VIA_VALLEY_RATIO = 0.15
_VIA_VALLEY_TURN_RATIO = 0.18
_VIA_COS_MARGIN = 0.05


def _validate_positive_real(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise ValueError(f"{name} must be a finite positive real number")
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise ValueError(f"{name} must be a finite positive real number")
    return result


def _coerce_knots(knots: object) -> list[int]:
    if knots is None or isinstance(knots, (str, bytes, bytearray, dict, set, frozenset)):
        raise ValueError("knots must be a 1D sequence of strictly increasing integer ticks")

    if hasattr(knots, "ndim"):
        if getattr(knots, "ndim") != 1:
            raise ValueError("knots must be 1D")
        if getattr(getattr(knots, "dtype", None), "kind", None) == "b":
            raise ValueError("knots cannot have boolean dtype")
        raw = knots.tolist()
    elif isinstance(knots, Sequence):
        raw = list(knots)
    else:
        raise ValueError("knots must be a 1D sequence of strictly increasing integer ticks")

    if len(raw) < 2:
        raise ValueError("knots must contain at least 2 entries (zero duration timeline)")

    parsed: list[int] = []
    for idx, item in enumerate(raw):
        if isinstance(item, bool) or not isinstance(item, numbers.Real):
            raise ValueError(f"knots[{idx}] must be an integer tick")
        if isinstance(item, numbers.Integral):
            tick = int(item)
        else:
            fval = float(item)
            if not math.isfinite(fval) or not fval.is_integer():
                raise ValueError(f"knots[{idx}] must be a finite integer tick")
            tick = int(fval)
        parsed.append(tick)

    if parsed[0] < 0:
        raise ValueError("knots must be non-negative")

    for idx in range(len(parsed) - 1):
        if parsed[idx + 1] <= parsed[idx]:
            raise ValueError(
                f"knots must be strictly increasing (zero or negative interval at index {idx})"
            )

    return parsed


def _coerce_q_knots(q_knots: object, expected_len: int) -> list[list[float]]:
    if q_knots is None or isinstance(q_knots, (str, bytes, bytearray, dict, set, frozenset)):
        raise ValueError("q_knots must be a 2D sequence of shape (n_knots, n_joints)")

    if hasattr(q_knots, "ndim"):
        if getattr(q_knots, "ndim") != 2:
            raise ValueError("q_knots must be 2D with shape (n_knots, n_joints)")
        if getattr(getattr(q_knots, "dtype", None), "kind", None) == "b":
            raise ValueError("q_knots cannot have boolean dtype")
        raw_rows = q_knots.tolist()
    elif isinstance(q_knots, Sequence):
        raw_rows = list(q_knots)
    else:
        raise ValueError("q_knots must be a 2D sequence of shape (n_knots, n_joints)")

    if len(raw_rows) != expected_len:
        raise ValueError(
            f"q_knots length ({len(raw_rows)}) must match knots length ({expected_len})"
        )

    parsed: list[list[float]] = []
    n_joints: int | None = None
    for row_idx, row in enumerate(raw_rows):
        if row is None or isinstance(row, (str, bytes, bytearray, dict, set, frozenset)):
            raise ValueError(f"q_knots[{row_idx}] must be a 1D sequence of joint angles")

        if hasattr(row, "ndim"):
            if getattr(row, "ndim") != 1:
                raise ValueError(f"q_knots[{row_idx}] must be 1D")
            if getattr(getattr(row, "dtype", None), "kind", None) == "b":
                raise ValueError(f"q_knots[{row_idx}] cannot have boolean dtype")
            vals = row.tolist()
        elif isinstance(row, Sequence):
            vals = list(row)
        else:
            raise ValueError(f"q_knots[{row_idx}] must be a 1D sequence of joint angles")

        if n_joints is None:
            n_joints = len(vals)
            if n_joints == 0:
                raise ValueError("q_knots must contain at least 1 joint column")
        elif len(vals) != n_joints:
            raise ValueError(
                f"inconsistent joint count at q_knots[{row_idx}]: expected {n_joints}, got {len(vals)}"
            )

        clean_row: list[float] = []
        for col_idx, val in enumerate(vals):
            if isinstance(val, bool) or not isinstance(val, numbers.Real):
                raise ValueError(f"q_knots[{row_idx}][{col_idx}] must be a finite real number")
            fval = float(val)
            if not math.isfinite(fval):
                raise ValueError(f"nonfinite joint angle at q_knots[{row_idx}][{col_idx}]")
            clean_row.append(fval)
        parsed.append(clean_row)

    return parsed


def _min_ticks_for_speed(dq: float, hz: float, max_speed: float) -> int:
    if dq <= 0.0:
        return 1
    scaled = dq * hz
    if not math.isfinite(scaled):
        raise ValueError("interval joint speed overflow")
    ticks = max(1, math.ceil(scaled / max_speed))
    while ticks > 1 and (scaled / (ticks - 1)) <= max_speed:
        ticks -= 1
    while (scaled / ticks) > max_speed:
        ticks += 1
    return ticks


def _cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    norm_a = math.hypot(*vec_a)
    norm_b = math.hypot(*vec_b)
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    return max(-1.0, min(1.0, dot / (norm_a * norm_b)))


def _split_motion_run(
    start: int,
    end: int,
    l2_speeds: list[float],
    dq_vecs: list[list[float]],
) -> list[tuple[int, int]]:
    length = end - start
    if length < 4:
        return [(start, end)]

    candidates: list[tuple[int, float]] = []
    idx = 1
    while idx <= length - 2:
        s_val = l2_speeds[start + idx]
        left = idx
        right = idx
        while right + 1 <= length - 2 and l2_speeds[start + right + 1] == s_val:
            right += 1

        if l2_speeds[start + left - 1] > s_val and l2_speeds[start + right + 1] > s_val:
            p_left = 0.0
            for j in range(left - 1, -1, -1):
                val = l2_speeds[start + j]
                if val <= s_val:
                    break
                if val > p_left:
                    p_left = val

            p_right = 0.0
            for j in range(right + 1, length):
                val = l2_speeds[start + j]
                if val <= s_val:
                    break
                if val > p_right:
                    p_right = val

            p_min = min(p_left, p_right)
            if p_min > 0.0:
                cross_cos = _cosine_similarity(
                    dq_vecs[start + left - 1], dq_vecs[start + right + 1]
                )
                ratio_limit = (
                    _VIA_VALLEY_TURN_RATIO if cross_cos < 0.5 else _VIA_VALLEY_RATIO
                )
                if s_val <= ratio_limit * p_min:
                    if right > left:
                        offset = (left + right + 1) // 2
                    else:
                        m = left
                        c_left = _cosine_similarity(
                            dq_vecs[start + m - 1], dq_vecs[start + m]
                        )
                        c_right = _cosine_similarity(
                            dq_vecs[start + m], dq_vecs[start + m + 1]
                        )
                        if c_left - c_right > _VIA_COS_MARGIN:
                            offset = m + 1
                        elif c_right - c_left > _VIA_COS_MARGIN:
                            offset = m
                        else:
                            score_after = max(
                                l2_speeds[start + m] / p_left,
                                l2_speeds[start + m + 1] / p_right,
                            )
                            score_before = max(
                                l2_speeds[start + m - 1] / p_left,
                                l2_speeds[start + m] / p_right,
                            )
                            offset = m + 1 if score_after <= score_before else m

                    if 2 <= offset <= length - 2:
                        candidates.append((offset, s_val / p_min))

        idx = right + 1

    if not candidates:
        return [(start, end)]

    # Keep non-overlapping split offsets with at least 2 intervals per sub-segment,
    # preferring deeper valleys if two candidates sit 1 interval apart.
    selected: list[tuple[int, float]] = []
    for offset, depth in candidates:
        if selected and offset - selected[-1][0] < 2:
            if depth < selected[-1][1]:
                selected[-1] = (offset, depth)
        else:
            selected.append((offset, depth))

    segments: list[tuple[int, int]] = []
    cursor = start
    for offset, _ in selected:
        split_idx = start + offset
        segments.append((cursor, split_idx))
        cursor = split_idx
    segments.append((cursor, end))
    return segments


def paced_knots(
    knots: Sequence[int],
    q_knots: Sequence[Sequence[float]],
    hz: float,
    *,
    max_joint_speed: float = 1.7,
    max_segment_avg_accel: float | None = 15.0,
) -> list[int]:
    """Retime solver tick knots before MuJoCo dynamics to bound joint speeds.

    Preserves the validated joint-space geometric path (`q_knots`), the solver
    clock (`hz`), stationary dwells, and every motion segment already within
    bounds. Only segments violating the joint speed bound (or the conservative
    multi-interval segment average acceleration bound) are stretched uniformly.

    Algorithm:
        1. Validate `hz`, strictly increasing integer `knots`, and rectangular
           finite 2D `q_knots` with matching length and non-zero intervals.
        2. Compute per-interval tick widths, joint displacements, infinity-norm
           joint speeds, and L2 joint speeds.
        3. Separate stationary dwells (untouched) from motion runs, and split
           directly abutting quintic zero-velocity via segments at deep speed
           valleys using directional continuity and normalized boundary speed.
        4. For each motion segment, compute the whole-segment stretch factor
           from `max_i |dq_i| / dt_i <= max_joint_speed` (default 1.7 rad/s)
           and, for segments of at least 4 intervals, the conservative average
           acceleration bound `2 * v_peak / T <= max_segment_avg_accel`
           (default 15.0 rad/s^2, leaving normal task motions untouched).
        5. Leave segments with stretch factor <= 1.0 at exact original tick
           lengths. Stretch exceeding segments proportionally via exact integer
           cumulative rounding, then clamp every interval to the smallest
           integer tick count that enforces its local `max |dq|` speed bound
           and never shortens any interval.

    Args:
        knots: Strictly increasing non-negative solver tick timestamps.
        q_knots: 2D sequence of shape `(len(knots), n_joints)` in radians.
        hz: Positive finite physics solver frequency in Hz (e.g., 500).
        max_joint_speed: Maximum permitted joint angular speed in rad/s.
        max_segment_avg_accel: Optional conservative limit on segment average
            acceleration `2 * v_peak / T` in rad/s^2, or `None` to disable.

    Returns:
        New `list[int]` of strictly increasing solver ticks starting at `0`
        with the same length as `knots`.
    """
    hz_f = _validate_positive_real(hz, "hz")
    v_lim = _validate_positive_real(max_joint_speed, "max_joint_speed")
    a_lim = (
        None
        if max_segment_avg_accel is None
        else _validate_positive_real(max_segment_avg_accel, "max_segment_avg_accel")
    )

    in_knots = _coerce_knots(knots)
    q_rows = _coerce_q_knots(q_knots, len(in_knots))

    n_intervals = len(in_knots) - 1
    orig_dks: list[int] = []
    dq_vecs: list[list[float]] = []
    max_dqs: list[float] = []
    max_speeds: list[float] = []
    l2_speeds: list[float] = []

    for i in range(n_intervals):
        dk = in_knots[i + 1] - in_knots[i]
        q0 = q_rows[i]
        q1 = q_rows[i + 1]
        dq_vec = [b - a for a, b in zip(q0, q1)]
        local_max_dq = max(abs(d) for d in dq_vec)
        inv_dt = hz_f / dk
        local_max_speed = local_max_dq * inv_dt
        local_l2_speed = math.hypot(*dq_vec) * inv_dt
        if not (math.isfinite(local_max_speed) and math.isfinite(local_l2_speed)):
            raise ValueError(f"nonfinite joint speed at interval {i}")

        orig_dks.append(dk)
        dq_vecs.append(dq_vec)
        max_dqs.append(local_max_dq)
        max_speeds.append(local_max_speed)
        l2_speeds.append(local_l2_speed)

    # Identify stationary dwell intervals: exact/sub-microradian holds, plus
    # multi-interval near-zero speed plateaus.
    is_dwell = [dq <= _DWELL_DQ_TOL for dq in max_dqs]
    idx = 0
    while idx < n_intervals:
        if max_speeds[idx] <= _DWELL_SPEED_TOL:
            run_end = idx + 1
            while run_end < n_intervals and max_speeds[run_end] <= _DWELL_SPEED_TOL:
                run_end += 1
            if run_end - idx >= 2:
                for k in range(idx, run_end):
                    is_dwell[k] = True
            idx = run_end
        else:
            idx += 1

    # Partition into stationary dwells and quintic motion segments.
    blocks: list[tuple[int, int, bool]] = []
    idx = 0
    while idx < n_intervals:
        dwell_flag = is_dwell[idx]
        run_end = idx + 1
        while run_end < n_intervals and is_dwell[run_end] == dwell_flag:
            run_end += 1
        if dwell_flag:
            blocks.append((idx, run_end, True))
        else:
            for seg_start, seg_end in _split_motion_run(idx, run_end, l2_speeds, dq_vecs):
                blocks.append((seg_start, seg_end, False))
        idx = run_end

    # Retime each violating motion segment proportionally while preserving dwells
    # and already-compliant segments untouched.
    new_dks: list[int] = []
    for seg_start, seg_end, dwell_flag in blocks:
        seg_dks = orig_dks[seg_start:seg_end]
        if dwell_flag:
            new_dks.extend(seg_dks)
            continue

        seg_max_dqs = max_dqs[seg_start:seg_end]
        v_peak = max(max_speeds[seg_start:seg_end])
        orig_ticks = sum(seg_dks)
        orig_duration = orig_ticks / hz_f

        scale = 1.0
        if v_peak > v_lim:
            scale = max(scale, v_peak / v_lim)

        check_accel = a_lim is not None and (seg_end - seg_start) >= 4
        if check_accel and a_lim is not None:
            avg_accel = (2.0 * v_peak) / orig_duration
            if avg_accel > a_lim:
                scale = max(scale, math.sqrt(avg_accel / a_lim))

        if scale <= 1.0:
            new_dks.extend(seg_dks)
            continue

        target_ticks = max(orig_ticks, math.ceil(scale * orig_ticks))
        v_cap = v_lim
        if check_accel and a_lim is not None:
            v_cap = min(v_cap, 0.5 * a_lim * (target_ticks / hz_f))

        cum_orig = 0
        prev_scaled = 0
        for orig_dk, local_dq in zip(seg_dks, seg_max_dqs):
            cum_orig += orig_dk
            scaled_cum = (2 * target_ticks * cum_orig + orig_ticks) // (2 * orig_ticks)
            prop_dk = scaled_cum - prev_scaled
            prev_scaled = scaled_cum
            req_dk = max(orig_dk, _min_ticks_for_speed(local_dq, hz_f, v_cap))
            new_dks.append(max(prop_dk, req_dk))

    paced = [0]
    tick = 0
    for dk in new_dks:
        tick += dk
        paced.append(tick)
    return paced
