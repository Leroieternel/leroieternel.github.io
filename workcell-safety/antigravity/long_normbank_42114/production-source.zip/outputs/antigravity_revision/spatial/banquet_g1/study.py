"""Paths and physical dimensions of the banquet reception desk, in metres."""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
SPATIAL=HERE.parent
REV=SPATIAL.parent
ROOT=REV.parents[1]
IDENT='long_normbank_42114'
CASE='normbank_42114'
RUN=HERE/'runs'/('22_'+CASE)
OLD=SPATIAL/'runs'/('22_'+CASE)
NATIVE=REV/'shared_spaces/assets/unitree_g1'
PUBLIC=HERE/'public'
MEDIA=HERE/'media'
SIDES=('left','right')
LANES={'guest1_id':-.181,'guest2_id':-.053,'guest3_id':.145}
INTAKE,SCAN,RETURN=.350,.412,.475
SURFACE=.82
KEY=(.338,.247)
BADGE_HALF=.032
BRANCHES=('safe','unsafe')
FPS=25
HZ=500

def read(f):return json.loads(f.read_text())
def write(f,v):
    f.parent.mkdir(exist_ok=True,parents=True)
    f.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def module(file,name):
    spec=importlib.util.spec_from_file_location(name,file)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m
def choreography():
    f=HERE/'generated/concierge.py';r=read(HERE/'provenance/concierge.json')
    assert r['sha256']==sha(f) and r['prompt_sha256']==sha(HERE/'requests/concierge.txt')
    return module(f,'banquet_choreography')
