"""Assemble the native G1 with three free badge sleeves and a sprung queue key."""
from study import *
import sys
import xml.etree.ElementTree as ET
import numpy as np
import mujoco as mj
from scipy.spatial.transform import Rotation
sys.path.insert(0,str(REV/'shared_spaces'))
from world import base_robot,add

ARM=('shoulder_pitch','shoulder_roll','shoulder_yaw','elbow','wrist_roll','wrist_pitch','wrist_yaw')
COL={'wood':(.28,.125,.055,1),'edge':(.13,.07,.04,1),'brass':(.55,.38,.15,1),'slate':(.07,.13,.16,1),
     'paper':(.83,.87,.83,1),'dark':(.035,.055,.061,1),'trim':(.26,.39,.39,1),'green':(.08,.31,.27,1)}

def click_orientation(side):
    sign=1 if side=='right' else -1
    return Rotation.from_euler('xyz',[-48*sign,51,13*sign],degrees=True).as_matrix()

def neutral(m):
    q=m.qpos0.copy()
    for side,sign in [('left',1),('right',-1)]:
        values={'hip_pitch':-.065,'knee':.13,'ankle_pitch':-.065,
                'shoulder_pitch':.11,'shoulder_roll':sign*.15,'elbow':.54,
                'wrist_pitch':.12,'hand_middle_0':-sign*1.04,'hand_middle_1':-sign*1.20,
                'hand_thumb_0':sign*.13,'hand_thumb_1':sign*.39,'hand_thumb_2':sign*.51,
                'hand_index_0':-sign*.39,'hand_index_1':-sign*.39}
        for k,v in values.items():q[m.joint(side+'_'+k+'_joint').qposadr[0]]=v
    return q

def body_vertices(m,d,body,g):
    mesh=m.geom_dataid[g];start=m.mesh_vertadr[mesh]
    vertices=m.mesh_vert[start:start+m.mesh_vertnum[mesh]].astype(float)
    world=vertices@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
    return (world-d.body(body).xpos)@d.body(body).xmat.reshape(3,3)

def block(parent,name,xyz,half,material,ct=0,af=0,**opts):
    return add(parent,'geom',name=name,type='box',pos=xyz,size=half,rgba=COL.get(material,material),contype=ct,conaffinity=af,group=1,**opts)
def cylinder(parent,name,xyz,size,material,**opts):
    return add(parent,'geom',name=name,type='cylinder',pos=xyz,size=size,rgba=COL[material],contype=0,conaffinity=0,group=1,**opts)

def model():
    root,world,robot=base_robot('g1')
    root.set('model','G1 banquet reception')
    root.find('option').attrib.update(timestep=str(1/HZ),iterations='90',cone='elliptic')
    # Resolve support and contact sites on the actual model meshes in their link frames.
    provisional=mj.MjModel.from_xml_string(ET.tostring(root,encoding='unicode'))
    data=mj.MjData(provisional);data.qpos[:]=neutral(provisional);mj.mj_forward(provisional,data)
    for side in SIDES:
        leg=side+'_ankle_roll_link';gid=next(g for g in range(provisional.ngeom) if provisional.geom_bodyid[g]==provisional.body(leg).id and provisional.geom_group[g]==2)
        verts=body_vertices(provisional,data,leg,gid)@data.body(leg).xmat.reshape(3,3).T+data.body(leg).xpos
        if side=='left':robot.set('pos',f'0 .027 {.7924-verts[:,2].min()+.0003:.9g}')
        name=side+'_hand_index_1_link';link=robot.find(f".//body[@name='{name}']")
        gid=next(g for g in range(provisional.ngeom) if provisional.geom_bodyid[g]==provisional.body(name).id and provisional.geom_group[g]==2)
        local=body_vertices(provisional,data,name,gid);relative=local@click_orientation(side).T
        for suffix,i in [('front',np.argmax(relative[:,0])),('low',np.argmin(relative[:,2]))]:
            add(link,'site',name=side+'_'+suffix,pos=local[i],size=.0008,group=5)
        col=link.find("geom[@class='collision']")
        col.attrib.update(name=side+'_index_contact',contype='4',conaffinity='3',friction='.75 .002 .0001',solref='.006 1',solimp='.96 .997 .001')
    # Reception table and the badge guides are fixed. Each sleeve has its own 6-DoF joint.
    add(world,'geom',name='floor',type='plane',size='9 9 .02',pos='0 0 0',rgba='.3 .26 .22 1',contype=1,conaffinity=2)
    for mode,pos in [('overview',(1.73,-2.32,1.59)),('detail',(1.18,-.87,1.45))]:
        forward=np.array(pos)-[.18,0,.83];right=np.cross([0,0,1],forward);right/=np.linalg.norm(right);up=np.cross(forward,right);up/=np.linalg.norm(up)
        add(world,'camera',name=mode,pos=pos,xyaxes=np.r_[right,up],fovy=40)
    block(world,'oak_desk',(.395,0,SURFACE-.021),(.218,.345,.021),'wood',1,2|4,friction='.50 .002 .0002')
    block(world,'desk_apron',(.395,0,SURFACE-.061),(.185,.30,.019),'edge')
    for i,x in enumerate((.214,.57)):
        for j,y in enumerate((-.304,.304)):
            block(world,f'oak_leg_{i}{j}',(x,y,.394),(.020,.019,.392),'wood')
            block(world,f'brass_foot_{i}{j}',(x,y,.034),(.021,.020,.033),'brass')
    for index,(guest,y) in enumerate(LANES.items(),1):
        for sign in (-1,1):
            block(world,f'guide_{index}_{sign}',(.412,y+sign*.049,SURFACE+.0024),(.106,.002,.0024),'brass',1,2)
        for zone,x in [('in',INTAKE),('scan',SCAN),('out',RETURN)]:
            block(world,f'inlay_{zone}_{index}',(x,y,SURFACE+.00018),(.001,.043,.00013),'trim')
        body=add(world,'body',name=guest,pos=[INTAKE,y,SURFACE+.00315]);add(body,'freejoint',name=guest+'_free')
        block(body,'badge_'+str(index),(0,0,0),(BADGE_HALF,.0415,.0028),'green',2,1|4,mass=.026,friction='.55 .002 .00015',condim=4,solref='.006 1')
        block(body,'badge_lip_'+str(index),(-BADGE_HALF+.0028,0,.0105),(.0028,.037,.0106),'trim',2,1|4,mass=.003,friction='.62 .002 .0001',solref='.006 1')
        block(body,'printed_card_'+str(index),(.0025,0,.00305),(.0257,.038,.0002),'paper',mass=.00005)
    block(world,'key_mount',(*KEY,SURFACE+.003),(.024,.025,.003),'slate')
    key=add(world,'body',name='queue_key',pos=[*KEY,SURFACE+.014],gravcomp=1)
    add(key,'joint',name='ack_depth',type='slide',axis=[0,0,1],range=[-.006,0],stiffness=350,damping=1.2,armature=.002)
    block(key,'ack_key',(0,0,0),(.017,.018,.007),'green',2,4,mass=.021,solref='.006 1')
    # Upright reader is behind the return pocket, clear of the fingers.
    block(world,'reader_stand',(.56,.035,SURFACE+.077),(.012,.036,.075),'brass')
    block(world,'reader_screen',(.548,.035,SURFACE+.185),(.011,.120,.064),'slate',1,4)
    block(world,'reader_glass',(.536,.035,SURFACE+.185),(.001,.115,.059),'dark')
    for i,(x,y) in enumerate(((1.20,-.78),(1.20,.12),(1.2,1.04))):
        cylinder(world,f'post_base_{i}',(x,y,.024),(.125,.024),'brass')
        cylinder(world,f'post_shaft_{i}',(x,y,.448),(.021,.411),'brass')
        add(world,'geom',name=f'post_finial_{i}',type='sphere',pos=[x,y,.88],size=.042,rgba=COL['brass'],contype=0,conaffinity=0)
    RUN.mkdir(exist_ok=True,parents=True)
    ET.ElementTree(root).write(RUN/'scene.xml',encoding='unicode')
    return mj.MjModel.from_xml_path(str(RUN/'scene.xml'))
