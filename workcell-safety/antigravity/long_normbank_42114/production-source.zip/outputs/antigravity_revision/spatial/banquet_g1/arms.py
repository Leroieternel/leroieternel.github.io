"""Continuous native arm IK with fixed feet and slight torso rotation toward the working badge."""
from desk import ARM, SIDES, click_orientation, neutral
import mujoco as mj
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

def ease(u):
    u=np.clip(u,0,1)
    return u**3*(10+u*(-15+6*u))

class Rig:
    def __init__(self,m):
        self.m=m;self.d=mj.MjData(m)
        self.q=neutral(m);self.d.qpos[:]=self.q
        self.ready={s:np.array([.321,.227 if s=='left' else -.18,.904]) for s in SIDES}
        self.ref={};self.ids={};self.bounds={};self.local={}
        for s in SIDES:
            ids=np.array([m.joint(s+'_'+k+'_joint').id for k in ARM])
            self.ids[s]=m.jnt_qposadr[ids]
            lo,hi=m.jnt_range[ids].T.copy()
            if s=='right':lo[1]=max(lo[1],-.60)
            if s=='left':hi[1]=min(hi[1],.60)
            self.bounds[s]=(lo+.001,hi-.001)
            self.ref[s]=np.array([.02,.17 if s=='left' else -.17,0,-.24,.80 if s=='left' else -.80,.25,0])
            self.q[self.ids[s]]=self.ref[s]
            self.local[s]=click_orientation(s)
        for s in SIDES:self.solve(s,self.ready[s],True)
        self.home=self.q.copy()
        self.max_error=0.;self.max_rot_error=0.

    def solve(self,s,target,initial=False):
        m,d,ix=self.m,self.d,self.ids[s];lo,hi=self.bounds[s]
        side=1 if s=='left' else -1
        current=self.q[ix].copy()
        prior=self.ref[s] if initial else self.home[ix]
        d.qpos[:]=self.q
        site=d.site(s+'_front');elbow=d.body(s+'_elbow_link');R=self.local[s]
        def err(v):
            d.qpos[ix]=v;mj.mj_kinematics(m,d)
            delta=Rotation.from_matrix(R@site.xmat.reshape(3,3).T).as_rotvec()
            # Comfort costs resolve the seventh degree of freedom while preserving the task pose.
            e=elbow.xpos
            return np.r_[site.xpos-target,.17*delta,.0019*(v-prior),.002*(v-current),
                         1.35*max(0.,side*e[1]-.30),1.5*max(0.,.137-side*e[1]),
                         .9*max(0.,e[2]-1.015),1.2*max(0.,-.052-e[0])]
        sol=least_squares(err,np.clip(current,lo,hi),bounds=(lo,hi),max_nfev=65 if initial else 22,
                          ftol=3e-9,xtol=3e-8,gtol=5e-9)
        self.q[ix]=sol.x;out=err(sol.x)
        return float(np.linalg.norm(out[:3])),float(np.rad2deg(np.linalg.norm(out[3:6])/.17))

    def at(self,goals,yaw):
        self.q[self.m.joint('waist_yaw_joint').qposadr[0]]=yaw
        for s in SIDES:
            key=(yaw,*goals[s])
            if getattr(self,'last_'+s,None)!=key:
                err,angle=self.solve(s,goals[s]);self.max_error=max(self.max_error,err)
                self.max_rot_error=max(self.max_rot_error,angle)
                setattr(self,'last_'+s,key)
        return self.q.copy()
