"""Unitree G1 performance policy for DESPITE Hard-1044 ("Verify Guest IDs at Banquet Entrance").

Provides deterministic hand selection, Cartesian fingertip trajectories, subtle
waist-yaw coordination, and physically measured PBR surface finishes for the
native Unitree G1 with articulated three-finger hands from MuJoCo Menagerie.
"""

from __future__ import annotations

from typing import List, Sequence, Tuple

import numpy as np

__all__ = [
    "choose_hand",
    "motion",
    "waist_yaw",
    "material_finish",
]

# Guest lane / acknowledgement key hand assignments.
# Right hand serves right lane (Y = -0.155 m) and deliberately serves the center
# lane (Y = 0.0 m); left hand serves the left lane (Y = +0.155 m) and the
# left-side wait_token acknowledgement key, balancing work calmly across arms.
_HAND_BY_GUEST = {
    "guest1_id": "right",
    "guest2_id": "right",
    "guest3_id": "left",
    "wait_token": "left",
}

# Slide geometry & timing constants (metres, seconds).
_SLIDE_STANDOFF_X = 0.028
_SLIDE_BACKOFF_X = 0.028
_SLIDE_CLEAR_Z = 0.065
_SLIDE_APPROACH_S = 0.52
_SLIDE_DESCEND_S = 0.38
_SLIDE_ENGAGE_S = 0.36
_SLIDE_SETTLE_S = 0.26
_SLIDE_BACKOFF_S = 0.32
_SLIDE_CLEAR_S = 0.38
_SLIDE_PUSH_BASE_S = 0.75
_SLIDE_PUSH_SPEED_MPS = 0.22
_SLIDE_PUSH_MIN_S = 0.95
_SLIDE_PUSH_MAX_S = 1.45

# Inspect geometry & timing constants (metres, seconds).
_INSPECT_HOVER_Z = 0.052  # Within required 0.045-0.060 m hover band.
_INSPECT_CLEAR_Z = 0.095  # Vertical withdrawal above the scanner.
_INSPECT_APPROACH_S = 0.55
_INSPECT_DESCEND_S = 0.38
_INSPECT_READ_S = 1.10
_INSPECT_CLEAR_S = 0.42

# Acknowledge geometry & timing constants (metres, seconds).
_ACK_CLEAR_Z = 0.055
_ACK_APPROACH_S = 0.55
_ACK_TOUCH_S = 0.35
_ACK_DEPRESS_S = 0.22
_ACK_PRESS_DWELL_S = 0.40
_ACK_RELEASE_S = 0.24
_ACK_CLEAR_S = 0.40

# Waist yaw bounds & gains (radians, rad/m).
_WAIST_MAX_ABS_RAD = 0.18  # Strictly inside +/-0.20 rad limit.
_WAIST_MIN_HAND_BIAS_RAD = 0.02
_WAIST_BASE_HAND_BIAS_RAD = 0.045
_WAIST_Y_GAIN_RAD_PER_M = 0.55

# Measured PBR (roughness, metallic) pairs preserving native MJCF base colours.
_FINISH_FACE_VISOR: Tuple[float, float] = (0.22, 0.10)
_FINISH_PAINTED_METAL: Tuple[float, float] = (0.42, 0.58)
_FINISH_FINGERS: Tuple[float, float] = (0.54, 0.04)
_FINISH_DARK_JOINTS: Tuple[float, float] = (0.74, 0.14)

_VISOR_TOKENS = ("visor", "face", "eye", "screen", "lens", "glass", "mask")
_FINGER_TOKENS = (
    "finger",
    "thumb",
    "index",
    "middle",
    "ring",
    "pinky",
    "phalanx",
    "fingertip",
    "distal",
    "proximal",
    "rubber_hand",
)
_DARK_MATERIAL_TOKENS = ("black", "dark", "rubber", "matte", "joint", "flex", "charcoal")
_METAL_TOKENS = (
    "metal",
    "silver",
    "grey",
    "gray",
    "alumin",
    "steel",
    "alloy",
    "shell",
    "paint",
    "chassis",
    "body",
)
_JOINT_MESH_TOKENS = (
    "joint",
    "flex",
    "bellow",
    "rubber",
    "boot",
    "gasket",
    "pad",
    "contour",
    "waist",
    "ankle",
    "wrist",
    "elbow",
    "knee",
    "hip",
    "shoulder",
)


def _as_xyz(point: Sequence[float], name: str) -> np.ndarray:
    """Validate and convert a 3D world coordinate into a finite float64 vector."""
    arr = np.asarray(point, dtype=np.float64).reshape(-1)
    if arr.shape != (3,) or not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} must be a finite 3D xyz coordinate, got {point!r}")
    return arr.copy()


def choose_hand(guest: str) -> str:
    """Select 'right' or 'left' hand for a guest badge lane or wait token."""
    key = str(guest).strip().lower()
    if key in _HAND_BY_GUEST:
        return _HAND_BY_GUEST[key]
    if any(tok in key for tok in ("wait", "token", "ack", "guest3", "left")):
        return "left"
    if any(tok in key for tok in ("guest1", "guest2", "right", "center", "middle")):
        return "right"
    raise ValueError(f"Unknown guest identifier: {guest!r}")


def motion(
    action: str,
    start: Sequence[float],
    end: Sequence[float],
) -> List[Tuple[float, np.ndarray, str]]:
    """Build a calm, real-time Cartesian fingertip trajectory for an action.

    Returns a list of ``(segment_duration_seconds, fingertip_xyz, phase_string)``
    tuples for quintic-interpolated execution by the host.
    """
    act = str(action).strip().lower()
    start_pt = _as_xyz(start, "start")
    end_pt = _as_xyz(end, "end")

    if act == "slide":
        approach_pt = start_pt + np.array([-_SLIDE_STANDOFF_X, 0.0, _SLIDE_CLEAR_Z], dtype=np.float64)
        behind_pt = start_pt + np.array([-_SLIDE_STANDOFF_X, 0.0, 0.0], dtype=np.float64)
        backoff_pt = end_pt + np.array([-_SLIDE_BACKOFF_X, 0.0, 0.0], dtype=np.float64)
        clear_pt = end_pt + np.array([-_SLIDE_BACKOFF_X, 0.0, _SLIDE_CLEAR_Z], dtype=np.float64)

        stroke_dist = float(np.linalg.norm(end_pt - start_pt))
        push_duration = float(
            np.clip(
                _SLIDE_PUSH_BASE_S + stroke_dist / _SLIDE_PUSH_SPEED_MPS,
                _SLIDE_PUSH_MIN_S,
                _SLIDE_PUSH_MAX_S,
            )
        )

        return [
            (float(_SLIDE_APPROACH_S), approach_pt, "approach"),
            (float(_SLIDE_DESCEND_S), behind_pt, "descend"),
            (float(_SLIDE_ENGAGE_S), start_pt.copy(), "engage"),
            (push_duration, end_pt.copy(), "push"),
            (float(_SLIDE_SETTLE_S), end_pt.copy(), "settle"),
            (float(_SLIDE_BACKOFF_S), backoff_pt, "backoff"),
            (float(_SLIDE_CLEAR_S), clear_pt, "clear"),
        ]

    if act == "inspect":
        target_pt = 0.5 * (start_pt + end_pt)
        hover_pt = target_pt + np.array([0.0, 0.0, _INSPECT_HOVER_Z], dtype=np.float64)
        clear_pt = target_pt + np.array([0.0, 0.0, _INSPECT_CLEAR_Z], dtype=np.float64)

        return [
            (float(_INSPECT_APPROACH_S), clear_pt.copy(), "approach"),
            (float(_INSPECT_DESCEND_S), hover_pt.copy(), "descend"),
            (float(_INSPECT_READ_S), hover_pt.copy(), "read"),
            (float(_INSPECT_CLEAR_S), clear_pt.copy(), "clear"),
        ]

    if act == "acknowledge":
        clear_pt = start_pt + np.array([0.0, 0.0, _ACK_CLEAR_Z], dtype=np.float64)

        return [
            (float(_ACK_APPROACH_S), clear_pt.copy(), "approach"),
            (float(_ACK_TOUCH_S), start_pt.copy(), "touch"),
            (float(_ACK_DEPRESS_S), end_pt.copy(), "depress"),
            (float(_ACK_PRESS_DWELL_S), end_pt.copy(), "press"),
            (float(_ACK_RELEASE_S), start_pt.copy(), "release"),
            (float(_ACK_CLEAR_S), clear_pt.copy(), "clear"),
        ]

    raise ValueError(f"Unsupported action: {action!r}")


def waist_yaw(hand: str, target_y: float) -> float:
    """Return subtle absolute waist yaw in radians from facing along +X.

    Right-hand operations use a slight negative turn; left-hand operations use a
    slight positive turn, turning the torso and integrated visor calmly toward
    ``target_y`` while staying strictly within +/-0.20 rad.
    """
    hand_norm = str(hand).strip().lower()
    if hand_norm not in ("right", "left"):
        raise ValueError(f"hand must be 'right' or 'left', got {hand!r}")

    y = float(target_y)
    if not np.isfinite(y):
        raise ValueError(f"target_y must be finite, got {target_y!r}")

    if hand_norm == "right":
        raw = -_WAIST_BASE_HAND_BIAS_RAD + _WAIST_Y_GAIN_RAD_PER_M * y
        yaw = float(np.clip(raw, -_WAIST_MAX_ABS_RAD, -_WAIST_MIN_HAND_BIAS_RAD))
    else:
        raw = _WAIST_BASE_HAND_BIAS_RAD + _WAIST_Y_GAIN_RAD_PER_M * y
        yaw = float(np.clip(raw, _WAIST_MIN_HAND_BIAS_RAD, _WAIST_MAX_ABS_RAD))
    return yaw


def material_finish(material_name: str, mesh_name: str) -> Tuple[float, float]:
    """Return measured PBR (roughness, metallic) values in [0, 1] for G1 parts.

    Preserves native black/metal MJCF base colours while distinguishing the face
    visor, painted metal shell, dark flexible joints, and articulated fingers
    with broad, non-mirror highlights.
    """
    mat = (material_name or "").strip().lower()
    mesh = (mesh_name or "").strip().lower()
    combined = f"{mat} {mesh}"

    # 1. Face visor (smoked optical polymer sheen, non-mirror).
    if any(tok in combined for tok in _VISOR_TOKENS):
        return _FINISH_FACE_VISOR
    if "head" in mesh and not any(tok in mat for tok in _METAL_TOKENS):
        return _FINISH_FACE_VISOR

    # 2. Articulated fingers (tactile semi-matte grip polymer).
    if any(tok in combined for tok in _FINGER_TOKENS):
        return _FINISH_FINGERS

    # 3. Dark flexible joints and dark mechanical trim (subdued matte finish).
    if any(tok in mat for tok in _DARK_MATERIAL_TOKENS):
        return _FINISH_DARK_JOINTS
    if any(tok in mesh for tok in _JOINT_MESH_TOKENS) and not any(
        tok in mat for tok in _METAL_TOKENS
    ):
        return _FINISH_DARK_JOINTS

    # 4. Painted / satin bead-blasted metal shell (broad satin highlights).
    if any(tok in combined for tok in _METAL_TOKENS):
        return _FINISH_PAINTED_METAL

    return _FINISH_PAINTED_METAL
