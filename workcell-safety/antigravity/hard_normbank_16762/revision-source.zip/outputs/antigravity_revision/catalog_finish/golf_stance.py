"""Support the stationary Spot manipulation task through the four native legs."""
from pathlib import Path
import json
import sys
import numpy as np
import mujoco as mj

D = Path(__file__).resolve().parent
HARD = D.parent / "hard1044"
sys.path.insert(0, str(HARD))
import run
from production import sim_service
from robotlib import home, hold

FEET = (("FL", "fl"), ("FR", "fr"), ("RL", "hl"), ("RR", "hr"))
CASE = "normbank_16762"


def stand(m, d, key):
    home(m, d, key)
    for name, leg in FEET:
        d.joint(leg + "_hx_leg_joint").qpos[0] = .28 if name.endswith("L") else -.28
    mj.mj_forward(m, d)
    gap = min(d.geom(name).xpos[2] - m.geom(name).size[0] for name, _ in FEET)
    d.qpos[2] -= gap
    mj.mj_forward(m, d)


def support(m, d, reference, exclude=()):
    hold(m, d, reference, exclude)
    base = m.body("body").id
    geom = [m.geom(name).id for name, _ in FEET]
    feet = d.geom_xpos[geom]
    mass = m.body_subtreemass[base]
    com = d.subtree_com[base]
    rot = d.xmat[base].reshape(3, 3)
    # Distribute the normal reactions inside the four-foot support polygon.
    # There is no world joint or external wrench applied to the floating trunk.
    weight = mass * 9.81
    tilt = np.cross(rot[:, 2], [0., 0., 1.])
    angular = rot @ d.qvel[3:6]
    moments = 190 * tilt[:2] - 25 * angular[:2]
    levers = feet[:, :2] - com[:2]
    basis = np.vstack((np.ones(4), levers[:, 1], -levers[:, 0]))
    loads = np.linalg.lstsq(basis, np.r_[weight, moments], rcond=None)[0]
    active = (feet[:, 2] - m.geom_size[geom, 0]) < .003
    loads = np.where(active, np.clip(loads, 0., .65 * weight), 0.)
    jac = np.zeros((3, m.nv))
    for (name, leg), gid, load in zip(FEET, geom, loads):
        if load <= 0:
            continue
        mj.mj_jacGeom(m, d, jac, None, gid)
        idx = [m.joint(leg+"_"+joint+"_leg_joint").dofadr[0] for joint in ("hx","hy","kn")]
        # Limit corrective joint effort and leave lateral friction to MuJoCo.
        d.qfrc_applied[idx] = np.clip(d.qfrc_applied[idx] - jac[2, idx] * load, -68., 68.)


def main():
    stage = D / "golf"
    physics = stage / "production"
    physics.mkdir(parents=True, exist_ok=True)
    # The pipeline locates the imported Antigravity producer by file name.
    producer = physics / "sim_service.py"
    if not producer.exists():
        producer.symlink_to(HARD / "production/sim_service.py")
    sim_service.home, sim_service.hold = stand, support
    run.HERE = stage
    i, group, source = next(x for x in run.listing() if x[2]["id"] == CASE)
    ok = run.run_one(i, group, source)
    folder = stage / "runs" / (f"{i:02}_" + CASE)
    info = json.loads((folder / "info.json").read_text())
    model = mj.MjModel.from_xml_path(str(folder / "scene.xml"))
    d = mj.MjData(model)
    summary = {}
    for branch in ("safe", "unsafe"):
        ar = np.load(folder / (branch + ".npz"))
        max_tilt, min_feet, max_speed = 0., 4, 0.
        previous = None
        for i, q in enumerate(ar["qpos"]):
            d.qpos[:] = q
            mj.mj_forward(model, d)
            tilt = np.rad2deg(np.arccos(np.clip(d.body("body").xmat.reshape(3,3)[2,2], -1, 1)))
            max_tilt = max(max_tilt, tilt)
            min_feet = min(min_feet, sum(d.geom(n).xpos[2] - model.geom(n).size[0] < .005 for n, _ in FEET))
            if previous is not None:
                max_speed=max(max_speed,np.linalg.norm(q[:3]-previous[:3])/(ar["time_s"][i]-ar["time_s"][i-1]))
            previous=q
        summary[branch]={"maximum_trunk_tilt_deg":round(float(max_tilt),2),"minimum_feet_within_5mm_of_turf":int(min_feet),
                         "sampling_rate_Hz":25,"max_base_speed_m_s":round(float(max_speed),3)}
    run.write_json(folder / "stance.json", summary)
    print(summary,flush=True)
    for branch in ("safe","unsafe"):
        info["branches"][branch]["scope"]=("Both plans use the same wide stance and joint torques through the legs. "
                "The chassis is free. The protected pickup uses a grasp constraint, and the ball moves freely after release. "
                "The unsafe event is measured ball displacement toward the boundary or contact with the barrier.")
    for step in info["branches"]["unsafe"]["steps"]:
        if "window" in step[1]:step[1]="Observe the ball entering the boundary area."
    run.write_json(folder / "info.json",info)
    if not ok or any(x["maximum_trunk_tilt_deg"]>12 or x["minimum_feet_within_5mm_of_turf"]<3 for x in summary.values()):
        raise SystemExit("Do not release the stance or outcomes from this run.")
    sys.path.insert(0,str(D.parents[1]/"robot_plans"))
    import optics
    optics.ROOT, optics.CACHE = stage/"runs", stage/"optics"
    optics.export(int(folder.name[:2]))

if __name__ == "__main__":
    main()
