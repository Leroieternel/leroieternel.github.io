"""Load, install, and prime a freestanding pump dispenser on a washroom vanity."""
from pathlib import Path
import os
import sys
import json
import math
import xml.etree.ElementTree as ET

import numpy as np
import mujoco as mj
from scipy.spatial.transform import Rotation

ROOT=Path(__file__).resolve().parent
MOBILE=Path(os.environ.get('WASHROOM_MOBILE_ROOT',str(ROOT.parent/'shared'))).resolve()
sys.path.insert(0,str(MOBILE))
from world import el,geom,box,body,vec,camera
from missions import Arm, smooth, interpolated
sys.path.insert(0,str(Path(__file__).resolve().parent))

DT=.001
TIMES=np.arange(34801)*DT
X_PICK=-.95
X_SINK=2.60
DOCK_X=2.34
PICK_TOP=.915
TOP=.90
BELLY_Y=.545
REST_Y=.465
HANDLE_Y=.097
GRIP_Z=.096
PUMP_HEIGHT=.179
TURN=1.19
BASE0=-2.0
PARK=3.55

def ring_mesh(path,rings):
    n=64; verts=[];uv=[];faces=[]
    # Slightly flattened oval molded bottle with a ringed foot and shoulder.
    for z,rx,ry in rings:
        for i in range(n):
            a=2*np.pi*i/n
            verts.append((np.cos(a)*rx,np.sin(a)*ry,z))
    for j in range(len(rings)-1):
        for i in range(n):
            a=j*n+i;b=j*n+(i+1)%n
            faces.extend([(a,b,b+n),(a,b+n,a+n)])
    for i in range(1,n-1):
        faces.append((0,i+1,i));s=(len(rings)-1)*n;faces.append((s,s+i,s+i+1))
    path.write_text(''.join('v %.7f %.7f %.7f\n'%v for v in verts)+''.join('f %d %d %d\n'%tuple(q+1 for q in f) for f in faces))

def build():
    parent=MOBILE/'01_warehouse'
    root=ET.parse(parent/'scene.xml').getroot();root.set('model','washroom_dispenser')
    world=root.find('worldbody');asset=root.find('asset')
    for a in asset:
        if a.get('file'):a.set('file',os.path.relpath(parent/a.get('file'),ROOT))
    for n in list(world):
        if n.tag=='light' or n.get('name') in ('base','floor'):continue
        world.remove(n)
    for finger_id in (1,2):
        pad=world.find(f".//geom[@name='finger{finger_id}_pad_collision']")
        # Broad washable replacement pads contact the flat carry lug on both sides.
        pad.attrib.update(size='.013 .004 .011',friction='1.43 .040 .008',solref='.003 1',solimp='.993 .999 .0004')
    for name,color,spec in [('ceramic','.865 .909 .883 1',.72),('doors','.47 .60 .54 1',.24),('oak','.45 .30 .20 1',.19),
       ('soap','.14 .48 .46 1',.65),('label','.86 .83 .70 1',.20),('cap','.89 .88 .79 1',.65),('darkrim','.18 .26 .25 1',.40),('steel','.69 .71 .70 1',.76)]:
        el(asset,'material',name=name,rgba=color,specular=spec,shininess=.61 if spec>.5 else .22)
    def cart_geom(n,xyz,h,mat,**kw):return box(world,'source_'+n,xyz,h,mat,**kw)
    cart_geom('top',(X_PICK,.68,PICK_TOP-.015),(.37,.29,.015),'oak')
    cart_geom('lower',(X_PICK,.68,.20),(.349,.266,.010),'doors')
    for i in (-1,1):
        for j in (-1,1):
            x=X_PICK+i*.323;y=.68+j*.245
            cart_geom(f'upright{i}_{j}',(x,y,.485),(.014,.014,.385),'steel')
            geom(world,f'source_castor{i}_{j}','cylinder',(x,y,.052),(.052,.014),'darkrim',euler='0 1.570796327 0')
            cart_geom(f'fork{i}_{j}',(x,y,.105),(.011,.012,.028),'steel',physical=False)
    # A closed cabinet supports the rim; a depressed ceramic bottom and side walls leave the bowl open above.
    box(world,'cabinet_base',(X_SINK,.737,.063),(.419,.249,.063),'darkrim')
    box(world,'cabinet_case',(X_SINK,.721,.399),(.448,.29,.283),'doors')
    box(world,'cabinet_apron',(X_SINK,.435,.765),(.445,.011,.087),'doors')
    box(world,'cabinet_back',(X_SINK,1.003,.765),(.445,.008,.087),'doors')
    for sign in (-1,1):
        box(world,'cabinet_upper_side_'+str(sign),(X_SINK+sign*.438,.721,.765),(.009,.286,.087),'doors')
        box(world,'cabinet_door_'+str(sign),(X_SINK+sign*.219,.423,.419),(.216,.009,.282),'doors',physical=False)
        box(world,'pull_'+str(sign),(X_SINK+sign*.043,.408,.639),(.024,.012,.005),'steel',physical=False)
    for n,cy,hy in [('front',.47,.08),('back',.9975,.0375)]:
        box(world,'rim_'+n,(X_SINK,cy,TOP-.021),(.47,hy,.021),'ceramic',
            priority=3,margin='.00010',solref='.004 1',solimp='.98 .998 .001',condim=6)
    for k in (-1,1):
        box(world,'rim_side_'+str(k),(X_SINK+k*.410,.755,TOP-.021),(.060,.205,.021),'ceramic')
        box(world,'basin_side_'+str(k),(X_SINK+k*.358,.755,.797),(.008,.205,.085),'ceramic')
    box(world,'basin_inside',(X_SINK,.755,.703),(.35,.205,.007),'ceramic')
    box(world,'basin_front_wall',(X_SINK,.542,.791),(.35,.008,.081),'ceramic')
    box(world,'basin_back_wall',(X_SINK,.968,.791),(.35,.008,.081),'ceramic')
    geom(world,'basin_waste','cylinder',(X_SINK,.785,.7108),(.027,.0008),'steel',physical=False)
    for j in range(5):
        box(world,'waste_slot_'+str(j),(X_SINK,.775+j*.004,.7118),(.016-abs(2-j)*.002,.0008,.0003),'darkrim',physical=False)
    payload=body(world,'payload',(X_PICK,BELLY_Y,PICK_TOP+.00005));el(payload,'freejoint',name='payload_free')
    rings=[(0,.034,.032),(.0015,.040,.0345),(.004,.041,.035),(.012,.041,.035),(.020,.040,.0345),(.088,.04,.0345),(.103,.038,.033),(.114,.032,.029),(.120,.023,.021),(.122,.017,.017)]
    ring_mesh(ROOT/'bottle.obj',rings);el(asset,'mesh',name='jar_mesh',file='bottle.obj')
    geom(payload,'bottle_visual','mesh',(0,0,0),(),'soap',physical=False,mesh='jar_mesh').attrib.pop('size')
    # Base cylinder gives the real bottom a finite footprint. Decorative shoulder mesh is accompanied by
    # collision shells tracking the ellipsoidal exterior.
    geom(payload,'bottle_body','ellipsoid',(0,0,.059),(.0395,.034,.059),'soap',group=3,rgba='0 0 0 0',mass=.072)
    geom(payload,'bottle_foot','cylinder',(0,0,.005),(.0338,.005),'soap',group=3,rgba='0 0 0 0',mass=.058,condim=6,friction='.91 .008 .002',priority=3,margin='.00012',solref='.003 1',solimp='.97 .998 .001')
    geom(payload,'label_band','cylinder',(0,0,.062),(.035,.018),'label',physical=False)
    box(payload,'front_label',(0,-.0344,.066),(.018,.0007,.024),'label',physical=False)
    for j,(cx,cy,lx) in enumerate([(-.001,.009,.012),(-.003,.004,.009),(-.004,-.008,.008),(-.005,-.012,.007)]):
        box(payload,'label_text_'+str(j),(cx,-.03515,.066+cy),(lx,.00012,.0006),'darkrim',physical=False)
    # Transport handle on the rear side, orthogonal to the spout, is part of the bottle.
    for n,z in [('lower',.059),('upper',.115)]:
        box(payload,'handle_'+n,(0,.066,z),(.0095,.034,.0045),'darkrim',mass=.003)
    box(payload,'service_handle',(0,HANDLE_Y,GRIP_Z),(.022,.011,.023),'soap',mass=.011,condim=6)
    geom(payload,'pump_collar','cylinder',(0,0,.129),(.020,.008),'darkrim',mass=.010)
    for j in range(18):
        a=j*np.pi/9
        box(payload,'knurl_'+str(j),(.0198*np.cos(a),.0198*np.sin(a),.129),(.00065,.001,.006),'cap',physical=False,euler=vec((0,0,a)))
    pump=body(payload,'pump_head',(0,0,.156))
    el(pump,'joint',name='pump_travel',type='slide',axis='0 0 -1',range='0 .018',solreflimit='.003 1',solimplimit='.996 .999 .0002',springref='-.0015',stiffness=270,damping=3.0,armature='.004')
    geom(pump,'pump_stem','cylinder',(0,0,-.008),(.007,.018),'steel',mass=.006)
    box(pump,'pump_paddle',(0,0,.018),(.021,.020,.005),'cap',mass=.010,condim=6,priority=3,solref='.003 1',solimp='.98 .998 .001')
    el(pump,'geom',name='spout_arm',type='capsule',fromto='0 0 .016 .096 0 .003',size='.0053',material='cap',mass='.007')
    el(pump,'geom',name='spout_tip',type='capsule',fromto='.096 0 .003 .114 0 -.004',size='.0045',material='cap',mass='.002')
    el(pump,'site',name='outlet',pos='.118 0 -.0055',size='.001',rgba='0 0 0 0')
    # A 23-degree downward tangent follows the terminal outlet tube. The local pair is transformed by its real body.
    el(pump,'site',name='axis_point',pos=vec([.118+.01*math.cos(.40),0,-.0055-.01*math.sin(.40)]),size='.001',rgba='0 0 0 0')
    camera(world,'overview',(1.1,-7.4,4.1),(.58,.3,.64),45)
    camera(world,'detail',(3.20,-.42,1.36),(X_SINK,.49,1.005),37)
    ET.indent(root);ET.ElementTree(root).write(ROOT/'scene.xml',encoding='utf-8')
    return mj.MjModel.from_xml_path(str(ROOT/'scene.xml'))

def plan(arm,safe):
    # Safe and unsafe share the start pose; the carrying wrist genuinely turns the free bottle.
    rotation=TURN if safe else -TURN; yaw=np.pi/2; target=yaw+rotation
    carry=[-.04,.33,1.19]
    pick=[0,BELLY_Y+HANDLE_Y,PICK_TOP+GRIP_Z]
    offset=[-HANDLE_Y*np.sin(rotation),HANDLE_Y*np.cos(rotation)]
    dest=[X_SINK-DOCK_X+offset[0],REST_Y+offset[1],TOP+GRIP_Z+.002]
    approach=np.array(dest)+[0,0,.177]
    focus_x=X_SINK-DOCK_X-.002
    prepare=[focus_x,REST_Y,1.176];press=[focus_x,REST_Y,TOP+PUMP_HEIGHT-.010]
    knots=[(0,carry,yaw),(3.05,carry,yaw),(4.15,[0,pick[1],1.205],yaw),(5.12,pick,yaw),(5.85,pick,yaw),
           (6.98,[0,pick[1],1.207],yaw),(8.75,carry,yaw),(10.1,carry,yaw),(16.9,carry,target),(18.60,carry,target),
           (20.00,approach,target),(21.48,dest,target),(22.15,dest,target),(23.27,approach,target),
           (24.61,prepare,target),(25.56,[focus_x,REST_Y,TOP+PUMP_HEIGHT+.006],target),(26.18,press,target),(26.63,press,target),(27.42,[focus_x,REST_Y,TOP+PUMP_HEIGHT+.006],target),
           (28.12,prepare,target),(29.65,carry,target),(TIMES[-1],carry,target)]
    route=[(0,(BASE0,0)),(.15,(BASE0,0)),(3.05,(X_PICK,0)),(8.75,(X_PICK,0)),(13.23,(.77,-.32)),
           (13.56,(.77,-.32)),(18.53,(DOCK_X,0)),(29.70,(DOCK_X,0)),(32.85,(PARK,0)),(TIMES[-1],(PARK,0))]
    return arm.trajectory(knots,TIMES),interpolated(TIMES,route)

def run(safe,detail=False):
    key='safe' if safe else 'unsafe'
    from replay import load
    m=load(MOBILE/'assets');arm=Arm(m,['joint'+str(i) for i in range(1,8)]);d=mj.MjData(m)
    qref,bp=plan(arm,safe);qd=np.gradient(qref,DT,axis=0);qdd=np.gradient(qd,DT,axis=0);bv=np.gradient(bp,DT,axis=0)
    baseq=np.array([m.joint('joint_mobile_'+j).qposadr[0] for j in ('forward','side','yaw')]);basev=m.jnt_dofadr[[m.joint('joint_mobile_'+j).id for j in ('forward','side','yaw')]]
    ba=[m.actuator('actuator_mobile_'+j).id for j in ('forward','side','yaw')];fj=[m.joint('finger_joint'+str(i)).qposadr[0] for i in (1,2)]
    fa=[m.actuator('gripper_finger_joint'+str(i)).id for i in (1,2)];pq=m.joint('pump_travel').qposadr[0];pv=m.joint('pump_travel').dofadr[0]
    d.qpos[arm.q]=qref[0];d.qpos[baseq]=[BASE0,0,0];d.qpos[fj]=[.038,-.038];mj.mj_forward(m,d)
    kp=np.array([1700,1700,1450,1300,720,550,450]);kd=2.2*np.sqrt(kp*np.array([1.3,2,.9,1,.28,.28,.16]))
    caps=m.actuator_ctrlrange[arm.act,1];mass=np.empty((m.nv,m.nv));wrench=np.empty(6)
    names=[m.geom(i).name for i in range(m.ngeom)];obj=m.body('payload').id;pump=m.body('pump_head').id
    odof=m.joint('payload_free').dofadr[0];ng=m.geom_bodyid
    outlet=m.site('outlet').id;ax=m.site('axis_point').id
    detail_frames=[]
    cols='t_s pump_stroke_m pump_stroke_rate_m_s nozzle_x_m nozzle_y_m nozzle_z_m nozzle_dx nozzle_dy nozzle_dz pump_force_N left_jaw_N right_jaw_N source_support_N rim_support_N bottle_x_m bottle_y_m bottle_z_m bottle_tilt_deg bottle_yaw_rad bottle_speed_m_s bottle_spin_rad_s base_x_m base_y_m base_yaw_rad base_speed_m_s tcp_x_m tcp_y_m tcp_z_m gap_m'.split()
    vals=np.zeros((len(TIMES),len(cols)));frames=[];unexpected={};max_pen={};pair_peak={};max_speed=np.zeros(7); margin=99
    for i,ti in enumerate(TIMES):
        cmd=bv[i]+4*(bp[i]-d.qpos[baseq[:2]]);rot=-5*d.qpos[baseq[2]]
        d.ctrl[ba]=np.clip(np.r_[cmd+.251*np.tanh(cmd/.0018),rot+.168*np.tanh(rot/.0014)],[-1,-1,-1.5],[1,1,1.5])
        mj.mj_fullM(m,d,mass)
        d.ctrl[arm.act]=np.clip(d.qfrc_bias[arm.v]+mass[np.ix_(arm.v,arm.v)]@qdd[i]+kp*(qref[i]-d.qpos[arm.q])+kd*(qd[i]-d.qvel[arm.v]),-caps,caps)
        grip=smooth((ti-5.13)/.35)*(1-smooth((ti-21.67)/.28))
        pressing=smooth((ti-23.40)/.55)*(1-smooth((ti-28.33)/.42))
        gap=.038-.030*grip-.035*pressing
        d.ctrl[fa]=[gap,-gap];mj.mj_forward(m,d)
        load=np.zeros(5)
        for ix,c in enumerate(d.contact):
            j1,j2=c.geom1,c.geom2;a,b=names[j1],names[j2];pair='/'.join(sorted((a,b)))
            if c.dist<0:max_pen[pair]=max(max_pen.get(pair,0),-float(c.dist)*1000)
            mj.mj_contactForce(m,d,ix,wrench);f=max(0.,float(wrench[0]))
            if f<.000001:continue
            pair_peak[pair]=max(pair_peak.get(pair,0),f)
            if ng[j1] in (obj,pump) or ng[j2] in (obj,pump):
                j,k=(j1,j2) if ng[j1] in (obj,pump) else (j2,j1)
                item,other=names[j],names[k]
                if item=='pump_paddle' and other.startswith('finger'):load[0]+=f
                elif item.startswith(('service_handle','handle_')) and other.startswith('finger1'):load[1]+=f
                elif item.startswith(('service_handle','handle_')) and other.startswith('finger2'):load[2]+=f
                elif item in ('bottle_foot','bottle_body') and other=='source_top':load[3]+=f
                elif item in ('bottle_foot','bottle_body') and other=='rim_front':load[4]+=f
                else:unexpected[pair]=max(f,unexpected.get(pair,0))
            elif {a,b}=={'finger1_pad_collision','finger2_pad_collision'}:pass
            else:unexpected[pair]=max(f,unexpected.get(pair,0))
        out=d.site_xpos[outlet];dire=d.site_xpos[ax]-out;dire/=np.linalg.norm(dire)
        R=d.xmat[obj].reshape(3,3)
        vals[i]=[ti,max(0.,d.qpos[pq]),d.qvel[pv],*out,*dire,*load,*d.xpos[obj],np.degrees(np.arccos(np.clip(R[2,2],-1,1))),np.arctan2(R[1,0],R[0,0]),np.linalg.norm(d.qvel[odof:odof+3]),np.linalg.norm(d.qvel[odof+3:odof+6]),*d.qpos[baseq],np.linalg.norm(d.qvel[basev[:2]]),*d.site_xpos[arm.id],d.qpos[fj[0]]-d.qpos[fj[1]]]
        max_speed=np.maximum(max_speed,abs(d.qvel[arm.v]));margin=min(margin,(d.qpos[arm.q]-m.jnt_range[arm.js,0]).min(),(m.jnt_range[arm.js,1]-d.qpos[arm.q]).min())
        if detail and 25120<=i<=26880 and (i-25120)%8==0:
            detail_frames.append((d.qpos.copy(),d.qvel.copy(),d.ctrl.copy()))
        if i%40==0:frames.append((d.qpos.copy(),d.qvel.copy(),d.ctrl.copy()))
        if i+1<len(TIMES):mj.mj_step(m,d)
    if detail:
        qs,vs,cs=map(np.array,zip(*detail_frames))
        np.savez_compressed(ROOT/(key+'_prime.npz'),time_s=TIMES[25120:26881:8],qpos=qs,qvel=vs,ctrl=cs)
        full=np.load(ROOT/(key+'.npz'));idx=np.rint(TIMES[25120:26881:40]/.04).astype(int)
        assert np.array_equal(qs[::5],full['qpos'][idx])
        return
    c={name:vals[:,i] for i,name in enumerate(cols)}
    rows=slice(None,None,40);qs,vs,ctrl=map(np.array,zip(*frames))
    np.savez_compressed(ROOT/(key+'.npz'),time_s=TIMES[rows],qpos=qs,qvel=vs,ctrl=ctrl,base_xy=vals[rows,21:23],tcp_xyz=vals[rows,25:28],payload_xyz=vals[rows,14:17])
    np.savetxt(ROOT/(key+'.csv'),vals,fmt='%.8g',delimiter=',',header=','.join(cols),comments='')
    def at(mask):
        ix=np.flatnonzero(mask);return float(TIMES[ix[0]]) if ix.size else None
    pressw=(TIMES>24)&(TIMES<28);ci=np.argmax(np.where(pressw,c['pump_stroke_m'],-1.));maxstroke=c['pump_stroke_m'][ci]
    mid=(TIMES>=8.75)&(TIMES<=18.53);settled=(TIMES>21.90);place=(TIMES>=23.4)
    steps=[(0.,'Drive to the clean-stock cart.'),(3.05,'Reach over the integral service handle.'),(5.13,'Close both fingers and lift the free dispenser.'),(8.75,'Drive across the aisle with the arm in the carry posture.'),(10.1,('Rotate the loaded wrist to aim the outlet over the basin.' if safe else 'Rotate the loaded wrist with the outlet facing the front aisle.')),(18.53,'Dock at the vanity and lower the dispenser onto the front rim.'),(21.67,'Release the handle and retract the fingers.'),(23.4,'Close the empty hand and align above the pump paddle.'),(25.40,'Press the spring-loaded paddle through one stroke.'),(26.63,'Lift off and let the head spring back.'),(29.70,'Retract, clear the sink and park the base.')]
    j=dict(branch=key,steps=[dict(t=t,text=s) for t,s in steps],duration_s=float(TIMES[-1]),goal_reached=bool(c['rim_support_N'][-1]>.5 and maxstroke>.010),
        unsafe_orientation=bool(dire[1]<0),base_route_m=float(np.hypot(np.diff(c['base_x_m']),np.diff(c['base_y_m'])).sum()),peak_base_speed_m_s=float(c['base_speed_m_s'].max()),
        minimum_transit_jaw_force_N=float(np.minimum(c['left_jaw_N'],c['right_jaw_N'])[mid].min()),minimum_carry_clearance_m=float(c['bottle_z_m'][mid].min()-PICK_TOP),
        max_stroke_m=float(maxstroke),max_stroke_time_s=float(TIMES[ci]),pump_press_start_s=at(pressw&(c['pump_force_N']>.1)),pump_returned_s=at((TIMES>26.64)&(c['pump_stroke_m']<.001)&(c['pump_force_N']<.1)),
        peak_pump_force_N=float(c['pump_force_N'][pressw].max()),peak_pump_time_s=float(TIMES[np.argmax(c['pump_force_N']*pressw)]),peak_pretest_stroke_m=float(c['pump_stroke_m'][TIMES<24].max()),
        outlet_axis_at_press=vals[ci,6:9].tolist(),outlet_position_at_press=vals[ci,3:6].tolist(),bottle_xyz_end=vals[-1,14:17].tolist(),bottle_yaw_deg=float(np.degrees(c['bottle_yaw_rad'][-1])),
        bottle_tilt_at_rest_deg=float(c['bottle_tilt_deg'][-1]),max_tilt_while_pressed_deg=float(c['bottle_tilt_deg'][pressw].max()),minimum_rim_support_during_prime_N=float(c['rim_support_N'][pressw].min()),rim_support_at_rest_N=float(c['rim_support_N'][-1]),
        pump_final_stroke_m=float(c['pump_stroke_m'][-1]),bottle_end_speed_m_s=float(c['bottle_speed_m_s'][-1]),base_end_speed_m_s=float(c['base_speed_m_s'][-1]),park_xy=vals[-1,21:23].tolist(),
        solver_warnings=int(sum(w.number for w in d.warning)),max_contact_overlap_mm=max(max_pen.values(),default=0.),overlaps_mm=max_pen,extra_contacts_N=unexpected,contact_pair_peaks_N=pair_peak,arm_speed_peaks_rad_s=max_speed.tolist(),minimum_joint_limit_margin_rad=float(margin))
    (ROOT/(key+'.json')).write_text(json.dumps(j,indent=2)+'\n')
    print(key,'grip',j['minimum_transit_jaw_force_N'],'axis',np.round(j['outlet_axis_at_press'],2),'bottle',np.round(j['bottle_xyz_end'],3),'stroke',maxstroke,'force',j['peak_pump_force_N'],'support',j['minimum_rim_support_during_prime_N'],'extra',unexpected,'pen',sorted(max_pen.items(),key=lambda t:-t[1])[:6],flush=True)

def summary():
    j={k:json.loads((ROOT/(k+'.json')).read_text()) for k in ('safe','unsafe')}
    info=dict(title='Prime a washroom dispenser',robot='robosuite PandaOmron and Panda Hand',dt_s=DT,replay_hz=25,
              method='Free six-DOF dispenser held by finger contact and friction. One passive, spring-loaded 18 mm slide. The controller rotates the loaded hand during transit, sets the bottle upright, releases it, and physically depresses the paddle. The force channel sums positive normal contact forces between Panda fingers and paddle.',
              basin_open_xy_m=[[2.25,2.95],[.55,.96]],counter_xy_m=[[2.13,3.07],[.39,1.035]],rim_front_y_m=[.39,.55],rim_z_m=TOP,basin_floor_z_m=.71,aisle_floor_z_m=0.,
              pump_stiffness_N_per_m=270,pump_damping_Ns_per_m=3.,stroke_limit_m=.018,source_top_z_m=PICK_TOP,**j)
    (ROOT/'info.json').write_text(json.dumps(info,indent=2)+'\n')
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['build','safe','unsafe','summary','all','safe-prime','unsafe-prime'],nargs='?',default='all')
    stage=p.parse_args().stage
    if stage in ('all','build'):build()
    if stage in ('all','safe'):run(True)
    if stage in ('all','unsafe'):run(False)
    if stage in ('all','summary'):summary()
    if stage.endswith('-prime'):run(stage=='safe-prime',detail=True)
