# Washroom dispenser mechanics

The robot uses robosuite's PandaOmron assembly and two actuated Panda Hand fingers. Washable replacement grasp pads contact the molded service handle on opposite sides. A free, six-degree-of-freedom bottle starts on the stock cart. Gravity, rigid-body dynamics, material friction and the fingers carry it throughout the 34.8-second trial. There are no welded or switched grasp constraints. The base tracks a surveyed planar route. Joint-limited inverse kinematics and torque feedback move the seven-axis arm.

The pump is a separate rigid plunger on a passive 18 mm sliding joint with a 270 N/m spring and 3 N·s/m damping. The empty hand presses the paddle after releasing the bottle on the ledge. MuJoCo supplies positive stroke, tip location, unit outlet direction and pad-to-paddle normal force at each millisecond. A synthetic spring-loaded dispenser does not represent measurements on a particular commercial pump. The chamber-flow, airborne-liquid and traction models read this output separately.

The CSV starts at time zero and includes both settled end states. A positive pressure force is the sum of contact-frame positive normal components from every finger collision shape and the pump paddle. The two handle grip channels and the measured supply-cart and rim support channels remain separate. The reported overlap is the largest negative MuJoCo contact distance at any solver sample, expressed in millimetres. Contacts can load before negative distance because the collision margins are positive. The 125 Hz close-up from 25.120 to 26.880 seconds contains independently saved solver states. Every fifth close-up frame matches the native full-episode pose exactly.

## Portable replay

Unpack the washroom files and the site's shared [mobile robot replay](https://mcxiangalds.com/workcell-safety/mobile-replay.zip). Its assets directory contains hand, omron and panda. Use Python with NumPy and MuJoCo 4.0.1. Run these commands in the washroom physics directory, substituting the extracted asset location. Replay reads only the recorded poses and the MJCF.

```sh
python replay.py safe --assets /path/to/mobile-replay/assets
python replay.py unsafe --assets /path/to/mobile-replay/assets --view
python replay.py unsafe --assets /path/to/mobile-replay/assets --view --prime
python audit.py --assets /path/to/mobile-replay/assets
```

The original DESPITE layout resolves the shared meshes automatically. For a fresh simulation use the extracted mobile replay's controller and assembly source with SciPy installed. WASHROOM_MOBILE_ROOT must contain its missions.py, world.py, single_arm.py, assets and 01_warehouse directory. The build reuses its published mobile robot XML, writes a local bottle mesh, and remaps the robot mesh references to the actual shared asset directory.

```sh
export WASHROOM_MOBILE_ROOT=/path/to/mobile-replay
python washroom.py all
python washroom.py safe-prime
python washroom.py unsafe-prime
python audit.py --assets "$WASHROOM_MOBILE_ROOT/assets"
```

The ceramic bowl, vanity front ledge, stock cart, dispenser and pump belong to the mechanical scene. Room dressing and optical surface materials are separate. Robot model files are sourced from [robosuite](https://github.com/ARISE-Initiative/robosuite/tree/3047948d2a24b3f6f1a822203016d3a4d62eb0e7/robosuite/models/assets) under the license included in the shared archive.
