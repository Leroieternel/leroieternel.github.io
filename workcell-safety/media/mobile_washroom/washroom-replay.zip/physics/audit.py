"""Check the sensor trace against saved MuJoCo poses for both dispenser runs."""
from pathlib import Path
import argparse
import json
import numpy as np
import mujoco as mj
from replay import load

ROOT=Path(__file__).resolve().parent
def verify(meshes=None):
    m=load(meshes);d=mj.MjData(m);output={}
    for b in ('safe','unsafe'):
        a=np.genfromtxt(ROOT/(b+'.csv'),delimiter=',',names=True)
        z=np.load(ROOT/(b+'.npz'));h=np.load(ROOT/(b+'_prime.npz'))
        j=json.loads((ROOT/(b+'.json')).read_text())
        assert np.allclose(np.diff(a['t_s']),.001);assert np.array_equal(z['time_s'],np.arange(len(z['time_s']))*.040)
        ind=np.arange(len(z['time_s']))*40
        assert np.allclose(z['payload_xyz'],np.c_[a['bottle_x_m'],a['bottle_y_m'],a['bottle_z_m']][ind],atol=1e-7)
        assert np.allclose(np.diff(h['time_s']),.008)
        assert np.array_equal(h['qpos'][::5],z['qpos'][np.rint(h['time_s'][::5]/.04).astype(int)])
        max_err=0;max_axis_error=0;nozzle=np.c_[a['nozzle_x_m'],a['nozzle_y_m'],a['nozzle_z_m']]
        axes=np.c_[a['nozzle_dx'],a['nozzle_dy'],a['nozzle_dz']]
        for i,q in enumerate(h['qpos']):
            t_idx=round(h['time_s'][i]*1000);d.qpos[:]=q;mj.mj_kinematics(m,d)
            pos=d.site('outlet').xpos;axis=d.site('axis_point').xpos-pos;axis/=np.linalg.norm(axis)
            max_err=max(max_err,np.linalg.norm(pos-nozzle[t_idx]));max_axis_error=max(max_axis_error,np.linalg.norm(axis-axes[t_idx]))
        assert max_err<1e-7 and max_axis_error<1e-7
        assert j['solver_warnings']==0 and not j['extra_contacts_N']
        assert j['goal_reached'] and j['minimum_transit_jaw_force_N']>3.
        assert j['minimum_carry_clearance_m']>.12
        assert .015<j['max_stroke_m']<.0181 and .1<j['peak_pump_force_N']<15
        assert j['peak_pretest_stroke_m']<.00020 and j['pump_final_stroke_m']<.0002
        assert j['minimum_rim_support_during_prime_N']>.20 and j['bottle_tilt_at_rest_deg']<.2 and j['max_tilt_while_pressed_deg']<1.
        assert j['outlet_axis_at_press'][1]*(1 if b=='safe' else -1)>.80
        assert j['bottle_end_speed_m_s']<.0001 and j['base_end_speed_m_s']<.0001
        assert j['max_contact_overlap_mm']<.1 and j['minimum_joint_limit_margin_rad']>.1
        assert np.all(np.array(j['arm_speed_peaks_rad_s'])<[2.175]*4+[2.61]*3)
        output[b]=dict(sample_count=len(a),replay_frames=len(ind),high_speed_frames=len(h['time_s']),nozzle_position_error_m=max_err,
                       nozzle_axis_error=max_axis_error,maximum_negative_contact_distance_mm=j['max_contact_overlap_mm'],
                       grip_floor_N_each=j['minimum_transit_jaw_force_N'],minimum_press_support_N=j['minimum_rim_support_during_prime_N'],
                       numerical_warnings=0,unexpected_object_contacts=0)
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--assets',type=Path);args=p.parse_args()
    result=verify(args.assets);(ROOT/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
