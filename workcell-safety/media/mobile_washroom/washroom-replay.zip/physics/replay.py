"""Inspect recorded free-body pump states in the physics scene, optionally in the native viewer."""
import argparse
from pathlib import Path
import time
import xml.etree.ElementTree as ET

import mujoco as mj
import numpy as np

ROOT=Path(__file__).resolve().parent

def load(directory=None):
    tree=ET.parse(ROOT/'scene.xml')
    for a in tree.findall('asset/mesh'):
        original=Path(a.get('file'))
        if directory and 'assets' in original.parts:
            n=original.parts.index('assets')
            path=directory.joinpath(*original.parts[n+1:])
        else:path=ROOT/original
        if not path.is_file():
            raise FileNotFoundError(f'Missing {path}. Pass --assets with the assets directory extracted from mobile-replay.zip.')
        a.set('file',str(path.resolve()))
    return mj.MjModel.from_xml_string(ET.tostring(tree.getroot(),encoding='unicode'))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('branch',choices=('safe','unsafe'))
    parser.add_argument('--assets',type=Path,help='Extracted robosuite mesh directory containing omron/, panda/ and hand/.')
    parser.add_argument('--view',action='store_true')
    parser.add_argument('--prime',action='store_true',help='Play the true 125 Hz prime interval at five-times slow motion.')
    args=parser.parse_args()
    m=load(args.assets);d=mj.MjData(m)
    with np.load(ROOT/(args.branch+('_prime' if args.prime else '')+'.npz')) as z:
        q,zv,ctrl,ts=z['qpos'],z['qvel'],z['ctrl'],z['time_s']
    def show(i):
        d.qpos[:]=q[i];d.qvel[:]=zv[i];d.ctrl[:]=ctrl[i];d.time=ts[i];mj.mj_forward(m,d)
    if args.view:
        import mujoco.viewer
        with mujoco.viewer.launch_passive(m,d) as viewer:
            viewer.cam.type=mj.mjtCamera.mjCAMERA_FIXED
            viewer.cam.fixedcamid=m.camera('detail' if args.prime else 'overview').id
            start=time.monotonic()
            for i in range(len(q)):
                if not viewer.is_running():break
                sleep=start+i/25.-time.monotonic()
                if sleep>0:time.sleep(sleep)
                with viewer.lock():show(i)
                viewer.sync()
    else:
        show(-1);print(f'{len(q)} saved frames, {ts[0]:.3f} to {ts[-1]:.3f} s. Final dispenser base at {d.body("payload").xpos.round(5)} m.')
