# Prime a restroom dispenser

Extract this archive. Install Python, mujoco==4.0.1, numpy, scipy and Pillow. From this directory:

    python physics/replay.py unsafe --view
    python physics/replay.py safe --view --prime
    python physics/washroom.py all
    python liquid_solver.py
    python traction.py
    python physics/audit.py
    python run_switch_test.py

The replay viewer shows the native rigid bodies. The liquid and traction programs compute the first hit of each measured dose parcel and the rubber coupon response. The last command repeats the separate Service Check approach, then computes its discharge and traction measurements. The released records include 1 kHz solver data, 25 Hz robot states, 125 Hz prime states, parcel impacts and traction histories. The online Cycles films show the furnished room, liquid and coupon. Robot mesh attribution is in shared/assets/LICENSE. Model parameters are simulation inputs and are uncalibrated to an individual soap or a real bathroom.
