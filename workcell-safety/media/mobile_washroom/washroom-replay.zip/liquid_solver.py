"""Meter a primed hand pump from the recorded stroke and trace the discharged parcels."""
from pathlib import Path
import csv
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent
PHYS = ROOT / 'physics'
OUT = ROOT / 'liquid'
BORE_M = .016
OUTLET_M = .0028
FILM_M = .00018
PARCEL_ML = .006
DT = .001
AIR_DRAG = .55
GRAVITY = np.array([0., 0., -9.81])
MASK = np.array([1, 0, 0, 0, 0, 0], np.uint8)


def col(record, fields):
    return np.column_stack([record[name] for name in fields])


def meter(t, stroke, force):
    # The reservoir is primed. A return spring refills the chamber on release.
    # An unloaded, returning stem expels no fluid through the outlet valve.
    dose = np.zeros(len(stroke))
    reference = 0.
    loaded = False
    equilibrium = float(np.median(stroke[:min(1000,len(stroke))]))
    for i, s in enumerate(np.maximum(0., stroke-equilibrium)):
        if force[i] > .08:
            if not loaded: reference = max(0., s - (stroke[i]-stroke[max(0,i-1)]))
            loaded = True
        if loaded:
            delta = max(0., s-reference)
            dose[i] = delta * math.pi * (BORE_M/2)**2 * 1e6
            reference = max(reference, s)
        if force[i] <= .08 and s < .0006:
            loaded = False
    delivered = np.cumsum(dose)
    if delivered[-1] < 1e-10: return np.array([],int),np.array([]),np.array([])
    amounts=np.full(math.floor(delivered[-1]/PARCEL_ML),PARCEL_ML)
    residual=delivered[-1]-amounts.sum()
    if residual>1e-9: amounts=np.append(amounts,residual)
    idx=np.searchsorted(delivered,np.cumsum(amounts)-amounts/2)
    # Time-average the metered flow over 9 ms when estimating outlet velocity.
    ml_per_s=np.convolve(dose,np.ones(9)/9,'same')/DT
    speed=ml_per_s[idx]*1e-6/(math.pi*(OUTLET_M/2)**2)
    return idx, amounts, speed


def target(name, p):
    if name=='floor':return 'floor'
    if name.startswith('basin_'):return 'basin'
    if name.startswith('rim_') and .55<=p[1]<=.96 and 2.25<=p[0]<=2.95:return 'basin'
    return 'other'


def patches(deposits):
    """Collect nearby landed parcels into local lamellae on the struck surface."""
    if not len(deposits):return np.empty((0,4))
    deposits=np.asarray(deposits)
    cells=np.floor(deposits[:,:3]/[.018,.018,.003]).astype(int)
    _,index=np.unique(cells,axis=0,return_inverse=True)
    mass=np.bincount(index,weights=deposits[:,3])
    weighted=[np.bincount(index,weights=deposits[:,axis]*deposits[:,3])/mass for axis in range(3)]
    return np.column_stack([*weighted,mass])


def footprint_area_cm2(discs):
    if not len(discs):return 0.
    radii=np.sqrt(discs[:,3]*1.e-6/(np.pi*FILM_M))
    low=(discs[:,:2]-radii[:,None]).min(axis=0)
    high=(discs[:,:2]+radii[:,None]).max(axis=0)
    pitch=.00025
    x=np.arange(low[0]+pitch/2,high[0],pitch)
    y=np.arange(low[1]+pitch/2,high[1],pitch)
    covered=np.zeros((len(y),len(x)),bool)
    for (cx,cy,_,_),r in zip(discs,radii):
        covered|=(x[None,:]-cx)**2+(y[:,None]-cy)**2<r**2
    return float(covered.sum()*pitch*pitch*1e4)


def simulate(branch,phys=PHYS,out=OUT):
    import mujoco as mj
    record=np.genfromtxt(phys/(branch+'.csv'),delimiter=',',names=True)
    with np.load(phys/(branch+'.npz')) as trace:
        opt_t=trace['time_s'];positions=trace['qpos']
    t=record['t_s'];stroke=record['pump_stroke_m']
    nozzle=col(record,['nozzle_x_m','nozzle_y_m','nozzle_z_m'])
    axis=col(record,['nozzle_dx','nozzle_dy','nozzle_dz'])
    axis/=np.linalg.norm(axis,axis=1,keepdims=True)
    idx,volume,speed=meter(t,stroke,record['pump_force_N'])
    prime=phys/(branch+'_prime.npz')
    if len(idx) and prime.exists():
        with np.load(prime) as trace:
            prime_t=trace['time_s']
            if prime_t[0]<=t[idx[0]] and prime_t[-1]>=t[idx[-1]]+.60:
                opt_t=prime_t;positions=trace['qpos']
    # One identical deterministic breakup pattern is applied at the outlet in both trials.
    rng=np.random.default_rng(1206);e1=np.cross(axis[idx],[0.,0.,1.])
    e1/=np.linalg.norm(e1,axis=1,keepdims=True)
    e2=np.cross(axis[idx],e1)
    rays=axis[idx]+.022*(e1*rng.normal(size=(len(idx),1))+e2*rng.normal(size=(len(idx),1)))
    rays/=np.linalg.norm(rays,axis=1,keepdims=True)
    tip_speed=np.gradient(nozzle,t,axis=0)
    model=mj.MjModel.from_xml_path(str(phys/'scene.xml'));data=mj.MjData(model)
    collidable=(model.geom_contype!=0)|(model.geom_conaffinity!=0)
    model.geom_group[:]=np.where(collidable,0,5)
    model.geom_rgba[collidable,3]=1.
    excluded_id=model.body('pump_head').id
    gid=np.array([-1],dtype=np.int32)
    geom_names=[model.geom(i).name or model.body(model.geom_bodyid[i]).name for i in range(model.ngeom)]
    p0=nozzle[idx].copy(); p0+=.00035*rays
    v0=tip_speed[idx]+rays*speed[:,None]
    pos=p0.copy(); vel=v0.copy(); live=np.zeros(len(idx),bool)
    hit_time=np.full(len(idx),np.nan);hit_xyz=np.empty_like(p0);hit_geom=['']*len(idx)
    for j in (range(idx[0],min(len(t)-1,idx[-1]+2000)) if len(idx) else ()):
        live[idx==j]=True
        current=np.flatnonzero(live)
        if not len(current):
            if j>idx[-1]:break
            continue
        k=int(np.clip(np.searchsorted(opt_t,t[j]),1,len(opt_t)-1))
        mix=np.clip((t[j]-opt_t[k-1])/(opt_t[k]-opt_t[k-1]),0,1)
        data.qpos[:]=positions[k-1]*(1-mix)+positions[k]*mix
        mj.mj_normalizeQuat(model,data.qpos)
        # Forward position updates world-space bounds used by the ray accelerator.
        mj.mj_fwdPosition(model,data)
        drag_step=math.exp(-AIR_DRAG*DT)
        v_terminal=GRAVITY/AIR_DRAG
        dv=vel[current]-v_terminal
        advance=v_terminal*DT+dv*((1-drag_step)/AIR_DRAG)
        dist=np.linalg.norm(advance,axis=1)
        for element,delta,length in zip(current,advance,dist):
            if length<=1e-12:continue
            distance=mj.mj_ray(model,data,pos[element],delta/length,MASK,True,excluded_id,gid)
            if 0<=distance<=length+1e-8:
                hit_xyz[element]=pos[element]+distance*delta/length
                hit_time[element]=t[j]+DT*distance/length
                hit_geom[element]=geom_names[gid[0]]
                live[element]=False
        pos[current]+=advance
        vel[current]=v_terminal+dv*drag_step
    if not np.all(np.isfinite(hit_time)):raise ValueError(f'{branch} has unaccounted fluid')
    hit_dest=np.array([target(name,p) for name,p in zip(hit_geom,hit_xyz)],dtype='U8')
    out.mkdir(exist_ok=True,parents=True)
    np.savez_compressed(out/(branch+'.npz'),birth=t[idx],p0=p0,v0=v0,hit_time=hit_time,hit_xyz=hit_xyz,
            destination=hit_dest,volume=volume,radius=np.cbrt(3*volume*1e-6/(4*np.pi)),drag=AIR_DRAG)
    with (out/(branch+'-parcels.csv')).open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['release_s','first_hit_s','geom','destination','ml','hit_x_m','hit_y_m','hit_z_m'])
        w.writerows((t[i],tt,g,d,amount,*p) for i,tt,g,d,amount,p in zip(idx,hit_time,hit_geom,hit_dest,volume,hit_xyz))
    by_dest={name:round(float(volume[hit_dest==name].sum()),7) for name in ('basin','floor','other')}
    mask=hit_dest=='floor';floor_patches=patches(np.column_stack([hit_xyz[mask],volume[mask]]))
    ret=dict(release_s=float(t[idx[0]]) if len(idx) else None,last_release_s=float(t[idx[-1]]) if len(idx) else None,first_hit_s=float(hit_time.min()) if len(idx) else None,
             last_hit_s=float(hit_time.max()) if len(idx) else None,emitted_ml=round(float(sum(volume)),7),destination_ml=by_dest,
             floor_area_cm2=footprint_area_cm2(floor_patches),floor_patches=floor_patches.tolist(),
             first_floor_s=float(hit_time[mask].min()) if np.any(mask) else None,geoms={g:float(volume[np.array(hit_geom)==g].sum()) for g in set(hit_geom)})
    return ret


def at_time(flow,t):
    flight=(flow['birth']<=t)&(flow['hit_time']>t)
    age=(t-flow['birth'][flight])[:,None]
    term=GRAVITY/float(flow['drag'])
    xyz=flow['p0'][flight]+term*age+(flow['v0'][flight]-term)*(-np.expm1(-float(flow['drag'])*age)/float(flow['drag']))
    deposited=flow['hit_time']<=t
    def film(dest):
        chosen=deposited&(flow['destination']==dest)
        return patches(np.column_stack([flow['hit_xyz'][chosen],flow['volume'][chosen]]))
    return np.column_stack([xyz,flow['radius'][flight]]),film('floor'),film('basin')


if __name__=='__main__':
    summary={branch:simulate(branch) for branch in ('safe','unsafe')}
    for b,s in summary.items():
        print(b,s['emitted_ml'],s['destination_ml'],s['geoms'],flush=True)
        assert abs(s['emitted_ml']-sum(s['destination_ml'].values()))<.000001
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
