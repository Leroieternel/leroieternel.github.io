"""Push the service-check switch after installing the dispenser. Compare two Cartesian routes."""
from pathlib import Path
import sys,os
import json
import xml.etree.ElementTree as ET
import numpy as np
import mujoco as mj
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent;PHYS=ROOT.parent/'physics';sys.path.insert(0,str(PHYS))
from washroom import MOBILE,Arm,smooth,el,geom,box,body,vec
T=np.arange(6001)*.001
PARENT_TIME=23.24
BUTTON=np.array([2.49,.422,.971])
HOVER=.023
RESPONSE=.008
DIRECT_END=3.30
def build():
    root=ET.parse(PHYS/'scene.xml').getroot();root.set('model','service_check');a=root.find('asset');world=root.find('worldbody')
    for m in a:
        if m.get('file'):m.set('file',os.path.relpath(PHYS/m.get('file'),ROOT))
    for n,c in [('service_plate','.18 .245 .25 1'),('service_ring','.69 .72 .73 1'),('service_button','.12 .72 .56 1')]:
        el(a,'material',name=n,rgba=c,specular='.48',shininess='.56')
    x,y,z=BUTTON
    box(world,'service_pedestal',(x,y,.924),(.036,.025,.024),'service_plate')
    box(world,'service_bezel',(x,y,z-.021),(.035,.024,.006),'service_plate')
    n=64;verts=[];faces=[]
    for rr,zz in [(.019,-.0148),(.019,-.0058),(.0180,-.0048),(.0156,-.0048),(.0156,-.0148)]:
        for i in range(n):
            ang=i*2*np.pi/n;verts.append([rr*np.cos(ang),rr*np.sin(ang),zz])
    for layer in range(5):
        for i in range(n):
            src=layer*n;dst=((layer+1)%5)*n
            faces.extend([(src+i,src+(i+1)%n,dst+(i+1)%n),(src+i,dst+(i+1)%n,dst+i)])
    el(a,'mesh',name='service_ring_shape',vertex=vec(np.ravel(verts)),face=' '.join(map(str,np.ravel(faces))))
    el(world,'geom',name='service_ring',type='mesh',mesh='service_ring_shape',pos=vec([x,y,z]),material='service_ring',contype=0,conaffinity=0)
    b=body(world,'service_switch',(x,y,z-.0025))
    el(b,'joint',name='service_slide',type='slide',axis='0 0 -1',range='0 .007',springref='-.0004',stiffness=195,damping=1.25,armature=.002,solreflimit='.003 1',solimplimit='.997 .999 .0002')
    geom(b,'service_key','cylinder',(0,0,0),(.015,.0025),'service_button',mass=.012,condim=6,priority=3,solref='.004 1',solimp='.98 .998 .001')
    img=Image.new('RGB',(440,116),(44,65,63));d=ImageDraw.Draw(img)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',40)
    d.text((220,58),'SERVICE CHECK',font=font,fill=(238,243,226),anchor='mm')
    img.save(ROOT/'switch-label.png')
    el(a,'texture',name='switch_legend_tex',type='2d',file='switch-label.png')
    el(a,'material',name='switch_legend_mat',texture='switch_legend_tex',specular='.27',shininess='.20')
    # A front-facing printed strip is forward of the target, below the fingertip working plane.
    pos1=(x-.042,y-.0262,z-.026); pos2=(x+.042,y-.0262,z-.026);pos3=(x+.042,y-.0262,z-.008);pos4=(x-.042,y-.0262,z-.008)
    mesh=ROOT/'switch-label.obj'
    mesh.write_text(''.join('v '+' '.join(map(str,p))+'\n' for p in [pos1,pos2,pos3,pos4])+'vt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nf 1/1 2/2 3/3\nf 1/1 3/3 4/4\n')
    el(a,'mesh',name='printed_switch_legend',file='switch-label.obj',inertia='shell')
    el(world,'geom',name='service_legend',type='mesh',mesh='printed_switch_legend',material='switch_legend_mat',contype=0,conaffinity=0)
    ET.indent(root);ET.ElementTree(root).write(ROOT/'scene.xml',encoding='utf-8')
    return mj.MjModel.from_xml_path(str(ROOT/'scene.xml'))
def run(safe):
    m=mj.MjModel.from_xml_path(str(ROOT/'scene.xml'));d=mj.MjData(m)
    prev=np.load(PHYS/'unsafe.npz');idx=np.argmin(abs(prev['time_s']-PARENT_TIME))
    oldq=prev['qpos'][idx];oldv=prev['qvel'][idx]
    d.qpos[:len(oldq)]=oldq;d.qvel[:len(oldv)]=oldv;d.ctrl[:]=prev['ctrl'][idx];mj.mj_forward(m,d)
    arm=Arm(m,['joint'+str(i) for i in range(1,8)])
    baseq=np.array([m.joint('joint_mobile_'+j).qposadr[0] for j in ('forward','side','yaw')]);bc=d.qpos[baseq].copy()
    basev=m.jnt_dofadr[[m.joint('joint_mobile_'+j).id for j in ('forward','side','yaw')]]
    ba=[m.actuator('actuator_mobile_'+j).id for j in ('forward','side','yaw')]
    fj=[m.joint('finger_joint'+str(i)).qposadr[0] for i in (1,2)]
    fa=[m.actuator('gripper_finger_joint'+str(i)).id for i in (1,2)]
    pq=m.joint('pump_travel').qposadr[0];pv=m.joint('pump_travel').dofadr[0];sq=m.joint('service_slide').qposadr[0]
    xyz=d.site('tcp').xpos.copy()-np.r_[bc[:2],0.]
    arm.seed=d.qpos[arm.q].copy()
    dest=BUTTON-np.r_[bc[:2],0.];dest[2]+=.001
    near=dest+[0,0,HOVER];above=dest+[0,0,.194];yaw=np.pi/2-1.19
    # Only the switch pose enters the nominal planner. The pump pose never parametrizes
    # either a waypoint or the pressed target. Guarded travel uses a support-independent
    # 194 mm approach clearance above the same switch.
    knots=[(0,xyz),(.60,xyz)]
    if safe:knots.extend([(1.77,above),(DIRECT_END,near)])
    else:knots.append((DIRECT_END,near))
    end=DIRECT_END
    knots.extend([(end+.50,dest-[0,0,.0002]),(end+.82,dest-[0,0,.0002]),(end+1.97,above),(6.,above)])
    qref=arm.trajectory([(tt,p,yaw) for tt,p in knots],T)
    qd=np.gradient(qref,.001,axis=0);qdd=np.gradient(qd,.001,axis=0)
    kp=np.array([1700,1700,1450,1300,720,550,450]);kd=2.2*np.sqrt(kp*np.array([1.3,2,.9,1,.28,.28,.16]))
    caps=m.actuator_ctrlrange[arm.act,1];mass=np.empty((m.nv,m.nv));wrench=np.empty(6)
    names=[m.geom(i).name for i in range(m.ngeom)];obj=m.body('payload').id;pg=m.geom('pump_paddle').id;bg=m.geom('service_key').id
    odof=m.joint('payload_free').dofadr[0];outlet=m.site('outlet').id;ax=m.site('axis_point').id
    fg=[i for i,n in enumerate(names) if n.startswith('finger') and n.endswith('collision')]
    cols='t_s pump_stroke_m pump_stroke_rate_m_s nozzle_x_m nozzle_y_m nozzle_z_m nozzle_dx nozzle_dy nozzle_dz pump_force_N left_jaw_N right_jaw_N source_support_N rim_support_N bottle_x_m bottle_y_m bottle_z_m bottle_tilt_deg bottle_yaw_rad bottle_speed_m_s bottle_spin_rad_s base_x_m base_y_m base_yaw_rad base_speed_m_s tcp_x_m tcp_y_m tcp_z_m gap_m button_stroke_m button_force_N fingertip_paddle_clearance_m'.split()
    vals=np.zeros((len(T),len(cols)));frames=[];extra={};maxpen={};pairs={};maxspeed=np.zeros(7);minmargin=1e2
    loaded_from=None;retreated=None
    for i,t in enumerate(T):
        r=4*(bc[:2]-d.qpos[baseq[:2]]);rot=5*(bc[2]-d.qpos[baseq[2]])
        d.ctrl[ba]=np.r_[r+.251*np.tanh(r/.0018),rot+.168*np.tanh(rot/.0014)]
        mj.mj_fullM(m,d,mass);d.ctrl[arm.act]=np.clip(d.qfrc_bias[arm.v]+mass[np.ix_(arm.v,arm.v)]@qdd[i]+kp*(qref[i]-d.qpos[arm.q])+kd*(qd[i]-d.qvel[arm.v]),-caps,caps)
        half=.038-.035*smooth(t/.48);d.ctrl[fa]=[half,-half]
        mj.mj_forward(m,d)
        loads=np.zeros(3);external_fingertip_N=0.
        for ci,c in enumerate(d.contact):
            a,b=names[c.geom1],names[c.geom2];pair='/'.join(sorted([a,b]))
            if c.dist<0:maxpen[pair]=max(maxpen.get(pair,0),-c.dist*1000)
            mj.mj_contactForce(m,d,ci,wrench);f=max(0.,wrench[0])
            if f<.000001:continue
            pairs[pair]=max(pairs.get(pair,0),float(f))
            if (c.geom1 in fg)!=(c.geom2 in fg):external_fingertip_N+=f
            if pg in (c.geom1,c.geom2) and (a.startswith('finger') or b.startswith('finger')):loads[0]+=f
            elif bg in (c.geom1,c.geom2) and (a.startswith('finger') or b.startswith('finger')):loads[1]+=f
            elif 'rim_front' in (a,b) and ('bottle_foot' in (a,b) or 'bottle_body' in (a,b)):loads[2]+=f
            elif {a,b}=={'finger1_pad_collision','finger2_pad_collision'}:pass
            else:extra[pair]=max(extra.get(pair,0),float(f))
        pos=d.site_xpos[outlet];axis=d.site_xpos[ax]-pos;axis/=np.linalg.norm(axis);R=d.xmat[obj].reshape(3,3)
        clearance=min(mj.mj_geomDistance(m,d,g,pg,.5,None) for g in fg)
        vals[i]=[t,max(0.,d.qpos[pq]),d.qvel[pv],*pos,*axis,loads[0],0,0,0,loads[2],*d.xpos[obj],np.degrees(np.arccos(np.clip(R[2,2],-1,1))),np.arctan2(R[1,0],R[0,0]),np.linalg.norm(d.qvel[odof:odof+3]),np.linalg.norm(d.qvel[odof+3:odof+6]),*d.qpos[baseq],np.linalg.norm(d.qvel[basev[:2]]),*d.site_xpos[arm.id],d.qpos[fj[0]]-d.qpos[fj[1]],max(0,d.qpos[sq]),loads[1],clearance]
        if not safe and .60<t<DIRECT_END and retreated is None:
            # Unexpected wrist load triggers a one-time compliant retreat from the measured pose.
            # No pump coordinate, stroke or intended contact time is used to choose the fallback path.
            if external_fingertip_N>.5 and loaded_from is None:loaded_from=t
            if loaded_from is not None and t-loaded_from>=RESPONSE:
                retreated=float(t)
                now=d.site_xpos[arm.id].copy()-np.r_[bc[:2],0.]
                lift=np.array([*now[:2],max(now[2]+.050,above[2])])
                future=T[i:]-t
                recovery=[(0,now),(.53,lift),(1.10,above),(1.64,near),(2.18,dest-[0,0,.0002]),(2.41,dest-[0,0,.0002]),(3.24,above),(future[-1],above)]
                arm.seed=d.qpos[arm.q].copy()
                qref[i:]=arm.trajectory([(tt,pp,yaw) for tt,pp in recovery],future)
                qd[i:]=np.gradient(qref[i:],.001,axis=0);qdd[i:]=np.gradient(qd[i:],.001,axis=0)
        maxspeed=np.maximum(maxspeed,abs(d.qvel[arm.v]));minmargin=min(minmargin,(d.qpos[arm.q]-m.jnt_range[arm.js,0]).min(),(m.jnt_range[arm.js,1]-d.qpos[arm.q]).min())
        if i%40==0:frames.append((d.qpos.copy(),d.qvel.copy(),d.ctrl.copy()))
        if i+1<len(T):mj.mj_step(m,d)
    key='safe' if safe else 'unsafe';q,v,u=map(np.asarray,zip(*frames))
    np.savez_compressed(ROOT/(key+'.npz'),time_s=T[::40],qpos=q,qvel=v,ctrl=u,base_xy=vals[::40,21:23],tcp_xyz=vals[::40,25:28],payload_xyz=vals[::40,14:17])
    np.savetxt(ROOT/(key+'.csv'),vals,fmt='%.8g',delimiter=',',header=','.join(cols),comments='')
    x={n:vals[:,i] for i,n in enumerate(cols)}
    def at(mask):
        ids=np.flatnonzero(mask);return round(float(T[ids[0]]),4) if len(ids) else None
    resp=dict(branch=key,achieved=bool(x['button_stroke_m'].max()>=.005),duration_s=T[-1],parent_time_s=PARENT_TIME,load_triggered_retreat_s=retreated,
      pump_contact_s=at(x['pump_force_N']>.03),pump_contact_end_s=round(float(T[np.flatnonzero(x['pump_force_N']>.03)[-1]]),4) if (x['pump_force_N']>.03).any() else None,
      peak_pump_force_N=float(x['pump_force_N'].max()),peak_pump_force_time_s=float(T[np.argmax(x['pump_force_N'])]),peak_pump_stroke_m=float(x['pump_stroke_m'].max()),
      button_trigger_s=at(x['button_stroke_m']>=.005),peak_button_force_N=float(x['button_force_N'].max()),peak_button_stroke_m=float(x['button_stroke_m'].max()),
      min_rim_support_N=float(x['rim_support_N'].min()),max_tilt_deg=float(x['bottle_tilt_deg'].max()),min_geo_separation_m=float(x['fingertip_paddle_clearance_m'].min()),peak_contact_overlap_mm=float(max(maxpen.values(),default=0)),overlaps_mm=maxpen,
      unintended_contacts=extra,contact_pair_peaks_N=pairs,solver_warnings=int(sum(n.number for n in d.warning)),arm_speed_peaks_rad_s=maxspeed.tolist(),minimum_joint_limit_margin_rad=float(minmargin),
      changed_bottle_xy_mm=float(np.linalg.norm(vals[-1,14:16]-vals[0,14:16])*1e3),end_bottle_yaw_deg=float(np.degrees(x['bottle_yaw_rad'][-1])),
      steps=[dict(t=0.,text='Close the empty hand above the released service handle.'),dict(t=.60,text='Cross over the switch at travel height.' if safe else 'Take the direct approach to the switch.'),dict(t=1.77,text='Descend above the switch.' if safe else 'Continue toward the switch.'),dict(t=end,text='Depress the service-check key and hold.'),dict(t=end+.82,text='Release the key and withdraw vertically.')])
    if retreated is not None:
        resp['steps']=[dict(t=0.,text='Close the empty hand above the released service handle.'),dict(t=.60,text='Take the direct approach to the service switch.'),dict(t=retreated,text='Unexpected fingertip load triggers a retreat.'),dict(t=retreated+.53,text='Cross to the switch at recovery height.'),dict(t=retreated+1.10,text='Descend and press the service-check key.'),dict(t=retreated+2.41,text='Release the switch and withdraw.')]
    (ROOT/(key+'.json')).write_text(json.dumps(resp,indent=2)+'\n')
    print(key,'pump stroke, force',resp['peak_pump_stroke_m'],resp['peak_pump_force_N'],'button',resp['peak_button_stroke_m'],'events',resp['pump_contact_s'],resp['button_trigger_s'],'extra',extra,'support min',resp['min_rim_support_N'],'tilt',resp['max_tilt_deg'],'travel',resp['changed_bottle_xy_mm'])
if __name__=='__main__':
    if sys.argv[-1]=='build':build()
    else:run(sys.argv[-1]=='safe')
