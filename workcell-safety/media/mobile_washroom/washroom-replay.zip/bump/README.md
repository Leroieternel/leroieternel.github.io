# Service-check switch after installation

Both six-second trials restart from the actual 23.240-second saved state of the outward-facing installation. The source bottle is already upright on the sink ledge and the robot has released the handle. The original position and velocity vectors are copied exactly. A separate, initially released, seven-millimetre spring-loaded pushbutton is mounted on the front rim. Its contact switch trips at five millimetres of travel.

The commanded task is to press the service-check switch, hold briefly and release. The guarded arm traverses at clearance before dropping above the switch. The direct arm moves on a single Cartesian segment toward the switch approach pose. The segment is specified by the hand's initial pose, switch pose and switch approach height. The pump has no motion command. The finger-paddle edge contact during this approach displaces the dispenser's spring-loaded head. External fingertip force triggers a short delayed retreat in the direct branch. The arm then crosses at clearance, depresses the independent switch, and withdraws.

Both runs record 1 kHz sensor and state channels in separate CSVs. The pump force is the sum of compressive normals at the physical finger/paddle contact pair; the real service button has its own force and stroke channels. The unsafe bottle rocks under half a degree during the brush, moves less than 0.05 mm across the rim, and remains continuously supported. Each 25 Hz NPZ contains the original MuJoCo positions, velocities and actuator controls. The optical pose export uses those same sampled positions. The numerical contact model allows small compliant overlaps.

From the complete project, reproduce with:

```sh
python accidental.py build
python accidental.py safe
python accidental.py unsafe
python export.py
python verify.py
```
