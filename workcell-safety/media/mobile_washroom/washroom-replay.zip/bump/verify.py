"""Check the matched fork, switch actuation, settled dispenser, contact identity and trace/optics correspondence."""
from pathlib import Path
import json,numpy as np
import mujoco as mj
ROOT=Path(__file__).resolve().parent
def verify():
    original=np.load(ROOT.parent/'physics'/'unsafe.npz');ip=np.argmin(abs(original['time_s']-23.24))
    model=mj.MjModel.from_xml_path(str(ROOT/'scene.xml'));body=mj.MjData(model)
    geo=json.loads((ROOT/'optics'/'objects.json').read_text());ids=[o['gid'] for o in geo]
    result={};base={}
    for b in ('safe','unsafe'):
        branch=json.loads((ROOT/(b+'.json')).read_text());a=np.genfromtxt(ROOT/(b+'.csv'),delimiter=',',names=True)
        states=np.load(ROOT/(b+'.npz'));opt=np.load(ROOT/'optics'/(b+'.npz'))
        assert np.array_equal(states['qpos'][0,:original['qpos'].shape[1]],original['qpos'][ip]);assert np.array_equal(states['qvel'][0,:original['qvel'].shape[1]],original['qvel'][ip]);base[b]=states['qpos'][0].copy()
        assert np.max(abs(states['qpos'][-1]-states['qpos'][0]))>0.05
        for i,q in enumerate(states['qpos']):
            body.qpos[:]=q;mj.mj_kinematics(model,body);tr=np.column_stack([body.geom_xmat[ids],body.geom_xpos[ids]]).astype('f')
            assert np.array_equal(opt['frames'][i],tr)
        assert len(a)==6001 and len(opt['time'])==151 and np.allclose(a['t_s'][::40],opt['time'])
        assert branch['achieved'] and branch['peak_button_stroke_m']>.005
        assert not branch['unintended_contacts'] and branch['solver_warnings']==0
        assert branch['min_rim_support_N']>.1 and branch['max_tilt_deg']<1 and branch['changed_bottle_xy_mm']<.1
        assert branch['end_bottle_yaw_deg']<-50 and branch['minimum_joint_limit_margin_rad']>.05
        assert np.all(np.array(branch['arm_speed_peaks_rad_s'])<[2.175]*4+[2.61]*3)
        assert a['button_stroke_m'][-1]<.001 and a['button_force_N'][-1]<.1 and a['pump_force_N'][-1]<.1
        if b=='safe':
            assert np.max(a['pump_force_N'])==0 and np.max(a['pump_stroke_m'])==0
        else:
            assert .0005<branch['peak_pump_stroke_m']<.018 and branch['pump_contact_s']<branch['load_triggered_retreat_s']<branch['button_trigger_s'] and branch['peak_contact_overlap_mm']<.15
            active=np.flatnonzero(a['pump_force_N']>.03);assert np.ptp(a['tcp_x_m'][active])>.0005
        branch['max_button_stroke_mm']=round(branch['peak_button_stroke_m']*1000,4)
        result[b]=branch
    assert np.array_equal(base['safe'],base['unsafe'])
    return result


if __name__=='__main__':
    j=verify()
    obj=dict(title='A brush on the way to the service-check switch',task='Press the service-check switch after installing an outward-facing dispenser.',robot='robosuite PandaOmron and Panda Hand',duration_s=6,dt_s=.001,replay_hz=25,source_state='Existing outward-facing trial at t=23.240 s. All pre-existing qpos and qvel are identical to that saved state in both initial conditions.',
        button_center_m=[2.49,.422,.971],button_actuation_m=.005,pump_body='pump_head',button_body='service_switch',pump_channel='pump_force_N',button_channel='button_force_N',
        approach='The direct nominal path depends only on the initial empty-hand pose and the separate target switch pose plus a common approach height. The protected path crosses at a higher clearance. The nominal controller replans once after an external fingertip load is observed on its approach. Both then press the service-check switch, hold and lift off.',
        controls='The dispenser has no actuator or equality weld. Any pump depression results from contact and dynamics. The nested pump and its spring, as well as the viscosity-independent chamber metering, are identical to the primary washroom case.',
        **j)
    (ROOT/'info.json').write_text(json.dumps(obj,indent=2)+'\n')
    print('Both six-second trials passed.')
