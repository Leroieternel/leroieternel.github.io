"""Place the same rubber test coupon on both simulated floors and apply one horizontal pulse."""
from pathlib import Path
import csv
import json
import math
import mujoco as mj
import numpy as np
from liquid_solver import FILM_M, OUT

DRY_MU, SOAP_MU = .62, .16
HALF = np.array([.018, .0125, .008])
MASS_KG = .100
PULL_N = .400
START_S, END_S, DURATION_S = .42, .55, 1.65
SAMPLE_XY = np.stack(np.meshgrid(np.linspace(-.0165,.0165,13),np.linspace(-.0115,.0115,9)),axis=-1).reshape(-1,2)


def wet_fraction(footprints,center,rotation):
    if not len(footprints):return 0.
    points=center[:2]+SAMPLE_XY@rotation[:2,:2].T
    inside=np.zeros(len(points),dtype=bool)
    for x,y,_,volume in footprints:
        radius2=volume*1.e-6/(math.pi*FILM_M)
        inside|=np.sum((points-[x,y])**2,axis=1)<radius2
    return float(inside.mean())


def run(branch,xy,angle,regions,output=OUT,ramp=False):
    q=[math.cos(angle/2),0,0,math.sin(angle/2)]
    xml=f"""<mujoco model="Washroom tile traction check"><option timestep=".001" cone="elliptic" integrator="implicitfast" iterations="80"/>
    <worldbody><geom name="tile" type="plane" size="5 5 .1" friction=".62 .002 .0001" priority="1" condim="4"/>
    <body name="coupon" pos="{xy[0]} {xy[1]} .00825" quat="{' '.join(map(str,q))}"><freejoint/>
    <geom name="rubber" type="box" size=".018 .0125 .008" mass=".100" condim="4" friction=".62 .002 .0001" solref=".003 1"/>
    </body></worldbody></mujoco>"""
    m=mj.MjModel.from_xml_string(xml);d=mj.MjData(m);bid=m.body('coupon').id
    field=['t_s','x_m','y_m','z_m','qw','qx','qy','qz','pull_N','normal_N','friction_N','wet_fraction','mu','travel_mm','speed_m_s']
    values=[];direction=np.array([math.cos(angle),math.sin(angle)])
    f6=np.zeros(6);first=None;onset_force=None;start_pos=None
    for j in range(round(DURATION_S/.001)+1):
        mj.mj_forward(m,d)
        p=d.xpos[bid].copy();rot=d.xmat[bid].reshape(3,3)
        portion=wet_fraction(regions,p,rot)
        mu=DRY_MU+(SOAP_MU-DRY_MU)*portion
        m.geom('tile').friction[0]=mu
        if ramp:
            force=float(np.clip(d.time-START_S,0.,1.0)) if onset_force is None else 0.
        else:force=PULL_N if START_S<=d.time<END_S else 0.
        d.xfrc_applied[bid,:2]=direction*force
        mj.mj_forward(m,d)
        normal=0.;tangent=np.zeros(3)
        for k in range(d.ncon):
            mj.mj_contactForce(m,d,k,f6);normal+=abs(f6[0])
            tangent+=d.contact[k].frame.reshape(3,3)[1:].T@f6[1:3]
        if start_pos is None or d.time<START_S:start_pos=p.copy()
        travel=float(np.linalg.norm(p[:2]-start_pos[:2])*1000)
        speed=float(np.linalg.norm(d.qvel[:2]))
        if speed>.006 and first is None:
            first=float(d.time);onset_force=force
        values.append([d.time,*p,*d.xquat[bid],force,normal,float(np.linalg.norm(tangent)),portion,mu,travel,speed])
        if j<round(DURATION_S/.001):mj.mj_step(m,d)
    test_name='ramp' if ramp else 'traction'
    a=np.array(values);np.savetxt(output/(branch+'-'+test_name+'.csv'),a,delimiter=',',header=','.join(field),comments='',fmt='%.8f')
    if not ramp:(output/(branch+'-traction.xml')).write_text(xml)
    ix={n:i for i,n in enumerate(field)}
    if np.max(np.abs(a[-100:,ix['speed_m_s']]))>.001:raise ValueError('Coupon still moving at end')
    return dict(start_xy_m=list(map(float,xy)),direction_deg=math.degrees(angle),mass_kg=MASS_KG,pull_N=None if ramp else PULL_N,force_rate_N_per_s=1.0 if ramp else None,
                initial_mu=float(a[round(START_S/.001),ix['mu']]),initial_coverage=float(a[round(START_S/.001),ix['wet_fraction']]),
                distance_mm=float(a[-1,ix['travel_mm']]),max_speed_m_s=float(a[:,ix['speed_m_s']].max()),
                peak_shear_N=float(a[:,ix['friction_N']].max()),average_normal_load_N=float(a[500:,ix['normal_N']].mean()),first_motion_s=first,
                first_motion_force_N=onset_force)


def main(output=OUT):
    fluid=json.loads((output/'summary.json').read_text())
    by={b:np.asarray(d['floor_patches']).reshape(-1,4) for b,d in fluid.items()}
    regions=by['unsafe']
    if not len(regions):raise ValueError('No floor deposit')
    largest=regions[np.argmax(regions[:,3])]
    xy=largest[:2]
    # Both coupons are positioned at the same world coordinate and pulled along the tile joint.
    results={b:run(b,xy,0.,by[b],output) for b in ('safe','unsafe')}
    meta=dict(method='Identical 100 g free rigid rubber coupon on a tile plane. Coverage modulates the assumed Coulomb coefficient at each solver step.',
              dry_mu=DRY_MU,wet_mu=SOAP_MU,film_depth_mm=FILM_M*1000,timestep_s=.001,pull_start_s=START_S,pull_end_s=END_S,duration_s=DURATION_S,
              coupon_dimensions_m=(HALF*2).tolist(),safe=results['safe'],unsafe=results['unsafe'])
    meta['ramp_test']={b:run(b,xy,0.,by[b],output,ramp=True) for b in ('safe','unsafe')}
    meta['ramp_test']['protocol']='Increase horizontal force by 1.0 N/s after settling. Record force at the first sample above 6 mm/s and release.'
    (output/'traction.json').write_text(json.dumps(meta,indent=2))
    print({b:(results[b]['distance_mm'],results[b]['initial_mu'],results[b]['initial_coverage']) for b in results},flush=True)

if __name__=='__main__':main()
