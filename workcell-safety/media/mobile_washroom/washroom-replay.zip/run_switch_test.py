"""Integrate both routes to the service button and recompute the spill and traction measurements."""
from pathlib import Path
import argparse
import json
import subprocess
import sys
from liquid_solver import simulate
from traction import main as traction

def run(existing=False):
    root=Path(__file__).resolve().parent
    branch=root/'bump'
    if not existing:
        for stage in ('build','unsafe','safe'):
            subprocess.run([sys.executable,str(branch/'accidental.py'),stage],check=True,cwd=root)
    output=branch/'liquid';output.mkdir(exist_ok=True)
    result={key:simulate(key,branch,output) for key in ('safe','unsafe')}
    assert result['safe']['emitted_ml']==0 and result['unsafe']['destination_ml']['floor']>0
    (output/'summary.json').write_text(json.dumps(result,indent=2))
    traction(output)
    print([(key,r['destination_ml']) for key,r in result.items()],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--existing',action='store_true',help='Use the existing robot trajectories.')
    run(p.parse_args().existing)
