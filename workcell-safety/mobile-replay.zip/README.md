# Mobile manipulation missions

These five MuJoCo models use the recorded driving and manipulation coordinates,
with the original robosuite Omron visual chassis, seven Panda joints and actuated
Panda Hand. The furnished Cycles movies are available in the web viewer.

Install Python with mujoco==4.0.1, numpy and scipy. Extract this archive before running.
All paths resolve from the extracted directory.

    python replay.py 1 safe --check
    python replay.py 1 unsafe
    python rerun.py 5 safe

The second command opens the MuJoCo viewer and plays the recorded physical state at
25 frames per second. The third integrates fresh contact dynamics at 1 kHz into
the selected case directory and recomputes the result JSON. The command cases,
in order, are warehouse, roastery, sterile supply, bindery and gallery.
The complete normal-force time series are included and are also available as separate CSV downloads.
Use each scene's info.json for metric definitions and labeled times.
The original robosuite license is included in assets/LICENSE.
