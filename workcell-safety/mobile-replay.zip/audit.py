"""Check intent, support, motion and consistency of the saved 1 kHz and 25 Hz products."""
import json
import numpy as np
import mujoco as mj
from world import ROOT, SLUGS, CHECKPOINTS, PICK_X, DEST_X

def audit(k):
    out=ROOT/SLUGS[k]
    info=json.loads((out/'info.json').read_text())
    model=mj.MjModel.from_xml_path(str(out/'scene.xml'));state=mj.MjData(model)
    records=[]
    for key in ('safe','unsafe'):
        result=info[key]
        trace=np.genfromtxt(out/(key+'.csv'),delimiter=',',names=True)
        time=trace['t_s']
        q=np.load(out/(key+'.npz'))
        assert np.allclose(np.diff(time),info['dt_s'],atol=2e-7)
        assert np.allclose(q['time_s'],time[::40])
        assert np.allclose(q['base_xy'],np.c_[trace['base_x_m'],trace['base_y_m']][::40],atol=.00001)
        assert np.allclose(q['payload_xyz'],np.c_[trace['item_x_m'],trace['item_y_m'],trace['item_z_m']][::40],atol=.00001)
        for i in range(0,len(q['qpos']),11):
            state.qpos[:]=q['qpos'][i];mj.mj_kinematics(model,state)
            assert np.allclose(state.body('payload').xpos,q['payload_xyz'][i],atol=1e-9)
        assert len(result['steps'])>=8
        assert result['goal_reached']==(key=='safe' or k==3)
        assert result['hazard']==(key=='unsafe')
        assert result['solver_warnings']==0 and not result['other_contacts_N'],result['other_contacts_N']
        assert result['route_m']>8 and result['max_base_speed_m_s']<1
        assert result['visit_error_mm']<2 and result['park_speed_m_s']<.002
        assert result['grasp_floor_N']>1 and result['min_carry_clearance_m']>.15
        assert result['arm_limit_margin_rad']>.1
        assert np.all(np.asarray(result['peak_arm_speed_rad_s']) < [2.175]*4+[2.61]*3)
        assert result['settled_s'] < result['duration_s']-1
        assert result['park_item_speed_m_s']<.0001
        hazard_force=trace['item_flag_N' if k==3 else 'catch_N']
        assert np.isclose(hazard_force.max(),result['peak_hazard_force_N'],rtol=.00001)
        if key=='safe':
            assert not np.any(hazard_force>.000001)
        else:
            assert result['peak_hazard_force_N']>.1
        records.append(dict(branch=key,base_travel_m=result['route_m'],park_speed_m_s=result['park_speed_m_s'],
                            contact_overlap_mm=result['max_overlap_mm'],lowest_grip_force_each_N=result['grasp_floor_N'],unexpected_contacts=0))
    return records

if __name__=='__main__':
    checks={slug:audit(i) for i,slug in enumerate(SLUGS)}
    (ROOT/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    print('Validated all ten rollouts, both supports, both parking states and geometric frame correspondence.')
