"""Derive support loss, impact and end-of-transient events from complete solver traces."""
from pathlib import Path
import json
import numpy as np

def add_outcome(out,k,key):
    path=out/(key+'.json');r=json.loads(path.read_text())
    a=np.genfromtxt(out/(key+'.csv'),delimiter=',',names=True)
    t=a['t_s'];dt=t[1]-t[0];after=t>=r['release_s']
    event=r['first_event_s'];end=r['settled_s']
    f=a['item_flag_N' if k==3 else 'catch_N']
    loaded=f>.000001
    r['hazard_impulse_Ns']=float(np.sum(f[loaded & (t<=(end if end else t[-1]))])*dt)
    r['impulse_window']='Through final payload settling; excludes subsequent static support.'
    r['max_payload_tilt_after_release_deg']=float(a['item_tilt_deg'][after].max())
    r['mechanism_peak_deg']=float(np.degrees(abs(a['mechanism_position_rad_or_m']).max())) if k in (1,3) else None
    dest=a['destination_N']>.04
    supported=np.flatnonzero(dest & after & (t<=event if event is not None else True))
    terminal=round(float(t[-1]),5)
    r['postrelease_events_s']={'first_loaded_destination':float(t[supported[0]]) if supported.size else None,
        'lost_destination_support':float(t[supported[-1]+1]) if supported.size and k!=3 and event is not None and supported[-1]+1<len(t) else None,
        'first_hazard_contact':r['first_hazard_contact_s'],'hazard_criterion':event,'settled':end,'parked_observation':terminal}
    if event is not None and k==4 and supported.size:
        mask=(t>=t[supported[0]])&(t<=t[supported[-1]]);p=np.c_[a['item_x_m'],a['item_y_m'],a['item_z_m']]
        r['supported_sphere_travel_mm']=float(np.linalg.norm(np.diff(p[mask],axis=0),axis=1).sum()*1000)
        r['supported_sphere_rotation_deg']=float(np.degrees(a['item_spin_rad_s'][mask].sum()*dt))
    path.write_text(json.dumps(r,indent=2)+'\n')
