import argparse
import time
import mujoco as mj
import numpy as np
from world import ROOT, SLUGS
p=argparse.ArgumentParser();p.add_argument('case',type=int,choices=range(1,6));p.add_argument('branch',choices=('safe','unsafe'));p.add_argument('--check',action='store_true')
a=p.parse_args();d=ROOT/SLUGS[a.case-1];m=mj.MjModel.from_xml_path(str(d/'scene.xml'));s=mj.MjData(m)
z=np.load(d/(a.branch+'.npz'));t=z['time_s']
def set_state(i):
    s.time=t[i];s.qpos[:]=z['qpos'][i];s.qvel[:]=z['qvel'][i];s.ctrl[:]=z['ctrl'][i];mj.mj_forward(m,s)
if a.check:
    for i in range(0,len(t),7):
        set_state(i);assert np.allclose(s.body('payload').xpos,z['payload_xyz'][i],atol=1.e-8)
    set_state(-1);print(d.name,a.branch,len(t),'verified recorded states through',t[-1],'s')
else:
    import mujoco.viewer
    with mujoco.viewer.launch_passive(m,s) as view:
        view.cam.type=mj.mjtCamera.mjCAMERA_FIXED;view.cam.fixedcamid=m.camera('overview').id
        start=time.perf_counter()
        for i,at in enumerate(t):
            if not view.is_running():break
            set_state(i);view.sync();time.sleep(max(0.,start+at+.04-time.perf_counter()))
