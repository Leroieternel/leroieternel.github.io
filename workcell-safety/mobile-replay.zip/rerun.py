import argparse
from pathlib import Path
from missions import run, combined
from outcomes import add_outcome
from world import ROOT, SLUGS
p=argparse.ArgumentParser();p.add_argument('case',type=int,choices=range(1,6));p.add_argument('branch',choices=('safe','unsafe'))
a=p.parse_args();k=a.case-1
run(k,a.branch=='safe');combined(k)
