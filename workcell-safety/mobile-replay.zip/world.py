"""Build five independent workcell mechanisms around the library Omron / Panda assembly."""
import os
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

import numpy as np

ROOT = Path(__file__).resolve().parent
LIB = ROOT/'source_models'
PREVIOUS = ROOT.parents[1]/'robot_plans'
SLUGS = ['01_warehouse','02_roastery','03_sterile','04_bindery','05_gallery']
NAMES = ['Outbound relay carton', 'Roast sample tin', 'Sterile supply cartridge', 'Press setting gauge', 'Conservation reference sphere']
TITLES = ['Dispatch a control relay','Weigh a roast sample','Supply a sterilizer loading shuttle','Set a bindery registration gauge','Deliver a conservation reference sphere']
PICK_X, DEST_X, Y = -2.6, 2.6, .63
TOP, PICK_TOP, CATCH = .949, .915, .738
HZ = [.031, .027, .029, .022, .027]
HALFX = [.027,.027,.024,.025,.027]
MASS = [.085,.121,.094,.148,.072]
CHECKPOINTS = [('Outbound barcode portal',-1.05,-.87),('Cupping aisle crossing',.28,-.76),('Sterile transfer threshold',-.34,-1.16),('Press aisle marker',.54,-.86),('Gallery inspection threshold',-1.38,-.70)]
ROUTES=[
    [(-1.46,-.65),(-1.05,-.87),(1.05,-.87)],
    [(-1.36,-.34),(.28,-.76),(1.18,-.42)],
    [(-1.50,-1.16),(-.34,-1.16),(1.36,-.54)],
    [(-1.15,-.74),(.54,-.86),(1.56,-.81)],
    [(-1.38,-.70),(.0,-.95),(1.20,-.29)]]
COLORS=['.64 .39 .18 1','.33 .18 .09 1','.80 .89 .85 1','.16 .32 .36 1','.69 .44 .21 1']
vec=lambda x:' '.join(f'{v:.9g}' for v in x)
def el(p,t,**a):return ET.SubElement(p,t,{k:str(v) for k,v in a.items()})
def body(p,n,pos):return el(p,'body',name=n,pos=vec(pos))
def geom(p,n,typ,pos,size,mat,physical=True,**kw):
    v=dict(name=n,type=typ,pos=vec(pos),size=vec(size),material=mat)
    if not physical:v.update(contype=0,conaffinity=0,mass=0,group=1)
    return el(p,'geom',**v,**kw)
def box(p,n,xyz,h,mat,**kw):return geom(p,n,'box',xyz,h,mat,**kw)
def camera(w,n,eye,to,fov):
    z=np.subtract(eye,to);z=z/np.linalg.norm(z);x=np.cross([0,0,1],z);x=x/np.linalg.norm(x)
    el(w,'camera',name=n,pos=vec(eye),xyaxes=vec(np.r_[x,np.cross(z,x)]),fovy=fov)
def capsule(w,n,p,q,r,mat):
    return el(w,'geom',name=n,type='capsule',fromto=vec([*p,*q]),size=r,material=mat,condim=6)
def cradle(w,x,y,z,prefix):
    for i in range(16):
        a,b=2*np.pi*np.array([i,i+1])/16
        capsule(w,prefix+str(i),(x+.014*np.cos(a),y+.014*np.sin(a),z),(x+.014*np.cos(b),y+.014*np.sin(b),z),.002,'tire')
def datum(w,c,n,cz,sx,sy):
    # Tapered, extruded framing supports real working and catch surfaces.
    box(w,n+'_slab',(c,.76,cz-.015),(sx,sy,.015),'paint')
    for i in (-1,1):
        for j in (-1,1):
            box(w,n+f'_leg_{i}_{j}',(c+i*(sx-.027),.76+j*(sy-.027),cz*.48),(.016,.016,cz*.48),'frame')
        box(w,n+f'_brace_{i}',(c+i*(sx-.027),.76,cz*.20),(.011,sy-.025,.011),'frame',physical=False)
    box(w,n+'_rail',(c,.76+sy-.027,cz*.20),(sx-.02,.011,.011),'frame',physical=False)
def copy_assets(dom,key,s):
    for entry in dom.find('asset'):
        if entry.get('file'):
            src=(LIB/({'omron':'bases','panda':'robots/panda','hand':'grippers'}[key])/entry.get('file'))
            dest=ROOT/'assets'/key/entry.get('file')
            dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists():shutil.copy2(src,dest)
            entry.set('file',os.path.relpath(dest,ROOT/SLUGS[0]))
        if key=='omron' and entry.tag=='material':entry.set('name','om_'+entry.get('name'))
        s.append(entry)
def build(k):
    out=ROOT/SLUGS[k];out.mkdir(exist_ok=True)
    root=ET.Element('mujoco',model=SLUGS[k])
    el(root,'compiler',angle='radian',autolimits='true',fusestatic='false')
    el(root,'option',timestep='.001',integrator='implicitfast',iterations=55,cone='elliptic')
    visual=el(root,'visual');el(visual,'global',offwidth=1280,offheight=800)
    el(visual,'quality',shadowsize=2048)
    el(visual,'headlight',ambient='.32 .32 .34',diffuse='.55 .55 .55',specular='.23 .23 .23')
    df=el(root,'default');el(df,'geom',friction='.72 .004 .0005',solref='.009 1',solimp='.96 .995 .001')
    asset=el(root,'asset');world=el(root,'worldbody');acts=el(root,'actuator');contact=el(root,'contact')
    for n,c in [('floor','.34 .35 .36 1'),('frame','.23 .28 .30 1'),('paint',['.68 .72 .72 1','.47 .33 .21 1','.70 .81 .78 1','.46 .53 .49 1','.54 .48 .39 1'][k]),('edge','.88 .56 .13 1'),('tire','.095 .115 .12 1'),('aluminum','.61 .65 .65 1'),('fiber',COLORS[k]),('sleeve',['.86 .75 .52 1','.78 .57 .32 1','.35 .64 .70 1','.60 .68 .67 1','.42 .27 .12 1'][k]),('ink','.13 .20 .22 1')]:
        el(asset,'material',name=n,rgba=c,specular=.54 if n=='aluminum' else .24,shininess=.65 if n=='aluminum' else .24)
    el(world,'light',directional='true',pos='-4 -4 7',dir='.42 .44 -.80')
    el(world,'geom',name='floor',type='plane',size='13 10 .1',material='floor')
    om=ET.parse(LIB/'bases/omron_mobile_base.xml').getroot()
    panda=ET.parse(LIB/'robots/panda/robot.xml').getroot()
    hand=ET.parse(LIB/'grippers/panda_gripper.xml').getroot()
    for dom,key in [(om,'omron'),(panda,'panda'),(hand,'hand')]:copy_assets(dom,key,asset)
    base=om.find('worldbody/body');world.append(base)
    for g in base.iter('geom'):
        if g.get('material'):g.set('material','om_'+g.get('material'))
        if g.get('group')=='0' or g.get('name')=='pedestal_feet_col':
            g.attrib.update(group='3',rgba='0 0 0 0')
        elif g.get('group')=='1':g.attrib.update(contype='0',conaffinity='0')
    # The mobile library uses planar forward, sideways and yaw drives with internal rolling resistance.
    # Retain the low telescoping pillar at its nominal height as a fixed factory setup.
    support=base.find(".//body[@name='support']");support.remove(support.find('joint'))
    for e in om.find('actuator'):
        if e.get('joint')!='joint_torso_height':acts.append(e)
    pr=panda.find('worldbody/body');pr.set('name','panda_base');pr.set('pos','-.05 0 0');pr.set('euler','0 0 1.57079632679');support.append(pr)
    for actuator in panda.find('actuator'):
        actuator.set('name','drive_'+actuator.get('joint'));acts.append(actuator)
    for g in pr.iter('geom'):
        if g.get('group')=='0':g.attrib.update(group='3',rgba='0 0 0 0')
    flange=pr.find(".//body[@name='right_hand']")
    wrist=hand.find('worldbody/body');flange.append(wrist)
    for g in wrist.iter('geom'):
        if g.get('group')=='0':g.attrib.update(group='3',rgba='0 0 0 0')
        if 'pad_collision' in g.get('name',''):
            g.attrib.update(priority='4',margin='.00025',condim='6',solref='.005 1',solimp='.96 .995 .001',friction='1.25 .012 .004')
    if k==4:
        # Reversible four-point protective inserts on the two library fingers support
        # a spherical specimen during a long run without attaching it to the arm.
        for i,sgn in [(1,1),(2,-1)]:
            tip=wrist.find(f".//body[@name='finger_joint{i}_tip']")
            pad=tip.find(f"geom[@name='finger{i}_pad_collision']")
            mount=el(tip,'body',name=f'protective_pad_{i}',pos=pad.get('pos'),quat=pad.get('quat'))
            for j in (-1,1):
                for row in (-1,1):
                    geom(mount,f'finger{i}_cup_{j}_{row}','sphere',(.006*j,sgn*.006,.006+row*.007),(.004,), 'tire',
                         mass=.00015,condim=6,priority=4,margin='.00015',solref='.003 1',solimp='.96 .997 .001',friction='1.15 .008 .001')
    for s in base.iter('site'):s.set('rgba','0 0 0 0')
    for actuator in hand.find('actuator'):acts.append(actuator)
    el(contact,'exclude',body1='link7',body2='right_gripper')
    el(contact,'exclude',body1='link0',body2='support')
    el(contact,'exclude',body1='link0',body2='fixed_support')
    el(flange,'site',name='tcp',pos='0 0 .098',size='.001',rgba='0 0 0 0')
    # The benches start beyond the driving footprint, with receivers safely above an independently supported tray.
    datum(world,PICK_X,'source_bench',PICK_TOP-.028,.4,.295)
    box(world,'pickup_pad',(PICK_X,Y,PICK_TOP-.014),(.092,.084,.014),'tire')
    datum(world,DEST_X,'receiver_bench',CATCH-.016,.43,.29)
    box(world,'catch_floor',(DEST_X,.70,CATCH-.008),(.398,.224,.008),'tire',priority=3,margin='.0009',solref='.002 1',solimp='.985 .999 .001',friction='.98 .01 .005',condim=6)
    for sgn in (-1,1):
        box(world,'catch_side_'+str(sgn),(DEST_X+sgn*.398,.70,CATCH+.035),(.008,.228,.035),'paint')
        box(world,'catch_end_'+str(sgn),(DEST_X,.70+sgn*.222,CATCH+.035),(.394,.006,.035),'paint')
    if k in (0,1,3,4):
        box(world,'receiver_plinth',(DEST_X,.83,(CATCH+TOP)/2),(.06,.048,(TOP-CATCH)/2-.022),'paint')
        # Rear bracket cantilevers the deck above the lower tray.
        box(world,'receiver_bracket',(DEST_X,.74,TOP-(.072 if k==1 else .032)),(.025 if k==1 else .044,.109,.012),'aluminum')
        if k==1:
            geom(world,'scale_axle','cylinder',(DEST_X,.66,TOP-.008),(.006,.098),'aluminum',physical=False,euler='1.5707963 0 0')
            box(world,'scale_bearing',(DEST_X,.733,TOP-.041),(.007,.008,.031),'frame',physical=False)
    if k==0:
        box(world,'receiver_shelf',(DEST_X,Y,TOP-.011),(.083,.116,.011),'aluminum')
        box(world,'shelf_edge_mark',(DEST_X-.082,Y,TOP-.008),(.0018,.115,.004),'edge',physical=False)
    if k==1:
        b=body(world,'weigh_deck',(DEST_X,Y,TOP-.008));el(b,'joint',name='deck_pitch',axis='0 1 0',range='-.56 .56',damping='.030',stiffness='.22',armature='.0002')
        box(b,'receiver_scale',(0,0,0),(.108,.104,.008),'aluminum',mass=.20,priority=3,margin='.0005',solref='.004 1',solimp='.98 .998 .001',friction='.105 .001 .0001',condim=6)
    if k==2:
        # The linear receiving saddle runs on rear bearings with the reject tray underneath.
        for z in (TOP-.047,TOP-.067):box(world,'track_'+str(z),(DEST_X+.1,.845,z),(.23,.009,.007),'aluminum')
        for i in (-1,1):box(world,'track_support_'+str(i),(DEST_X+i*.18,.845,(TOP+CATCH)/2-.025),(.015,.02,(TOP-CATCH)/2-.028),'frame')
        b=body(world,'shuttle',(DEST_X+.24,Y,TOP-.008));el(b,'joint',name='shuttle_slide',type='slide',axis='-1 0 0',range='-.01 .25',damping=12,armature=.15)
        box(b,'receiver_shuttle',(0,0,0),(.076,.081,.008),'paint',mass=.48)
        box(b,'shuttle_beam',(0,.135,-.027),(.028,.08,.006),'aluminum',physical=False)
        el(acts,'position',name='shuttle_motor',joint='shuttle_slide',kp=1250,kv=60)
    if k==3:
        box(world,'receiver_bed',(DEST_X,Y,TOP-.011),(.207,.114,.011),'aluminum')
        b=body(world,'registration_flag',(DEST_X-.013,Y+.052,TOP+.005));el(b,'joint',name='flag_pitch',axis='0 1 0',range='-.01 1.56',damping='.0016',armature='.00005')
        box(b,'registration_finger',(0,0,.023),(.0034,.009,.023),'edge',mass=.015)
        geom(world,'flag_axle','cylinder',(DEST_X-.013,Y+.052,TOP+.004),(.006,.013),'ink',physical=False,euler='1.57079633 0 0')
    if k==4:
        # A fixed downsloping examination track; the seated sphere stays behind a circular locating lip.
        b=body(world,'ramp',(DEST_X,Y,TOP-.009));b.set('euler','0 -.13 0')
        box(b,'receiver_ramp',(0,0,0),(.169,.094,.009),'aluminum',friction='.40 .001 .0001',condim=6)
        cradle(b,.012,0,.011,'receiver_seat_');cradle(world,PICK_X,Y,PICK_TOP+.002,'pickup_ring_')
    bottom=PICK_TOP if k!=4 else PICK_TOP+.002+np.sqrt((HZ[k]+.002)**2-(.014*np.cos(np.pi/16))**2)-HZ[k]
    obj=body(world,'payload',(PICK_X,Y,bottom+HZ[k]));el(obj,'freejoint',name='payload_free')
    if k in (0,2,3):
        halfy=[.045,0,.039,.065,0][k]
        box(obj,'item',(0,0,0),(HALFX[k],halfy,HZ[k]),'fiber',mass=MASS[k],condim=6)
        box(obj,'item_label',(0,0,HZ[k]+.00015),(HALFX[k]*.72,halfy*.52,.00015),'sleeve',physical=False)
        for i in range(7):
            box(obj,f'item_ident_{i}',(-.012+i*.0037,.004,HZ[k]+.00034),(.00035+(i%3)*.00015,halfy*.20,.0001),'ink',physical=False)
    if k==1:
        geom(obj,'item','cylinder',(0,0,0),(HALFX[k],HZ[k]),'fiber',mass=MASS[k],condim=6,friction='.30 .002 .0002')
        geom(obj,'sample_label','cylinder',(0,0,.001),(HALFX[k]+.00015,HZ[k]*.48),'sleeve',physical=False)
        geom(obj,'sample_lid','cylinder',(0,0,HZ[k]-.001),(HALFX[k]+.00015,.0012),'aluminum',physical=False)
    if k==4:
        geom(obj,'item','sphere',(0,0,0),(HZ[k],),'fiber',mass=MASS[k],condim=6,friction='.6 .001 .0001')
        # Offset engraved marking lies on the sphere; a small spherical cap & equatorial band make rotation legible.
        for j,(z,hh) in enumerate([(.006,.0008),(.017,.0009)]):
            rr=np.sqrt(HZ[k]**2-z*z)
            geom(obj,'reference_mark_'+str(j),'cylinder',(0,0,z),(rr+.00012,hh),'ink',physical=False)
    camera(world,'overview',(1.7,-8.7,5.35),(0,.42,.58),54)
    camera(world,'detail',(DEST_X+.70,-.38,1.54),(DEST_X,.65,.91),36)
    ET.indent(root);ET.ElementTree(root).write(out/'scene.xml',encoding='utf-8')
    
    return out
if __name__=='__main__':
    import mujoco
    for k in range(5):
        out=build(k);m=mujoco.MjModel.from_xml_path(str(out/'scene.xml'));print(out,m.nq,m.nbody)
