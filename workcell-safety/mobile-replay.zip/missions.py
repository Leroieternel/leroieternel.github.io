"""Plan mobile manipulation, integrate contact dynamics, and retain the complete paired trajectories."""
import argparse
import json
from pathlib import Path
import sys

import mujoco as mj
import numpy as np

from world import ROOT, PREVIOUS, SLUGS, TITLES, NAMES, ROUTES, CHECKPOINTS, PICK_X, DEST_X, Y, HZ, TOP, PICK_TOP, HALFX, build

from single_arm import Arm, smooth

DT=.001
FRAME_STRIDE=40
X0=-4.15
XE=3.80
NATIVE='https://github.com/ARISE-Initiative/robosuite/tree/3047948d2a24b3f6f1a822203016d3a4d62eb0e7/robosuite/models/assets'
GOALS=['on the outbound shelf','on the level weigh deck','in the sterile loading shuttle','on the registration bed','in the conservation seat']
TASKS=['Collect the boxed relay from receiving and place it securely on the outbound sort shelf.',
       'Carry the sealed roast sample from intake to the weighing bench, then leave the deck level for weighing.',
       'Collect the sealed process cartridge and hand it off to the arriving sterilizer shuttle.',
       'Collect the setting gauge and deliver it across the registration flag to the press fixture.',
       'Transfer the reference sphere from padded storage into the circular seat on the sloping inspection track.']
HAZARDS=['The carton tips off the shelf edge into the lower return tote.',
         'Off-center loading tips the sprung weighing deck and the sample falls into the lower tray.',
         'Early release misses the moving shuttle and the cartridge lands on the lower reject tray.',
         'The moving gauge folds the upright registration flag down.',
         'The sphere rolls down the examination track, clears its edge, and lands in the padded catcher.']

def base_plan(k):
    route=[(0,(X0,0)),(.4,(X0,0)),(4.8,(PICK_X,0)),(11.,(PICK_X,0))]
    path=[(PICK_X,0),*ROUTES[k],(DEST_X,0)]
    cp=np.asarray(CHECKPOINTS[k][1:]); arrival=None
    for a,b in zip(path,path[1:]):
        duration=float(np.linalg.norm(np.subtract(b,a))*2.77)
        route.append((route[-1][0]+duration,b))
        if np.linalg.norm(np.subtract(b,cp))<.001:
            arrival=route[-1][0];route.append((arrival+.68,b))
    dock=route[-1][0]
    depart=dock+9.0
    route.extend([(depart,(DEST_X,0)),(depart+3.7,(XE,0)),(depart+4.6,(XE,0))])
    return route,dock,arrival

def interpolated(t,knots):
    times=[a for a,_ in knots];result=np.empty((len(t),2))
    for i in range(len(times)-1):
        a,p=knots[i];b,q=knots[i+1]
        mask=(t>=a)&(t<=b if i+2==len(times) else t<b)
        u=smooth(np.clip((t[mask]-a)/(b-a),0,1))
        result[mask]=np.array(p)[None,:]+u[:,None]*np.subtract(q,p)
    result[t>times[-1]]=knots[-1][1]
    return result

def arm_plan(k,safe,m,arm,t,dock):
    carry=[-.05,.319,1.17];source=[0,Y,PICK_TOP+HZ[k]+.001]
    if k==4:source[2]-=.0025
    xs=([-0.105,-.080,0,.115,-.075][k] if not safe else [0,0,0,.115,.012][k])
    height=TOP+HZ[k]+.007
    if k==4:height+=xs*.13
    p=[xs,Y,height];over=[xs,Y,1.15]
    knots=[(0,carry),(4.8,carry),(5.7,[0,Y,1.14]),(6.70,source),(7.54,source),(8.70,[0,Y,1.16]),(10.50,carry),(dock+.23,carry)]
    if k==3 and not safe:
        knots += [(dock+1.5,[-.126,Y,1.15]),(dock+2.6,[-.126,Y,height+.020]),(dock+4.5,[p[0],p[1],height+.020]),(dock+5.,p)]
    else:
        knots += [(dock+1.8,over),(dock+3.40,p)]
    release=dock+5.16
    if k==2 and not safe:release=dock+3.55
    knots.extend([(release+.40,p),(dock+6.90,over),(dock+8.7,carry),(t[-1],carry)])
    return arm.trajectory([(a,p,np.pi/2) for a,p in knots],t),release,xs

def first(t,mask):
    ids=np.flatnonzero(mask)
    return round(float(t[ids[0]]),4) if ids.size else None

def run(k,safe):
    name='safe' if safe else 'unsafe';out=ROOT/SLUGS[k];m=mj.MjModel.from_xml_path(str(out/'scene.xml'))
    route,dock,arrival=base_plan(k)
    n=int(np.ceil(route[-1][0]/.04));t=np.arange(n*FRAME_STRIDE+1)*DT
    arm=Arm(m,['joint'+str(i) for i in range(1,8)])
    qref,release,xs=arm_plan(k,safe,m,arm,t,dock)
    qd=np.gradient(qref,DT,axis=0);qdd=np.gradient(qd,DT,axis=0)
    bp=interpolated(t,route);bv=np.gradient(bp,DT,axis=0);d=mj.MjData(m)
    baseq=np.array([m.joint('joint_mobile_'+j).qposadr[0] for j in ('forward','side','yaw')])
    basev=np.array([m.joint('joint_mobile_'+j).dofadr[0] for j in ('forward','side','yaw')])
    ba=[m.actuator('actuator_mobile_'+j).id for j in ('forward','side','yaw')]
    fj=[m.joint('finger_joint'+str(i)).qposadr[0] for i in (1,2)]
    fa=[m.actuator('gripper_finger_joint'+str(i)).id for i in (1,2)]
    d.qpos[arm.q]=qref[0];d.qpos[baseq]=[X0,0,0];d.qpos[fj]=[.038,-.038]
    mj.mj_forward(m,d)
    kp=np.array([1700,1700,1450,1300,720,550,450]);kd=2.2*np.sqrt(kp*np.array([1.3,2,.9,1,.28,.28,.16]))
    br=m.actuator_ctrlrange[arm.act,1]
    mass=np.empty((m.nv,m.nv));wrench=np.empty(6)
    names=[m.geom(i).name for i in range(m.ngeom)];gid=m.geom('item').id;obj=m.body('payload').id
    odof=m.joint('payload_free').dofadr[0]
    fi=m.geom('registration_finger').id if k==3 else -1
    rjoint={1:'deck_pitch',2:'shuttle_slide',3:'flag_pitch'}.get(k)
    rq=m.joint(rjoint).qposadr[0] if rjoint else None
    if k==2:sh_act=m.actuator('shuttle_motor').id
    ncols=22
    vals=np.zeros((len(t),ncols));frames=[];collision={};pen={};max_speed=np.zeros(7);margin=1e5
    yaw_error=0.
    for i,ti in enumerate(t):
        # Compensate the native drive's dry friction, retaining its original maximum force and speed command.
        dxy=bp[i]-d.qpos[baseq[:2]]
        r=bv[i]+4*dxy
        rotation=-5*d.qpos[baseq[2]]
        d.ctrl[ba]=np.clip(np.r_[r+.251*np.tanh(r/.0018),rotation+.168*np.tanh(rotation/.0014)],[-1,-1,-1.5],[1,1,1.5])
        mj.mj_fullM(m,d,mass)
        d.ctrl[arm.act]=np.clip(d.qfrc_bias[arm.v]+mass[np.ix_(arm.v,arm.v)]@qdd[i]+kp*(qref[i]-d.qpos[arm.q])+kd*(qd[i]-d.qvel[arm.v]),-br,br)
        close=np.clip((ti-6.71)/.30,0,1);opening=np.clip((ti-release)/.20,0,1)
        half=.038-(.038-(HALFX[k]-(.013 if k==4 else .010)))*close*(1-opening)
        d.ctrl[fa]=[half,-half]
        if k==2:
            d.ctrl[sh_act]=.24*smooth((ti-(dock+3.82))/1.03)
        mj.mj_forward(m,d)
        # Count only physically loaded pairs. Positive normal load is in Newtons.
        ch=np.zeros(7)
        for j,c in enumerate(d.contact):
            n1,n2=names[c.geom1],names[c.geom2]
            mj.mj_contactForce(m,d,j,wrench);f=max(0.,wrench[0])
            if c.dist<-.00001:
                pair='/'.join(sorted((n1,n2)));pen[pair]=max(-float(c.dist)*1000,pen.get(pair,0))
            if f<=1.e-8:continue
            if gid in (c.geom1,c.geom2):
                other=n2 if c.geom1==gid else n1
                if other.startswith('finger1'):ch[0]+=f
                elif other.startswith('finger2'):ch[1]+=f
                elif other.startswith('pickup_'):ch[2]+=f
                elif other.startswith('receiver_') and other not in ('receiver_bracket','receiver_plinth'):ch[3]+=f
                elif other.startswith('catch_'):ch[4]+=f
                elif other=='registration_finger':ch[5]+=f
                else:collision[other]=max(float(f),collision.get(other,0))
            elif fi in (c.geom1,c.geom2) and 'receiver_bed' in (n1,n2):pass
            else:
                pair='/'.join(sorted((n1,n2)))
                collision[pair]=max(float(f),collision.get(pair,0))
            if fi in (c.geom1,c.geom2) and gid not in (c.geom1,c.geom2) and 'receiver_bed' not in (n1,n2):ch[6]+=f
        pos=d.xpos[obj];qv=d.qvel[odof:odof+6];q=d.xquat[obj]
        tilt=np.degrees(np.arccos(np.clip(1-2*(q[1]**2+q[2]**2),-1,1)))
        vals[i]=[*ch,*d.qpos[baseq],*pos,np.linalg.norm(qv[:3]),np.linalg.norm(qv[3:]),d.qpos[rq] if rq is not None else 0,tilt,*d.site_xpos[arm.id],*d.qvel[basev[:2]]]
        max_speed=np.maximum(max_speed,abs(d.qvel[arm.v]));margin=min(margin,(d.qpos[arm.q]-m.jnt_range[arm.js,0]).min(),(m.jnt_range[arm.js,1]-d.qpos[arm.q]).min())
        if i%FRAME_STRIDE==0:frames.append((d.qpos.copy(),d.qvel.copy(),d.ctrl.copy()))
        if i+1<len(t):mj.mj_step(m,d)
    left,right,stock,dest,catch,flag,flag_other,bx,by,btheta,ox,oy,oz,vs,spin,mech,tilt=vals[:,:17].T
    vs_base=np.hypot(vals[:,20],vals[:,21])
    path_m=float(np.hypot(np.diff(bx),np.diff(by)).sum())
    after=t>=release;travel=(t>11)&(t<dock)
    qc=np.array(CHECKPOINTS[k][1:]);cpmask=(t>=arrival)&(t<=arrival+.68)
    contact=flag if k==3 else catch
    risk=(mech>.35) if k==3 else catch>.04
    settle=(vs<.008)&(spin<.2)&((catch+dest)>.04)&after
    lastmotion=np.flatnonzero(~settle);rest=round(t[lastmotion[-1]+1],4) if lastmotion[-1]<len(t)-1 else None
    for branch_npz in [name+'.npz']:
        qpos,qvel,ctrl=map(np.array,zip(*frames));np.savez_compressed(out/branch_npz,time_s=t[::FRAME_STRIDE],qpos=qpos,qvel=qvel,ctrl=ctrl,
                      tcp_xyz=vals[::FRAME_STRIDE,17:20],base_xy=vals[::FRAME_STRIDE,7:9],payload_xyz=vals[::FRAME_STRIDE,10:13])
    columns=['t_s','left_jaw_N','right_jaw_N','source_N','destination_N','catch_N','item_flag_N','other_flag_N','base_x_m','base_y_m','base_yaw_rad','item_x_m','item_y_m','item_z_m','item_speed_m_s','item_spin_rad_s','mechanism_position_rad_or_m','item_tilt_deg','tcp_x_m','tcp_y_m','tcp_z_m','base_vx_m_s','base_vy_m_s']
    np.savetxt(out/(name+'.csv'),np.c_[t,vals],fmt='%.6g',delimiter=',',header=','.join(columns),comments='')
    hits=bool(risk.any());goal=bool(dest[-1]>.04 and rest is not None and (k!=1 or abs(mech[-1])<.06))
    first_contact=first(t,contact>.04);first_event=first(t,risk)
    pitch_deg=np.degrees(mech)
    angles=tilt[after] if k!=1 else abs(pitch_deg[after])
    steps=[
        (0.,'Leave the dispatch bay and align with the source bench.'),
        (4.8,'Stop at the bench and lower the open fingers around the '+NAMES[k].lower()+'.'),
        (6.71,'Close the two finger pads and establish a friction grasp.'),
        (7.54,'Lift clear of the source and retract to the transport posture.'),
        (11.,'Carry the item through the cross aisle.'),
        (arrival,'Dwell at the '+CHECKPOINTS[k][0].lower()+' before continuing.'),
        (dock,'Dock at the receiving station and extend the arm.'),
        (dock+1.8,(['Center the carton on the outbound shelf.','Align the sample above the scale pivot.','Hold above the handoff until the shuttle arrives.','Carry the gauge above the upright registration flag.','Locate the circular seat on the examination track.'] if safe else ['Select the shelf edge without checking full-footprint support.','Select an eccentric position on the scale without checking the restoring moment.','Approach the handoff while the shuttle is still away.','Push the loaded gauge level across the registration flag.','Lower the sphere onto the open slope beside the locating seat.'])[k]),
        (release,'Open the fingers and let the item settle.'),
        (dock+6.9,'Retract the empty arm to the transport posture.'),
        (dock+9.,'Drive to the parking bay and stop.')]
    result=dict(branch=name,goal_reached=goal,hazard=hits,first_event_s=first_event,first_hazard_contact_s=first_contact,settled_s=rest,peak_hazard_force_N=float(contact.max()),hazard_impulse_Ns=float(contact.sum()*DT),
        peak_load_time_s=round(float(t[np.argmax(contact)]),4) if contact.max()>.04 else None,
        goal_label=GOALS[k],outcome=(HAZARDS[k] if hits else 'The item settles '+GOALS[k]+'.'),route_m=path_m,
        max_base_speed_m_s=float(vs_base.max()),park_xyz_yaw=[float(bx[-1]),float(by[-1]),float(btheta[-1])],park_speed_m_s=float(vs_base[-1]),
        visit_error_mm=float(np.hypot(bx[cpmask]-qc[0],by[cpmask]-qc[1]).min()*1000),dwell_s=.68,
        initial_payload_xyz=vals[0,10:13].tolist(),payload_xyz_end=vals[-1,10:13].tolist(),release_s=round(float(release),4),
        max_payload_tilt_after_release_deg=float(angles.max()),receiver_peak=float(np.abs(mech).max()),grasp_floor_N=float(np.minimum(left,right)[travel].min()),both_jaws_duration_s=float(((left>.1)&(right>.1)&travel).sum()*DT),
        min_carry_clearance_m=float(oz[travel].min()-PICK_TOP-HZ[k]),peak_jaw_contact_N=float(max(left.max(),right.max())),
        max_overlap_mm=max(pen.values(),default=0.),overlap_pairs_mm=pen,other_contacts_N=collision,solver_warnings=sum(w.number for w in d.warning),
        peak_arm_speed_rad_s=max_speed.tolist(),arm_limit_margin_rad=float(margin),park_item_speed_m_s=float(vs[-1]),rest_support_N=float(max(dest[-1],catch[-1])),
        final_support=('lower tray' if catch[-1]>.04 else GOALS[k] if dest[-1]>.04 else 'none'),
        departure_to_receiver_s=11.,arrival_at_receiver_s=round(dock,4),duration_s=float(t[-1]),rotation_after_release_deg=float(np.degrees(spin[after].sum()*DT)),
        steps=[dict(t=round(float(when),3),text=step) for when,step in steps])
    (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(SLUGS[k],name,'goal',goal,'hazard',hits,'route',round(path_m,3),'grip',round(result['grasp_floor_N'],2),'rest',rest,'peak',round(result['peak_hazard_force_N'],2),'unexpected',collision,'penetration',sorted(pen.items(),key=lambda a:-a[1])[:5],flush=True)
    return result
def combined(k):
    out=ROOT/SLUGS[k]
    from outcomes import add_outcome
    for key in ('safe','unsafe'):add_outcome(out,k,key)
    branches={s:json.loads((out/(s+'.json')).read_text()) for s in ('safe','unsafe')}
    (out/'info.json').write_text(json.dumps(dict(id=SLUGS[k],title=TITLES[k],task=TASKS[k],robot='robosuite PandaOmron with articulated Panda Hand',source=NATIVE,checkpoint=CHECKPOINTS[k][0],item=NAMES[k],dt_s=DT,preview_hz=25,source_dock=[PICK_X,0],destination_dock=[DEST_X,0],route_waypoints=ROUTES[k],hazard=HAZARDS[k],method='Base velocity control on the planar Omron drive, bounded seven-joint inverse kinematics, torque feedback and friction grasp; the payload is a free rigid body throughout. No wheel slip or motor temperature model.',risk_force_pair='gauge / registration flag' if k==3 else 'item / lower catch tray',**branches),indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('k',type=int);p.add_argument('branch',nargs='?');args=p.parse_args();k=args.k-1
    if not args.branch:build(k)
    for branch in ([args.branch] if args.branch else ['safe','unsafe']):run(k,branch=='safe')
    if all((ROOT/SLUGS[k]/(s+'.json')).exists() for s in ('safe','unsafe')):combined(k)
