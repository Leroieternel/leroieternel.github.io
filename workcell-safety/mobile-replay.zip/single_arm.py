import numpy as np
import mujoco as mj
from scipy.spatial.transform import Rotation

def smooth(x):
    x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))

def matrix(yaw):return Rotation.from_euler('z',yaw).as_matrix()@np.diag([1.,-1.,-1.])

class Arm:
    def __init__(self,m,names):
        self.m=m;self.d=mj.MjData(m)
        js=[m.joint(n).id for n in names];self.js=js;self.q=m.jnt_qposadr[js];self.v=m.jnt_dofadr[js]
        self.act=np.array([m.actuator('drive_'+j).id for j in names])
        self.lim=m.jnt_range[js].T.copy();self.lim[0]+=.004;self.lim[1]-=.004
        self.id=m.site('tcp').id
        self.seed=np.array([0,-.55,0,-1.90,0,1.55,.7] if len(js)==7 else [-3,-1.5,1.8,-1.8,-1.57,0])
    def solve(self,p,yaw,seed,initial=False):
        m,d=self.m,self.d;R=matrix(yaw);q=np.clip(seed,*self.lim).copy()
        jp=np.zeros((3,m.nv));jr=jp.copy()
        seeds=[q]
        if initial:
            rng=np.random.default_rng(29);seeds += [np.clip(q+rng.normal(0,.92,len(q)),*self.lim) for _ in range(24)]
        for guess in seeds:
            q=guess.copy()
            for _ in range(110):
                d.qpos[self.q]=q;mj.mj_kinematics(m,d);mj.mj_comPos(m,d)
                poserr=p-d.site_xpos[self.id];roterr=Rotation.from_matrix(R@d.site_xmat[self.id].reshape(3,3).T).as_rotvec()
                if np.linalg.norm(poserr)<.00010 and np.linalg.norm(roterr)<.0005:return q.copy()
                mj.mj_jacSite(m,d,jp,jr,self.id);J=np.vstack((jp[:,self.v],.25*jr[:,self.v]))
                resid=np.r_[poserr,.25*roterr]
                dq=J.T@np.linalg.solve(J@J.T+np.eye(6)*.00018,resid)
                length=max(np.max(abs(dq))/.14,1);q=np.clip(q+dq/length,*self.lim)
        raise ValueError(('unreachable',np.round(p,3),yaw,np.linalg.norm(poserr),np.linalg.norm(roterr)))
    def trajectory(self,knots,t):
        seed=self.solve(np.array(knots[0][1]),knots[0][2],self.seed,True)
        qs=[];kin_times=np.unique(np.r_[np.arange(0,t[-1]+.00001,.04),[float(k[0]) for k in knots],t[-1]])
        times=[k[0] for k in knots]
        for tt in kin_times:
            i=min(max(0,np.searchsorted(times,tt,side='right')-1),len(knots)-2)
            a,start,ya=knots[i];b,end,yb=knots[i+1];u=smooth((tt-a)/(b-a))
            xyz=(1-u)*np.asarray(start)+u*np.asarray(end);seed=self.solve(xyz,ya*(1-u)+yb*u,seed)
            qs.append(seed)
        qs=np.array(qs)
        return np.stack([np.interp(t,kin_times,col) for col in qs.T],axis=1)
