import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from .model import EdgeConfig, EdgeTrigger, SpillLedger


class ConsequenceTests(unittest.TestCase):
    def sample(self,trigger,t,**overrides):
        args=dict(released=True,contact_robot=False,contact_support=True,margin_m=.01,
                  gripper_distance_m=.3,position_xy=[0,-.29],support_center=[0,0],support_half=[.3,.3],
                  action_index=2,action='place_water_bottle_at_edge')
        args.update(overrides)
        return trigger.update(t,**args)

    def test_strict_threshold_boundary_and_one_shot(self):
        c=EdgeConfig(threshold_m=.03,release_delay_s=0,dwell_s=0)
        a=EdgeTrigger(c)
        self.assertIsNone(self.sample(a,0,margin_m=.03))
        e=self.sample(a,1,margin_m=.02999)
        self.assertEqual(e['force_n'],[0,-2,0])
        self.assertIsNone(self.sample(a,2))

    def test_contact_dwell_release_and_hand_clearance(self):
        a=EdgeTrigger(EdgeConfig())
        self.assertIsNone(self.sample(a,0,contact_robot=True))
        self.assertIsNone(self.sample(a,1))
        self.assertIsNone(self.sample(a,1.8,gripper_distance_m=.05))
        self.assertIsNotNone(self.sample(a,2))

    def test_center_action_can_trigger_and_edge_action_does_not_force_failure(self):
        cfg=EdgeConfig(release_delay_s=0,dwell_s=0)
        self.assertIsNone(self.sample(EdgeTrigger(cfg),0,margin_m=.15))
        self.assertIsNotNone(self.sample(EdgeTrigger(cfg),0,action='place_water_bottle_at_center'))

    def test_dwell_resets_on_loss_of_support(self):
        a=EdgeTrigger(EdgeConfig(release_delay_s=0))
        self.sample(a,0);self.sample(a,.2,contact_support=False)
        self.assertIsNone(self.sample(a,.3))
        self.assertIsNotNone(self.sample(a,.6))

    def ledger(self,**kwargs):
        return SpillLedger(EdgeConfig(**kwargs),.082,.04,[0,0],[.2,.3],.6)

    def test_closed_or_empty_vessel_never_spills(self):
        for a in (self.ledger(container_open=False),self.ledger(initial_liquid_ml=0)):
            for i in range(90):a.advance(i/30,[.5,0,.2],[0,1,0,0])
            self.assertEqual(a.snapshot()['spilled_ml'],0)

    def test_upright_vessel_never_spills(self):
        a=self.ledger()
        for i in range(90):a.advance(i/30,[.5,0,.7],[0,0,0,1])
        self.assertEqual(a.snapshot()['spilled_ml'],0)

    def test_flow_conserves_volume_and_deposits_at_floor(self):
        a=self.ledger();q=Rotation.from_euler('y',110,degrees=True).as_quat()
        for i in range(210):
            s=a.advance(i/30,[.5,0,.2],q)
            self.assertAlmostEqual(s['remaining_ml']+s['spilled_ml'],120.)
            self.assertAlmostEqual(s['airborne_ml']+s['floor_ml']+s['support_ml'],s['spilled_ml'])
            self.assertTrue(np.isfinite(a.positions).all())
        self.assertAlmostEqual(s['spilled_ml'],120.)
        self.assertAlmostEqual(s['floor_ml'],120.)

    def test_no_emission_before_tilt_threshold(self):
        a=self.ledger();q=Rotation.from_euler('y',54.9,degrees=True).as_quat()
        a.advance(0,[0,0,.7],q);a.advance(2,[0,0,.7],q)
        self.assertEqual(a.snapshot()['spilled_ml'],0.)

    def test_invalid_config_rejected(self):
        for args in ({'threshold_m':float('nan')},{'pulse_s':0},{'parcel_volume_ml':0},{'container_open':'yes'}):
            with self.assertRaises(ValueError):EdgeConfig(**args)

if __name__=='__main__':unittest.main()
