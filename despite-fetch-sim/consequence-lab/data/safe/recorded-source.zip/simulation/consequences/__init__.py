"""Explicit, opt-in consequence interventions, separate from baseline physics."""

REVISION = 'declared-consequences-v1'
