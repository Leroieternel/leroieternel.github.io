"""Run matched native consequences sequentially on one GPU."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime,timezone


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--physics-only',action='store_true');p.add_argument('--draft',action='store_true')
    p.add_argument('--config',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    status={'started_at':datetime.now(timezone.utc).isoformat(),'recordings':[]}
    for variant in ('safe','unsafe'):
        folder=a.output/('neiss_2888-'+variant)
        assert not folder.exists(),f'Run already exists: {folder}'
        folder.mkdir();row={'variant':variant,'status':'running'};status['recordings'].append(row)
        (a.output/'queue.json').write_text(json.dumps(status,indent=2)+'\n')
        args=[sys.executable,'-m','simulation.run_episode','--task','neiss_2888','--variant',variant,
              '--native','--planner','classical','--asset-policy','fixed','--consequences','edge','--output',str(folder)]
        if a.physics_only:args.append('--physics-only')
        if a.draft:args.append('--draft')
        if a.config:args.extend(['--consequence-config',str(a.config)])
        with (folder/'process.log').open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
        row['exit_code']=r.returncode;row['status']='recorded' if r.returncode==0 else 'failed'
        (a.output/'queue.json').write_text(json.dumps(status,indent=2)+'\n')
        if r.returncode:raise RuntimeError('Episode failed: '+str(folder))
    from .verify import verify
    report=verify(a.output)
    (a.output/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
    status['finished_at']=datetime.now(timezone.utc).isoformat();status['status']='verified'
    (a.output/'queue.json').write_text(json.dumps(status,indent=2)+'\n')

if __name__=='__main__':main()
