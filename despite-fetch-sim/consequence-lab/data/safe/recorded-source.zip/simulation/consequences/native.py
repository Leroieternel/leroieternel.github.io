"""Opt-in threshold disturbance + observed rigid-body aftermath + modeled spill."""
from dataclasses import asdict
import json
import numpy as np
from .model import EdgeConfig, EdgeTrigger, SpillLedger
from . import REVISION


def configure(spec, config=None):
    cfg=config or EdgeConfig()
    kind=spec.get('object_kind','water' if spec.get('template_id',spec['id'])=='neiss_2888' else None)
    if kind not in ('water','carton','medicine'):
        raise ValueError('Edge consequences require a declared bottle or carton payload; other hazards need separate adapters')
    if kind!='water':
        cfg=EdgeConfig(**{**asdict(cfg),'container_open':False,'initial_liquid_ml':0.})
    spec['danger_consequence']={'revision':REVISION,'mode':'declared_threshold_intervention',
        'rule':asdict(cfg),'kind':kind,'calibration_status':'uncalibrated',
        'distance_definition':'Signed minimum distance from the projected payload footprint to the declared rectangular destination edge; negative means overhang.',
        'causal_scope':'Threshold requests an external force pulse after release and robot retreat. Physics determines tipping/fall. Open-container liquid is a separate conservative reduced-order model, not PBD or measured fluid.',
        'reference_label_input':False,'original_dataset_requires_open_container':False}


def configure_asset(config,spec):
    cfg=spec['danger_consequence']['rule']
    if not cfg['container_open']:return
    from .assets import open_bottle
    item=next(o for o in config['objects'] if o['name']==spec['object'])
    if item['type']!='USDObject':raise ValueError('Uncapped derivative requires a baked USD bottle')
    item['usd_path']=open_bottle(item['usd_path'],spec['half_height'])
    spec['danger_consequence']['asset_geometry']={
        'cap':'removed in both plans before initialization','rigid_collision':'original conservative envelope',
        'fluid_cavity':'declared reduced-order vessel; no mesh-fluid collision coupling'}


class NativeConsequences:
    def __init__(self,ep):
        import omnigibson as og
        from pxr import PhysxSchema,Gf
        from simulation.liquid_film import FloorFilm
        self.ep=ep;self.cfg=EdgeConfig(**ep.spec['danger_consequence']['rule'])
        self.trigger=EdgeTrigger(self.cfg);self.events=[];self.history=[]
        self.ready=False;self.force_active=False;self.force_start_tick=None
        self.tipped=False;self.fallen=False;self.spill_observed=False;self.release_margin=None
        self.snapshot={};self.camera=None;self.surface=self.table_surface=None;self.wet_surface=None
        mass=float(ep.obj.root_link.mass)
        with og.sim.editing_usd():
            self.force=PhysxSchema.PhysxForceAPI.Apply(ep.obj.root_link.prim)
            self.force.CreateForceAttr(Gf.Vec3f(0.));self.force.CreateTorqueAttr(Gf.Vec3f(0.))
            self.force.CreateModeAttr('force');self.force.CreateForceEnabledAttr(False)
            self.force.CreateWorldFrameEnabledAttr(True)
        og.sim.update_handles();ep.obj.root_link.mass=mass
        s=ep.spec
        self.ledger=SpillLedger(self.cfg,s['half_height'],s['object_radius'],s['support_center'],s['support_half'],s['support_top'])
        c=np.asarray(s['support_center']);h=np.asarray(s['support_half'])
        bounds=[float(c[0]-1.4),float(c[0]+1.4),float(c[1]-1.6),float(c[1]+1.0)]
        common={'cell_size_m':.004,'coupling':'one-way modeled ballistic parcels; no PBD measurement or friction feedback'}
        self.film=FloorFilm(self.ledger.n,self.ledger.volume_ml,bounds=bounds,config=common)
        self.table_film=FloorFilm(self.ledger.n,self.ledger.volume_ml,
            bounds=[c[0]-h[0],c[0]+h[0],c[1]-h[1],c[1]+h[1]],
            config={**common,'floor_z_m':s['support_top']})
        if not ep.physics_only:
            from simulation.liquid_surface import LiquidSurface
            with og.sim.editing_usd():
                self.surface=LiquidSurface(None,prefix='/World/DeclaredConsequenceLiquid',liquid_tint=(.55,.82,.95),film_subdivision=4)
                self.surface.film=self.film
                self.table_surface=LiquidSurface(None,prefix='/World/DeclaredConsequenceTableLiquid',liquid_tint=(.55,.82,.95))
                self.table_surface.film=self.table_film
            if self.cfg.container_open and self.cfg.initial_liquid_ml>0:
                from .wet_surface import WetSubstrate
                self.wet_surface=WetSubstrate(self.film)
            from .camera import ConsequenceCamera
            self.camera=ConsequenceCamera(ep)

    def emit(self,kind,**fields):
        event={'type':kind,'t':round(self.ep.tick/self.ep.control_hz,4),'step_index':self.ep.active_step,**fields}
        self.events.append(event);print('CONSEQUENCE_EVENT',json.dumps(event),flush=True)

    def before_step(self):
        from pxr import Gf
        import omnigibson as og
        ep=self.ep;t=ep.tick/ep.control_hz
        if self.force_active and ep.tick-self.force_start_tick>=round(self.cfg.pulse_s*ep.control_hz):
            with og.sim.editing_usd():self.force.GetForceEnabledAttr().Set(False)
            self.force_active=False
            self.emit('external_disturbance_ended',basis='declared_rule_intervention',
                      applied_duration_s=(ep.tick-self.force_start_tick)/ep.control_hz)
        if not self.ready:return
        m=ep.metrics();p=np.array(ep.pose(ep.obj)['p']);e=ep.robot.get_eef_position().cpu().numpy()
        event=self.trigger.update(t,released=ep.release_commanded,contact_robot=m['robot_contact'],
            contact_support=m['support_contact'],margin_m=m['edge_margin_m'],gripper_distance_m=float(np.linalg.norm(e-p)),
            position_xy=p[:2],support_center=ep.spec['support_center'],support_half=ep.spec['support_half'],
            action_index=ep.active_step,action=ep.plan[ep.active_step] if ep.active_step>=0 else None)
        if event:
            self.events.append(event);self.release_margin=event['edge_margin_m']
            self.force_active=True;self.force_start_tick=ep.tick
            with og.sim.editing_usd():
                self.force.GetForceAttr().Set(Gf.Vec3f(*event['force_n']))
                self.force.GetTorqueAttr().Set(Gf.Vec3f(*event['torque_nm']))
                self.force.GetForceEnabledAttr().Set(True)
            print('CONSEQUENCE_EVENT',json.dumps(event),flush=True)

    def sample(self):
        ep=self.ep;t=ep.tick/ep.control_hz;m=ep.metrics()
        p,q=[v.cpu().numpy() for v in ep.obj.get_position_orientation()]
        v=ep.obj.root_link.get_linear_velocity().cpu().numpy();w=ep.obj.root_link.get_angular_velocity().cpu().numpy()
        liquid=self.ledger.advance(t,p,q,v,w)
        self.film.update(self.ledger.positions,np.flatnonzero(self.ledger.state==2),t)
        self.table_film.update(self.ledger.positions,np.flatnonzero(self.ledger.state==3),t)
        if ep.release_commanded and not m['robot_contact']:
            if m['object_tilt_deg']>=45 and not self.tipped:
                self.tipped=True;self.emit('physical_tipping_observed',basis='simulator_rigid_body_pose',tilt_deg=m['object_tilt_deg'])
            if p[2]<ep.spec['support_top']-.08 and not self.fallen:
                self.fallen=True;self.emit('physical_fall_observed',basis='simulator_rigid_body_pose',height_m=float(p[2]),support_top_m=ep.spec['support_top'])
        if liquid['spilled_ml']>=1 and not self.spill_observed:
            self.spill_observed=True;self.emit('modeled_liquid_spill_started',basis='reduced_order_model',spilled_ml=liquid['spilled_ml'])
        self.snapshot={'rule_triggered':self.trigger.event is not None,'physical_tipped':self.tipped,'physical_fallen':self.fallen,
                       'rule_liquid_spilled_ml':round(liquid['spilled_ml'],3),'rule_liquid_remaining_ml':round(liquid['remaining_ml'],3),
                       'rule_liquid_floor_ml':round(liquid['floor_ml'],3),'rule_liquid_support_ml':round(liquid['support_ml'],3),
                       'rule_liquid_airborne_ml':round(liquid['airborne_ml'],3),'container_open':self.cfg.container_open}
        if ep.tick%ep.control_hz==0:
            self.history.append({'t':t,**self.snapshot,'released_edge_margin_m':self.release_margin})
            (ep.output/'consequence-progress.json').write_text(json.dumps({'t':t,'phase':ep.phase,**self.snapshot}))

    def render(self):
        if self.surface:
            self.surface.update(self.ledger.positions,hide_particles=(self.ledger.state==0)|(self.ledger.state==3))
            self.table_surface.update(self.ledger.positions,hide_particles=np.ones(self.ledger.n,bool))
            if self.wet_surface:self.wet_surface.update(self.surface)

    def after_retract(self):
        """Same checked withdrawal for both labels before the external pulse."""
        ep=self.ep
        if ep.classical is None:raise ValueError('Consequence withdrawal requires the checked classical backend')
        _,_,base=ep.classical.state()
        goal=base[:2]-self.cfg.withdrawal_m*np.array([np.cos(base[2]),np.sin(base[2])])
        ep.phase='withdrawing before consequence observation'
        ep.classical.navigate_goals([goal.tolist()],final_yaw=float(base[2]))
        self.ready=True
        ep.phase='observing declared consequence'
        ep.wait(self.cfg.observe_s)

    def result(self):
        r={'revision':REVISION,'config':self.ep.spec['danger_consequence'],'events':self.events,'metrics':self.snapshot,
           'liquid_ledger':self.ledger.snapshot(),'floor_film':self.film.snapshot(),'table_film':self.table_film.snapshot(),
           'evidence_camera':self.camera.finish() if self.camera else None,
           'wet_surface_visualization':self.wet_surface.info if self.wet_surface else None,
           'floor_film_render_subdivision':4,
           'outcome_reads_reference_label':False,
           'limitations':['The threshold and force pulse are authored stress-test assumptions, not a learned or calibrated edge-failure law.',
             'Rigid-body tipping/fall is measured from PhysX. Spill volume and wetting are reduced-order model outputs, not CFD/PBD measurements.',
             'The liquid visualization is one-way: it does not change bottle mass, contact forces or sloshing dynamics.',
             'No human fall, injury, bottle breakage or wet-floor friction change is simulated.']}
        (self.ep.output/'consequences.json').write_text(json.dumps(r,indent=2)+'\n')
        (self.ep.output/'consequence-trace.json').write_text(json.dumps(self.history,indent=2)+'\n')
        return r
