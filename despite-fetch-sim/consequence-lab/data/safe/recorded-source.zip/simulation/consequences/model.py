"""Label-blind threshold trigger and conservative, reduced-order spill ledger.

The threshold requests an external disturbance; it does not assert that an
object fell. Tilt/drop are observed separately. Liquid volumes in this module
are model outputs, never PhysX PBD particle measurements.
"""
from dataclasses import dataclass, asdict
import math
import numpy as np
from scipy.spatial.transform import Rotation


@dataclass(frozen=True)
class EdgeConfig:
    threshold_m: float = .03
    dwell_s: float = .25
    release_delay_s: float = .75
    gripper_clearance_m: float = .18
    force_n: float = 2.
    pulse_s: float = .10
    lever_arm_m: float = .065
    withdrawal_m: float = .80
    observe_s: float = 8.
    container_open: bool = True
    initial_liquid_ml: float = 120.
    spill_tilt_deg: float = 55.
    maximum_flow_ml_s: float = 60.
    parcel_volume_ml: float = .1
    seed: int = 41

    def __post_init__(self):
        for key, value in asdict(self).items():
            if key in ('container_open', 'seed'): continue
            if not math.isfinite(value) or value < 0: raise ValueError('Invalid '+key)
        if not isinstance(self.container_open, bool): raise ValueError('container_open must be boolean')
        if not 0 < self.spill_tilt_deg < 180: raise ValueError('Invalid spill angle')
        if min(self.pulse_s, self.parcel_volume_ml) <= 0: raise ValueError('Positive pulse and parcel size required')
        if self.initial_liquid_ml/self.parcel_volume_ml > 10000: raise ValueError('Too many liquid parcels')


class EdgeTrigger:
    def __init__(self, config):
        self.cfg = config
        self.release_time = self.since = self.trigger_time = None
        self.event = None

    def update(self, t, *, released, contact_robot, contact_support, margin_m,
               gripper_distance_m, position_xy, support_center, support_half,
               action_index, action):
        if self.event is not None: return None
        if not released or contact_robot:
            self.since = self.release_time = None
            return None
        if self.release_time is None: self.release_time = t
        eligible = (contact_support and math.isfinite(margin_m) and margin_m < self.cfg.threshold_m)
        if not eligible:
            self.since = None
            return None
        if self.since is None: self.since = t
        if (t-self.since+1e-9 < self.cfg.dwell_s or
                t-self.release_time+1e-9 < self.cfg.release_delay_s or
                gripper_distance_m < self.cfg.gripper_clearance_m): return None
        delta = np.asarray(position_xy)-support_center
        distances = np.asarray(support_half)-np.abs(delta)
        axis = int(np.argmin(distances))
        direction = np.zeros(3); direction[axis] = 1. if delta[axis] >= 0 else -1.
        force = direction*self.cfg.force_n
        torque = np.cross([0.,0.,self.cfg.lever_arm_m], force)
        self.trigger_time = t
        self.event = dict(type='edge_threshold_disturbance_requested', t=round(t,4),
                          step_index=action_index, action=action,
                          basis='declared_rule_intervention', edge_margin_m=float(margin_m),
                          threshold_m=self.cfg.threshold_m, comparison='strictly less than',
                          force_n=force.tolist(), torque_nm=torque.tolist(),
                          requested_pulse_s=self.cfg.pulse_s,
                          calibration_status='uncalibrated', reads_reference_label=False)
        return dict(self.event)


class SpillLedger:
    """Fixed-volume parcels: vessel -> ballistic flight -> support/floor deposit.

    This is a transparent reduced-order rendering model, not CFD, PBD or a
    measurement of real fluid. No emission is caused by a reference label.
    """
    def __init__(self, cfg, half_height, radius, support_center, support_half, support_top):
        self.cfg=cfg; self.n=int(round(cfg.initial_liquid_ml/cfg.parcel_volume_ml))
        self.volume_ml=cfg.initial_liquid_ml/self.n if self.n else 0.
        self.positions=np.zeros((self.n,3)); self.velocities=np.zeros((self.n,3))
        self.state=np.zeros(self.n,np.int8)  # 0 inside, 1 flying, 2 floor, 3 support
        self.credit=0.;self.emitted=0;self.initial=cfg.initial_liquid_ml
        self.half_height=half_height;self.radius=radius
        self.center=np.asarray(support_center);self.half=np.asarray(support_half);self.top=support_top
        rng=np.random.default_rng(cfg.seed)
        angle=rng.uniform(0,2*np.pi,self.n);r=radius*.65*np.sqrt(rng.uniform(0,1,self.n))
        self.local=np.column_stack([r*np.cos(angle),r*np.sin(angle),rng.uniform(-half_height*.8,half_height*.1,self.n)])
        self.nozzle_z=half_height-.012
        self.last_t=None

    def advance(self,t,position,quaternion,linear_velocity=(0,0,0),angular_velocity=(0,0,0)):
        dt=0. if self.last_t is None else t-self.last_t
        if dt < -1e-9: raise ValueError('Liquid time cannot go backwards')
        self.last_t=t
        rot=Rotation.from_quat(quaternion);position=np.asarray(position)
        upright=rot.apply([0.,0.,1.]);tilt=math.degrees(math.acos(np.clip(upright[2],-1,1)))
        old=self.positions.copy();flying=self.state==1
        self.positions[flying]+=self.velocities[flying]*dt+np.array([0,0,-4.905])*dt*dt
        self.velocities[flying,2]-=9.81*dt
        xy=self.positions[:,:2]
        table=flying&(old[:,2]>=self.top)&(self.positions[:,2]<=self.top)&np.all(np.abs(xy-self.center)<=self.half,axis=1)
        self.positions[table,2]=self.top+.0005;self.state[table]=3;self.velocities[table]=0
        floor=(self.state==1)&(self.positions[:,2]<=.001)
        self.positions[floor,2]=.0005;self.state[floor]=2;self.velocities[floor]=0
        if self.cfg.container_open and tilt>self.cfg.spill_tilt_deg and self.emitted<self.n:
            ratio=min(1.,(tilt-self.cfg.spill_tilt_deg)/35.)
            self.credit+=self.cfg.maximum_flow_ml_s*ratio*dt
            count=min(self.n-self.emitted,int((self.credit+1e-10)/self.volume_ml))
            if count:
                ids=np.arange(self.emitted,self.emitted+count)
                # Mouth jitter is deterministic and far smaller than its aperture.
                phi=ids*2.399963229728653;rr=.002*np.sqrt((ids%13+.5)/13)
                offset=rot.apply(np.column_stack([rr*np.cos(phi),rr*np.sin(phi),np.full(count,self.nozzle_z)]))
                self.positions[ids]=position+offset
                self.velocities[ids]=np.asarray(linear_velocity)+np.cross(np.asarray(angular_velocity),offset)+upright*.35
                self.state[ids]=1;self.emitted+=count;self.credit-=count*self.volume_ml
        inside=self.state==0
        self.positions[inside]=rot.apply(self.local[inside])+position
        return self.snapshot()

    def snapshot(self):
        return {'model':'reduced_order_conservative_parcels',
                'initial_ml':self.initial,'remaining_ml':(self.n-self.emitted)*self.volume_ml,
                'spilled_ml':self.emitted*self.volume_ml,
                'airborne_ml':int(np.sum(self.state==1))*self.volume_ml,
                'floor_ml':int(np.sum(self.state==2))*self.volume_ml,
                'support_ml':int(np.sum(self.state==3))*self.volume_ml,
                'container_open':self.cfg.container_open,'calibration_status':'uncalibrated'}
