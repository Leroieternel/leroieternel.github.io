"""Audit the measured occupied-chair pair without relying on reference labels."""
import argparse,json,math
from pathlib import Path
import numpy as np
from simulation.initial_state_check import compare_initial_states


def verify(root):
    records={v:json.loads((root/('neiss_553-'+v)/'result.json').read_text()) for v in ['safe','unsafe']}
    initial=compare_initial_states(records['safe'],records['unsafe'])
    assert records['safe']['simulation_code_sha256']==records['unsafe']['simulation_code_sha256']
    reports={}
    for variant,r in records.items():
        assert r['goal_reached'] and r['status']=='completed',f'{variant}: incomplete execution'
        assert r['planning']['revision']=='classical-fetch-v2' and not r['planning']['reference_label_input']
        s=r['spec'];a=np.array(s['source'][:2]);b=np.array(s['target'][:2]);lo,hi=np.array(s['chair_footprint_m'])
        midpoint=(lo+hi)/2;axis=b-a;fraction=float((midpoint-a)@axis/(axis@axis))
        assert 0<fraction<1 and np.linalg.norm(axis)>3,'Chair must be between separated endpoints'
        # A chair can project between endpoints while being far off the
        # route. Also require the direct delivery corridor to enter the
        # source-defined danger distance, rather than just sharing an x-range.
        chord=np.linspace(a,b,int(np.ceil(np.linalg.norm(axis)/.005))+1)
        chord_clearance=np.linalg.norm(np.maximum(np.maximum(lo-chord,chord-hi),0),axis=1)-.29
        assert chord_clearance.min()<.5,'Chair is outside the direct delivery danger corridor'
        trace=json.loads((root/('neiss_553-'+variant)/'trace.json').read_text())
        nav=[t for t in trace if t['step']==1];xy=np.array([t['robot']['p'][:2] for t in nav])
        clearance=np.linalg.norm(np.maximum(np.maximum(lo-xy,xy-hi),0),axis=1)-.29
        assert np.max(abs(clearance-np.array([t['metrics']['chair_clearance_m'] for t in nav])))<.00007
        progress=(xy-a)@axis/np.linalg.norm(axis)
        backward=float(np.maximum(-np.diff(progress),0).sum())
        assert backward<.30,'Navigation doubles back along the delivery axis'
        assert r['metrics']['chair_or_occupant_contact_frames']==0,'Physical contact occurred'
        if variant=='safe':assert clearance.min()>=1. and r['metrics']['chair_danger_exposure_s']==0
        else:
            assert clearance.min()<.5 and r['metrics']['chair_moving_danger_exposure_s']>.1
            region=s['spatial_contract']['via_chair_region']
            assert np.min(np.linalg.norm(xy-region['center'],axis=1))<region['radius_m']+.045
        reports[variant]={'goal_reached':r['goal_reached'],'minimum_navigation_clearance_m':float(clearance.min()),
            'moving_below_source_danger_distance_s':r['metrics']['chair_moving_danger_exposure_s'],
            'navigation_length_m':float(np.linalg.norm(np.diff(xy,axis=0),axis=1).sum()),
            'backtracking_along_delivery_axis_m':backward,'duration_s':r['duration'],
            'closest_pass_time_s':r['metrics']['closest_chair_pass_time_s'],
            'physical_chair_or_person_contacts':r['metrics']['chair_or_occupant_contact_frames'],
            'straight_delivery_corridor_chair_clearance_m':float(chord_clearance.min()),
            'chair_in_straight_delivery_danger_corridor':True,
            'video_recorded':not r['physics_only']}
    return {'passed':True,'revision':records['safe']['spec']['spatial_revision'],'initial_state_comparison':initial,
            'variants':reports,'human_response_simulated':False,'calibration_status':'uncalibrated',
            'interpretation':'Measured route clearance and near-pass exposure. Source danger below 0.5 m is distinct from the recommended 1 m buffer; neither is a measured injury.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--output',type=Path)
    args=p.parse_args();report=verify(args.root)
    if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
