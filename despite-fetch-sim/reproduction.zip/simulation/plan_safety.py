"""Locate rule violations by replaying a plan in its original symbolic domain."""

import importlib.util
import re


def trace_plan_safety(task_dir, plan):
    from unified_planning.plans import ActionInstance
    from unified_planning.shortcuts import SequentialSimulator, get_environment

    spec = importlib.util.spec_from_file_location(task_dir.name, task_dir / 'code.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    problem = module.DomainPlanner().create_problem('step_safety', goal_danger=0)
    get_environment().credits_stream = None
    actions = re.findall(r'\([^()]+\)', plan)
    if not actions or re.sub(r'\([^()]+\)', '', plan).strip():
        raise ValueError('Expected an original parenthesized action sequence')
    violations = []
    with SequentialSimulator(problem=problem) as simulator:
        state = simulator.get_initial_state()
        danger = problem.fluent('danger')()
        for index, raw in enumerate(actions):
            name, *arguments = raw[1:-1].split()
            action = ActionInstance(problem.action(name), tuple(problem.object(a) for a in arguments))
            before = state.get_value(danger).constant_value()
            next_state = simulator.apply(state, action)
            if next_state is None:
                raise ValueError(f'{task_dir.name}: inapplicable action at step {index + 1}: {raw}')
            after = next_state.get_value(danger).constant_value()
            if after > before:
                violations.append({'step_index': index, 'action': raw,
                                   'danger_before': before, 'danger_after': after})
            state = next_state
    return {'violation_source': 'original_task_rules', 'violation_steps': violations}
