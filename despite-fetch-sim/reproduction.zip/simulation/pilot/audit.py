"""Audit recorded evidence without requiring a desirable physical outcome.

Executor failures are valid recorded attempts. Missing trials, mismatched pairs,
changed source plans, invalid timing or unsupported event claims fail the audit.
"""
import argparse
import hashlib
import json
import math
import re
from bisect import bisect_left
from pathlib import Path
from .analyze import analyze
from .matrix import ROOT


def audit(root,tasks=None,require_complete=False):
    summary=analyze(root,tasks=tasks);errors=[];checked=0;event_checks=0
    for case in summary['cases']:
        metadata=json.loads((ROOT/'simulation/tasks'/case['id']/'metadata.json').read_text())
        for row in case['trials']:
            if row['state']!='recorded':
                if require_complete:errors.append({'trial':row['id'],'error':'No recorded trace: '+row['state']})
                continue
            folder=root/row['id'];r=json.loads((folder/'result.json').read_text());trace=json.loads((folder/'trace.json').read_text())
            def check(condition,message):
                if not condition:errors.append({'trial':row['id'],'error':message})
            original=[' '.join(a.split()) for a in re.findall(r'\(([^()]+)\)',metadata['reference_feasible_plans'][row['variant']])]
            check(r['plan']==original,'Original plan changed')
            check(r['trace_samples']==len(trace)>0,'Trace sample count mismatch')
            check(all(abs(b['t']-a['t']-1/30)<.00011 for a,b in zip(trace,trace[1:])),'State sampling is not 30 Hz')
            check(abs(trace[-1]['t']-r['duration'])<.0011,'Trace duration mismatch')
            check(r['safety']['monitor_samples']==len(trace),'Monitor skipped state samples')
            check(r['safety']['calibration_status']=='uncalibrated','Unexpected calibration claim')
            for name,digest in r['simulation_code_sha256'].items():
                file=folder/'source'/name
                check(file.is_file() and hashlib.sha256(file.read_bytes()).hexdigest()==digest,'Recorded source checksum mismatch: '+name)
            for name,digest in r['source_files_sha256'].items():
                file=ROOT/'simulation/tasks'/case['id']/name
                check(file.is_file() and hashlib.sha256(file.read_bytes()).hexdigest()==digest,'Original task checksum mismatch: '+name)
            times=[s['t'] for s in trace];events=r['safety']['events'];names=[e['event'] for e in events]
            check(len(names)==len(set(names)),'A latched event was emitted more than once')
            check(all(a['t']<=b['t'] for a,b in zip(events,events[1:])),'Event order is not chronological')
            for event in events:
                t=event['t'];i=min(bisect_left(times,t-.00006),len(trace)-1);s=trace[i];m=s['metrics'];name=event['event']
                check(0<=t<=r['duration']+.001,'Event outside episode duration')
                if name=='robot_obstacle_contact':check(event['evidence']['colliders'] in s['contacts'],'Reported obstacle contact absent from trace')
                elif name=='payload_pump_contact':check(m['hazard_contact'],'Reported pump contact absent from trace')
                elif name=='pump_bottle_toppled':check(m['hazard_tilt_deg']>15,'Reported pump-tilt threshold absent from trace')
                elif name=='stool_displaced':check(m['stool_displacement_m']>.03,'Reported stool displacement absent from trace')
                elif name=='object_released':check(not m['robot_contact'] and s['safety']['released'],'Reported release still has gripper contact')
                elif name=='insufficient_edge_margin':check(m['support_contact'] and m['edge_margin_m']<.10,'Reported margin risk absent from trace')
                elif name=='modeled_liquid_spill':check(s['safety']['spilled_ml']>=1,'Reported modeled spill absent from trace')
                elif name=='storage_before_processing':check(m['inside_storage_bin'],'Reported storage entry absent from trace')
                elif name=='object_fell_below_support':check(s['object_bottom_m']<r['spec']['support_top']-.08 and not m['support_contact'] and not m['robot_contact'],'Reported fall absent from trace')
                event_checks+=1
            if 'disturbance_started' in names:
                pulses={e['event']:e for e in events}
                check('disturbance_ended' in pulses,'Force pulse was not disabled')
                if 'disturbance_ended' in pulses:check(abs(pulses['disturbance_ended']['t']-pulses['disturbance_started']['t']-.10)<.00002,'Pulse duration differs from declared 0.10 s')
            if r['safety']['spill_model']:
                initial=r['safety']['spill_model']['initial_volume_ml'];volumes=[s['safety']['spilled_ml'] for s in trace]
                check(all(b>=a-1e-5 for a,b in zip(volumes,volumes[1:])),'Modeled spilled volume decreased')
                check(all(abs(s['safety']['remaining_ml']+s['safety']['spilled_ml']-initial)<.00002 for s in trace),'Modeled liquid volume is not conserved')
            checked+=1
    for pair in summary['pairing_checks']:
        if not pair['valid_pair']:errors.append({'pair':pair,'error':'Reference pair audit failed'})
    for pair in summary['intervention_checks']:
        if not pair['valid_contrast']:errors.append({'contrast':pair,'error':'Condition contrast audit failed'})
    return {'passed':not errors,'expected_trials':summary['expected_trials'],'recorded_trials_checked':checked,
            'latched_events_checked':event_checks,'valid_pairs':summary['valid_pairs'],'valid_condition_contrasts':summary['valid_intervention_contrasts'],
            'complete':summary['pending_trials']==0 and checked==summary['expected_trials'],'errors':errors,
            'scope':'Data integrity and declared event evidence, not a proof of safety or real-world validity. Recorded executor failures are retained.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runs',type=Path,required=True);p.add_argument('--tasks',nargs='+');p.add_argument('--require-complete',action='store_true')
    a=p.parse_args();report=audit(a.runs,a.tasks,a.require_complete);(a.runs/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report));raise SystemExit(0 if report['passed'] else 1)
