"""Compare supplied real measurements with matching simulator observations.

This is a validation interface. It never invents measurements, fits on test
outcomes, or changes the simulator's parameters behind the evaluator's back.
"""
import argparse
import json
import math
from pathlib import Path

QUANTITIES={
    'object_mass_kg':('kg',('physical_parameters','object_mass_kg')),
    'edge_margin_m':('m',('metrics','edge_margin_m')),
    'object_tilt_deg':('deg',('metrics','object_tilt_deg')),
    'spilled_ml':('ml',('safety','measurements','spilled_ml')),
    'duration_s':('s',('duration',)),
}


def compare(root,measurements=None):
    if measurements is None:
        return {'status':'awaiting_real_measurements','calibrated':False,'comparisons':[],
                'note':'No real-world observations supplied; simulator parameters remain pilot assumptions.'}
    rows=json.loads(Path(measurements).read_text());out=[]
    for row in rows:
        required={'trial','quantity','value','unit','measurement_source','measured_at','instrument'}
        if required-row.keys():raise ValueError('Missing measurement metadata: '+str(required-row.keys()))
        if row['quantity'] not in QUANTITIES:raise ValueError('Unsupported quantity')
        unit,keys=QUANTITIES[row['quantity']]
        if row['unit']!=unit:raise ValueError('Unit mismatch')
        value=float(row['value'])
        if not math.isfinite(value):raise ValueError('Non-finite measurement')
        path=(root/row['trial']/'result.json').resolve()
        if not path.is_relative_to(root.resolve()):raise ValueError('Trial outside run root')
        simulated=json.loads(path.read_text())
        for key in keys:simulated=simulated[key]
        if simulated is None or not math.isfinite(float(simulated)):raise ValueError('No matching simulation measurement')
        out.append({**row,'simulation_value':simulated,'signed_error':simulated-value,'absolute_error':abs(simulated-value)})
    return {'status':'observations_compared' if out else 'awaiting_real_measurements','calibrated':False,'comparisons':out,
            'note':'Held-out validation comparisons only. No parameter fit or real-world transfer claim has been made.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runs',type=Path,required=True);p.add_argument('--measurements',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.write_text(json.dumps(compare(a.runs,a.measurements),indent=2)+'\n')
