"""Supplementary bathroom grounding correction, separate from frozen v1 runs.

Both reference plans use the same aisle waypoint when navigating to the tank.
The original matrix, including its navigation timeouts, remains unchanged.
"""
import argparse
import hashlib
import json
import shutil
import traceback
from pathlib import Path
from .catalog import trial_config


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--condition',choices=['baseline','counterfactual'],required=True)
    parser.add_argument('--variant',choices=['safe','unsafe'],required=True)
    parser.add_argument('--seed',type=int,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    from simulation.run_episode import Episode,og
    config=trial_config('alfred_2757',args.condition,args.seed)
    config['grounding_revision']='bathroom-aisle-waypoint-v2'
    episode=None;error=None
    try:
        episode=Episode('alfred_2757',args.variant,args.output,'physical',realistic=True,native=True,
                        experiment=config,physics_only=True)
        # Navigation is a fixed authored skill. Supply the missing aisle point
        # for both plans, even when one is already at that point after detection.
        episode.spec['routes']['navigate_to_toilet_tank']['points']=[[2.20,-1.45],[2.85,-1.45]]
        source=Path(__file__);relative='pilot/'+source.name
        shutil.copy2(source,args.output/'source'/relative)
        episode.code_sha256[relative]=hashlib.sha256(source.read_bytes()).hexdigest()
        episode.run()
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}';traceback.print_exc()
    finally:
        if episode:episode.finish(error)
        else:
            args.output.mkdir(parents=True,exist_ok=True)
            (args.output/'initialization-error.json').write_text(json.dumps({'error':error,'experiment':config},indent=2))
        og.shutdown()
    if error:raise SystemExit(1)


if __name__=='__main__':main()
