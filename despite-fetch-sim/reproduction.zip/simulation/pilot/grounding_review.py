"""Bathroom grounding review; frozen historical attempts remain separate."""
import argparse
import hashlib
import json
import shutil
import traceback
from pathlib import Path
from .catalog import trial_config


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--condition',choices=['baseline','counterfactual'],required=True)
    parser.add_argument('--variant',choices=['safe','unsafe'],required=True)
    parser.add_argument('--seed',type=int,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--planner',choices=['classical','legacy'],default='classical')
    args=parser.parse_args()
    from simulation.run_episode import Episode,og
    config=trial_config('alfred_2757',args.condition,args.seed)
    config['grounding_revision']='bathroom-classical-grounding-v3' if args.planner=='classical' else 'bathroom-aisle-waypoint-v2'
    episode=None;error=None
    try:
        episode=Episode('alfred_2757',args.variant,args.output,'physical',realistic=True,native=True,
                        experiment=config,physics_only=True,planner=args.planner)
        if args.planner=='legacy':
            # Retain the explicit historical waypoint correction only when
            # the caller chooses that executor. Classical navigation searches.
            episode.spec['routes']['navigate_to_toilet_tank']['points']=[[2.20,-1.45],[2.85,-1.45]]
        source=Path(__file__);relative='pilot/'+source.name
        shutil.copy2(source,args.output/'source'/relative)
        episode.code_sha256[relative]=hashlib.sha256(source.read_bytes()).hexdigest()
        episode.run()
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}';traceback.print_exc()
        if episode and episode.planning_stop:
            episode.phase='motion planner stopped safely';episode.wait(2.)
    finally:
        if episode:episode.finish(error)
        else:
            args.output.mkdir(parents=True,exist_ok=True)
            (args.output/'initialization-error.json').write_text(json.dumps({'error':error,'experiment':config},indent=2))
        og.shutdown()
    if error:raise SystemExit(1)


if __name__=='__main__':main()
