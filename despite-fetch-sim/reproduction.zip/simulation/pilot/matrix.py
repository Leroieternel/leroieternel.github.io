"""Resumable GPU matrix. Failed attempts remain in the evidence ledger."""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor,as_completed
from .catalog import SOURCE_IDS,SEEDS,CONDITIONS,trial_config

ROOT=Path(__file__).resolve().parents[2]


def matrix(tasks=SOURCE_IDS,seeds=SEEDS):
    return [dict(task=task,condition=condition,seed=seed,variant=variant)
            for seed,task,condition,variant in itertools.product(seeds,tasks,CONDITIONS,('safe','unsafe'))]


def run_id(row):
    return f"{row['task']}/{row['condition']}/seed-{row['seed']}/{row['variant']}"


def code_digest():
    paths=[ROOT/'simulation/pilot'/n for n in ('catalog.py','monitor.py','interventions.py','run.py')]
    paths.extend(ROOT/'simulation'/n for n in ('run_episode.py','pair_cases.py','scene_cases.py','genie_scene.py','runtime.py'))
    h=hashlib.sha256()
    for path in sorted(paths):h.update(str(path.relative_to(ROOT)).encode());h.update(path.read_bytes())
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'simulation/runs/mechanism-pilot/reference')
    p.add_argument('--tasks',nargs='+',default=list(SOURCE_IDS),choices=SOURCE_IDS)
    p.add_argument('--seeds',nargs='+',type=int,default=list(SEEDS))
    p.add_argument('--video',action='store_true',help='Record every attempt with the verified 30 fps capture profile')
    p.add_argument('--timeout',type=int,default=1800)
    p.add_argument('--workers',type=int,default=1,choices=[1,2,3,4])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    digest=code_digest();rows=matrix(a.tasks,a.seeds)
    schedule={'code_sha256':digest,'design':'source × reference plan × condition × seed','trials':rows,'expected_trials':len(rows),'scheduler_workers':a.workers}
    (a.output/'schedule.json').write_text(json.dumps(schedule,indent=2))
    def execute(row):
        target=a.output/run_id(row);result=target/'result.json';stamp=target/'attempt.json'
        if result.exists() and stamp.exists() and json.loads(stamp.read_text()).get('code_sha256')==digest:
            return dict(**row,state='resumed',path=run_id(row))
        if target.exists() and (result.exists() or stamp.exists()):
            # Never silently replace a failed/old attempt. Preserve its full log.
            target.rename(target.with_name(target.name+'-archived-'+str(time.time_ns())))
        target.mkdir(parents=True,exist_ok=True)
        started=time.time();stamp.write_text(json.dumps({'code_sha256':digest,'started_unix_s':started,'trial':row,'scheduler_workers':a.workers},indent=2))
        cmd=[str(ROOT/'.runtime/isaac601/bin/python'),'-m','simulation.pilot.run',
             '--task',row['task'],'--condition',row['condition'],'--seed',str(row['seed']),
             '--variant',row['variant'],'--output',str(target)]
        if a.video:cmd.append('--video')
        try:
            with (target/'execution.log').open('w') as log:
                r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=a.timeout,env={**os.environ,'PYTHONUNBUFFERED':'1'})
            status='recorded' if result.exists() else 'initialization_failed'
            entry=dict(**row,state=status,path=run_id(row),returncode=r.returncode,wall_seconds=round(time.time()-started,2))
        except subprocess.TimeoutExpired:
            entry=dict(**row,state='timeout',path=run_id(row),wall_seconds=round(time.time()-started,2))
        return entry
    ledger=[]
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        futures=[pool.submit(execute,row) for row in rows]
        for future in as_completed(futures):
            entry=future.result();ledger.append(entry)
            (a.output/'ledger.json').write_text(json.dumps(ledger,indent=2))
            print(json.dumps(entry),flush=True)
    (a.output/'ledger.json').write_text(json.dumps(ledger,indent=2))


if __name__=='__main__':main()
