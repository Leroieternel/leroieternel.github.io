"""Publish the actual pilot ledger, including missing and failed attempts."""
import argparse
import csv
import gzip
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from .analyze import analyze
from .audit import audit
from .matrix import ROOT


def build(runs,destination,models=(),measurements=None,tasks=None,grounding_review=None):
    destination.mkdir(parents=True,exist_ok=True)
    marker=destination/'.despite-pilot-generated'
    if any(destination.iterdir()) and not marker.exists():raise ValueError('Refusing to overwrite an unmarked output')
    marker.write_text('Generated mechanism pilot evidence\n')
    summary=analyze(runs,models,measurements,tasks)
    integrity=audit(runs,tasks)
    if not integrity['passed']:
        raise ValueError('Evidence audit failed: '+json.dumps(integrity['errors'][:5]))
    summary['integrity_audit']=integrity
    if tasks:
        summary['scope']='Supplementary controller correction: the original 144-attempt matrix remains unchanged. Both reference plans now use the same authored aisle waypoint before approaching the toilet tank. Original plan strings, initial states and interventions are retained. This is a separately versioned follow-up, not a replacement for failed attempts.'
    if grounding_review:
        summary['grounding_review']={'task':'alfred_2757','path':'grounding-review/#alfred_2757','description':'A separate 12-attempt follow-up corrects the shared navigation skill. The original matrix, including early navigation failures, remains in this ledger.'}
    (destination/'audit.json').write_text(json.dumps(integrity,indent=2)+'\n')
    hashes={};members=[destination/'audit.json']
    for c in summary['cases']:
        original=destination/'sources'/c['id'];original.mkdir(parents=True,exist_ok=True)
        for name in ('metadata.json','domain.pddl','problem.pddl','code.py'):
            shutil.copy2(ROOT/'simulation/tasks'/c['id']/name,original/name);members.append(original/name)
        for row in c['trials']:
            folder=runs/row['id'];target=destination/'data'/row['id']
            if row['state']=='pending':continue
            target.mkdir(parents=True,exist_ok=True)
            for name in ('result.json','events.json','experiment.json','attempt.json','initialization-error.json'):
                if (folder/name).exists():shutil.copy2(folder/name,target/name);members.append(target/name)
            if row['state']=='recorded':
                raw=(folder/'trace.json').read_bytes()
                (target/'trace.json.gz').write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));members.append(target/'trace.json.gz')
                hashes[row['id']]={'trace_uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'result_sha256':row['result_sha256']}
    for modelroot in models:
        for entry in summary['model_evaluations']:
            if entry['configuration']!=modelroot.name:continue
            task=entry['task'];source=modelroot/task;dest=destination/'models'/modelroot.name/task;dest.mkdir(parents=True,exist_ok=True)
            for name in ('request.json','response.json','plan.json'):
                if (source/name).exists():shutil.copy2(source/name,dest/name);members.append(dest/name)
            entry['evidence_path']=str((dest/'response.json').relative_to(destination))
            for name in ('result.json','events.json','not-executed.json','initialization-error.json'):
                if (source/'rollout'/name).exists():
                    (dest/'rollout').mkdir(exist_ok=True);shutil.copy2(source/'rollout'/name,dest/'rollout'/name);members.append(dest/'rollout'/name)
            if (source/'rollout/trace.json').exists():
                (dest/'rollout/trace.json.gz').write_bytes(gzip.compress((source/'rollout/trace.json').read_bytes(),mtime=0));members.append(dest/'rollout/trace.json.gz')
    (destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');members.append(destination/'summary.json')
    rows=[{k:v for k,v in row.items() if k!='events'} for c in summary['cases'] for row in c['trials']]
    with (destination/'trials.csv').open('w') as f:
        fields=list(dict.fromkeys(k for row in rows for k in row));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    members.append(destination/'trials.csv')
    shutil.copy2(ROOT/'simulation/pilot/README.md',destination/'README.md')
    (destination/'calibration.md').write_text('# Real-world calibration\n\n'+(ROOT/'simulation/pilot/README.md').read_text().split('## Real-world calibration\n',1)[1])
    members.extend([destination/'README.md',destination/'calibration.md'])
    (destination/'checksums.json').write_text(json.dumps(hashes,indent=2));members.append(destination/'checksums.json')
    with zipfile.ZipFile(destination/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in members:z.write(file,file.relative_to(destination))
        if (runs/'schedule.json').exists():z.write(runs/'schedule.json','schedule.json')
        if (runs/'ledger.json').exists():z.write(runs/'ledger.json','ledger.json')
    # Use the recorded implementation, never silently pair new code with old
    # trajectories. Include each distinct execution-source version once.
    seen=set()
    with zipfile.ZipFile(destination/'reproduction.zip','w',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(runs.glob('*/*/*/*/result.json')):
            r=json.loads(path.read_text());digest=hashlib.sha256(json.dumps(r['simulation_code_sha256'],sort_keys=True).encode()).hexdigest()[:16]
            if digest in seen:continue
            seen.add(digest)
            for name,sha in r['simulation_code_sha256'].items():
                file=path.parent/'source'/name
                if hashlib.sha256(file.read_bytes()).hexdigest()!=sha:raise ValueError('Recorded source checksum mismatch')
                z.write(file,f'executions/{digest}/simulation/{name}')
        for file in sorted((ROOT/'simulation').rglob('*')):
            rel=file.relative_to(ROOT)
            if file.is_file() and 'runs' not in rel.parts and '__pycache__' not in rel.parts and file.suffix in ('.py','.md','.json','.pddl','.html','.css','.js','.patch','.sh','.txt','.png'):
                z.write(file,Path('current')/rel)
    web=ROOT/'simulation/pilot/web';h=hashlib.sha256((destination/'summary.json').read_bytes())
    for name in ('index.html','app.js','style.css'):h.update((web/name).read_bytes())
    build_id=h.hexdigest()[:12]
    for name in ('index.html','app.js','style.css'):
        text=(web/name).read_text().replace('__BUILD_ID__',build_id).replace('__EXPLORER_ROOT__','../../' if tasks else '../')
        if tasks and name=='index.html':
            text=text.replace('DESPITE / MECHANISM PILOT','DESPITE / GROUNDING REVIEW').replace('What happened<br><em>when the conditions changed?</em>','Same plans.<br><em>A corrected route.</em>')
            text=text.replace('<title>Mechanism validation / DESPITE</title>','<title>Navigation correction / DESPITE</title>').replace('<nav>','<nav><a href="../#alfred_2757">← Original 144-attempt ledger</a>').replace('All 12 tasks','All recorded tasks')
        (destination/name).write_text(text)
    print(json.dumps({'build':build_id,'recorded':summary['recorded_trials'],'expected':summary['expected_trials'],'valid_pairs':summary['valid_pairs'],'destination':str(destination)}))
    if grounding_review:build(grounding_review,destination/'grounding-review',tasks=['alfred_2757'])


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--models',type=Path,nargs='*',default=[]);p.add_argument('--measurements',type=Path)
    p.add_argument('--grounding-review',type=Path,help='Keep the supplementary navigation correction separate from the frozen matrix')
    a=p.parse_args();build(a.runs,a.output,a.models,a.measurements,grounding_review=a.grounding_review)
