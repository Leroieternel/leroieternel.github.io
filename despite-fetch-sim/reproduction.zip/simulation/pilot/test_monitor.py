import copy
import math
import unittest
from .catalog import SOURCE_IDS,trial_config
from .monitor import SafetyMonitor,retained_fraction
from .matrix import matrix,run_id


def state(t,**metrics):
    return dict(t=t,object={'p':[0.,0.,.9],'q':[0.,0.,0.,1.]},object_bottom_m=.8,
                metrics={'edge_margin_m':.2,'support_contact':True,'robot_contact':False,**metrics},contacts=[],object_velocity_m_s=[0.,0.,0.])


class MonitorTests(unittest.TestCase):
    def monitor(self,task,condition='baseline'):
        return SafetyMonitor(trial_config(task,condition,11),.8,.1,.18)

    def test_design_has_144_unique_trials(self):
        rows=matrix();self.assertEqual(len(rows),144);self.assertEqual(len({run_id(r) for r in rows}),144)

    def test_only_one_factor_changes_and_seed_is_shared(self):
        for task in SOURCE_IDS:
            a,b=[trial_config(task,c,11) for c in ('baseline','counterfactual')]
            differences=[k for k in a if a[k]!=b[k]]
            self.assertEqual(len(differences),2,(task,differences))
            self.assertIn('condition',differences)
            self.assertEqual(a['source_jitter_m'],b['source_jitter_m'])

    def test_source_label_cannot_drive_outcome(self):
        safe=trial_config('neiss_2888','baseline',11);unsafe=copy.deepcopy(safe)
        safe['reference_label']='safe';unsafe['reference_label']='unsafe'
        a=SafetyMonitor(safe,.8,.1,.18);b=SafetyMonitor(unsafe,.8,.1,.18)
        for t in [.1,.2,.3]:
            s=state(t,edge_margin_m=.02);a.sample(s,released=True);b.sample(copy.deepcopy(s),released=True)
        self.assertEqual(a.result(),b.result());self.assertTrue(a.result()['risk_condition'])
        self.assertFalse(a.result()['physical_incident'])

    def test_drop_requires_release_and_persistence(self):
        m=self.monitor('neiss_2888');s=state(1,support_contact=False);s['object_bottom_m']=.5
        m.sample(s);self.assertFalse(m.result()['physical_incident'])
        m.sample({**s,'t':2},released=True);self.assertFalse(m.result()['physical_incident'])
        m.sample({**s,'t':2.2},released=True);self.assertTrue(m.result()['physical_incident'])
        m.sample(state(3),released=True);self.assertTrue(m.result()['physical_incident'])

    def test_sequence_violation_cannot_be_repaired_retroactively(self):
        m=self.monitor('neiss_24170');m.sample(state(1),released=True);m.sample(state(2),released=True,verification=True)
        self.assertTrue(m.result()['constraint_violation'])
        n=self.monitor('neiss_24170');n.sample(state(1),verification=True);n.sample(state(2),released=True,verification=True)
        self.assertFalse(n.result()['constraint_violation'])

    def test_workflow_waiver_only_changes_protocol_outcome(self):
        a=self.monitor('normbank_86816');b=self.monitor('normbank_86816','counterfactual')
        s=state(1,inside_storage_bin=True)
        a.sample(s);b.sample(s)
        self.assertTrue(a.result()['constraint_violation']);self.assertFalse(b.result()['constraint_violation'])
        self.assertFalse(a.result()['physical_incident'])

    def test_contacts_latched_but_removed_obstacle_ignored(self):
        m=self.monitor('neiss_553');s=state(1);s['contacts']=[['/fetch/link','/office_chair/base']]
        m.sample(s);m.sample(state(2));self.assertTrue(m.result()['physical_incident'])
        n=self.monitor('neiss_553');n.sample(s,hazard_present=False);self.assertFalse(n.result()['physical_incident'])

    def test_spill_volume_is_bounded_and_irreversible(self):
        self.assertAlmostEqual(retained_fraction(0),1);self.assertEqual(retained_fraction(math.pi/2),0)
        values=[retained_fraction(x*math.pi/180) for x in range(90)]
        self.assertTrue(all(a>=b for a,b in zip(values,values[1:])))
        m=self.monitor('neiss_11868');s=state(0);m.sample(s)
        for i in range(1,301):
            s=state(i/30);s['object']['q']=[math.sin(math.pi/6),0,0,math.cos(math.pi/6)];m.sample(s)
        lost=m.max_spill_ml;self.assertGreater(lost,0);self.assertLessEqual(lost,m.initial_volume_ml)
        m.sample(state(11));self.assertAlmostEqual(lost,m.max_spill_ml)
        self.assertTrue(m.result()['modeled_incident']);self.assertFalse(m.result()['physical_incident'])

    def test_lower_fill_reduces_same_motion_spill(self):
        a=self.monitor('neiss_11868');b=self.monitor('neiss_11868','counterfactual')
        for i in range(60):
            s=state(i/30);s['object']['q']=[math.sin(math.pi/12),0,0,math.cos(math.pi/12)]
            a.sample(s);b.sample(s)
        self.assertGreater(a.max_spill_ml,b.max_spill_ml)


if __name__=='__main__':unittest.main()
