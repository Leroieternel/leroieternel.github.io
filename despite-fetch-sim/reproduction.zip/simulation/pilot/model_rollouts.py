"""Execute valid model plans as supplied, without repairing or replacing them."""
import argparse
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path
from .catalog import CASES

ROOT=Path(__file__).resolve().parents[2]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--models',type=Path,required=True)
    p.add_argument('--planner',choices=['classical','legacy'],default='classical');a=p.parse_args()
    for task in CASES:
        folder=a.models/task;r=json.loads((folder/'response.json').read_text());out=folder/'rollout';out.mkdir(exist_ok=True)
        if (out/'result.json').exists():
            old=json.loads((out/'result.json').read_text())
            hashes=old.get('simulation_code_sha256',{})
            current=(bool(hashes) and old.get('motion_backend','legacy')==a.planner and
                     old.get('plan')==r.get('actions') and
                     all((ROOT/'simulation'/name).is_file() and
                         hashlib.sha256((ROOT/'simulation'/name).read_bytes()).hexdigest()==digest
                         for name,digest in hashes.items()))
            if a.planner=='classical':
                from simulation.planning.grounding import REVISION
                current=current and old.get('planning',{}).get('revision')==REVISION
            if current:continue
            # Keep historical model evidence; a different executor is a new run.
            out.rename(out.with_name(out.name+'-archived-'+str(time.time_ns())))
            out.mkdir()
        if (out/'not-executed.json').exists():continue
        reason=None
        if r['parse_status']!='valid':reason='No valid grounded plan was returned.'
        elif r.get('semantic',{}).get('score',0)<1:reason='Original semantic validator did not find a feasible plan.'
        else:
            original=json.loads((ROOT/'simulation/tasks'/task/'metadata.json').read_text())
            allowed=set(x for text in original['reference_feasible_plans'].values() for x in re.findall(r'\(([^()]+)\)',text))
            missing=set(r['actions'])-allowed
            if missing:reason='No verified physical skill binding for '+str(sorted(missing))
        if reason:
            (out/'not-executed.json').write_text(json.dumps({'reason':reason,'plan_replaced':False,'plan_source':'model output'},indent=2));continue
        cmd=[str(ROOT/'.runtime/isaac601/bin/python'),'-m','simulation.pilot.run','--task',task,'--variant','safe','--condition','baseline','--seed','11','--plan-file',str(folder/'plan.json'),'--output',str(out)]
        cmd+=['--planner',a.planner]
        # --variant only selects an existing metadata key in the runner. The
        # result's plan_source is model output; no reference plan is executed.
        with (out/'execution.log').open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
        print(task,'recorded' if (out/'result.json').exists() else 'failed',flush=True)


if __name__=='__main__':main()
