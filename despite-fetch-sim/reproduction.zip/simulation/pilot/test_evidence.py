import json
from pathlib import Path
import tempfile
import unittest
from .analyze import state_match,analyze
from .calibration import compare
from .model_eval import parse_plan,prompt_for


class EvidenceTests(unittest.TestCase):
    def test_missing_runs_remain_pending(self):
        with tempfile.TemporaryDirectory() as d:
            s=analyze(Path(d));self.assertEqual(s['expected_trials'],144)
            self.assertEqual(s['recorded_trials'],0);self.assertEqual(s['pending_trials'],144)
            self.assertFalse(s['calibration']['calibrated'])

    def test_pairing_handles_quaternion_sign_and_rejects_displacement(self):
        a={'robot':{'p':[0,0,0],'q':[0,0,0,1]}};b={'robot':{'p':[0,0,0],'q':[0,0,0,-1]}}
        self.assertTrue(state_match(a,b)['matched']);b['robot']['p'][0]=.01
        self.assertFalse(state_match(a,b)['matched'])

    def test_timeout_is_not_counted_as_pending_or_safe(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'ledger.json').write_text(json.dumps([{'task':'neiss_2888','condition':'baseline','seed':11,'variant':'safe','state':'timeout'}]))
            s=analyze(root);self.assertEqual(s['pending_trials'],143);self.assertEqual(s['timeouts'],1)
            row=s['cases'][0]['trials'][0];self.assertIsNone(row['monitored_safe_completion'])

    def test_model_parser_never_repairs_an_empty_or_malformed_plan(self):
        self.assertEqual(parse_plan('{"plan":"(grab_water_bottle) (place_object storage_area)"}')[1],['grab_water_bottle','place_object storage_area'])
        for raw in ['{"plan":""}','{"plan":"(grab) some explanation"}','{"plan":"(a(b))"}']:
            with self.assertRaises(ValueError):parse_plan(raw)

    def test_model_prompt_omits_reference_answers_and_metadata_solutions(self):
        s=prompt_for('neiss_2888');self.assertNotIn('reference_feasible_plans',s)
        self.assertNotIn('instantaneous_solution',s);self.assertIn('DOMAIN:',s);self.assertIn('PROBLEM:',s)

    def test_comparison_does_not_claim_calibration_and_checks_units(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'trial').mkdir();(root/'trial/result.json').write_text('{"duration":10}')
            row={'trial':'trial','quantity':'duration_s','unit':'s','value':9,'measurement_source':'synthetic UNIT TEST ONLY', 'measured_at':'test','instrument':'test fixture'}
            m=root/'test-measurements.json';m.write_text(json.dumps([row]))
            r=compare(root,m);self.assertFalse(r['calibrated']);self.assertEqual(r['comparisons'][0]['absolute_error'],1)
            row['unit']='ms';m.write_text(json.dumps([row]))
            with self.assertRaises(ValueError):compare(root,m)


if __name__=='__main__':unittest.main()
