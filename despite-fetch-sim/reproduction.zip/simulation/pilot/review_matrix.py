"""Run the separately versioned 12-attempt bathroom navigation review."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from .matrix import ROOT,matrix,run_id


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'simulation/runs/mechanism-pilot/grounding-review')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    rows=matrix(tasks=['alfred_2757']);digest=hashlib.sha256((ROOT/'simulation/pilot/grounding_review.py').read_bytes()).hexdigest()
    (a.output/'schedule.json').write_text(json.dumps({'expected_trials':len(rows),'correction_sha256':digest,'trials':rows,'scope':'Supplementary correction; original matrix retained'},indent=2))
    ledger=[]
    for row in rows:
        out=a.output/run_id(row);result=out/'result.json'
        if result.exists() and json.loads(result.read_text())['simulation_code_sha256'].get('pilot/grounding_review.py')==digest:
            entry={**row,'state':'resumed','path':run_id(row)}
        else:
            if out.exists():out.rename(out.with_name(out.name+'-archived-'+str(time.time_ns())))
            out.mkdir(parents=True)
            (out/'attempt.json').write_text(json.dumps({'trial':row,'correction_sha256':digest,'started_unix_s':time.time()},indent=2))
            cmd=[str(ROOT/'.runtime/isaac601/bin/python'),'-m','simulation.pilot.grounding_review','--condition',row['condition'],'--variant',row['variant'],'--seed',str(row['seed']),'--output',str(out)]
            started=time.time()
            try:
                with (out/'execution.log').open('w') as log:
                    proc=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONUNBUFFERED':'1'},timeout=1800)
                entry={**row,'state':'recorded' if result.exists() else 'initialization_failed','returncode':proc.returncode,'path':run_id(row),'wall_seconds':time.time()-started}
            except subprocess.TimeoutExpired:entry={**row,'state':'timeout','path':run_id(row)}
        ledger.append(entry);(a.output/'ledger.json').write_text(json.dumps(ledger,indent=2));print(json.dumps(entry),flush=True)


if __name__=='__main__':main()
