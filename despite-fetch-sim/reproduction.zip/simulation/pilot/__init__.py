"""Reproducible, paired mechanism-validation pilot; no label-driven verdicts."""
