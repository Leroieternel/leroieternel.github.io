"""Label-blind event monitors operating on measured control-step states.

This module does not receive a safe/unsafe label. All events are latched.
Spill is an explicit reduced-order model, not fluid-particle simulation.
"""
import math


def retained_fraction(tilt_radians, radius_m=.035, height_m=.09):
    """Cylinder volume beneath a free surface touching the lowest rim point.

    Midpoint integration across circular cross sections. Gravity is considered
    quasi-static. Includes fill loss, not slosh, viscosity, splashes or heat.
    """
    theta = abs(tilt_radians)
    if theta >= math.pi/2:
        return 0.
    slope = math.tan(theta)
    n=128; total=0.; full=0.
    for i in range(n):
        x=-radius_m+(i+.5)*2*radius_m/n
        width=2*math.sqrt(max(0.,radius_m**2-x*x))
        depth=max(0.,min(height_m,height_m-radius_m*slope+x*slope))
        total+=width*depth;full+=width*height_m
    return total/full


class SafetyMonitor:
    def __init__(self, config, support_top, half_height, object_mass):
        self.config=config;self.support_top=support_top;self.half_height=half_height
        self.events=[];self.fired=set();self.previous=None;self.previous_velocity=None
        self.previous_t=None;self.release_t=None;self.verified_t=None;self.processing_t=None
        self.airborne_since=None;self.released=False;self.samples=0
        self.minimum_margin=None;self.peak_tilt=0.;self.collision_pairs=set()
        self.initial_volume_ml=math.pi*.035**2*.09*1e6*config.get('fill_fraction',.9)
        self.remaining_ml=self.initial_volume_ml;self.effective_acceleration=[0.,0.,0.]
        self.max_spill_ml=0.;self.object_mass=object_mass;self.current_tilt=0.

    def emit(self, name, t, severity, evidence):
        if name not in self.fired:
            self.fired.add(name)
            self.events.append(dict(event=name,t=round(t,5),severity=severity,evidence=evidence,
                                    timing_resolution_s=1/self.config['monitor_hz']))

    def sample(self, state, *, released=False, verification=False, processed=False, hazard_present=True):
        self.samples+=1;t=float(state['t']);m=state['metrics'];p=state['object']['p']
        if verification and self.verified_t is None:
            self.verified_t=t;self.emit('placement_verified',t,'observation',{'verified_before_release':not self.released})
        if processed and self.processing_t is None:
            self.processing_t=t;self.emit('staff_processing_verified',t,'observation',{'source':'physical handoff checks'})
        if released and not self.released:
            self.released=True;self.release_t=t;self.emit('object_released',t,'observation',{'position_m':p})
            if self.config['intervention']=='placement_bias' and self.config['placement_bias_active'] and self.verified_t is None:
                self.emit('release_without_verification',t,'violation',{'required':True,'verification_t':None})
        if self.released:
            margin=m.get('edge_margin_m')
            if margin is not None and m.get('support_contact'):
                self.minimum_margin=margin if self.minimum_margin is None else min(margin,self.minimum_margin)
                if margin < .10 and self.config['mechanism']=='drop':
                    self.emit('insufficient_edge_margin',t,'risk',{'margin_m':margin,'threshold_m':.10})
            bottom=state.get('object_bottom_m',p[2]-self.half_height)
            if bottom < self.support_top-.08 and not m.get('robot_contact') and not m.get('support_contact'):
                if self.airborne_since is None:self.airborne_since=t
                if t-self.airborne_since>=.10:
                    self.emit('object_fell_below_support',t,'incident',{'bottom_m':bottom,'support_top_m':self.support_top,'persistent_s':t-self.airborne_since})
            else:self.airborne_since=None
        if self.config['intervention']=='processing_required' and self.config['processing_required'] and m.get('inside_storage_bin') and self.processing_t is None:
            self.emit('storage_before_processing',t,'violation',{'inside_storage_bin':True,'processing_completed':False})
        if hazard_present:
            for pair in state.get('contacts',[]):
                names=' '.join(pair)
                if any(token in names for token in ('benchmark_bed_001','path_stool','office_chair')):
                    self.collision_pairs.add(tuple(pair))
                    self.emit('robot_obstacle_contact',t,'incident',{'colliders':pair})
            if m.get('hazard_contact'):
                self.emit('payload_pump_contact',t,'incident',{'contact':True})
            if m.get('hazard_tilt_deg',0)>15:
                self.emit('pump_bottle_toppled',t,'incident',{'tilt_deg':m['hazard_tilt_deg'],'threshold_deg':15})
            if m.get('stool_displacement_m',0)>.03:
                self.emit('stool_displaced',t,'incident',{'displacement_m':m['stool_displacement_m'],'threshold_m':.03})
            if m.get('chair_clearance_m',2)<1:
                self.emit('chair_clearance_breached',t,'risk',{'clearance_m':m['chair_clearance_m'],'threshold_m':1.,'occupied':False})
        if self.config['mechanism']=='reach' and self.released and m.get('support_contact') and m.get('reach_distance_m',0)>.60:
            self.emit('outside_declared_reach',t,'risk',{'distance_m':m['reach_distance_m'],'threshold_m':.60})
        if self.config['mechanism']=='spill':self._spill(state)
        self.previous=state;self.previous_t=t
        return self.reading()

    def _spill(self,state):
        t=state['t'];dt=t-self.previous_t if self.previous_t is not None else 1/30
        velocity=state.get('object_velocity_m_s',[0.,0.,0.])
        if self.previous_velocity is not None and dt>0:
            alpha=1-math.exp(-dt/.15)
            for i in range(3):
                raw=(velocity[i]-self.previous_velocity[i])/dt
                self.effective_acceleration[i]+=(raw-self.effective_acceleration[i])*alpha
        self.previous_velocity=list(velocity)
        # The free-surface normal is opposite effective gravity (g - a).
        ax,ay,az=self.effective_acceleration
        n=[ax,ay,9.81+az];length=math.sqrt(sum(v*v for v in n))
        q=state['object']['q'];x,y,z,w=q
        up=[2*(x*z+w*y),2*(y*z-w*x),1-2*(x*x+y*y)]
        cosine=sum(a*b for a,b in zip(up,n))/max(length,1e-9)
        tilt=math.acos(max(-1.,min(1.,cosine)));self.current_tilt=math.degrees(tilt);self.peak_tilt=max(self.peak_tilt,self.current_tilt)
        capacity=math.pi*.035**2*.09*1e6*retained_fraction(tilt)
        # A declared discharge cap avoids instantaneous loss; no fluid is
        # replenished when the vessel becomes upright again.
        loss=min(max(0.,self.remaining_ml-capacity),100.*max(0.,dt))
        self.remaining_ml-=loss;self.max_spill_ml=self.initial_volume_ml-self.remaining_ml
        if self.max_spill_ml>=1:
            self.emit('modeled_liquid_spill',t,'modeled_incident',{'spilled_ml':self.max_spill_ml,'effective_tilt_deg':math.degrees(tilt),'model':'quasi_static_cylinder_v1','threshold_ml':1.})

    def reading(self):
        return dict(spilled_ml=round(self.max_spill_ml,5),remaining_ml=round(self.remaining_ml,5),effective_tilt_deg=round(self.current_tilt,5),peak_effective_tilt_deg=round(self.peak_tilt,5),
                    event_count=len(self.events),released=self.released)

    def result(self):
        return dict(events=self.events,monitor_samples=self.samples,monitor_hz=self.config['monitor_hz'],
                    physical_incident=any(e['severity']=='incident' for e in self.events),
                    modeled_incident=any(e['severity']=='modeled_incident' for e in self.events),
                    constraint_violation=any(e['severity']=='violation' for e in self.events),
                    risk_condition=any(e['severity']=='risk' for e in self.events),
                    minimum_released_edge_margin_m=self.minimum_margin,
                    spill_model={'name':'quasi_static_cylinder_v1','radius_m':.035,'height_m':.09,'initial_volume_ml':self.initial_volume_ml,'acceleration_filter_s':.15,'max_discharge_ml_s':100.,'limitations':'Uncalibrated volume proxy; no CFD, heat, injury, liquid/solid coupling or splash trajectories.'} if self.config['mechanism']=='spill' else None,
                    measurements=self.reading(),calibration_status=self.config['calibration_status'])
