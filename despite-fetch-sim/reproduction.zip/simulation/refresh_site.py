"""Refresh the viewer of an existing verified build, preserving all recordings.

Recorded-source archives remain attached to their original episodes. Current
tooling has its own archive; it is never presented as the source of an old run.
"""
import argparse
import hashlib
import html
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent


def digest_files(paths):
    digest=hashlib.sha256()
    for path in paths:digest.update(path.read_bytes())
    return digest.hexdigest()[:12]


def refresh(destination):
    if not (destination/'.despite-generated').exists():raise ValueError('Expected a marked existing simulator build')
    paired=destination/'plan-pairs'
    manifest=json.loads((paired/'manifest.json').read_text())
    # Check every linked episode against its previously published manifest.
    for case in manifest['cases']:
        for row in case['variants'].values():
            for name,digest in row['sha256'].items():
                file=paired/row['path']/name
                if hashlib.sha256(file.read_bytes()).hexdigest()!=digest:raise ValueError('Recording checksum mismatch: '+str(file))
    rooms=list(dict.fromkeys(c['scene_title'] for c in manifest['cases']))
    version=digest_files([ROOT/'plan_pairs'/n for n in ('index.html','style.css','app.js')]+[paired/c['variants'][v]['path']/'result.json' for c in manifest['cases'] for v in ('safe','unsafe')])
    manifest['build_id']=version
    replacements={'__BUILD_ID__':version,'__ROOM_COUNT__':str(len(rooms)),
                  '__CASE_COUNT__':str(len(manifest['cases'])),'__RECORDING_COUNT__':str(2*len(manifest['cases'])),
                  '__ROOM_NAMES__':html.escape(' · '.join(rooms))}
    for name in ('index.html','app.js','style.css'):
        text=(ROOT/'plan_pairs'/name).read_text()
        for old,new in replacements.items():text=text.replace(old,new)
        (paired/name).write_text(text)
    (paired/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(paired/'paired-data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ('manifest.json','summary.csv','README.txt'):z.write(paired/name,name)
        for path in sorted((paired/'data').rglob('*')):
            if path.is_file() and path.suffix in ('.json','.pddl','.py'):z.write(path,path.relative_to(paired))
    main_manifest=json.loads((destination/'data/manifest.json').read_text())
    for episode in main_manifest['episodes']:
        for name,digest in episode['recording_sha256'].items():
            path=destination/episode['path']/name
            if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError('Original episode checksum mismatch: '+str(path))
    main_version=digest_files([ROOT/'site'/n for n in ('index.html','style.css','app.js')]+[paired/'manifest.json'])
    main_manifest['build_id']=main_version
    pairs_link=f'<a href="plan-pairs/">Explore {len(rooms)} rooms &amp; {len(manifest["cases"])} safe / unsafe plan pairs →</a>'
    cards=[]
    for room in rooms:
        cases=[c for c in manifest['cases'] if c['scene_title']==room];c=cases[0]
        cards.append(f'<a href="plan-pairs/#{html.escape(c["id"])}"><img src="plan-pairs/{html.escape(c["variants"]["safe"]["path"])}/poster.jpg" alt="{html.escape(room)} rendered in Isaac Sim" loading="lazy"><strong>{html.escape(room)}</strong><span>{len(cases)} plan {"pair" if len(cases)==1 else "pairs"} · {len(cases)*2} recordings</span></a>')
    gallery='<section class="room-preview" aria-label="Explore native rooms"><div class="section-heading"><div><p class="eyebrow">PAIRED EXECUTIONS</p><h2>Explore the rooms.</h2></div><p>Select a room to compare its safe and unsafe reference plans.</p></div><div class="room-preview-grid">'+''.join(cards)+'</div></section>'
    replacements={'__BUILD_ID__':main_version,'__PAIRS_LINK__':pairs_link,'__ROOM_GALLERY__':gallery,
                  '__PREVIOUS_LINK__':'<a href="previous/">Compare the previous furnished scenes →</a>' if (destination/'previous').is_dir() else '',
                  '__MOTION_REVIEW_LINK__':'<a href="motion-review/">Compare motion clarity →</a>' if (destination/'motion-review').is_dir() else '',
                  '__NAVIGATION_REVIEW_LINK__':'<a href="navigation-review/">See the arrival-turn correction →</a>' if (destination/'navigation-review').is_dir() else ''}
    for name in ('index.html','app.js','style.css'):
        text=(ROOT/'site'/name).read_text()
        for old,new in replacements.items():text=text.replace(old,new)
        (destination/name).write_text(text)
    (destination/'data/manifest.json').write_text(json.dumps(main_manifest,indent=2)+'\n')
    with zipfile.ZipFile(destination/'reproduction.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('README.txt','Current simulator and viewer tooling. Exact historical execution source is in each episode\'s recorded-source.zip; the pilot also exports source by recorded execution digest. No licensed 3D assets are included.\n')
        for path in sorted(ROOT.rglob('*')):
            rel=path.relative_to(ROOT)
            if path.is_file() and 'runs' not in rel.parts and '__pycache__' not in rel.parts and path.suffix in ('.py','.md','.json','.pddl','.html','.css','.js','.patch','.sh','.txt','.png'):
                z.write(path,Path('simulation')/rel)
    print(json.dumps({'paired_build':version,'main_build':main_version,'preserved_recordings':2+2*len(manifest['cases']),'destination':str(destination)}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    refresh(parser.parse_args().output)
