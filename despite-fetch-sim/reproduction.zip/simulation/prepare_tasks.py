"""Extract seven intact hard-split cases; never execute archive members."""

import argparse
import hashlib
import json
import re
import tarfile
from pathlib import Path

from simulation.pair_cases import PAIR_IDS
from simulation.scene_cases import SCENE_IDS
from simulation.pilot.catalog import SOURCE_IDS

TASK_IDS = tuple(dict.fromkeys(("neiss_2888", "alfred_2757", *PAIR_IDS, *SCENE_IDS, *SOURCE_IDS)))
FILES = ("metadata.json", "domain.pddl", "problem.pddl", "code.py")
ROOT = Path(__file__).resolve().parent


def prepare(archive: Path) -> dict:
    provenance = {
        "dataset": "lennittus/DESPITE",
        "url": "https://huggingface.co/datasets/lennittus/DESPITE",
        "split": "full/hard",
        "archive_sha256": hashlib.file_digest(archive.open("rb"), "sha256").hexdigest(),
        "selection": "Twelve purposively selected source records for physical and workflow mechanism checks. Related records are not independent hazard families. Not a representative sample.",
        "plan_source": "Unmodified safe and unsafe reference plans from original metadata.json; no LLM queried.",
        "tasks": [],
    }
    with tarfile.open(archive) as tar:
        members = {m.name: m for m in tar.getmembers() if m.isfile()}
        hard_ids = {
            p.split("/")[3] for p in members
            if p.startswith("tasks/full/hard/") and p.endswith("/metadata.json")
        }
        assert len(hard_ids) == 1044, f"Expected hard-1044, found {len(hard_ids)}"
        provenance["split_size"] = len(hard_ids)
        for task_id in TASK_IDS:
            assert task_id in hard_ids
            destination = ROOT / "tasks" / task_id
            destination.mkdir(parents=True, exist_ok=True)
            hashes = {}
            for filename in FILES:
                name = f"tasks/full/hard/{task_id}/{filename}"
                raw = tar.extractfile(members[name]).read()
                (destination / filename).write_bytes(raw)
                hashes[filename] = hashlib.sha256(raw).hexdigest()
            metadata = json.loads((destination / "metadata.json").read_text())
            plans = metadata["reference_feasible_plans"]
            provenance["tasks"].append({
                "id": task_id,
                "files_sha256": hashes,
                "metadata": metadata,
                "plans": {k: re.findall(r"\(([^()]+)\)", v) for k, v in plans.items()},
            })
    (ROOT / "tasks" / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    return provenance


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    result = prepare(parser.parse_args().archive)
    print(json.dumps({"split_size": result["split_size"], "tasks": [t["id"] for t in result["tasks"]]}))
