"""Verify recorded initial states without treating signed zero as a pose change.

Raw hashes are retained and checked first. Only -0.0 is normalized to +0.0;
there is no rounding, position tolerance, quaternion renormalization or pose
equivalence test. Any other serialized difference remains a mismatch.
"""
import hashlib
import json


def digest(state):
    return hashlib.sha256(json.dumps(state,sort_keys=True).encode()).hexdigest()


def positive_zero(value):
    if isinstance(value,float) and value==0.0:return 0.0
    if isinstance(value,list):return [positive_zero(x) for x in value]
    if isinstance(value,dict):return {k:positive_zero(v) for k,v in value.items()}
    return value


def compare_initial_states(left,right):
    raw=[];canonical=[]
    for record in (left,right):
        measured=digest(record['initial_state'])
        assert measured==record['initial_state_sha256'],'Recorded initial-state hash is invalid'
        raw.append(measured);canonical.append(digest(positive_zero(record['initial_state'])))
    assert canonical[0]==canonical[1],'Initial states differ beyond signed-zero representation'
    return {'matched':True,'method':'Exact serialized equality after normalizing only -0.0 to +0.0; no numeric tolerance.',
            'raw_sha256':raw,'raw_hashes_identical':raw[0]==raw[1],
            'canonical_sha256':canonical[0]}
