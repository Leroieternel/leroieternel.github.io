"""Build a measured before/after review from complete reception recordings."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
import imageio.v2 as imageio
from simulation.audit_reception_motion import compare


def build(before,after,output):
    report=compare(before,after)
    output.mkdir(parents=True,exist_ok=True)
    report['clips']={}
    report['alignment']='Unsafe reference in both clips. Start one second before the delivery action; end one second after placement. Playback is real time; the shorter clip holds its last frame.'
    for name,root in [('before',before),('after',after)]:
        run=root/'normbank_86816-unsafe'
        result=json.loads((run/'result.json').read_text())
        fps=result['video_fps'];step=result['plan'].index('navigate_to_storage_area')
        first=max(0,round((result['steps'][step]['start']-1)*fps))
        last=min(result['frames'],round((result['steps'][-1]['end']+1)*fps))
        reader=imageio.get_reader(run/'episode.mp4')
        writer=imageio.get_writer(output/f'{name}.mp4',fps=fps,codec='libx264',quality=None,
                                 macro_block_size=16,ffmpeg_params=['-crf','14','-movflags','+faststart'])
        try:
            for i in range(first,last):
                frame=reader.get_data(i);writer.append_data(frame)
                if i==first:imageio.imwrite(output/f'{name}.jpg',frame)
        finally:
            reader.close();writer.close()
        for file in ['result.json','trace.json']:
            shutil.copy2(run/file,output/f'{name}-{file}')
        report['clips'][name]={'first_source_frame':first,'frames':last-first,'fps':fps,'duration_s':(last-first)/fps,
                              'result_file':f'{name}-result.json','trace_file':f'{name}-trace.json',
                              'source_video_sha256':hashlib.sha256((run/'episode.mp4').read_bytes()).hexdigest(),
                              'source_result_sha256':hashlib.sha256((run/'result.json').read_bytes()).hexdigest(),
                              'video_sha256':hashlib.sha256((output/f'{name}.mp4').read_bytes()).hexdigest()}
    payload=json.dumps(report,indent=2)+'\n'
    release=hashlib.sha256(payload.encode()).hexdigest()[:12]
    (output/'comparison.json').write_text(payload)
    template=(Path(__file__).parent/'reception_review/index.html').read_text()
    (output/'index.html').write_text(template.replace('__BUILD_ID__',release))
    print(json.dumps({'build':release,'output':str(output),'metrics':report['variants']}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['before','after','output']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();build(a.before,a.after,a.output)
