"""Regression checks on the path follower; full PhysX runs remain mandatory."""
import math
import unittest
from types import SimpleNamespace
import numpy as np
from simulation.segment_navigation import execute,wrap


class Tensor:
    def __init__(self,value):self.value=np.asarray(value)
    def detach(self):return self
    def cpu(self):return self
    def numpy(self):return self.value


class Plant:
    def __init__(self,smooth=False):
        self.control_hz=60;self.tick=0;self.xy=np.array([.15,.25]);self.yaw=0.
        self.last_base_command=np.zeros(2);self.velocity=np.zeros(2);self.history=[]
        self.motion_profile={'speed':.1,'turn':.3,'acceleration':.12,'angular_acceleration':.4} if smooth else None
        self.spec={'default_navigation_limits':{'speed':.45,'turn':1.2},
                   'base_acceleration_limits':{'acceleration':.6,'angular_acceleration':1.6},
                   'navigation_controller':{'position_tolerance_m':.018,'cross_track_tolerance_m':.03,'heading_tolerance_rad':.025,'distance_gain':1.4}}
        self.robot=SimpleNamespace(get_position_orientation=lambda:(Tensor([*self.xy,0]),Tensor([0,0,math.sin(self.yaw/2),math.cos(self.yaw/2)])))
        self.steps=[{}]
    def step(self,base=(0,0)):
        cfg=self.motion_profile or self.spec['base_acceleration_limits']
        caps=np.array([cfg['acceleration'],cfg['angular_acceleration']])/60
        self.last_base_command+=np.clip(np.asarray(base)-self.last_base_command,-caps,caps)
        # Finite response lag catches overshoot that ideal teleporting tests miss.
        self.velocity+=(self.last_base_command-self.velocity)*.25
        self.xy+=self.velocity[0]*np.array([math.cos(self.yaw),math.sin(self.yaw)])/60
        self.yaw+=self.velocity[1]/60;self.tick+=1
        self.history.append([*self.xy,self.yaw,*self.last_base_command])


class NavigationTests(unittest.TestCase):
    def test_both_profiles_keep_single_turn_direction_and_distinct_steps(self):
        for smooth in (False,True):
            with self.subTest(smooth=smooth):
                ep=Plant(smooth)
                execute(ep,{'segments':[{'goal':[-.42,.25],'reverse':True,'label':'reverse'},
                    {'goal':[-.42,-.02],'continue_to':[-.42,-.16],'label':'aisle'}]})
                checkpoint=ep.xy.copy();command_at_checkpoint=ep.last_base_command.copy()
                ep.steps.append({})
                execute(ep,{'segments':[{'goal':[-.42,-.16],'label':'table'}],'yaw':math.atan2(-.19,-.61)})
                a=np.asarray(ep.history);turn=np.diff(a[:,2])
                self.assertLess(np.linalg.norm(ep.xy-[-.42,-.16]),.035)
                self.assertLess(abs(wrap(ep.yaw-math.atan2(-.19,-.61))),.03)
                self.assertLess(np.degrees(abs(turn).sum()),185)
                self.assertGreater(command_at_checkpoint[0],.02,'No stop-and-restart at the action boundary')
                self.assertGreater(np.linalg.norm(ep.xy-checkpoint),.10)
                self.assertLess(np.linalg.norm(np.diff(a[:,:2],axis=0),axis=1).sum(),1.10)
                obstacle=np.array([.12,-.33]);half=np.array([.14,.13])
                clearance=np.linalg.norm(np.maximum(abs(a[:,:2]-obstacle)-half,0),axis=1)-.29
                self.assertGreater(clearance.min(),.08)
                if smooth:self.assertLessEqual(abs(a[:,4]).max(),.300001)


if __name__=='__main__':unittest.main()
