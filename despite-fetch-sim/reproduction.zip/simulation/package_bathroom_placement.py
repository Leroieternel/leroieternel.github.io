"""Replace the reviewed bathroom pair while preserving all other recordings."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from simulation.build_pairs import build
from simulation.pilot.catalog import SOURCE_IDS
from simulation.refresh_site import refresh
from simulation.verify_bathroom_placement import verify


def stage(old_runs, new_runs, reviews, previous_site, output):
    report=verify(new_runs)
    fresh={}
    for variant in ('safe','unsafe'):
        name='alfred_2757-'+variant
        qa=json.loads((reviews/name/'review.json').read_text())
        assert qa['visual_review_status']=='reviewed'
        assert hashlib.sha256((new_runs/name/'episode.mp4').read_bytes()).hexdigest()==qa['video_sha256']
        fresh[name]={**qa,'run':name}
    assert not output.exists(),'Use a fresh staging directory'
    output.parent.mkdir(parents=True,exist_ok=True)
    combined=output.parent/'combined-runs';combined.mkdir()
    for task in SOURCE_IDS:
        for variant in ('safe','unsafe'):
            name=task+'-'+variant
            (combined/name).symlink_to(((new_runs if task=='alfred_2757' else old_runs)/name).resolve(),target_is_directory=True)
    shutil.copytree(previous_site,output)
    pairs=output/'plan-pairs'
    old_manifest=json.loads((pairs/'manifest.json').read_text())
    old_review=json.loads((pairs/'release-review.json').read_text())
    build(combined,pairs,all_tasks=True)
    manifest=json.loads((pairs/'manifest.json').read_text())
    next(c for c in manifest['cases'] if c['id']=='alfred_2757')['execution_audit']='bathroom-placement-audit.json'
    (pairs/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    old_by_id={c['id']:c for c in old_manifest['cases']}
    for case in manifest['cases']:
        if case['id']=='alfred_2757':continue
        for variant in ('safe','unsafe'):
            for name in ('episode.mp4','result.json','trace.json'):
                assert case['variants'][variant]['sha256'][name]==old_by_id[case['id']]['variants'][variant]['sha256'][name]
    # Keep the original single-episode explorer consistent with the pair page.
    primary_path=output/'data/manifest.json'
    primary=json.loads(primary_path.read_text())
    entry=next(e for e in primary['episodes'] if e['task_id']=='alfred_2757')
    destination=output/entry['path'];run=new_runs/'alfred_2757-safe'
    for name in list(entry['recording_sha256']):
        src=run/name
        if src.exists():shutil.copy2(src,destination/name)
        entry['recording_sha256'][name]=hashlib.sha256((destination/name).read_bytes()).hexdigest()
    pair_folder=pairs/'data/alfred_2757/safe'
    for name in ('recorded-source.zip','motion-audit.json'):
        shutil.copy2(pair_folder/name,destination/name)
    primary_path.write_text(json.dumps(primary,indent=2)+'\n')
    refresh(output)
    manifest=json.loads((pairs/'manifest.json').read_text())
    release={**old_review,'created_at':datetime.now(timezone.utc).isoformat(),
        'paired_build_id':manifest['build_id'],
        'recordings':[fresh.get(r['run'],r) for r in old_review['recordings']]}
    release['source_implementation_note']='Exact source is retained per recording. The bathroom pair adds supported shallow-angle sponge placement; the study pair retains its earlier spatial repair. Both labels within each pair use identical code and geometry. The other 22 recordings are unchanged.'
    release['bathroom_placement_followup']={
        'previous_videos':{v:old_by_id['alfred_2757']['variants'][v]['sha256']['episode.mp4'] for v in ('safe','unsafe')},
        'audit':'bathroom-placement-audit.json',
        'source_sha256':json.loads((new_runs/'alfred_2757-safe/result.json').read_text())['simulation_code_sha256']}
    release['previous_release_browser_checks']=old_review.get('browser_checks')
    release['browser_checks']={'status':'pending_staged_browser_review'}
    release['outcome_summary']={
        'completed':sum(r['status']=='completed' for r in release['recordings']),
        'blocked':sum(r['status']=='blocked' for r in release['recordings']),
        'goals_reached':sum(r['goal_reached'] for r in release['recordings'])}
    (pairs/'release-review.json').write_text(json.dumps(release,indent=2)+'\n')
    (pairs/'bathroom-placement-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    with zipfile.ZipFile(pairs/'paired-data.zip','a',zipfile.ZIP_DEFLATED) as archive:
        archive.write(pairs/'bathroom-placement-audit.json','bathroom-placement-audit.json')
    for old in (previous_site/'safety-pilot').rglob('*'):
        if old.is_file():assert old.read_bytes()==(output/old.relative_to(previous_site)).read_bytes()
    print(json.dumps({'site':str(output),'build_id':manifest['build_id'],
        'replaced_recordings':2,'unchanged_recordings':22}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('old-runs','new-runs','reviews','previous-site','output'):
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();stage(a.old_runs,a.new_runs,a.reviews,a.previous_site,a.output)
