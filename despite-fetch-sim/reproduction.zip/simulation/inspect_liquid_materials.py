"""Diagnostic stills of a recorded floor state; no physical time advancement."""
import gzip,json
from pathlib import Path
import numpy as np


def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    from simulation.run_episode import Episode,og
    from simulation.liquid_film import FloorFilm
    from simulation.preview_native import camera
    import imageio.v2 as imageio
    ep=Episode('neiss_11868','unsafe',a.output/'work','physical',realistic=True,native=True,draft=True,physics_only=True)
    try:
        from pxr import UsdGeom,UsdShade,Sdf
        particles=json.load(gzip.open(a.run/'liquid-particles.json.gz','rt'))
        film=json.loads((a.run/'floor-film.json').read_text());data=json.loads((a.run/'validation.json').read_text())
        points=np.asarray(particles['frames'][-1]['positions_m'],dtype=np.float32)
        positions=points.copy();f=FloorFilm(len(points),particles['particle_volume_ml'],obstacles=ep.spec['map_objects'])
        for deposit in film['deposits']:
            i=deposit['particle_id'];positions[i]=deposit['position_m'];f.update(positions,[i],deposit['time_s'])
        f.update(positions,[],data['seconds']);ep.liquid.surface.film=f;ep.liquid.surface.update(points)
        camera([-.68,.53,.23],[-.44,.15,.002],32)
        shader=UsdShade.Shader(og.sim.stage.GetPrimAtPath('/World/Looks/MeasuredHotLiquid/Shader'))
        before=og.sim.current_time
        for name,thin,shadows in [('baseline',False,True),('no-shadow',False,False),('thin-no-shadow',True,False)]:
            with og.sim.editing_usd():
                shader.GetInput('thin_walled').Set(thin)
                for mesh in (ep.liquid.surface.mesh,ep.liquid.surface.film_mesh):
                    UsdGeom.PrimvarsAPI(mesh.GetPrim()).CreatePrimvar('doNotCastShadows',Sdf.ValueTypeNames.Bool).Set(not shadows)
            for _ in range(48):og.sim.render()
            rgb=og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3]
            imageio.imwrite(a.output/(name+'.jpg'),rgb)
            print('MATERIAL_CHECK',name,flush=True)
        assert before==og.sim.current_time
    finally:og.shutdown()


if __name__=='__main__':main()
