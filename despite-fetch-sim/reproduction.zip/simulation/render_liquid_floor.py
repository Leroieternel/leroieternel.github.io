"""Render recorded liquid positions with Fetch hidden for floor inspection.

This is a labelled state-reconstruction view, never an execution recording or
input to the safety measurements. No physics is advanced after loading the
recorded state. The original two-camera videos are unchanged.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np


def reconstruct_film(points,volume,spec,film_record,until,hz):
    from simulation.liquid_film import FloorFilm
    film=FloorFilm(len(points),volume,bounds=spec['map_bounds'],obstacles=spec['map_objects'],config=film_record['model'])
    by_tick={};contact_positions=points.copy()
    for d in film_record['deposits']:
        tick=round(d['time_s']*hz)
        if tick<=round(until*hz):by_tick.setdefault(tick,[]).append(d)
    # Preserve every control tick and the original explicit substep cadence.
    for tick in range(round(until*hz)+1):
        deposits=by_tick.get(tick,[])
        for d in deposits:contact_positions[d['particle_id']]=d['position_m']
        film.update(contact_positions,[d['particle_id'] for d in deposits],tick/hz)
    return film


def render(run,output):
    import imageio.v2 as imageio
    print('Loading recorded liquid state',flush=True)
    r=json.loads((run/'result.json').read_text())
    data=json.load(gzip.open(run/'liquid-particles.json.gz','rt'))
    recorded=data['frames'][-1]
    points=np.asarray(recorded['positions_m'],dtype=np.float32)
    film_record=json.loads((run/'floor-film.json').read_text()) if (run/'floor-film.json').exists() else None
    reconstructed_film=None
    floor=points[np.asarray(data['floor_particle_ids'],dtype=int)]
    floor=floor[(floor[:,2]>-.003)&(floor[:,2]<.006)]
    if not len(floor):raise ValueError('No recorded liquid particles at floor height')
    # Find a visible cluster of measured droplets, rather than a possibly empty
    # point between several disconnected pools.
    cells=np.floor(floor[:,:2]/.05).astype(int)
    keys,counts=np.unique(cells,axis=0,return_counts=True)
    center=(keys[counts.argmax()]+.5)*.05
    cluster=floor[np.linalg.norm(floor[:,:2]-center,axis=1)<.12]
    target=np.median(cluster,axis=0).astype(float)
    t=json.loads((run/'trace.json').read_text())
    state=min(t,key=lambda s:abs(s['t']-recorded['t']))
    # Require the current rendering implementation to match the frozen run.
    root=Path(__file__).resolve().parent
    for name,digest in r['simulation_code_sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    from simulation.run_episode import Episode,og
    import torch
    print('Initializing inspection renderer',flush=True)
    ep=Episode('neiss_11868',r['variant'],output/'render-work','physical',realistic=True,native=True,draft=True,physics_only=True)
    try:
        from pxr import UsdGeom
        print('Reconstructing measured particle state without physics steps',flush=True)
        before=og.sim.current_time
        ep.obj.set_position_orientation(position=torch.tensor(state['object']['p']),orientation=torch.tensor(state['object']['q']))
        ep.robot.set_position_orientation(position=torch.tensor(state['robot']['p']),orientation=torch.tensor(state['robot']['q']))
        ep.robot.set_joint_positions(torch.tensor(state['joints']))
        with og.sim.editing_usd():UsdGeom.Imageable(ep.robot.prim).MakeInvisible()
        if film_record:
            from scipy.ndimage import label
            film=reconstruct_film(points,data['particle_volume_ml'],r['spec'],film_record,recorded['t'],r['control_hz'])
            assert abs(film.snapshot()['volume_error_ml'])<1e-7
            ep.liquid.surface.film=film
            origin,height=film.surface_grid()
            regions,n=label(height>film.cfg['visible_depth_m'])
            assert n,'No visible film above the declared display threshold'
            volumes=np.bincount(regions.ravel(),weights=height.ravel());volumes[0]=0
            wet=np.argwhere(regions==volumes.argmax());weight=height[tuple(wet.T)]
            target=np.r_[origin+np.average(wet,axis=0,weights=weight)*film.dx,0.]
            extent=float((np.ptp(wet,axis=0).max()+1)*film.dx)
            reconstructed_film={'metrics':film.snapshot(),'focus_region_area_cm2':len(wet)*film.dx**2*1e4,
                                'source_sha256':hashlib.sha256((run/'floor-film.json').read_bytes()).hexdigest()}
        ep.liquid.surface.update(points)
        from simulation.preview_native import camera
        if reconstructed_film:
            distance=max(.06,extent*2.5)
            camera(target+[-.45*distance,.55*distance,distance],target,32)
        else:camera(target+[-.20,.22,.42],target,26)
        for _ in range(48):og.sim.render()
        assert og.sim.current_time==before,'Inspection must not advance physics'
        rgb=og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3]
        output.mkdir(parents=True,exist_ok=True)
        imageio.imwrite(output/'floor-inspection.jpg',rgb)
        metadata={'kind':'recorded_particle_state_render','recorded_time_s':recorded['t'],
            'caption':'Recorded floor particles; robot hidden for inspection. This is a reconstruction of measured state, not an additional physical run.',
            'robot_hidden':True,'physics_advanced_during_inspection':False,
            'particle_source':'liquid-particles.json.gz',
            'particle_source_sha256':hashlib.sha256((run/'liquid-particles.json.gz').read_bytes()).hexdigest(),
            'renderer_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'camera_target_m':target.tolist(),'visible_cluster_particles':len(cluster),
            'calibration_status':'uncalibrated'}
        if reconstructed_film:
            metadata.update(kind='recorded_floor_film_reconstruction',film=reconstructed_film,
                caption='Floor film reconstructed from recorded contacts at this timestamp; close camera, robot hidden for inspection. Uncalibrated spreading model, not another physical run.')
        (output/'floor-inspection.json').write_text(json.dumps(metadata,indent=2)+'\n')
        print(json.dumps(metadata),flush=True)
    finally:og.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();render(a.run,a.output)
