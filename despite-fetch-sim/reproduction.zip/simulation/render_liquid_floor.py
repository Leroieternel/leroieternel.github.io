"""Render recorded liquid positions with Fetch hidden for floor inspection.

This is a labelled state-reconstruction view, never an execution recording or
input to the safety measurements. No physics is advanced after loading the
recorded state. The original two-camera videos are unchanged.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np


def render(run,output):
    import imageio.v2 as imageio
    print('Loading recorded liquid state',flush=True)
    r=json.loads((run/'result.json').read_text())
    data=json.load(gzip.open(run/'liquid-particles.json.gz','rt'))
    recorded=data['frames'][-1]
    points=np.asarray(recorded['positions_m'],dtype=np.float32)
    floor=points[np.asarray(data['floor_particle_ids'],dtype=int)]
    floor=floor[(floor[:,2]>-.003)&(floor[:,2]<.006)]
    if not len(floor):raise ValueError('No recorded liquid particles at floor height')
    # Find a visible cluster of measured droplets, rather than a possibly empty
    # point between several disconnected pools.
    cells=np.floor(floor[:,:2]/.05).astype(int)
    keys,counts=np.unique(cells,axis=0,return_counts=True)
    center=(keys[counts.argmax()]+.5)*.05
    cluster=floor[np.linalg.norm(floor[:,:2]-center,axis=1)<.12]
    target=np.median(cluster,axis=0).astype(float)
    t=json.loads((run/'trace.json').read_text())
    state=min(t,key=lambda s:abs(s['t']-recorded['t']))
    # Require the current rendering implementation to match the frozen run.
    root=Path(__file__).resolve().parent
    for name,digest in r['simulation_code_sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    from simulation.run_episode import Episode,og
    import torch
    print('Initializing inspection renderer',flush=True)
    ep=Episode('neiss_11868',r['variant'],output/'render-work','physical',realistic=True,native=True,draft=True,physics_only=True)
    try:
        from pxr import UsdGeom
        print('Reconstructing measured particle state without physics steps',flush=True)
        before=og.sim.current_time
        ep.obj.set_position_orientation(position=torch.tensor(state['object']['p']),orientation=torch.tensor(state['object']['q']))
        ep.robot.set_position_orientation(position=torch.tensor(state['robot']['p']),orientation=torch.tensor(state['robot']['q']))
        ep.robot.set_joint_positions(torch.tensor(state['joints']))
        with og.sim.editing_usd():UsdGeom.Imageable(ep.robot.prim).MakeInvisible()
        ep.liquid.surface.update(points)
        from simulation.preview_native import camera
        camera(target+[-.20,.22,.42],target,26)
        for _ in range(48):og.sim.render()
        assert og.sim.current_time==before,'Inspection must not advance physics'
        rgb=og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3]
        output.mkdir(parents=True,exist_ok=True)
        imageio.imwrite(output/'floor-inspection.jpg',rgb)
        metadata={'kind':'recorded_particle_state_render','recorded_time_s':recorded['t'],
            'caption':'Recorded floor particles; robot hidden for inspection. This is a reconstruction of measured state, not an additional physical run.',
            'robot_hidden':True,'physics_advanced_during_inspection':False,
            'particle_source':'liquid-particles.json.gz',
            'particle_source_sha256':hashlib.sha256((run/'liquid-particles.json.gz').read_bytes()).hexdigest(),
            'renderer_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'camera_target_m':target.tolist(),'visible_cluster_particles':len(cluster),
            'calibration_status':'uncalibrated'}
        (output/'floor-inspection.json').write_text(json.dumps(metadata,indent=2)+'\n')
        print(json.dumps(metadata),flush=True)
    finally:og.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();render(a.run,a.output)
