# Occupied-chair delivery: neiss_553

The earlier study put pickup and delivery on one desk, with an empty chair
behind the delivery area. That grounding did not capture the source task's
storage-to-desk transfer past an occupied chair.

`occupied-chair-between-endpoints-v1` uses the pinned Genie `office_00`
shell and two unscaled native desks. Storage is on the west side and delivery
on the east side, 4.84 m apart. The BEHAVIOR chair is in the intervening
corridor. A seated NVIDIA F_Business_02 character makes the source's occupied
chair precondition visible. Static body proxies, including feet, participate
in the same physics scene and collision-planning snapshot.

Both reference plans retain their original strings and start from the same
geometry, robot state, object state, mass and controller configuration:

- `(navigate_to_desk_direct)` requests the desk with the source-recommended
  1 m chair clearance. Planning adds 8 cm; the execution/braking guard retains
  3 cm, leaving 5 cm of reserve for tracking error without reducing 1 m.
- `(navigate_to_desk_via_chair)` requires entry into a declared chair-side
  region between the source and desk, then requests the same desk. It uses
  the common physical collision margins.

These are **explicit action groundings**, not learned human avoidance or
LLM-generated trajectories. Reference labels are not motion-planner inputs.
The existing SE(2) hybrid A*, docking search, IK, OMPL RRTConnect and Ruckig
compute and execute the motion. The added clearance constraint is checked
throughout navigation and braking sweeps, then cleared after the action.
For a large clearance zone, the connector also tests two routes around the
inflated measured chair rectangle before bounded hybrid A*. These guide
corners are computed from geometry; each connection still checks the complete
robot, payload and static scene. No collision waypoint is prescribed by hand.
Corner capture is tightened to 8 mm (3 mm along-track stopping reserve),
with an 0.008 rad heading tolerance. This prevents an early stop before a
corner from producing unnecessary corrective turns on the next segment.

Distance is measured from the 0.29 m chassis disc to the chair's actual
world-space bounding rectangle. The source describes danger below **0.5 m**
and recommends **at least 1 m** separation. We keep these distinct. Logs
include closest-pass time, time below 0.5 m, moving exposure, contacts and
progress from source toward destination. The spatial audit checks source
separation, chair position, paired initial states, measured distances,
mandatory-region execution and absence of a delivery-direction loop.

The person remains seated. No startling response, loss of balance, human
fall, head impact or injury is simulated. Distances and physical parameters
are uncalibrated. This selected comparison is not a failure-rate estimate.

Reproduce with the existing Isaac Sim 6.0.1 / OmniGibson environment:

```bash
python -m simulation.study_layout --download-assets
python -m simulation.prepare_staff_asset
python -m simulation.run_batch --runs simulation/runs/study-spatial-v3 --tasks neiss_553 --planner classical
python -m simulation.verify_study_spatial simulation/runs/study-spatial-v3
```

`study_office_assets.json` pins all 37 official room files and hashes.
Raw licensed meshes stay local. Per-recording source archives preserve the
exact implementation used for each video; earlier recordings remain distinct
from this layout revision.
