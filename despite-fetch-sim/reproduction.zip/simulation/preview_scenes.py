"""Inspect distinct native rooms and their geometry before recording tasks."""
import json
from pathlib import Path
import numpy as np
from simulation.runtime import configure, ROOT
from simulation.prepare_scene_assets import SCENES
from simulation.preview_native import camera


def main():
    configure()
    import omnigibson as og
    from omnigibson.macros import gm
    gm.USE_GPU_DYNAMICS=False;gm.ENABLE_TRANSITION_RULES=False
    import imageio.v2 as imageio
    from simulation.rendering import configure_capture
    env=og.Environment(configs={'scene':{'type':'Scene','floor_plane_visible':False,'use_skybox':False},'render':{'viewer_width':1440,'viewer_height':960}})
    from pxr import Usd,UsdGeom,UsdLux,Sdf
    configure_capture()
    output=ROOT/'simulation/runs/new-scene-preview';output.mkdir(parents=True,exist_ok=True)
    for name,path in SCENES.items():
        stage=og.sim.stage
        with og.sim.editing_usd():
            stage.RemovePrim('/World/ReviewRoom')
            room=stage.DefinePrim('/World/ReviewRoom','Xform');room.GetReferences().AddReference(str(ROOT/'.runtime/genie-assets'/path))
            for prim in Usd.PrimRange(room):
                if prim.HasAPI(UsdLux.LightAPI):
                    light=UsdLux.LightAPI(prim);light.CreateExposureAttr((light.GetExposureAttr().Get() or 0)-.65)
                    prim.CreateAttribute('visibleInPrimaryRay',Sdf.ValueTypeNames.Bool).Set(False)
        cache=UsdGeom.BBoxCache(0,['default','render'])
        rows=[]
        for prim in Usd.PrimRange(room):
            if prim.IsA(UsdGeom.Mesh) or prim.IsA(UsdGeom.Xform):
                bound=cache.ComputeWorldBound(prim).ComputeAlignedRange()
                lo,hi=np.array(bound.GetMin()),np.array(bound.GetMax())
                if np.isfinite(lo).all() and np.isfinite(hi).all():rows.append({'path':str(prim.GetPath()),'type':prim.GetTypeName(),'lo':lo.tolist(),'hi':hi.tolist()})
        (output/(name+'-bounds.json')).write_text(json.dumps(rows,indent=2))
        layer=Usd.Stage.Open(str(ROOT/'.runtime/genie-assets'/path)).GetRootLayer()
        authored=layer.customLayerData.get('cameraSettings',{}).get('Perspective',{})
        eye=authored.get('position',[0,0,1.6]);target=authored.get('target',[1,0,.8])
        views=[('authored',eye,target,20)]
        if name=='kitchen':views += [('interior',[-1.2,1.0,1.8],[1,-1,.8],16)]
        if name=='study':views += [('interior',[-1.95,-.65,1.9],[.25,.15,.85],14)]
        if name=='lobby':views += [('interior',[-1,1.5,1.7],[2,0,.8],16)]
        for view,eye,target,focal in views:
            camera(eye,target,focal)
            for _ in range(45):og.sim.render()
            imageio.imwrite(output/(name+'-'+view+'.jpg'),og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3])
        if name in ['kitchen','study','lobby']:
            from simulation.genie_scene import measure_surface
            samples = {'kitchen': [(1.0,.65),(.95,-.6),(.9,.8)], 'study':[(.48,-.40),(.48,.15),(.48,.65)], 'lobby':[(2.95,-.5),(2.95,0),(2.95,.9),(2.65,-.5),(2.35,-.5)]}[name]
            for point in samples:
                try: print('SURFACE',name,point,measure_surface('',[point],1.4,room=ROOT/'.runtime/genie-assets'/path),flush=True)
                except Exception as e: print('SURFACE_ERROR',name,point,str(e),flush=True)
        print('PREVIEW_READY',name,'bounds',len(rows),flush=True)
    og.shutdown()


if __name__=='__main__':main()
