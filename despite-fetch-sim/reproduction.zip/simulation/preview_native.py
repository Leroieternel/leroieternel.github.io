"""Render native room assets before adapting any physical task into them."""
import argparse
import json
from pathlib import Path
from simulation.runtime import configure, ROOT


def camera(eye, target, focal=22):
    import numpy as np
    import torch
    import omnigibson as og
    from scipy.spatial.transform import Rotation
    eye, target = np.asarray(eye, dtype=float), np.asarray(target, dtype=float)
    z = eye - target; z /= np.linalg.norm(z)
    x = np.cross([0, 0, 1], z); x /= np.linalg.norm(x)
    q = Rotation.from_matrix(np.column_stack([x, np.cross(z, x), z])).as_quat()
    og.sim.viewer_camera.focal_length = focal
    og.sim.viewer_camera.set_position_orientation(position=torch.tensor(eye, dtype=torch.float32),
                                                   orientation=torch.tensor(q, dtype=torch.float32))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene', default='Rs_int')
    parser.add_argument('--output', type=Path, default=ROOT / 'simulation/runs/native-preview')
    parser.add_argument('--diagnose', action='store_true')
    args = parser.parse_args()
    configure()
    import omnigibson as og
    from omnigibson.macros import gm
    gm.USE_GPU_DYNAMICS = False
    gm.ENABLE_TRANSITION_RULES = False
    gm.ENABLE_OBJECT_STATES = False
    config = {'scene': {'type': 'InteractiveTraversableScene', 'scene_model': args.scene},
              'render': {'viewer_width': 1440, 'viewer_height': 960}}
    if args.scene == 'genie':
        config['scene'] = {'type': 'Scene', 'floor_plane_visible': False, 'use_skybox': False}
    env = og.Environment(configs=config)
    import omnigibson.lazy as L
    import imageio.v2 as imageio
    args.output.mkdir(parents=True, exist_ok=True)
    if args.scene == 'genie':
        with og.sim.editing_usd():
            prim = og.sim.stage.DefinePrim('/World/NativeRoom', 'Xform')
            prim.GetReferences().AddReference(str(ROOT / '.runtime/genie-assets/background/home/home_b/background.usda'))
    objects = []
    for obj in env.scene.objects:
        low, high = obj.aabb
        objects.append({'name': obj.name, 'category': obj.category,
                        'aabb': [low.cpu().tolist(), high.cpu().tolist()],
                        'rooms': getattr(obj, 'in_rooms', [])})
    (args.output / 'objects.json').write_text(json.dumps(objects, indent=2))
    if args.scene == 'genie':
        bounds = L.pxr.UsdGeom.BBoxCache(0, ['default', 'render'])
        native = og.sim.stage.GetPrimAtPath('/World/NativeRoom/background')
        rows = []
        for prim in native.GetChildren():
            b = bounds.ComputeWorldBound(prim).ComputeAlignedRange()
            rows.append({'path': str(prim.GetPath()), 'aabb': [list(b.GetMin()), list(b.GetMax())]})
        (args.output / 'native-bounds.json').write_text(json.dumps(rows, indent=2))
    settings = L.carb.settings.get_settings()
    settings.set('/rtx/sceneDb/ambientLightIntensity', 0.0)
    views = [('bedroom', [-2.25, 1.0, 1.45], [-3.1, -1., .8]),
             ('living', [1.25, .8, 1.45], [-.65, -1.8, .8]),
             ('bathroom', [-2.3, 1.9, 1.45], [-3.25, 2.9, .8])]
    if args.scene == 'genie':
        views = [('bedroom', [.65, .8, 1.45], [2.2, 2.35, .7]),
                 ('living', [-.25, -.8, 1.5], [-1.9, 1.8, .8]),
                 ('bathroom', [1.85, -1.2, 1.5], [2.9, -2.8, .85])]
    for name, eye, target in views:
        camera(eye, target)
        for _ in range(40): og.sim.render()
        rgb = og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[..., :3]
        imageio.imwrite(args.output / (name + '.jpg'), rgb)
        print('RENDERED', name, flush=True)
    if args.diagnose and args.scene == 'genie':
        with og.sim.editing_usd():
            for prim in L.pxr.Usd.PrimRange(og.sim.stage.GetPrimAtPath('/World/NativeRoom')):
                if prim.IsA(L.pxr.UsdGeom.Mesh):
                    b = bounds.ComputeWorldBound(prim).ComputeAlignedRange()
                    if b.GetMin()[2] > 2.25:
                        L.pxr.UsdGeom.Imageable(prim).MakeInvisible()
        camera([0, -.01, 9], [0, 0, 0], 19)
        for _ in range(30): og.sim.render()
        imageio.imwrite(args.output / 'layout.jpg', og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[..., :3])
        print('RENDERED layout', flush=True)
    og.shutdown()


if __name__ == '__main__':
    main()
