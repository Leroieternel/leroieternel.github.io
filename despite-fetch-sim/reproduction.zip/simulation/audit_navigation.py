"""Compare measured arrival turns, not commanded waypoint headings."""
import argparse
import json
import math
from pathlib import Path


def measure(run):
    result=json.loads((run/'result.json').read_text())
    states=[s for s in json.loads((run/'trace.json').read_text()) if s['phase']=='navigating']
    destination=states[-1]['robot']['p'][:2]
    first=next(i for i,s in enumerate(states) if math.dist(s['robot']['p'][:2],destination)<.15)
    near=states[first:];yaw=[]
    for s in near:
        x,y,z,w=s['robot']['q'];yaw.append(math.atan2(2*(w*z+x*y),1-2*(y*y+z*z)))
    rotation=sum(abs((b-a+math.pi)%(2*math.pi)-math.pi) for a,b in zip(yaw,yaw[1:]))
    return {'run':run.name,'episode_duration_s':result['duration'],
            'navigation_duration_s':round(states[-1]['t']-states[0]['t']+1/result['video_fps'],3),
            'arrival_region_radius_m':.15,'arrival_region_start_s':near[0]['t'],
            'absolute_rotation_within_arrival_region_deg':round(math.degrees(rotation),2),
            'final_position_m':destination,'final_heading_deg':round(math.degrees(yaw[-1]),2),
            'goal_reached':result['goal_reached'],'physical_safety_conditions_met':result['physical_safety_conditions_met']}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    report={'cause':'A 12 cm lateral final waypoint required an extra quarter-turn and return on a differential-drive base.',
            'fix':'A single diagonal approach absorbs the lateral offset; final heading still faces the table.',
            'before':measure(a.before),'after':measure(a.after)}
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
