#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME_DIR="$PROJECT_ROOT/.runtime"
SIM_PYTHON="$RUNTIME_DIR/isaac601/bin/python"
OG_COMMIT=b544acbbb76b461349bcba21f93b870b11da6608
mkdir -p "$RUNTIME_DIR/datasets"
if [[ ! -x "$SIM_PYTHON" ]]; then
    conda create -y -p "$RUNTIME_DIR/isaac601" python=3.12 pip
fi
if [[ ! -d "$RUNTIME_DIR/BEHAVIOR-1K/.git" ]]; then
    git clone --no-checkout --filter=blob:none https://github.com/StanfordVL/BEHAVIOR-1K.git "$RUNTIME_DIR/BEHAVIOR-1K"
    git -C "$RUNTIME_DIR/BEHAVIOR-1K" checkout "$OG_COMMIT"
fi
if [[ "$(git -C "$RUNTIME_DIR/BEHAVIOR-1K" rev-parse HEAD)" != "$OG_COMMIT" ]]; then
    echo 'Existing OmniGibson checkout differs from the tested commit; use a separate runtime directory.' >&2
    exit 1
fi
export OMNI_KIT_ACCEPT_EULA=YES
export OMNIGIBSON_DATA_PATH="$RUNTIME_DIR/datasets"
"$SIM_PYTHON" -m pip install 'isaacsim[all,extscache]==6.0.1.0' --extra-index-url https://pypi.nvidia.com
"$SIM_PYTHON" -m pip install -e "$RUNTIME_DIR/BEHAVIOR-1K/bddl3" -e "$RUNTIME_DIR/BEHAVIOR-1K/OmniGibson" --no-build-isolation 'setuptools==80.10.2' 'coverage==7.17.2' 'llvmlite==0.50.0' 'numba==0.68.1' 'websockets==17.4' 'torch==2.11.0' 'numpy==2.2.6'
PATCH_FILE="$PROJECT_ROOT/simulation/patches/omnigibson-physics-material-usd-guard.patch"
if git -C "$RUNTIME_DIR/BEHAVIOR-1K" apply --check "$PATCH_FILE" 2>/dev/null; then
    git -C "$RUNTIME_DIR/BEHAVIOR-1K" apply "$PATCH_FILE"
elif ! git -C "$RUNTIME_DIR/BEHAVIOR-1K" apply --reverse --check "$PATCH_FILE" 2>/dev/null; then
    echo 'OmniGibson patch does not apply cleanly.' >&2
    exit 1
fi
"$SIM_PYTHON" -m omnigibson.utils.asset_utils --download_omnigibson_robot_assets
"$SIM_PYTHON" -m omnigibson.utils.asset_utils --download_behavior_1k_assets
cd "$PROJECT_ROOT"
"$SIM_PYTHON" -m simulation.prepare_visual_assets
"$SIM_PYTHON" -m simulation.smoke_test
