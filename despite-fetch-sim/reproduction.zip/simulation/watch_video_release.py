"""Audit finished recordings while the serial GPU queue continues."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

from simulation.pilot.catalog import SOURCE_IDS
from simulation.video_release_qa import inspect


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    finished={};expected=[task+'-'+v for task in SOURCE_IDS for v in ('safe','unsafe')]
    ledger=args.output/'ledger.json'
    if ledger.exists():
        previous=json.loads(ledger.read_text()).get('runs',{})
        for name,row in previous.items():
            report=args.output/name/'review.json';video=args.runs/name/'episode.mp4'
            if name not in expected or row.get('status')!='passed' or not report.exists() or not video.exists():continue
            review=json.loads(report.read_text())
            if hashlib.sha256(video.read_bytes()).hexdigest()!=row['video_sha256']:continue
            if review.get('video_sha256')!=row['video_sha256']:continue
            finished[name]={**row,'visual_review':review.get('visual_review_status','pending')}
        print('RESUMED_AUDITS',len(finished),flush=True)
    while len(finished)<len(expected):
        for name in expected:
            if name in finished:continue
            run=args.runs/name
            if not (run/'result.json').exists():continue
            try:
                report=inspect(run,args.output/name)
                finished[name]={'status':'passed','video_sha256':report['video_sha256'],
                                'duration_s':report['duration_s'],'frames':report['frames'],'visual_review':'pending'}
            except Exception as error:
                finished[name]={'status':'failed','error':f'{type(error).__name__}: {error}'}
            data={'updated_at':datetime.now(timezone.utc).isoformat(),'expected':len(expected),'checked':len(finished),'runs':finished}
            (args.output/'ledger.json').write_text(json.dumps(data,indent=2)+'\n')
            print('VIDEO_AUDIT',name,finished[name]['status'],flush=True)
        if len(finished)<len(expected):time.sleep(8)


if __name__=='__main__':main()
