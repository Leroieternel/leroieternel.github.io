"""Inspect existing measured liquid states without advancing physics.

Native cup and liquid geometry retain their original materials and scale.
Fetch is hidden explicitly to reveal droplets occluded in the camera recording.
These are labelled state reconstructions, never new physical outcomes.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np


def render(run, output, times):
    import imageio.v2 as imageio
    result=json.loads((run/'result.json').read_text())
    archive=run/'liquid-particles.json.gz'
    particles=json.load(gzip.open(archive,'rt'))
    trace=json.loads((run/'trace.json').read_text())
    root=Path(__file__).resolve().parent
    for name,digest in result['simulation_code_sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    from simulation.run_episode import Episode,og
    import torch
    print('Initializing recorded-state inspection',flush=True)
    ep=Episode('neiss_11868',result['variant'],output/'renderer-work','physical',
               realistic=True,native=True,draft=True,physics_only=True)
    try:
        from pxr import UsdGeom
        from simulation.preview_native import camera
        before=og.sim.current_time
        with og.sim.editing_usd():UsdGeom.Imageable(ep.robot.prim).MakeInvisible()
        output.mkdir(parents=True,exist_ok=True)
        shots=[]
        for time in times:
            frame=min(particles['frames'],key=lambda f:abs(f['t']-time))
            assert abs(frame['t']-time)<1e-5,'Require an actual recorded particle frame'
            state=min(trace,key=lambda s:abs(s['t']-time))
            assert abs(state['t']-time)<1/30
            pos=np.asarray(state['object']['p'])
            ep.obj.set_position_orientation(position=torch.tensor(pos,dtype=torch.float32),
                orientation=torch.tensor(state['object']['q'],dtype=torch.float32))
            ep.robot.set_position_orientation(position=torch.tensor(state['robot']['p'],dtype=torch.float32),
                orientation=torch.tensor(state['robot']['q'],dtype=torch.float32))
            ep.robot.set_joint_positions(torch.tensor(state['joints'],dtype=torch.float32))
            points=np.asarray(frame['positions_m'],dtype=np.float32)
            ep.liquid.surface.update(points)
            eye=pos+[.12,.30,.10];target=pos+[0,0,-.01]
            camera(eye,target,28)
            for _ in range(32):og.sim.render()
            assert og.sim.current_time==before,'Inspection must not advance physics'
            rgb=og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3]
            filename=f'spill-state-{round(time*1000):05d}.jpg'
            imageio.imwrite(output/filename,rgb)
            escaped=np.asarray(particles['first_escape_time_s'])
            escaped=(escaped>=0)&(escaped<=time)
            near=escaped&(np.linalg.norm(points[:,:2]-pos[:2],axis=1)<.13)&(points[:,2]>pos[2]-.22)
            shots.append({'time_s':time,'image':filename,'camera_eye_m':eye.tolist(),
                'camera_target_m':target.tolist(),'camera_focal_mm':28,
                'escaped_particles_near_cup':int(near.sum()),
                'cumulative_spilled_ml':state['metrics']['spilled_volume_ml'],
                'floor_ml':state['metrics']['floor_liquid_ml'],
                'image_sha256':hashlib.sha256((output/filename).read_bytes()).hexdigest()})
            print('Rendered',filename,flush=True)
        metadata={'kind':'unoccluded_recorded_state_inspection','shots':shots,
            'caption':'Recorded particle states, with Fetch hidden and the camera moved closer. Original liquid size and material. These are state reconstructions, not additional camera recordings.',
            'robot_hidden':True,'liquid_geometry_scale':1,'original_material':True,
            'physics_advanced':False,'interpolated_states':False,
            'source_particle_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'source_trace_sha256':hashlib.sha256((run/'trace.json').read_bytes()).hexdigest(),
            'renderer_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'calibration_status':'uncalibrated'}
        (output/'spill-inspection.json').write_text(json.dumps(metadata,indent=2)+'\n')
    finally:og.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--times',type=float,nargs='+',default=[20,26,27.5,28])
    a=p.parse_args();render(a.run,a.output,a.times)
