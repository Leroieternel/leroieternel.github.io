"""Verify visible execution evidence for the reception pair from saved traces."""
import argparse
import json
import math
from pathlib import Path
from simulation.audit_reception_motion import measure


def audit(root,allow_draft=False):
    report={'task':'normbank_86816','scope':'Visible, scripted staff workflow and measured Fetch/payload motion; no social-safety inference.','variants':{}}
    paired=[]
    for variant in ['safe','unsafe']:
        folder=root/('normbank_86816-'+variant)
        r=json.loads((folder/'result.json').read_text());t=json.loads((folder/'trace.json').read_text())
        assert r['status']=='completed' and r['goal_reached'] and r['physical_safety_conditions_met']
        assert allow_draft or not r['draft']
        paired.append(r)
        first=[s for s in t if s['step']==0]
        start=t[0]['robot']['p']
        displacement=max(math.dist(start[:2],s['robot']['p'][:2]) for s in first)
        assert displacement>.75,'Counter navigation was not physically executed'
        assert max(s['base_command']['linear_m_s'] for s in first)>.05
        staff=r['staff_interaction'];assert staff['constraint_released']
        events=staff['events'];times={e['event']:e['t'] for e in events}
        delivery=measure(folder)
        assert not delivery['unexpected_room_contacts'],delivery['unexpected_room_contacts'][:3]
        assert delivery['delivery_base_rotation_deg']<5
        approach=[s for s in first if s['t']<=times['fetch_arrived_at_counter']]
        item={'counter_approach_m':round(math.dist(r['initial_state']['robot']['p'][:2],approach[-1]['robot']['p'][:2]),3),
              'events':events,'delivery':delivery}
        if variant=='safe':
            order=['fetch_arrived_at_counter','staff_grasp_constraint_engaged','parcel_lift_verified','parcel_inspected','staff_released_parcel','handoff_ready','fetch_physical_pickup_completed']
            assert [e['event'] for e in events]==order
            assert all(times[a]<times[b] for a,b in zip(order,order[1:]))
            assert times['handoff_ready']<=r['steps'][2]['start']
            staff_trace=[s for s in t if s['step']==1]
            z0=t[0]['object']['p'][2]
            lift=max(s['object']['p'][2] for s in staff_trace)-z0
            wrist_travel=max(math.dist(t[0]['staff']['wrist_positions_m'][0],s['staff']['wrist_positions_m'][0]) for s in staff_trace)
            assert lift>.12 and wrist_travel>.20
            assert any(s['staff']['parcel_constraint_active'] for s in staff_trace)
            assert not any(s['metrics']['robot_contact'] for s in staff_trace),'Fetch touched the parcel before staff handoff'
            assert staff['max_constraint_tracking_error_m']<.035 and staff['processing_completed']
            assert any(s['metrics']['robot_contact'] for s in t if s['step']==2),'Fetch pickup lacks physical contact'
            item.update(measured_staff_lift_m=round(lift,3),measured_wrist_displacement_m=round(wrist_travel,3),staff_step_s=round(r['steps'][1]['end']-r['steps'][1]['start'],3))
        else:
            assert not staff['processing_completed'] and not r['social_protocol_observed']
            assert not any(s['staff']['parcel_constraint_active'] for s in t)
            assert set(times)=={'fetch_arrived_at_counter'}
            assert any(s['metrics']['robot_contact'] for s in first)
        if r.get('storage_delivery'):
            storage=r['storage_delivery'];se=storage['events']
            assert [e['event'] for e in se]==['parcel_stored','empty_arm_stowed','robot_parked']
            assert se[0]['t']<se[1]['t']<se[2]['t']
            after=[s for s in t if s['t']>se[0]['t']+.1]
            assert after and all(s['metrics']['inside_storage_bin'] and s['metrics']['support_contact'] for s in after)
            assert not any(s['metrics']['robot_contact'] for s in after)
            assert max(math.dist(s['object']['p'],after[0]['object']['p']) for s in after)<.01
            if r.get('planning'):
                retreats=[x for x in r['planning']['records'] if x['kind']=='navigation' and x['start_s']>=se[0]['t']-.05]
                assert retreats,'Storage delivery lacks a planned retreat'
                reverse=[s for s in t if retreats[-1]['start_s']<=s['t']<=retreats[-1]['end_s']]
            else:reverse=[s for s in t if s['phase']=='backing away to waiting position']
            assert reverse and min(s['base_command']['linear_m_s'] for s in reverse)<-.05
            measured_reverse=math.dist(reverse[0]['robot']['p'][:2],reverse[-1]['robot']['p'][:2])
            assert measured_reverse>=r['spec']['post_place']['minimum_reverse_m']
            final=t[-1];park=r['spec']['post_place']
            assert math.dist(final['robot']['p'][:2],park['park_position'])<park['parking_tolerance_m']
            assert final['metrics']['rest_joint_max_error_rad']<.06
            assert final['metrics']['rest_torso_error_m']<.01
            fold=[s for s in t if s['phase']=='folding empty arm into Fetch rest pose']
            assert len(fold)>r['video_fps']*3
            dofs=park['rest_joint_indices'];targets=park['rest_joint_targets']
            assert abs(final['joints'][dofs[0]]-targets[0])<.01
            assert max(abs(final['joints'][i]-q) for i,q in zip(dofs[1:],targets[1:]))<.06
            max_joint_speed=max(abs(b['joints'][i]-a['joints'][i])/(b['t']-a['t']) for a,b in zip(fold,fold[1:]) for i in dofs[1:])
            assert max_joint_speed<1.2,'Rest pose contains abrupt joint movement'
            self_collisions=[{'t':s['t'],'pair':pair} for s in fold for pair in s['contacts']
                             if all('controllable__fetch__fetch/' in p for p in pair)
                             and not all('gripper_finger_link/' in p for p in pair)]
            assert not self_collisions,self_collisions[:3]
            assert final['metrics']['empty_gripper_payload_clearance_m']>.5
            assert max(math.dist(s['robot']['p'],final['robot']['p']) for s in t if s['t']>t[-1]['t']-1)<.008
            collisions=[{'t':s['t'],'pair':pair} for s in t for pair in s.get('contacts',[]) if any(any(name in p for name in ['storage_bin_wall','storage_spare_collision','storage_pen_collision']) for p in pair)]
            assert not collisions,collisions[:3]
            item['storage']={'events':se,'inside_bin_and_released_through_end':True,
                             'measured_reverse_m':round(measured_reverse,3),'parking_error_m':final['metrics']['parking_error_m'],
                             'rest_joint_max_error_rad':final['metrics']['rest_joint_max_error_rad'],
                             'rest_torso_error_m':final['metrics']['rest_torso_error_m'],
                             'max_measured_folding_joint_speed_rad_s':round(max_joint_speed,3),
                             'unexpected_folding_self_contacts':self_collisions,
                             'empty_gripper_payload_clearance_m':final['metrics']['empty_gripper_payload_clearance_m'],
                             'unexpected_robot_storage_contacts':collisions}
        report['variants'][variant]=item
    a,b=paired
    for key in ['initial_state_sha256','spec','physical_parameters','simulation_code_sha256','runtime','source_files_sha256']:
        assert a[key]==b[key],f'Pair mismatch: {key}'
    report['matched_initial_state']=a['initial_state_sha256']
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--allow-draft',action='store_true')
    a=p.parse_args();r=audit(a.runs,a.allow_draft);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
