"""Download the public CC0 assets used by the furnished simulation scenes."""
import hashlib
import json
import urllib.request
from pathlib import Path
from simulation.runtime import RUNTIME, ROOT


def request(url):
    return urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'DESPITE research scene pilot'}), timeout=120)


def prepare():
    manifest=[]
    for asset,kind in [('wood_floor','material'),('large_floor_tiles_02','material'),
                       ('cotton_jersey','material'),('white_plaster_02','material'),('walnut_veneer','material'),
                       ('throw_pillows_01','model'),
                       ('modern_wooden_cabinet','model'),('side_table_01','model'),('modern_coffee_table_01','model')]:
        with request('https://api.polyhaven.com/files/'+asset) as response:
            metadata=json.load(response)
        root=RUNTIME/('materials' if kind=='material' else 'models')/asset
        if kind=='material':
            files={}
            for channel in ['Diffuse','nor_gl','Rough']:
                choices=metadata[channel]['2k']; entry=choices.get('jpg') or choices['png']
                files[channel+'.'+entry['url'].rsplit('.',1)[-1]]=entry
        else:
            entry=metadata['usd']['2k']['usd']
            files={entry['url'].rsplit('/',1)[-1]:entry,**entry.get('include',{})}
        for relative,entry in files.items():
            dest=root/relative; dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists() or hashlib.md5(dest.read_bytes()).hexdigest()!=entry['md5']:
                with request(entry['url']) as response: payload=response.read()
                assert hashlib.md5(payload).hexdigest()==entry['md5'], 'Download checksum mismatch'
                dest.write_bytes(payload)
            manifest.append({'asset':asset,'path':str(dest.relative_to(RUNTIME)), 'url':entry['url'],
                             'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'license':'CC0-1.0'})
        print('Ready:',asset,flush=True)
    (ROOT/'simulation/visual_assets.json').write_text(json.dumps(manifest,indent=2)+'\n')


if __name__=='__main__':prepare()
