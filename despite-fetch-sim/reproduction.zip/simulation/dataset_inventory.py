"""Read-only census of DESPITE's archived task declarations and action effects.

Never executes task code and never extracts archive paths. Raw symbol counts
are not a physical-object ontology. Run from the repository root.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import tarfile


def sexpr(text):
    tokens = re.findall(r"\(|\)|[^\s()]+", re.sub(r";[^\n]*", "", text).lower())
    root, stack = [], []
    current = root
    for token in tokens:
        if token == "(":
            new = []
            current.append(new)
            stack.append(current)
            current = new
        elif token == ")":
            if not stack:
                raise ValueError("Unmatched closing parenthesis")
            current = stack.pop()
        else:
            current.append(token)
    if stack or len(root) != 1:
        raise ValueError("Unbalanced or multiple PDDL roots")
    return root[0]


def text_of(expr):
    return "(" + " ".join(map(text_of, expr)) + ")" if isinstance(expr, list) else str(expr)


def typed(items):
    result, pending = [], []
    index = 0
    while index < len(items):
        value = items[index]
        if value == "-":
            if index + 1 == len(items):
                raise ValueError("Missing type")
            result.extend((name, text_of(items[index + 1])) for name in pending)
            pending = []
            index += 2
        else:
            pending.append(text_of(value))
            index += 1
    return result + [(name, "object") for name in pending]


def sections(expr, key):
    return [v for v in expr if isinstance(v, list) and v and v[0] == key]


def effects(expr, sign="add", condition=None):
    """Only effect targets; WHEN guards and quantified parameters are excluded."""
    if not expr or not isinstance(expr, list):
        return []
    h = expr[0]
    if h in ("and", "or"):
        return [v for child in expr[1:] for v in effects(child, sign, condition)]
    if h == "not":
        return effects(expr[1], "delete", condition)
    if h == "when":
        return effects(expr[2], sign, text_of(expr[1]))
    if h in ("forall", "exists"):
        return effects(expr[2], sign, condition)
    if h in ("assign", "increase", "decrease", "scale-up", "scale-down"):
        target = expr[1]
        return [{"symbol": target[0], "arguments": target[1:], "operation": h,
                 "condition": condition, "effect": text_of(expr)}]
    if h == "at" and len(expr) == 3 and expr[1] in ("start", "end"):
        return effects(expr[2], sign, condition)
    return [{"symbol": h, "arguments": expr[1:], "operation": sign,
             "condition": condition, "effect": text_of(expr)}]


def parse_task(files, split, task_id):
    metadata = json.loads(files["metadata.json"])
    d, p = (sexpr(files[n].decode()) for n in ("domain.pddl", "problem.pddl"))
    objects = {}
    for origin, expr, key in (("constant", d, ":constants"), ("object", p, ":objects")):
        for s in sections(expr, key):
            for name, typename in typed(s[1:]):
                if name in objects and objects[name]["type"] != typename:
                    raise ValueError(f"Conflicting object types for {name}")
                objects[name] = {"name": name, "type": typename, "origin": origin}
    predicates, functions = [], []
    for key, dest in ((":predicates", predicates), (":functions", functions)):
        for s in sections(d, key):
            for dec in s[1:]:
                if isinstance(dec, list) and dec:
                    dest.append({"name": dec[0], "parameters": typed(dec[1:]), "declaration": text_of(dec)})
    actions = []
    for key in (":action", ":durative-action"):
        for a in sections(d, key):
            attrs = dict(zip(a[2::2], a[3::2]))
            actions.append({"name": a[1], "parameters": typed(attrs.get(":parameters", [])),
                            "effects": effects(attrs.get(":effect", []))})
    plan_actions = {k: [re.findall(r"[^\s()]+", a)[0].lower()
                       for a in re.findall(r"\([^()]+\)", v)]
                    for k, v in metadata["reference_feasible_plans"].items()}
    changed = sorted({e["symbol"] for a in actions for e in a["effects"]})
    return {"id": task_id, "split": split, "source": task_id.split("_")[0],
            "metadata": metadata, "objects": list(objects.values()),
            "predicates": predicates, "functions": functions, "actions": actions,
            "changed_symbols": changed, "plan_actions": plan_actions,
            "files_sha256": {n: hashlib.sha256(raw).hexdigest() for n, raw in files.items()},
            "archive_path": f"tasks/full/{split}/{task_id}"}


def aggregate(tasks):
    raw_names = {o["name"] for t in tasks for o in t["objects"]}
    predicates = {p["name"] for t in tasks for p in t["predicates"]}
    changed = {p for t in tasks for p in t["changed_symbols"]}
    boolean_changed = {e["symbol"] for t in tasks for a in t["actions"]
                       for e in a["effects"] if e["operation"] in ("add", "delete")}
    changes = {(e["symbol"], e["operation"]) for t in tasks for a in t["actions"] for e in a["effects"]}
    return {"tasks": len(tasks), "entity_declarations": sum(len(t["objects"]) for t in tasks),
            "unique_entity_names": len(raw_names), "unique_type_names": len({o['type'] for t in tasks for o in t['objects']}),
            "predicate_declarations": sum(len(t['predicates']) for t in tasks),
            "unique_predicate_names": len(predicates), "unique_changed_symbols": len(changed),
            "unique_changed_boolean_names": len(boolean_changed), "unique_effect_operation_pairs": len(changes),
            "unique_action_names": len({a['name'] for t in tasks for a in t['actions']}),
            "action_declarations": sum(len(t['actions']) for t in tasks),
            "effect_literals": sum(len(a['effects']) for t in tasks for a in t['actions']),
            "zero_argument_predicate_declarations": sum(not p['parameters'] for t in tasks for p in t['predicates']),
            "numeric_function_declarations": sum(len(t['functions']) for t in tasks),
            "empty_object_tasks": sum(not t['objects'] for t in tasks)}


def census(archive, output):
    output.mkdir(parents=True, exist_ok=True)
    buckets = defaultdict(dict)
    file_counts = Counter()
    sampled = defaultdict(dict)
    with tarfile.open(archive, 'r|gz') as tar:
        for m in tar:
            if not m.isfile():
                continue
            a = m.name.split('/')
            if len(a) == 5 and a[:2] == ['tasks', 'full'] and a[-1] in ('metadata.json', 'domain.pddl', 'problem.pddl'):
                buckets[a[2], a[3]][a[-1]] = tar.extractfile(m).read()
                file_counts[a[-1]] += 1
            elif a[:2] == ['tasks', 'sampled'] and a[-1] == 'metadata.json':
                raw = tar.extractfile(m).read()
                sampled['/'.join(a[:-2])][a[-2]] = (hashlib.sha256(raw).hexdigest(), json.loads(raw))
    tasks, errors = [], []
    for (split, task_id), files in sorted(buckets.items()):
        try:
            tasks.append(parse_task(files, split, task_id))
        except Exception as e:
            errors.append({'id': task_id, 'split': split, 'error': repr(e)})
    ids = [t['id'] for t in tasks]
    assert len(ids) == len(set(ids)), 'Duplicate task IDs across full splits require explicit resolution'
    summaries = {'all': aggregate(tasks)}
    for split in ('easy', 'hard'):
        summaries[split] = aggregate([t for t in tasks if t['split'] == split])
    for source in sorted({t['source'] for t in tasks}):
        summaries[source] = aggregate([t for t in tasks if t['source'] == source])
        summaries[source + '_hard'] = aggregate([t for t in tasks if t['source'] == source and t['split'] == 'hard'])
    byid = {t['id']: t for t in tasks}
    sample_audit = {}
    for label, items in sampled.items():
        sample_audit[label] = {'count': len(items), 'absent_from_full': [i for i in items if i not in byid],
            'metadata_bytes_differ': [i for i, (sha, _) in items.items() if i in byid and byid[i]['files_sha256']['metadata.json'] != sha],
            'metadata_content_differs': [i for i, (_, obj) in items.items() if i in byid and byid[i]['metadata'] != obj]}
    report = {'archive': str(archive.resolve()), 'archive_sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
        'scope': 'tasks/full/easy + tasks/full/hard, deduplicated by source task ID; sampled excluded',
        'summaries': summaries, 'parse_errors': errors, 'source_file_counts': dict(file_counts),
        'sampled_subset_audit': sample_audit,
        'definitions': {'entity_declarations': 'One PDDL constant or problem-object per task; includes physical objects, humans, locations and abstract symbols.',
            'unique_entity_names': 'Exact lower-case PDDL identifiers across tasks, without synonym merging; not 3D asset categories.',
            'unique_changed_symbols': 'Distinct predicate/function target names occurring in any domain action effect; possible symbolic updates, not observed physical transitions.',
            'unique_effect_operation_pairs': 'Distinct target-name and add/delete/numeric-operation pairs; duplicate wording is not canonicalized.'}}
    (output/'tasks.json').write_text(json.dumps(tasks, ensure_ascii=False, separators=(',', ':')))
    (output/'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'summaries':summaries,'errors':errors,'sampled':sample_audit},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    census(args.archive,args.output)
