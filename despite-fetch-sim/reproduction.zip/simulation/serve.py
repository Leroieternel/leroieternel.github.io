"""Local preview with byte-range support for interactive MP4 seeking."""
import argparse
import functools
import re
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class RangeHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def send_head(self):
        self.remaining=None
        file=Path(self.translate_path(self.path))
        value=self.headers.get('Range')
        if not value or not file.is_file():
            return super().send_head()
        size=file.stat().st_size
        match=re.fullmatch(r'bytes=(\d*)-(\d*)',value)
        if not match or not any(match.groups()) or size==0:
            self.send_error(416,'Unsupported byte range');return None
        left,right=match.groups()
        start=int(left) if left else max(0,size-int(right))
        end=min(size-1,int(right)) if left and right else size-1
        if start>=size or start>end:
            self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.end_headers();return None
        stream=file.open('rb');stream.seek(start);self.remaining=end-start+1
        self.send_response(206)
        self.send_header('Content-Type',self.guess_type(str(file)))
        self.send_header('Content-Length',str(self.remaining))
        self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers();return stream

    def copyfile(self,source,outputfile):
        if self.remaining is None:
            return super().copyfile(source,outputfile)
        while self.remaining:
            data=source.read(min(1024*1024,self.remaining))
            if not data:break
            outputfile.write(data);self.remaining-=len(data)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',type=int,default=8765)
    p.add_argument('--directory',type=Path,default=Path('.runtime/publish'))
    args=p.parse_args()
    handler=functools.partial(RangeHandler,directory=str(args.directory.resolve()))
    print(f'http://127.0.0.1:{args.port}/despite-fetch-sim/',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),handler).serve_forever()
