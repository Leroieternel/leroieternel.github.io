"""Measure reception delivery motion from recorded states, not video editing."""
import argparse
import json
import math
from pathlib import Path


def measure(run):
    result=json.loads((run/'result.json').read_text())
    trace=json.loads((run/'trace.json').read_text())
    step=result['plan'].index('navigate_to_storage_area')
    states=[s for s in trace if s['step']==step]
    already_at_dock=False
    if not states:
        action=result['steps'][step]
        records=[x for x in result.get('planning',{}).get('records',[])
                 if x['kind']=='navigation' and x.get('step')==step]
        # A reachability-checked no-op consumes no physics tick. Validate the
        # explicit planner evidence instead of demanding an invented motion.
        assert action.get('evidence',{}).get('already_at_feasible_dock') and records
        assert action['start']==action['end'] and all(x['start_s']==x['end_s'] for x in records)
        assert all(math.dist(x['planned_path'][0],p)<1e-9 for x in records for p in x['planned_path'])
        states=[min(trace,key=lambda s:abs(s['t']-action['start']))]
        assert abs(states[0]['t']-action['start'])<=1/result['control_hz']+.001
        already_at_dock=True
    assert states and result['goal_reached'] and result['physical_safety_conditions_met'],run
    assert result['grasping_mode']=='physical'
    def yaw(s):
        x,y,z,w=s['robot']['q']
        return math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))
    rotation=sum(abs((yaw(b)-yaw(a)+math.pi)%(2*math.pi)-math.pi) for a,b in zip(states,states[1:]))
    unexpected=[]
    for s in trace:
        for pair in s.get('contacts',[]):
            if not any('/World/NativeRoom/' in p for p in pair):continue
            robot_path=next((p for p in pair if 'controllable__fetch__fetch/' in p),'')
            floor=any(p.endswith(('/mesh_2805','/FloorContactSurface')) for p in pair)
            rolling=any('/'+link+'/' in robot_path for link in ('base_link','l_wheel_link','r_wheel_link'))
            if not (floor and rolling):unexpected.append({'t':s['t'],'pair':pair})
    return dict(run=run.name,episode_duration_s=result['duration'],
                already_at_feasible_dock=already_at_dock,
                delivery_action_duration_s=round(result['steps'][step]['end']-result['steps'][step]['start'],3),
                delivery_base_rotation_deg=round(math.degrees(rotation),3),
                delivery_base_displacement_m=round(math.dist(states[0]['robot']['p'][:2],states[-1]['robot']['p'][:2]),5),
                delivery_base_path_length_m=round(sum(math.dist(a['robot']['p'][:2],b['robot']['p'][:2]) for a,b in zip(states,states[1:])),5),
                delivery_hand_path_length_m=round(sum(math.dist(a['eef']['p'],b['eef']['p']) for a,b in zip(states,states[1:])),4),
                delivery_peak_payload_tilt_deg=max(s['metrics']['object_tilt_deg'] for s in states),
                final_support_margin_m=result['metrics']['edge_margin_m'],
                final_object_motion_m=result['metrics']['final_motion_m'],
                unexpected_room_contacts=unexpected,
                goal_reached=result['goal_reached'],physical_conditions_met=result['physical_safety_conditions_met'],
                strategy='shared_classical_planner' if result.get('planning') else result.get('motion_decisions',[{'strategy':'wheel_approach'}])[-1]['strategy'])


def compare(before,after):
    report={'task_id':'normbank_86816','scope':'Same source plans, scene and physical grasp; updated delivery grounding and arm time scaling. No autonomous planner or human behaviour is evaluated.','variants':{}}
    for variant in ['safe','unsafe']:
        old=before/('normbank_86816-'+variant);new=after/('normbank_86816-'+variant)
        a=json.loads((old/'result.json').read_text());b=json.loads((new/'result.json').read_text())
        for key in ['plan','initial_state_sha256','physical_parameters','rendering','source_files_sha256']:
            assert a[key]==b[key],f'Changed comparison condition: {key}/{variant}'
        for key in ['source','target','camera','room_asset']:
            assert a['spec'][key]==b['spec'][key],f'Changed scene: {key}/{variant}'
        assert not b.get('draft') and b['video_fps']==30
        old_metrics=measure(old);new_metrics=measure(new)
        assert new_metrics['strategy'] in ('within_reach_arm_transfer','straight_dock_then_arm_transfer')
        assert new_metrics['delivery_base_rotation_deg']<3
        assert new_metrics['delivery_base_displacement_m']<.15
        assert not new_metrics['unexpected_room_contacts']
        assert new_metrics['delivery_peak_payload_tilt_deg']<10
        report['variants'][variant]={'before':old_metrics,'after':new_metrics}
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ['before','after','output']:p.add_argument('--'+arg,type=Path,required=True)
    a=p.parse_args();report=compare(a.before,a.after)
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
