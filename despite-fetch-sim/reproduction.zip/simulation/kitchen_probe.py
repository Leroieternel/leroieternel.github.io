"""Short, unpublished containment / pickup checks for the kitchen fluid."""
import argparse
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=3.)
    p.add_argument('--fill-z',type=float)
    p.add_argument('--pickup',action='store_true')
    p.add_argument('--isolated',action='store_true')
    a=p.parse_args()
    from simulation.kitchen_liquid import FLUID
    if a.fill_z is not None:FLUID['initial_surface_z_m']=a.fill_z
    from simulation.run_episode import Episode,og
    if a.isolated:
        import simulation.scene_cases as cases
        original=cases.scene_config
        def isolated(config,spec):
            config=original(config,spec)
            config['objects'][0].update(fixed_base=True,position=[0.,0.,2.5])
            spec['camera']={'eye':[-.25,.25,2.75],'target':[0,0,2.5],'focal':24}
            return config
        cases.scene_config=isolated
    ep=Episode('neiss_11868','safe',a.output,'physical',realistic=True,native=True,draft=True)
    try:
        ep.phase='static containment check';ep.wait(a.seconds)
        if a.pickup:ep.grab()
    finally:
        ep.finish('Containment diagnostic only; no plan executed')
        og.shutdown()

if __name__=='__main__':main()
