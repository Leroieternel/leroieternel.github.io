# DESPITE: Fetch execution pilot

Two original safe reference plans and five additional safe/unsafe plan pairs
from **hard-1044** are executed by Fetch with physical finger contact in
**Isaac Sim 6.0.1.0 + OmniGibson 3.9.3**. The English website synchronizes
recorded RTX video, original plan steps and measured physical state.

This is a selected-case feasibility pilot, not an LLM safety-rate benchmark.
No LLM generates these plans. Object poses are available to the controller as
oracle state. The robot and task objects are not teleported after initialization.

The new **native Genie Sim apartment** variant, including the refined can label,
is documented in [NATIVE_ASSETS.md](NATIVE_ASSETS.md). Use `--native` for its
original room materials and 30 fps recordings. The furnished-scene workflow
below remains available for comparison and records at 15 fps.

## Runtime setup and earlier furnished scenes

Tested on Ubuntu 24.04, NVIDIA RTX 4090 24 GB, driver 580.178.04, Python 3.12.
Allow approximately 100 GB for the isolated runtime and research assets. Run
from the repository root with Conda available. Review NVIDIA and BEHAVIOR asset
license terms before installing. BEHAVIOR assets and their key remain local.

```bash
bash simulation/setup_runtime.sh
.runtime/isaac601/bin/python -m simulation.prepare_visual_assets
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --realistic --output simulation/runs/neiss_2888-interiors-final
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task alfred_2757 --realistic --output simulation/runs/alfred_2757-interiors-final
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-interiors-final \
  --sponge simulation/runs/alfred_2757-interiors-final
python3 -m simulation.serve
```

Open `http://localhost:8765/despite-fetch-sim/`. Installation prompts for the
BEHAVIOR research asset license unless its key is already installed. The
runtime setup pins upstream commit `b544acbbb76b461349bcba21f93b870b11da6608`
and applies the included USD editing-context patch for physics materials.
Isaac's dependency metadata and OmniGibson's newer dependencies conflict on
some package pins; this combination was verified by actual episode execution,
not by a clean `pip check`. Do not silently substitute Isaac 6.2.

The original semantic validator uses the DESPITE project's PDDL dependencies.
In an environment with the repository requirements installed, run:

```bash
python -m simulation.validate_plans
```

The original safe references score 2 and their unsafe alternatives score 1.
Frozen task files, archive SHA-256 and extraction provenance are in `tasks/`.
The source archive is the DESPITE dataset's `tasks.tar.gz` (not packaged here).
`prepare_tasks.py` can re-extract the selected tasks from that archive.

## What is measured

| Case | Plan | Physical checks |
| --- | --- | --- |
| `neiss_2888` | Grasp bottle → navigate → place at centre | Destination contact, stable final position, <15° final tilt, support footprint, ≥10 cm edge margin |
| `alfred_2757` | Grasp sponge → approach pump bottle → inspect → navigate → place | Destination contact, stable final position, ≥12 cm clearance, sampled pump bottle tilt <15° |

Motor commands run at 30 Hz; PhysX runs at 120 Hz. Video and state traces are
recorded at 30 Hz in the native Genie apartment, or 15 Hz in the earlier
furnished scenes. Peak tilt means the maximum over these sampled states, not a continuous-time guarantee. The final one-second object's motion must remain below 2 cm.
Source records do not specify dimensions, mass or friction: all such parameters
are explicit assumptions in `scenes.py`, `run_episode.py` and result JSON.
A gripper lift failure, missed arm target or navigation timeout fails the run.
`build_site.py` refuses incomplete episodes. Videos contain actual simulation
frames; there is no generated-image background or composited success result.

## Scene construction

`realistic.py` builds an enclosed room with wood or ceramic PBR floor, window,
blinds, pleated curtain meshes, lighting, textured furniture and a sculpted
linen duvet. The bed, upholstered sofa, lamps and bathroom fixtures come from BEHAVIOR.
Wooden tables, a tambour-door sideboard, cushions, floor materials and textile
PBR maps come from Poly Haven. The latter are ordinary USD assets
rendered in Isaac Sim, not images pasted behind the robot.

`detail_assets.py` generates metre-scale USD bottle meshes and their convex
collision hulls together. The PET water bottle has moulded ribs, a tapered neck,
a sealed cap and a printed label. Its static visible fill is approximately
170 mL, consistent with the assumed 0.18 kg combined mass. This fill does not
simulate fluid motion. The soap bottle has a separate metal pump and nozzle;
the nozzle has its own collider, and the clearance calculation conservatively
uses a 5.5 cm radial footprint. Labels are deterministic typographic artwork.

Fetch retains the native robot geometry and articulation. Its existing UVs are
used to distinguish shell, rubber and lens finishes; exposed base metal has a
separate material. The native vanity's disconnected faucet geometry is replaced
by a smooth curved chrome spout, mixer and aerator. Toggle-button markers are
hidden in the display. The faucet and mixer mount to the measured counter surface: 64 perimeter
samples verify both bases are supported, with a 0.5 mm seating overlap. A low
side view exposes the mounting joint, and result JSON records the surface fit.
These faucet parts are decorative, outside both plans.
The floor geometry and texture assets are unchanged.

Broad overcast window light and ceiling/wall bounce lights replace hard light
accents. Imported lamp intensity overrides are suppressed; ceramic table lamps use
controlled warm bulbs and downward area lights. Extra ambient occlusion is
disabled. A low-intensity, unshadowed dome and two bounce fills approximate
indirect room illumination; the window, ceiling and practical lights retain
shadows. These artistic lighting settings do not constitute photometric validation.
Wall microstructure, textile weave, wood grain and roughness maps
use explicit UVs and appropriate material scales. Non-renderable rig guide
curves from the cabinet asset are hidden. All images, including
the site's enlarged detail views, are actual RTX renders. Detail images show
the settled initial state, while the video and state trace remain synchronized.
Results record source-code hashes, mass, contact offsets and visual revision.

The short Fetch fingers pinch the bottle's neck with a 10 cm height offset.
The former cylinder's grasp target must not be reused for the tapered bottle:
a target below its shoulder can make the palm tip the bottle. The original
three-action reference plan remains unchanged; the geometric motor skill is
updated and the complete episode must be rerun.

Task supports use explicitly sized collision proxies. Decorative furniture
uses visual meshes; simplified sofa, table, sideboard and lamp colliders keep occupied space
explicit. These are pilot scenes inspired by the tasks, not reconstructions
of the original NEISS incident or ALFRED environment. Appearance alone is not
physical validation. No liquid dynamics, human body, injury model, learned
perception or real-world transfer is evaluated.

The Genie Sim reference informed room presentation and lighting. These runs
use Fetch and OmniGibson, not the Genie Sim simulator. Earlier local diagnostic
runs used primitive rooms; only the final furnished runs should be published.

## Assets and attribution

- [BEHAVIOR-1K](https://behavior.stanford.edu/): textured bed, upholstered sofa,
  plant, rug, lamps, wall art, bathroom vanity and toilet. Its research asset
  license governs these files. Meshes, textures and decryption keys are not
  redistributed with the website or reproduction archive.
- [Throw Pillows 01](https://polyhaven.com/a/throw_pillows_01), Serhii Khromov.
- [Wood Floor](https://polyhaven.com/a/wood_floor), Dimitrios Savva; [Large Floor Tiles 02](https://polyhaven.com/a/large_floor_tiles_02), Rob Tuytel.
- [Modern Wooden Cabinet](https://polyhaven.com/a/modern_wooden_cabinet), Patrik Pangerl; [Side Table 01](https://polyhaven.com/a/side_table_01), James Ray Cock; [Modern Coffee Table 01](https://polyhaven.com/a/modern_coffee_table_01), Amin.
- [Cotton Jersey](https://polyhaven.com/a/cotton_jersey), colormass and Rico Cilliers; [White Plaster 02](https://polyhaven.com/a/white_plaster_02), Rob Tuytel; [Walnut Veneer](https://polyhaven.com/a/walnut_veneer), Jenelle van Heerden.
- All Poly Haven assets are [CC0](https://polyhaven.com/license).
  `visual_assets.json` records exact download URLs and SHA-256 values.
- Room architecture, curtains, duvet, bottle meshes, label artwork and faucet
  geometry are authored by this project. Generated asset files live under
  `.runtime/generated/details` and are regenerated from the reproduction code.
  The label renderer uses the Ubuntu `fonts-dejavu-core` fonts.

The website publishes recordings, JSON measurements, original selected task
files and reproduction code. It does not stream a live GPU simulator.


## Five paired reference-plan cases

The additional comparison uses five intact NEISS records from hard-1044:
`neiss_19378` (supply-box clearance), `neiss_24170` (placement verification),
`neiss_27998` (recipient reach), `neiss_4188` (bed contact), and `neiss_8985`
(stool disturbance). Each safe and unsafe plan is copied verbatim from its
source metadata. Both pass the original feasibility validator; their semantic
safety scores differ. These are selected controlled delivery cases, not a
representative benchmark and not evaluations of an LLM.

`pair_cases.py` declares every physical grounding, including the placement bias,
reach point, mass, path and threshold. A missing verification action retains the
same initially biased release target; the explicit oracle check corrects it.
A hazardous route supplies wheel-controller waypoints, never collision-free
teleportation. The same initial scene and logged initial poses (rounded to
5 decimal places) are checked across each pair. Plan labels never determine
measured safety outcomes. A stable low-clearance placement can complete its
task while violating the declared margin. A blocked route can terminate before
later plan actions; those actions remain visible as unexecuted.

The carton and medication bottle are pinned native Genie Sim assets. The carton
uses a documented uniform 0.85 scale to fit the Fetch parallel gripper. The
movable footstool uses BEHAVIOR-1K `footstool/sghekm`. Native room furniture
remains static: table/bed movement, patient biomechanics, liquid spilling and
injury are outside the physical model. Reach is only a declared geometric proxy.

Run physics diagnostics before expensive final captures:

```bash
.runtime/isaac601/bin/python -m simulation.run_batch --runs simulation/runs/pair-draft --draft --resume
.runtime/isaac601/bin/python -m simulation.run_batch --runs simulation/runs/plan-pairs-final --resume
.runtime/isaac601/bin/python -m simulation.build_pairs --runs simulation/runs/plan-pairs-final --output .runtime/publish/plan-pairs
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-navigation-final \
  --sponge simulation/runs/alfred_2757-clarity-final \
  --pairs .runtime/publish/plan-pairs
```

Run `python3 -m simulation.prepare_genie_assets` first to verify/download both
the apartment manifest and the additional `pair_assets.json` object manifest.
The two original runs passed to `build_site` must exist; run them with
`simulation.run_episode --native` when reproducing from a fresh checkout.

Draft captures are 10 fps and are rejected by publication. Final captures retain
30 fps native DLAA and seven additional render-only updates. One GPU process
runs at a time; the batch waits for free memory without unloading other jobs.
Each recording preserves the exact hashed simulator source under `source/`.
Published per-episode archives verify those bytes, including for older videos;
the main reproduction package contains the current complete launcher and tasks.

The original bedside route now absorbs a 12 cm lateral correction into its
approach. The previous extra short segment required a roughly 90-degree turn
and return on the differential-drive base. `audit_navigation.py` compares the
measured absolute rotation within the final 15 cm of the approach.

`build_navigation_review.py --before <original-run> --after <corrected-run>
--output <review-directory>` extracts aligned arrival clips from the two full
physical recordings. Pass that directory to `build_site --navigation-review`
to include the visual before/after audit in the published explorer.


## Three additional native rooms

`scene_cases.py` maps three more intact hard-1044 reference-plan pairs into
independently authored Genie kitchen, study and hotel reception layouts. These
are task proxies, not reconstructions of the original incident locations.

- `neiss_11868`: a cup from a kitchen counter to a side table. The
  smooth-motion action changes speed and command slew limits; both plans use the
  same waypoints. The 15° navigation-tilt limit is a mechanical pilot proxy. No
  liquid, heat, spilling or burn is simulated.
- `neiss_553`: a boxed therapy-tool proxy in a furnished study with a BEHAVIOR
  chair. Clearance is the distance from the chassis disc to the chair rectangle.
  There is no person or injury model.
- `normbank_86816`: a carton handoff on a hotel reception counter, used as a
  counter-layout proxy for the original bank-lobby task. The current revision
  visibly executes staff handling with scripted skeletal motion (see below).
  Both transfers may succeed physically; this does not
  establish social safety or reproduce the original financial context.

All navigation follows declared waypoints with closed-loop wheel control. No
language model or autonomous route search is run. Room mesh collisions and
original textures remain active. Named, invisible support overlays sit 0.3 mm
above measured native table surfaces to provide OmniGibson contact telemetry.

The reception delivery additionally supports an explicitly declared docking
region. Within 16 cm of the stop, facing the counter within 0.10 rad, and with
the requested hand target inside an 83 cm horizontal bound, the original
`navigate_to_storage_area` action can use a short straight approach followed
by an arm transfer. The forward correction reduces nominal horizontal hand
reach to 70 cm, includes the wheel stop tolerance, and must be at most 17 cm.
It uses 0.08 m/s speed and 0.12 m/s² command acceleration limits. When no
correction is needed the base stays still. Outside these bounds, the original
waypoint approach remains. This is a scene-specific docking strategy, not an
autonomous reachability or collision-free planner.
The physical IK controller must reach the hand target within 2 cm. During
the transfer, room contacts on arm links and payload clearance below 10 cm
abort the execution. Final grasp release, support contact and stability are
still checked independently.

Reception arm segments use quintic time scaling with duration selected from
0.25 m/s linear speed, 0.65 m/s² linear acceleration and 1 rad/s angular speed
bounds on the *commanded* trajectory. These are not guarantees about the
measured joint dynamics. A near-identical arm target is held instead of adding
another artificial multi-second segment. In the archived motion-only comparison,
the original plans, scene, physical grasp mode and source/destination coordinates
were unchanged. The subsequent visible-staff revision restages the shared initial
layout; both plan variants still use the same updated skills. Result JSON records the selected delivery
strategy and measured base rotation/displacement.

`audit_reception_motion.py --before <old-scene-runs> --after <new-scene-runs>
--output <report.json>` checks unchanged initial state, source/destination,
camera, mass, original plan and rendering. It requires completed physical
placements, less than 3° delivery rotation, less than 15 cm base displacement,
no unexpected robot/room contacts, and less than 10° payload tilt in delivery.
`build_reception_review.py` takes the same before/after roots and `--output`
to extract real-time delivery clips. Include that directory with
`build_site --reception-review <review-directory>` for the comparison link.

```bash
python -m simulation.prepare_scene_assets
python -m simulation.prepare_staff_asset
python -m simulation.prepare_tasks /path/to/tasks.tar.gz
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m simulation.validate_plans
.runtime/isaac601/bin/python -m simulation.run_batch \
  --runs simulation/runs/scene-diversity-final \
  --tasks neiss_11868 neiss_553 normbank_86816 --resume
.runtime/isaac601/bin/python -m simulation.build_pairs \
  --runs simulation/runs/plan-pairs-final \
  --scene-runs simulation/runs/scene-diversity-final \
  --output .runtime/publish/plan-pairs
```

The original five pairs retain their recorded source snapshots. The viewer
selects a room first, then a task, with synchronized videos, action seeking,
room-specific spatial diagrams, measured conditions and original plan strings.
`scene_assets.json` records pinned asset paths, sizes and SHA-256 hashes. Raw
third-party meshes and any BEHAVIOR decryption key are excluded from the site
and reproduction package.


### Visible reception staff handoff

The reception revision starts Fetch at `[1.35, 2.05]` metres and commands a
real approach to `[2.42, 2.05]`. The safe plan preserves its five original
actions. The unsafe `accept_object` skill includes an approach and physical
pickup, but does not trigger staff processing. Both variants share their
initial robot, parcel and staff state.

The original NVIDIA Isaac Sim `F_Business_02` skeletal character is cached by
`python -m simulation.prepare_staff_asset`. Its file hashes and source URLs
are recorded in `staff_asset.json`. Raw character geometry and textures are
excluded from the website and downloadable source archives.

Staff motion is explicit scripted two-arm skeletal IK. The actor reaches,
lifts the parcel by 15 cm, turns it for inspection, lowers it to the handoff
position, releases it, and clears both hands. During staff handling a
temporary PhysX fixed constraint connects the dynamic parcel to a kinematic
grip anchor. This is not force-controlled human grasping. Fetch subsequently
uses physical fingers, with no attachment constraint or object teleportation.
The processing flag is set only after lift, placement and hand clearance
checks; the trace records staff wrist positions and grasp-constraint state.
No social interpretation, human decisions, or actual financial transaction
is modelled.

Fetch starts above the floor and settles under gravity before the plan starts.
The native floor mesh has 1 mm decorative tile bevels that snag the factory
chassis collision shape. Its visual geometry is retained, but its collision
surface is a continuous box at the measured native tile-top height, with the
same XY bounds. This assumption is recorded as `native_scene.floor_collision_proxy`.
Walls, furniture, chassis and wheel collisions remain active. The robot moves
only through its wheel and arm controllers during the plan.

`python -m simulation.audit_staff_handoff --runs <paired-run-root> --output
<report.json>` verifies actual approach distance, staff wrist travel, dynamic
parcel lift, release-before-pickup, physical Fetch contact, final support,
absence of unexpected robot/room contacts, and identical pairing conditions.
The earlier motion-only comparison remains an explicitly labelled archive;
its initial scene predates the visible staff workflow.
