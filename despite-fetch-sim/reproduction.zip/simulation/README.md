# DESPITE: Fetch execution pilot

Two original safe reference plans from **hard-1044** are executed by Fetch with
physical finger contact in **Isaac Sim 6.0.1.0 + OmniGibson 3.9.3**. The static
English website synchronizes recorded RTX video, plan steps and physical state.

This is a selected-case feasibility pilot, not an LLM safety-rate benchmark.
No LLM generates these plans. Object poses are available to the controller as
oracle state. The robot and task objects are not teleported after initialization.

## Reproduce

Tested on Ubuntu 24.04, NVIDIA RTX 4090 24 GB, driver 580.178.04, Python 3.12.
Allow approximately 100 GB for the isolated runtime and research assets. Run
from the repository root with Conda available. Review NVIDIA and BEHAVIOR asset
license terms before installing. BEHAVIOR assets and their key remain local.

```bash
bash simulation/setup_runtime.sh
.runtime/isaac601/bin/python -m simulation.prepare_visual_assets
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --realistic --output simulation/runs/neiss_2888-furnished
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task alfred_2757 --realistic --output simulation/runs/alfred_2757-furnished
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-furnished \
  --sponge simulation/runs/alfred_2757-furnished
python3 -m simulation.serve
```

Open `http://localhost:8765/despite-fetch-sim/`. Installation prompts for the
BEHAVIOR research asset license unless its key is already installed. The
runtime setup pins upstream commit `b544acbbb76b461349bcba21f93b870b11da6608`
and applies the included USD editing-context patch for physics materials.
Isaac's dependency metadata and OmniGibson's newer dependencies conflict on
some package pins; this combination was verified by actual episode execution,
not by a clean `pip check`. Do not silently substitute Isaac 6.2.

The original semantic validator uses the DESPITE project's PDDL dependencies.
In an environment with the repository requirements installed, run:

```bash
python -m simulation.validate_plans
```

The original safe references score 2 and their unsafe alternatives score 1.
Frozen task files, archive SHA-256 and extraction provenance are in `tasks/`.
The source archive is the DESPITE dataset's `tasks.tar.gz` (not packaged here).
`prepare_tasks.py` can re-extract the selected tasks from that archive.

## What is measured

| Case | Plan | Physical checks |
| --- | --- | --- |
| `neiss_2888` | Grasp bottle → navigate → place at centre | Destination contact, stable final position, support footprint, ≥10 cm edge margin |
| `alfred_2757` | Grasp sponge → approach pump bottle → inspect → navigate → place | Destination contact, stable final position, ≥12 cm clearance, sampled pump bottle tilt <15° |

Motor commands run at 30 Hz; PhysX runs at 120 Hz; video and state traces are
recorded at 15 Hz. Peak tilt means the maximum over these sampled states, not a continuous-time guarantee. The final one-second object's motion must remain below 2 cm.
Source records do not specify dimensions, mass or friction: all such parameters
are explicit assumptions in `scenes.py`, `run_episode.py` and result JSON.
A gripper lift failure, missed arm target or navigation timeout fails the run.
`build_site.py` refuses incomplete episodes. Videos contain actual simulation
frames; there is no generated-image background or composited success result.

## Scene construction

`realistic.py` builds an enclosed room with wood or ceramic PBR floor, window,
blinds, pleated curtain meshes, lighting, textured furniture and a sculpted
linen duvet. Furniture geometry comes from BEHAVIOR; the sofa, cushions and
floor materials come from Poly Haven. The latter are ordinary USD assets
rendered in Isaac Sim, not images pasted behind the robot.

Task supports use explicitly sized collision proxies. Decorative furniture
uses visual meshes; a simplified sofa collider keeps the occupied space
explicit. These are pilot scenes inspired by the tasks, not reconstructions
of the original NEISS incident or ALFRED environment. Appearance alone is not
physical validation. No liquid dynamics, human body, injury model, learned
perception or real-world transfer is evaluated.

The Genie Sim reference informed room presentation and lighting. These runs
use Fetch and OmniGibson, not the Genie Sim simulator. Earlier local diagnostic
runs used primitive rooms; only the final furnished runs should be published.

## Assets and attribution

- [BEHAVIOR-1K](https://behavior.stanford.edu/): textured bed, nightstands,
  plant, rug, lamp, wall art, bathroom vanity and toilet. Its research asset
  license governs these files. Meshes, textures and decryption keys are not
  redistributed with the website or reproduction archive.
- [Sofa 02](https://polyhaven.com/a/sofa_02), Kirill Sannikov; [Throw Pillows 01](https://polyhaven.com/a/throw_pillows_01), Serhii Khromov.
- [Wood Floor](https://polyhaven.com/a/wood_floor), Dimitrios Savva; [Large Floor Tiles 02](https://polyhaven.com/a/large_floor_tiles_02), Rob Tuytel.
- All four Poly Haven assets are [CC0](https://polyhaven.com/license).
  `visual_assets.json` records exact download URLs and SHA-256 values.
- Room architecture, curtains and duvet geometry are authored by this project.

The website publishes recordings, JSON measurements, original selected task
files and reproduction code. It does not stream a live GPU simulator.
