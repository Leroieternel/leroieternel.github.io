# DESPITE: Fetch execution pilot

Reference plans from **hard-1044** are grounded in ten Fetch task engines in
**Isaac Sim 6.0.1.0 + OmniGibson 3.9.3**. The twelve-source mechanism pilot
reuses two of these engines for additional source tasks. The English website
compares recorded RTX video, original plan steps and measured physical state;
each recording retains the executor version that produced it.

This is a selected-case feasibility pilot, not an LLM safety-rate benchmark.
No LLM generates these plans. Object poses are available to the controller as
oracle state. The robot and task objects are not teleported after initialization.

The new **native Genie Sim apartment** variant, including the refined can label,
is documented in [NATIVE_ASSETS.md](NATIVE_ASSETS.md). Use `--native` for its
original room materials and 30 fps recordings. The furnished-scene workflow
below remains available for comparison and records at 15 fps.

## Runtime setup and earlier furnished scenes

### Classical motion backend

`classical-fetch-v2` is the default shared backend for all ten native task
engines, the twelve-source pilot matrix (including two engine aliases), and
model-plan rollouts. `--planner legacy` explicitly selects the archived baseline.
Changing the default does not change already recorded videos: each result
records `motion_backend`, the planner revision and exact source hashes.

`planning/grounding.py` maps task actions to object targets, inspection regions
and mandatory via-regions. It never reads the safe/unsafe reference label.
An unknown binding fails explicitly; there is no silent legacy fallback.
A future task still needs its scene, objects, action bindings and safety monitor.
The planner cannot infer these from an arbitrary natural-language plan.

```bash
.runtime/isaac601/bin/python -m pip install --only-binary=:all: --no-deps -r simulation/planning/requirements.txt
.runtime/isaac601/bin/python -m unittest simulation.test_classical_planning -v
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_11868 --variant safe --native --planner classical \
  --output simulation/runs/classical-general-v2/neiss_11868-safe
.runtime/isaac601/bin/python -m simulation.planning.audit \
  simulation/runs/classical-general-v2/neiss_11868-safe
# All task engines and both reference plans, without video rendering:
.runtime/isaac601/bin/python -m simulation.run_batch \
  --runs simulation/runs/classical-general-v2-validation --physics-only --resume
.runtime/isaac601/bin/python -m simulation.planning.validation \
  simulation/runs/classical-general-v2-validation
# Explain an existing recording using its own frozen parameters and results:
python -m simulation.explain_motion \
  simulation/runs/classical-final/neiss_11868-safe \
  --output simulation/reports/kitchen-safe-numerical-evidence-v1.json
```

The numerical walkthrough of the previously shared kitchen videos is
[`reports/kitchen-motion-numerical-walkthrough-v1.json`](reports/kitchen-motion-numerical-walkthrough-v1.json).
It includes the actual per-step timestamps, IK coordinates, route cost,
braking-distance calculation, wheel conversion and arm timing. It is derived
from the v1 recording, not a claim that the historical video ran v2.

The shared-backend v2 kitchen regressions are **physics-only**, with no new
video. Their action timings, targets, controller settings and measured outcomes
are in [`reports/kitchen-safe-numerical-evidence-v2.json`](reports/kitchen-safe-numerical-evidence-v2.json)
and [`reports/kitchen-unsafe-numerical-evidence-v2.json`](reports/kitchen-unsafe-numerical-evidence-v2.json).
[`reports/kitchen-controller-example-v2.json`](reports/kitchen-controller-example-v2.json)
reconstructs the curvature and wheel commands at simulation time 27.2 s.
These commands are requested targets before acceleration limiting, not measured
wheel speeds. Historical v1 videos retain their original results.

The integration acceptance report separates motion validity, plan completion,
physical goals and bounded planning stops. It includes ten task engines and
two additional source-task aliases, with matched safe/unsafe initial states:

```bash
.runtime/isaac601/bin/python -m simulation.summarize_motion_acceptance \
  --runs simulation/runs/classical-general-v2-validation \
  --aliases simulation/runs/classical-general-v2-pilot-aliases \
  --output simulation/reports/classical-general-v2-acceptance.json
```

This is one paired integration regression per source task, not the repeated
144-trial mechanism matrix or a measured LLM safety rate. Physical calibration
remains explicitly `uncalibrated`.

The 2026-11-14 [v2 acceptance report](reports/classical-general-v2-acceptance.json)
records 24 runs using the current shared motion modules. All 24 motion audits
pass, including explicit pre-execution planning stops; this does not mean all
tasks succeeded. There are 21 completed plans, 18 achieved physical goals,
three planning stops and no executor failures. Each of the twelve pairs has
identical initial state, execution code, scene specification and physical
parameters. Both bathroom plans stop at delivery docking because the bounded
search finds no robust collision-free arm approach. The unsafe stool plan
stops because its required region has no feasible route in the current search.
These stops do not prove geometric infeasibility. The remaining completed
plans with failed physical goals are edge placements whose supported-footprint
condition is not met; execution completion is recorded separately.

The planner reads enabled USD collision meshes, checks URDF forward kinematics
against live Fetch link poses, and uses FCL for the full robot and carried
object. It samples target-facing docking poses, checks approach and placement
reachability, and chooses a feasible route. Navigation uses weighted SE(2)
hybrid A* with forward/reverse primitives, checked direct connectors and
shortcuts, followed by curvature-regulated differential-drive commands,
braking-distance speed regulation and a predicted-collision stop. The stopping predictor includes a reaction interval followed by deceleration; it does not extrapolate constant speed beyond a reachable goal. The two original navigation actions split the searched route by its progress past the physical obstacle, so each action includes measured travel. This is a local implementation, not a ROS/Nav2 server.
The arm uses bounded numerical pose IK, dense checks of direct joint paths,
OMPL RRTConnect for blocked connections, and phase-synchronized Ruckig timing.
Retimed samples are checked again before motor execution. Search operates on
a separate CPU model; the physical robot is never teleported to test poses.

`planning.json` contains docking candidates, paths, algorithm choices,
trajectory limits, endpoint errors and interventions. `planning-scene.json.gz`
contains the full local collision snapshot. The public `planning-scene-manifest.json` contains collider bounds, hashes and the URDF/live-pose agreement check without redistributing mesh vertex arrays. The source
plan label is not passed to either planner. Only explicit actions, such as
`adjust_movement_smooth`, change the controller's motion limits. A collision
avoidance executor may prevent a hazard in an unsafe source plan; report the
measured result separately from that source label.

Limits: oracle geometry/localization, static scene snapshot, conservative
convex robot/payload shapes and sampled swept checks. This is not a proof of
continuous collision freedom or calibrated real-world safety. The floor liquid
model remains separate from motion planning and does not alter robot friction.

### Shared grounding and numerical parameters

The numerical examples are in metres, seconds and radians. These limits are
uncalibrated pilot settings, not manufacturer safety ratings.

1. **Metric grounding:** original symbolic actions select an object/surface or
   a required region. Scene configuration supplies its pose, dimensions, mass
   and collision meshes. The former bedroom “direct” action no longer forces
   an authored waypoint inside the bed; a collision-free route is searched.
2. **Docking:** test the current base pose and target-facing candidates on
   radii 0.50, 0.55, 0.60, 0.65 and 0.70 m, with 32 angular samples. Collision
   checking and arm approach/descent feasibility reject candidates. Additional
   IK checks cover a 2.5 cm stand-off error and ±0.03 rad heading error. Search
   is bounded to 24 ranked candidates and three feasible routes, so the chosen
   pose is not a globally optimal solution. Selection adds a mid-reach preference
   `2*abs(radius-0.60)` to route cost. Reachability is checked again against the
   actual grasp after transport; a failed check triggers a new docking search.
3. **Grasp transform:** measure `T_hand_object = inverse(T_world_hand) *
   T_world_object`. For an upright desired object pose, the target hand pose is
   `T_world_hand_goal = T_world_object_goal * inverse(T_hand_object)`. Candidate
   base rotations change both the orientation and translation of this offset.
   The measured grasp is refreshed before lowering to account for small slip.
4. **Base path:** state `(x,y,yaw)`, bins 4.5 cm and 15°, 9 cm forward/reverse
   arc primitives and pivot turns. Path cost is `sum(distance + 0.18*abs(dyaw))`.
   The heuristic is `distance_to_goal + 0.12*abs(yaw_error)`, weighted by 1.6.
   Direct forward/reverse connectors are checked before expanding A*. A route
   with `expanded=0` used a checked connector, not an A* search expansion.
5. **Tracking:** 13 cm pure-pursuit lookahead, curvature `2*y_local/L²`, followed
   by linear/angular speed, curvature and stopping-distance limits. Braking
   uses `d = v*0.1 + v²/(2*a)` and its inverse velocity bound. The actual
   commands are acceleration limited at the episode controller frequency.
   Fetch wheel radius is 0.0613 m and wheel separation is 0.372 m;
   `wheel_left=(v-0.186*w)/0.0613`, `wheel_right=(v+0.186*w)/0.0613`.
6. **Arm IK:** eight coordinates (torso translation plus seven revolute joints),
   bounded least squares with residual `[3*position_error, rotation_log_error,
   0.001*(q-q_seed)]`; at most 100 evaluations per solve. Multiple elbow seeds
   and two antipodal grasp yaws are considered. Acceptance requires <3 mm
   position error and <0.025 rad rotation error.
7. **Arm paths and time:** dense joint-space edge checks use ≤2 mm torso and
   ≤0.008 rad joint increments. RRTConnect handles blocked direct connections;
   every Ruckig output segment is checked again. Baseline velocity limits are
   `[0.075,0.55,0.55,0.7,0.55,0.7,0.55,0.7]`; acceleration limits are
   `[0.18,0.9,0.9,1.1,0.9,1.1,0.9,1.1]`; jerk limits are
   `[0.55,2,2,2.5,2,2.5,2,2.5]`. For payload mass `m`, uniform time dilation
   uses `s=clip(sqrt(0.18/max(0.18,m)),0.35,1)` and limits `v*s`, `a*s²`, `j*s³`.
   The measured mass, scale and actual limits are written to each arm record.
8. **Physical execution:** wheel velocity and arm joint-position motor targets
   advance PhysX. The payload moves by finger contact and friction. Planning
   treats its measured grasp as rigid, but the simulator does not attach it to
   the robot with a fixed joint. Grip slip, missed tracking and contact can
   therefore invalidate an otherwise feasible geometric plan.

Common protection includes a 0.32 m chassis planning radius (0.29 m body plus
3 cm tracking buffer), 15 mm arm-body clearance and 6 mm wrist/gripper/payload
clearance. Existing near-wall starts may retreat with an explicitly logged
initial clearance, without permitting intersection. Arm execution holds the
base heading with wheel feedback. A bounded planning failure is recorded as
`motion_planner_no_solution`, with remaining actions unexecuted and
`infeasibility_proven=false`; it is not a successful or proven-impossible task.

The bathroom initialization now places the sponge on the opposite supported
rim of the same native vanity; the old wall-side pickup conflicts with forearm
clearance. Both variants share this metric grounding revision, which is stored
in `spec.initial_geometry_revision`. Its thin-sponge pinch point is 30 mm above
the object centre: offline FK measures approximately 10.8 mm fingertip/table
clearance, versus 4.8 mm at the former 24 mm offset. The source dataset does not prescribe its
metric pose. In the reception, the common base planner retreats from the
counter before the common joint planner folds the arm.

A source “unsafe” label, execution completion, physical goal achievement and
monitored safety events are separate outputs. In particular, collision
avoidance can neutralize an unsafe route. The staff remains a scripted
skeletal actor: the new robot planners do not turn it into a learned or
physically validated human policy.

### Earlier runtime setup

Tested on Ubuntu 24.04, NVIDIA RTX 4090 24 GB, driver 580.178.04, Python 3.12.
Allow approximately 100 GB for the isolated runtime and research assets. Run
from the repository root with Conda available. Review NVIDIA and BEHAVIOR asset
license terms before installing. BEHAVIOR assets and their key remain local.

```bash
bash simulation/setup_runtime.sh
.runtime/isaac601/bin/python -m simulation.prepare_visual_assets
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --realistic --output simulation/runs/neiss_2888-interiors-final
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task alfred_2757 --realistic --output simulation/runs/alfred_2757-interiors-final
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-interiors-final \
  --sponge simulation/runs/alfred_2757-interiors-final
python3 -m simulation.serve
```

Open `http://localhost:8765/despite-fetch-sim/`. Installation prompts for the
BEHAVIOR research asset license unless its key is already installed. The
runtime setup pins upstream commit `b544acbbb76b461349bcba21f93b870b11da6608`
and applies the included USD editing-context patch for physics materials.
Isaac's dependency metadata and OmniGibson's newer dependencies conflict on
some package pins; this combination was verified by actual episode execution,
not by a clean `pip check`. Do not silently substitute Isaac 6.2.

The original semantic validator uses the DESPITE project's PDDL dependencies.
In an environment with the repository requirements installed, run:

```bash
python -m simulation.validate_plans
```

The original safe references score 2 and their unsafe alternatives score 1.
Frozen task files, archive SHA-256 and extraction provenance are in `tasks/`.
The source archive is the DESPITE dataset's `tasks.tar.gz` (not packaged here).
`prepare_tasks.py` can re-extract the selected tasks from that archive.

## What is measured

| Case | Plan | Physical checks |
| --- | --- | --- |
| `neiss_2888` | Grasp bottle → navigate → place at centre | Destination contact, stable final position, <15° final tilt, support footprint, ≥10 cm edge margin |
| `alfred_2757` | Grasp sponge → approach pump bottle → inspect → navigate → place | Destination contact, stable final position, ≥12 cm clearance, sampled pump bottle tilt <15° |

For these two original household cases, motor commands run at 30 Hz and PhysX
at 120 Hz. The particle-fluid kitchen uses 60 Hz control and 480 Hz physics.
Video and state traces are
recorded at 30 Hz in the native Genie apartment, or 15 Hz in the earlier
furnished scenes. Peak tilt means the maximum over these sampled states, not a continuous-time guarantee. The final one-second object's motion must remain below 2 cm.
Source records do not specify dimensions, mass or friction: all such parameters
are explicit assumptions in `scenes.py`, `run_episode.py` and result JSON.
A gripper lift failure, missed arm target or navigation timeout fails the run.
`build_site.py` refuses incomplete episodes. Videos contain actual simulation
frames; there is no generated-image background or composited success result.

## Scene construction

`realistic.py` builds an enclosed room with wood or ceramic PBR floor, window,
blinds, pleated curtain meshes, lighting, textured furniture and a sculpted
linen duvet. The bed, upholstered sofa, lamps and bathroom fixtures come from BEHAVIOR.
Wooden tables, a tambour-door sideboard, cushions, floor materials and textile
PBR maps come from Poly Haven. The latter are ordinary USD assets
rendered in Isaac Sim, not images pasted behind the robot.

`detail_assets.py` generates metre-scale USD bottle meshes and their convex
collision hulls together. The PET water bottle has moulded ribs, a tapered neck,
a sealed cap and a printed label. Its static visible fill is approximately
170 mL, consistent with the assumed 0.18 kg combined mass. This fill does not
simulate fluid motion. The soap bottle has a separate metal pump and nozzle;
the nozzle has its own collider, and the clearance calculation conservatively
uses a 5.5 cm radial footprint. Labels are deterministic typographic artwork.

Fetch retains the native robot geometry and articulation. Its existing UVs are
used to distinguish shell, rubber and lens finishes; exposed base metal has a
separate material. The native vanity's disconnected faucet geometry is replaced
by a smooth curved chrome spout, mixer and aerator. Toggle-button markers are
hidden in the display. The faucet and mixer mount to the measured counter surface: 64 perimeter
samples verify both bases are supported, with a 0.5 mm seating overlap. A low
side view exposes the mounting joint, and result JSON records the surface fit.
These faucet parts are decorative, outside both plans.
The floor geometry and texture assets are unchanged.

Broad overcast window light and ceiling/wall bounce lights replace hard light
accents. Imported lamp intensity overrides are suppressed; ceramic table lamps use
controlled warm bulbs and downward area lights. Extra ambient occlusion is
disabled. A low-intensity, unshadowed dome and two bounce fills approximate
indirect room illumination; the window, ceiling and practical lights retain
shadows. These artistic lighting settings do not constitute photometric validation.
Wall microstructure, textile weave, wood grain and roughness maps
use explicit UVs and appropriate material scales. Non-renderable rig guide
curves from the cabinet asset are hidden. All images, including
the site's enlarged detail views, are actual RTX renders. Detail images show
the settled initial state, while the video and state trace remain synchronized.
Results record source-code hashes, mass, contact offsets and visual revision.

The short Fetch fingers pinch the bottle's neck with a 10 cm height offset.
The former cylinder's grasp target must not be reused for the tapered bottle:
a target below its shoulder can make the palm tip the bottle. The original
three-action reference plan remains unchanged; the geometric motor skill is
updated and the complete episode must be rerun.

Task supports use explicitly sized collision proxies. Decorative furniture
uses visual meshes; simplified sofa, table, sideboard and lamp colliders keep occupied space
explicit. These are pilot scenes inspired by the tasks, not reconstructions
of the original NEISS incident or ALFRED environment. Appearance alone is not
physical validation. No liquid dynamics, human body, injury model, learned
perception or real-world transfer is evaluated.

The Genie Sim reference informed room presentation and lighting. These runs
use Fetch and OmniGibson, not the Genie Sim simulator. Earlier local diagnostic
runs used primitive rooms; only the final furnished runs should be published.

## Assets and attribution

- [BEHAVIOR-1K](https://behavior.stanford.edu/): textured bed, upholstered sofa,
  plant, rug, lamps, wall art, bathroom vanity and toilet. Its research asset
  license governs these files. Meshes, textures and decryption keys are not
  redistributed with the website or reproduction archive.
- [Throw Pillows 01](https://polyhaven.com/a/throw_pillows_01), Serhii Khromov.
- [Wood Floor](https://polyhaven.com/a/wood_floor), Dimitrios Savva; [Large Floor Tiles 02](https://polyhaven.com/a/large_floor_tiles_02), Rob Tuytel.
- [Modern Wooden Cabinet](https://polyhaven.com/a/modern_wooden_cabinet), Patrik Pangerl; [Side Table 01](https://polyhaven.com/a/side_table_01), James Ray Cock; [Modern Coffee Table 01](https://polyhaven.com/a/modern_coffee_table_01), Amin.
- [Cotton Jersey](https://polyhaven.com/a/cotton_jersey), colormass and Rico Cilliers; [White Plaster 02](https://polyhaven.com/a/white_plaster_02), Rob Tuytel; [Walnut Veneer](https://polyhaven.com/a/walnut_veneer), Jenelle van Heerden.
- All Poly Haven assets are [CC0](https://polyhaven.com/license).
  `visual_assets.json` records exact download URLs and SHA-256 values.
- Room architecture, curtains, duvet, bottle meshes, label artwork and faucet
  geometry are authored by this project. Generated asset files live under
  `.runtime/generated/details` and are regenerated from the reproduction code.
  The label renderer uses the Ubuntu `fonts-dejavu-core` fonts.

The website publishes recordings, JSON measurements, original selected task
files and reproduction code. It does not stream a live GPU simulator.


## Five paired reference-plan cases

The additional comparison uses five intact NEISS records from hard-1044:
`neiss_19378` (supply-box clearance), `neiss_24170` (placement verification),
`neiss_27998` (recipient reach), `neiss_4188` (bed contact), and `neiss_8985`
(stool disturbance). Each safe and unsafe plan is copied verbatim from its
source metadata. Both pass the original feasibility validator; their semantic
safety scores differ. These are selected controlled delivery cases, not a
representative benchmark and not evaluations of an LLM.

`pair_cases.py` declares every physical grounding, including the placement bias,
reach point, mass, path and threshold. A missing verification action retains the
same initially biased release target; the explicit oracle check corrects it.
A hazardous route supplies wheel-controller waypoints, never collision-free
teleportation. The same initial scene and logged initial poses (rounded to
5 decimal places) are checked across each pair. Plan labels never determine
measured safety outcomes. A stable low-clearance placement can complete its
task while violating the declared margin. A blocked route can terminate before
later plan actions; those actions remain visible as unexecuted.

The carton and medication bottle are pinned native Genie Sim assets. The carton
uses a documented uniform 0.85 scale to fit the Fetch parallel gripper. The
movable footstool uses BEHAVIOR-1K `footstool/sghekm`. Native room furniture
remains static: table/bed movement, patient biomechanics, liquid spilling and
injury are outside the physical model. Reach is only a declared geometric proxy.

Run physics diagnostics before expensive final captures:

```bash
.runtime/isaac601/bin/python -m simulation.run_batch --runs simulation/runs/pair-draft --draft --resume
.runtime/isaac601/bin/python -m simulation.run_batch --runs simulation/runs/plan-pairs-final --resume
.runtime/isaac601/bin/python -m simulation.build_pairs --runs simulation/runs/plan-pairs-final --output .runtime/publish/plan-pairs
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-navigation-final \
  --sponge simulation/runs/alfred_2757-clarity-final \
  --pairs .runtime/publish/plan-pairs
```

Run `python3 -m simulation.prepare_genie_assets` first to verify/download both
the apartment manifest and the additional `pair_assets.json` object manifest.
The two original runs passed to `build_site` must exist; run them with
`simulation.run_episode --native` when reproducing from a fresh checkout.

Draft captures are 10 fps and are rejected by publication. Final captures retain
30 fps native DLAA and seven additional render-only updates. One GPU process
runs at a time; the batch waits for free memory without unloading other jobs.
Each recording preserves the exact hashed simulator source under `source/`.
Published per-episode archives verify those bytes, including for older videos;
the main reproduction package contains the current complete launcher and tasks.

The original bedside route now absorbs a 12 cm lateral correction into its
approach. The previous extra short segment required a roughly 90-degree turn
and return on the differential-drive base. `audit_navigation.py` compares the
measured absolute rotation within the final 15 cm of the approach.

`build_navigation_review.py --before <original-run> --after <corrected-run>
--output <review-directory>` extracts aligned arrival clips from the two full
physical recordings. Pass that directory to `build_site --navigation-review`
to include the visual before/after audit in the published explorer.


## Three additional native rooms

`scene_cases.py` maps three more intact hard-1044 reference-plan pairs into
independently authored Genie kitchen, study and hotel reception layouts. These
are task proxies, not reconstructions of the original incident locations.

- `neiss_11868`: a cup from a kitchen counter to a side table. The
  smooth-motion action changes speed and command slew limits; both plans use the
  same waypoints. The 15° navigation-tilt limit is a mechanical pilot proxy. No
  liquid, heat, spilling or burn is simulated.
- `neiss_553`: a boxed therapy-tool proxy in a furnished study with a BEHAVIOR
  chair. Clearance is the distance from the chassis disc to the chair rectangle.
  There is no person or injury model.
- `normbank_86816`: a carton handoff on a hotel reception counter, used as a
  counter-layout proxy for the original bank-lobby task. The current revision
  visibly executes staff handling with scripted skeletal motion (see below).
  Both transfers may succeed physically; this does not
  establish social safety or reproduce the original financial context.

All navigation follows declared waypoints with closed-loop wheel control. No
language model or autonomous route search is run. Room mesh collisions and
original textures remain active. Named, invisible support overlays sit 0.3 mm
above measured native table surfaces to provide OmniGibson contact telemetry.

The reception delivery additionally supports an explicitly declared docking
region. Within 16 cm of the stop, facing the counter within 0.10 rad, and with
the requested hand target inside an 83 cm horizontal bound, the original
`navigate_to_storage_area` action can use a short straight approach followed
by an arm transfer. The forward correction reduces nominal horizontal hand
reach to 70 cm, includes the wheel stop tolerance, and must be at most 17 cm.
It uses 0.08 m/s speed and 0.12 m/s² command acceleration limits. When no
correction is needed the base stays still. Outside these bounds, the original
waypoint approach remains. This is a scene-specific docking strategy, not an
autonomous reachability or collision-free planner.
The physical IK controller must reach the hand target within 2 cm. During
the transfer, room contacts on arm links and payload clearance below 10 cm
abort the execution. Final grasp release, support contact and stability are
still checked independently.

Reception arm segments use quintic time scaling with duration selected from
0.25 m/s linear speed, 0.65 m/s² linear acceleration and 1 rad/s angular speed
bounds on the *commanded* trajectory. These are not guarantees about the
measured joint dynamics. A near-identical arm target is held instead of adding
another artificial multi-second segment. In the archived motion-only comparison,
the original plans, scene, physical grasp mode and source/destination coordinates
were unchanged. The subsequent visible-staff revision restages the shared initial
layout; both plan variants still use the same updated skills. Result JSON records the selected delivery
strategy and measured base rotation/displacement.

`audit_reception_motion.py --before <old-scene-runs> --after <new-scene-runs>
--output <report.json>` checks unchanged initial state, source/destination,
camera, mass, original plan and rendering. It requires completed physical
placements, less than 3° delivery rotation, less than 15 cm base displacement,
no unexpected robot/room contacts, and less than 10° payload tilt in delivery.
`build_reception_review.py` takes the same before/after roots and `--output`
to extract real-time delivery clips. Include that directory with
`build_site --reception-review <review-directory>` for the comparison link.

```bash
python -m simulation.prepare_scene_assets
python -m simulation.prepare_staff_asset
python -m simulation.prepare_tasks /path/to/tasks.tar.gz
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m simulation.validate_plans
.runtime/isaac601/bin/python -m simulation.run_batch \
  --runs simulation/runs/scene-diversity-final \
  --tasks neiss_11868 neiss_553 normbank_86816 --resume
.runtime/isaac601/bin/python -m simulation.build_pairs \
  --runs simulation/runs/plan-pairs-final \
  --scene-runs simulation/runs/scene-diversity-final \
  --output .runtime/publish/plan-pairs
```

The original five pairs retain their recorded source snapshots. The viewer
selects a room first, then a task, with synchronized videos, action seeking,
room-specific spatial diagrams, measured conditions and original plan strings.
`scene_assets.json` records pinned asset paths, sizes and SHA-256 hashes. Raw
third-party meshes and any BEHAVIOR decryption key are excluded from the site
and reproduction package.


### Visible reception staff handoff

The reception revision starts Fetch at `[1.35, 2.05]` metres and commands a
real approach to `[2.42, 2.05]`. The safe plan preserves its five original
actions. The unsafe `accept_object` skill includes an approach and physical
pickup, but does not trigger staff processing. Both variants share their
initial robot, parcel and staff state.

The original NVIDIA Isaac Sim `F_Business_02` skeletal character is cached by
`python -m simulation.prepare_staff_asset`. Its file hashes and source URLs
are recorded in `staff_asset.json`. Raw character geometry and textures are
excluded from the website and downloadable source archives.

Staff motion is explicit scripted two-arm skeletal IK. The actor reaches,
lifts the parcel by 15 cm, turns it for inspection, lowers it to the handoff
position, releases it, and clears both hands. During staff handling a
temporary PhysX fixed constraint connects the dynamic parcel to a kinematic
grip anchor. This is not force-controlled human grasping. Fetch subsequently
uses physical fingers, with no attachment constraint or object teleportation.
The processing flag is set only after lift, placement and hand clearance
checks; the trace records staff wrist positions and grasp-constraint state.
No social interpretation, human decisions, or actual financial transaction
is modelled.

Fetch starts above the floor and settles under gravity before the plan starts.
The native floor mesh has 1 mm decorative tile bevels that snag the factory
chassis collision shape. Its visual geometry is retained, but its collision
surface is a continuous box at the measured native tile-top height, with the
same XY bounds. This assumption is recorded as `native_scene.floor_collision_proxy`.
Walls, furniture, chassis and wheel collisions remain active. The robot moves
only through its wheel and arm controllers during the plan.

`python -m simulation.audit_staff_handoff --runs <paired-run-root> --output
<report.json>` verifies actual approach distance, staff wrist travel, dynamic
parcel lift, release-before-pickup, physical Fetch contact, final support,
absence of unexpected robot/room contacts, and identical pairing conditions.
The earlier motion-only comparison remains an explicitly labelled archive;
its initial scene predates the visible staff workflow.

The storage revision uses Genie `benchmark_storage_box_000` with original
materials and a documented 1.3 uniform scale. `storage_assets.json` pins its
files; `prepare_genie_assets` fetches them along with the other task assets.
The open bin is labelled **STORAGE**, with two small fixed native cartons and
a native pen dressing its rear compartment. The target is the clear interior,
not the countertop. A ray-measured bin floor and four conservative static wall
proxies provide contact while preserving the hollow opening; their dimensions
are stored in the result. Containment requires the whole parcel to lie within
the interior and below the rim, with released gripper and stable floor contact.

After placement, Fetch raises the empty gripper above the rim, withdraws it,
lowers it for clearance and reverses along its clear approach corridor
to `[2.02, 2.05]`. Once clear of the counter, it smoothly folds to a declared compact
side-rest configuration through position motor drives. The lift remains at
15 cm, with the gripper outside the torso envelope. Quintic interpolation
bounds the commanded angular speed and acceleration; all states advance through
PhysX, with no `tuck()` reset or direct joint-position assignment. The original plan strings remain intact: withdrawal, stowing
and parking are terminal substeps of the placement skill. No robot or payload
poses are teleported. The audit checks persistent containment, negative wheel
commands and measured reverse displacement, final parking and arm-pose errors,
and unexpected contacts with the bin or its contents. The English viewer links
directly to storage, arm-folding and parking timestamps.

## Kitchen obstacle and liquid consequence

`neiss_11868` now includes a collidable BEHAVIOR footstool (`sghekm`) in the
direct route. Both original plans use the same declared detour, native Genie
cup, obstacle, initial particles and wheel executor. The direct segment
intersects the stool's rectangle inflated by the 0.29 m chassis radius; the
executed detour must maintain positive clearance without physical contact.
This is a manually grounded case study, not autonomous path planning.

`kitchen_liquid.py` replaces the cup's closed collision hull with an open
tapered wall and bottom while retaining its original visual geometry and UVs.
PhysX GPU PBD particles interact with the cup's rigid body. Kitchen runs use
480 Hz physics, 60 Hz control and 30 fps recording. The particles are created
once. Neither their evolution nor the measurements read the reference label.
The current navigation limits are 0.45 m/s, 1.20 rad/s, 0.60 m/s² and
1.60 rad/s². Executing `adjust_movement_smooth` reduces them to 0.10 m/s,
0.30 rad/s, 0.12 m/s² and 0.40 rad/s², including final heading alignment.
These are command limits; actual physical motion remains recorded. The action
does not change the route, cup or liquid.

`segment_navigation.py` now backs straight from the counter to x = −0.42 m,
turns into the clear aisle, passes a checkpoint at y = −0.02 m without stopping,
continues to y = −0.16 m, and faces the table once. The route is a manually
checked corridor, not an autonomous shortest-path planner. Fixed segment
tangents, explicit reverse travel, stopping-distance limits and latched goal
completion prevent orbiting a point or reversing direction after passing it.
The historical point-pursuit controller aligned every navigation call to a fixed
180° and reused the same endpoint for two actions; its unsafe recording
accumulated about 492° of heading travel. That execution remains archived.
Both reference plans are rerun under the corrected common controller. A
previous spill is not assumed to survive the navigation correction. The audit
checks measured turning, travel distance and collision clearance independently
of the dataset safety label.

For this kitchen pair, the Fetch base support uses zero tangential friction
with the minimum combination rule, and the driven wheels use friction 1.0,
following the separate contact values in the supplied Fetch URDF. The imported
convex base has support points at floor level: assigning generic floor friction
to that support could pin the chassis while its wheels spun. This contact
correction is identical for both plans; collisions remain enabled and poses
are never overridden to finish navigation.

The primary measured consequence is cumulative escaped particle volume,
expressed using nominal particle rest volume. The floor measure counts escaped
particles remaining within the floor-height band for three control ticks.
The unspilled-volume ledger counts particles that have never escaped; it is
not an instantaneous estimate of liquid remaining inside the cup. A 1 ml pilot
detection threshold separates the recorded outcomes. All fluid parameters,
fill level, mass, friction, motor limits and this threshold are **uncalibrated**.
There is no temperature, skin-contact, burn or slip-injury solver. The physical
spill is an exposure pathway for the hot-liquid source task, not an injury
measurement. This deliberately selected stress case is not a failure-rate
estimate; more conservative controls can complete the unsafe-labelled plan
without crossing the detection threshold.
The millimetre-scale surface resolves individual droplets. The current
renderer adds a conservative floor-film model driven by actual floor contacts
(see below). Wetting and spreading remain uncalibrated; the images must not be
used as validated predictions of real-world wetting area.

`liquid_surface.py` reconstructs a visual surface from the actual simulated
particle positions, independently of the measurement code. This surface has
no colliders and cannot trigger a spill. `kitchen_evidence.py` records a second
RTX camera of the same simulation frames. The viewer can switch cameras while
preserving a plan's time, inspect the physical obstacle, seek the first spill,
and view the final liquid on the floor. Existing independent playback, shared
controls, frame stepping, speeds, fullscreen and original plan strings remain.

When Fetch occludes the floor, `render_liquid_floor.py` provides a separately
labelled inspection image reconstructed from the last recorded particle state,
with the robot hidden. It verifies the frozen source, records the particle-file
digest and timestamp, and asserts that rendering does not advance physics.
This inspection image is not presented as another physical rollout or used to
calculate safety metrics. The original recordings retain the robot and all
natural occlusion.

`render_spill_evidence.py` additionally reconstructs exact recorded states at
20.0, 26.0, 27.5 and 28.0 seconds, looking toward the side of the cup where liquid
escaped. The inspection panel appears immediately below the unsafe player,
with the 26.0 s view selected by default, a floor-state view and a link to the
original camera at each timestamp. This addresses both the small spill volume
(about 3.4 ml) and gripper/torso occlusion in the full-room video. The script
checks frozen simulation source hashes, uses the archived particle positions
and matching cup pose, keeps liquid size/material unchanged, and asserts zero
physics advancement. No intermediate particle states are interpolated. Each
image and its source archive/trace are hashed. These views are explicitly
labelled state reconstructions and do not change the recorded outcomes.
Those historical recordings have a visibly coarse, bead-like surface. They
are kept unchanged as historical evidence, not relabelled as new film renders.

```bash
.runtime/isaac601/bin/python -m simulation.render_spill_evidence --run simulation/runs/kitchen-liquid-final/neiss_11868-unsafe --output simulation/runs/kitchen-liquid-final/neiss_11868-unsafe/spill-inspection
```

Each run saves particle trajectories at 2 Hz, per-particle first escape times
and cup-local positions, conserved particle counts, per-frame spill and floor
measurements, contact traces and frozen source. Run both full recordings and
the independent audit before publication:

```bash
.runtime/isaac601/bin/python -m simulation.run_episode --task neiss_11868 --variant safe --native --output simulation/runs/kitchen-liquid-final/neiss_11868-safe
.runtime/isaac601/bin/python -m simulation.run_episode --task neiss_11868 --variant unsafe --native --output simulation/runs/kitchen-liquid-final/neiss_11868-unsafe
python -m simulation.audit_kitchen_liquid simulation/runs/kitchen-liquid-final
```

The audit checks identical starting conditions and executor sources, complete
plans, the particle volume ledger, the source action at first detected spill,
physical obstacle clearance, unexpected arm-to-room contacts, and matching
frame counts for both camera recordings. Diagnostic runs use `--draft` or
`--physics-only` and are never substituted for the final recordings.

## Continuous liquid surface and floor film

`liquid_surface.py` reconstructs an overlapping-kernel surface from the current
PhysX particle positions. The transparent material has a water-like index of
refraction (1.333), thickness-dependent absorption and room reflections. As in
OmniGibson's native fluid isosurface, opaque shadow casting is disabled for the
transmitting mesh; otherwise RTX produces a false black slab below the fluid.
The reconstruction is spatial only. No generated frames, video interpolation
or label-triggered geometry are used.

`liquid_film.py` receives each particle once after sustained floor contact.
Its nominal volume is deposited at the measured contact position and spread
using conservative finite-volume height fluxes, positivity limits and no-flux
static-obstacle boundaries. Gravity leveling has an explicit mobility cap;
contact-line spreading uses a phenomenological diffusivity. The rendered
height and area are not enlarged. The only vertical offset is 60 µm to avoid
z-fighting. The ledger records deposited volume, computed volume, any floor
volume outside the modeled domain, area and maximum depth. Unit checks cover
volume conservation, spreading, duplicate-contact rejection and a solid wall.

This is a **one-way, uncalibrated subgrid model**, not a validated two-way
free-surface solver. Settled particles are hidden in the surface reconstruction
to avoid drawing them twice, but remain in PhysX and in the original outcome
measurements. The film does not change their trajectories, robot traction,
cup forces, the reference label, or the task's measured spill volume. There
is no evaporation, absorption, temperature, injury or slip-friction model.

`run_liquid_validation.py` provides a separately labelled controlled tilt test:
the same cup and PBD parameters are placed on a kinematic fixture that smoothly
tilts to 75° and returns upright. This deliberately exposes the flow/impact/
spreading mechanism; it is not a Fetch execution or an additional unsafe-plan
outcome. Two cameras capture the same physical time at 30 fps. Source files are
frozen before the run, and their hashes are checked again at completion.
The website has playback, frame stepping, speed and fullscreen controls, plus
measured particle volumes and explicitly model-estimated wet area.

```bash
python -m unittest simulation.test_liquid_film -v
.runtime/isaac601/bin/python -m simulation.run_liquid_validation --output simulation/runs/liquid-film-final
python -m simulation.build_liquid_validation --run simulation/runs/liquid-film-final --output .runtime/website/despite-fetch-sim/liquid-validation
```

The original kitchen pair must also be rerun with the updated renderer before
claiming its video uses the new film. In the corrected navigation run, floor
loss is tiny; the renderer must not turn that measurement into a large puddle.
The audit checks the film ledger independently of the dataset safety label.
