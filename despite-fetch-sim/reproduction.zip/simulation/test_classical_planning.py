"""Regression checks for paths, swept collisions and trajectory constraints.

Run with the simulator Python; these tests do not launch Isaac Sim or use GPU.
"""
import math
import unittest
import numpy as np
import fcl
from simulation.planning.model import wrap,transform,placement_from_grasp,CollisionWorld,se2
from scipy.spatial.transform import Rotation
from simulation.planning.navigation import Navigator,sweep,stopping_sweep,position_headings
from simulation.planning.arm import ArmPlanner,edge_valid
from simulation.planning.grounding import configure,intent,REVISION


class PlanarWorld:
    def __init__(self,obstacles):
        self.obstacles=[fcl.CollisionObject(fcl.Box(*size),fcl.Transform(center)) for center,size in obstacles]
        self.robot=fcl.CollisionObject(fcl.Box(.36,.24,.35));self.last_collision=None;self.checks=0
    def valid(self,q,base,**kwargs):
        self.checks+=1;self.robot.setTransform(fcl.Transform(base[:3,:3],base[:3,3]+[0,0,.175]))
        result=all(not fcl.collide(self.robot,o,fcl.CollisionRequest(),fcl.CollisionResult()) for o in self.obstacles)
        self.last_collision=None if result else ['robot','test obstacle'];return result


class JointWorld:
    checks=0
    last_collision=None
    def valid(self,q,base,**kwargs):
        self.checks+=1
        # A slab blocks the direct arm connection. A path must change another
        # joint and go around it, rather than checking the goal in isolation.
        result=not(-.12<q[1]<.12 and abs(q[2])<.35)
        self.last_collision=None if result else ['arm','slab'];return result


class JointModel:
    lower=np.array([0.]+[-2.]*7);upper=np.array([.38]+[2.]*7)
    def ik(self,target,seed,**kwargs):
        goal=seed.copy();goal[1]=target[0,3];return [goal]


class PlanningTests(unittest.TestCase):
    def test_tracking_reserve_restores_planning_constraints_on_failure(self):
        from types import SimpleNamespace
        from simulation.planning.executor import ClassicalMotion
        motion=ClassicalMotion.__new__(ClassicalMotion)
        constraints=[{'object':'office_chair','minimum_clearance_m':1.,'planning_buffer_m':.08,'tracking_buffer_m':.03,'active_buffer_m':.08}]
        motion.world=SimpleNamespace(navigation_clearance_constraints=constraints)
        def fail(path):
            self.assertEqual(motion.world.navigation_clearance_constraints[0]['active_buffer_m'],.03)
            self.assertEqual(motion.world.navigation_clearance_constraints[0]['minimum_clearance_m'],1.)
            raise RuntimeError('stop')
        motion._track=fail
        with self.assertRaisesRegex(RuntimeError,'stop'):motion.track([])
        self.assertIs(motion.world.navigation_clearance_constraints,constraints)
        self.assertEqual(constraints[0]['active_buffer_m'],.08)

    def test_action_clearance_is_enforced_on_sweeps_and_can_be_released(self):
        world=CollisionWorld.__new__(CollisionWorld)
        world.fcl=fcl;world.base_disc=fcl.CollisionObject(fcl.Cylinder(.32,.35))
        world.lo=np.empty((0,3));world.hi=np.empty((0,3));world.world=[]
        world.valid=lambda *a,**kw:True
        world.navigation_clearance_constraints=[{'object':'office_chair','bounds_xy_m':[[-.3,-.3],[.3,.3]],'minimum_clearance_m':1.,'tracking_buffer_m':.03}]
        nav=Navigator(world,[-3,3,-3,3],0,np.zeros(8))
        self.assertTrue(nav.valid([-2,-1.3,0]))
        self.assertTrue(nav.valid([2,-1.3,0]))
        self.assertIsNone(nav.edge(np.array([-2.,-1.3,0]),np.array([2.,-1.3,0])))
        self.assertTrue(nav.valid([0,-1.8,0]))
        self.assertTrue(nav.valid([1.3,1.3,0]))  # Rounded rectangle, not a square inflation.
        path,detail=nav.plan([-2,-1.3,0],[2,-1.3,0],timeout=1.)
        self.assertIn('clearance-boundary',detail['algorithm'])
        self.assertTrue(detail['geometry_guidance']['full_robot_payload_world_sweeps_checked'])
        self.assertTrue(all(nav.valid(p) for a,b in zip(path,path[1:]) for p in sweep(a,b)))
        world.navigation_clearance_constraints=[]
        self.assertTrue(world.navigation_valid(np.zeros(8),se2([0,-1.3,0],0)))

    def test_study_action_constraints_are_groundings_not_reference_labels(self):
        from simulation.scene_cases import scene_spec
        spec=scene_spec('neiss_553')
        self.assertEqual(intent(spec,'direct')['clearance_constraints'][0]['minimum_clearance_m'],1.)
        self.assertNotIn('clearance_constraints',intent(spec,'chair'))
        self.assertEqual(intent(spec,'chair')['regions'][0]['center'],[0,-1.0])
        self.assertEqual(intent({},'direct'),{'kind':'delivery'})

    def test_swept_rectangle_catches_thin_obstacle(self):
        world=PlanarWorld([([0,0,.3],[.01,1,.6])])
        nav=Navigator(world,[-2,2,-2,2],0,np.zeros(8))
        self.assertTrue(nav.valid([-1,0,0]));self.assertTrue(nav.valid([1,0,0]))
        self.assertIsNone(nav.edge(np.array([-1.,0,0]),np.array([1.,0,0])))

    def test_navigation_routes_around_obstacle(self):
        world=PlanarWorld([([0,0,.3],[.3,.7,.6])])
        nav=Navigator(world,[-1.5,1.5,-1,1],0,np.zeros(8))
        path,detail=nav.plan([-1,0,0],[1,0,0],timeout=8.)
        self.assertGreater(detail['expanded'],0)
        self.assertTrue(all(nav.valid(p) for a,b in zip(path,path[1:]) for p in sweep(a,b)))
        self.assertGreater(max(abs(p[1]) for p in path),.45)

    def test_infeasible_goal_is_reported(self):
        nav=Navigator(PlanarWorld([([0,0,.3],[.4,.4,.6])]),[-1,1,-1,1],0,np.zeros(8))
        with self.assertRaisesRegex(RuntimeError,'goal is in collision'):nav.plan([-.8,0,0],[0,0,0])

    def test_rectangular_room_connection_checks_both_legs_and_turns(self):
        world=PlanarWorld([([0,0,.3],[.4,.7,.6])])
        nav=Navigator(world,[-1.5,1.5,-1.5,1.5],0,np.zeros(8))
        start=np.array([-1.,-1.,0]);goal=np.array([1.,1.,math.pi/2])
        self.assertIsNone(nav.connect(start,goal))
        path,detail=nav.plan(start,goal,timeout=.1)
        self.assertIn('orthogonal connector',detail['algorithm'])
        self.assertEqual(detail['expanded'],0)
        self.assertTrue(all(nav.valid(p) for a,b in zip(path,path[1:]) for p in sweep(a,b)))
        np.testing.assert_allclose(path[0],start);np.testing.assert_allclose(path[-1],goal)
        # Adding barriers across both L routes must reject this connector,
        # not accept a 2-D corner without checking the connecting sweeps.
        blocked=Navigator(PlanarWorld([([0,0,.3],[.4,.7,.6]),
            ([-1,0,.3],[.5,.3,.6]),([0,-1,.3],[.3,.5,.6])]),[-1.5,1.5,-1.5,1.5],0,np.zeros(8))
        self.assertIsNone(blocked.orthogonal_connection(start,goal))

    def test_rrt_detour_and_retiming(self):
        world=JointWorld();planner=ArmPlanner(JointModel(),world)
        start=np.array([.2,-.7,0,0,0,0,0,0]);goal=start.copy();goal[1]=.7
        self.assertFalse(edge_valid(start,goal,lambda q:world.valid(q,np.eye(4))))
        target=np.eye(4);target[0,3]=goal[1]
        path,detail=planner.plan(start,target,np.eye(4),timeout=3.)
        self.assertIn('RRTConnect',detail['algorithm'])
        q,timing=planner.retime(path,np.eye(4),60)
        q=np.array(q)
        self.assertTrue(all(world.valid(p,np.eye(4)) for p in q))
        self.assertLess(np.max(abs(q[-1]-goal)),1e-7)
        velocity=np.diff(q,axis=0)*60
        self.assertTrue(np.all(abs(velocity)<=np.array(timing['velocity_limits'])+1e-5))
        self.assertTrue(np.all(q>=JointModel.lower-1e-9));self.assertTrue(np.all(q<=JointModel.upper+1e-9))

    def test_wrap_does_not_request_full_circle(self):
        self.assertAlmostEqual(wrap(-math.pi+.01-(math.pi-.01)),.02)

    def test_position_only_waypoint_has_no_artificial_heading_reset(self):
        self.assertAlmostEqual(position_headings([0,0,0],[0,1])[0],math.pi/2)
        self.assertAlmostEqual(position_headings([0,0,0],[-1,0])[0],0.)
        self.assertAlmostEqual(position_headings([0,0,1.2],[0,0])[0],1.2)

    def test_stopping_prediction_decelerates_instead_of_holding_speed(self):
        path=stopping_sweep([0,0,0],[.45,0],[.45,0],[.6,1.6])
        expected=.45*.10+.45**2/(2*.6)
        self.assertAlmostEqual(path[-1][0],expected,delta=.01)
        self.assertLess(path[-1][0],.23)
        reverse=stopping_sweep([0,0,0],[-.45,0],[-.45,0],[.6,1.6])
        self.assertAlmostEqual(reverse[-1][0],-path[-1][0])

    def test_all_task_route_bindings_have_motion_goals(self):
        from simulation.pair_cases import CASES as pairs,pair_spec
        from simulation.scene_cases import CASES as scenes,scene_spec
        from simulation.genie_scene import native_spec
        for task,c in list(pairs.items())+list(scenes.items()):
            spec=pair_spec(task) if task in pairs else scene_spec(task)
            configure(spec)
            self.assertEqual(spec['classical_planning']['revision'],REVISION)
            for action,binding in c['actions'].items():
                if binding[0]=='navigate':self.assertIn('kind',intent(spec,binding[1]))
        for task in ('neiss_2888','alfred_2757'):
            spec=native_spec(task);configure(spec)
            for route in spec['routes']:self.assertIn('kind',intent(spec,route))

    def test_unknown_semantic_region_cannot_fall_back_to_script(self):
        with self.assertRaises(ValueError):intent({},'unknown_route')

    def test_joint_goal_stow_uses_rrt_and_rejects_limits(self):
        planner=ArmPlanner(JointModel(),JointWorld());start=np.array([.2,-.7,0,0,0,0,0,0]);goal=start.copy();goal[1]=.7
        path,detail=planner.plan_joints(start,goal,np.eye(4),timeout=3.)
        self.assertIn('RRTConnect',detail['algorithm'])
        np.testing.assert_allclose(path[-1],goal,atol=1e-5)
        goal[0]=1.
        with self.assertRaises(ValueError):planner.plan_joints(start,goal,np.eye(4))

    def test_placement_rotates_measured_grasp_offset_after_base_turn(self):
        obj=transform([.8,.2,.9],Rotation.from_euler('y',.25).as_quat())
        hand=transform([.85,.2,1.0],Rotation.from_euler('x',math.pi).as_quat())
        goal=placement_from_grasp(hand,obj,[1.,2.,.6],yaw_delta=math.pi/2,gap=.008)
        placed=goal@np.linalg.inv(hand)@obj
        np.testing.assert_allclose(placed[:3,3],[1.,2.,.608],atol=1e-9)
        np.testing.assert_allclose(placed[:3,2],[0,0,1],atol=1e-9)
        np.testing.assert_allclose(placed[:3,0],[0,1,0],atol=1e-9)

    def test_heavy_payload_time_dilation_keeps_path_and_reduces_acceleration(self):
        planner=ArmPlanner(JointModel(),JointWorld());a=np.array([.2,.7,0,0,0,0,0,0]);b=a.copy();b[1]=1.
        light,lt=planner.retime([a,b],np.eye(4),60,payload_mass_kg=.18)
        heavy,ht=planner.retime([a,b],np.eye(4),60,payload_mass_kg=1.)
        self.assertGreater(len(heavy),len(light)*2)
        np.testing.assert_allclose(heavy[-1],b,atol=1e-9)
        self.assertAlmostEqual(ht['acceleration_limits'][1]/lt['acceleration_limits'][1],.18)
        vel=np.diff(heavy,axis=0)*60
        self.assertTrue(np.all(abs(vel)<=np.array(ht['velocity_limits'])+1e-5))

    def test_tilted_solid_placement_preserves_grasp_and_support_clearance(self):
        obj=transform([.8,.2,.9],Rotation.from_euler('z',.7).as_quat())
        hand=transform([.79,.21,.93],Rotation.from_euler('xyz',[math.pi,0,.7]).as_quat())
        quat=Rotation.from_euler('y',-.15).as_quat();half=np.array([.0525,.035,.0105])
        goal=placement_from_grasp(hand,obj,[1.,2.,.81],gap=.008,
            object_quaternion=quat,half_extents=half,support_top=.8)
        placed=goal@np.linalg.inv(hand)@obj
        corners=np.array([[x,y,z] for x in (-1,1) for y in (-1,1) for z in (-1,1)])*half
        corners=corners@placed[:3,:3].T+placed[:3,3]
        self.assertAlmostEqual(corners[:,2].min(),.808,places=9)
        np.testing.assert_allclose(placed[:2,3],[1.,2.],atol=1e-9)
        np.testing.assert_allclose(placed[:3,:3],Rotation.from_quat(quat).as_matrix(),atol=1e-9)
        # Re-measuring an unchanged physical grasp after moving the arm must
        # reproduce the same world goal, rather than applying the tilt twice.
        new_obj=transform([1.1,1.5,1.2],Rotation.from_euler('xyz',[.02,-.15,.1]).as_quat())
        new_hand=new_obj@np.linalg.inv(obj)@hand
        again=placement_from_grasp(new_hand,new_obj,[1.,2.,.81],gap=.008,
            object_quaternion=quat,half_extents=half,support_top=.8)
        np.testing.assert_allclose(again,goal,atol=1e-9)


if __name__=='__main__':unittest.main()
