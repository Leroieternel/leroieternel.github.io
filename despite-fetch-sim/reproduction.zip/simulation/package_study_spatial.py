"""Stage a reviewed study-layout replacement; preserve the other 22 videos."""
import argparse,hashlib,json,shutil,zipfile
from datetime import datetime,timezone
from pathlib import Path
from simulation.build_pairs import build
from simulation.pilot.catalog import SOURCE_IDS
from simulation.verify_study_spatial import verify


def stage(old_runs,new_runs,reviews,previous_site,output):
    report=verify(new_runs)
    for variant in ['safe','unsafe']:
        folder=new_runs/('neiss_553-'+variant)
        (folder/'spatial-audit.json').write_text(json.dumps(report,indent=2)+'\n')
        qa=json.loads((reviews/folder.name/'review.json').read_text())
        assert qa['visual_review_status']=='reviewed',folder.name
        assert hashlib.sha256((folder/'episode.mp4').read_bytes()).hexdigest()==qa['video_sha256']
    output.parent.mkdir(parents=True,exist_ok=True)
    combined=output.parent/'combined-runs';combined.mkdir(exist_ok=True)
    for task in SOURCE_IDS:
        for variant in ['safe','unsafe']:
            name=task+'-'+variant;target=(new_runs if task=='neiss_553' else old_runs)/name
            link=combined/name
            if link.is_symlink():link.unlink()
            assert not link.exists();link.symlink_to(target.resolve(),target_is_directory=True)
    assert not output.exists(),'Choose a fresh staging directory'
    shutil.copytree(previous_site,output)
    pairs=output/'plan-pairs'
    old_review=json.loads((pairs/'release-review.json').read_text())
    old_manifest=json.loads((pairs/'manifest.json').read_text())
    build(combined,pairs,all_tasks=True)
    manifest=json.loads((pairs/'manifest.json').read_text())
    previous_by_id={c['id']:c for c in old_manifest['cases']}
    for case in manifest['cases']:
        if case['id']=='neiss_553':continue
        for variant in ['safe','unsafe']:
            for file in ['episode.mp4','result.json','trace.json']:
                assert case['variants'][variant]['sha256'][file]==previous_by_id[case['id']]['variants'][variant]['sha256'][file]
    fresh={}
    for variant in ['safe','unsafe']:
        name='neiss_553-'+variant
        qa=json.loads((reviews/name/'review.json').read_text())
        fresh[name]={**{k:v for k,v in qa.items() if k!='sampled_frames'},'run':name}
    release={**old_review,'created_at':datetime.now(timezone.utc).isoformat(),'paired_build_id':manifest['build_id'],
        'recordings':[fresh.get(r['run'],r) for r in old_review['recordings']]}
    release['base_release_motion_and_render_source_sha256']=release.pop('shared_motion_and_render_source_sha256',None)
    release['source_implementation_note']='Both labels within each pair share exact recorded source. The study pair adds source-grounded chair-clearance constraints and an occupied-chair layout; the other 22 recordings are unchanged. Algorithm family remains classical-fetch-v2.'
    release['layout_followup']={'task':'neiss_553','revision':report['revision'],
        'previous_videos':{v:previous_by_id['neiss_553']['variants'][v]['sha256']['episode.mp4'] for v in ['safe','unsafe']},
        'spatial_audit':report,'source_sha256':json.loads((new_runs/'neiss_553-safe/result.json').read_text())['simulation_code_sha256']}
    release['previous_release_browser_checks']=release.pop('browser_checks',None)
    release['browser_checks']={'status':'pending_staged_browser_review'}
    release['outcome_summary']={'completed':sum(r['status']=='completed' for r in release['recordings']),
        'blocked':sum(r['status']=='blocked' for r in release['recordings']),
        'goals_reached':sum(r['goal_reached'] for r in release['recordings'])}
    (pairs/'release-review.json').write_text(json.dumps(release,indent=2)+'\n')
    (pairs/'study-spatial-audit.json').write_text(json.dumps(report,indent=2)+'\n')
    page=output/'index.html';text=page.read_text()
    text=text.replace('plan-pairs/data/neiss_553/safe/poster.jpg"','plan-pairs/data/neiss_553/safe/poster.jpg?v='+manifest['build_id']+'"')
    page.write_text(text)
    source=Path(__file__).resolve().parent
    with zipfile.ZipFile(output/'reproduction.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for file in source.rglob('*'):
            rel=file.relative_to(source)
            if file.is_file() and not any(p in ('runs','reports','__pycache__') for p in rel.parts) and file.suffix in ('.py','.sh','.md','.json','.pddl','.patch','.txt','.html','.css','.js','.png'):
                archive.write(file,Path('simulation')/rel)
    # Historical pilot evidence remains byte-identical, including browser files.
    for old in (previous_site/'safety-pilot').rglob('*'):
        if old.is_file():assert old.read_bytes()==(output/old.relative_to(previous_site)).read_bytes()
    print(json.dumps({'site':str(output),'build_id':manifest['build_id'],'replaced_recordings':2,'unchanged_recordings':22}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['old-runs','new-runs','reviews','previous-site','output']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();stage(a.old_runs,a.new_runs,a.reviews,a.previous_site,a.output)
