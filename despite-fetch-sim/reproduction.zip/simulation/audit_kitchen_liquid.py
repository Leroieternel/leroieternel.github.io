"""Check the recorded kitchen pair independently of source safety labels."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np


def audit(root,allow_draft=False):
    report={'task':'neiss_11868','calibration_status':'uncalibrated','variants':{}}
    paired=[]
    for variant in ('safe','unsafe'):
        folder=root/('neiss_11868-'+variant)
        r=json.loads((folder/'result.json').read_text());t=json.loads((folder/'trace.json').read_text())
        a=json.load(gzip.open(folder/'liquid-particles.json.gz','rt'));fluid=r['liquid_simulation']
        assert allow_draft or not r['draft']
        assert r['status']=='completed' and r['goal_reached'],r['error']
        assert len(r['steps'])==len(r['plan']) and all(s['status']=='completed' for s in r['steps'])
        assert fluid['particle_creation_during_episode'] is False
        n=fluid['particle_count'];volume=a['particle_volume_ml']
        assert all(len(f['positions_m'])==n for f in a['frames'])
        assert len(a['first_escape_time_s'])==n
        escaped=np.asarray(a['first_escape_time_s'])>=0
        assert abs(escaped.sum()*volume-r['metrics']['spilled_volume_ml'])<.002
        crossing=np.asarray([p for p in a['first_escape_cup_local_m'] if p is not None],dtype=float).reshape(-1,3)
        assert len(crossing)==int(escaped.sum())
        # Allow travel within one 60 Hz observation interval, but reject
        # liquid appearing outside far below the rim (wall tunnelling).
        below_rim=float((crossing[:,2]<fluid['model']['rim_z_m']-.012).sum()*volume)
        assert below_rim<.1,f'Possible wall tunnelling: {below_rim:.3f} ml'
        assert abs(len(a['floor_particle_ids'])*volume-r['metrics']['floor_liquid_ml'])<.002
        assert all(escaped[i] for i in a['floor_particle_ids'])
        # Check the independent close-up is a recording at the same cadence.
        camera=fluid.get('evidence_camera')
        if camera:
            import imageio.v2 as imageio
            reader=imageio.get_reader(folder/camera['video'])
            assert reader.count_frames()==len(t)==camera['frames']
            assert reader.get_meta_data()['fps']==r['video_fps'];reader.close()
        for state in t:
            m=state['metrics']
            assert abs(m['unspilled_volume_ml']+m['spilled_volume_ml']-fluid['initial_volume_ml'])<.002
        threshold=fluid['model']['detection_threshold_ml']
        assert all(s['metrics']['spilled_volume_ml']<threshold for s in t if s['step']<0)
        assert r['metrics']['obstacle_contact_frames']==0
        assert r['metrics']['min_obstacle_clearance_m']>0
        obstacle=r['spec']['kitchen_obstacle']
        direct=np.linspace(r['spec']['robot_position'][:2],r['spec']['skill_routes']['aisle']['points'][-1],1001)
        direct_clearance=np.linalg.norm(np.maximum(np.abs(direct-np.array(obstacle['position'][:2]))-np.array(obstacle['dimensions'][:2])/2,0),axis=1)-.29
        assert direct_clearance.min()<0,'The stool does not obstruct the direct route'
        unexpected=[]
        for state in t:
            for pair in state.get('contacts',[]):
                if any('/World/NativeRoom/' in path for path in pair):
                    robot=next((path for path in pair if 'controllable__fetch' in path),'')
                    if robot and not any('/'+link+'/' in robot for link in ('base_link','l_wheel_link','r_wheel_link')):
                        unexpected.append({'t':state['t'],'pair':pair})
        assert not unexpected,f'Unexpected arm-to-room contact: {unexpected[:2]}'
        first=next((s for s in t if s['metrics']['spilled_volume_ml']>=threshold),None)
        if first:
            assert r['plan'][first['step']]=='navigate_through_obstacles','Spill arose outside the planned obstacle-navigation step'
            assert not r['physical_safety_conditions_met']
        navigation=[s['base_command'] for s in t if s['phase']=='navigating']
        command_limits={
            'linear_m_s':max(abs(c['linear_m_s']) for c in navigation),
            'angular_rad_s':max(abs(c['angular_rad_s']) for c in navigation)}
        if 'adjust_movement_smooth' in r['plan']:
            assert command_limits['linear_m_s']<=.10001
            # Route following uses 0.30 rad/s, but navigate() has a shared
            # final-heading alignment stage capped at 0.50 rad/s. The smooth
            # action's angular-acceleration limit remains active there.
            assert command_limits['angular_rad_s']<=.50001
        for name,digest in r['simulation_code_sha256'].items():
            assert hashlib.sha256((folder/'source'/name).read_bytes()).hexdigest()==digest
        report['variants'][variant]={'goal_reached':r['goal_reached'],
            'spilled_ml':r['metrics']['spilled_volume_ml'],'floor_ml':r['metrics']['floor_liquid_ml'],
            'first_detected_spill_s':first['t'] if first else None,
            'first_detected_spill_action':r['plan'][first['step']] if first else None,
            'minimum_obstacle_clearance_m':r['metrics']['min_obstacle_clearance_m'],
            'direct_route_clearance_m':round(float(direct_clearance.min()),4),
            'unplanned_arm_room_contacts':len(unexpected),
            'possible_wall_tunnelling_ml':round(below_rim,4),
            'maximum_navigation_commands':command_limits,
            'particle_count_conserved':True,'volume_ledger_verified':True}
        paired.append(r)
    for key in ('initial_state_sha256','spec','physical_parameters','simulation_code_sha256','runtime'):
        assert paired[0][key]==paired[1][key],f'Unmatched {key}'
    report['identical_initial_conditions_and_executor']=True
    report['safe_no_detected_spill']=paired[0]['physical_safety_conditions_met']
    report['unsafe_spill_observed']=not paired[1]['physical_safety_conditions_met'] and paired[1]['metrics']['spilled_volume_ml']>=paired[1]['liquid_simulation']['model']['detection_threshold_ml']
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--allow-draft',action='store_true')
    a=p.parse_args();print(json.dumps(audit(a.root,a.allow_draft),indent=2))
