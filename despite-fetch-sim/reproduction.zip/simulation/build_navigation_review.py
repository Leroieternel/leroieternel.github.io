"""Compare measured bedside arrivals from two full physical executions."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
import imageio.v2 as imageio
from simulation.audit_navigation import measure

ROOT=Path(__file__).resolve().parent


def build(before,after,output):
    output.mkdir(parents=True,exist_ok=True)
    report={'alignment':'One second before first entering 15 cm of the measured final stop; clips end one second after navigation. The shorter clip holds its last frame.',
            'cause':'The old route ended with a 12 cm lateral segment, followed by a return to the final heading.',
            'fix':'Absorb the lateral offset into the approach and retain the final heading.',
            'clips':{}}
    results=[]
    for name,run in [('before',before),('after',after)]:
        result=json.loads((run/'result.json').read_text());trace=json.loads((run/'trace.json').read_text())
        assert result['task_id']=='neiss_2888' and result['goal_reached'] and result['physical_safety_conditions_met']
        assert not result.get('draft') and result['video_fps']==30
        audit=measure(run);fps=result['video_fps']
        first=next(i for i,s in enumerate(trace) if s['t']>=audit['arrival_region_start_s']-1)
        last=min(len(trace),max(i for i,s in enumerate(trace) if s['phase']=='navigating')+fps+1)
        reader=imageio.get_reader(run/'episode.mp4')
        writer=imageio.get_writer(output/f'{name}.mp4',fps=fps,codec='libx264',quality=None,
                                 macro_block_size=16,ffmpeg_params=['-crf','14','-movflags','+faststart'])
        try:
            for i in range(first,last):
                frame=reader.get_data(i);writer.append_data(frame)
                if i==first:imageio.imwrite(output/f'{name}.jpg',frame)
        finally:reader.close();writer.close()
        for file in ['result.json','trace.json']:shutil.copy2(run/file,output/f'{name}-{file}')
        report['clips'][name]={**audit,'first_video_frame':first,'frames':last-first,'fps':fps,
                              'duration_s':(last-first)/fps,
                              'source_result_sha256':hashlib.sha256((run/'result.json').read_bytes()).hexdigest(),
                              'source_video_sha256':hashlib.sha256((run/'episode.mp4').read_bytes()).hexdigest()}
        results.append(result)
    assert results[0]['plan']==results[1]['plan']
    assert results[0]['spec']['camera']==results[1]['spec']['camera']
    assert results[0]['rendering']==results[1]['rendering']
    assert results[0]['physical_parameters']==results[1]['physical_parameters']
    (output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    shutil.copy2(ROOT/'navigation_review/index.html',output/'index.html')
    print(json.dumps(report))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for flag in ['before','after','output']:p.add_argument('--'+flag,type=Path,required=True)
    a=p.parse_args();build(a.before,a.after,a.output)
