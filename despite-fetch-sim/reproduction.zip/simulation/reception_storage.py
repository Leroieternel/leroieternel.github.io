"""Visible reception storage and measured motor-driven end-of-task parking.

The bin retains native Genie geometry/UVs. Its thin floor and sloping walls
use explicit conservative static contact proxies, leaving the cavity open.
Small spare cartons and a pen are fixed dressing, never task success evidence.
"""
import math
import numpy as np
from scipy.spatial.transform import Rotation


def configure_storage(spec, carton_path, carton_dimensions):
    from simulation.genie_scene import prepared_object, measure_surface
    from simulation.scenes import box
    bin_path, dims = prepared_object('storage_bin', physical=False)
    cfg = spec['storage_bin']
    center = np.asarray(cfg['center'])
    counter = spec['support_top']
    position = np.r_[center, counter+dims[2]/2]
    floor = measure_surface('Asset', [(x,y) for x in [-.08,0,.08] for y in [-.12,0,.12]], 0., bin_path)
    top = float(position[2]+floor['surface_z_m']+.0003)
    rim = float(counter+dims[2])
    inner = np.asarray(cfg['inner_half'])
    cfg.update(asset='objects/benchmark/storage_box/benchmark_storage_box_000/Aligned.usd',
               uniform_scale=1.3, dimensions_m=dims.tolist(), position_m=position.tolist(),
               counter_top_m=counter, floor_top_m=top, rim_top_m=rim,
               native_floor_measurement=floor, wall_proxy_thickness_m=.012,
               collider_model='thin floor plus four conservative vertical walls; open top',
               clutter_model='two fixed native cartons and a fixed native pen in the rear compartment')
    spec['surface_measurements']['storage_bin'] = dict(floor,world_floor_top_m=top)
    spec['support_top'] = top
    spec['support_center'] = center.tolist()
    spec['support_half'] = inner.tolist()
    spec['target'][2] = top+spec['half_height']
    objects = [dict(type='USDObject',name='NativeStorageBin',usd_path=bin_path,
                    position=position.tolist(),fixed_base=True,visual_only=True),
               box(spec['support'],[*center,top-.004],[*list(2*inner),.008],[.4,.5,.5],visible=False)]
    height = rim-top
    for axis in range(2):
        for sign in [-1,1]:
            p=np.r_[center,top+height/2];p[axis]+=sign*(inner[axis]+.006)
            d=np.r_[2*inner,height];d[axis]=.012;d[1-axis]+=.024
            objects.append(box(f'storage_bin_wall_{axis}_{"a" if sign<0 else "b"}',p.tolist(),d.tolist(),[.4,.5,.5],visible=False))
    for i,(dx,dy,scale) in enumerate([(.075,.126,.48),(-.05,.137,.52)]):
        size=np.asarray(carton_dimensions)*scale
        p=[center[0]+dx,center[1]+dy,top+size[2]/2]
        objects.append(dict(type='USDObject',name=f'StorageSpareParcel{i}',usd_path=carton_path,
                            position=p,scale=[scale]*3,fixed_base=True,visual_only=True))
        objects.append(box(f'storage_spare_collision_{i}',p,size.tolist(),[.5,.4,.3],visible=False))
    pen, pd=prepared_object('storage_pen',physical=False)
    scale=.8; yaw=math.pi/2 if pd[1]>pd[0] else 0.
    size=pd*scale
    if yaw:size=size[[1,0,2]]
    p=[center[0],center[1]+.063,top+size[2]/2+.001]
    objects.append(dict(type='USDObject',name='StoragePen',usd_path=pen,position=p,scale=[scale]*3,
                        orientation=[0,0,math.sin(yaw/2),math.cos(yaw/2)],fixed_base=True,visual_only=True))
    objects.append(box('storage_pen_collision',p,size.tolist(),[.3,.3,.3],visible=False))
    return objects


def finish_storage_visuals(stage,spec):
    from pathlib import Path
    from PIL import Image,ImageDraw,ImageFont
    from pxr import UsdGeom,UsdShade,Sdf
    from simulation.runtime import RUNTIME
    from simulation.detail_assets import pbr
    directory=RUNTIME/'generated/storage';directory.mkdir(parents=True,exist_ok=True)
    texture=directory/'storage-label.png'
    im=Image.new('RGB',(1000,260),(242,241,226));d=ImageDraw.Draw(im)
    bold=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',106)
    regular=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',35)
    d.rounded_rectangle((8,8,991,251),radius=20,outline=(42,72,65),width=8)
    d.text((500,105),'STORAGE',font=bold,fill=(28,54,48),anchor='mm')
    d.text((500,198),'RECEPTION ITEMS',font=regular,fill=(57,77,68),anchor='mm')
    im.save(texture)
    cfg=spec['storage_bin'];cx,cy=cfg['center']
    x=cx-cfg['dimensions_m'][0]/2-.0008
    y=cy-cfg['dimensions_m'][1]/2-.0008
    z=cfg['counter_top_m']+.070;w=.205;h=.0533
    mat=pbr(stage,'/World/StorageLabelMaterial',[1.,1.,1.],roughness=.65,texture=texture)
    for name,points,normal in [
        ('Side',[[x,cy+w/2,z-h/2],[x,cy-w/2,z-h/2],[x,cy-w/2,z+h/2],[x,cy+w/2,z+h/2]],[-1,0,0]),
        ('Front',[[cx-.14,y,z-.021],[cx+.02,y,z-.021],[cx+.02,y,z+.021],[cx-.14,y,z+.021]],[0,-1,0]),
    ]:
        m=UsdGeom.Mesh.Define(stage,'/World/StorageLabel'+name)
        m.CreatePointsAttr(points)
        m.CreateFaceVertexCountsAttr([4]);m.CreateFaceVertexIndicesAttr([0,1,2,3]);m.CreateSubdivisionSchemeAttr('none')
        m.CreateNormalsAttr([normal]*4);m.SetNormalsInterpolation('vertex')
        UsdGeom.PrimvarsAPI(m).CreatePrimvar('st',Sdf.ValueTypeNames.TexCoord2fArray,'vertex').Set([(0,0),(1,0),(1,1),(0,1)])
        UsdShade.MaterialBindingAPI.Apply(m.GetPrim()).Bind(mat)


def event(ep,name,**evidence):
    item=dict(event=name,t=round(ep.tick/30,4),**evidence)
    ep.storage_events.append(item)
    print('STORAGE_EVENT',item,flush=True)


def storage_metrics(ep):
    cfg=ep.spec['storage_bin'];lo,hi=[x.detach().cpu().numpy() for x in ep.obj.aabb]
    center=np.asarray(cfg['center']);half=np.asarray(cfg['inner_half'])
    inside=bool(np.all(lo[:2]>=center-half) and np.all(hi[:2]<=center+half)
                and abs(lo[2]-cfg['floor_top_m'])<.015 and hi[2]<cfg['rim_top_m']+.005)
    bp,bq=[x.detach().cpu().numpy() for x in ep.robot.get_position_orientation()]
    eef=ep.robot.get_eef_position().detach().cpu().numpy()
    park=ep.spec['post_place'];error=float(np.linalg.norm(bp[:2]-park['park_position']))
    joint_idx=ep.robot.arm_control_idx[ep.robot.default_arm]
    q=ep.robot.get_joint_positions();goal=rest_joint_goal(ep)
    joint_error=float((q[joint_idx]-goal[joint_idx]).abs().max())
    torso_error=float((q[ep.robot.trunk_control_idx]-goal[ep.robot.trunk_control_idx]).abs().max())
    return dict(inside_storage_bin=inside,parking_error_m=round(error,4),
                rest_joint_max_error_rad=round(joint_error,4),rest_torso_error_m=round(torso_error,4),
                empty_gripper_payload_clearance_m=round(float(np.linalg.norm(eef-(lo+hi)/2)),4),
                robot_parked=bool(error<park['parking_tolerance_m'] and joint_error<.06 and torso_error<.01))


def rest_joint_goal(ep):
    goal=ep.robot.tucked_default_joint_pos.clone()
    # A compact side fold keeps the gripper outside the torso envelope. The
    # factory low-torso tuck intersects this asset's enabled self-collisions.
    goal[ep.robot.trunk_control_idx]=ep.spec['post_place']['rest_torso_height_m']
    arm=ep.robot.arm_control_idx[ep.robot.default_arm]
    for i,value in zip(arm,ep.spec['post_place']['rest_arm_joint_targets_rad']):goal[i]=value
    return goal


def fold_empty_arm(ep):
    """Track a declared compact rest configuration through position motor drives.

    Switch controllers at the measured joint state, only after releasing the
    parcel and backing clear of the counter. Never call tuck() or teleport
    joints: every intermediate configuration is stepped through PhysX.
    """
    ep.robot.reload_controllers({
        'base':{'name':'DifferentialDriveController','command_input_limits':None,'command_output_limits':None},
        'arm_0':{'name':'JointController','motor_type':'position','use_delta_commands':False,
                 'command_input_limits':None,'command_output_limits':None,'subsume_controllers':['trunk']},
        'camera':{'name':'JointController','use_delta_commands':False,'command_input_limits':None},
        'gripper_0':{'name':'MultiFingerGripperController','mode':'binary'},
    })
    ep.idx=ep.robot.controller_action_idx
    dofs=ep.robot.controller_joint_idx['arm_0']
    start=ep.robot.get_joint_positions()[dofs].detach().cpu().numpy()
    goal=rest_joint_goal(ep)[dofs].detach().cpu().numpy()
    ep.arm_target=start.copy()
    ep.phase='folding empty arm into Fetch rest pose'
    # The first subsumed DOF is the linear torso; remaining seven are revolute.
    speed=np.array([.045]+[.50]*7);acceleration=np.array([.10]+[.9]*7)
    delta=goal-start
    seconds=max(3.,float(np.max(1.875*np.abs(delta)/speed)),
                float(np.sqrt(np.max((10/math.sqrt(3))*np.abs(delta)/acceleration))))
    ticks=math.ceil(seconds*30)
    for i in range(ticks):
        u=(i+1)/ticks;s=u*u*u*(10+u*(-15+6*u))
        ep.arm_target=start+s*delta
        ep.step()
        for pair in ep.frame_contacts:
            if all(ep.robot.prim_path in p for p in pair) and not all('gripper_finger_link/' in p for p in pair):
                raise RuntimeError('Unexpected self-contact while folding the empty arm: '+str(pair))
    ep.arm_target=goal
    ep.camera_pose=[0.,.15]
    ep.wait(1.)
    actual=ep.robot.get_joint_positions()[dofs].detach().cpu().numpy()
    error=np.abs(actual-goal)
    if error[0]>.01 or np.max(error[1:])>.06:
        raise RuntimeError('Motor-driven Fetch rest pose missed joint targets: '+str(error.tolist()))
    ep.spec['post_place']['rest_joint_indices']=dofs.detach().cpu().tolist()
    ep.spec['post_place']['rest_joint_targets']=goal.tolist()
    event(ep,'empty_arm_stowed',controller='JointController position drives; quintic interpolation',
          duration_s=round(seconds,3),max_revolute_error_rad=float(np.max(error[1:])),
          torso_error_m=float(error[0]),eef_position_m=ep.robot.get_eef_position().detach().cpu().numpy().tolist())


def verify_stored(ep):
    m=ep.metrics()
    if not (m['inside_storage_bin'] and m['support_contact'] and not m['robot_contact']):
        raise RuntimeError('Storage placement lacks containment, bin-floor contact, or gripper release: '+str(m))
    event(ep,'parcel_stored',bin_floor_contact=True,inside_bin=True,gripper_released=True)


def finish_storage_delivery(ep):
    bp,bq=[x.detach().cpu().numpy() for x in ep.robot.get_position_orientation()]
    rotation=Rotation.from_quat(bq)
    ep.phase='withdrawing empty gripper from storage bin'
    ep.move_hand(bp+rotation.apply([.34,0,1.16]),ep.grasp_quat,seconds=2.)
    ep.phase='lowering empty gripper for reverse clearance'
    rest=np.asarray(ep.spec['post_place']['reverse_eef_relative'])
    ep.move_hand(bp+rotation.apply(rest),ep.grasp_quat,seconds=2.5,tolerance=.025)
    ep.gripper=-1.;ep.wait(.35)
    ep.phase='backing away to waiting position'
    ep.motion_profile={'speed':.10,'turn':.25,'acceleration':.12,'angular_acceleration':.35}
    start=ep.robot.get_position_orientation()[0].detach().cpu().numpy()
    target=np.asarray(ep.spec['post_place']['park_position'])
    for _ in range(600):
        p,q=[x.detach().cpu().numpy() for x in ep.robot.get_position_orientation()]
        delta=target-p[:2];distance=float(np.linalg.norm(delta))
        if distance<.018:break
        yaw=Rotation.from_quat(q).as_euler('xyz')[2]
        desired=math.atan2(-delta[1],-delta[0])
        heading=(desired-yaw+math.pi)%(2*math.pi)-math.pi
        if abs(heading)>.3:raise RuntimeError('Parking reverse deviated from the clear approach corridor')
        ep.step((-min(.10,.8*distance),float(np.clip(1.6*heading,-.25,.25))))
    else:raise RuntimeError('Parking reverse timed out')
    ep.wait(.6)
    fold_empty_arm(ep)
    ep.wait(.35)
    ep.phase='parked with arm folded'
    final=ep.robot.get_position_orientation()[0].detach().cpu().numpy()
    displacement=float(np.linalg.norm(final[:2]-start[:2]));m=ep.metrics()
    if displacement<ep.spec['post_place']['minimum_reverse_m'] or not m['robot_parked']:
        raise RuntimeError('Final parking pose was not physically achieved: '+str(m))
    event(ep,'robot_parked',reverse_distance_m=displacement,parking_error_m=m['parking_error_m'],rest_joint_max_error_rad=m['rest_joint_max_error_rad'])
    ep.steps[-1]['evidence']={'kind':'inside_bin_then_stow_and_park','events':list(ep.storage_events)}
