"""Check the bathroom repair from measured execution and immutable source plans."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from simulation.initial_state_check import compare_initial_states
from simulation.planning.audit import audit_run


def placement_overlap_probe(folder, result, trace):
    """Inspect the requested endpoint without moving the simulator or claiming a collision occurred."""
    import fcl
    from simulation.planning.model import convex_geometry
    snapshot=json.load(gzip.open(folder/'planning-scene.json.gz','rt'))
    attempts=[d for d in result['planning']['records'] if d['kind']=='docking']
    target=np.array(attempts[-1]['target_m'])
    payload=snapshot['payload'];hazard=next(i for i in snapshot['world'] if '/pump_bottle/' in i['path'])
    shape=convex_geometry(payload['vertices'],payload['faces'])
    obstacle=fcl.CollisionObject(convex_geometry(hazard['vertices'],hazard['faces']))
    yaw=Rotation.from_quat(trace[-1]['object']['q']).as_euler('xyz')[2]
    orientations=[Rotation.from_euler('z',yaw).as_quat(),*result['spec']['placement_object_orientations_xyzw']]
    probes=[]
    for quat in orientations:
        rotation=Rotation.from_quat(quat).as_matrix();position=target.copy()
        half=np.r_[result['spec']['object_half_xy'],result['spec']['half_height']]
        position[2]=result['spec']['support_top']+(np.abs(rotation)@half)[2]+.008
        body=fcl.CollisionObject(shape,fcl.Transform(rotation,position))
        contact=fcl.CollisionResult()
        count=fcl.collide(body,obstacle,fcl.CollisionRequest(num_max_contacts=8,enable_contact=True),contact)
        probes.append({'object_position_m':position.tolist(),'object_quaternion_xyzw':np.asarray(quat).tolist(),
            'overlaps_pump_collision_geometry':bool(count),
            'maximum_reported_penetration_m':max((c.penetration_depth for c in contact.contacts),default=0.)})
    return {'kind':'offline requested-endpoint geometry check','not_an_observed_collision':True,
        'infeasibility_proven':False,'geometry':'recorded conservative payload and pump convex hulls',
        'requested_target_m':target.tolist(),'candidates':probes}


def verify(runs):
    provenance=json.loads((Path(__file__).parent/'tasks/provenance.json').read_text())
    source=next(t for t in provenance['tasks'] if t['id']=='alfred_2757')
    results={};reports={}
    for variant in ('safe','unsafe'):
        folder=runs/('alfred_2757-'+variant)
        r=json.loads((folder/'result.json').read_text())
        trace=json.loads((folder/'trace.json').read_text())
        assert r['plan']==source['plans'][variant]
        assert r['source_files_sha256']==source['files_sha256']
        assert r['grasping_mode']=='physical' and r['motion_backend']=='classical'
        assert r['spec']['placement_pose_revision']['revision']=='supported-sponge-placement-v1'
        audit=audit_run(folder)
        assert audit['unexpected_contact_frames']==0
        docks=[x for x in r['planning']['records'] if x['kind']=='docking' and x['status']=='completed']
        assert docks,'The original delivery-docking regression must be fixed in each variant'
        assert any(s['action']=='navigate_to_toilet_tank' and s['status']=='completed' for s in r['steps'])
        reports[variant]={
            'status':r['status'],'goal_reached':r['goal_reached'],
            'physical_conditions_met':r['physical_safety_conditions_met'],
            'original_plan_preserved':True,'unexpected_robot_contact_frames':0,
            'selected_docks':[{'pose':d['selected_pose'],
                'object_quaternion_xyzw':d['navigation_plan'].get('placement_object_quaternion_xyzw')}
                for d in docks],
            'final_metrics':r['metrics'],'planning_stop':r.get('planning_stop'),
            'max_pump_bottle_tilt_deg':max(s['metrics']['hazard_tilt_deg'] for s in trace),
            'result_sha256':hashlib.sha256((folder/'result.json').read_bytes()).hexdigest(),
            'trace_sha256':hashlib.sha256((folder/'trace.json').read_bytes()).hexdigest(),
        }
        if variant=='safe':
            assert r['status']=='completed' and r['goal_reached'] and r['physical_safety_conditions_met']
            assert r['metrics']['support_contact'] and not r['metrics']['robot_contact']
            assert r['metrics']['final_motion_m']<.002
            assert r['metrics']['object_tilt_deg']<3
            assert r['metrics']['hazard_clearance_m']>=r['spec']['hazard_clearance']
            assert r['metrics']['edge_margin_m']>=0
            assert any(s['phase']=='lowering object' for s in trace)
            assert any(s['phase']=='releasing' for s in trace)
        if r['status']=='blocked':
            assert variant=='unsafe' and r['planning_stop']['action']=='place_sponge toilet_tank'
            assert not r['planning_stop']['infeasibility_proven']
            assert not r['goal_reached']
            reports[variant]['requested_placement_probe']=placement_overlap_probe(folder,r,trace)
        results[variant]=r
    a,b=results['safe'],results['unsafe']
    assert a['simulation_code_sha256']==b['simulation_code_sha256']
    assert a['spec']==b['spec'] and a['physical_parameters']==b['physical_parameters']
    initial=compare_initial_states(a,b)
    return {'revision':'supported-sponge-placement-v1','task':'alfred_2757',
        'calibration_status':'uncalibrated','same_source_plans_and_physical_scene':True,
        'initial_state_comparison':initial,'recordings':reports,
        'interpretation':'The safe plan must actually release and stably support the sponge. The unsafe label remains a dataset label; an intercepted placement is not recorded as an observed accident or a completed task.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('runs',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();report=verify(a.runs);text=json.dumps(report,indent=2)+'\n'
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(text)
    print(text)
