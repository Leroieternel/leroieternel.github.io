"""Stage all 24 reviewed v2 recordings without changing historical experiments."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil

from simulation.build_pairs import build as build_pairs
from simulation.build_site import build as build_site
from simulation.pilot.catalog import SOURCE_IDS


ROOT = Path(__file__).resolve().parent
ARCHIVES = ('previous', 'motion-review', 'navigation-review', 'reception-motion',
            'kitchen-navigation-review', 'liquid-validation', 'texture-review')


def refresh_pilot_web(destination, supplementary=False):
    """Update navigation and batch labels; preserve every recorded result byte."""
    web = ROOT / 'pilot/web'
    digest = hashlib.sha256((destination / 'summary.json').read_bytes())
    for name in ('index.html', 'app.js', 'style.css'):
        digest.update((web / name).read_bytes())
    for name in ('index.html', 'app.js', 'style.css'):
        text = (web / name).read_text().replace('__BUILD_ID__', digest.hexdigest()[:12])
        text = text.replace('__EXPLORER_ROOT__', '../../' if supplementary else '../')
        if supplementary and name == 'index.html':
            text = text.replace('DESPITE / MECHANISM PILOT', 'DESPITE / GROUNDING REVIEW')
            text = text.replace('What happened<br><em>when the conditions changed?</em>',
                                'Same plans.<br><em>A corrected route.</em>')
            text = text.replace('<title>Mechanism validation / DESPITE</title>',
                                '<title>Navigation correction / DESPITE</title>')
            text = text.replace('<nav>', '<nav><a href="../#alfred_2757">← Original 144-attempt ledger</a>')
            text = text.replace('All 12 tasks', 'All recorded tasks')
        (destination / name).write_text(text)


def mark_archive(folder):
    """Keep comparison features, but identify their old recordings explicitly."""
    for page in folder.rglob('index.html'):
        text = page.read_text()
        if 'id="v2-archive-notice"' in text:
            continue
        notice = ('<aside id="v2-archive-notice" '
                            'style="padding:12px 20px;background:#fff4df;color:#594325;'
                            'font:15px/1.5 system-ui;border-bottom:1px solid #d8c6a4">'
                            'Historical comparison — these recordings retain their original executor. '
                            '<a href="/despite-fetch-sim/plan-pairs/">Open all 12 current v2 plan pairs →</a>'
                            '</aside>')
        text = re.sub(r'<body\b[^>]*>', lambda match: match.group() + notice, text, count=1)
        if 'id="v2-archive-notice"' not in text:
            # Older standalone comparisons use HTML's optional body tag.
            text = re.sub(r'<main\b', lambda match: notice + match.group(), text, count=1)
        assert 'id="v2-archive-notice"' in text, page
        page.write_text(text)


def stage(runs, reviews, previous_site, output):
    expected = [task + '-' + variant for task in SOURCE_IDS for variant in ('safe', 'unsafe')]
    capture_followup = None
    if (runs / 'capture-followup.json').exists():
        capture_followup = json.loads((runs / 'capture-followup.json').read_text())
        assert capture_followup['status'] == 'finished', 'Capture correction has not been reviewed'
        for variant in capture_followup['variants']:
            result = json.loads((runs / (capture_followup['task'] + '-' + variant) / 'result.json').read_text())
            assert result['spec']['camera'] == capture_followup['camera'], 'Old camera recording remains'
    reports = []
    shared_implementation = None
    for name in expected:
        result = json.loads((runs / name / 'result.json').read_text())
        implementation = {key: value for key, value in result['simulation_code_sha256'].items()
                          if key.startswith('planning/') or key in ('run_episode.py', 'rendering.py')}
        if shared_implementation is None:
            shared_implementation = implementation
        assert implementation == shared_implementation, f'Mixed motion/render implementation: {name}'
        report = json.loads((reviews / name / 'review.json').read_text())
        assert report['visual_review_status'] == 'reviewed', f'Visual review missing: {name}'
        video_sha = hashlib.sha256((runs / name / 'episode.mp4').read_bytes()).hexdigest()
        assert video_sha == report['video_sha256'], f'Reviewed video changed: {name}'
        reports.append({**{k: v for k, v in report.items() if k != 'sampled_frames'}, 'run': name})
    ledger_path = reviews / 'ledger.json'
    ledger = json.loads(ledger_path.read_text())
    assert set(ledger['runs']) == set(expected)
    assert all(row['status'] == 'passed' for row in ledger['runs'].values())
    for row in ledger['runs'].values():
        row['visual_review'] = 'reviewed'
    ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
    pairs = output.parent / (output.name + '-paired-build')
    build_pairs(runs, pairs, all_tasks=True)
    build_site([runs / 'neiss_2888-safe', runs / 'alfred_2757-safe'], output,
               previous=previous_site / 'previous', motion_review=previous_site / 'motion-review',
               pairs=pairs, navigation_review=previous_site / 'navigation-review',
               reception_review=previous_site / 'reception-motion')
    for name in ('kitchen-navigation-review', 'liquid-validation', 'safety-pilot'):
        shutil.copytree(previous_site / name, output / name)
    if not (output / 'texture-review').exists():
        shutil.copytree(previous_site / 'texture-review', output / 'texture-review')
    for name in ARCHIVES:
        mark_archive(output / name)
    refresh_pilot_web(output / 'safety-pilot')
    refresh_pilot_web(output / 'safety-pilot/grounding-review', supplementary=True)
    # Historical evidence is immutable. Only the three browser files may differ.
    for old in (previous_site / 'safety-pilot').rglob('*'):
        if not old.is_file() or old.name in ('index.html', 'app.js', 'style.css'):
            continue
        new = output / old.relative_to(previous_site)
        assert new.read_bytes() == old.read_bytes(), f'Historical evidence changed: {old}'
    oversized = [str(p) for p in output.rglob('*') if p.is_file() and p.stat().st_size >= 100_000_000]
    assert not oversized, f'Files exceed the publication size limit: {oversized}'
    manifest = json.loads((output / 'plan-pairs/manifest.json').read_text())
    assert len(manifest['cases']) == 12 and {c['id'] for c in manifest['cases']} == set(SOURCE_IDS)
    for case in manifest['cases']:
        for variant in ('safe', 'unsafe'):
            assert case['variants'][variant]['motion_revision'] == 'classical-fetch-v2'
    release = {'created_at': datetime.now(timezone.utc).isoformat(),
               'motion_revision': 'classical-fetch-v2', 'task_count': 12, 'recording_count': 24,
               'paired_build_id': manifest['build_id'], 'calibration_status': 'uncalibrated',
               'shared_motion_and_render_source_sha256': shared_implementation,
               'review_method': 'Video metadata, all-frame trace and motion audit; visual inspection of sampled original frames. Browser playback checks are recorded separately.',
               'capture_followup': capture_followup,
               'historical_experiment_results_preserved': True, 'recordings': reports}
    (output / 'plan-pairs/release-review.json').write_text(json.dumps(release, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'build': manifest['build_id'], 'recordings': len(reports)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=Path, required=True)
    parser.add_argument('--reviews', type=Path, required=True)
    parser.add_argument('--previous-site', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    stage(args.runs, args.reviews, args.previous_site, args.output)
