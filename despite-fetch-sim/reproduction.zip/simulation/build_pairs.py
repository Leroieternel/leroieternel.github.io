"""Publish complete physical attempts, preserving labels separately from outcomes."""
import argparse
import csv
import hashlib
import html
import json
import shutil
import zipfile
from pathlib import Path
import imageio.v2 as imageio
from simulation.pair_cases import PAIR_IDS
from simulation.scene_cases import SCENE_IDS
from simulation.plan_safety import trace_plan_safety

ROOT=Path(__file__).resolve().parent


def verified_sources(run, destination):
    result=json.loads((run/'result.json').read_text())
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,digest in result['simulation_code_sha256'].items():
            source=run/'source'/name
            if not source.exists():source=ROOT/name
            assert hashlib.sha256(source.read_bytes()).hexdigest()==digest,f'Source mismatch: {run.name}/{name}'
            archive.write(source,'simulation/'+name)


def build(source, destination, scene_runs=None):
    if destination.exists():
        assert (destination/'.despite-pairs-generated').exists()
        shutil.rmtree(destination)
    shutil.copytree(ROOT/'plan_pairs',destination)
    (destination/'.despite-pairs-generated').write_text('Generated physical plan comparisons\n')
    provenance=json.loads((ROOT/'tasks/provenance.json').read_text())
    semantics=json.loads((ROOT/'tasks/semantic_validation.json').read_text())
    manifest={'schema_version':1,'dataset':'DESPITE hard-1044','selection':'Eight hand-selected paired cases across four native room layouts; not representative.' if scene_runs else 'Five hand-selected delivery cases; not representative.',
              'source_archive_sha256':provenance['archive_sha256'],
              'units':{'position':'metres','time':'seconds','quaternion':'xyzw','joint_positions':'radians for revolute joints; metres for prismatic joints, in native Fetch DOF order','tilt':'degrees'},'cases':[]}
    digest=hashlib.sha256()
    summary=[]
    for id in (*SCENE_IDS,*PAIR_IDS) if scene_runs else PAIR_IDS:
        original=next(x for x in provenance['tasks'] if x['id']==id)
        row={'id':id,'metadata':original['metadata'],'source_files_sha256':original['files_sha256'],'variants':{}}
        initial=[];conditions=[]
        for variant in ['safe','unsafe']:
            run=(scene_runs if id in SCENE_IDS else source)/(id+'-'+variant); result=json.loads((run/'result.json').read_text()); trace=json.loads((run/'trace.json').read_text())
            assert not result.get('draft') and result['grasping_mode']=='physical'
            assert result['status'] in ('completed','blocked'),f'Unresolved executor error: {run}'
            assert result['plan']==original['plans'][variant] and result['task_id']==id and result['variant']==variant
            assert result['frames']==len(trace)>100 and all(a['t']<b['t'] for a,b in zip(trace,trace[1:]))
            if variant=='safe':assert result['goal_reached'] and result['physical_safety_conditions_met'],f'Safe reference did not meet its physical conditions: {run}'
            if result['status']=='blocked':
                expected={'neiss_4188':'benchmark_bed_001','neiss_8985':'path_stool'}.get(id)
                assert expected and any(expected in p for s in trace for pair in s.get('contacts',[]) for p in pair),f'Blocked route lacks contact evidence for its declared obstacle: {run}'
            if result['goal_reached']:assert not result['metrics']['robot_contact'],'A completed placement must release the object'
            # Unsafe is a source label, not a prescribed physical outcome.
            reader=imageio.get_reader(run/'episode.mp4')
            assert reader.count_frames()==len(trace) and reader.get_meta_data()['fps']==result['video_fps']==30
            reader.close()
            target=destination/'data'/id/variant;target.mkdir(parents=True)
            hashes={}
            for f in ['result.json','trace.json','episode.mp4','poster.jpg','final.jpg']:
                shutil.copy2(run/f,target/f);hashes[f]=hashlib.sha256((target/f).read_bytes()).hexdigest()
            verified_sources(run,target/'recorded-source.zip')
            safety=trace_plan_safety(ROOT/'tasks'/id, original['metadata']['reference_feasible_plans'][variant])
            assert bool(safety['violation_steps']) == (variant == 'unsafe'), (id, variant, safety)
            row['variants'][variant]={'path':f'data/{id}/{variant}','semantic':{**semantics[id][variant],**safety},'sha256':hashes}
            summary.append({'task_id':id,'reference_label':variant,'semantic_score':semantics[id][variant]['score'],
                            'status':result['status'],'goal_reached':result['goal_reached'],
                            'physical_conditions_met':result['physical_safety_conditions_met'],
                            'duration_s':result['duration'],'video_fps':result['video_fps'],
                            'metric':result['paired_case']['metric'],
                            'metric_unit':result['paired_case'].get('unit','frames' if result['paired_case']['metric'].endswith('_frames') else 'metres'),
                            'metric_value':result['metrics'][result['paired_case']['metric']],
                            'threshold':result['paired_case']['threshold'],
                            'initial_state_sha256':result['initial_state_sha256']})
            digest.update(hashes['result.json'].encode()); initial.append(result['initial_state_sha256'])
            conditions.append({k:result[k] for k in ['spec','physical_parameters','simulation_code_sha256','runtime']})
            row.update(title=result['title'],case=result['paired_case'],scene_id=result['spec'].get('scene_id','bedroom'),scene_title=result['paired_case'].get('scene_title','Original bedroom'))
        assert initial[0]==initial[1],f'Unmatched initial states in {id}'
        assert conditions[0]==conditions[1],f'Unmatched scene, mass, software or skill implementation in {id}'
        row['initial_state_sha256']=initial[0]
        if id=='normbank_86816' and result.get('staff_interaction'):
            from simulation.audit_staff_handoff import audit
            report=audit(scene_runs)
            audit_path=f'data/{id}/staff-handoff-audit.json'
            (destination/audit_path).write_text(json.dumps(report,indent=2)+'\n')
            row['execution_audit']=audit_path
        taskdir=destination/'data'/id/'source';taskdir.mkdir()
        for filename in ['metadata.json','code.py','domain.pddl','problem.pddl']:
            raw=(ROOT/'tasks'/id/filename).read_bytes()
            assert hashlib.sha256(raw).hexdigest()==original['files_sha256'][filename]
            (taskdir/filename).write_bytes(raw)
        manifest['cases'].append(row)
    for name in ['index.html','app.js','style.css']:digest.update((destination/name).read_bytes())
    manifest['build_id']=digest.hexdigest()[:12]
    rooms=list(dict.fromkeys(case['scene_title'] for case in manifest['cases']))
    replacements={'__BUILD_ID__':manifest['build_id'],'__ROOM_COUNT__':str(len(rooms)),
                  '__CASE_COUNT__':str(len(manifest['cases'])),
                  '__RECORDING_COUNT__':str(2*len(manifest['cases'])),
                  '__ROOM_NAMES__':html.escape(' · '.join(rooms))}
    for name in ['index.html','app.js']:
        p=destination/name;content=p.read_text()
        for key,value in replacements.items():content=content.replace(key,value)
        p.write_text(content)
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with (destination/'summary.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    (destination/'README.txt').write_text(
        'DESPITE: paired physical reference-plan executions in native rooms\n\n'
        'summary.csv: one row per original task and reference label.\n'
        'manifest.json: provenance, file checksums, units and pairing conditions.\n'
        'data/<task>/source/: unchanged original hard-1044 task files.\n'
        'data/<task>/<variant>/result.json: plan, outcomes, physical assumptions, runtime and source hashes.\n'
        'data/<task>/<variant>/trace.json: recorded-frame time, phase, joint positions, robot/object poses and contact measurements.\n\n'
        'The data archive excludes video and 3D assets. Videos and exact per-episode source archives are linked in the English viewer.\n'
        'A safe/unsafe reference label is separate from its measured physical outcome. Blocked attempts retain their full original plan; later actions are unexecuted.\n'
        'These hand-selected, oracle-controlled case studies are not an LLM safety-rate estimate. Read each result for its model limitations.\n'
    )
    with zipfile.ZipFile(destination/'paired-data.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name in ['manifest.json','summary.csv','README.txt']:archive.write(destination/name,name)
        for source in sorted((destination/'data').rglob('*')):
            if source.is_file() and source.suffix in ['.json','.pddl','.py']:
                archive.write(source,source.relative_to(destination))
    print(json.dumps({'pairs':len(manifest['cases']),'build':manifest['build_id'],'output':str(destination)}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runs',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--scene-runs',type=Path);a=p.parse_args();build(a.runs,a.output,a.scene_runs)
