import copy
import unittest
from simulation.initial_state_check import compare_initial_states,digest


def record(state):return {'initial_state':state,'initial_state_sha256':digest(state)}


class InitialStateChecks(unittest.TestCase):
    def test_signed_zero_keeps_raw_hashes_and_matches(self):
        a=record({'q':[0.0,-0.0,0.0,1.0],'fluid':{'seed_hash':'abc'}})
        b=record({'q':[-0.0,0.0,-0.0,1.0],'fluid':{'seed_hash':'abc'}})
        result=compare_initial_states(a,b)
        self.assertTrue(result['matched'])
        self.assertFalse(result['raw_hashes_identical'])
        self.assertEqual(result['raw_sha256'],[a['initial_state_sha256'],b['initial_state_sha256']])

    def test_any_nonzero_change_or_fluid_change_fails(self):
        a=record({'p':[0.0,0.0,1.0],'fluid':{'seed_hash':'abc'}})
        for state in ({'p':[1e-12,0.0,1.0],'fluid':{'seed_hash':'abc'}},
                      {'p':[0.0,0.0,1.0],'fluid':{'seed_hash':'def'}}):
            with self.assertRaises(AssertionError):compare_initial_states(a,record(state))

    def test_tampered_raw_record_fails(self):
        a=record({'p':[0.0,0.0,1.0]});b=copy.deepcopy(a);b['initial_state']['p'][0]=-0.0
        with self.assertRaises(AssertionError):compare_initial_states(a,b)


if __name__=='__main__':unittest.main()
