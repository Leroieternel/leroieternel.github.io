"""Download the pinned native Genie Sim apartment and preserve its texture paths."""
import hashlib
import json
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from simulation.runtime import RUNTIME, ROOT


def main():
    manifest = json.loads((ROOT / 'simulation/genie_assets.json').read_text())
    extra=ROOT/'simulation/pair_assets.json'
    if extra.exists():
        more=json.loads(extra.read_text());assert more['revision']==manifest['revision']
        existing={x['path'] for x in manifest['files']}
        manifest['files'].extend(x for x in more['files'] if x['path'] not in existing)
    destination = RUNTIME / 'genie-assets'
    base = 'https://huggingface.co/datasets/agibot-world/GenieSimAssets/resolve/' + manifest['revision'] + '/'

    def download(item):
        target = destination / item['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists() or target.stat().st_size != item['size']:
            temp = target.with_suffix(target.suffix + '.partial')
            request = urllib.request.Request(base + urllib.parse.quote(item['path'], safe='/'),
                                             headers={'User-Agent': 'DESPITE research simulation asset preparation'})
            with urllib.request.urlopen(request, timeout=120) as response, temp.open('wb') as output:
                while chunk := response.read(1024 * 1024):
                    output.write(chunk)
            assert temp.stat().st_size == item['size'], item['path']
            temp.replace(target)
        with target.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        if item.get('sha256'):
            assert digest == item['sha256'], 'Asset checksum mismatch: ' + item['path']
        return {**item, 'sha256': digest}

    verified = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        for item in pool.map(download, manifest['files']):
            verified.append(item)
            if len(verified) % 25 == 0:
                print(f'Verified {len(verified)} / {len(manifest["files"])} files', flush=True)
    (destination / 'verified-assets.json').write_text(json.dumps({**manifest, 'files': verified}, indent=2))
    print(f'Prepared {len(verified)} pinned Genie Sim files in {destination}', flush=True)


if __name__ == '__main__':
    main()
