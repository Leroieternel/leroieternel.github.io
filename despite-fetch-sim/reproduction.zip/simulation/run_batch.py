"""Serial, resumable physical recording batch. Never unload another GPU job."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from simulation.pair_cases import PAIR_IDS
from simulation.scene_cases import SCENE_IDS


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,required=True);p.add_argument('--draft',action='store_true')
    p.add_argument('--tasks',nargs='+',default=['neiss_2888','alfred_2757',*PAIR_IDS,*SCENE_IDS]);p.add_argument('--variants',nargs='+',default=['safe','unsafe'])
    p.add_argument('--resume',action='store_true')
    p.add_argument('--planner',choices=['classical','legacy'],default='classical')
    p.add_argument('--physics-only',action='store_true')
    a=p.parse_args()
    a.runs.mkdir(parents=True,exist_ok=True);logdir=a.runs/'logs';logdir.mkdir(exist_ok=True);rows=[]
    for task in a.tasks:
        for variant in a.variants:
            dest=a.runs/(task+'-'+variant);result=dest/'result.json'; valid=False
            if a.resume and result.exists():
                r=json.loads(result.read_text())
                valid=(r.get('draft')==a.draft and r.get('motion_backend','legacy')==a.planner and r.get('physics_only',False)==a.physics_only and r['status'] in ['completed','blocked'] and
                       all(hashlib.sha256((Path(__file__).parent/n).read_bytes()).hexdigest()==h for n,h in r['simulation_code_sha256'].items()))
            if not valid:
                # A failed initialization must never reuse an older result.
                if dest.exists() and any(dest.iterdir()):
                    previous_log=logdir/(task+'-'+variant+'.log')
                    if previous_log.exists():shutil.copy2(previous_log,dest/'execution.log')
                    dest.rename(dest.with_name(dest.name+'-archived-'+str(time.time_ns())))
                while True:
                    free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).splitlines()[0])
                    if free>=18000:break
                    (a.runs/'batch-progress.json').write_text(json.dumps({'state':'waiting_for_gpu','task':task,'variant':variant,'free_mib':free}))
                    print('WAITING_FOR_GPU',free,flush=True);time.sleep(30)
                command=[sys.executable,'-m','simulation.run_episode','--task',task,'--variant',variant,'--native','--output',str(dest)]
                command+=['--planner',a.planner]
                if a.draft:command.append('--draft')
                if a.physics_only:command.append('--physics-only')
                (a.runs/'batch-progress.json').write_text(json.dumps({'state':'running','task':task,'variant':variant,'finished':rows}))
                print('START',task,variant,flush=True);start=time.monotonic()
                with (logdir/(task+'-'+variant+'.log')).open('w') as log:
                    proc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OMNIGIBSON_NO_OMNI_LOGS':'False'})
                elapsed=round(time.monotonic()-start,1)
                if result.exists():
                    r=json.loads(result.read_text());row={'task':task,'variant':variant,'status':r['status'],'goal':r['goal_reached'],'safe':r['physical_safety_conditions_met'],'duration':r['duration'],'wall_seconds':elapsed,'error':r['error']}
                else:row={'task':task,'variant':variant,'status':'initialization_error','exit_code':proc.returncode,'wall_seconds':elapsed}
            else:row={'task':task,'variant':variant,'status':r['status'],'goal':r['goal_reached'],'safe':r['physical_safety_conditions_met'],'resumed':True}
            rows.append(row);print('RESULT',json.dumps(row),flush=True)
            (a.runs/'batch-progress.json').write_text(json.dumps({'state':'between_runs','finished':rows},indent=2))
    (a.runs/'batch-progress.json').write_text(json.dumps({'state':'finished','finished':rows},indent=2))


if __name__=='__main__':main()
