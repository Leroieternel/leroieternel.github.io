"""Replay declarative PDDL without importing any dataset code.py.

The source Python danger rules are deliberately not interpreted by this engine.
A successful symbolic replay establishes neither physical execution nor safety.
"""
from collections import defaultdict
from fractions import Fraction
import hashlib
import re
import json


def action_strings(plan):
    if isinstance(plan, str):
        raw = re.findall(r'\([^()]*\)', plan)
        if re.sub(r'\([^()]*\)', '', plan).strip():
            raise ValueError('Plan must contain only parenthesized actions')
    elif isinstance(plan, list) and all(isinstance(a, str) for a in plan):
        raw = plan
    else:
        raise ValueError('Plan must be a string or list of action strings')
    result = []
    for a in raw:
        a = a.strip()
        if a.startswith('(') and a.endswith(')'):
            a = a[1:-1]
        if not a or '(' in a or ')' in a:
            raise ValueError('Malformed action: ' + a)
        result.append('(' + ' '.join(a.lower().split()) + ')')
    return result


def archive_worker(item):
    """Importable worker target; package __main__ cannot be unpickled by spawn."""
    split, task_id, files = item
    metadata = json.loads(files['metadata.json'])
    results = {v: replay(files['domain.pddl'], files['problem.pddl'], plan)
               for v, plan in metadata['reference_feasible_plans'].items()}
    return {'task_id': task_id, 'split': split, 'reference_plans': results}


def atom_key(expression):
    return '(' + ' '.join([expression.fluent().name, *[str(a) for a in expression.args]]) + ')'


def constant_value(value):
    if value.is_object_exp():
        return value.object().name
    v = value.constant_value()
    if isinstance(v, Fraction):
        # Preserve exact PDDL arithmetic, including values not representable as floats.
        return int(v) if v.denominator == 1 else str(v)
    return v


def spatial_diagnostics(values):
    locations, objects, held = [], defaultdict(list), set()
    for atom, value in values.items():
        if value is not True:
            continue
        name, *args = atom[1:-1].split()
        if name == 'robot_at' and len(args) == 1:
            locations.append(args[0])
        if name == 'object_at' and len(args) == 2:
            objects[args[0]].append(args[1])
        if name == 'robot_has' and len(args) == 1:
            held.add(args[0])
    flags = []
    if len(locations) > 1:
        flags.append({'kind': 'multiple_symbolic_robot_locations', 'locations': sorted(locations),
                      'interpretation': 'Review endpoint versus visited-region semantics; not multiple physical poses.'})
    for obj, places in objects.items():
        if len(places) > 1 or obj in held:
            flags.append({'kind': 'object_location_semantics_need_review', 'entity': obj,
                          'locations': sorted(places), 'robot_has': obj in held})
    return flags


def replay(domain_text, problem_text, plan, max_ground_fluents=50000):
    from unified_planning.io import PDDLReader
    from unified_planning.engines.sequential_simulator import UPSequentialSimulator
    from unified_planning.model.fluent import get_all_fluent_exp
    from unified_planning.model.walkers import StateEvaluator
    from unified_planning.plans import ActionInstance
    import unified_planning

    result = {'revision': 'despite-state-transitions-v1', 'engine': 'unified_planning',
              'engine_version': unified_planning.__version__, 'basis': 'declarative_pddl',
              'physical_execution': False, 'source_python_danger_rules_executed': False,
              'safety_assessment': 'not_assessed', 'steps': [], 'status': 'error',
              'input_sha256': {k: hashlib.sha256(v.encode()).hexdigest()
                               for k, v in [('domain', domain_text), ('problem', problem_text)]}}
    try:
        actions = action_strings(plan)
        result['plan'] = actions
        # UP 1.3's grounder creates actions in the default environment. Use the
        # same environment; corpus workers are recycled to bound its caches.
        problem = PDDLReader().parse_problem_string(domain_text, problem_text)
        total = 0
        for fluent in problem.fluents:
            size = 1
            for parameter in fluent.signature:
                t = parameter.type
                if t.is_user_type():
                    n = sum(1 for _ in problem.objects(t))
                elif t.is_bool_type():
                    n = 2
                elif t.is_int_type() and t.lower_bound is not None and t.upper_bound is not None:
                    n = t.upper_bound - t.lower_bound + 1
                else:
                    raise ValueError('Non-finite fluent argument domain: ' + str(t))
                size *= n
            total += size
            if total > max_ground_fluents:
                raise ValueError(f'Grounding limit exceeded: {total} > {max_ground_fluents}')
        fluents = sorted((e for f in problem.fluents for e in get_all_fluent_exp(problem, f)), key=atom_key)
        result['grounded_fluent_count'] = len(fluents)
        result['declared_fluents'] = [f.name for f in problem.fluents]
        written = {e.fluent.fluent().name for a in problem.actions for e in a.effects}
        result['declared_but_never_written'] = sorted(set(result['declared_fluents']) - written)
        snapshot = lambda state: {atom_key(f): constant_value(state.get_value(f)) for f in fluents}
        evaluator = StateEvaluator(problem)
        with UPSequentialSimulator(problem) as simulator:
            state = simulator.get_initial_state()
            before = snapshot(state)
            result['initial'] = before
            result['initial_spatial_diagnostics'] = spatial_diagnostics(before)
            blocked = False
            for index, raw in enumerate(actions):
                entry = {'step_index': index, 'action': raw, 'status': 'not_applied', 'changes': []}
                result['steps'].append(entry)
                if blocked:
                    entry['reason'] = 'An earlier action did not apply'
                    continue
                try:
                    name, *args = raw[1:-1].split()
                    action = problem.action(name)
                    if len(args) != len(action.parameters):
                        raise ValueError('Action argument count mismatch')
                    actual = []
                    for token, parameter in zip(args, action.parameters):
                        t = parameter.type
                        if t.is_user_type():
                            actual.append(problem.object(token))
                        elif t.is_bool_type() and token in ('true', 'false'):
                            actual.append(token == 'true')
                        elif t.is_int_type():
                            actual.append(int(token))
                        elif t.is_real_type():
                            actual.append(Fraction(token))
                        else:
                            raise ValueError('Unsupported action argument: ' + token)
                    ai = ActionInstance(action, tuple(actual))
                    unmet, reason = simulator.get_unsatisfied_conditions(state, ai, full_check=True)
                    entry['unsatisfied_conditions'] = [str(v) for v in unmet]
                    if unmet or reason is not None:
                        entry.update(status='inapplicable', reason=str(reason))
                        blocked = True
                        continue
                    next_state = simulator.apply(state, ai)
                    if next_state is None:
                        entry.update(status='inapplicable', reason='Simulator refused action')
                        blocked = True
                        continue
                    after = snapshot(next_state)
                    entry.update(status='applied', changes=[{'atom': k, 'before': before[k], 'after': after[k]}
                                                           for k in before if before[k] != after[k]],
                                 spatial_diagnostics=spatial_diagnostics(after))
                    state, before = next_state, after
                except Exception as exc:
                    entry.update(status='error', error=f'{type(exc).__name__}: {exc}')
                    blocked = True
            result.update(status='blocked' if blocked else 'completed', final=before,
                          symbolic_goal_reached=simulator.is_goal(state),
                          goals=[{'expression': str(g), 'value': constant_value(evaluator.evaluate(g, state))}
                                 for g in problem.goals])
    except Exception as exc:
        result.update(status='error', error=f'{type(exc).__name__}: {exc}')
    return result
