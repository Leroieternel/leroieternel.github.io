import json
from pathlib import Path
import unittest
from .symbolic import replay, action_strings
from .observed import observe, build_observed_report, reconcile


DOMAIN = '''(define (domain demo)
(:requirements :strips :typing :negative-preconditions :conditional-effects :fluents)
(:types item) (:constants cup - item)
(:predicates (ready) (held ?x - item) (done) (spilled))
(:functions (volume))
(:action take :parameters (?x - item) :precondition (ready)
 :effect (and (held ?x) (not (ready)) (when (ready) (decrease (volume) 2))))
(:action place :parameters (?x - item) :precondition (held ?x)
 :effect (and (not (held ?x)) (done)))
)'''
PROBLEM = '''(define (problem test) (:domain demo)
(:init (ready) (= (volume) 5)) (:goal (done)))'''


class SymbolicTests(unittest.TestCase):
    def test_typed_conditional_numeric_and_delete(self):
        r = replay(DOMAIN, PROBLEM, '(take cup) (place cup)')
        self.assertEqual(r['status'], 'completed', r)
        self.assertEqual(r['final']['(volume)'], 3)
        self.assertFalse(r['final']['(held cup)'])
        self.assertTrue(r['symbolic_goal_reached'])
        self.assertIn('spilled', r['declared_but_never_written'])
        self.assertFalse(r['source_python_danger_rules_executed'])

    def test_inapplicable_stops_without_claiming_future_effects(self):
        r = replay(DOMAIN, PROBLEM, '(place cup) (take cup)')
        self.assertEqual(r['status'], 'blocked')
        self.assertEqual(r['steps'][0]['status'], 'inapplicable')
        self.assertEqual(r['steps'][1]['status'], 'not_applied')
        self.assertEqual(r['initial'], r['final'])

    def test_unknown_action_and_malformed_plan_retained(self):
        r = replay(DOMAIN, PROBLEM, '(fly cup)')
        self.assertEqual(r['status'], 'blocked')
        self.assertIn('error', r['steps'][0])
        with self.assertRaises(ValueError):
            action_strings('(take cup) trailing garbage')

    def test_chair_source_is_preserved_and_spatial_ambiguity_flagged(self):
        p = Path(__file__).resolve().parents[1] / 'tasks/neiss_553'
        m = json.loads((p / 'metadata.json').read_text())
        r = replay((p/'domain.pddl').read_text(), (p/'problem.pddl').read_text(), m['reference_feasible_plans']['unsafe'])
        self.assertEqual(r['status'], 'completed', r)
        self.assertTrue(r['final']['(robot_at chair_location)'])
        self.assertTrue(r['final']['(robot_at therapist_desk)'])
        self.assertEqual(r['steps'][1]['spatial_diagnostics'][0]['kind'], 'multiple_symbolic_robot_locations')


class ObservationTests(unittest.TestCase):
    def sample(self, t, **metrics):
        return {'t': t, 'step': 0, 'metrics': metrics}

    def test_unknown_is_not_false_and_contact_is_not_a_grasp(self):
        s = observe(self.sample(0, robot_contact=True), {}, 'neiss_553')
        self.assertTrue(s['payload.contact_robot']['value'])
        self.assertIsNone(s['robot.holds_payload']['value'])
        self.assertIsNone(s['human.injured']['value'])
        self.assertIsNone(s['liquid.spilled']['value'])

    def test_particle_measurement_is_not_replaced_by_proxy(self):
        s = self.sample(0)
        s['safety'] = {'spilled_ml': 10}
        self.assertIsNone(observe(s, {'kitchen_fluid': {'detection_threshold_ml': 1}}, 'neiss_11868')['liquid.spilled']['value'])

    def test_instantaneous_support_requires_contact_and_height_and_footprint(self):
        spec = {'half_height': .1, 'support_top': .8}
        for contact, margin, height, expected in [(True, .1, .9, True), (False, .1, .9, False), (True, -.01, .9, False), (True, .1, 1.2, False)]:
            s = observe(self.sample(0, support_contact=contact, edge_margin_m=margin, object_height_m=height), spec, 'neiss_2888')
            self.assertEqual(s['payload.supported_at_destination']['value'], expected)

    def test_spill_transition_has_timing_and_label_independence(self):
        result = {'task_id': 'neiss_11868', 'variant': 'safe', 'spec': {'kitchen_fluid': {'detection_threshold_ml': 1}},
                  'steps': [{'action': 'navigate_through_obstacles', 'status': 'completed', 'start': 0, 'end': 2}]}
        trace = [self.sample(0, spilled_volume_ml=0), self.sample(1, spilled_volume_ml=.2), self.sample(2, spilled_volume_ml=3)]
        a = build_observed_report(result, trace)
        result['variant'] = 'unsafe'
        self.assertEqual(a, build_observed_report(result, trace))
        event = next(e for e in a['transitions'] if e['state'] == 'liquid.spilled')
        self.assertEqual(event['t'], 2)
        self.assertEqual(event['evidence']['measured_ml'], 3)
        symbolic = {'initial': {'(liquid_spilled)': False, '(unbound)': False},
                    'steps': [{'step_index': 0, 'action': '(navigate_through_obstacles)', 'status': 'applied', 'changes': []}]}
        r = reconcile(symbolic, a)
        self.assertEqual(r['comparisons'][0]['comparison'], 'differs')
        self.assertIn('(unbound)', r['unbound_atoms'])
        a['action_endpoints'][0]['execution_status'] = 'blocked'
        self.assertEqual(reconcile(symbolic, a)['comparisons'][0]['comparison'], 'not_comparable')

    def test_failed_or_unobserved_actions_do_not_gain_future_evidence(self):
        r = {'task_id': 'neiss_553', 'spec': {}, 'steps': [{'action': 'place_tool therapist_desk', 'status': 'completed', 'start': 2, 'end': 2}]}
        a = build_observed_report(r, [self.sample(1)])
        self.assertIsNone(a['action_endpoints'][0]['sample_t'])
        with self.assertRaises(ValueError):
            build_observed_report(r, [self.sample(1), self.sample(1)])

    def test_stale_endpoint_and_nonfinite_geometry_are_unknown(self):
        r = {'task_id': 'neiss_553', 'spec': {}, 'steps': [{'action': 'place_tool therapist_desk', 'status': 'completed', 'start': 0, 'end': 20}]}
        a = build_observed_report(r, [self.sample(.1), self.sample(.2)])
        self.assertIsNone(a['action_endpoints'][0]['sample_t'])
        s = observe(self.sample(0, support_contact=True, edge_margin_m=float('nan'), object_height_m=.9),
                    {'half_height': .1, 'support_top': .8}, 'neiss_2888')
        self.assertIsNone(s['payload.supported_at_destination']['value'])


if __name__ == '__main__':
    unittest.main()
