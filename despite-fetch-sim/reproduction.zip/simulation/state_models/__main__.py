"""Generate state-transition evidence from PDDL and optional existing runs."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import tarfile
import time
from .symbolic import replay, archive_worker
from .observed import build_observed_report, reconcile
from . import REVISION


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def tooling_hashes():
    return {p.name: digest(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


def task_report(task_dir, output, run=None):
    metadata = json.loads((task_dir / 'metadata.json').read_text())
    domain, problem = [(task_dir / name).read_text() for name in ('domain.pddl', 'problem.pddl')]
    report = {'revision': REVISION, 'task_id': metadata['task_id'], 'tooling_sha256': tooling_hashes(),
              'source_sha256': {n: digest(task_dir / n) for n in ['domain.pddl', 'problem.pddl', 'metadata.json']}}
    if run:
        result = json.loads((run / 'result.json').read_text())
        source_id = result.get('experiment', {}).get('source_task_id', result['task_id'])
        if source_id != metadata['task_id']:
            raise ValueError('Run and source task IDs differ')
        # Refuse comparisons against changed source PDDL when a run has hashes.
        for name, sha in report['source_sha256'].items():
            recorded = result.get('source_files_sha256', {}).get(name)
            if recorded is not None and recorded != sha:
                raise ValueError('Recorded source differs from task directory: ' + name)
        trace = json.loads((run / 'trace.json').read_text())
        report['symbolic'] = replay(domain, problem, result['plan'])
        report['observed'] = build_observed_report(result, trace)
        report['reconciliation'] = reconcile(report['symbolic'], report['observed'])
        report['run'] = {'path': str(run.resolve()), 'recorded_at': result.get('recorded_at'),
                         'reference_variant': result.get('variant'), 'status': result['status'],
                         'sha256': {n: digest(run / n) for n in ['result.json', 'trace.json']},
                         'new_physics_executed': False}
    else:
        report['reference_plans'] = {variant: replay(domain, problem, plan)
                                     for variant, plan in metadata['reference_feasible_plans'].items()}
    write(output, report)
    return report


def archive_items(archive, split):
    buckets = {}
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            parts = member.name.split('/')
            if not member.isfile() or len(parts) != 5 or parts[:2] != ['tasks', 'full']:
                continue
            if split != 'all' and parts[2] != split:
                continue
            if parts[-1] not in ('domain.pddl', 'problem.pddl', 'metadata.json'):
                continue
            bucket = buckets.setdefault((parts[2], parts[3]), {})
            bucket[parts[-1]] = tar.extractfile(member).read().decode()
            if len(bucket) == 3:
                yield parts[2], parts[3], buckets.pop((parts[2], parts[3]))
    if buckets:
        raise ValueError('Incomplete task files: ' + str(list(buckets)[:5]))


def corpus_report(archive, output, split, workers):
    output.mkdir(parents=True, exist_ok=True)
    counts, per_split, per_source = Counter(), {}, {}
    failures, spatial = [], []
    started = time.monotonic()
    stream = output / 'symbolic-transitions.jsonl.gz'
    # Separate processes, not threads: UP maintains a process-local expression
    # environment. Recycling workers bounds those expression caches.
    with mp.get_context('spawn').Pool(workers, maxtasksperchild=80) as pool, gzip.open(stream, 'wt', encoding='utf8') as out:
        for entry in pool.imap_unordered(archive_worker, archive_items(archive, split), chunksize=1):
            out.write(json.dumps(entry, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n')
            counts['tasks'] += 1
            per_split[entry['split']] = per_split.get(entry['split'], 0) + 1
            source = entry['task_id'].split('_')[0]
            per_source[source] = per_source.get(source, 0) + 1
            for variant, result in entry['reference_plans'].items():
                counts['plans'] += 1
                counts[result['status'] + '_plans'] += 1
                if result.get('symbolic_goal_reached'):
                    counts['symbolic_goal_reached_plans'] += 1
                if result['status'] != 'completed':
                    failures.append({'task_id': entry['task_id'], 'variant': variant, 'status': result['status'],
                                     'error': result.get('error'), 'failed_steps': [s for s in result['steps'] if s['status'] in ('error', 'inapplicable')]})
                if any(s.get('spatial_diagnostics') for s in result['steps']):
                    spatial.append({'task_id': entry['task_id'], 'variant': variant})
            if counts['tasks'] % 200 == 0:
                print(json.dumps({'progress': dict(counts), 'elapsed_s': round(time.monotonic() - started, 1)}), flush=True)
    report = {'revision': REVISION, 'scope': 'DESPITE full/' + split, 'archive_sha256': digest(archive),
              'counts': dict(counts), 'by_split': per_split, 'by_source': per_source,
              'failures': failures, 'plans_with_spatial_semantics_flags': spatial,
              'tooling_sha256': tooling_hashes(), 'transitions_sha256': digest(stream),
              'elapsed_s': round(time.monotonic() - started, 1),
              'physical_execution': False, 'source_python_danger_rules_executed': False,
              'safety_assessment': 'not_assessed',
              'interpretation': 'Declarative state-transition replay only. Original code.py safety augmentation is not executed. Failures are retained without repairing source domains.'}
    write(output / 'summary.json', report)
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--task-dir', type=Path)
    mode.add_argument('--archive', type=Path)
    p.add_argument('--run', type=Path, help='Analyze original telemetry without rerunning or modifying it')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--split', choices=['all', 'easy', 'hard'], default='all')
    p.add_argument('--workers', type=int, default=4)
    args = p.parse_args()
    if args.workers < 1 or args.workers > 8:
        p.error('workers must be between 1 and 8')
    if args.run and not args.task_dir:
        p.error('--run requires --task-dir')
    report = task_report(args.task_dir, args.output, args.run) if args.task_dir else corpus_report(args.archive, args.output, args.split, args.workers)
    print(json.dumps({'output': str(args.output), 'task_id': report.get('task_id'), 'counts': report.get('counts')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
