# DESPITE state-transition layer

This first implementation separates **symbolic prediction**, **simulator
observation**, and **unmodeled states**. It does not turn 13,133 predicate names
into 13,133 physical processes or infer harm from an unsafe reference label.

## What runs now

- `symbolic.py` reads `domain.pddl` and `problem.pddl` with Unified Planning 1.3,
  checks action applicability, and records each changed grounded fluent with
  its before/after value. Supported finite instantaneous PDDL uses the engine's
  conditional-effect, negative-precondition and numeric semantics. Numeric
  fractions retain exact strings. Invalid domains/actions remain errors;
  subsequent actions do not acquire invented outcomes.
- `observed.py` reads recorded positions, contacts, support geometry, particle
  volume, chair clearance and scripted staff telemetry. It derives discrete
  state changes, numeric extrema and per-action endpoint observations.
  Missing signals are `null` with an explicit reason, never assumed false.
- `reconcile` compares a small, explicit set of source predicates with their
  operational simulator definitions. It includes unchanged predicates, so a
  physical spill can contradict a symbolic `liquid_spilled=false` even if no
  PDDL effect ever writes that predicate. Unbound atoms remain listed.
- The common `Episode.finish` exports `state-transitions.json` for future
  episodes. This observer does not change motor commands or physical state.
  Existing recordings are analyzed into separate reports, without modifying
  their videos, state traces, results or execution hashes.

## Run

The symbolic replay uses the already installed project environment. The
observation module itself uses only the Python standard library and can run
inside the Isaac environment without installing Unified Planning there.

```bash
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m unittest simulation.state_models.test_transitions -v

# Both original reference plans, symbolic transitions only:
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m simulation.state_models \
  --task-dir simulation/tasks/neiss_553 \
  --output simulation/reports/state-models-v1/chair-symbolic.json

# Compare the actual plan in an existing recording with its original telemetry:
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m simulation.state_models \
  --task-dir simulation/tasks/neiss_553 \
  --run simulation/runs/study-spatial-v3/neiss_553-unsafe \
  --output simulation/reports/state-models-v1/examples/neiss_553-unsafe.json

# Whole DESPITE archive; no task Python code is imported and no tar paths extracted:
/home/mcxiangalds/miniconda3/envs/despite/bin/python -m simulation.state_models \
  --archive /tmp/despite-literature-review/tasks.tar.gz \
  --output simulation/reports/state-models-v1/corpus --workers 4
```

Corpus output is a compressed JSONL stream plus a summary retaining errors,
blocked actions, source/split counts and spatial-semantics diagnostics. Its
success count describes declarative replay, **not** physical or safety success.
Original `code.py` danger augmentation is intentionally not executed by this
tool; the existing `simulation.plan_safety` validator remains separate.

## Grounding rules and limitations

The explicit twelve-task binding table maps each source payload and destination
to the recorded scene roles. `object_at(payload, destination)` is operationalized
as contact with the destination support, nonnegative footprint margin and
bottom-height agreement within 3.5 cm. This is an instantaneous support test,
not a stability guarantee or a universal interpretation of every `object_at`.

`robot_has` remains unknown: the old trace's aggregate robot/object contact
cannot distinguish a successful finger grasp from contact elsewhere on the
robot. A future grasp observer needs finger-specific contact, gripper state,
and persistence of the object-to-hand transform. A commanded `grab` action is
not sufficient evidence.

`liquid_spilled` uses the run's explicit detection threshold and measured PBD
particle volume. The older pilot's `safety.spilled_ml` is a reduced-order model
and is not substituted. Neither particles nor a visible wet-film renderer
establish wet friction, burns, slip injury or real-world accuracy.

The chair observer reports the source's 0.5 m exposure threshold and 1 m
recommended clearance separately. Its input is the recorded chassis-disc to
chair-footprint distance; it does not measure full robot-to-human clearance.
Human reaction, balance, falling and injury remain unknown. Static occupants
do not provide a human dynamics model.

The staff grasp constraint is explicitly labeled a scripted observation.
`staff_has_object=true` after a source processing action can disagree with a
recording in which the staff already released the parcel by that action's end.
Similarly, `robot_at(chair_location)` and `robot_at(therapist_desk)` can both be
true in the unmodified source domain. These cases need a distinction between
current pose, visited region and completed processing, not fabricated motion.

Time alignment selects the latest recorded sample at or before an action end,
only if it belongs to that action interval. Missing, failed or unexecuted
steps are not counted as validated. Endpoint samples older than two median
sampling periods and zero-duration actions have no fresh endpoint observation.
Samples are not interpolated. All physical
thresholds and parameters remain **uncalibrated**.

## Extending to physical state models

For each normalized state, register its entity binding, value/unit, model,
parameters, preconditions, update law, observation and uncertainty. Reuse
rigid-body/articulation state for positions, contact, grasp and opening. Use
volume-conserving fluid state for fill/spill/wetting. Add explicit thermal,
electrical, contamination and material-damage modules for those mechanisms.
Use event/permission/protocol state machines for consent, information and
processing order. Any scripted or reduced-order approximation must retain its
evidence type rather than masquerading as a measured physical outcome.

The present task does not enable OmniGibson's global transition-rule flag,
create thermal/injury models, or claim physical coverage of all DESPITE tasks.
Future capabilities must be added per object and validated with matched
conditions. This observer provides the shared evidence interface for that work.

Primary API references:
- https://unified-planning.readthedocs.io/en/latest/operation_modes.html#sequentialsimulator
- https://behavior.stanford.edu/omnigibson/object_states.html

## 2026-11-15 validation

The complete canonical archive contained 12,279 tasks and 24,558 reference
plans. Declarative replay completed for 24,533 plans; 24,532 also reached their
PDDL goal. Twenty-four plans encountered invalid `danger` expressions, and
one referenced an absent action. `bddl_528`'s unsafe plan completed without
meeting its goal. These findings are retained, not automatically repaired.
There were 778 plans with spatial-semantics diagnostic flags; these flags need
interpretation and are not 778 proven data errors or physical failures.

An independent integrity pass reconstructed 226,950 recorded fluent changes
and verified the final states and stream counts. The observed-state regression
used 24 existing recordings across twelve tasks, with 35,578 samples. The
explicit bindings produced 85 agreeing comparisons, 4 differing comparisons,
80 unknowns and 14 non-comparable entries. These counts are repeated
state/step comparisons, not independent trials or safety rates.

Ten unit tests passed. No fresh Isaac episode was executed for this change;
the common export hook is checked through the pure-Python observer and
recorded-telemetry regression. All physical calibration remains pending.
Evidence is in `simulation/reports/state-models-v1/validation.json`,
`corpus/summary.json`, `corpus/symbolic-transitions.jsonl.gz` and `examples/`.
