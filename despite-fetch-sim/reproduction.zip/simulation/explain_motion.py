"""Export per-action numerical evidence from an existing motion recording.

This never runs or repairs a plan. It reads the recorded version, rather than
substituting the current planner's parameters into an older video explanation.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path


def route_numbers(path):
    length = sum(math.hypot(b[0]-a[0], b[1]-a[1]) for a,b in zip(path,path[1:]))
    turn = sum(abs((b[2]-a[2]+math.pi)%(2*math.pi)-math.pi) for a,b in zip(path,path[1:]))
    return {'distance_m': length, 'absolute_turn_rad': turn,
            'absolute_turn_deg': math.degrees(turn),
            'cost_distance_plus_0_18_turn': length+.18*turn}


def explain(run):
    file=run/'result.json';r=json.loads(file.read_text())
    planning=json.loads((run/'planning.json').read_text())
    assert planning==r['planning'], 'Planning record differs from result'
    for name,digest in r['simulation_code_sha256'].items():
        assert hashlib.sha256((run/'source'/name).read_bytes()).hexdigest()==digest,name
    steps=[]
    for index,action in enumerate(r['plan']):
        step=next((s for i,s in enumerate(r['steps']) if i==index),{})
        events=[]
        for record in planning['records']:
            if record.get('step')!=index:continue
            kind=record['kind']
            event={k:record[k] for k in ('kind','phase','status','start_s','end_s','error') if k in record}
            if kind=='arm':
                plan=record.get('plan',{});timing=record.get('timing',{})
                event.update(algorithm=plan.get('algorithm'),target_world_transform=plan.get('target_world'),
                             collision_checks=plan.get('collision_checks'),endpoint_error_m=record.get('endpoint_error_m'),
                             initial_proximity_limits=record.get('initial_proximity_limits',[]),
                             timing=timing)
                waypoints=plan.get('waypoints',[])
                if waypoints:event.update(joints_start=waypoints[0],joints_goal=waypoints[-1],joint_waypoint_count=len(waypoints))
            elif kind=='navigation':
                path=record['planned_path'];limits=record['limits']
                event.update(planned_route=route_numbers(path),start_pose=path[0],goal_pose=path[-1],
                             limits=limits,endpoint_error_m=record.get('position_error_m'),
                             heading_error_rad=record.get('heading_error_rad'))
                if limits.get('acceleration',0)>0:
                    speed=limits['speed'];a=limits['acceleration']
                    event['braking_example_at_speed_cap']={'reaction_time_s':.1,'speed_m_s':speed,
                        'acceleration_m_s2':a,'distance_m':speed*.1+speed*speed/(2*a),
                        'interpretation':'Limit-based example, not a claim that this speed was attained.'}
                samples=record.get('controller_samples',[])
                if samples:
                    event['controller_sample_count']=len(samples)
                    event['first_controller_sample']=samples[0]
            elif kind=='docking':
                event.update({k:record[k] for k in ('purpose','target_m','candidates_collision_free',
                    'selected_pose','placement_ik_and_descent_checked','navigation_plan') if k in record})
                event['rejected_candidates']=record.get('rejected_candidates',[])
                if record.get('route'):event['selected_route']=route_numbers(record['route'])
            else:
                event=record
            events.append(event)
        steps.append({'index':index+1,'original_action':'('+action+')',
                      'start_s':step.get('start'),'end_s':step.get('end'),
                      'status':step.get('status','not_executed'),'execution':events})
    return {'artifact_type':'Derived numerical evidence; not a new rollout or safety certification',
            'task_id':r['task_id'],'source_variant':r['variant'],
            'recorded_backend_revision':planning['revision'],
            'source_result':str(file.resolve()),'source_result_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
            'recorded_source_hashes_verified':True,'physics_only':r.get('physics_only',False),
            'units':{'translation':'metres','rotation':'radians','time':'seconds'},
            'frequencies':{k:r[k] for k in ('physics_hz','control_hz','video_fps')},
            'geometry':{k:r['spec'].get(k) for k in ('source','target','source_support_top','support_top','half_height','initial_geometry_revision')},
            'physical_parameters':r['physical_parameters'],
            'recorded_planner_parameters':planning.get('parameters','Not separately recorded in this version; consult its frozen source.'),
            'calibration_status':planning['calibration_status'],'steps':steps,
            'outcome':{k:r.get(k) for k in ('status','duration','goal_reached','physical_safety_conditions_met','termination_reason','planning_stop','metrics')}}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('run',type=Path);p.add_argument('--output',type=Path)
    args=p.parse_args();report=explain(args.run);text=json.dumps(report,indent=2)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text)
        print(args.output)
    else:print(text)
