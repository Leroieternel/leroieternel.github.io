"""Controlled cup-tilt test: PBD flow, ground impact and conservative film.

The cup is a prescribed kinematic fixture. This is explicitly a rendering and
fluid-mechanism test, NOT a Fetch plan execution or a benchmark safety outcome.
"""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
from types import SimpleNamespace
import numpy as np


def run(output,preview=False,seconds=10.):
    from simulation.runtime import configure,ROOT
    configure()
    import torch
    import imageio.v2 as imageio
    import omnigibson as og
    from omnigibson.macros import gm
    from scipy.spatial.transform import Rotation
    gm.USE_GPU_DYNAMICS=True;gm.ENABLE_HQ_RENDERING=True
    gm.ENABLE_TRANSITION_RULES=False;gm.ENABLE_CCD=True
    from simulation.scene_cases import scene_spec
    from simulation.scenes import make_config
    from simulation.genie_scene import native_config,finish_native_scene
    from simulation.rendering import configure_capture,settle_capture
    from simulation.preview_native import camera
    from simulation.kitchen_liquid import KitchenLiquid
    from simulation.detail_assets import pbr,lathe
    from omnigibson.sensors.vision_sensor import VisionSensor
    spec=scene_spec('neiss_11868')
    config=native_config(make_config('neiss_2888','physical'),spec)
    center=np.array([-.45,.05,.32])
    for obj in config['objects']:
        if obj['name']==spec['object']:
            obj.update(kinematic_only=True,fixed_base=True,position=center.tolist())
    output.mkdir(parents=True,exist_ok=True)
    source_names=('run_liquid_validation.py','kitchen_liquid.py','liquid_surface.py','liquid_film.py',
                  'rendering.py','runtime.py','scene_cases.py','scenes.py','genie_scene.py',
                  'detail_assets.py','prepare_scene_assets.py','realistic.py','preview_native.py',
                  'pair_cases.py','scene_assets.json','genie_assets.json','pair_assets.json')
    sources=output/'source';sources.mkdir(exist_ok=True)
    source_sha256={}
    for name in source_names:
        path=ROOT/'simulation'/name
        shutil.copy2(path,sources/name)
        source_sha256[name]=hashlib.sha256((sources/name).read_bytes()).hexdigest()
    print('Loading controlled fluid test scene',flush=True)
    env=og.Environment(configs=config)
    try:
        from pxr import UsdGeom,UsdShade,UsdPhysics,Gf
        finish_native_scene(env,spec);rendering=configure_capture()
        cup=env.scene.object_registry('name',spec['object']);robot=env.scene.robots[0]
        assert cup.kinematic_only,'The prescribed tilt requires a true kinematic fixture'
        cup.set_position_orientation(position=torch.tensor(center,dtype=torch.float32),
                                     orientation=torch.tensor([0.,0,0,1.]))
        ep=SimpleNamespace(spec=spec,env=env,obj=cup,robot=robot,output=output,tick=0,
            control_hz=60,physics_only=True,frame_contacts=set(),active_step=-1,phase='settling fixture')
        ep.pose=lambda obj:{'p':obj.get_position_orientation()[0].cpu().tolist()}
        liquid=KitchenLiquid(ep)
        with og.sim.editing_usd():
            steel=pbr(og.sim.stage,'/World/Looks/TiltFixtureSteel',(.32,.35,.38),.23,.9)
            rubber=pbr(og.sim.stage,'/World/Looks/TiltFixtureRubber',(.035,.035,.035),.65,0)
            def cylinder(path,position,radius,height,axis='Z'):
                prim=UsdGeom.Cylinder.Define(og.sim.stage,path);prim.CreateRadiusAttr(radius);prim.CreateHeightAttr(height)
                prim.CreateAxisAttr(axis);prim.AddTranslateOp().Set(Gf.Vec3d(*position))
                UsdShade.MaterialBindingAPI.Apply(prim.GetPrim()).Bind(steel)
                UsdPhysics.CollisionAPI.Apply(prim.GetPrim())
            cylinder('/World/TiltFixture/Base',[-.65,.05,.012],.075,.024)
            cylinder('/World/TiltFixture/Post',[-.65,.05,.17],.009,.30)
            cylinder('/World/TiltFixture/Axle',[-.565,.05,.32],.005,.18,'X')
            mount=UsdGeom.Xform.Define(og.sim.stage,'/World/TiltFixture/Clamp')
            mount.AddTranslateOp().Set(Gf.Vec3d(*center));clamp_rotation=mount.AddRotateXOp()
            lathe(og.sim.stage,'/World/TiltFixture/Clamp/Ring',
                  [(-.004,.025),(-.004,.029),(.004,.029),(.004,.025)],rubber,segments=96)
        camera([-.81,.86,.68],[-.43,.17,.16],26)
        floorcam=VisionSensor(relative_prim_path='/floor_film_validation_camera',name='floor_film_validation_camera',
                modalities=['rgb'],image_width=1280,image_height=720,focal_length=32.,clipping_range=(.01,100.))
        floorcam.load(None);floorcam.initialize()
        eye=np.array([-.68,.53,.23]);target=np.array([-.44,.15,.002])
        z=eye-target;z/=np.linalg.norm(z);x=np.cross([0,0,1],z);x/=np.linalg.norm(x)
        q=Rotation.from_matrix(np.column_stack([x,np.cross(z,x),z])).as_quat()
        floorcam.set_position_orientation(position=torch.tensor(eye,dtype=torch.float32),orientation=torch.tensor(q,dtype=torch.float32))
        fps=10 if preview else 30
        writers=[imageio.get_writer(str(output/name),fps=fps,codec='libx264',quality=None,macro_block_size=16,
                     ffmpeg_params=['-crf','16','-movflags','+faststart']) for name in ('pour.mp4','floor.mp4')]
        # Hold the background Fetch's actual initial end-effector pose.
        bp,bq=robot.get_position_orientation();p,q=robot.get_eef_pose()
        inv=Rotation.from_quat(bq.cpu().numpy()).inv()
        arm=np.r_[inv.apply((p-bp).cpu().numpy()),(inv*Rotation.from_quat(q.cpu().numpy())).as_rotvec()]
        action=torch.zeros(robot.action_dim,dtype=torch.float32,device=og.sim.device)
        action[robot.controller_action_idx['arm_0']]=torch.tensor(arm,dtype=torch.float32,device=og.sim.device)
        action[robot.controller_action_idx['gripper_0']]=1
        records=[];count=0
        def smooth(x):x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))
        for i in range(round(seconds*60)):
            t=(i+1)/60
            angle=75*smooth((t-1)/1.5)*(1-smooth((t-4)/1.5))
            with og.sim.editing_usd():clamp_rotation.Set(float(-angle))
            cup.set_position_orientation(position=torch.tensor(center,dtype=torch.float32),
                orientation=torch.tensor(Rotation.from_euler('x',-angle,degrees=True).as_quat(),dtype=torch.float32))
            ep.phase='tilting cup' if 1<t<4 else ('returning cup upright' if 4<=t<5.5 else 'observing liquid')
            with og.sim.render_on_step(False):env.step(action.unsqueeze(0))
            ep.tick=i+1;liquid.sample()
            if (i+1)%(60//fps)==0:
                liquid.surface.update(liquid.positions)
                og.sim.render()
                if not preview:settle_capture()
                views=[og.sim.viewer_camera,floorcam]
                for index,view in enumerate(views):
                    rgb=view.get_obs()[0]['rgb'].cpu().numpy()[...,:3].astype(np.uint8)
                    writers[index].append_data(rgb)
                    if count==0:imageio.imwrite(output/('poster.jpg' if index==0 else 'floor-poster.jpg'),rgb)
                    if (i+1)%60==0:imageio.imwrite(output/f'{"pour" if index==0 else "floor"}-{round(t):02d}.jpg',rgb)
                records.append({'t':t,'cup_tilt_deg':angle,'phase':ep.phase,**liquid.snapshot,'film':liquid.film.snapshot()})
                count+=1
            if (i+1)%60==0:print('LIQUID_VALIDATION',round(t,2),liquid.snapshot,liquid.film.snapshot(),flush=True)
        for writer in writers:writer.close()
        fluid=liquid.result()
        assert abs(liquid.film.snapshot()['volume_error_ml'])<1e-7
        assert len(liquid.film.deposits)==len({x['particle_id'] for x in liquid.film.deposits})
        data={'kind':'controlled_cup_tilt_validation','benchmark_episode':False,'preview':preview,
              'cup_motion':'Prescribed kinematic fixture, smooth 0 to 75 degree tilt and return; no robot grasp execution',
              'seconds':seconds,'fps':fps,'frames':count,'physics_hz':480,'control_hz':60,
              'initial_particle_positions_sha256':hashlib.sha256(liquid.initial_particle_positions.astype('<f4').tobytes()).hexdigest(),
              'liquid':fluid,'rendering':rendering,'records':records,
              'source_sha256':source_sha256,
              'limitations':['Uncalibrated surface model; not a measurement of real wetting area.',
                             'One-way film coupling; no absorption, temperature, injury or slip-friction simulation.',
                             'No generated frames, no particles added during the test; floor volume originates in measured PBD contacts.']}
        assert all(hashlib.sha256((ROOT/'simulation'/name).read_bytes()).hexdigest()==sha
                   for name,sha in source_sha256.items()),'Source changed during recording'
        (output/'validation.json').write_text(json.dumps(data,indent=2)+'\n')
        print('VALIDATION_FINISHED',count,flush=True)
    finally:og.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--preview',action='store_true');p.add_argument('--seconds',type=float,default=10.)
    a=p.parse_args();run(a.output,a.preview,a.seconds)
