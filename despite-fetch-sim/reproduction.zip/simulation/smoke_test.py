"""Load the real Fetch articulation and render a short native OmniGibson scene."""

import json
from pathlib import Path

from simulation.runtime import configure

configure()

import imageio.v3 as iio
import torch
import omnigibson as og
from omnigibson.macros import gm

gm.USE_GPU_DYNAMICS = False
gm.ENABLE_TRANSITION_RULES = False
gm.DEFAULT_VIEWER_WIDTH = 960
gm.DEFAULT_VIEWER_HEIGHT = 640


def main():
    env = og.Environment(configs={
        "env": {"action_frequency": 30, "rendering_frequency": 30, "physics_frequency": 120},
        "scene": {"type": "Scene", "floor_plane_color": [0.16, 0.2, 0.25]},
        "robots": [{"model": "fetch", "name": "fetch", "obs_modalities": [], "grasping_mode": "physical"}],
        "objects": [{"type": "PrimitiveObject", "name": "test_cube", "primitive_type": "Cube", "size": 0.08, "position": [0.8, 0.0, 0.5], "rgba": [0.1, 0.8, 0.6, 1.0]}],
    })
    robot = env.scene.robots[0]
    print("FETCH_LOADED", len(robot.joints), robot.action_dim, flush=True)
    print("CONTROLLERS", robot.controller_action_idx, flush=True)
    print("JOINTS", list(robot.joints), flush=True)
    print("EEF", robot.get_eef_pose(), flush=True)
    og.sim.viewer_camera.set_position_orientation(
        position=torch.tensor([-2.39951, 2.26469, 2.66227]),
        orientation=torch.tensor([-0.23898481, 0.48475231, 0.75464013, -0.37204802]),
    )
    for _ in range(60):
        env.step(torch.zeros((1, robot.action_dim)))
    obs, _ = og.sim.viewer_camera.get_obs()
    image = obs["rgb"].cpu().numpy()[..., :3]
    out = Path("simulation/runs/smoke")
    out.mkdir(parents=True, exist_ok=True)
    iio.imwrite(out / "fetch.png", image)
    (out / "result.json").write_text(json.dumps({"status": "passed", "isaacsim": "6.0.1", "omnigibson": og.__version__, "frames": 60, "image_shape": list(image.shape)}, indent=2))
    print("SMOKE_PASSED", image.shape, flush=True)
    og.shutdown()


if __name__ == "__main__":
    main()
