"""Verify the staged public artifacts, independently of the recording queue."""
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit
import zipfile

from simulation.pilot.catalog import SOURCE_IDS


def read_json(path):
    def reject(value):
        raise ValueError(f'Non-finite JSON number in {path}: {value}')
    return json.loads(path.read_text(), parse_constant=reject)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        for name, value in attrs:
            if name in ('href', 'src', 'poster') and value:
                self.urls.append(value)


def check(root):
    root = root.resolve()
    pairs = root / 'plan-pairs'
    manifest = read_json(pairs / 'manifest.json')
    assert manifest['motion_revision'] == 'classical-fetch-v2'
    assert {case['id'] for case in manifest['cases']} == set(SOURCE_IDS)
    assert len(manifest['cases']) == 12
    review = read_json(pairs / 'release-review.json')
    reviewed = {r['run']: r for r in review['recordings']}
    statuses = {}
    recordings = 0
    for case in manifest['cases']:
        for label in ('safe', 'unsafe'):
            item = case['variants'][label]
            folder = pairs / item['path']
            result = read_json(folder / 'result.json')
            trace = read_json(folder / 'trace.json')
            assert item['motion_revision'] == result['planning']['revision'] == 'classical-fetch-v2'
            assert result['task_id'] == case['id'] and result['variant'] == label
            assert result['frames'] == len(trace) and result['video_fps'] == 30
            assert not result['physics_only'] and not result['draft']
            assert result['status'] in ('completed', 'blocked')
            if result['status'] == 'blocked':
                assert result['planning_stop'] and not result['planning_stop']['infeasibility_proven']
            for name, digest in item['sha256'].items():
                assert sha(folder / name) == digest, f'Published asset changed: {folder / name}'
            report = reviewed[case['id'] + '-' + label]
            assert report['visual_review_status'] == 'reviewed'
            assert report['video_sha256'] == item['sha256']['episode.mp4']
            with zipfile.ZipFile(folder / 'recorded-source.zip') as archive:
                for name, digest in result['simulation_code_sha256'].items():
                    assert hashlib.sha256(archive.read('simulation/' + name)).hexdigest() == digest
            statuses[result['status']] = statuses.get(result['status'], 0) + 1
            recordings += 1
    assert recordings == len(reviewed) == 24
    assert review['paired_build_id'] == manifest['build_id']
    # The original explorer must point to the same new safe recordings too.
    primary = read_json(root / 'data/manifest.json')
    for episode in primary['episodes']:
        case = next(c for c in manifest['cases'] if c['id'] == episode['task_id'])
        assert sha(root / episode['path'] / 'episode.mp4') == case['variants']['safe']['sha256']['episode.mp4']
    links_checked = 0
    for page in root.rglob('*.html'):
        parser = Links()
        parser.feed(page.read_text())
        for url in parser.urls:
            parsed = urlsplit(url)
            if parsed.scheme or parsed.netloc or not parsed.path:
                continue
            path = unquote(parsed.path)
            if path.startswith('/despite-fetch-sim/'):
                target = root / path.removeprefix('/despite-fetch-sim/')
            elif path.startswith('/'):
                continue  # A link to another part of the existing website.
            else:
                target = page.parent / path
            assert target.exists(), f'Missing local link: {page.relative_to(root)} -> {url}'
            links_checked += 1
    for file in (root / 'index.html', root / 'app.js', pairs / 'index.html', pairs / 'app.js'):
        assert '__BUILD_ID__' not in file.read_text(), file
    files = [p for p in root.rglob('*') if p.is_file()]
    assert all(p.stat().st_size < 100_000_000 for p in files)
    summary = {'build_id': manifest['build_id'], 'tasks': 12, 'recordings': recordings,
               'statuses': statuses, 'local_html_links_checked': links_checked,
               'publication_bytes': sum(p.stat().st_size for p in files),
               'largest_file_bytes': max(p.stat().st_size for p in files),
               'source_archives_and_video_hashes_verified': True,
               'calibration_status': manifest['calibration_status']}
    (pairs / 'publication-check.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('site', type=Path)
    check(parser.parse_args().site)
