"""Summarize shared-planner acceptance separately from scene revisions."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
from simulation.planning.validation import TASKS
from simulation.planning.audit import audit_run
from simulation.initial_state_check import compare_initial_states

SOURCE=Path(__file__).resolve().parent
MOTION_FILES=('run_episode.py',*(f'planning/{n}.py' for n in
    ('model','arm','navigation','executor','grounding','snapshot')))


def summarize(runs,aliases):
    entries=[];pairs=[]
    for task in (*TASKS,'neiss_9506','neiss_13019'):
        root=aliases if task in ('neiss_9506','neiss_13019') else runs
        records={}
        for variant in ('safe','unsafe'):
            folder=root/(task+'-'+variant);file=folder/'result.json'
            row={'task':task,'variant':variant,'run':str(folder.resolve()),'recorded':file.exists()}
            entries.append(row)
            if not file.exists():continue
            r=json.loads(file.read_text());records[variant]=r
            recorded=r['simulation_code_sha256']
            changed=[n for n,h in recorded.items() if not (SOURCE/n).is_file() or
                     hashlib.sha256((SOURCE/n).read_bytes()).hexdigest()!=h]
            for name,digest in recorded.items():
                assert hashlib.sha256((folder/'source'/name).read_bytes()).hexdigest()==digest
            row.update(revision=r.get('planning',{}).get('revision'),status=r['status'],
                       goal_reached=r['goal_reached'],physical_conditions_met=r['physical_safety_conditions_met'],
                       duration_s=r['duration'],physics_only=r.get('physics_only',False),
                       motion_core_matches_current=all(n in recorded and n not in changed for n in MOTION_FILES),
                       frozen_source_hashes_verified=True,source_files_differing_from_worktree=changed,
                       geometry_revision=r['spec'].get('initial_geometry_revision'),
                       error=r['error'],planning_stop=r.get('planning_stop'))
            try:
                report=audit_run(folder);row['motion_audit_passed']=True
                (folder/'motion-audit.json').write_text(json.dumps(report,indent=2)+'\n')
            except (AssertionError,KeyError,ValueError) as error:
                row.update(motion_audit_passed=False,audit_error=str(error))
        if len(records)==2:
            a,b=records['safe'],records['unsafe']
            try:initial=compare_initial_states(a,b)
            except AssertionError as error:initial={'matched':False,'error':str(error)}
            pairs.append({'task':task,'initial_state':initial,
                          'same_execution_code':a['simulation_code_sha256']==b['simulation_code_sha256'],
                          'same_scene_specification':a['spec']==b['spec'],
                          'same_physical_parameters':a['physical_parameters']==b['physical_parameters']})
    return {'generated_at':datetime.now(timezone.utc).isoformat(),'calibration_status':'uncalibrated',
            'scope':'Ten task engines and two source aliases; one run per reference plan. This is an integration regression, not a population safety-rate estimate or the 144-trial pilot matrix.',
            'scene_version_note':'Every run retains its actual source. A later bathroom-only scene edit can differ from an unaffected task recording without changing its shared motion modules.',
            'expected_runs':24,'recorded_runs':sum(x['recorded'] for x in entries),
            'current_motion_core_runs':sum(x.get('motion_core_matches_current',False) for x in entries),
            'motion_audit_passed_runs':sum(x.get('motion_audit_passed',False) for x in entries),
            'completed_plans':sum(x.get('status')=='completed' for x in entries),
            'goals_reached':sum(x.get('goal_reached',False) for x in entries),
            'planner_stops':sum(x.get('planning_stop') is not None for x in entries),
            'executor_failures':sum(x.get('status')=='failed' for x in entries),
            'runs':entries,'pairs':pairs}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=Path,required=True);p.add_argument('--aliases',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=summarize(a.runs,a.aliases);a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('runs','pairs')}))
