"""Executable, measured Fetch episodes grounded in DESPITE hard-1044."""
