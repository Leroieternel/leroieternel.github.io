"""Render a surface reconstructed only from measured PBD particle positions.

This mesh has no collision or rigid-body API. It never changes the fluid state.
Connected particle clusters are meshed separately to avoid a room-sized voxel
grid. The same reconstruction is used for both reference plans.
"""
import numpy as np
from scipy.ndimage import gaussian_filter, label


class LiquidSurface:
    def __init__(self,material):
        import omnigibson as og
        from pxr import UsdGeom, UsdShade, Sdf
        self.mesh=UsdGeom.Mesh.Define(og.sim.stage,'/World/MeasuredLiquidSurface')
        self.mesh.CreateSubdivisionSchemeAttr('none')
        self.mesh.CreateDoubleSidedAttr(True)
        # Use an explicit coffee-like visual material on the reconstructed
        # mesh; the PBD system retains its independent physical material.
        mat=UsdShade.Material.Define(og.sim.stage,'/World/Looks/MeasuredHotLiquid')
        shader=UsdShade.Shader.Define(og.sim.stage,'/World/Looks/MeasuredHotLiquid/Shader')
        shader.CreateIdAttr('UsdPreviewSurface')
        shader.CreateInput('diffuseColor',Sdf.ValueTypeNames.Color3f).Set((.075,.022,.007))
        shader.CreateInput('roughness',Sdf.ValueTypeNames.Float).Set(.12)
        shader.CreateInput('metallic',Sdf.ValueTypeNames.Float).Set(0.)
        shader.CreateInput('ior',Sdf.ValueTypeNames.Float).Set(1.333)
        mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(),'surface')
        UsdShade.MaterialBindingAPI.Apply(self.mesh.GetPrim()).Bind(mat)

    def update(self,positions):
        import omnigibson as og
        with og.sim.editing_usd():
            self._update(positions)

    def _update(self,positions):
        import warp as wp
        from pxr import Vt
        p=np.asarray(positions,dtype=np.float32)
        # Separate disconnected droplets / floor pools from the cup volume.
        lo=p.min(0)-.025;cells=np.floor((p-lo)/.025).astype(int)
        occupancy=np.zeros(tuple(cells.max(0)+2),bool)
        occupancy[tuple(cells.T)]=True
        groups,_=label(occupancy,np.ones((3,3,3),bool))
        ids=groups[tuple(cells.T)]
        vertices=[];triangles=[];offset=0
        for group in np.unique(ids):
            points=p[ids==group]
            extent=np.maximum(np.ptp(points,axis=0),.006)
            h=max(.0014,float((np.prod(extent)/2000000)**(1/3)))
            lower=points.min(0)-4*h
            shape=np.maximum(np.ceil((points.max(0)-lower)/h).astype(int)+5,9)
            field=np.zeros(tuple(shape),np.float32)
            q=(points-lower)/h
            ijk=np.floor(q).astype(int);fraction=q-ijk
            for x in (0,1):
                for y in (0,1):
                    for z in (0,1):
                        d=np.array([x,y,z]);weight=np.prod(np.where(d,fraction,1-fraction),axis=1)
                        np.add.at(field,tuple((ijk+d).T),weight)
            field=gaussian_filter(field,.85)
            # Kernel level controls visualization only; spill volume is counted
            # directly from particles, never from this interpolated surface.
            if field.max()<.055:continue
            verts,faces=wp.MarchingCubes.extract_surface_marching_cubes(wp.array(field,dtype=wp.float32,device='cuda:0'),.055)
            v=verts.numpy()*h+lower;f=faces.numpy().reshape(-1,3)
            if not len(f):continue
            vertices.append(v);triangles.append(f+offset);offset+=len(v)
        if not vertices:
            self.mesh.GetPointsAttr().Set([]);self.mesh.GetFaceVertexIndicesAttr().Set([]);self.mesh.GetFaceVertexCountsAttr().Set([])
            return
        v=np.concatenate(vertices).astype(np.float32);f=np.concatenate(triangles).astype(np.int32)
        # Density fields increase inward, so reverse winding for outward normals.
        f=f[:,::-1].copy()
        n=np.zeros_like(v);face_n=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
        for i in range(3):np.add.at(n,f[:,i],face_n)
        n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-12)
        self.mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(v))
        self.mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(f.ravel()))
        self.mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(np.full(len(f),3,np.int32)))
        self.mesh.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(n));self.mesh.SetNormalsInterpolation('vertex')
        self.mesh.CreateExtentAttr([v.min(0).tolist(),v.max(0).tolist()])
