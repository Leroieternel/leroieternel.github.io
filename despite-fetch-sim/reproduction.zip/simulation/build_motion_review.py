"""Extract an action-aligned before/after clip from two verified physical runs."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

import imageio.v2 as imageio

ROOT = Path(__file__).resolve().parent


def build(before, after, output):
    output.mkdir(parents=True, exist_ok=True)
    report = {'comparison': 'Two physical executions of the same reference plan and camera; aligned by withdrawal onset.',
              'clips': {}}
    for name, source in [('before', before), ('after', after)]:
        result = json.loads((source/'result.json').read_text())
        trace = json.loads((source/'trace.json').read_text())
        assert result['goal_reached'] and result['physical_safety_conditions_met']
        start = next(i for i, state in enumerate(trace) if state['phase']=='retracting')
        fps = result['video_fps']
        first = max(0, start-fps//2)
        last = min(len(trace), first+4*fps)
        reader = imageio.get_reader(source/'episode.mp4')
        writer = imageio.get_writer(str(output/f'{name}.mp4'), fps=fps, codec='libx264', quality=None,
                                   macro_block_size=16, ffmpeg_params=['-crf','14','-movflags','+faststart'])
        try:
            for i in range(first, last):
                frame = reader.get_data(i)
                writer.append_data(frame)
                if i==first: imageio.imwrite(output/f'{name}.jpg', frame)
        finally:
            reader.close(); writer.close()
        shutil.copy2(source/'result.json', output/f'{name}-result.json')
        report['clips'][name] = {'run':source.name, 'first_video_frame':first, 'frames':last-first,
                                'fps':fps, 'result_file':f'{name}-result.json',
                                'source_result_sha256':hashlib.sha256((source/'result.json').read_bytes()).hexdigest(),
                                'rendering':result.get('rendering', {'antialiasing':'DLSS Quality',
                                                'extra_render_updates_per_recorded_frame':0})}
    assert report['clips']['before']['frames']==report['clips']['after']['frames']
    (output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    shutil.copy2(ROOT/'motion_review/index.html', output/'index.html')
    print(json.dumps({'output':str(output),'frames':report['clips']['after']['frames']}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before',type=Path,required=True)
    parser.add_argument('--after',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    build(args.before,args.after,args.output)
