# Composable DESPITE object models

This package separates **object category**, **capabilities**, and **concrete asset**.
It is integrated into the shared `Episode` recorder, so the same observers run
for every task and both reference variants. State evolution never receives a
safe/unsafe reference label.

## Implemented mechanisms

| Module | Runtime behavior | Evidence / limits |
| --- | --- | --- |
| M01 Spatial | Pose and full-AABB region containment | Measured pose; declared regions |
| M02 Grasp | Bilateral finger contact, relative-motion and dwell checks; separate attachment observation | An inference with explicit tolerances; aggregate robot contact is insufficient |
| M03 Articulation | Joint opening fraction and lock observation | Requires actual joint position and declared limits |
| M04 Motion | Velocity, acceleration and translational energy | Contact force is unknown unless supplied |
| M05 Collision | Contact, impulse, clearance and threshold crossing | Distance violation is not injury |
| M06 Support | Contact/footprint support; velocity and dwell stability; falling detection | Missing contact/constraint information stays unknown |
| M07 Damage | Measured broken state or optional impact-energy trigger | Reduced-order prediction; no automatic fracture geometry |
| M08 Liquid | Actual particle volume, spill threshold, floor volume; optional conservative transfer ledger | Measured PBD and ledger modes cannot be mixed |
| M09 Thermal | Temperature observations or exact lumped-capacity cooling/heating ODE | Requires mass, heat capacity, conductance, ambient temperature and power; no burn model |
| M10 Electrical | Connected/switch state; optional resistive current and power | No electrocution model or general circuit solver |
| M11 Contamination | Measured load or contact-gated removal and conservative transfers | Removed mass is tracked separately; not microbial validation |
| M12 Processing | Observed shape or contact-evidenced, mass-conserving discrete transformation | No mesh cutting/deformation solver |
| M13 Perception | Timestamped belief, confidence and expiration | Belief does not overwrite world truth |
| M14 Human | Presence, posture, occupancy and explicit injury observations | Static/scripted actors do not establish injury outcomes |
| M15 Permission | Actor/operation grants, expiry, revocation, access events | Explicit authority and policy; separate from physical reachability |
| M16 Communication | Recipient/message/delivery events; optional free-field sound attenuation | No inferred human emotion or reception |
| M17 Protocol | Event automaton, preconditions and ordering violations | E.g. processing must precede storage; violation is independent of injury |
| M18 Progress | Three-valued goal conjunction and observed action status | Goals and safety are independent |

These are **18 working state mechanisms, not 18 high-fidelity physics solvers**.
Rigid dynamics and particle flow continue to run in Isaac/PhysX. Simplified
models and business rules retain different evidence types. The package does
not automatically implement every predicate in all 12,279 DESPITE records;
each task still needs reviewed entity bindings, scene geometry and parameters.
All physical parameters remain **uncalibrated** until real measurements exist.

## Composition

```python
from simulation.object_models import World, compose

world = World({
    "cup": compose("cup", {"M09": {
        "mode": "lumped", "mass_kg": 0.25,
        "specific_heat_j_kg_k": 4180, "conductance_w_k": 1.2,
        "initial_temperature_c": 80,
    }}),
    "chair": compose("chair"),
})
world.step(0)
state = world.step(1, {"cup": {
    "ambient_temperature_c": 22, "heat_power_w": 0,
}})
```

The category profiles contain observer defaults. A cup supports rigid motion,
grasp, support, liquid and thermal state; this alone does not invent a fill
volume or temperature. Reduced-order modes require explicit parameters.

`World.step(t, observations, events)` returns evidence-bearing states and
discrete transitions. Times strictly increase. Events have unique IDs, target
objects and evidence sources. Invalid transfers, duplicate events, nonfinite
inputs and invalid transitions cannot partially mutate the world. Fluid and
contamination transfers conserve quantity across their source and target.

## Shared simulator integration

New runs write:

- `object-states.jsonl`: timestamped state for payload, robot, destination,
  and applicable hazard/chair/staff/workflow roles.
- `object-models.json`: configuration, final states, events, transition evidence
  and explicit limitations.
- `result.json.object_models`: references to these files.
- `result.json.object_asset`: source hash, selected asset, measured dimensions,
  effective mass, friction, grasp recipe and validation status.

The current bridge observes the explicit task roles, not every triangle of the
room. M06 in this bridge names the destination support; `supported: false`
there does not mean the object lacks support elsewhere. M18's bridge subgoal is destination support; the original PDDL goal is
still evaluated separately. M17 in the reception task follows actual recorded
staff-processing and storage observations, not the names of plan actions.

The model layer does not currently write thermal, electrical, contamination or
fracture predictions back into PhysX/materials. Those mechanisms can already
be stepped and evaluated through the API; scene-specific sources/sensors and
visual effects must be bound before claiming those phenomena are physically
simulated. Missing measurements produce `null` with `basis: unknown`.

## Asset diversity

`assets.json` supplies six semantic entries: three water-bottle models (Genie
017, BEHAVIOR ackxiy/lzdzkk), one medicine bottle, one carton and the existing
fluid-compatible cup. Automatic draws exclude experimental entries. The thin
neck of ackxiy slipped in physical trials, so that model requires an explicit
asset ID and is not automatically assigned. Additional entries use the same contract.
The two BEHAVIOR bottles come from the installed licensed dataset. Their
original material maps are retained; local baked derivatives are not published.

```bash
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --variant safe --native --asset-policy scene --asset-seed 0 \
  --asset-id behavior-water-lzdzkk \
  --output simulation/runs/assets-v1/neiss_2888-safe

# Use the same task + seed (or explicit ID) for the unsafe member.
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --variant unsafe --native --asset-id behavior-water-lzdzkk \
  --output simulation/runs/assets-v1/neiss_2888-unsafe
```

Selection hashes the **source** task/scene-instance ID, seed and category,
including tasks that share a lower-level engine template; it never uses the
reference variant. It does not silently select another model if a local file
is missing. `--asset-policy fixed` reproduces the legacy asset choice. Frozen
pilot experiments retain their original assets unless explicitly overridden.
Both `simulation.run_batch` and `simulation.pilot.run` accept `--asset-policy`,
`--asset-seed` and `--asset-id`; the pilot defaults to `fixed`. Batch resume
checks the requested asset policy/seed/ID as well as the implementation hashes,
so changing the asset draw cannot silently reuse an earlier recording.

Swaps rebake actual mesh/colliders, measure dimensions, adjust grasp height,
mass and friction, recompute footprint and support heights, and feed the live
geometry into the existing v2 planner. BEHAVIOR bottles preserve their authored
collision decomposition: a single convex hull fills a bottle's neck/shoulder
concavity and is not an adequate grasp contact model. A failed grasp or no feasible route is
reported as such; the object is never attached just to make the run succeed.
The initial recipes for newly added assets require an actual episode check.

Medication and drinking-water categories cannot be interchanged. The kitchen
fluid task requires `fluid_vessel_cup105`, so arbitrary cup meshes are rejected
until they have a matching hollow vessel, capacity and fluid setup.

## Offline execution and validation

```bash
python -m unittest simulation.object_models.test_models -v
python -m simulation.object_models --inventory --output simulation/reports/object-models-v1/inventory
python -m simulation.object_models \
  --replay-run simulation/runs/classical-v2-video-release/neiss_11868-unsafe \
  --output simulation/reports/object-models-v1/neiss_11868-unsafe
python -m simulation.object_models --config config.json --input observations.jsonl --output output-dir
```

Config format: `{"objects": {"cup": {"category": "cup", "modules": {"M08": {}}}}}`.
Each JSONL input has `t`, `observations` keyed by object, and optional `events`.
Offline replay checks observer integration; it is not a new physical experiment.

If `nvidia-smi` fails inside the restricted command sandbox but works on the
host, run the GPU validation with device-accessible execution. This alone is
not evidence of a broken driver and does not warrant reinstalling it.

## Validation snapshot (2026-11-15)

See `simulation/reports/object-models-v1/validation.json` for the machine-readable
record. All 23 mechanism/asset tests and 10 existing transition tests passed;
24 historical runs (35,578 samples) were replayed through the observer layer.
These replays are not new physics experiments.

Two new Isaac Sim 6.0.1 / OmniGibson 3.9.3 episodes used
`behavior-water-lzdzkk`, with identical initial state, recorded implementation
and asset parameters. Both action sequences completed. The safe placement had
17.5 cm edge clearance. The unsafe placement overhung the declared support by
0.98 cm and failed its full-footprint condition; the bottle remained at rest,
so no fall or breakage is claimed. The recordings are diagnostic 10 fps runs.

The native run sources remain immutable. Updated M02 observation reports are
stored separately under `native-replays/`: a small seating shift during lift
is distinguished from losing a bilateral hold for the remainder of the run.
Three failed `behavior-water-ackxiy` trials are retained; this asset remains
experimental and is excluded from automatic draws.
