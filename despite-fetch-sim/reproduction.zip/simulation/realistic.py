"""Furnished, enclosed interiors rendered by Isaac Sim RTX.

BEHAVIOR furniture, CC0 Poly Haven materials and USD assets. Task supports
retain dimensioned collision proxies; decorative meshes never drive results.
"""
import json
import math
from pathlib import Path
from simulation.runtime import RUNTIME
from simulation.scenes import box

ASSETS = RUNTIME / 'datasets/behavior-1k-assets/objects'
MATERIALS = RUNTIME / 'materials'
MODELS = RUNTIME / 'models'


def furniture(name, category, model, center, size, yaw=0):
    metadata = json.loads((ASSETS / category / model / 'misc/metadata.json').read_text())
    offset = [size[i] / metadata['bbox_size'][i] * metadata['base_link_offset'][i] for i in range(3)]
    c, s = math.cos(yaw), math.sin(yaw)
    rotated = [c*offset[0]-s*offset[1], s*offset[0]+c*offset[1], offset[2]]
    return dict(type='DatasetObject', name=name, category=category, model=model, bounding_box=size,
                position=[center[i]-rotated[i] for i in range(3)],
                orientation=[0,0,math.sin(yaw/2),math.cos(yaw/2)], fixed_base=True, visual_only=True)


def upgrade_config(config, task_id):
    bedroom = task_id == 'neiss_2888'
    # Replace the open test stage with a complete architectural shell.
    objects = [o for o in config['objects'] if o['name'] not in {'back_wall','end_wall','baseboard'}]
    hidden = {'storage_top','storage_body','storage_handle','bed_frame','mattress','blanket','pillow',
              'bedside_table','bedside_base','sink_cabinet','sink_top','mirror','toilet_bowl','toilet_foot','tank_plinth','toilet_tank'}
    for obj in objects:
        if obj['name'] in hidden: obj['visible'] = False
    plaster = [.79,.76,.69]
    trim = [.88,.85,.78]
    objects += [
        box('textured_floor', [-.10,-.35,-.018], [5.8,5.9,.035], [1,1,1], visual_only=True),
        box('end_wall', [-.1,2.6,1.5], [5.8,.12,3.0], [.46,.54,.48] if bedroom else plaster),
        box('entry_wall', [-.1,-3.3,1.5], [5.8,.12,3.0], plaster),
        box('left_wall', [-3.0,-.35,1.5], [.12,5.9,3.0], plaster),
        box('ceiling', [-.1,-.35,3.02], [5.8,5.9,.08], [.91,.89,.83]),
        # A real window opening in the east wall, with light entering the room.
        box('east_wall_low', [2.8,-.35,.48], [.12,5.9,.96], plaster),
        box('east_wall_high', [2.8,-.35,2.76], [.12,5.9,.48], plaster),
        box('east_wall_left', [2.8,-2.35,1.74], [.12,1.9,1.56], plaster),
        box('east_wall_right', [2.8,1.50,1.74], [.12,2.2,1.56], plaster),
        box('window_sill', [2.70,-.50,.96], [.34,1.9,.07], trim),
        box('window_frame_top', [2.74,-.50,2.5], [.10,1.84,.07], trim),
        box('window_frame_left', [2.74,-1.4,1.73], [.10,.07,1.54], trim),
        box('window_frame_right', [2.74,.40,1.73], [.10,.07,1.54], trim),
        box('window_mullion', [2.74,-.50,1.73], [.07,.035,1.54], trim),
        box('window_crossbar', [2.74,-.50,1.7], [.07,1.80,.035], trim),
        furniture('storage_cabinet_visual','nightstand','hessxe',[.70,-1,.37],[.70,.70,.74]),
        furniture('plant','pot_plant','mqhlkf',[2.20,-2.35,.70],[.60,.64,1.40]),
    ]
    for name, pos, size in [
        ('skirting_east',[2.72,-.35,.065],[.04,5.78,.13]),
        ('skirting_end',[-.1,2.52,.065],[5.65,.04,.13]),
        ('skirting_left',[-2.92,-.35,.065],[.04,5.78,.13]),
        ('cornice_east',[2.71,-.35,2.94],[.12,5.78,.12]),
        ('cornice_end',[-.1,2.51,2.94],[5.65,.12,.12]),
    ]: objects.append(box(name,pos,size,trim))
    if bedroom:
        objects += [
            furniture('bed_visual','bed','mpgavt',[1.91,.12,.39],[2.08,1.50,.78],yaw=-math.pi/2),
            furniture('bedside_cabinet_visual','nightstand','hessxe',[.70,1,.37],[.70,.72,.74]),
            furniture('reading_lamp','floor_lamp','ogolip',[2.2,1.8,.85],[.46,.34,1.70]),
            furniture('wall_art','painting','jykkya',[1.90,2.50,1.85],[.025,.90,.78],yaw=-math.pi/2),
            furniture('bedside_rug','carpet','ctclvd',[.65,.02,.008],[1.45,2.65,.012]),
            box('sofa_collision',[-1.3,2.0,.43],[2.2,.9,.86],[.3,.3,.3],visible=False),
        ]
    else:
        objects += [
            furniture('bathroom_vanity','furniture_sink','czyfhq',[2.40,-.55,.51],[.60,.90,1.02]),
            furniture('toilet_visual','toilet','obhimx',[1.24,1.0,.36],[.78,.50,.72],yaw=math.pi),
            furniture('bath_mat','carpet','ctclvd',[.80,-.05,.008],[.65,.85,.012]),
            furniture('bathroom_mirror','mirror','edxfnt',[-.65,2.51,1.8],[.02,1.05,.76],yaw=-math.pi/2),
            furniture('towel_rail','towel_rack','pqhsry',[-.65,2.46,1.12],[.07,.56,.08],yaw=-math.pi/2),
            box('flush_button',[.77,1.22,.808],[.045,.085,.008],[.5,.53,.54],visual_only=True),
        ]
    config['objects'] = objects
    config['scene'].update(floor_plane_visible=False, use_skybox=False)
    config['render'] = {'viewer_width':1440,'viewer_height':960}
    return config


def _pbr(stage, name, color, roughness=.6, metal=0):
    import omnigibson.lazy as L
    S=L.pxr.UsdShade; T=L.pxr.Sdf.ValueTypeNames
    mat=S.Material.Define(stage, '/World/DecorMaterials/'+name)
    shader=S.Shader.Define(stage, mat.GetPath().AppendChild('Shader'))
    shader.CreateIdAttr('UsdPreviewSurface')
    shader.CreateInput('diffuseColor',T.Color3f).Set(L.pxr.Gf.Vec3f(*color))
    shader.CreateInput('roughness',T.Float).Set(roughness)
    shader.CreateInput('metallic',T.Float).Set(metal)
    mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(),'surface')
    return mat


def _usd_asset(stage, name, asset, center, size, yaw=0):
    """Reference an external USD and fit its visual bounds without exporting it."""
    import omnigibson as og
    import omnigibson.lazy as L
    U,G=L.pxr.UsdGeom,L.pxr.Gf
    outer=U.Xform.Define(stage,'/World/Decor/'+name)
    content=U.Xform.Define(stage,outer.GetPath().AppendChild('Asset'))
    content.GetPrim().GetReferences().AddReference(str(MODELS/asset/f'{asset}_2k.usdc'))
    # Use native OmniPBR for consistent RTX support instead of relying on a
    # Blender MaterialX graph. Preserve the downloaded mesh and its UVs.
    material_path=f'/World/DecorMaterials/{name}PBR'
    material=L.pxr.UsdShade.Material.Define(stage,material_path)
    shader=L.pxr.UsdShade.Shader.Define(stage,material_path+'/Shader')
    shader.SetSourceAsset(L.pxr.Sdf.AssetPath('OmniPBR.mdl'),'mdl')
    shader.SetSourceAssetSubIdentifier('OmniPBR','mdl')
    shader.CreateOutput('out',L.pxr.Sdf.ValueTypeNames.Token)
    material.CreateSurfaceOutput('mdl').ConnectToSource(shader.ConnectableAPI(),'out')
    for input_name,filename in [('diffuse_texture',f'{asset}_diff_2k.jpg'),
                                ('normalmap_texture',f'{asset}_nor_gl_2k.exr'),
                                ('reflectionroughness_texture',f'{asset}_roughness_2k.jpg' if asset=='sofa_02' else f'{asset}_rough_2k.jpg')]:
        shader.CreateInput(input_name,L.pxr.Sdf.ValueTypeNames.Asset).Set(L.pxr.Sdf.AssetPath(str(MODELS/asset/'textures'/filename)))
    shader.CreateInput('diffuse_color_constant',L.pxr.Sdf.ValueTypeNames.Color3f).Set(G.Vec3f(1,1,1))
    shader.CreateInput('reflection_roughness_constant',L.pxr.Sdf.ValueTypeNames.Float).Set(.65)
    # Poly Haven's MaterialX network references EXR roughness, while its USD
    # download manifest supplies JPEG. Resolve that packaging mismatch locally.
    for prim in L.pxr.Usd.PrimRange(content.GetPrim()):
        if prim.IsA(U.Mesh):
            L.pxr.UsdShade.MaterialBindingAPI.Apply(prim).Bind(material, bindingStrength=L.pxr.UsdShade.Tokens.strongerThanDescendants)
        for attr in prim.GetAttributes():
            if attr.GetTypeName() == L.pxr.Sdf.ValueTypeNames.Asset:
                value=attr.Get()
                if value and value.path.startswith('./textures/'):
                    path=MODELS/asset/value.path
                    if not path.exists() and path.with_suffix('.jpg').exists():
                        attr.Set(L.pxr.Sdf.AssetPath(str(path.with_suffix('.jpg'))))
    cache=U.BBoxCache(L.pxr.Usd.TimeCode.Default(),[U.Tokens.default_,U.Tokens.render])
    bounds=cache.ComputeLocalBound(content.GetPrim()).ComputeAlignedRange()
    lo,hi=bounds.GetMin(),bounds.GetMax(); native=hi-lo
    scale=G.Vec3d(*[size[i]/native[i] for i in range(3)])
    mid=(lo+hi)*.5
    content.AddTranslateOp().Set(G.Vec3d(*[-mid[i]*scale[i] for i in range(3)]))
    content.AddScaleOp().Set(scale)
    outer.AddTranslateOp().Set(G.Vec3d(*center));outer.AddRotateZOp().Set(yaw)
    print('VISUAL_ASSET',asset,'native_bounds',list(native),flush=True)


def _rounded_box(stage,name,center,size,radius,material):
    """Bevelled ceramic geometry; dimensions match the controlled support."""
    import numpy as np
    import omnigibson.lazy as L
    U,S=L.pxr.UsdGeom,L.pxr.UsdShade
    points=[];indices=[];counts=[];n=16
    half=np.array(size)/2; inner=half-radius
    for axis in range(3):
        other=[a for a in range(3) if a!=axis]
        for sign in [-1,1]:
            start=len(points)
            for j in range(n+1):
                for i in range(n+1):
                    p=np.zeros(3);p[axis]=sign*half[axis]
                    p[other[0]]=(i/n*2-1)*half[other[0]];p[other[1]]=(j/n*2-1)*half[other[1]]
                    q=np.clip(p,-inner,inner);delta=p-q
                    p=q+radius*delta/np.linalg.norm(delta)+center;points.append(p.tolist())
            for j in range(n):
                for i in range(n):
                    a=start+j*(n+1)+i;indices.extend([a,a+1,a+n+2,a+n+1]);counts.append(4)
    mesh=U.Mesh.Define(stage,'/World/Decor/'+name);mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr(counts);mesh.CreateFaceVertexIndicesAttr(indices)
    mesh.CreateSubdivisionSchemeAttr('none');mesh.CreateDoubleSidedAttr(True)
    S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(material)


def finish_lighting(env, task_id='neiss_2888'):
    import omnigibson as og
    import omnigibson.lazy as L
    U,S,G,T=L.pxr.UsdGeom,L.pxr.UsdShade,L.pxr.Gf,L.pxr.Sdf.ValueTypeNames
    stage=og.sim.stage
    settings=L.carb.settings.get_settings()
    settings.set_int('/rtx/raytracing/showLights',0)
    settings.set_int('/rtx/post/dlss/execMode',1)
    settings.set_float('/rtx/sceneDb/ambientLightIntensity',.10)
    with og.sim.editing_usd():
        floor=env.scene.object_registry('name','textured_floor')
        shader=S.Shader(stage.GetPrimAtPath(f'{floor.prim_path}/Looks/default/Shader'))
        material='wood_floor' if task_id=='neiss_2888' else 'large_floor_tiles_02'
        for channel,input_name in [('Diffuse','diffuse_texture'),('nor_gl','normalmap_texture'),('Rough','reflectionroughness_texture')]:
            shader.CreateInput(input_name,T.Asset).Set(L.pxr.Sdf.AssetPath(str(MATERIALS/material/(channel+'.jpg'))))
        shader.CreateInput('texture_scale',T.Float2).Set(G.Vec2f(3.0,3.0))
        shader.CreateInput('reflection_roughness_constant',T.Float).Set(.42)
        shader.CreateInput('diffuse_color_constant',T.Color3f).Set(G.Vec3f(1,1,1))
        # Soft, broad lighting through the window; a dim ceiling bounce fill.
        for name,pos,intensity,color,w,h,rotation in [
            ('WindowKey',[2.70,-.50,1.85],3000,[1,.92,.80],1.65,1.4,[0,90,0]),
            ('CeilingFill',[-.2,-.25,2.92],1400,[1,.95,.87],4.5,4.5,[0,0,0]),
            ('CameraFill',[-2.6,-2.9,2.2],700,[.88,.94,1],3,2,[65,0,-40]),
        ]:
            light=L.pxr.UsdLux.RectLight.Define(stage,'/World/'+name)
            light.CreateIntensityAttr(intensity);light.CreateColorAttr(G.Vec3f(*color))
            light.CreateWidthAttr(w);light.CreateHeightAttr(h)
            xf=U.Xformable(light);xf.AddTranslateOp().Set(G.Vec3d(*pos));xf.AddRotateXYZOp().Set(G.Vec3f(*rotation))
        # Draped linen curtains: actual pleated meshes, with cast shadows.
        fabric=_pbr(stage,'Linen',[.64,.58,.47],.96)
        blind_mat=_pbr(stage,'PaintedBlinds',[.90,.88,.82],.6)
        glass_mat=_pbr(stage,'FrostedWindow',[.80,.86,.91],.35)
        glass_shader=S.Shader(stage.GetPrimAtPath('/World/DecorMaterials/FrostedWindow/Shader'))
        glass_shader.CreateInput('emissiveColor',T.Color3f).Set(G.Vec3f(.7,.75,.8))
        for name,position,scale,mat in [('FrostedGlass',[2.83,-.5,1.73],[.01,1.8,1.48],glass_mat)]+[
            (f'Blind{i}',[2.66,-.50,1.05+i*.067],[.085,1.78,.012],blind_mat) for i in range(21)]:
            cube=U.Cube.Define(stage,'/World/Decor/'+name);cube.CreateSizeAttr(1)
            cube.AddTranslateOp().Set(G.Vec3d(*position));cube.AddRotateYOp().Set(25 if name.startswith('Blind') else 0)
            cube.AddScaleOp().Set(G.Vec3d(*scale));S.MaterialBindingAPI.Apply(cube.GetPrim()).Bind(mat)
        for side,y0 in [('Left',-1.70),('Right',.42)]:
            points=[];indices=[];counts=[];nx,nz=60,24
            for j in range(nz+1):
                z=.10+2.60*j/nz
                for i in range(nx+1):
                    y=y0+.40*i/nx
                    x=2.51+.055*math.cos(i/nx*math.pi*12)+.014*math.sin(j/nz*math.pi)
                    points.append((x,y,z))
            for j in range(nz):
                for i in range(nx):
                    a=j*(nx+1)+i;indices.extend([a,a+1,a+nx+2,a+nx+1]);counts.append(4)
            mesh=U.Mesh.Define(stage,'/World/Decor/Curtain'+side)
            mesh.CreatePointsAttr(points);mesh.CreateFaceVertexIndicesAttr(indices);mesh.CreateFaceVertexCountsAttr(counts)
            mesh.CreateSubdivisionSchemeAttr('catmullClark');mesh.CreateDoubleSidedAttr(True)
            S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(fabric)
        if task_id=='neiss_2888':
            _usd_asset(stage,'Sofa','sofa_02',[-1.3,2.0,.43],[2.2,.9,.86],yaw=0)
            _usd_asset(stage,'BedPillows','throw_pillows_01',[1.91,.78,.67],[1.10,.47,.26],yaw=0)
            # A folded linen duvet with a draped hem and small, geometric folds.
            duvet=_pbr(stage,'Duvet',[.75,.72,.65],.95)
            points=[];counts=[];indices=[];n=72
            for j in range(n+1):
                y=-1.02+1.62*j/n
                for i in range(n+1):
                    x=1.10+1.62*i/n
                    side=max(0,(abs(x-1.91)-.65)/.16)
                    foot=max(0,(-.82-y)/.20)
                    fold=.010*math.sin(31*x+6*y)+.006*math.sin(26*y-9*x)
                    z=.535-.24*max(side,foot)**1.35+fold
                    points.append((x,y,z))
            for j in range(n):
                for i in range(n):
                    a=j*(n+1)+i;indices.extend([a,a+1,a+n+2,a+n+1]);counts.append(4)
            mesh=U.Mesh.Define(stage,'/World/Decor/Duvet')
            mesh.CreatePointsAttr(points);mesh.CreateFaceVertexCountsAttr(counts);mesh.CreateFaceVertexIndicesAttr(indices)
            mesh.CreateSubdivisionSchemeAttr('catmullClark');mesh.CreateDoubleSidedAttr(True)
            S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(duvet)
        else:
            ceramic=_pbr(stage,'Ceramic',[.88,.88,.84],.22)
            _rounded_box(stage,'Cistern',[.72,1.0,.60],[.38,.68,.40],.035,ceramic)
            _rounded_box(stage,'CisternLid',[.72,1.0,.789],[.39,.69,.022],.010,ceramic)
            _rounded_box(stage,'RearPedestal',[.79,1.0,.24],[.30,.40,.48],.065,ceramic)
            towel=_pbr(stage,'CottonTowel',[.72,.78,.75],.98)
            pts=[];idx=[];cnt=[]
            for j in range(25):
                for i in range(31):
                    pts.append([-.88+.46*i/30,2.38+.018*math.cos(i/30*math.pi*8),.52+.62*j/24])
            for j in range(24):
                for i in range(30):
                    a=j*31+i;idx.extend([a,a+1,a+32,a+31]);cnt.append(4)
            mesh=U.Mesh.Define(stage,'/World/Decor/HangingTowel');mesh.CreatePointsAttr(pts)
            mesh.CreateFaceVertexIndicesAttr(idx);mesh.CreateFaceVertexCountsAttr(cnt)
            mesh.CreateSubdivisionSchemeAttr('catmullClark');mesh.CreateDoubleSidedAttr(True)
            S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(towel)
    # Allow RTX material and camera buffers to converge before recording.
    for _ in range(16): og.sim.render()
