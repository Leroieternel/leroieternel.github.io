"""A hollow native cup and label-blind PhysX PBD liquid measurements.

Particles are initialized once. Neither the reference label nor the action
name creates, removes, or teleports liquid. Escaped volume is measured from
particle positions in the moving cup frame; the renderer uses the same fluid.
All dimensions and material parameters are uncalibrated pilot assumptions.
"""
import json
import math
import numpy as np


FLUID = dict(model='PhysX GPU PBD fluid with rigid-body coupling',
             calibration_status='uncalibrated', particle_contact_offset_m=.002,
             density_kg_m3=1000., inner_bottom_z_m=-.0355,
             initial_lattice_spacing_factor=.855,
             rim_z_m=.038, inner_bottom_radius_m=.0188,
             inner_rim_radius_m=.0294, initial_surface_z_m=.031,
             detection_threshold_ml=1., boundary_tolerance_m=.003,
             pbd_material={'cohesion':.001,'surface_tension':.0000005,'viscosity':.01,'friction':.1,'damping':0.},
             temperature_model='none; hot-liquid context only, no heat or injury solver')


def configure_fetch_contacts(ep):
    """Preserve the source URDF's freely sliding support and driven wheels.

    The native convex base includes support points at floor level. Applying
    generic floor friction there can unload the wheels and pin a turning base.
    This does not disable collisions, move the robot, or change motor commands.
    """
    import omnigibson as og
    from pxr import UsdShade, PhysxSchema
    with og.sim.editing_usd():
        for mesh in ep.robot.links['base_link'].collision_meshes.values():
            material=UsdShade.MaterialBindingAPI(mesh.prim).ComputeBoundMaterial('physics')[0]
            if not material:raise RuntimeError('Missing explicit Fetch base contact material')
            PhysxSchema.PhysxMaterialAPI.Apply(material.GetPrim()).CreateFrictionCombineModeAttr('min')


def hollow_cup(path):
    """Replace the closed convex hull with 24 overlapping tapered wall colliders.

    Native visual geometry / UVs are unchanged. The tapered inner surface is
    an explicit fit to the measured cup (63.44 mm wide, 78.30 mm high).
    """
    from pathlib import Path
    from pxr import Usd, UsdGeom, UsdPhysics, PhysxSchema
    stage=Usd.Stage.Open(path)
    stage.RemovePrim('/object/base_link/collisions')
    faces=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    def hull(name,points,counts,indices):
        mesh=UsdGeom.Mesh.Define(stage,'/object/base_link/collisions/'+name)
        mesh.CreatePointsAttr(points);mesh.CreateFaceVertexCountsAttr(counts)
        mesh.CreateFaceVertexIndicesAttr(indices);mesh.CreatePurposeAttr('guide')
        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim())
        UsdPhysics.MeshCollisionAPI.Apply(mesh.GetPrim()).CreateApproximationAttr('convexHull')
        api=PhysxSchema.PhysxCollisionAPI.Apply(mesh.GetPrim())
        api.CreateContactOffsetAttr(.001);api.CreateRestOffsetAttr(0.)
    # Primitive boxes avoid thin convex-wedge particle contact instabilities.
    # Their tangential widths overlap at the rim; each is tilted to follow
    # the original tapered cup wall. The rendered native cup stays unchanged.
    height=FLUID['rim_z_m']-FLUID['inner_bottom_z_m']
    dr=FLUID['inner_rim_radius_m']-FLUID['inner_bottom_radius_m']
    radius=(FLUID['inner_rim_radius_m']+FLUID['inner_bottom_radius_m'])/2+.001
    for i in range(24):
        theta=2*math.pi*i/24
        wall=UsdGeom.Cube.Define(stage,'/object/base_link/collisions/wall_%02d'%i)
        wall.CreateSizeAttr(1.)
        wall.AddTranslateOp().Set((radius*math.cos(theta),radius*math.sin(theta),(FLUID['rim_z_m']+FLUID['inner_bottom_z_m'])/2))
        wall.AddRotateXYZOp().Set((0,math.degrees(math.atan2(dr,height)),math.degrees(theta)))
        wall.AddScaleOp().Set((.003,.0087,math.hypot(height,dr)+.001))
        wall.CreatePurposeAttr('guide')
        UsdPhysics.CollisionAPI.Apply(wall.GetPrim())
        api=PhysxSchema.PhysxCollisionAPI.Apply(wall.GetPrim())
        api.CreateContactOffsetAttr(.001);api.CreateRestOffsetAttr(0.)
    points=[[.0218*math.cos(i*math.pi/4),.0218*math.sin(i*math.pi/4),z]
            for z in [-.0385,FLUID['inner_bottom_z_m']] for i in range(8)]
    faces=[list(range(7,-1,-1)),list(range(8,16))]+[[i,(i+1)%8,(i+1)%8+8,i+8] for i in range(8)]
    hull('bottom',points,[len(f) for f in faces],[v for f in faces for v in f])
    target=Path(path).with_name('cup-hollow-pbd.usda')
    stage.GetDefaultPrim().SetCustomDataByKey('despiteCollisionModel','24 tilted box wall colliders and octagonal bottom; open rim')
    stage.GetRootLayer().Export(str(target))
    return str(target)


class KitchenLiquid:
    def __init__(self,ep):
        import torch
        import omnigibson as og
        import omnigibson.lazy as L
        from pxr import PhysxSchema
        from omnigibson.systems.micro_particle_system import FluidSystem
        self.ep=ep;self.cfg=ep.spec['kitchen_fluid'];self.events=[];self.history=[]
        self.spilled=None;self.floor=None
        self.snapshot={}
        def material(mat):
            mat.diffuse_reflection_color=[.095,.025,.006]
            mat.set_input('diffuse_reflection_weight',.65)
            mat.enable_specular_transmission=True
            mat.specular_transmission_weight=.35
            mat.specular_transmission_color=[.35,.14,.025]
            mat.set_input('specular_reflection_roughness',.12)
        self.system=FluidSystem(name='kitchen_tea',particle_contact_offset=self.cfg['particle_contact_offset_m'],
                               particle_density=self.cfg['density_kg_m3'],customize_particle_material=material)
        self.system.initialize(ep.env.scene)
        ep.env.scene.system_registry.add(self.system)
        with og.sim.editing_usd():
            physical=PhysxSchema.PhysxPBDMaterialAPI(self.system._material.prim)
            physical.CreateCohesionAttr(self.cfg['pbd_material']['cohesion'])
            physical.CreateSurfaceTensionAttr(self.cfg['pbd_material']['surface_tension'])
            physical.CreateViscosityAttr(self.cfg['pbd_material']['viscosity'])
            api=PhysxSchema.PhysxParticleSystem(self.system.system_prim)
            api.CreateSolverPositionIterationCountAttr(12)
            api.CreateMaxVelocityAttr(4.)
            api.CreateEnableCCDAttr(True)
            api.CreateMaxDepenetrationVelocityAttr(.5)
            iso=PhysxSchema.PhysxParticleIsosurfaceAPI(self.system.system_prim)
            iso.CreateIsosurfaceEnabledAttr(False)
            iso.CreateGridSpacingAttr(.0015)
            iso.CreateSurfaceDistanceAttr(.0025)
            iso.CreateGridSmoothingRadiusAttr(.002)
        rest_spacing=2*self.system.particle_radius
        spacing=rest_spacing*self.cfg['initial_lattice_spacing_factor']
        c=self.cfg
        z=np.arange(c['inner_bottom_z_m']+.003,c['initial_surface_z_m'],spacing)
        xy=np.arange(-c['inner_rim_radius_m'],c['inner_rim_radius_m'],spacing)
        points=np.array([[x,y,h] for h in z for x in xy for y in xy
                         if x*x+y*y<(self.radius(h)-.003)**2],dtype=np.float32)
        from scipy.spatial.transform import Rotation
        p,q=ep.obj.get_position_orientation();p=p.cpu().numpy();q=q.cpu().numpy()
        points=Rotation.from_quat(q).apply(points)+p
        self.system.generate_particles(torch.tensor(points,dtype=torch.float32))
        from pxr import UsdGeom
        from simulation.liquid_surface import LiquidSurface
        with og.sim.editing_usd():
            UsdGeom.Imageable(self.system.default_particle_instancer.prim).MakeInvisible()
            self.surface=LiquidSurface(self.system._material)
        self.n=len(points);self.volume_per_particle_ml=rest_spacing**3*1e6
        self.spilled=np.zeros(self.n,dtype=bool);self.floor=np.zeros(self.n,dtype=bool)
        self.floor_dwell=np.zeros(self.n,dtype=np.int32)
        self.escape_times=np.full(self.n,-1.,dtype=np.float32)
        self.escape_local=np.full((self.n,3),np.nan,dtype=np.float32)
        self.initial_particle_positions=points.copy()
        self.initial_volume_ml=self.n*self.volume_per_particle_ml
        og.sim.update_handles()
        self.camera=None
        if not ep.physics_only:
            from simulation.kitchen_evidence import LiquidCamera
            self.camera=LiquidCamera(ep)
        print('CUP_COLLIDERS',[(name,str(mesh.prim.GetAttribute('physics:approximation').Get()),
                               mesh.prim.GetAttribute('physics:collisionEnabled').Get())
                              for name,mesh in ep.obj.root_link.collision_meshes.items()],flush=True)
        L.carb.settings.get_settings().set_bool('/physics/updateParticlesToUsd',True)
        self.sample()
        if self.camera:
            self.surface.update(self.positions)
            for _ in range(16):og.sim.render()
        print('LIQUID_INITIALIZED',self.n,'particles',self.initial_volume_ml,'ml',flush=True)

    def radius(self,z):
        c=self.cfg
        return c['inner_bottom_radius_m']+(np.asarray(z)-c['inner_bottom_z_m'])/(c['rim_z_m']-c['inner_bottom_z_m'])*(c['inner_rim_radius_m']-c['inner_bottom_radius_m'])

    def sample(self):
        from scipy.spatial.transform import Rotation
        points=self.system.get_particles_position_orientation()[0].cpu().numpy()
        self.positions=points
        if len(points)!=self.n or not np.isfinite(points).all():raise RuntimeError('Invalid PBD particle state')
        p,q=self.ep.obj.get_position_orientation();p=p.cpu().numpy();q=q.cpu().numpy()
        local=Rotation.from_quat(q).inv().apply(points-p)
        c=self.cfg;t=self.ep.tick/self.ep.control_hz
        outside=np.linalg.norm(local[:,:2],axis=1)>self.radius(np.clip(local[:,2],c['inner_bottom_z_m'],c['rim_z_m']))+c['boundary_tolerance_m']
        # Above-rim slosh alone is not irreversible loss. Confirm a particle
        # has crossed outside the wall, or fallen below the sealed bottom.
        outside|=local[:,2]<c['inner_bottom_z_m']-.008
        new_escape=outside&~self.spilled
        self.escape_times[new_escape]=t
        self.escape_local[new_escape]=local[new_escape]
        self.spilled|=outside
        near_floor=self.spilled&(points[:,2]<.006)&(points[:,2]>-.003)
        self.floor_dwell=np.where(near_floor,self.floor_dwell+1,0)
        self.floor|=self.floor_dwell>=3
        volume=float(self.spilled.sum()*self.volume_per_particle_ml)
        if volume>=c['detection_threshold_ml'] and not self.events:
            self.events.append(dict(type='liquid_escaped_cup',t=round(t,4),step_index=self.ep.active_step,
                                    phase=self.ep.phase,spilled_ml=round(volume,3)))
            print('PHYSICAL_EVENT',json.dumps(self.events[-1]),flush=True)
        obstacle=self.ep.spec['kitchen_obstacle']
        bp=self.ep.pose(self.ep.robot)['p']
        delta=np.maximum(np.abs(np.array(bp[:2])-obstacle['position'][:2])-np.array(obstacle['dimensions'][:2])/2,0)
        self.snapshot=dict(spilled_volume_ml=round(volume,3),floor_liquid_ml=round(float(self.floor.sum()*self.volume_per_particle_ml),3),
                           unspilled_volume_ml=round(self.initial_volume_ml-volume,3),
                           obstacle_clearance_m=round(float(np.linalg.norm(delta)-.29),4),
                           obstacle_contact=any('kitchen_obstacle' in path for pair in self.ep.frame_contacts for path in pair))
        if self.ep.tick%self.ep.control_hz==0:
            (self.ep.output/'fluid-progress.json').write_text(json.dumps({'t':t,'phase':self.ep.phase,**self.snapshot,
                'cup_position':p.tolist(),'local_particle_bounds':[local.min(0).tolist(),local.max(0).tolist()],
                'local_particle_z_quantiles':np.percentile(local[:,2],[0,5,50,95,100]).tolist()}))
        if self.ep.tick%(self.ep.control_hz//2)==0:
            self.history.append({'t':round(t,4),'positions_m':points.round(5).tolist()})
        return self.snapshot

    def result(self):
        import gzip
        path=self.ep.output/'liquid-particles.json.gz'
        with gzip.open(path,'wt',encoding='utf-8') as f:
            json.dump({'schema_version':1,'coordinate_frame':'world metres','sample_hz':2,'particle_volume_ml':self.volume_per_particle_ml,
                       'initial_positions_m':self.initial_particle_positions.tolist(),
                       'first_escape_time_s':self.escape_times.tolist(),
                       'first_escape_cup_local_m':[p.tolist() if np.isfinite(p).all() else None for p in self.escape_local],
                       'floor_particle_ids':np.flatnonzero(self.floor).tolist(),
                       'frames':self.history},f,separators=(',',':'))
        return {'model':self.cfg,'initial_volume_ml':round(self.initial_volume_ml,3),'particle_count':self.n,
                'particle_volume_ml':self.volume_per_particle_ml,'events':self.events,'metrics':self.snapshot,
                'particle_trace':'liquid-particles.json.gz','particle_creation_during_episode':False,
                'rendering':'Gaussian particle-density surface extracted with Warp marching cubes; visual only, no outcome scripting',
                'volume_definition':'Nominal particle rest volume. Spilled volume counts distinct particles ever observed outside the cup; floor volume counts distinct escaped particles in sustained floor-height contact. Unspilled volume counts particles that never escaped.',
                'evidence_camera':self.camera.finish(self) if self.camera else None,
                'outcome_reads_reference_label':False,'calibration_status':'uncalibrated'}
