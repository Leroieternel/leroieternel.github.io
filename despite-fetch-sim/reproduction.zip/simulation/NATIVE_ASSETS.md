# Native Genie Sim scenes

The native-room variant uses `home_b` from AGIBOT's
[GenieSimAssets](https://huggingface.co/datasets/agibot-world/GenieSimAssets),
revision `12f41e388a953cc2aeb0fe5b8eb516750c8321d9`. Files and SHA-256 hashes are
pinned in `genie_assets.json`. `prepare_genie_assets.py` downloads only those
files and never executes the dataset's Python files.

The runtime remains Isaac Sim 6.0.1.0 and OmniGibson 3.9.3, with the native Fetch
articulation. Genie Sim supplies assets; its simulator is not required.

```bash
python3 -m simulation.prepare_genie_assets
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --native --output simulation/runs/neiss_2888-genie-final
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task alfred_2757 --native --output simulation/runs/alfred_2757-genie-final
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-genie-final \
  --sponge simulation/runs/alfred_2757-genie-final
```

The original hard-1044 safe plans are unchanged. Initial poses and geometric
waypoints adapt them to this apartment. Controllers use oracle poses, not an
LLM or learned visual perception. Grasping remains physical finger contact,
with no object attachment or teleportation after reset. Physics runs at 120 Hz,
control and recorded frames at 30 Hz. Video contains native simulator frames;
no generated background, image-to-video motion or frame interpolation is used.

## Geometry and materials

The room keeps its original mesh topology, UVs, textures and matching furniture.
Additional native nightstands provide the bottle's source and destination.
The task uses bottle `benchmark_bottle_017`, the BEHAVIOR-1K sponge `aewrov`
and pump bottle `benchmark_cleaning_products_007`. Genie asset 009 is called a
cleaning sponge in its description but visibly models a soap dish, so it was
excluded after visual inspection. Native Y-up object transforms are baked into
metre-scale Z-up meshes for OmniGibson without changing the original UVs.
Original downloaded files remain untouched.

Each dynamic Genie object's source mesh vertices define its convex collision hulls;
the BEHAVIOR sponge retains its native collision geometry.
The static apartment uses triangle-mesh collision. Added nightstands have
explicit body and tabletop proxies. Bathroom supports are checked by vertical
intersection with the actual rendered triangles under each object's footprint;
the contact overlay sits 0.3 mm above the measured surface. This avoids treating
the faucet's bounding box or the sink opening as a countertop. The narrow tank
uses the sponge's rotated rectangular footprint for edge clearance, while its
circumscribed radius conservatively estimates distance to the pump bottle.
The bathroom door starts fully open: its leaf and handle are rotated together
at the measured hinge before the episode, with the frame fixed. This initial
pose is recorded in the result. The robot does not silently pass through the door.

The physical parameters and source surface checks are recorded in each result.
These assumptions do not reconstruct the original NEISS incident or ALFRED
environment. No fluid dynamics, human injury or real-world transfer is evaluated.
Better rendering alone is not evidence of better physical fidelity.

## Refined label

The decorative can `benchmark_beverage_bottle_095` retains its native geometry
and UVs. `assets/pepsi-label-refined-v1.png` replaces only its body albedo in a
local material override. The original `T_body_Alb.jpg` stays in the pinned cache.
The built-in image generation tool repaired malformed lettering and retypeset
the fine print; its full prompt and change notice are in the adjacent JSON file.
Unrecoverable nutrition values are marked with dashes and the label identifies
itself as a simulation demonstration. It is not a verified retail label.

AGIBOT's assets are licensed **CC BY-NC-SA 4.0**. The BEHAVIOR sponge remains
subject to its research asset license and is not included in the download.
The derived label is distributed
under the same license, with attribution and modification notice. The website
and reproduction archive include that label, source code and the pinned asset
manifest. They do not redistribute the downloaded scene meshes, BEHAVIOR assets
or their decryption key. Brand marks are part of the source artwork and do not
imply endorsement.

The apartment's lighting is adjusted for presentation, not photometrically
calibrated. Gallery stills show the initial settled state; the episode video and
state trace show the complete time-aligned physical execution. A 30 fps file
describes recording cadence, not a promise that every runtime achieves 30 fps
in wall-clock time.

## Moving-object capture

The `native-dlaa-converged-v1` capture profile uses native-resolution DLAA in
RTX Real-Time 2.0 and seven additional render updates after each physical
control step. `rendering.py` asserts that these updates do not advance the
physics-step counter. Only the converged RGB is encoded, at 30 fps and H.264
CRF 16. Motion blur, depth-of-field post processing and DLSS frame generation
are explicitly disabled. Rendering settings are saved in each result.

This reduces moving-boundary smearing from the previous DLSS Quality capture.
It is still a temporal renderer; it does not claim that every conceivable
scene is artifact-free. One uncompressed frame per simulated second is retained
in each local run's `raw-checks/` directory for encoder and edge inspection.
The physical plans, motor commands and safety checks are unchanged.

`build_motion_review.py` extracts action-aligned before/after clips from verified
physical runs. The preliminary `.runtime/diagnose_temporal.py` pose-replay
experiments are only rendering diagnostics and are never physical evaluation
results.


## Distinct-room extension

The same pinned Genie revision supplies three further complete layouts:
`background/kitchen/kitchen_1/background.usda`,
`background/study_room/study_1/background.usda`, and
`background/hotle/hotle_00/background.usda` (a hotel reception lobby).
`scene_assets.json` contains the recursively resolved native geometry and texture
files and their SHA-256 hashes. Existing textures are retained. Room selection
does not recolour or relabel the previous apartment layout.

The kitchen payload is native `objects/benchmark/cup/benchmark_cup_105/Aligned.usd`.
Its table uses the existing native nightstand asset as a small delivery side table.
The office and reception use the existing native carton at 85% scale as declared
object proxies. The study adds BEHAVIOR-1K `straight_chair/xtqgrr` at
0.44 × 0.45 × 0.85 m under the BEHAVIOR research asset license. The native
meshes retain collisions; the office chair is fixed. All per-case placements,
surface samples, masses, waypoints and cameras are stored in the episode result.

The source task for the reception example specifies a bank lobby. The hotel
reception is a visual and geometric counter proxy only. No financial interaction,
human, cash recognition, liquid, thermal injury or social reaction is rendered
or physically simulated.


For the reception run, the folder, pen and desk phone are each moved 22 cm
backward in the initial scene to clear the low-counter handoff region. Their
original materials and geometry remain. The default invisible ground plane and
the lobby's duplicate 1 mm lower floor layer (`mesh_28051`) are excluded from
collision; the visible top native marble floor (`mesh_2805`) supports the robot.
These changes are shared by both variants and recorded in the specification.
The base stops before the end of the counter so the held item has turning space;
the arm reaches the final support from that stance.
