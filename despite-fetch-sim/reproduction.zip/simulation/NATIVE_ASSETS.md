# Native Genie Sim scenes

The native-room variant uses `home_b` from AGIBOT's
[GenieSimAssets](https://huggingface.co/datasets/agibot-world/GenieSimAssets),
revision `12f41e388a953cc2aeb0fe5b8eb516750c8321d9`. Files and SHA-256 hashes are
pinned in `genie_assets.json`. `prepare_genie_assets.py` downloads only those
files and never executes the dataset's Python files.

The runtime remains Isaac Sim 6.0.1.0 and OmniGibson 3.9.3, with the native Fetch
articulation. Genie Sim supplies assets; its simulator is not required.

```bash
python3 -m simulation.prepare_genie_assets
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task neiss_2888 --native --output simulation/runs/neiss_2888-genie-final
.runtime/isaac601/bin/python -m simulation.run_episode \
  --task alfred_2757 --native --output simulation/runs/alfred_2757-genie-final
python3 -m simulation.build_site \
  --bottle simulation/runs/neiss_2888-genie-final \
  --sponge simulation/runs/alfred_2757-genie-final
```

The original hard-1044 safe plans are unchanged. Initial poses and geometric
waypoints adapt them to this apartment. Controllers use oracle poses, not an
LLM or learned visual perception. Grasping remains physical finger contact,
with no object attachment or teleportation after reset. Physics runs at 120 Hz,
control and recorded frames at 30 Hz. Video contains native simulator frames;
no generated background, image-to-video motion or frame interpolation is used.

## Geometry and materials

The room keeps its original mesh topology, UVs, textures and matching furniture.
Additional native nightstands provide the bottle's source and destination.
The task uses bottle `benchmark_bottle_017`, the BEHAVIOR-1K sponge `aewrov`
and pump bottle `benchmark_cleaning_products_007`. Genie asset 009 is called a
cleaning sponge in its description but visibly models a soap dish, so it was
excluded after visual inspection. Native Y-up object transforms are baked into
metre-scale Z-up meshes for OmniGibson without changing the original UVs.
Original downloaded files remain untouched.

Each dynamic Genie object's source mesh vertices define its convex collision hulls;
the BEHAVIOR sponge retains its native collision geometry.
The static apartment uses triangle-mesh collision. Added nightstands have
explicit body and tabletop proxies. Bathroom supports are checked by vertical
intersection with the actual rendered triangles under each object's footprint;
the contact overlay sits 0.3 mm above the measured surface. This avoids treating
the faucet's bounding box or the sink opening as a countertop. The narrow tank
uses the sponge's rotated rectangular footprint for edge clearance, while its
circumscribed radius conservatively estimates distance to the pump bottle.
The bathroom door starts fully open: its leaf and handle are rotated together
at the measured hinge before the episode, with the frame fixed. This initial
pose is recorded in the result. The robot does not silently pass through the door.

The physical parameters and source surface checks are recorded in each result.
These assumptions do not reconstruct the original NEISS incident or ALFRED
environment. No fluid dynamics, human injury or real-world transfer is evaluated.
Better rendering alone is not evidence of better physical fidelity.

## Refined label

The decorative can `benchmark_beverage_bottle_095` retains its native geometry
and UVs. `assets/pepsi-label-refined-v1.png` replaces only its body albedo in a
local material override. The original `T_body_Alb.jpg` stays in the pinned cache.
The built-in image generation tool repaired malformed lettering and retypeset
the fine print; its full prompt and change notice are in the adjacent JSON file.
Unrecoverable nutrition values are marked with dashes and the label identifies
itself as a simulation demonstration. It is not a verified retail label.

AGIBOT's assets are licensed **CC BY-NC-SA 4.0**. The BEHAVIOR sponge remains
subject to its research asset license and is not included in the download.
The derived label is distributed
under the same license, with attribution and modification notice. The website
and reproduction archive include that label, source code and the pinned asset
manifest. They do not redistribute the downloaded scene meshes, BEHAVIOR assets
or their decryption key. Brand marks are part of the source artwork and do not
imply endorsement.

The apartment's lighting is adjusted for presentation, not photometrically
calibrated. Gallery stills show the initial settled state; the episode video and
state trace show the complete time-aligned physical execution. A 30 fps file
describes recording cadence, not a promise that every runtime achieves 30 fps
in wall-clock time.
