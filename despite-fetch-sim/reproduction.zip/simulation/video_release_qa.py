"""Validate a rendered v2 episode and extract unchanged frames for visual review."""
import argparse
import hashlib
import json
import math
import subprocess
from pathlib import Path

import imageio.v2 as imageio
import imageio_ffmpeg
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from simulation.planning.audit import audit_run


def inspect(run, output):
    result=json.loads((run/'result.json').read_text())
    trace=json.loads((run/'trace.json').read_text())
    assert result.get('planning',{}).get('revision')=='classical-fetch-v2'
    assert not result['physics_only'] and not result['draft']
    motion=audit_run(run)
    output.mkdir(parents=True,exist_ok=True)
    (run/'motion-audit.json').write_text(json.dumps(motion,indent=2)+'\n')
    reader=imageio.get_reader(run/'episode.mp4')
    metadata=reader.get_meta_data();count=reader.count_frames();reader.close()
    assert count==result['frames']==len(trace)
    assert metadata['fps']==result['video_fps']==30
    assert tuple(metadata['size'])==(1440,960)
    assert abs(count/metadata['fps']-result['duration'])<1/metadata['fps']+.001
    times={0.,max(0.,result['duration']-1/result['video_fps'])}
    for step in result['steps']:
        start,end=step['start'],step['end']
        times.update((min(start+.15,result['duration']-.05),(start+end)/2,max(start,end-.10)))
    for record in result['planning']['records']:
        if record['kind']=='navigation' and record.get('end_s') is not None:
            times.add((record['start_s']+record['end_s'])/2)
    times=sorted(times)
    if len(times)>20:
        times=[times[i] for i in sorted(set(np.linspace(0,len(times)-1,20).round().astype(int)))]
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
    columns=4;w,h=400,304;sheet=Image.new('RGB',(columns*w,math.ceil(len(times)/columns)*h),'#19211d')
    draw=ImageDraw.Draw(sheet);frames=[];ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
    for i,time_s in enumerate(times):
        index=min(count-1,max(0,round(time_s*result['video_fps'])))
        actual=index/result['video_fps'];path=output/f'frame-{index:05d}.png'
        subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-ss',str(actual),'-i',str(run/'episode.mp4'),
                        '-frames:v','1','-y',str(path)],check=True)
        image=Image.open(path).convert('RGB');rgb=np.asarray(image)
        assert rgb.std()>5, f'Blank or corrupt sampled video frame: {path}'
        state=trace[index];x=(i%columns)*w;y=(i//columns)*h
        sheet.paste(image.resize((w,267),Image.Resampling.LANCZOS),(x,y))
        draw.text((x+8,y+271),f'{actual:.2f} s · {state["phase"][:35]}',font=font,fill='white')
        frames.append({'time_s':actual,'frame_index':index,'phase':state['phase'],'step_index':state['step'],
                       'image':path.name,'mean_luminance':round(float(rgb.mean()),3),
                       'near_white_fraction':round(float(np.all(rgb>=250,axis=2).mean()),6),
                       'near_black_fraction':round(float(np.all(rgb<=4,axis=2).mean()),6)})
    sheet.save(output/'contact-sheet.jpg',quality=94)
    report={'task':result['task_id'],'variant':result['variant'],'revision':'classical-fetch-v2',
            'status':result['status'],'goal_reached':result['goal_reached'],
            'physical_conditions_met':result['physical_safety_conditions_met'],
            'video_sha256':hashlib.sha256((run/'episode.mp4').read_bytes()).hexdigest(),
            'duration_s':result['duration'],'frames':count,'fps':metadata['fps'],'size':metadata['size'],
            'motion_audit_passed':True,'sampled_frames':frames,
            'visual_review_status':'pending_human_or_assistant_inspection',
            'note':'Original encoded frames are extracted without image synthesis. The contact sheet only resizes them for review.'}
    (output/'review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('sampled_frames','note')}),flush=True)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('run',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();inspect(args.run,args.output)
