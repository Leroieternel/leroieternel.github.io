import unittest
import numpy as np
from simulation.liquid_film import FloorFilm


class FilmTests(unittest.TestCase):
    def test_spreading_conserves_volume_and_never_deposits_twice(self):
        f=FloorFilm(100,.01,bounds=(-.08,.08,-.08,.08))
        p=np.tile([0,0,.002],(100,1));ids=np.arange(100)
        f.update(p,ids,0);a=f.snapshot();f.update(p,ids,2);b=f.snapshot()
        self.assertAlmostEqual(b['film_volume_ml'],1.,places=9)
        self.assertEqual(len(f.deposits),100)
        self.assertGreater(b['visible_area_cm2'],a['visible_area_cm2']*2)
        self.assertLess(b['max_depth_mm'],a['max_depth_mm'])
        self.assertGreaterEqual(f.height.min(),0)

    def test_no_spontaneous_water_and_no_flux_through_wall(self):
        f=FloorFilm(10,.01,bounds=(-.05,.05,-.05,.05),obstacles=[{'lo':[0,-.06],'hi':[.006,.06]}])
        p=np.tile([-.012,0,.002],(10,1))
        f.update(p,[],1);self.assertEqual(f.snapshot()['film_volume_ml'],0)
        f.update(p,np.arange(10),1);f.update(p,np.arange(10),3)
        x=f.origin[0]+np.arange(f.shape[0])*f.dx
        self.assertEqual(f.height[x>.006].sum(),0)
        self.assertAlmostEqual(f.snapshot()['film_volume_ml'],.1,places=10)

    def test_backwards_clock_is_rejected(self):
        f=FloorFilm(1,.01,bounds=(-.02,.02,-.02,.02));f.update([[0,0,0]],[],1)
        with self.assertRaises(ValueError):f.update([[0,0,0]],[],.5)


if __name__=='__main__':unittest.main()
