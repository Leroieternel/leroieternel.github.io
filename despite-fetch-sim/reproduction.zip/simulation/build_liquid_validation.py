"""Package a completed controlled-fluid recording with its provenance."""
import argparse,gzip,hashlib,json,shutil,zipfile
from pathlib import Path
import imageio.v2 as imageio


def build(run,output):
    data=json.loads((run/'validation.json').read_text())
    assert data['kind']=='controlled_cup_tilt_validation' and not data['benchmark_episode'] and not data['preview']
    assert data['fps']==30 and data['frames']==len(data['records'])
    fluid=data['liquid'];film=json.loads((run/'floor-film.json').read_text())
    assert film==fluid['floor_film']
    assert abs(film['metrics']['volume_error_ml'])<1e-7
    particles=json.load(gzip.open(run/'liquid-particles.json.gz','rt'))
    n=fluid['particle_count'];volume=fluid['particle_volume_ml']
    assert all(len(f['positions_m'])==n for f in particles['frames'])
    assert fluid['particle_creation_during_episode'] is False
    assert abs(sum(t>=0 for t in particles['first_escape_time_s'])*volume-fluid['metrics']['spilled_volume_ml'])<.002
    assert abs(len(particles['floor_particle_ids'])*volume-fluid['metrics']['floor_liquid_ml'])<.002
    ids=[d['particle_id'] for d in film['deposits']]
    assert len(ids)==len(set(ids)) and set(ids)<=set(particles['floor_particle_ids'])
    assert abs(len(ids)*volume-film['metrics']['film_volume_ml'])<1e-7
    assert all(abs(r['film']['volume_error_ml'])<1e-7 for r in data['records'])
    assert all(abs(r['spilled_volume_ml']+r['unspilled_volume_ml']-fluid['initial_volume_ml'])<.002 for r in data['records'])
    for name in ('pour.mp4','floor.mp4'):
        reader=imageio.get_reader(run/name)
        assert reader.count_frames()==data['frames'] and reader.get_meta_data()['fps']==30
        reader.close()
    output.mkdir(parents=True,exist_ok=True)
    sources=run/'source'
    with zipfile.ZipFile(output/'source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name,sha in data['source_sha256'].items():
            path=sources/name
            assert hashlib.sha256(path.read_bytes()).hexdigest()==sha,name
            archive.write(path,'simulation/'+name)
    files=['pour.mp4','floor.mp4','poster.jpg','floor-poster.jpg','validation.json','floor-film.json','liquid-particles.json.gz']
    for file in files:shutil.copy2(run/file,output/file)
    for name in ('pour-04.jpg','floor-08.jpg','floor-10.jpg'):
        if (run/name).exists():shutil.copy2(run/name,output/name)
    shutil.copy2(Path(__file__).with_name('liquid_validation.html'),output/'index.html')
    manifest={'recording_sha256':{file:hashlib.sha256((output/file).read_bytes()).hexdigest() for file in files},
              'kind':'controlled_fluid_test_not_benchmark_episode','checks':'Native frame counts, source hashes and conservative film volume verified'}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'output':str(output),'frames':data['frames'],'floor_ml':data['liquid']['metrics']['floor_liquid_ml']}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();build(a.run,a.output)
