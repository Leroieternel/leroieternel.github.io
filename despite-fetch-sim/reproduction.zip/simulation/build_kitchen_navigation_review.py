"""Publish a before/after navigation comparison from actual complete rollouts."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
import numpy as np
import imageio.v2 as imageio
from simulation.initial_state_check import compare_initial_states


def measure(run):
    result=json.loads((run/'result.json').read_text())
    trace=json.loads((run/'trace.json').read_text())
    nav=[s for s in trace if s['step']>=0 and result['plan'][s['step']].startswith('navigate_')]
    p=np.asarray([s['robot']['p'][:2] for s in nav]);q=np.asarray([s['robot']['q'] for s in nav])
    angles=np.unwrap(np.arctan2(2*(q[:,3]*q[:,2]+q[:,0]*q[:,1]),1-2*(q[:,1]**2+q[:,2]**2)))
    turn=np.diff(angles)
    return result,trace,{'start_s':nav[0]['t'],'end_s':nav[-1]['t'],
        'distance_m':round(float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),4),
        'total_turn_deg':round(float(np.degrees(abs(turn).sum())),3),
        'opposite_turn_deg':round(float(np.degrees(min(np.maximum(turn,0).sum(),np.maximum(-turn,0).sum()))),3),
        'navigation_duration_s':round(nav[-1]['t']-nav[0]['t'],3),
        'spilled_ml':result['metrics']['spilled_volume_ml'],
        'minimum_obstacle_clearance_m':result['metrics']['min_obstacle_clearance_m'],
        'obstacle_contact_frames':result['metrics']['obstacle_contact_frames']}


def build(before,after,output):
    output.mkdir(parents=True,exist_ok=True)
    report={'task_id':'neiss_11868','variants':{},'method':'Clips contain original recorded frames from 0.5 s before navigation until 0.5 s after navigation. No frame interpolation. Navigation metrics use measured robot poses during the original navigation actions.',
            'limitations':'The revised controller changes both route following and command acceleration limits; this is not a route-only ablation. It uses a declared corridor and oracle poses, not a learned or globally optimal path planner. Both reference plans use the same controller revision. Fluid parameters remain uncalibrated; outcomes are recomputed, not forced to preserve a safety label.',
            'previous_publication':'https://github.com/Leroieternel/leroieternel.github.io/tree/948a0625a6f58a869824267284b0a6a47b89156a/despite-fetch-sim/plan-pairs/data/neiss_11868'}
    for variant in ('safe','unsafe'):
        report['variants'][variant]={};pair=[]
        for label,root in [('before',before),('after',after)]:
            folder=root/('neiss_11868-'+variant);r,t,m=measure(folder);pair.append(r)
            assert r['goal_reached'] and not r['draft'] and r['video_fps']==30
            fps=r['video_fps'];lo=max(0,next(i for i,s in enumerate(t) if s['t']>=m['start_s']-.5))
            hi=min(len(t),next((i for i,s in enumerate(t) if s['t']>m['end_s']+.5),len(t)))
            name=f'{variant}-{label}'
            reader=imageio.get_reader(folder/'episode.mp4')
            writer=imageio.get_writer(output/(name+'.mp4'),fps=fps,codec='libx264',quality=None,
                                     macro_block_size=16,ffmpeg_params=['-crf','16','-movflags','+faststart'])
            try:
                for i in range(lo,hi):
                    frame=reader.get_data(i);writer.append_data(frame)
                    if i==lo:imageio.imwrite(output/(name+'.jpg'),frame)
            finally:reader.close();writer.close()
            for file in ('result.json','trace.json'):shutil.copy2(folder/file,output/f'{name}-{file}')
            report['variants'][variant][label]={**m,'video':name+'.mp4','poster':name+'.jpg','result':name+'-result.json','trace':name+'-trace.json',
                'clip_first_frame':lo,'clip_frames':hi-lo,'clip_start_episode_s':lo/fps,
                'source_video_sha256':hashlib.sha256((folder/'episode.mp4').read_bytes()).hexdigest(),
                'source_result_sha256':hashlib.sha256((folder/'result.json').read_bytes()).hexdigest()}
        report['variants'][variant]['initial_state_comparison']={**compare_initial_states(*pair),'record_order':['before','after']}
        for key in ('plan','source_files_sha256','physical_parameters','runtime'):
            assert pair[0][key]==pair[1][key],(variant,key)
    old=before/'neiss_11868-unsafe'
    inspection=old/'spill-inspection/spill-inspection.json'
    if inspection.exists():
        info=json.loads(inspection.read_text());target=output/'previous-spill-inspection';target.mkdir(exist_ok=True)
        report['previous_spill_inspection']={'caption':'These recorded-state views belong to the previous controller. They are not outcomes of the revised route. Fetch is hidden to remove occlusion.','images':[]}
        shutil.copy2(inspection,target/'spill-inspection.json')
        for shot in info['shots']:
            source=old/'spill-inspection'/shot['image'];assert hashlib.sha256(source.read_bytes()).hexdigest()==shot['image_sha256']
            shutil.copy2(source,target/shot['image'])
            report['previous_spill_inspection']['images'].append({'path':'previous-spill-inspection/'+shot['image'],'label':str(shot['time_s'])+' s · cup'})
        for name in ('floor-inspection.jpg','floor-inspection.json'):
            if (old/name).exists():shutil.copy2(old/name,target/name)
        if (old/'floor-inspection.jpg').exists():report['previous_spill_inspection']['images'].append({'path':'previous-spill-inspection/floor-inspection.jpg','label':'52.0 s · floor'})
    (output/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    template=(Path(__file__).parent/'kitchen_navigation_review.html').read_text()
    (output/'index.html').write_text(template.replace('__REPORT__',json.dumps(report).replace('</','<\\/')))
    print(json.dumps({v:{k:p[k]['total_turn_deg'] for k in ('before','after')} for v,p in report['variants'].items()}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('before','after','output'):p.add_argument('--'+arg,type=Path,required=True)
    a=p.parse_args();build(a.before,a.after,a.output)
