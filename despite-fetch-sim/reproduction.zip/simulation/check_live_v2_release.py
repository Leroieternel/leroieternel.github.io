"""Read back the published manifest, evidence and seekable media headers."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen


def check(site, url):
    pairs = site / 'plan-pairs'
    expected = json.loads((pairs / 'manifest.json').read_text())
    build = expected['build_id']
    url = url.rstrip('/') + '/'

    def request(path, method='GET', headers=None):
        request_url = url + quote(path, safe='/') + '?v=' + build
        return urlopen(Request(request_url, method=method, headers={
            'User-Agent': 'DESPITE-release-verification', **(headers or {})}), timeout=20)

    with request('plan-pairs/manifest.json') as response:
        published = json.load(response)
    assert published == expected, 'The public manifest is not the staged release'

    def recording(job):
        task, variant, item = job
        relative = 'plan-pairs/' + item['path'].rstrip('/') + '/'
        # Verify the published evidence and recorded-source manifest byte for byte.
        for filename in ('result.json', 'trace.json', 'motion-audit.json'):
            with request(relative + filename) as response:
                raw = response.read()
            expected_sha = hashlib.sha256((site / relative / filename).read_bytes()).hexdigest()
            assert hashlib.sha256(raw).hexdigest() == expected_sha, (task, variant, filename)
        video = site / relative / 'episode.mp4'
        with request(relative + 'episode.mp4', method='HEAD') as response:
            assert int(response.headers['Content-Length']) == video.stat().st_size
            assert 'video/mp4' in response.headers.get('Content-Type', '')
        with request(relative + 'episode.mp4', headers={'Range': 'bytes=0-31'}) as response:
            assert response.status == 206, (task, variant, 'Video does not support range requests')
            assert response.headers['Content-Range'] == f'bytes 0-31/{video.stat().st_size}'
            with video.open('rb') as source:
                assert response.read(32) == source.read(32)
        return {'task': task, 'variant': variant, 'public_evidence_matches': True,
                'video_bytes': video.stat().st_size, 'video_range_status': 206}

    jobs = [(case['id'], variant, case['variants'][variant])
            for case in expected['cases'] for variant in ('safe', 'unsafe')]
    with ThreadPoolExecutor(max_workers=6) as pool:
        rows = list(pool.map(recording, jobs))
    for name in ('index.html', 'app.js', 'data/manifest.json',
                 'plan-pairs/index.html', 'plan-pairs/app.js',
                 'plan-pairs/release-review.json', 'plan-pairs/publication-check.json'):
        with request(name) as response:
            assert response.read() == (site / name).read_bytes(), 'Stale public artifact: ' + name
    result = {'url': url, 'build_id': build, 'task_count': len(expected['cases']),
              'recording_count': len(rows), 'recordings': rows, 'status': 'passed'}
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('site', type=Path)
    parser.add_argument('--url', default='https://mcxiangalds.com/despite-fetch-sim/')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = check(args.site, args.url)
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
