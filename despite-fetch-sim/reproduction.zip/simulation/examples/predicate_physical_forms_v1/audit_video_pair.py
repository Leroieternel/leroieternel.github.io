"""Check new cup recordings against saved particles and recorded motion."""
import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from simulation.audit_kitchen_liquid import audit


def main(runs, output):
    report = audit(runs)
    occupancy = {}
    for variant in ('safe', 'unsafe'):
        directory = runs / f'neiss_11868-{variant}'
        result = json.loads((directory / 'result.json').read_text())
        trace = json.loads((directory / 'trace.json').read_text())
        with gzip.open(directory / 'liquid-particles.json.gz', 'rt') as stream:
            particle_trace = json.load(stream)
        volume = particle_trace['particle_volume_ml']
        initial = result['liquid_simulation']['initial_volume_ml']
        times = np.array([s['t'] for s in trace])
        cfg = result['spec']['kitchen_fluid']
        checked = 0
        for frame in particle_trace['frames']:
            index = int(np.argmin(abs(times - frame['t'])))
            # Initialization can precede the first recorded video frame.
            if abs(times[index] - frame['t']) > .001:
                assert frame['t'] == 0
                continue
            state = trace[index]
            points = np.asarray(frame['positions_m'])
            local = Rotation.from_quat(state['object']['q']).inv().apply(points - state['object']['p'])
            z = local[:, 2]
            r = np.linalg.norm(local[:, :2], axis=1)
            wall = cfg['inner_bottom_radius_m'] + (
                np.clip(z, cfg['inner_bottom_z_m'], cfg['rim_z_m']) - cfg['inner_bottom_z_m']
            ) / (cfg['rim_z_m'] - cfg['inner_bottom_z_m']) * (
                cfg['inner_rim_radius_m'] - cfg['inner_bottom_radius_m'])
            # Positions and poses in the saved diagnostic trace are rounded
            # to five decimals. Bracket boundary particles rather than
            # pretending that this lossy export recovers the exact live count.
            eps = .00003
            definite = ((z >= cfg['inner_bottom_z_m'] + eps) &
                        (z <= cfg['rim_z_m'] - eps) & (r <= wall - eps))
            possible = ((z >= cfg['inner_bottom_z_m'] - eps) &
                        (z <= cfg['rim_z_m'] + eps) & (r <= wall + eps))
            measured = state['metrics']['current_inside_volume_ml']
            assert definite.sum() * volume - .002 <= measured <= possible.sum() * volume + .002, (variant, frame['t'])
            checked += 1
        max_balance_error = max(abs(s['metrics']['current_inside_volume_ml'] +
                                    s['metrics']['current_outside_vessel_volume_ml'] - initial) for s in trace)
        assert max_balance_error <= .002
        states = [json.loads(line) for line in (directory / 'object-states.jsonl').read_text().splitlines()]
        assert len(states) == len(trace)
        held_count = 0
        for state, sample in zip(states, trace):
            assert state['t'] == sample['t']
            observed = state['objects']['payload']
            assert observed['M08']['volume']['value'] == sample['metrics']['current_inside_volume_ml']
            held_count += observed['M02']['held']['value'] is True
        assert held_count > 0, 'No physically evidenced hold in this recording'
        occupancy[variant] = {'particle_frames_verified': checked,
                              'saved_position_uncertainty_m': eps,
                              'max_current_volume_balance_error_ml': max_balance_error,
                              'physically_observed_held_frames': held_count,
                              'observer_video_alignment_verified': True}
    report['instantaneous_occupancy_checks'] = occupancy
    report['new_physics_recordings'] = True
    report['visual_review'] = 'separate keyframe inspection required'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'audit': str(output), 'variants': report['variants']}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    main(a.runs, a.output)
