"""Package actual two-camera cup recordings with trace-driven annotations.

No generated/interpolated frames or physical-state changes. The two views are
recorded simultaneously by Isaac Sim; annotations come from the same frames.
"""
import argparse
import bisect
import hashlib
import json
import subprocess
from pathlib import Path

import imageio.v2 as imageio
import imageio_ffmpeg

from simulation.initial_state_check import compare_initial_states


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def timecode(t):
    # ASS has centisecond precision. Floor boundaries so a 30 fps frame at
    # 0.0667 s already shows its own annotation, rather than waiting for 0.07.
    cs = int(t * 100 + 1e-6)
    return f'{cs // 360000}:{cs // 6000 % 60:02}:{cs // 100 % 60:02}.{cs % 100:02}'


def ass_text(text):
    return str(text).replace('\\', '/').replace('{', '(').replace('}', ')').replace('\n', ' ')


def export_transitions(result, trace, observations, output):
    """Keep observation changes separate from the source action effects."""
    events, previous = [], {}
    for frame, observation in zip(trace, observations):
        state = observation['objects']['payload']
        values = {
            '(robot_has hot_liquid)': state['M02']['held']['value'],
            '(liquid_spilled)': state['M08']['spilled']['value'],
            '(floor_wet kitchen_floor)': frame['metrics']['floor_liquid_ml'] >= .1,
            'sim:supported(payload,destination)': state['M06']['supported']['value'],
            'sim:stable(payload,destination)': state['M06']['stable']['value'],
        }
        for predicate, value in values.items():
            if predicate not in previous or previous[predicate] != value:
                events.append({'t': frame['t'], 'predicate': predicate, 'value': value,
                               'previous': previous.get(predicate),
                               'initial_observation': predicate not in previous,
                               'phase': frame['phase'],
                               'action': f'({result["plan"][frame["step"]]})' if frame['step'] >= 0 else None,
                               'cup_pose': frame['object'],
                               'metrics': frame['metrics']})
        previous = values
    write(output / f'{result["variant"]}-state-transitions.json', {
        'task_id': result['task_id'], 'variant': result['variant'],
        'basis': 'Observed physical state, not copied PDDL action effects',
        'calibration_status': 'uncalibrated',
        'support_binding': 'Legacy bedside_table channel refers to the destination side table in this kitchen.',
        'events': events})


def annotate(run, output):
    result = read(run / 'result.json')
    trace = read(run / 'trace.json')
    observations = [json.loads(line) for line in (run / 'object-states.jsonl').read_text().splitlines()]
    assert len(trace) == len(observations)
    assert all(f['t'] == s['t'] for f, s in zip(trace, observations))
    export_transitions(result, trace, observations, output)
    state_times = [row['t'] for row in observations]
    assert result['status'] == 'completed' and result['goal_reached'], result['error']
    assert result['grasping_mode'] == 'physical'
    assert result['motion_backend'] == 'classical'
    assert not result['draft'] and not result['physics_only']
    fps = result['video_fps']
    for file in ('episode.mp4', 'liquid-detail.mp4'):
        reader = imageio.get_reader(run / file)
        assert reader.count_frames() == len(trace)
        assert reader.get_meta_data()['fps'] == fps == 30
        reader.close()
    variant = result['variant']
    duration = len(trace) / fps
    events = []

    def line(start, end, text, x, y, size=30, color='&H00F1F5F2', layer=1):
        tags = f'{{\\an7\\pos({x},{y})\\fs{size}\\c{color}}}'
        events.append(f'Dialogue: {layer},{timecode(start)},{timecode(end)},Default,,0,0,0,,{tags}{ass_text(text)}')

    line(0, duration, f'{variant.capitalize()} reference plan  |  Open-cup transport', 32, 16, 42)
    line(0, duration, 'Whole kitchen  /  physical stool in the aisle', 32, 77, 26)
    line(0, duration, 'Cup close-up  /  same physical episode', 990, 77, 26)
    line(0, duration, 'Isaac Sim + OmniGibson  |  Uncalibrated nominal volumes  |  Thin-wall liquid shading artifact  |  No heat/injury model',
         32, 982, 25, '&H00A9C0B1')
    for index, frame in enumerate(trace):
        t0, t1 = index / fps, (index + 1) / fps
        state_index = bisect.bisect_right(state_times, frame['t'] + .0001) - 1
        assert state_index >= 0
        state = observations[state_index]['objects']['payload']
        assert abs(state_times[state_index] - frame['t']) < .001
        held = state['M02']['held']['value']
        grasp = 'UNKNOWN' if held is None else ('HELD' if held else 'NOT HELD')
        metrics = frame['metrics']
        i = frame['step']
        action = f'({result["plan"][i]})' if i >= 0 else 'Settling the initial scene'
        if frame['phase'] == 'observing final stability':
            action += '  /  observing final stability'
        line(t0, t1, f'{max(0, i + 1):02} / {len(result["plan"]):02}  |  {action}', 32, 787, 32)
        line(t0, t1, f'{frame["phase"]}    |    {frame["t"]:.1f} / {result["duration"]:.1f} s', 32, 834, 28)
        line(t0, t1, f'Grasp: {grasp}    |    Cup tilt: {metrics["object_tilt_deg"]:.1f} deg'
             f'    |    Currently inside cup: {metrics["current_inside_volume_ml"]:.3f} nominal ml', 32, 882, 29)
        threshold = result['spec']['kitchen_fluid']['detection_threshold_ml']
        spilled = metrics['spilled_volume_ml'] >= threshold
        line(t0, t1, f'(liquid_spilled) = {str(spilled).lower()}    |    Escaped: {metrics["spilled_volume_ml"]:.3f} ml'
             f'    |    Floor: {metrics["floor_liquid_ml"]:.3f} ml    |    Detection threshold: {threshold:.1f} ml',
             32, 930, 28, '&H0080B9FF' if spilled else '&H00BDDEB3')
    header = '''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1024
ScaledBorderAndShadow: yes
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,30,&H00FFFFFF,&H00FFFFFF,&H0014251F,&H0014251F,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    subtitles = output / f'{variant}-plan.ass'
    subtitles.write_text(header + '\n'.join(events) + '\n')
    video = output / f'{variant}-plan.mp4'
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    # This directory is generated locally with a known simple path. No shell
    # interpolation is used; invoke ffmpeg with an argument vector.
    subtitle_path = str(subtitles.resolve()).replace('\\', '/').replace(':', '\\:').replace("'", "'\\''")
    filters = (f'[0:v]scale=960:640:flags=lanczos,setsar=1[left];'
               f'[1:v]scale=960:640:flags=lanczos,setsar=1[right];'
               f'[left][right]hstack=inputs=2:shortest=1,pad=1920:1024:0:112:color=0x14251f,'
               f"ass='{subtitle_path}'[out]")
    command = [ffmpeg, '-hide_banner', '-y', '-i', str(run / 'episode.mp4'),
               '-i', str(run / 'liquid-detail.mp4'), '-filter_complex', filters,
               '-map', '[out]', '-an', '-c:v', 'libx264', '-threads', '6', '-preset', 'fast',
               '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
               '-fps_mode', 'passthrough', str(video)]
    temporary_video = output / f'.{variant}-plan.encoding.mp4'
    command[-1] = str(temporary_video)
    with (output / f'{variant}-encode.log').open('w') as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    reader = imageio.get_reader(temporary_video)
    assert reader.count_frames() == len(trace)
    assert reader.get_meta_data()['fps'] == fps
    assert reader.get_meta_data()['size'] == (1920, 1024)
    reader.close()
    temporary_video.replace(video)
    manifest = {
        'task': result['task_id'], 'variant': variant, 'plan': [f'({a})' for a in result['plan']],
        'source_run': str(run.resolve()), 'output_video': str(video.resolve()),
        'duration_s': duration, 'fps': fps, 'frames': len(trace),
        'source_sha256': {name: sha(run / name) for name in
                          ('episode.mp4', 'liquid-detail.mp4', 'trace.json', 'object-states.jsonl', 'result.json')},
        'output_sha256': sha(video), 'frame_interpolation': False,
        'composition': 'Simultaneous whole-scene and cup cameras, with trace-driven annotations. Full episode retained.',
        'calibration_status': 'uncalibrated',
        'visual_limits': ['Particle-kernel surface reconstruction can extend through thin cup walls. Exterior dark shading is not evidence of escaped particles.',
                          'Volumes are nominal particle-volume sums, not calibrated real-world millilitres.'],
        'outcome': {k: result[k] for k in ('goal_reached', 'physical_safety_conditions_met', 'metrics')},
    }
    write(output / f'{variant}-video.json', manifest)
    print(json.dumps({'video': str(video), 'duration_s': duration, 'frames': len(trace)}), flush=True)


def scene_manifest(runs, output):
    records = [read(runs / f'neiss_11868-{v}' / 'result.json') for v in ('safe', 'unsafe')]
    comparison = compare_initial_states(*records)
    assert records[0]['simulation_code_sha256'] == records[1]['simulation_code_sha256']
    spec = records[0]['spec']
    contract = read(Path(__file__).with_name('contracts.json'))['examples'][0]
    scene = {
        'task_id': 'neiss_11868', 'scene': 'native Genie Sim kitchen with a BEHAVIOR footstool',
        'coordinate_frame': 'world metres, z up',
        'scene_assets': {'room': spec['room_asset'], 'cup': records[0]['object_asset'],
                         'obstacle': spec['kitchen_obstacle']},
        'source_cup_position_m': spec['source'], 'destination_cup_position_m': spec['target'],
        'robot_start_position_m': spec['robot_position'],
        'support_center_m': spec['support_center'], 'support_half_extents_m': spec['support_half'],
        'support_top_m': spec['support_top'],
        'physics': records[0]['physical_parameters'], 'fluid': spec['kitchen_fluid'],
        'initial_fluid': records[0]['initial_state']['fluid'], 'paired_initial_state_check': comparison,
        'volume_measurement': {k: records[0]['liquid_simulation'].get(k) for k in
                               ('particle_count', 'particle_volume_ml', 'initial_volume_ml',
                                'volume_definition', 'occupancy_definition')},
        'navigation_and_arm': spec['classical_planning'],
        'entity_binding': contract['source_entity_binding'],
        'physical_components': contract['physical_components'],
        'predicate_bindings': contract['predicate_bindings'],
        'instantaneous_occupancy': {
            'metric': 'current_inside_volume_ml',
            'observer': 'M08.volume',
            'definition': 'Sum nominal volume of particles whose centres are inside the tapered cavity and below the rim at this instant.',
            'physical_form': 'Liquid geometry follows the same moving particles; no full/empty mesh swap.'},
        'transition_files': {v: f'{v}-state-transitions.json' for v in ('safe', 'unsafe')},
        'plans': {r['variant']: [f'({a})' for a in r['plan']] for r in records},
        'causal_order': ['plan', 'motor controller', 'rigid-body and PBD dynamics', 'measured predicates and rendered surfaces'],
        'calibration_status': 'uncalibrated',
        'limits': ['Dataset safe/unsafe labels do not determine physical outcomes.',
                   'The current inside-volume observer uses particle centres in the tapered cavity; cumulative escape is separate.',
                   'Floor film has one-way coupling; floor friction, human injury and heat transfer are not modeled.',
                   'Liquid surface reconstruction can protrude through the thin cup wall; external dark shading is a rendering artifact, not a spill measurement.',
                   'All displayed liquid quantities are uncalibrated nominal particle-volume sums.',
                   'This is one paired execution, not a safety-rate or real-world calibration experiment.'],
        'repeat_command': '.runtime/isaac601/bin/python -m simulation.run_batch --tasks neiss_11868 --variants safe unsafe --planner classical --asset-id genie-cup-105 --runs <new-output-directory>',
    }
    write(output / 'scene-model.json', scene)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--variant', choices=('safe', 'unsafe'))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for variant in ([args.variant] if args.variant else ['safe', 'unsafe']):
        annotate(args.runs / f'neiss_11868-{variant}', args.output)
    if all((args.runs / f'neiss_11868-{v}' / 'result.json').exists() for v in ('safe', 'unsafe')):
        scene_manifest(args.runs, args.output)
