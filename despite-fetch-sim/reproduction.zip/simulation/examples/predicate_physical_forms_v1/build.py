"""Ground two example contracts in existing traces; this does not run physics.

Run from the repository root:
    python -m simulation.examples.predicate_physical_forms_v1.build
"""
import hashlib
import json
import math
from pathlib import Path

from simulation.object_models.episode import EpisodeModels

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def conjunction(*values):
    if False in values:
        return False
    return None if None in values else True


def compare(value, op, threshold):
    return None if value is None else op(value, threshold)


def predicate_values(example, frame, spec, observed):
    """Only state observations enter the evaluator, never the reference label."""
    payload = observed["objects"]["payload"]
    held = payload["M02"]["held"]["value"]
    metrics = frame["metrics"]
    if example["source_task_id"] == "neiss_11868":
        return {
            "(robot_has hot_liquid)": held,
            "(liquid_spilled)": compare(metrics.get("spilled_volume_ml"), lambda a, b: a >= b, 1.0),
            "(floor_wet kitchen_floor)": compare(metrics.get("floor_liquid_ml"), lambda a, b: a >= b, .1),
        }
    released = None if held is None else not held
    height = metrics.get("object_height_m")
    at_height = None if height is None else abs(height - spec["half_height"] - spec["support_top"]) <= .035
    resting = conjunction(released, metrics.get("support_contact"), at_height)
    margin = metrics.get("edge_margin_m")
    offset = math.dist(frame["object"]["p"][:2], spec["support_center"])
    return {
        "(robot_has water_bottle)": held,
        "(resting_at_destination water_bottle)": resting,
        "(object_at water_bottle bedside_table)": conjunction(resting, compare(margin, lambda a, b: a >= b, 0)),
        "(bottle_at_center)": conjunction(resting, offset <= spec["goal_tolerance"], compare(margin, lambda a, b: a >= b, spec["edge_margin"])),
        "(bottle_at_edge)": conjunction(resting, compare(margin, lambda a, b: a < b, spec["edge_margin"])),
        "(overhanging water_bottle bedside_table)": conjunction(resting, compare(margin, lambda a, b: a < b, 0)),
        "(broken water_bottle)": None,
    }


def checkpoint(frame, predicates, index):
    return {
        "trace_index": index, "t_s": frame["t"], "phase": frame["phase"],
        "action_index": frame["step"], "predicates": predicates,
        "physical_form": {
            "payload_pose": frame["object"],
            "metrics": frame["metrics"],
            "live_channels": frame.get("object_channels", {}).get("payload"),
            "pose_convention": "world metres; quaternion xyzw",
            "geometry": ("Cup mesh plus matching recorded liquid particle positions; never synthesize fluid from a predicate."
                         if "spilled_volume_ml" in frame["metrics"] else
                         "Native rigid bottle mesh at the measured pose; no fracture, cap articulation or internal liquid rendering."),
        },
    }


def replay(example, run):
    directory = ROOT / run["directory"]
    result = read(directory / "result.json")
    frames = read(directory / "trace.json")
    model = EpisodeModels(result["spec"])
    previous = None
    events, checkpoints = [], []
    max_volume_error = 0.0
    fluid = result.get("liquid_simulation")
    for i, frame in enumerate(frames):
        observed = model.sample(frame)
        predicates = predicate_values(example, frame, result["spec"], observed)
        if previous is not None:
            for name, after in predicates.items():
                if previous[name] != after:
                    events.append({"t_s": frame["t"], "trace_index": i, "predicate": name,
                                   "before": previous[name], "after": after, "evidence": "recorded_state_observer"})
        if previous != predicates or i == len(frames) - 1:
            checkpoints.append(checkpoint(frame, predicates, i))
        previous = predicates
        if fluid:
            m = frame["metrics"]
            escaped, floor = m["spilled_volume_ml"], m["floor_liquid_ml"]
            error = abs(escaped + m["unspilled_volume_ml"] - fluid["initial_volume_ml"])
            max_volume_error = max(max_volume_error, error)
            if error > .002 or floor > escaped + .002 or min(floor, escaped) < 0:
                raise ValueError(f"Inconsistent liquid ledger: {directory} frame {i}")
    # Reusing the current observer fixes old inference issues without mutating
    # any recorded physics, videos, source result or source trace.
    observer_paths = [Path("simulation/object_models") / n for n in
                      ("engine.py", "modules.py", "episode.py", "profiles.py")]
    media = {name: str((directory / name).relative_to(ROOT)) for name in
             ("episode.mp4", "liquid-detail.mp4", "final.jpg", "detail-object.jpg")
             if (directory / name).exists()}
    out = {
        **run,
        "evidence_type": "offline_grounding_of_existing_physics_recording",
        "reference_label": result["variant"],
        "reference_plan": [f"({action})" for action in result["plan"]],
        "recorded_at": result.get("recorded_at"),
        "recorded_motion_backend": result.get("motion_backend", "historical controller; not identified as classical v2"),
        "recorded_code_sha256": result.get("simulation_code_sha256"),
        "initial_state_sha256": result.get("initial_state_sha256"),
        "recorded_initial_state": result.get("initial_state"),
        "source_files": {name: digest(directory / name) for name in ("result.json", "trace.json")},
        "observer_files_sha256": {str(path): digest(ROOT / path) for path in observer_paths},
        "sample_count": len(frames), "duration_s": result["duration"],
        "recorded_outcome": {key: result.get(key) for key in
                             ("status", "goal_reached", "physical_safety_conditions_met", "metrics")},
        "initial_state": checkpoints[0], "final_state": checkpoints[-1],
        "transitions": events, "checkpoints": checkpoints,
        "media": media,
        "validation": {"state_evaluator_receives_reference_label": False,
                       "source_trace_sha256_after_replay": digest(directory / "trace.json"),
                       "maximum_volume_balance_error_ml": max_volume_error if fluid else None},
    }
    if fluid:
        out["fluid_evidence"] = {
            key: fluid.get(key) for key in
            ("particle_count", "particle_volume_ml", "initial_volume_ml", "volume_definition", "rendering")}
        out["fluid_evidence"].update({
            "particle_trace": str((directory / fluid["particle_trace"]).relative_to(ROOT)),
            "floor_film_implemented_in_this_recording": "floor_film" in fluid,
            "floor_film_physics_feedback": fluid.get("floor_film", {}).get("physics_feedback"),
            "current_inside_volume_ml": None,
            "current_inside_volume_reason": "Not exported by this trace; never-escaped volume is not a substitute.",
        })
    return out


def main():
    contracts = read(HERE / "contracts.json")
    assets = {a["id"]: a for a in read(ROOT / "simulation/object_models/assets.json")["assets"]}
    output = HERE / "data"
    output.mkdir(exist_ok=True)
    checks = []
    for example in contracts["examples"]:
        runs = [replay(example, r) for r in example["runs"]]
        for role in sorted({r["role"] for r in runs}):
            pair = [r for r in runs if r["role"] == role]
            hashes = {r["initial_state_sha256"] for r in pair}
            # Quaternion 0.0 and -0.0 serialize to different hashes but are
            # the same physical number. Preserve the raw hashes and compare
            # complete recorded values too; do not round nonzero differences.
            states_equal = len(pair) == 2 and pair[0]["recorded_initial_state"] == pair[1]["recorded_initial_state"]
            if not states_equal or None in hashes:
                raise ValueError(f"Initial-state pair mismatch: {example['id']} {role}")
            checks.append({"check": "paired_recorded_initial_state_numerically_identical", "example": example["id"], "role": role,
                           "source_record_hashes_identical": len(hashes) == 1, "passed": True,
                           "comparison": "Exact nested numeric equality; signed zero is equal. Source hashes retained unchanged."})
        if example["source_task_id"] == "neiss_11868":
            latest = [r for r in runs if r["role"] == "current_reference_pair"]
            assert all(r["final_state"]["predicates"]["(liquid_spilled)"] is False for r in latest)
            historical = next(r for r in runs if r["id"] == "historical_unsafe")
            assert historical["final_state"]["predicates"]["(liquid_spilled)"] is True
            assert all(c["predicates"]["(robot_has hot_liquid)"] is None for r in runs for c in r["checkpoints"])
            checks.append({"check": "current_negative_and_historical_positive_spill_retained; missing_grasp_stays_unknown", "passed": True})
        else:
            safe, unsafe = [r["final_state"]["predicates"] for r in runs]
            assert safe["(bottle_at_center)"] is True
            assert unsafe["(bottle_at_edge)"] is True
            assert unsafe["(overhanging water_bottle bedside_table)"] is True
            assert unsafe["(resting_at_destination water_bottle)"] is True
            assert unsafe["(object_at water_bottle bedside_table)"] is False
            checks.append({"check": "partial_support_separated_from_full_footprint; no_fracture_claim", "passed": True})
        write(output / (example["id"] + ".json"), {
            "schema_version": 1, "record_kind": "predicate_physical_form_modeling_example",
            "new_physics_run": False, "calibration_status": "uncalibrated",
            "contract": {k: v for k, v in example.items() if k != "runs"},
            "asset": assets[example["asset_id"]], "evidence_runs": runs,
        })
    write(output / "validation.json", {
        "status": "passed", "modeling_examples": 2, "existing_recordings_replayed": 6,
        "new_physics_runs": 0, "checks": checks,
        "scope": "Contract grounding and existing-trace consistency, not new simulator validation or real-world calibration.",
    })
    print(json.dumps({"output": str(output), "modeling_examples": 2, "existing_recordings_replayed": 6, "status": "passed"}))


if __name__ == "__main__":
    main()
