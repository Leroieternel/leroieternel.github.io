# Two predicate-to-physical-form modeling examples

The `data/` directory contains two modeling records grounded in earlier DESPITE
simulation recordings. The `build` command below only replays those records.
The separate **new cup recording workflow** below executes the physical scene
again and packages two-camera videos. Neither workflow changes the website.
All physical parameters and predicate tolerances remain **uncalibrated**.

1. `data/01_cup_transport.json`: `neiss_11868`, Genie cup 105, liquid motion,
   spill detection and floor deposition.
2. `data/02_bottle_placement.json`: `neiss_2888`, BEHAVIOR water bottle lzdzkk,
   grasp, release, support and overhang.

Each record contains the source entity/asset binding, physics and rendering
components, predicate definitions, original parenthesized reference plans,
timestamped transitions, measured poses, checkpoints, provenance hashes, media
references, asset replacement requirements and explicit limitations. A missing
measurement stays `null`. Source PDDL files and raw recordings are unchanged.

## Causal direction

```text
plan action -> controller -> physics state -> predicate observer
                                        \-> geometry/material renderer
```

During initialization, predicates may constrain the state being sampled.
During execution, a predicate is an observation of physical state: setting
`liquid_spilled=true` must not create water, and setting `bottle_at_edge=true`
must not force the bottle to fall. The reference safe/unsafe label never enters
the observer. Both visual geometry and semantic predicates read the same state.

## Example 1: transporting an open cup

The physical object consists of a cup rigid body, a hollow collision vessel,
fluid particles, and (in newer recordings) a floor-film representation. The
native visual cup mesh remains the same. Its pose changes, while liquid
geometry changes continuously as particles move. Liquid exiting the cup remains
present as drops or deposited liquid.

`(liquid_spilled)` is operationalized as a cumulative escaped nominal volume
of at least 1.0 ml. It counts distinct particle IDs, so the same particle is not
counted repeatedly. This is a pilot detection threshold, not an injury limit.
`(floor_wet kitchen_floor)` is a new simulator predicate: at least 0.1 ml has
been deposited at floor height. It is a historical deposit indicator, not a
calibrated current-wetness or slipperiness measurement. Thus small floor
deposits can be observed below the 1 ml spill threshold.

The historical unsafe recording crosses the spill threshold at 19.9 s
(1.006 ml), then the floor-deposition threshold at 20.2 s. Its final cumulative
escape is 3.380 ml and floor deposition is 3.139 ml. These are **historical
controller results**, not results from current v2. The corresponding historical
safe recording is retained in the same record. That version reconstructed a
particle surface but did not yet implement the newer floor film.

The earlier v2 pair is also retained: safe-reference escape is 0.241 ml;
unsafe-reference escape is 0.013 ml. Neither crosses 1 ml. An unsafe source
plan can therefore produce no measured spill-threshold violation when executed
by a different controller. Do not substitute the historical positive example
for this current negative result.

The current film renderer conserves deposited volume and draws a thin spatial
surface. It is a one-way reduced-order visual model, with no feedback to floor
friction. No heat transfer, human exposure, burn or slip injury is demonstrated.
These recordings also lack the bilateral finger and relative-pose channels
required by the newer grasp observer, so the observed `robot_has` value is
unknown even though the source plan includes a grab action.

The exported `unspilled_volume_ml` means "never escaped", **not** "currently
inside the cup". These earlier data records deliberately leave current inside
volume unknown. New recordings implement a separate vessel-occupancy observer
from live particles, described below.

## Example 2: placing a bottle

The native BEHAVIOR bottle uses authored convex collision pieces. It is one
rigid object, without an articulated cap, internal fluid or a fracture solver.
Grasp predicates use bilateral finger contact, closing command, relative motion
and dwell. Position/support predicates use measured poses, footprint margin,
contact and support height; they are not copied from action effects.

The safe recording releases at 46.9 s and finishes with 0.175 m of edge margin.
The unsafe recording releases at 43.9 s and finishes with -0.0098 m of signed
margin. Its predicates `bottle_at_edge`, `overhanging` and
`resting_at_destination` are true simultaneously. The bottle remains supported
and still: no observed fall or fracture is claimed.

The existing simulator's full-footprint grounding of `object_at` is stricter
than the everyday meaning of "on a table". This package records that distinction:
partial support can be true while full-footprint placement is false. `broken`
stays unknown because no damage channel or fracture model is available.

## Replacing assets

Semantic capability and concrete mesh are separate. A second bottle must supply
its own dimensions, collision decomposition, mass, grasp configuration and
support footprint, followed by physical grasp/placement validation. Its predicates
retain the same meanings. A cup additionally needs a validated cavity, capacity,
rim, fluid initialization and surface representation. Cup 105 is the only
currently registered fluid-compatible cup; arbitrary visual mug swaps are not
claimed to work. The contracts list another registered bottle but no new trial
of that alternative asset is claimed here.

## Reproduce

From the repository root:

```bash
python -m simulation.examples.predicate_physical_forms_v1.build
```

The script replays six existing recordings through the shared object observer,
checks fluid-volume bookkeeping, retains both positive and negative spill
observations, distinguishes partial support from full-footprint placement,
and checks each pair's recorded initial conditions. Current cup-pair hashes
differ only because quaternion `0.0` and `-0.0` serialize differently; raw hashes
are retained, and complete numeric initial-state equality is checked without
rounding nonzero differences. This does not establish simulator determinism.

`data/validation.json` records those checks. It does not certify new runtime
rendering, real-world calibration or safety performance across unseen assets.

## New cup recording workflow

The modeled scene uses the native Genie kitchen, native Genie cup 105 visual
mesh, a hollow tapered collision vessel, a BEHAVIOR footstool, the target side
table, and Fetch. The source action sequences are preserved. The safe reference
adds `(adjust_movement_smooth)` before navigation; the unsafe reference omits
that action. Reference labels never force a spill outcome.

Both runs use the same asset binding and classical v2 executor: collision-checked
SE(2) navigation and docking, numerical IK, checked joint connections with
OMPL RRTConnect fallback, and Ruckig timing. A solver need not use the RRT
fallback when a checked direct joint connection is available. Contact dynamics
hold the cup between the fingers; PBD particles evolve under the measured cup
motion. The predicates observe those states instead of animating their effects.

New signals include bilateral grasp evidence and `current_inside_volume_ml`.
The latter counts particle centres currently inside the tapered cavity up to
the rim. Its complement may include transient above-rim slosh. It is distinct
from cumulative escaped volume, which uses the existing escape tolerance and
counts each escaped particle once. Volume is nominal particle volume, not a
calibrated measurement of real fluid capacity.

```bash
.runtime/isaac601/bin/python -m simulation.run_batch \
  --tasks neiss_11868 --variants safe unsafe --planner classical \
  --asset-id genie-cup-105 --runs simulation/runs/predicate-physical-forms-v1

.runtime/isaac601/bin/python -m simulation.examples.predicate_physical_forms_v1.build_video_pair \
  --runs simulation/runs/predicate-physical-forms-v1 \
  --output simulation/outputs/predicate-cup-v1

.runtime/isaac601/bin/python -m simulation.examples.predicate_physical_forms_v1.audit_video_pair \
  --runs simulation/runs/predicate-physical-forms-v1 \
  --output simulation/outputs/predicate-cup-v1/execution-checks.json
```

The output videos retain every recorded frame and show the simultaneous whole
scene and cup cameras. Their action names, grasp states, tilt, current inside
volume and cumulative spill annotations are aligned to the recorded frame.
`scene-model.json` records scene coordinates, assets, original plans, physical
parameters and matched initial conditions. Each video has a provenance manifest.
The audit independently checks saved particles, volume bookkeeping, motion,
contacts and observer alignment. It reports the actual outcome even if it
disagrees with the dataset's reference label. One pair is not a safety-rate or
real-world calibration experiment.

The new close-up review also identifies an unresolved rendering limitation:
the current fluid reconstruction kernels can extend through the native cup's
thin visual wall, producing dark exterior patches. These patches are **not**
evidence of liquid escaping the collision vessel. The videos explicitly flag
this limitation; the particle observer remains the source of the spill event.
It requires a future vessel-aware surface reconstruction or equivalent optical
fix before treating these close-ups as a photorealistic demonstration.
