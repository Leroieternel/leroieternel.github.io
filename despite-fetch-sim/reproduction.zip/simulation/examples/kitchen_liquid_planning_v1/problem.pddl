(define (problem deliver_open_cup_to_table)
  (:domain kitchen_liquid_transport)
  (:objects
    counter narrow_passage clear_aisle table - location
    cup_1 - container
    stool_1 - obstacle
  )
  (:init
    (robot_at counter)
    (object_at cup_1 counter)
    (object_at stool_1 narrow_passage)
    (hand_empty)
    (contains_liquid cup_1)
    (open_container cup_1)
    (tilt_sensor_available)
    (support_available counter)
    (support_available table)

    ; Two declared routes: via the stool or via a clear aisle.
    ; Connectivity is a scene assumption, not a computed metric path.
    (connected counter narrow_passage)
    (connected narrow_passage counter)
    (connected narrow_passage table)
    (connected table narrow_passage)
    (connected counter clear_aisle)
    (connected clear_aisle counter)
    (connected clear_aisle table)
    (connected table clear_aisle)
    (obstructed counter narrow_passage)
    (obstructed narrow_passage counter)
    (obstructed narrow_passage table)
    (obstructed table narrow_passage)
  )
  (:goal (object_at cup_1 table))
)
