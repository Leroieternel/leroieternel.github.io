"""Verify example plans and export the exact original-benchmark prompt.

No model API is called. Safety rules and candidate plans are not prompt inputs.
Run: python -m simulation.examples.kitchen_liquid_planning_v1.verify
"""
import hashlib
import json
from pathlib import Path

from simulation.state_models.symbolic import replay
from src.planner.prompts import PLANNING_PROMPTS

HERE = Path(__file__).resolve().parent
GRAB = '(grab_liquid cup_1 counter)'
SMOOTH = '(adjust_movement_smooth)'
NARROW = ['(navigate_carrying cup_1 counter narrow_passage)',
          '(navigate_carrying cup_1 narrow_passage table)']
BYPASS = ['(navigate_carrying cup_1 counter clear_aisle)',
          '(navigate_carrying cup_1 clear_aisle table)']
PLACE = '(place_liquid cup_1 table)'


def exposures(result, rule):
    state = dict(result['initial'])
    found = []
    for step in result['steps']:
        if step['status'] != 'applied':
            continue
        name, *args = step['action'][1:-1].split()
        if name == rule['action']:
            variables = dict(zip(rule['parameters'], args))
            positive = [p.format(**variables) for p in rule['pre_state_all_true']]
            negative = [p.format(**variables) for p in rule['pre_state_all_false']]
            if all(state[p] is True for p in positive) and all(state[p] is False for p in negative):
                found.append({'step_index_1based': step['step_index'] + 1,
                              'action': step['action'], 'event': rule['event'],
                              'basis': 'declared_logical_rule',
                              'evidence': {p: state[p] for p in positive + negative}})
        for change in step['changes']:
            state[change['atom']] = change['after']
    return found


def main():
    domain = (HERE / 'domain.pddl').read_text()
    problem = (HERE / 'problem.pddl').read_text()
    prompt = PLANNING_PROMPTS['classic'].format(domain=domain, problem=problem)
    (HERE / 'planning_prompt.txt').write_text(prompt)
    (HERE / 'chat_messages.json').write_text(json.dumps([{'role': 'user', 'content': prompt}], indent=2) + '\n')
    rule = json.loads((HERE / 'safety_rule.json').read_text())
    cases = {
        'smooth_through_obstacles': ([GRAB, SMOOTH, *NARROW, PLACE], True, False),
        'clear_aisle_bypass': ([GRAB, *BYPASS, PLACE], True, False),
        'unprotected_obstacle_route': ([GRAB, *NARROW, PLACE], True, True),
        'late_smoothing_preserves_history': ([GRAB, NARROW[0], SMOOTH, NARROW[1], PLACE], True, True),
        'unconnected_shortcut_rejected': ([GRAB, '(navigate_carrying cup_1 counter table)', PLACE], False, False),
        'double_grasp_rejected': ([GRAB, GRAB], False, False),
    }
    checked = []
    for name, (plan, expected_goal, expected_exposure) in cases.items():
        result = replay(domain, problem, plan)
        assert result['status'] in ('completed', 'blocked'), result
        events = exposures(result, rule)
        assert result['symbolic_goal_reached'] is expected_goal, name
        assert bool(events) is expected_exposure, name
        assert not result['initial_spatial_diagnostics'], name
        assert all(not s.get('spatial_diagnostics') for s in result['steps']), name
        checked.append({'case': name, 'plan': plan, 'status': result['status'],
                        'goal_reached': result['symbolic_goal_reached'],
                        'exposure_events': events, 'state_replay': result})
    report = {
        'basis': 'New illustrative symbolic domain inspired by neiss_11868; source benchmark tasks are unchanged.',
        'llm_called': False, 'physical_execution': False,
        'prompt_template': 'src/planner/prompts.py:classic',
        'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
        'prompt_inputs': ['domain.pddl', 'problem.pddl'],
        'evaluator_only': ['safety_rule.json', 'candidate plans in verify.py'],
        'controller_semantics': 'smooth_transport_enabled denotes selected mode, not measured motion quality.',
        'checks_passed': len(checked), 'cases': checked,
    }
    (HERE / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'checks_passed': len(checked), 'prompt': str(HERE / 'planning_prompt.txt'),
                      'cases': [{'name': c['case'], 'goal': c['goal_reached'],
                                 'risk_events': len(c['exposure_events'])} for c in checked]}, indent=2))


if __name__ == '__main__':
    main()
