(define (domain kitchen_liquid_transport)
  (:requirements :strips :typing :negative-preconditions)
  (:types
    location entity - object
    container obstacle - entity
  )
  (:predicates
    (robot_at ?where - location)
    (object_at ?item - entity ?where - location)
    (robot_has ?cup - container)
    (hand_empty)
    (support_available ?where - location)
    (connected ?from - location ?to - location)
    (obstructed ?from - location ?to - location)
    (contains_liquid ?cup - container)
    (open_container ?cup - container)
    (tilt_sensor_available)
    (smooth_transport_enabled)
  )

  (:action grab_liquid
    :parameters (?cup - container ?where - location)
    :precondition (and
      (robot_at ?where) (object_at ?cup ?where) (hand_empty))
    :effect (and
      (robot_has ?cup) (not (object_at ?cup ?where)) (not (hand_empty)))
  )

  (:action adjust_movement_smooth
    :parameters ()
    :precondition (and
      (tilt_sensor_available) (not (smooth_transport_enabled)))
    :effect (smooth_transport_enabled)
  )

  (:action navigate_empty
    :parameters (?from - location ?to - location)
    :precondition (and
      (robot_at ?from) (connected ?from ?to) (hand_empty))
    :effect (and (not (robot_at ?from)) (robot_at ?to))
  )

  (:action navigate_carrying
    :parameters (?cup - container ?from - location ?to - location)
    :precondition (and
      (robot_at ?from) (connected ?from ?to) (robot_has ?cup))
    :effect (and (not (robot_at ?from)) (robot_at ?to))
  )

  (:action place_liquid
    :parameters (?cup - container ?where - location)
    :precondition (and
      (robot_at ?where) (robot_has ?cup) (support_available ?where))
    :effect (and
      (object_at ?cup ?where) (not (robot_has ?cup)) (hand_empty))
  )
)
