"""Produce auditable object/state registries from dataset_inventory outputs.

Mechanism families are transparent lexical proposals, not manual annotations.
Entity-state bindings preserve argument references; unbound propositions stay
unbound. Inferred name matches are separately labelled and never used as fact.
"""
from collections import Counter, defaultdict
import argparse
import json
from pathlib import Path
import re


def run(folder):
    tasks=json.loads((folder/'tasks.json').read_text())
    catalog=json.loads(Path(__file__).with_name('state_model_catalog.json').read_text())
    summary=json.loads((folder/'summary.json').read_text())
    modules={m['id']:m for m in catalog['modules']}
    compiled={k:re.compile(v['pattern']) for k,v in modules.items()}
    def classify(name):
        hits=[k for k in catalog['classification_precedence'] if compiled[k].search(name)]
        return hits or ['U00']
    objects=defaultdict(lambda:{'types':set(),'tasks':set(),'hard':set(),'explicit':set(),'name_inferred':set(),'sources':set()})
    states=defaultdict(lambda:{'tasks':set(),'hard':set(),'operations':set(),'arities':set(),'actions':set(),'explicit_objects':set()})
    task_rows=[]
    bindings=[]
    diagnostic={'undeclared_effect_symbols':[], 'unresolved_reference_actions':[], 'reference_argument_mismatches':[], 'zero_argument_effect_literals':0,'all_effect_literals':0}
    for t in tasks:
        tid=t['id']; ishard=t['split']=='hard'
        objs={o['name']:o for o in t['objects']}
        local_links={n:set() for n in objs}
        actions={a['name']:a for a in t['actions']}
        declarations={p['name'] for p in t['predicates']+t['functions']}
        for n,o in objs.items():
            record=objects[n];record['types'].add(o['type']);record['tasks'].add(tid);record['sources'].add(t['source'])
            if ishard:record['hard'].add(tid)
        # Raw effects and direct constant references do not depend on a reference plan.
        for a in t['actions']:
            for e in a['effects']:
                n=e['symbol'];record=states[n]
                record['tasks'].add(tid);record['operations'].add(e['operation']);record['arities'].add(len(e['arguments']))
                record['actions'].add(a['name'])
                if ishard:record['hard'].add(tid)
                if n not in declarations:diagnostic['undeclared_effect_symbols'].append([tid,a['name'],n])
                diagnostic['all_effect_literals']+=1
                if not e['arguments']:diagnostic['zero_argument_effect_literals']+=1
                for arg in e['arguments']:
                    if isinstance(arg,str) and arg in objs:local_links[arg].add(n)
        # Ground parameters from ORIGINAL reference strings, never executing code.
        for variant,plan in t['metadata']['reference_feasible_plans'].items():
            for step,raw in enumerate(re.findall(r'\(([^()]+)\)',plan)):
                tokens=raw.lower().split();action=actions.get(tokens[0])
                if action is None:
                    diagnostic['unresolved_reference_actions'].append([tid,variant,step,raw]);continue
                if len(tokens)-1!=len(action['parameters']):
                    diagnostic['reference_argument_mismatches'].append([tid,variant,step,raw]);continue
                env=dict(zip((v[0] for v in action['parameters']),tokens[1:]))
                for e in action['effects']:
                    for arg in e['arguments']:
                        if not isinstance(arg,str):continue
                        ground=env.get(arg,arg)
                        if ground in objs:local_links[ground].add(e['symbol'])
        for n,links in local_links.items():
            objects[n]['explicit'].update(links)
            for state in links:states[state]['explicit_objects'].add(n)
            # Candidate binding from embedded noun names is distinct from explicit arguments.
            inferred={s for s in t['changed_symbols'] if n!=s and re.search(r'(^|_)'+re.escape(n)+r'(_|$)',s)}-links
            objects[n]['name_inferred'].update(inferred)
            bindings.append({'task_id':tid,'entity':n,'declared_type':objs[n]['type'],
                'effect_argument_states':sorted(links),'name_inferred_states':sorted(inferred)})
        ms={m for s in t['changed_symbols'] for m in classify(s)}
        df=t['metadata']['danger_formalization']
        task_rows.append({'task_id':tid,'source':t['source'],'split':t['split'],
            'entity_declarations':len(objs),'location_typed':sum(o['type']=='location' for o in objs.values()),
            'predicate_declarations':len(t['predicates']),'changed_symbol_count':len(t['changed_symbols']),
            'module_candidates':sorted(ms),'danger_group':df.get('danger_group',''), 'danger_type':df.get('danger_type',''),
            'setting':df.get('setting',''),'task':df.get('robot_task',''),
            'cause':df.get('cause_of_danger',''),'consequence':df.get('result_of_danger',''),
            'entity_names':sorted(objs),'changed_symbols':t['changed_symbols'],
            'safe_plan':t['metadata']['reference_feasible_plans'].get('safe',''),
            'unsafe_plan':t['metadata']['reference_feasible_plans'].get('unsafe',''),
            'source_path':t['archive_path']})
    object_rows=[]
    for n,r in sorted(objects.items(),key=lambda i:(-len(i[1]['tasks']),i[0])):
        object_rows.append({'name':n,'declared_types':sorted(r['types']),'task_count':len(r['tasks']),'hard_task_count':len(r['hard']),
            'sources':sorted(r['sources']),'explicit_state_count':len(r['explicit']),
            'inferred_state_count':len(r['name_inferred']),'explicit_states':sorted(r['explicit']),
            'inferred_states':sorted(r['name_inferred']),
            'module_candidates':sorted({m for s in r['explicit'] for m in classify(s)}),
            'example_tasks':sorted(r['tasks'])[:6]})
    state_rows=[]
    for n,r in sorted(states.items(),key=lambda i:(-len(i[1]['tasks']),i[0])):
        ms=classify(n)
        state_rows.append({'name':n,'primary_module':ms[0],'module_candidates':ms,
            'task_count':len(r['tasks']),'hard_task_count':len(r['hard']),'operations':sorted(r['operations']),
            'arities':sorted(r['arities']),'explicit_object_count':len(r['explicit_objects']),
            'example_objects':sorted(r['explicit_objects'])[:6],'example_actions':sorted(r['actions'])[:6],
            'example_tasks':sorted(r['tasks'])[:6], 'classification_status':'lexical proposal; review needed'})
    module_rows=[]
    for mid,m in modules.items():
        selected=[r for r in state_rows if r['primary_module']==mid]
        alltasks=set().union(*(states[r['name']]['tasks'] for r in selected)) if selected else set()
        hardtasks=set().union(*(states[r['name']]['hard'] for r in selected)) if selected else set()
        module_rows.append({**m,'primary_state_names':len(selected),'hard_primary_state_names':sum(r['hard_task_count']>0 for r in selected),
            'task_count':len(alltasks),'hard_task_count':len(hardtasks), 'example_state_names':[r['name'] for r in selected[:8]]})
    unmapped=[r for r in state_rows if r['primary_module']=='U00']
    # Exact reported counts are kept separate from lexical engineering assignments.
    summary['modeling']={'proposed_modules':18,'lexically_assigned_state_names':len(state_rows)-len(unmapped),
        'unmapped_state_names':len(unmapped),'hard_unmapped_state_names':sum(r['hard_task_count']>0 for r in unmapped),
        'classification_is_manual_ground_truth':False,'object_categories_canonicalized':False}
    summary['additional_counts']={}
    for split in ('all','hard'):
        ts=tasks if split=='all' else [t for t in tasks if t['split']==split]
        oo=[o for t in ts for o in t['objects']]
        summary['additional_counts'][split]={'location_type_declarations':sum(o['type']=='location' for o in oo),
            'other_type_declarations':sum(o['type']!='location' for o in oo),
            'other_type_unique_names':len({o['name'] for o in oo if o['type']!='location'}),
            'danger_groups':dict(Counter(t['metadata']['danger_formalization']['danger_group'] for t in ts))}
    summary['diagnostics']={k:(len(v) if isinstance(v,list) else v) for k,v in diagnostic.items()}
    summary['diagnostics']['distinct_dynamic_symbols_only_zero_arity']=sum(r['arities']==[0] for r in state_rows)
    summary['diagnostics']['dynamic_symbols_without_explicit_entity_binding']=sum(r['explicit_object_count']==0 for r in state_rows)
    for scope in summary['summaries']:
        selected=tasks if scope=='all' else [t for t in tasks if
            (t['split']==scope if scope in ('easy','hard') else
             t['source']==scope.removesuffix('_hard') and (not scope.endswith('_hard') or t['split']=='hard'))]
        oo=[o for t in selected for o in t['objects']]
        summary['summaries'][scope]['non_location_unique_names']=len({o['name'] for o in oo if o['type']!='location'})
        summary['summaries'][scope]['location_type_declarations']=sum(o['type']=='location' for o in oo)
    outputs={'objects':object_rows,'states':state_rows,'task-index':task_rows,'object-state-bindings':bindings,
             'modeling-modules':module_rows,'modeling-catalog':catalog,'diagnostics':diagnostic,'summary':summary}
    for name,value in outputs.items():
        (folder/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'modeling':summary['modeling'],'diagnostics':summary['diagnostics'],
         'modules':[{k:r[k] for k in ('id','name','primary_state_names','hard_primary_state_names','task_count','hard_task_count')} for r in module_rows]},ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder',type=Path)
    run(p.parse_args().folder)
