"""Record the two additional source tasks after the native-engine video batch."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',type=Path,required=True)
    args=parser.parse_args();root=args.runs;progress=root/'batch-progress.json'
    while not progress.exists() or json.loads(progress.read_text()).get('state')!='finished':
        time.sleep(5)
    rows=[];source=Path(__file__).resolve().parent
    for task in ('neiss_9506','neiss_13019'):
        for variant in ('safe','unsafe'):
            folder=root/(task+'-'+variant);file=folder/'result.json';valid=False
            if file.exists():
                record=json.loads(file.read_text())
                valid=(not record.get('physics_only') and not record.get('draft') and
                       record.get('planning',{}).get('revision')=='classical-fetch-v2' and
                       record['status'] in ('completed','blocked') and
                       all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in record['simulation_code_sha256'].items()))
            if not valid:
                if folder.exists():folder.rename(folder.with_name(folder.name+'-archived-'+str(time.time_ns())))
                while int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).splitlines()[0])<18000:
                    time.sleep(10)
                (root/'alias-progress.json').write_text(json.dumps({'state':'running','task':task,'variant':variant,'finished':rows}))
                command=[sys.executable,'-m','simulation.pilot.run','--task',task,'--variant',variant,'--condition','baseline','--seed','11',
                         '--video','--planner','classical','--output',str(folder)]
                print('START',task,variant,flush=True);started=time.monotonic()
                with (root/'logs'/(task+'-'+variant+'.log')).open('w') as log:
                    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'OMNIGIBSON_NO_OMNI_LOGS':'False'})
                if not file.exists():
                    rows.append({'task':task,'variant':variant,'status':'initialization_error','exit_code':result.returncode})
                    continue
                record=json.loads(file.read_text())
                print('RECORDED',task,variant,round(time.monotonic()-started,1),'wall seconds',flush=True)
            row={'task':task,'variant':variant,'status':record['status'],'goal':record['goal_reached'],
                 'physical_conditions_met':record['physical_safety_conditions_met'],'duration_s':record['duration']}
            rows.append(row);print('RESULT',json.dumps(row),flush=True)
    (root/'alias-progress.json').write_text(json.dumps({'state':'finished','finished':rows},indent=2))


if __name__=='__main__':main()
