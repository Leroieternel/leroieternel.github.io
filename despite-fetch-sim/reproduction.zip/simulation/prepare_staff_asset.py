"""Cache the official Isaac Sim business character; never publish raw assets."""
import hashlib
import json
import urllib.request
from pathlib import Path

from simulation.runtime import ROOT, RUNTIME

BASE = 'https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/6.0/Isaac/People/Characters/F_Business_02/'
FILES = ['F_Business_02.usd', *['textures/female_adult_business_02_'+s+'.png' for s in ['BaseColor', 'Normal', 'ORM']]]
DEST = RUNTIME/'staff-assets/F_Business_02'


def main():
    rows=[]
    for name in FILES:
        target=DEST/name
        target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():
            with urllib.request.urlopen(BASE+name,timeout=60) as response:
                temporary=target.with_suffix(target.suffix+'.partial')
                temporary.write_bytes(response.read())
                temporary.replace(target)
        rows.append({'path':name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    manifest={'source':'NVIDIA Isaac Sim 6.0 character assets','character':'F_Business_02',
              'url':BASE,'documentation':'https://docs.isaacsim.omniverse.nvidia.com/6.0.0/assets/usd_assets_props.html',
              'redistribution':'Raw character files are excluded from website and reproduction archives; obtain from NVIDIA under its asset terms.',
              'files':rows}
    (ROOT/'simulation/staff_asset.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'files':len(rows),'bytes':sum(x['bytes'] for x in rows)}))


if __name__=='__main__':main()
