"""Held-out comparison interface; never auto-fit or invent real measurements."""
import argparse
import json
import math
from pathlib import Path

QUANTITIES={
    'mass':('kg',('recipe','mass_kg')),
    'max_tilt':('deg',('outcome','max_tilt_deg')),
    'max_displacement':('m',('outcome','max_displacement_m')),
    'release_com_margin':('m',('initial_state','com_support_margin_m')),
    'escaped_liquid':('ml',('liquid','ledger','spilled_ml')),
}


def compare(root,rows=None):
    out=[]
    for row in rows or []:
        required={'trial','quantity','value','unit','instrument','measured_at','measurement_source'}
        if required-set(row):raise ValueError('Missing measurement provenance')
        unit,keys=QUANTITIES[row['quantity']]
        if row['unit']!=unit or not math.isfinite(float(row['value'])):raise ValueError('Invalid unit/value')
        path=(root/row['trial']/'result.json').resolve()
        if not path.is_relative_to(root.resolve()):raise ValueError('Trial path escapes run root')
        value=json.loads(path.read_text())
        for key in keys:value=value[key]
        out.append({**row,'simulation_value':value,'signed_error':value-float(row['value']),
                    'absolute_error':abs(value-float(row['value']))})
    return {'status':'compared_with_supplied_measurements' if out else 'awaiting_real_measurements',
        'calibrated':False,'comparisons':out,'note':'No fitting performed; comparisons do not establish general transfer accuracy.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--runs',type=Path,required=True);p.add_argument('--measurements',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.write_text(json.dumps(compare(a.runs,json.loads(a.measurements.read_text()) if a.measurements else None),indent=2)+'\n')
