"""Source-linked object consequence fixtures, separate from whole-plan rollouts."""

REVISION = 'object-consequences-v1'
