"""Pure observation logic shared by fixtures and future full-plan adapters."""
import math


class OutcomeObserver:
    def __init__(self, support_top, initial_xy, floor_case=False):
        self.top=support_top; self.initial_xy=initial_xy; self.floor_case=floor_case
        self.events=[]; self.previous_t=-1.; self.max_tilt=0.;self.max_displacement=0.
        self.contact_samples=0;self.stable_since=None;self.last=None

    def update(self, sample):
        t=sample['t']
        if t<=self.previous_t:raise ValueError('Observation times must increase')
        self.previous_t=t;self.last=sample
        self.max_tilt=max(self.max_tilt,sample['tilt_deg'])
        distance=math.dist(sample['position_m'][:2],self.initial_xy)
        self.max_displacement=max(self.max_displacement,distance)
        contact=sample['probe_contact'];self.contact_samples+=int(contact)
        active={e['type'] for e in self.events}
        conditions={'contact':contact,'tipped':sample['tilt_deg']>=45.,
            'fell_below_support':not self.floor_case and sample['position_m'][2]<self.top-.08,
            'displaced':self.floor_case and distance>.03,
            'modeled_spill':sample.get('modeled_spilled_ml',0)>=1.}
        for name,on in conditions.items():
            if on and name not in active:self.events.append({'type':name,'t':t,
                'basis':'reduced_order_liquid' if name=='modeled_spill' else 'PhysX_contact_or_rigid_state'})
        stable=sample['support_contact'] and sample['tilt_deg']<15 and sample['speed_m_s']<.02 and sample['angular_speed_rad_s']<.15
        self.stable_since=(t if self.stable_since is None else self.stable_since) if stable else None
        return conditions

    def report(self):
        if self.last is None:raise ValueError('No physical observations')
        events={e['type'] for e in self.events}
        # No source reference label is accepted by this observer.
        return {'events':self.events,'max_tilt_deg':self.max_tilt,'max_displacement_m':self.max_displacement,
            'contact_samples':self.contact_samples,'tipped':'tipped' in events,'fell':'fell_below_support' in events,
            'displaced':'displaced' in events,'modeled_spill':'modeled_spill' in events,
            'stable_at_end':self.stable_since is not None and self.last['t']-self.stable_since>=.5,
            'reference_label_used':False,'calibration_status':'uncalibrated'}
