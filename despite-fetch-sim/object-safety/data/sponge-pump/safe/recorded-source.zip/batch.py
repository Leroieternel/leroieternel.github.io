"""Run native object fixtures serially; retain failures and original records."""
import argparse
import json
from pathlib import Path
import subprocess
from simulation.runtime import ROOT
from .cases import CASES
from .verify import audit_pair


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cases',nargs='+',choices=CASES,default=list(CASES));p.add_argument('--physics-only',action='store_true')
    p.add_argument('--condition',type=Path);p.add_argument('--asset-id')
    a=p.parse_args();root=a.output.resolve();root.mkdir(parents=True,exist_ok=True)
    queue={'status':'running','physics_only':a.physics_only,'attempts':[],'pairs':[]}
    def save():(root/'run-index.json').write_text(json.dumps(queue,indent=2)+'\n')
    for case in a.cases:
        for variant in ('safe','unsafe'):
            dest=root/(case+'-'+variant)
            if dest.exists():raise FileExistsError('Fresh output required: '+str(dest))
            cmd=[str(ROOT/'.runtime/isaac601/bin/python'),'-m','simulation.object_safety.run',
                '--case',case,'--variant',variant,'--output',str(dest)]
            if a.physics_only:cmd.append('--physics-only')
            if a.condition:cmd+=['--condition',str(a.condition.resolve())]
            if a.asset_id:cmd+=['--asset-id',a.asset_id]
            row={'case':case,'variant':variant,'command':cmd,'status':'running'};queue['attempts'].append(row);save()
            with (root/(case+'-'+variant+'.log')).open('w') as log:
                result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            row['returncode']=result.returncode
            row['status']='completed' if result.returncode==0 and (dest/'result.json').exists() else 'failed';save()
            if row['status']=='failed':queue['status']='failed';save();return 1
        try:queue['pairs'].append(audit_pair(root,case));save()
        except Exception as e:
            queue.update(status='audit_failed',error=repr(e));save();raise
    queue['status']='completed';save();return 0


if __name__=='__main__':raise SystemExit(main())
