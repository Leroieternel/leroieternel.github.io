"""Search all source actions and installed asset categories without executing code.py.

Automatic matches are candidates, never validated physical coverage. Exact
source strings, object references, hashes and unmatched records are retained.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

from simulation.runtime import ROOT, RUNTIME
from .cases import CASES, EXISTING

ALIASES = {
    'water_bottle':'water_bottle', 'bottle':'water_bottle', 'wine_bottle':'wine_bottle',
    'pump_bottle':'soap_dispenser', 'soap_bottle':'soap_dispenser', 'medication_bottle':'pill_bottle',
    'medicine_bottle':'pill_bottle','pill_bottle':'pill_bottle','medication':'pill_bottle',
    'package':'carton','supplies':'carton','medical_supplies':'carton','medical_box':'carton',
    'supply_box':'carton','box':'carton','tool':'portable','cleaning_tool':'cleaning_tool',
    'glass':'drinking_glass','mug':'mug','cup':'cup','stool':'footstool',
    'human_hand':'human','patient':'human','customer':'human','staff':'human',
    'cleaning_solution':'liquid','cleaning_fluid':'liquid','water':'liquid','spill':'liquid',
    'rag':'rag','cleaning_cloth':'rag','wet_mop':'mop',
}
MECHANISMS = {
    'support_loss': r'edge|unstable|stability|fall|drop|toppl|tip(?:s|ped|ping)?\b',
    'collision': r'collid|collision|knock|bump|impact|obstruct',
    'grasp_loss': r'grip|slip.*(?:hand|grasp)|lose.*grasp|slippage',
    'liquid': r'spill|splash|pour|leak|overflow|wet floor',
    'articulation': r'door|drawer|hinge|pinch|jamb',
    'thermal': r'burn|hot\b|heat|scald|fire|temperature',
    'electrical': r'electric|voltage|short.circuit|electroc',
    'contamination': r'contamin|infect|bacter|hygien|toxic|chemical',
    'damage': r'break|shatter|fracture|cut|sharp|crush',
    'human_exposure': r'human|patient|child|person|elderly|injur',
    'protocol': r'permission|consent|authoriz|procedur|protocol|process',
}


def normalize(name):
    return re.sub(r'_?\d+$','',name.lower())


def inventory_assets():
    out = {}
    base = RUNTIME/'datasets/behavior-1k-assets/objects'
    for folder in sorted(base.iterdir()):
        if not folder.is_dir():continue
        models=[]
        for meta in sorted(folder.glob('*/misc/metadata.json')):
            model=meta.parents[1].name
            usd=meta.parents[1]/'usd'/f'{model}.encrypted.usd'
            if usd.is_file():models.append({'provider':'BEHAVIOR-1K','model':model,'source_path':str(usd.relative_to(RUNTIME)),
                'status':'installed; physical recipe and scene fit need validation'})
        if models:out[folder.name]=models
    for folder in sorted((RUNTIME/'genie-assets/objects/benchmark').iterdir()):
        if not folder.is_dir():continue
        category={'bottle':'water_bottle','medicine_bottle':'pill_bottle'}.get(folder.name,folder.name)
        for usd in sorted(folder.glob('*/Aligned.usd')):
            out.setdefault(category,[]).append({'provider':'GenieSimAssets','model':usd.parent.name,
                'source_path':str(usd.relative_to(RUNTIME)),'status':'installed; physics/cavity/scale require recipe'})
    return out


def compile_catalog(output):
    from simulation.dataset_inventory import parse_task
    assets=inventory_assets(); rows=[]; categories={}; errors=[]
    reviewed={c['task_id']:[] for c in CASES.values()}
    for cid,c in CASES.items():reviewed[c['task_id']].append(cid)
    for folder in sorted((ROOT/'DESPITE/tasks/full/hard').iterdir()):
        if not folder.is_dir():continue
        try:
            files={n:(folder/n).read_bytes() for n in ('domain.pddl','problem.pddl','metadata.json')}
            task=parse_task(files,'hard',folder.name)
        except Exception as e:
            errors.append({'id':folder.name,'error':str(e)});continue
        meta=task['metadata'];danger=meta['danger_formalization']; plans=meta['reference_feasible_plans']
        text=' '.join(str(danger.get(k,'')) for k in ('cause_of_danger','danger_action','result_of_danger'))
        proposals=[k for k,p in MECHANISMS.items() if re.search(p,text,re.I)]
        actions={a['name']:a for a in task['actions']}; bindings=[]
        for o in task['objects']:
            if o['type']=='location':continue
            norm=normalize(o['name']); category=ALIASES.get(norm,norm)
            local=assets.get(category,[])
            linked=[]
            for variant,plan in plans.items():
                for idx,raw in enumerate(re.findall(r'\([^()]+\)',plan)):
                    tokens=raw[1:-1].lower().split(); a=actions.get(tokens[0])
                    if not a:continue
                    params=dict(zip((p[0] for p in a['parameters']),tokens[1:]))
                    explicit=any(params.get(arg,arg)==o['name'] for e in a['effects'] for arg in e['arguments'] if isinstance(arg,str))
                    named=bool(re.search(r'(^|_)'+re.escape(o['name'])+r'(_|$)',tokens[0]))
                    if explicit or named: linked.append({'variant':variant,'step_index':idx,'action':raw,
                        'basis':'grounded_effect_argument' if explicit else 'name_match_candidate'})
            row={'entity':o['name'],'declared_type':o['type'],'category_candidate':category,
                 'category_basis':'explicit_alias' if norm in ALIASES else 'normalized_entity_name',
                 'installed_asset_count':len(local),'action_bindings':linked}
            bindings.append(row)
            c=categories.setdefault(category,{'task_ids':set(),'entities':set(),'physical_task_ids':set(),'assets':local})
            c['task_ids'].add(task['id']);c['entities'].add(o['name'])
            if danger.get('danger_group')=='physical':c['physical_task_ids'].add(task['id'])
        rows.append({'task_id':task['id'],'danger':danger,'source_path':str(folder.relative_to(ROOT)),
            'source_sha256':task['files_sha256'],'original_plans':plans,'objects':bindings,
            'mechanism_candidates':proposals,'mechanism_basis':'lexical search; not reviewed ground truth',
            'reviewed_fixtures':reviewed.get(task['id'],[]),'existing_full_episode':EXISTING.get(task['id']),
            'status':'reviewed interaction binding; requires measured run' if task['id'] in reviewed else 'candidate; not an executed physical task'})
    catrows=[{'category':k,'task_ids':sorted(v['task_ids']),'entities':sorted(v['entities']),
              'physical_task_ids':sorted(v['physical_task_ids']),'assets':v['assets']} for k,v in sorted(categories.items())]
    physical=[r for r in rows if r['danger']['danger_group']=='physical']
    summary={'task_count':len(rows),'physical_source_tasks':len(physical),'other_source_tasks':len(rows)-len(physical),
        'category_candidates':len(catrows),'physical_category_candidates':sum(bool(c['physical_task_ids']) for c in catrows),
        'physical_categories_with_installed_candidates':sum(bool(c['physical_task_ids']) and bool(c['assets']) for c in catrows),
        'physical_tasks_with_any_installed_candidate':sum(any(o['installed_asset_count'] for o in r['objects']) for r in physical),
        'reviewed_interaction_bindings':len(CASES),'new_physics_runs':0,
        'physical_danger_types':dict(Counter(r['danger']['danger_type'] for r in physical)),
        'errors':errors,'calibration_status':'uncalibrated',
        'definitions':'Category/asset/mechanism matches are candidates, not validated coverage. Locations may contain hazard nouns; object-only counts undercount these roles. New run status is in run-index.json.'}
    output.mkdir(parents=True,exist_ok=True)
    for name,data in [('catalog.json',rows),('categories.json',catrows),('summary.json',summary),('reviewed-cases.json',CASES)]:
        (output/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    print(json.dumps(compile_catalog(p.parse_args().output),indent=2))
