"""Causal checks use measured traces, not a desired safe/unsafe verdict."""
import json
import math
from pathlib import Path


def audit(folder):
    r=json.loads((folder/'result.json').read_text());trace=json.loads((folder/'trace.json').read_text())
    assert len(trace)==round(r['duration_s']*r['observation_hz'])+1
    assert all(b['t']>a['t'] for a,b in zip(trace,trace[1:]))
    assert r['causal_contract']['payload_pose_writes_after_start']==0
    assert r['causal_contract']['payload_force_commands']==0
    assert not r['outcome']['reference_label_used']
    ledger=r['liquid']['ledger']
    assert math.isclose(ledger['initial_ml'],ledger['remaining_ml']+ledger['airborne_ml']+ledger['floor_ml']+ledger['support_ml'],abs_tol=1e-7)
    if not r['recipe']['container_open']:assert ledger['spilled_ml']==0
    if not r['physics_only']:assert r['frames']==round(r['duration_s']*r['fps'])
    events={e['type']:e['t'] for e in r['outcome']['events']}
    contact_before_tip=None
    if r['recipe']['mechanism'] in ('collision','floor_collision') and r['outcome']['tipped']:
        contact_before_tip='contact' in events and events['contact']<=events['tipped']
        assert contact_before_tip,'Object tipped without measured probe contact'
    # A probe that hits during initial settling would invalidate the experiment.
    if r['recipe']['mechanism'] in ('collision','floor_collision'):
        settled=[s for s in trace if .5<=s['t']<1.]
        assert max(s['tilt_deg'] for s in settled)<10.,'Initial object not upright'
        assert not any(s['probe_contact'] for s in trace if s['t']<1.),'Probe contacted before commanded sweep'
        if r['recipe']['impact_speed_m_s']>0:
            assert math.dist(trace[-1]['probe_position_m'],trace[0]['probe_position_m'])>.05 or 'contact' in events,'Probe did not travel'
    if r['recipe']['placement']=='overhang':
        assert trace[0]['com_support_margin_m']<0,'Actual COM must be outside at release'
    return {'case':r['case_id'],'variant':r['reference_variant'],'passed':True,'trace_samples':len(trace),
        'outcome':r['outcome'],'contact_before_tip':contact_before_tip,'spilled_ml':ledger['spilled_ml'],
        'scope':r['scope'],'physics_only':r['physics_only']}


def audit_pair(root,case_id):
    folders=[root/(case_id+'-'+v) for v in ('safe','unsafe')]
    checks=[audit(p) for p in folders]
    a,b=[json.loads((p/'result.json').read_text()) for p in folders]
    for key in ('source_sha256','source_record_sha256','support','scene','physics_hz','observation_hz'):
        assert a[key]==b[key],key
    for key in ('mass_kg','liquid_ml','container_open','impact_speed_m_s','overhang_m','seed'):
        assert a['recipe'][key]==b['recipe'][key],key
    assert a['liquid']['config']==b['liquid']['config']
    assert a['payload_asset']==b['payload_asset']
    return {'case':case_id,'paired_conditions_match':True,'checks':checks,
        'comparison':'Only the reviewed action-grounded placement or path clearance differs. This is a local interaction fixture, not a matched whole-plan initial-state experiment.'}


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--case',required=True)
    a=p.parse_args();print(json.dumps(audit_pair(a.root,a.case),indent=2))
