"""An explicitly uncapped visual derivative of the original bottle mesh.

The original bottle's rigid collision envelope is retained. Liquid uses the
separately declared reduced-order cavity/nozzle, not this convex envelope.
"""
from pathlib import Path
import hashlib
import numpy as np


def open_bottle(path, half_height):
    from pxr import Usd, UsdGeom, Sdf, UsdShade
    signature=hashlib.sha256(Path(path).read_bytes()+Path(__file__).read_bytes()).hexdigest()[:12]
    output=Path(path).with_name('open-bottle-'+signature+'.usda')
    stage=Usd.Stage.Open(str(path))
    cutoff=half_height-.012
    count=0
    for prim in list(stage.Traverse()):
        if '/visuals/' not in str(prim.GetPath()) or not prim.IsA(UsdGeom.Mesh):continue
        mesh=UsdGeom.Mesh(prim);points=np.asarray(mesh.GetPointsAttr().Get(),float)
        if points[:,2].max()<=cutoff:continue
        sizes=mesh.GetFaceVertexCountsAttr().Get();indices=np.asarray(mesh.GetFaceVertexIndicesAttr().Get())
        st=UsdGeom.PrimvarsAPI(mesh).GetPrimvar('st');uv=np.asarray(st.ComputeFlattened(),float) if st else None
        normals=np.asarray(mesh.GetNormalsAttr().Get(),float) if mesh.GetNormalsAttr().Get() else None
        ninterp=mesh.GetNormalsInterpolation();uvinterp=st.GetInterpolation() if st else None
        def channel(values,interp,vertex,corner):
            if values is None:return []
            return values[corner if interp=='faceVarying' else vertex].tolist()
        vertices=[];out_uv=[];out_norm=[];offset=0
        for size in sizes:
            polygon=[]
            for j in range(size):
                vi=indices[offset+j]
                polygon.append(np.asarray([*points[vi],*channel(normals,ninterp,vi,offset+j),*channel(uv,uvinterp,vi,offset+j)]))
            offset+=size;clipped=[]
            for a,b in zip(polygon,polygon[1:]+polygon[:1]):
                ain=a[2]<=cutoff;bin=b[2]<=cutoff
                if ain:clipped.append(a)
                if ain!=bin:clipped.append(a+(b-a)*(cutoff-a[2])/(b[2]-a[2]))
            for j in range(1,len(clipped)-1):
                for v in (clipped[0],clipped[j],clipped[j+1]):
                    vertices.append(v[:3].tolist());k=3
                    if normals is not None:
                        n=v[k:k+3];out_norm.append((n/max(np.linalg.norm(n),1e-12)).tolist());k+=3
                    if uv is not None:out_uv.append(v[k:k+2].tolist())
        mesh.GetPointsAttr().Set(vertices)
        mesh.GetFaceVertexCountsAttr().Set([3]*(len(vertices)//3))
        mesh.GetFaceVertexIndicesAttr().Set(list(range(len(vertices))))
        if out_norm:mesh.GetNormalsAttr().Set(out_norm);mesh.SetNormalsInterpolation('faceVarying')
        if out_uv:
            st.Set(out_uv);st.SetInterpolation('faceVarying')
            if st.IsIndexed():st.BlockIndices()
        mesh.CreateDoubleSidedAttr(True);count+=1
    if not count:raise ValueError('No top-of-bottle visual mesh found')
    stage.GetDefaultPrim().SetCustomDataByKey('despiteOpenContainer',True)
    stage.GetDefaultPrim().SetCustomDataByKey('despiteOpenContainerModel','Visual cap removed; explicit reduced-order nozzle; original rigid collision envelope retained')
    stage.GetRootLayer().Export(str(output))
    return str(output)
