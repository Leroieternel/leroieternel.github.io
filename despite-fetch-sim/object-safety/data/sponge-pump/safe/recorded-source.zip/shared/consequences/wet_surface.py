"""Optical wetting beneath the volume-conserving film; no physics changes."""
import numpy as np


class WetSubstrate:
    def __init__(self, film, floor_path='/World/NativeRoom/background/home_b/part_05/part_05'):
        import omnigibson as og
        from pxr import Usd,UsdGeom,UsdShade,Gf,Sdf
        self.film=film;floor=UsdGeom.Mesh(og.sim.stage.GetPrimAtPath(floor_path))
        if not floor:raise ValueError('The wetting adapter requires a declared native wood floor')
        matrix=UsdGeom.Xformable(floor.GetPrim()).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
        points=np.array([matrix.Transform(Gf.Vec3d(*p)) for p in floor.GetPointsAttr().Get()])
        indices=np.array(floor.GetFaceVertexIndicesAttr().Get())
        uv=np.array(UsdGeom.PrimvarsAPI(floor.GetPrim()).GetPrimvar('st').ComputeFlattened())
        design=np.c_[points[indices,:2],np.ones(len(indices))]
        self.uv_map=np.linalg.lstsq(design,uv,rcond=None)[0]
        residual=float(np.max(np.abs(design@self.uv_map-uv)))
        if residual>1e-4:raise ValueError('Floor UVs are not affine; an explicit mesh UV projection is required')
        original=UsdShade.MaterialBindingAPI(floor.GetPrim()).ComputeBoundMaterial()[0]
        shader=next(UsdShade.Shader(p) for p in Usd.PrimRange(original.GetPrim()) if p.IsA(UsdShade.Shader))
        prefix='/World/DeclaredConsequenceWetFloor'
        with og.sim.editing_usd():
            material=UsdShade.Material.Define(og.sim.stage,prefix+'/Material')
            copied=UsdShade.Shader.Define(og.sim.stage,prefix+'/Material/Shader')
            copied.SetSourceAsset(Sdf.AssetPath('OmniPBR.mdl'),'mdl');copied.SetSourceAssetSubIdentifier('OmniPBR','mdl')
            copied.CreateOutput('out',Sdf.ValueTypeNames.Token)
            for item in shader.GetInputs():
                value=item.Get()
                if value is None:continue
                if item.GetTypeName()==Sdf.ValueTypeNames.Asset:value=Sdf.AssetPath(value.resolvedPath or value.path)
                copied.CreateInput(item.GetBaseName(),item.GetTypeName()).Set(value)
            # A declared optical approximation of wet wood. This does not add
            # water, enlarge its footprint, or change contact friction.
            copied.CreateInput('albedo_brightness',Sdf.ValueTypeNames.Float).Set(.68)
            copied.CreateInput('reflection_roughness_constant',Sdf.ValueTypeNames.Float).Set(.055)
            copied.CreateInput('reflection_roughness_texture_influence',Sdf.ValueTypeNames.Float).Set(0.)
            material.CreateSurfaceOutput('mdl').ConnectToSource(copied.ConnectableAPI(),'out')
            self.mesh=UsdGeom.Mesh.Define(og.sim.stage,prefix+'/Substrate')
            self.mesh.CreateSubdivisionSchemeAttr('none');self.mesh.CreateDoubleSidedAttr(True)
            UsdShade.MaterialBindingAPI.Apply(self.mesh.GetPrim()).Bind(material)
            self.st=UsdGeom.PrimvarsAPI(self.mesh.GetPrim()).CreatePrimvar('st',Sdf.ValueTypeNames.TexCoord2fArray,UsdGeom.Tokens.vertex)
            UsdGeom.PrimvarsAPI(self.mesh.GetPrim()).CreatePrimvar('doNotCastShadows',Sdf.ValueTypeNames.Bool).Set(True)
        self.info={'kind':'optical_wet_wood_approximation','source_floor':floor_path,
                   'original_texture_and_uv_preserved':True,'uv_fit_max_error':residual,
                   'albedo_multiplier':.68,'roughness':.055,'footprint':'linearly interpolated modeled film surface',
                   'changes_volume_or_friction':False,'calibration_status':'uncalibrated'}

    def update(self, surface):
        import omnigibson as og
        from pxr import Vt
        points=surface.film_mesh.GetPointsAttr().Get()
        if points is None or not len(points):return
        # LiquidSurface stores the top vertices followed by the bottom copy.
        n=len(points)//2;v=np.asarray(points,dtype=np.float32)[:n].copy()
        triangles=np.asarray(surface.film_mesh.GetFaceVertexIndicesAttr().Get(),dtype=np.int32).reshape(-1,3)
        triangles=triangles[np.all(triangles<n,axis=1)]
        v[:,2]=self.film.cfg['floor_z_m']+.00002
        uv=np.c_[v[:,:2],np.ones(n)]@self.uv_map
        with og.sim.editing_usd():
            self.mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(v))
            self.mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(triangles.ravel()))
            self.mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(np.full(len(triangles),3,np.int32)))
            self.mesh.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(np.tile([0.,0.,1.],(n,1)).astype(np.float32)))
            self.mesh.SetNormalsInterpolation('vertex');self.st.Set(Vt.Vec2fArray.FromNumpy(uv.astype(np.float32)))
            self.mesh.CreateExtentAttr([v.min(0).tolist(),v.max(0).tolist()])
