"""Post-process native fixture traces into explicitly sourced predicates.

This projection never changes a simulation or reads the reference label.
Rigid-body observations and reduced-order liquid estimates remain separate.
"""
import hashlib
from pathlib import Path


def project(result, trace):
    last={};changes=[];stable_since=None
    thresholds={'upright_deg':15.,'tipped_deg':45.,'settled_speed_m_s':.02,
                'settled_angular_speed_rad_s':.15,'stable_dwell_s':.5,'spill_ml':1.}
    initial_volume=result['recipe']['liquid_ml']
    for sample in trace:
        t=sample['t']
        settled=(sample['support_contact'] and sample['tilt_deg']<thresholds['upright_deg']
                 and sample['speed_m_s']<thresholds['settled_speed_m_s']
                 and sample['angular_speed_rad_s']<thresholds['settled_angular_speed_rad_s'])
        stable_since=(t if stable_since is None else stable_since) if settled else None
        values={
            'upright':(sample['tilt_deg']<thresholds['upright_deg'],'rigid_pose','tilt_deg'),
            'tipped':(sample['tilt_deg']>=thresholds['tipped_deg'],'rigid_pose','tilt_deg'),
            'touching_target_support':(sample['support_contact'],'support_observation','support_contact'),
            'settled_on_target_support':(stable_since is not None and t-stable_since>=thresholds['stable_dwell_s'],
                                         'contact_pose_velocity_dwell','support_contact + tilt + velocity'),
            'probe_contact':(sample['probe_contact'],'PhysX_contact','probe_contact'),
        }
        if result['recipe']['mechanism']!='floor_collision':
            values['com_over_target_support']=(sample['com_support_margin_m']>=0,'derived_support_geometry','com_support_margin_m')
            values['footprint_inside_target_support']=(sample['footprint_margin_m']>=0,'projected_AABB_geometry','footprint_margin_m')
        if initial_volume:
            values['container_open']=(result['recipe']['container_open'],'declared_condition','recipe.container_open')
            values['liquid_escaped']=(sample['modeled_spilled_ml']>=thresholds['spill_ml'],'reduced_order_liquid','modeled_spilled_ml')
            values['liquid_on_floor']=(sample['modeled_floor_ml']>=thresholds['spill_ml'],'reduced_order_liquid','modeled_floor_ml')
            values['liquid_inventory_depleted']=(initial_volume-sample['modeled_spilled_ml']<=.001,'reduced_order_liquid','initial inventory - modeled spill')
        current={k:{'value':v,'basis':basis,'source':source,'calibration_status':'uncalibrated'} for k,(v,basis,source) in values.items()}
        for predicate,reading in current.items():
            if predicate not in last or last[predicate]['value']!=reading['value']:
                changes.append({'t':t,'object':'payload','predicate':predicate,
                    'before':last.get(predicate,{}).get('value'),'after':reading['value'],
                    'initialization':predicate not in last,'basis':reading['basis'],'source':reading['source']})
        last=current
    return {'scope':'post-processing of the recorded local interaction; no new physics',
        'projection_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'reference_label_used':False,'thresholds':thresholds,'final_predicates':last,'transitions':changes,
        'notes':['Positive centre-of-mass margin alone does not establish stability.',
                 'Liquid predicates are reduced-order model estimates, not PhysX fluid measurements.',
                 'Floor-case support observation is a near-floor geometry proxy; table support uses Touching.',
                 'Grasp, temperature, human injury and seal failure are not observed by this local fixture.']}
