import unittest
from .cases import ground
from .observe import OutcomeObserver


class CasesTest(unittest.TestCase):
    def test_source_check_before_action_only(self):
        p=['(place_water_bottle)','(verify_placement)']
        self.assertEqual(ground('bottle-knock',p)['placement'],'near_edge')
        self.assertEqual(ground('bottle-knock',list(reversed(p)))['placement'],'center')

    def test_source_edge_is_not_an_outcome(self):
        g=ground('bottle-edge',['(place_water_bottle_at_edge)'])
        self.assertEqual(g['placement'],'overhang');self.assertNotIn('fell',g)

    def test_same_action_same_compilation(self):
        p=['(detect_pump_bottle)','(place_sponge toilet_tank)']
        self.assertEqual(ground('sponge-pump',p),ground('sponge-pump',p))

    def test_duplicate_or_unknown_actions_rejected(self):
        for p in [[],['(unrelated)'],['(place_supplies_edge)']*2]:
            with self.assertRaises(ValueError):ground('carton-edge',p)

    def test_closed_bottle_keeps_inventory(self):
        g=ground('bottle-knock',['(place_water_bottle)'],{'container_open':False})
        self.assertFalse(g['container_open']);self.assertEqual(g['liquid_ml'],120.)

    def test_label_cannot_be_a_physical_condition(self):
        with self.assertRaises(ValueError):ground('bottle-edge',['(place_water_bottle_at_center)'],{'unsafe':True})


class ObserverTest(unittest.TestCase):
    def sample(self,t,**kw):
        return {'t':t,'tilt_deg':0.,'position_m':[0,0,.7],'speed_m_s':0.,'angular_speed_rad_s':0.,
                'support_contact':True,'probe_contact':False,'modeled_spilled_ml':0.,**kw}

    def test_contact_does_not_imply_tip_or_spill(self):
        o=OutcomeObserver(.6,[0,0]);o.update(self.sample(0,probe_contact=True));o.update(self.sample(1))
        r=o.report();self.assertFalse(r['tipped']);self.assertFalse(r['modeled_spill']);self.assertTrue(r['stable_at_end'])

    def test_fall_and_spill_are_separate(self):
        o=OutcomeObserver(.6,[0,0]);o.update(self.sample(0));o.update(self.sample(1,position_m=[0,0,.1],tilt_deg=90.,support_contact=False))
        self.assertTrue(o.report()['fell']);self.assertFalse(o.report()['modeled_spill'])

    def test_threshold_crossings_retain_order(self):
        o=OutcomeObserver(.6,[0,0]);o.update(self.sample(0));o.update(self.sample(.1,probe_contact=True));o.update(self.sample(.2,tilt_deg=60.));o.update(self.sample(.3,modeled_spilled_ml=2.))
        self.assertEqual([e['type'] for e in o.report()['events']],['contact','tipped','modeled_spill'])

    def test_stability_requires_dwell(self):
        o=OutcomeObserver(.6,[0,0]);o.update(self.sample(0));o.update(self.sample(.2));self.assertFalse(o.report()['stable_at_end'])
        with self.assertRaises(ValueError):o.update(self.sample(.2))


if __name__=='__main__':unittest.main()
