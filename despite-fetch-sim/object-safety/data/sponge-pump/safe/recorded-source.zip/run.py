"""Native Isaac/OmniGibson object-interaction fixtures in the existing Genie room.

This is an interaction test, not a fabricated whole Fetch-plan rollout. A
dynamic, gravity-compensated probe supplies a declared initial velocity.
No object pose or force is written after initialization. Liquid is explicitly
the existing reduced-order conservative model, not measured PBD liquid.
"""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import shutil

from simulation.runtime import ROOT, configure
from .cases import CASES, ground
from .observe import OutcomeObserver


def run(case_id, variant, output, *, physics_only=False, condition=None, asset_id=None):
    import re
    case=CASES[case_id]
    source=ROOT/'DESPITE/tasks/full/hard'/case['task_id']
    metadata=json.loads((source/'metadata.json').read_text())
    plan=re.findall(r'\([^()]+\)',metadata['reference_feasible_plans'][variant])
    recipe=ground(case_id,plan,condition)
    output.mkdir(parents=True,exist_ok=False)
    (output/'source').mkdir()
    sources={}
    for p in sorted(Path(__file__).parent.glob('*.py')):
        sources[p.name]=hashlib.sha256(p.read_bytes()).hexdigest();shutil.copy2(p,output/'source'/p.name)
    shared=['runtime.py','scenes.py','genie_scene.py','rendering.py','liquid_surface.py','liquid_film.py',
            'consequences/model.py','consequences/assets.py','consequences/wet_surface.py']
    shared += [str(p.relative_to(ROOT/'simulation')) for p in sorted((ROOT/'simulation/object_models').glob('*')) if p.suffix in ('.py','.json')]
    for name in shared:
        p=ROOT/'simulation'/name;dest=output/'source/shared'/name;dest.parent.mkdir(parents=True,exist_ok=True)
        sources['shared/'+name]=hashlib.sha256(p.read_bytes()).hexdigest();shutil.copy2(p,dest)
    for name in ('metadata.json','domain.pddl','problem.pddl'):
        shutil.copy2(source/name,output/'source'/name)
    configure()
    import numpy as np
    import torch
    import imageio.v2 as imageio
    from scipy.spatial.transform import Rotation
    import omnigibson as og
    from omnigibson.macros import gm
    from omnigibson.object_states import Touching
    gm.USE_GPU_DYNAMICS=False;gm.ENABLE_TRANSITION_RULES=False;gm.ENABLE_CCD=True
    og.launch(physics_dt=1/240,rendering_dt=1/60,sim_step_dt=1/60,viewer_width=1440,viewer_height=960)
    from simulation.genie_scene import native_spec, native_config, finish_native_scene
    from simulation.scenes import make_config
    spec=native_spec('neiss_2888')
    kind=recipe['kind'];spec['object_kind']='water' if kind=='footstool' else kind
    if asset_id:
        if kind not in ('water','carton'):raise ValueError('This fixture has no reviewed interchangeable asset contract')
        from simulation.object_models.assets import bind
        bind(spec,policy='scene',seed=recipe['seed'],asset_id=asset_id,scene_key=case['task_id'])
    config=native_config(make_config('neiss_2888','physical'),spec)
    config['robots']=[]
    config['env'].update(physics_frequency=240,action_frequency=60,rendering_frequency=60)
    payload=next(o for o in config['objects'] if o['name']==spec['object'])
    category=recipe['category'];floor_case=recipe['mechanism']=='floor_collision'
    dims=[spec['object_radius']*2,spec['object_radius']*2,spec['half_height']*2]
    if floor_case:
        payload.clear();payload.update(type='DatasetObject',name=spec['object'],category='footstool',model='sghekm',
            bounding_box=[.36,.28,.34],fixed_base=False)
        spec['support_top']=0.;spec['half_height']=.17;spec['support_center']=[.65,1.25];spec['support_half']=[1.,1.]
        spec['object_radius']=.18;dims=[.36,.28,.34]
    if recipe['container_open'] and kind=='water':
        from simulation.consequences.assets import open_bottle
        payload['usd_path']=open_bottle(payload['usd_path'],spec['half_height'])
    center=np.array(spec['support_center'],float);half=np.array(spec['support_half'],float)
    top=spec['support_top'];front=center[1]-half[1]
    p=np.array([*center,top+spec['half_height']+.002])
    if recipe['placement']=='overhang':p[1]=front-recipe['overhang_m']
    elif recipe['placement']=='near_edge':p[1]=front+spec['object_radius']+.008
    payload['position']=p.tolist()
    probe_cfg=None;probe_path=None
    if recipe['mechanism'] in ('collision','floor_collision'):
        # The same speed and path family are shared. Placement/clearance comes
        # from the reviewed source actions. The probe has a visible geometry.
        probe_x=center[0]+recipe.get('sweep_clearance',0.)
        probe_start=np.array([probe_x,front+.21,top+spec['half_height']*1.6])
        if kind=='footstool':probe_start=np.array([probe_x,center[1]+.65,.20])
        if case_id=='sponge-pump':
            probe_cfg=dict(type='DatasetObject',name='contact_probe',category='sponge',model='aewrov',
                bounding_box=[.105,.070,.021],fixed_base=False,position=probe_start.tolist())
        else:
            probe_cfg=dict(type='PrimitiveObject',name='contact_probe',primitive_type='Sphere',radius=.035 if not floor_case else .16,
                fixed_base=False,position=probe_start.tolist(),rgba=[.80,.24,.075,1.])
        config['objects'].append(probe_cfg)
    env=og.Environment(configs=config)
    assert abs(og.sim.get_sim_step_dt()-1/60)<1e-8, 'Unexpected simulator time step'
    scene_info=finish_native_scene(env,spec)
    from simulation.rendering import configure_capture,settle_capture
    render_info=configure_capture()
    obj=env.scene.object_registry('name',spec['object']);obj.root_link.mass=recipe['mass_kg']
    for link in obj.links.values():link.set_contact_offset(.001);link.set_rest_offset(0.)
    support=env.scene.object_registry('name',spec['support'])
    probe=env.scene.object_registry('name','contact_probe') if probe_cfg else None
    if probe:
        probe.root_link.mass=5. if floor_case else .35
        probe.root_link.disable_gravity()
    from pxr import PhysxSchema,PhysicsSchemaTools
    from omni.physx import get_physx_simulation_interface
    contacts=set()
    with og.sim.editing_usd():
        for link in obj.links.values():PhysxSchema.PhysxContactReportAPI.Apply(link.prim).CreateThresholdAttr(0.)
    def on_contact(headers,data):
        for h in headers:
            if h.num_contact_data:
                paths=tuple(str(PhysicsSchemaTools.intToSdfPath(x)) for x in (h.collider0,h.collider1))
                if any(obj.prim_path+'/' in x or (probe and probe.prim_path+'/' in x) for x in paths):contacts.add(paths)
    subscription=get_physx_simulation_interface().subscribe_contact_report_events(on_contact)
    camera=og.sim.viewer_camera
    eye=np.array([center[0]+.95,center[1]-1.55,top+1.05]);target=np.array([center[0],center[1]-.19,top*.65])
    if floor_case:eye=np.array([-.30,-.25,1.60]);target=np.array([.65,1.20,.10])
    z=(eye-target)/np.linalg.norm(eye-target);x=np.cross([0,0,1],z);x/=np.linalg.norm(x);y=np.cross(z,x)
    camera.focal_length=21.
    camera.set_position_orientation(position=torch.tensor(eye,dtype=torch.float32),orientation=torch.tensor(Rotation.from_matrix(np.column_stack([x,y,z])).as_quat(),dtype=torch.float32))
    from simulation.consequences.model import EdgeConfig,SpillLedger,support_projection_margin
    fluid_config=EdgeConfig(container_open=recipe['container_open'],initial_liquid_ml=recipe['liquid_ml'],seed=recipe['seed'])
    ledger=SpillLedger(fluid_config,spec['half_height'],spec['object_radius'],center,half,top)
    surface=table_surface=wet_surface=None;film=table_film=None
    if recipe['liquid_ml']:
        from simulation.liquid_film import FloorFilm
        film=FloorFilm(ledger.n,ledger.volume_ml,bounds=[center[0]-1.2,center[0]+1.2,center[1]-1.5,center[1]+.8],
            config={'cell_size_m':.004,'coupling':'one-way modeled ballistic parcels'})
        table_film=FloorFilm(ledger.n,ledger.volume_ml,bounds=[center[0]-half[0],center[0]+half[0],front,center[1]+half[1]],
            config={'cell_size_m':.004,'floor_z_m':top,'coupling':'one-way modeled ballistic parcels'})
        if not physics_only:
            from simulation.liquid_surface import LiquidSurface
            from simulation.consequences.wet_surface import WetSubstrate
            with og.sim.editing_usd():
                surface=LiquidSurface(None,prefix='/World/ObjectTestLiquid',liquid_tint=(.55,.82,.95),film_subdivision=2);surface.film=film
                table_surface=LiquidSurface(None,prefix='/World/ObjectTestTableLiquid');table_surface.film=table_film
            wet_surface=WetSubstrate(film)
    from simulation.object_models import World,compose
    profile={'pump_bottle':'water_bottle','footstool':'chair'}.get(category,category)
    world=World({'payload':compose(profile)})
    state_file=(output/'object-states.jsonl').open('w')
    observer=OutcomeObserver(top,p[:2].tolist(),floor_case)
    duration=7.;hz=60;fps=30;trace=[];frames=0
    writer=None
    if not physics_only:
        writer=imageio.get_writer(str(output/'episode.mp4'),fps=fps,codec='libx264',quality=None,macro_block_size=16,
            ffmpeg_params=['-crf','16','-movflags','+faststart'])
    def arr(v):return v.detach().cpu().numpy()
    def capture():
        nonlocal frames
        if surface:
            surface.update(ledger.positions,hide_particles=(ledger.state==0)|(ledger.state==3))
            table_surface.update(ledger.positions,hide_particles=np.ones(ledger.n,bool));wet_surface.update(surface)
        og.sim.render();settle_capture()
        rgb=arr(camera.get_obs()[0]['rgb'])[...,:3].astype(np.uint8);writer.append_data(rgb)
        if frames==0:imageio.imwrite(output/'poster.jpg',rgb)
        if frames%15==0:
            folder=output/'checks';folder.mkdir(exist_ok=True);imageio.imwrite(folder/f'{frames:04d}.jpg',rgb)
        frames+=1
        return rgb
    for _ in range(16 if writer else 0):og.sim.render()
    initial=None
    for tick in range(round(duration*hz)+1):
        t=tick/hz
        if tick:
            contacts.clear()
            if probe and tick==hz:
                probe.root_link.set_linear_velocity(torch.tensor([0.,-recipe['impact_speed_m_s'],0.],dtype=torch.float32))
            with og.sim.render_on_step(False):og.sim.step()
        pos,quat=[arr(v) for v in obj.root_link.get_position_orientation()]
        vel=arr(obj.root_link.get_linear_velocity());omega=arr(obj.root_link.get_angular_velocity())
        com=pos+Rotation.from_quat(quat).apply(arr(obj.root_link.center_of_mass))
        tilt=float(np.degrees(np.arccos(np.clip(Rotation.from_quat(quat).as_matrix()[2,2],-1,1))))
        liquid=ledger.advance(t,pos,quat,vel,omega)
        if film:
            film.update(ledger.positions,np.flatnonzero(ledger.state==2),t)
            table_film.update(ledger.positions,np.flatnonzero(ledger.state==3),t)
        probe_contact=bool(probe and any(any(probe.prim_path+'/' in s for s in pair) and any(obj.prim_path+'/' in s for s in pair) for pair in contacts))
        support_contact=bool(obj.states[Touching].get_value(support)) if not floor_case else float(obj.aabb[0][2])<.008
        bounds=[arr(v) for v in obj.aabb]
        footprint_margin=float(min(np.min(center+half-bounds[1][:2]),np.min(bounds[0][:2]-(center-half))))
        sample={'t':round(t,6),'position_m':pos.tolist(),'quaternion_xyzw':quat.tolist(),'center_of_mass_world_m':com.tolist(),
            'com_support_margin_m':support_projection_margin(com,center,half),'tilt_deg':tilt,
            'aabb_m':[v.tolist() for v in bounds],'footprint_margin_m':footprint_margin,
            'linear_velocity_m_s':vel.tolist(),'angular_velocity_rad_s':omega.tolist(),
            'speed_m_s':float(np.linalg.norm(vel)),'angular_speed_rad_s':float(np.linalg.norm(omega)),
            'support_contact':support_contact,'probe_contact':probe_contact,'contacts':[list(x) for x in sorted(contacts)],
            'modeled_spilled_ml':liquid['spilled_ml'],'modeled_floor_ml':liquid['floor_ml'],
            'probe_position_m':arr(probe.get_position_orientation()[0]).tolist() if probe else None}
        if initial is None:initial=sample
        observer.update(sample);trace.append(sample)
        observed=world.step(t,{'payload':{'position_m':pos.tolist(),'quaternion_xyzw':quat.tolist(),
            'linear_velocity_m_s':vel.tolist(),'angular_velocity_rad_s':omega.tolist(),'mass_kg':recipe['mass_kg'],
            'tilt_deg':tilt,'support_contact':support_contact,'support_height_error_m':float(pos[2]-spec['half_height']-top),
            'edge_margin_m':footprint_margin,'contact':probe_contact}})
        state_file.write(json.dumps(observed,allow_nan=False,separators=(',',':'))+'\n')
        if writer and tick%2==0 and tick<round(duration*hz):last_rgb=capture()
        if tick%60==0:
            (output/'progress.json').write_text(json.dumps(sample,indent=2))
            print('OBJECT_FRAME',case_id,variant,t,round(tilt,1),round(liquid['spilled_ml'],1),flush=True)
    if writer:writer.close();imageio.imwrite(output/'final.jpg',last_rgb)
    state_file.close()
    import importlib.metadata
    versions={}
    for package in ('isaacsim','omnigibson','numpy','scipy'):
        try:versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:versions[package]='unavailable'
    report={'revision':'object-consequences-v1','software':versions,'case_id':case_id,'source_task_id':case['task_id'],'reference_variant':variant,
        'scope':'object interaction fixture; preceding and subsequent plan actions are not executed',
        'original_plan':plan,'tested_action':recipe['action'],'tested_action_index':recipe['action_index'],
        'recipe':recipe,'duration_s':duration,'fps':fps,'frames':frames,'physics_hz':240,'observation_hz':hz,
        'physics_only':physics_only,'outcome':observer.report(),'initial_state':initial,'final_state':trace[-1],
        'liquid':{'basis':'reduced_order_model_not_PBD','config':asdict(fluid_config),'ledger':ledger.snapshot()},
        'support':{'center_m':center.tolist(),'half_extents_m':half.tolist(),'top_m':top},
        'scene':scene_info,'render':render_info,'camera':{'eye_m':eye.tolist(),'target_m':target.tolist(),'focal_mm':21.},
        'payload_asset':{k:v for k,v in payload.items() if k not in ('position',)},'source_sha256':sources,
        'source_record_sha256':{n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in ('metadata.json','domain.pddl','problem.pddl')},
        'causal_contract':{'dynamic_test_object':True,'payload_pose_writes_after_start':0,'payload_force_commands':0,
            'probe':{'model':'dynamic gravity-compensated impactor; one initial velocity command at 1 s',
                     'mass_kg':5. if floor_case else .35,'initial_velocity_m_s':[0.,-recipe['impact_speed_m_s'],0.],
                     'pose_writes_after_start':0} if probe else None,'outcome_reads_reference_label':False},
        'limitations':[recipe['source_scope'],'Uncalibrated mass, friction, support and contact path.',
            'A source unsafe label is not an observed failure. Outcomes come from contacts and states.',
            'Liquid emission/film is one-way reduced-order; no coupled fluid mass, seal failure, fracture, human falls or injuries.']}
    (output/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    (output/'trace.json').write_text(json.dumps(trace,allow_nan=False,separators=(',',':'))+'\n')
    (output/'object-models.json').write_text(json.dumps(world.report(),indent=2,allow_nan=False)+'\n')
    print('OBJECT_DONE',case_id,variant,json.dumps(report['outcome']),flush=True)
    og.shutdown()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--case',choices=CASES,required=True);p.add_argument('--variant',choices=['safe','unsafe'],required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--physics-only',action='store_true');p.add_argument('--condition',type=Path);p.add_argument('--asset-id')
    a=p.parse_args();run(a.case,a.variant,a.output,physics_only=a.physics_only,condition=json.loads(a.condition.read_text()) if a.condition else None,asset_id=a.asset_id)
