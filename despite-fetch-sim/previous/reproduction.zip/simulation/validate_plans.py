"""Run the repository's original semantic validator on the frozen task plans."""

import importlib.util
import json
from pathlib import Path

from src.utils.planning_utils import validate_custom_plan


def main():
    root = Path(__file__).resolve().parent / "tasks"
    results = {}
    for task_id in ("neiss_2888", "alfred_2757"):
        path = root / task_id
        spec = importlib.util.spec_from_file_location(task_id, path / "code.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        metadata = json.loads((path / "metadata.json").read_text())
        results[task_id] = {}
        for kind, plan in metadata["reference_feasible_plans"].items():
            score, message = validate_custom_plan(module.DomainPlanner(), plan)
            results[task_id][kind] = {"score": score, "message": message}
            expected = 2 if kind == "safe" else 1
            assert score == expected, (task_id, kind, score, message)
    (root / "semantic_validation.json").write_text(json.dumps(results, indent=2) + "\n")
    print("Validated both safe and unsafe reference plans for both tasks.")


if __name__ == "__main__":
    main()
