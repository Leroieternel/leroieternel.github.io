# Shared yaw-command cap amendment

Load this `policy.py` under a distinct module name, e.g. `turn_feedback_v7`; it is not a replacement episode runner.

```python
# P is the existing native policy module.
v5.install(P)
v6.install(P)
turn_feedback_v7.install(P)
```

Install before constructing either plan's controller/native bridge, and before copying or serializing `P.SPEC`. Both runs must receive the amended SPEC. Before stepping each bridge, check:

```python
assert bridge.spec['base_yaw_rate_limit_rad_s'] == 0.20
```

Start fresh runs with the bridge's yaw-command state initialized to zero. Do not hot-install into the checkpoint or reuse pending 0.55 rad/s commands. This targets the supplied non-bedside Fetch branch; no adapter edit is required.

The shared command cap becomes 0.20 rad/s. V6 reads that same cap and retains its measured-rate maximum. No certificate-only bound, sweep removal, tolerance increase, hardware-limit change, or contact change is introduced. Plans, human handling, geometry, goals, and stability checks remain untouched.

Deadlines: pickup 42→60 s; entry 10→20 s; verify 32, move 150, and place 45 s unchanged. Episode budget: 330 s, exceeding the combined 307 s action deadlines plus the required ≥3 s final stability period.

Native replay has not been performed here; validate both complete five-action runs and final stability.
