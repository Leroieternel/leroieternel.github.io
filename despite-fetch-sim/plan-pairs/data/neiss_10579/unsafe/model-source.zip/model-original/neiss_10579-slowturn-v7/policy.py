"""Install after v5/v6, BEFORE creating controllers or native bridges.
Fresh runs only: do not lower the bound around pending higher-rate commands.
"""

PATCH_SPEC = {
    'id': 'turn-feedback-v7-shared-yaw-cap',
    'entrypoint': 'install(existing_native_policy_module)',
    'requires': 'neiss_10579-receding-turn-v6',
    'startup_only': True,
    'base_yaw_rate_limit_rad_s': 0.20,
    'episode_seconds': 330.0,
    'deadline_remap_s': {42.0: 60.0, 10.0: 20.0},
    'validation': 'native replay required',
}


def install(P):
    """Amend shared SPEC in place; leave every controller method unchanged."""
    if getattr(P, '_neiss_shared_yaw_cap_v7', False):
        return PATCH_SPEC
    if not (getattr(P, '_neiss_coherent_navigation_v5', False)
            and getattr(P, '_neiss_receding_turn_v6', False)):
        raise RuntimeError('Install the supplied v5 and v6 first')

    spec = P.SPEC
    deadlines = spec['action_deadlines_s']
    if float(spec['base_yaw_rate_limit_rad_s']) != 0.55:
        raise RuntimeError('Expected the supplied shared 0.55 rad/s command cap')
    # Preserve actual action keys rather than guessing undisclosed names.
    if sorted(float(v) for v in deadlines.values()) != [10., 32., 42., 45., 150.]:
        raise RuntimeError('Unexpected action deadlines; refusing an ambiguous amendment')
    remap = PATCH_SPEC['deadline_remap_s']
    amended = {name: remap.get(float(v), float(v))
               for name, v in deadlines.items()}
    if sum(amended.values()) + 3.0 > PATCH_SPEC['episode_seconds']:
        raise RuntimeError('Episode budget must include final stability time')

    # The native bridge clamps its yaw target using this SAME shared key.
    # Its existing slew remains bounded when initialized at zero. V6 already
    # takes max(this cap, measured yaw rate); no certificate edit is needed.
    spec['base_yaw_rate_limit_rad_s'] = PATCH_SPEC['base_yaw_rate_limit_rad_s']
    deadlines.update(amended)
    spec['episode_seconds'] = PATCH_SPEC['episode_seconds']
    P._neiss_shared_yaw_cap_v7 = True
    return PATCH_SPEC
