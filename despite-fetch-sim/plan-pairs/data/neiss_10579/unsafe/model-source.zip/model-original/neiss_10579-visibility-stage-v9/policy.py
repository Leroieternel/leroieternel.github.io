"""Install one candidate staging-goal override into the already-loaded native P.

This module does not replace the planner, command writer, or safety checks.
"""
from functools import wraps

# Map-frame base pose: x metres, y metres, yaw radians.
# Intermediate LOW-carry side-lane staging, NOT the delivery goal.
STAGING_GOAL = (2.40, -1.20, 0.0)


def install(P, *, sensors_enabled, active_action):
    """Patch P once, before running controllers; return the same native module.

    Required read-only bindings, both called as (controller, observation):
      sensors_enabled: the existing native sensor-enable flag, as a bool.
      active_action: the existing active action's canonical name.
    Bind actual native state, not variant labels or inferred sensor availability.
    """
    if not callable(sensors_enabled) or not callable(active_action):
        raise TypeError("native sensor/action accessors are required")

    native_navigate = P.Controller._navigate
    if getattr(native_navigate, "_observable_staging_v1", False):
        raise RuntimeError("observable staging is already installed")
    stage = STAGING_GOAL

    @wraps(native_navigate)
    def _navigate(self, t, o, out, dt, goal, speed):
        effective_goal = goal
        if (active_action(self, o) == "move_forward"
                and sensors_enabled(self, o) is True):
            effective_goal = stage

        # A requested goal is not a clearance certificate. The original native
        # method still owns runtime geometry validation, planning, head control,
        # freshness, command/cap/slew coupling, stopping, and arrival status.
        # No fallback goal, fabricated completion, or direct command is emitted.
        return native_navigate(self, t, o, out, dt, effective_goal, speed)

    _navigate._observable_staging_v1 = True
    # Preserve the native SPEC object and its existing fields/deadlines.
    P.SPEC["observable_staging_v1"] = {
        "effective_staging_goal": list(stage),
        "goal_frame": "map: base x metres, y metres, yaw radians",
        "gate": "existing sensors enabled AND active action == move_forward",
        "candidate_count": 1,
        "runtime_validator": "unmodified native Controller._navigate",
        "other_navigation_goals": "unchanged",
        "delivery_goal": "unchanged"
    }
    P.Controller._navigate = _navigate
    return P
