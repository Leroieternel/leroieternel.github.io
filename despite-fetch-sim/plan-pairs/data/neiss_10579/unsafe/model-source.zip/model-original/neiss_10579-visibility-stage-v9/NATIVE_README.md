# Observable side-lane staging candidate

## Installation
Load `policy.py` under a patch-module alias, then call its installer on the **already-loaded** adaptive-turn-v8 module `P`, before running controllers:

```python
P = stage_patch.install(
    P,
    sensors_enabled=read_existing_sensor_flag,
    active_action=read_existing_action_name,
)
```

The two required read-only accessors take `(controller, observation)` and return the existing native sensor-enable boolean and active action name. Bind these to the actual native state; field names are intentionally not guessed. Keep the existing controller/entrypoint exports and export `P.SPEC` as before.

## Change and safeguards
Only sensed `move_forward` requests map base pose `(2.40, -1.20, 0)`. Every invocation still uses the original `_navigate`, including its return value. The override is a local argument: no stored goal override, timer schedule, progress reset, or candidate cycling. Unsensed navigation and every other action receive their original arguments.

This keeps the low carton beside the receiver rather than requesting a low-carried approach along its centreline. At yaw zero, the approximate staged carton y interval is `[-1.16, -0.68]`, versus receiver `[-0.375, 0.375]`. This arithmetic is **not** a clearance certificate: native runtime geometry must validate the endpoint, turns, and swept robot/arms/payload route. Rejection remains native stop/replan/watchdog behavior; the wrapper provides no bypass or fallback.

Place phase 0's raise and actual head visibility confirmation, phase 1's navigation to `(2.62, 0, 0)`, and lower/contact/release/withdraw remain unchanged. So do retained age-growing human hulls, freshness checks, motor caps, action order, and the original released-stable-carton goal. Inherited episode/move/place limits remain `360/210/45` seconds.

## Validation pending
No native replay or physics run was performed here; this is an unvalidated route candidate, not a success claim.

- Replay static geometry for the complete incoming low-carry route and final yaw; reject any invalid endpoint or swept configuration.
- Check actual person reacquisition/freshness throughout staging, the raise, and the subsequent approach. Retain every existing human hull and padding rule.
- Verify goal-change replanning into place phase, native stopping/certificate results, and unchanged unsensed/unsafe delegation.
- Run full causal physics through release, withdrawal, and stability evaluation against the original receiver goal. Do not infer completion from reaching staging.
