# Receding-turn runtime override

## Installation

Load the supplied full native implementation, including v5 and the current integrator additions. Load this `policy.py` under a distinct module name, then call:

```python
turn_patch.install(existing_native_policy_module)
```

Install before constructing controllers. Do not replace the existing implementation with this helper module. Installation is idempotent; no native-observation rebinding is needed.

## Change

The failing turn was checking the entire remaining heading change against a forecast-aged human envelope on every tick. This patch instead certifies the reachable **one-control-interval command plus latency plus complete braking tail** for in-place route turns. The original route, waypoint heading and completion predicates remain intact.

The certificate uses the native **0.55 rad/s physical limit**, not the smaller reference slew. At 60 Hz with negligible translation, its forecast is approximately **1.233 s**, and its symmetric yaw interval is approximately **±0.451 rad**, including the existing ±0.025 drift allowance. Both turn directions are covered. Measured angular speed can enlarge that interval. Measured translation, pending linear commands, interpolation padding, and the full braking displacement are included.

Every tick rechecks that tube against the original native static voxel prior and every retained v5 human envelope. Static tests use occupied voxel volumes and native loaded-link bounds. Angular interpolation receives explicit conservative padding. Historical support planes, identity associations, uncapped 0.10 m/s age expansion after 1.25 s, and the v5 SAT margins are unchanged. Certification failure issues no turn command.

During stationary restoration, a genuinely forward-visible intermediate head pose can become the restoration target. It must still pass the original settled-head dwell and a new physical scan before driving. An unsuccessful intermediate target falls back to the original target. This avoids unnecessarily returning all the way to centre when a closer, physically verified view suffices. Placement keeps its original raised-side head target.

If a completed refresh still blocks the turn, an aged-envelope replan may relocate the turn vertex, including short forward staging legs of 0.12/0.24/0.36 m. Every retained actor participates. These are route proposals only: all subsequent commands still undergo the normal live gates. Neither planning nor refresh resets the measured-progress watchdog.

## Preserved

- Original pickup, opposing-contact attach, verification, carry IK and motor/force limits.
- Native collision geometry, head sweep limits, ray configuration and decimation.
- Forward-visibility gate before sensed navigation commands, including turns and receiver approach.
- Original physical placement, receiver-contact seating, release, withdrawal and stable-goal predicates.
- Shared 270 s episode, 150 s move and 45 s placement budgets.
- Existing contact/fall failures and 25 s measured-progress watchdog.

Unsensed navigation delegates to its original implementation. No human or object configuration changes are made.

## Local release gates

This patch has **not been physics-executed here**; completion and the 270 s bound remain test requirements, not claimed results. The certificate relies on the supplied native speed limits, 0.30 s latency bound, measured 0.70/0.60 braking model, and unchanged control cadence.

Inspect `navigation_debug.receding_turn_certificate` at the reported vertex. Require actual yaw progress without unverified-head motion, then completion of all five original actions. Run the existing `assert_native_success(controller, final_observation)` and the native validator, including physical receiver contact/release, final stability, and all collision/fall/head flags. Also replay the unchanged unsensed plan under the same shared budget.
