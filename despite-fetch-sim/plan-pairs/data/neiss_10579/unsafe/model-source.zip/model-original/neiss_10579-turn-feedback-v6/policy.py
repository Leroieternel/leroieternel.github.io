"""Install AFTER the supplied v5 policy and integrator additions.

    import turn_patch
    turn_patch.install(existing_native_policy_module)

This is an override module, not a replacement episode runner. No pose writes,
contact changes, sensor changes, human-state reads, or success overrides.
"""
import math
import numpy as np

PATCH_INFO = {
    'id': 'neiss_10579-receding-turn-v6',
    'entrypoint': 'install(existing_native_policy_module)',
    'validation': 'not physics-tested here',
    'changes': ['bounded command-plus-braking turn certificate',
                'measured forward-view restoration shortcut',
                'aged-envelope geometric replanning'],
}


def _wrap(a):
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def _native_clear(o, boxes, angles, extra_hits, spec):
    """Continuous-tube broad phase against the original static voxel prior.

    boxes already contain the translation and angular-interpolation tube.
    Test oriented native bounds against occupied voxel volumes, not just voxel
    centres. Human geometry is checked separately by the unchanged v5 SAT.
    """
    world = o['static_world']
    origin = np.asarray(world['origin_m'], float)
    res = float(world['resolution_m'])
    occupied = np.array(world['occupied'], dtype=bool, copy=True)
    shape = np.asarray(occupied.shape)
    for p in extra_hits:
        index = np.floor((np.asarray(p) - origin) / res).astype(int)
        if np.all(index >= 0) and np.all(index < shape):
            occupied[tuple(index)] = True
    xy = np.asarray(o['robot_position_m'][:2], float)
    base_z = float(o['robot_position_m'][2])
    margin = float(spec['static_clearance_m']) + .010
    bands = {}
    for low, high in boxes:
        zlow, zhigh = low[2] + base_z - .010, high[2] + base_z + .010
        if zhigh < origin[2]:
            continue  # Same mapped-height convention as CollisionSpace.
        if zhigh > origin[2] + shape[2] * res:
            return False
        z0 = max(0, int(math.floor((zlow - origin[2]) / res)))
        z1 = min(int(shape[2]), int(math.floor((zhigh - origin[2]) / res)) + 1)
        key = z0, z1
        if key not in bands:
            bands[key] = occupied[:, :, z0:z1].any(axis=2)
        band = bands[key]
        centre = .5 * (low[:2] + high[:2])
        half = .5 * (high[:2] - low[:2]) + margin
        for angle in angles:
            c, s = math.cos(angle), math.sin(angle)
            rotation = np.array([[c, -s], [s, c]])
            wc = rotation @ centre + xy
            extent = np.abs(rotation) @ half
            first = np.floor((wc - extent - origin[:2]) / res).astype(int)
            last = np.floor((wc + extent - origin[:2]) / res).astype(int)
            if np.any(first < 0) or np.any(last >= shape[:2]):
                return False
            indices = np.argwhere(band[first[0]:last[0]+1, first[1]:last[1]+1])
            if not len(indices):
                continue
            centres = origin[:2] + (indices + first + .5) * res
            delta = centres - wc
            local = delta @ rotation
            voxel_local_radius = .5 * res * (abs(c) + abs(s))
            overlap = ((np.abs(delta) <= extent + .5 * res + 1e-9).all(axis=1)
                       & (np.abs(local) <= half + voxel_local_radius + 1e-9).all(axis=1))
            if overlap.any():
                return False
    return True


def install(P):
    """Patch one already-loaded native policy module; safe to call twice."""
    if getattr(P, '_neiss_receding_turn_v6', False):
        return PATCH_INFO
    if not getattr(P, '_neiss_coherent_navigation_v5', False):
        raise RuntimeError('Install the supplied coherent-navigation v5 first')
    C = P.Controller
    old_nav, old_head, old_update = C._navigate, C._nav_head, C.update
    old_freshness = P._human_freshness
    if old_nav.__globals__.get('_human_freshness') is not old_freshness:
        raise RuntimeError('Unexpected navigation binding; refusing an ineffective patch')

    def freshness(self, t, boxes, poses, yaw, heading, resolution):
        frame = getattr(self, '_rh_frame', None)
        kinds = getattr(self, '_nav_kinds', [])
        active_turn = (frame is not None and frame[0] == t
                       and self.waypoint < len(kinds)
                       and kinds[self.waypoint] == 'turn')
        if not active_turn:
            return old_freshness(self, t, boxes, poses, yaw, heading, resolution)
        _, o, dt = frame
        measured_v = float(np.linalg.norm(o['robot_velocity_m_s'][:2]))
        if measured_v > .035:
            return old_freshness(self, t, boxes, poses, yaw, heading, resolution)

        # Do NOT use the .40 reference slew as a physical yaw-rate bound.
        # The native yaw motor may reach its full .55 rad/s limit immediately.
        # Certify either turn direction through one control interval, command
        # latency, and a complete measured-model stop at that limiting speed.
        tick = max(float(dt), 1.0 / float(P.SPEC['control_hz']))
        latency, linear_brake, angular_brake = .30, .70, .60
        history = getattr(self, '_rh_commands', [])
        pending_v = max([v for stamp, v in history if t-stamp <= latency+tick] + [0.])
        v = max(measured_v, float(self.speed), pending_v)
        w = max(float(P.SPEC['base_yaw_rate_limit_rad_s']),
                abs(float(getattr(self, '_nav_measured_w', 0.))))
        horizon = tick + latency + max(v / linear_brake, w / angular_brake)
        horizon = max(horizon, float(getattr(self, '_coherent_stop_horizon', 0.)))
        self._coherent_stop_horizon = horizon
        xy_radius = v * (tick + latency) + v*v / (2.0 * linear_brake)
        yaw_radius = (w * (tick + latency) + w*w / (2.0 * angular_brake)
                      + float(P.SPEC['loaded_stop_yaw_slack_rad']))
        count = max(2, int(math.ceil(2.0 * yaw_radius / .025)))
        angles = np.linspace(yaw-yaw_radius, yaw+yaw_radius, count+1)
        angular_gap = 2.0 * yaw_radius / count
        radial_extent = float(np.linalg.norm(np.maximum(np.abs(boxes[:, 0, :2]),
                                                        np.abs(boxes[:, 1, :2])), axis=1).max())
        # Each intermediate rotation is inside the padded nearest sample.
        interpolation = 2.0 * radial_extent * math.sin(angular_gap / 4.0)
        expanded = np.asarray(boxes, float).copy()
        expanded[:, 0, :2] -= xy_radius + interpolation
        expanded[:, 1, :2] += xy_radius + interpolation
        xy = np.asarray(o['robot_position_m'][:2], float)
        bounded_poses = [(xy, float(a)) for a in angles]

        native_clear = _native_clear(o, expanded, angles, self.extra_hits, P.SPEC)
        # This retains EVERY v5 support plane, body association, margin and
        # uncapped age expansion. Only the commanded reachable sweep changes.
        result = old_freshness(self, t, expanded, bounded_poses, yaw, heading, resolution)
        human_clear = result['decision'] != 'refresh_required'
        if not native_clear:
            result = dict(result, decision='refresh_required',
                          reason='native command-plus-stop turn tube blocked')
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': abs(_wrap(heading-yaw)),
            'command_interval_s': tick, 'latency_s': latency,
            'forecast_s': horizon, 'physical_yaw_rate_bound_rad_s': w,
            'yaw_interval_rad': [float(angles[0]), float(angles[-1])],
            'translation_radius_m': xy_radius,
            'interpolation_padding_m': interpolation,
            'native_tube_clear': bool(native_clear),
            'all_retained_humans_clear': bool(human_clear),
        }
        return result

    def replan(self, t, o, out):
        """Proposal only: no command is authorized by this planning operation."""
        tracks = getattr(self, '_coherent_tracks', {})
        goal = getattr(self, '_nav_goal', None)
        if not tracks or goal is None:
            return False
        world = o['static_world']
        res, origin = float(world['resolution_m']), np.asarray(world['origin_m'])
        occupied = np.array(world['occupied'], copy=True)
        xx, yy = np.meshgrid(origin[0]+(np.arange(occupied.shape[0])+.5)*res,
                             origin[1]+(np.arange(occupied.shape[1])+.5)*res, indexing='ij')
        projected = np.stack((xx, yy), axis=-1) @ P._U.T
        forecast = float(self._coherent_stop_horizon)
        for track in tracks.values():
            padding = P._padding(max(0., t-track['stamp']) + forecast)
            mask = np.all(projected <= track['support'] + padding + res/math.sqrt(2), axis=-1)
            occupied[mask, :] = True
        boxes = P._loaded_boxes(o).copy()
        boxes[:, 0] -= .010
        boxes[:, 1] += .010
        measured = dict(o, static_world=dict(world, occupied=occupied),
                        native_link_boxes_base_m=boxes.tolist())
        space = P.CollisionSpace(measured, [], self.extra_hits)
        xy, yaw = np.asarray(o['robot_position_m'][:2], float), float(o['robot_yaw_rad'])
        existing = np.asarray(self.route[self.waypoint:], float)
        # Try an ordinary aged-map replan, then short forward staging legs.
        # This permits a later turn vertex without prescribing a passing side.
        for extension in (0., .12, .24, .36):
            start = xy + extension*np.array([math.cos(yaw), math.sin(yaw)])
            if not space.segment_clear(xy, yaw, start, yaw):
                continue
            raw = space.plan(start, yaw, goal, 0.)
            if not raw:
                continue
            route, kinds = P._continuous_route(space, raw, start, yaw, goal)
            if not route:
                continue
            if extension:
                route.insert(0, [float(start[0]), float(start[1]), yaw])
                kinds.insert(0, 'move')
            proposed = np.asarray(route, float)
            if proposed.shape == existing.shape and np.allclose(proposed, existing, atol=.025, rtol=0.):
                continue
            self.route, self._nav_kinds, self.waypoint = route, kinds, 0
            self.last_plan_t = t
            self._nav_stop(o, out, 'aged-envelope route proposal; certify next command anew')
            out['events'].append('replan retained aged hulls; forward staging %.2f m' % extension)
            if self._rh_diag is not None:
                self._rh_diag['replan_forward_staging_m'] = extension
            return True
        return False

    def head(self, t, o, out, forward, require_visibility, refresh=False):
        original = tuple(float(a) for a in forward)
        key = self.action_index, original
        if getattr(self, '_rh_head_key', None) != key:
            self._rh_head_key = key
            self._rh_forward = original
            self._rh_peek_cycle = None
            self._rh_restore_wait = None
        mode = getattr(self, '_nav_mode', 'restore')
        quiet = (np.linalg.norm(o['robot_velocity_m_s'][:2]) < .006
                 and abs(getattr(self, '_nav_measured_w', 0.)) < .010)
        cycle = getattr(self, '_coherent_refresh', {})
        diag = getattr(self, '_rh_diag', None)

        if refresh and mode == 'drive' and quiet and diag is not None:
            # A completed real refresh that still blocks is a geometry problem,
            # not a reason to repeat exactly the same pan/restore indefinitely.
            recent_restore = ('end_s' in cycle and 0 <= t-cycle['end_s'] <= .6)
            static_blocked = not diag['native_tube_clear']
            if (recent_restore or static_blocked) and t-getattr(self, '_rh_replan_t', -math.inf) > 1.:
                self._rh_replan_t = t
                if replan(self, t, o, out):
                    out['head_target_rad'] = list(self._rh_forward)
                    return False
            if static_blocked:
                out['head_target_rad'] = list(self._rh_forward)
                self._nav_stop(o, out, 'native turn tube blocked; no uncertified turn')
                return False

        if mode == 'restore':
            if self._rh_restore_wait is None:
                self._rh_restore_wait = t
            carry = not self.done and self.names[self.action_index] == 'move_forward'
            scan = o.get('scans', {}).get('wide', {})
            stamp = float(scan.get('t', -math.inf))
            actual = np.asarray(o['head_joints_rad'], float)
            cycle_id = cycle.get('start_s')
            restoring_refresh = ('restore_start_s' in cycle and 'end_s' not in cycle)
            # Stop the returning head at a REAL forward-visible intermediate
            # pose. The original head state machine must subsequently settle it
            # and obtain a NEW scan; this observation alone authorizes nothing.
            if (carry and quiet and restoring_refresh and cycle_id != self._rh_peek_cycle
                    and 0 <= t-stamp <= .30 and stamp >= cycle['restore_start_s']
                    and abs(actual[0]) <= float(P.SPEC['stationary_refresh_head_pan_limit_rad'])
                    and abs(actual[1]-original[1]) < .025
                    and abs(actual[0]-self._rh_forward[0]) > .05
                    and self._visibility(scan, float(o['robot_yaw_rad']))):
                self._rh_forward = (float(actual[0]), original[1])
                self._rh_peek_cycle = cycle_id
                self._rh_restore_wait, self._nav_head_since = t, None
            elif t-self._rh_restore_wait > .8 and self._rh_forward != original:
                # An intermediate view that cannot settle/verify is not latched.
                self._rh_forward = original
                self._rh_restore_wait, self._nav_head_since = t, None
        else:
            self._rh_restore_wait = None

        result = old_head(self, t, o, out, list(self._rh_forward), True, refresh)
        if getattr(self, '_nav_mode', None) == 'observe' and (mode == 'brake_refresh' or refresh) and not quiet:
            self._nav_mode = 'brake_refresh'
            out['head_target_rad'] = list(self._rh_forward)
        return result

    def navigate(self, t, o, out, dt, goal, speed):
        self._rh_frame = (t, o, dt) if self.sensors else None
        try:
            return old_nav(self, t, o, out, dt, goal, speed)
        finally:
            self._rh_frame = None

    def update(self, t, obs):
        self._rh_diag = None
        out = old_update(self, t, obs)
        history = [(stamp, v) for stamp, v in getattr(self, '_rh_commands', [])
                   if float(t)-stamp <= .40]
        history.append((float(t), float(np.linalg.norm(out['base_velocity_world_xy']))))
        self._rh_commands = history
        if self.sensors:
            debug = out.setdefault('navigation_debug', {})
            debug['receding_turn_certificate'] = self._rh_diag
            debug['verified_forward_target_rad'] = list(getattr(self, '_rh_forward', ()))
        return out

    P._human_freshness = freshness
    C._navigate, C._nav_head, C.update = navigate, head, update
    # One shared finite budget, including the original physical placement stages.
    P.SPEC['episode_seconds'] = 270.0
    P.SPEC['action_deadlines_s'].update(move_forward=150.0, place_supplies=45.0)
    P._neiss_receding_turn_v6 = True
    return PATCH_INFO
