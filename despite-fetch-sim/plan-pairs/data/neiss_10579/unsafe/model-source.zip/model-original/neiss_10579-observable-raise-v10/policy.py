from functools import wraps

_STAGE_XY = (0.80, -1.20)
_TAG = '_observable_staging_v1'

SPEC = {
    'name': 'early-raise-staging-v10',
    'stage_xy_m': _STAGE_XY,
    'terminal_yaw_rad': 0.0,  # Supplied by native navigation, not overridden.
    'scope': 'XYgoal only when sensors_enabled and move_forward; placement unchanged',
}


def _read(value):
    return value() if callable(value) else value


def install(P, sensors_enabled, active_action):
    """Replace the unique directly owned tagged navigation hook on P.

    Use live zero-argument getters for changing sensor/action state.
    P may be the owning instance/namespace, or a policy class whose hook
    is an ordinary instance method. XYgoal is the first non-self argument.
    """
    matches = [
        (name, hook) for name, hook in vars(P).items()
        if callable(hook) and getattr(hook, _TAG, False) is True
    ]
    if len(matches) != 1:
        raise RuntimeError('Expected exactly one owned tagged staging hook')

    name, old_stage = matches[0]
    # Exactly one unwrap: retain every controller underneath the old stage.
    native_navigate = old_stage.__wrapped__
    if not callable(native_navigate):
        raise TypeError('Tagged staging hook has no callable native delegate')
    goal_index = 1 if isinstance(P, type) else 0

    @wraps(native_navigate)
    def staged(*args, **kwargs):
        if _read(sensors_enabled) and _read(active_action) == 'move_forward':
            goal = list(_STAGE_XY)
            if len(args) > goal_index:
                args = args[:goal_index] + (goal,) + args[goal_index + 1:]
            elif 'XYgoal' in kwargs:
                kwargs = dict(kwargs)
                kwargs['XYgoal'] = goal
            else:
                raise TypeError('Expected a supplied native XYgoal')
        return native_navigate(*args, **kwargs)

    # Reuse the replacement-slot tag so reinstalling does not stack adapters.
    staged._observable_staging_v1 = True
    setattr(P, name, staged)
    return staged
