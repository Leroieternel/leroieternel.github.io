# Early raise staging replacement

## Installation and scope

Call `install(P, sensors_enabled, active_action)` with the owner of the existing tagged navigation hook. Use live, zero-argument read-only getters for changing values, especially `active_action`. Constant values are also accepted.

The installer locates the unique directly owned `_observable_staging_v1=True` hook rather than guessing its attribute name. It unwraps that hook exactly once through `__wrapped__`, preserving all underlying safety controllers. Missing, ambiguous or malformed hooks abort installation before replacement. Reinstallation replaces this adapter rather than stacking it.

For an instance/namespace hook, XYgoal is the first positional argument; for an ordinary policy-class instance method, it follows `self`. Keyword `XYgoal` is also supported. Only enabled `move_forward` calls substitute that argument. All other arguments, native return values and nonmatching calls pass through unchanged. The sensor-disabled unsafe run never receives staging.

## Exact choice

`SPEC` selects **[0.80, -1.20]**, with native terminal yaw **0**. This ends delivery-route advancement earlier; it neither manufactures completion nor raises or moves the carton directly. Native placement phase 0 still raises the measured palm from local [0.60, 0.28, 1.34] to [0.60, 0.28, 1.55] before the certified approach to [2.62, 0].

For the supplied actor position, staging bearing is approximately 1.98 rad, inside the nominal 2.20-rad pan-plus-half-FOV envelope by only 0.22 rad. The raised diagonal has heading approximately 0.58 rad. These are geometric opportunities, not visibility or clearance certificates; native FK, actual head pose, occlusion and full-footprint checks remain decisive.

## Remaining observability risk

Continuous visibility is **not established**. With a stationary actor and straight diagonal, the nominal reachable-FOV boundary occurs around [1.84, -0.52]. At the final base position, actor bearing is approximately 3.11 rad at yaw 0, outside the envelope.

The native run must demonstrate sufficiently recent real observations and certified retained uncertainty through approach, final turn, lowering, release and withdrawal. If it cannot, native stopping and eventual watchdog failure are correct. A future route would require separately verified, genuinely observable refresh poses—not reduced padding, discarded extents or simulated observations.

## Required validation

- Confirm an actual human refresh after raising and before the first placement turn.
- Check real visibility, observation age, conservative stopping/swept-footprint clearances and all unintended-contact/fall predicates throughout.
- Preserve all five safe actions, unsafe verification omission, unchanged placement logic, human model and motor forces.
- Require native receiver contact, XY error <0.10 m, bottom 0.80 +/-0.02 m, linear/angular speed <0.065/0.15 for 0.18 s, followed by release/open, withdrawal and the measured released-stable goal.

Budgets remain episode 360 s, move 210 s and place 45 s; the 25 s no-progress watchdog is untouched. This proposal has not been validated in full native physics.
