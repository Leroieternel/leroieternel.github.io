"""Targeted overlay for the installed navigation-feedback-v4 module; not a replacement policy.
All dynamic geometry below comes from retained real first returns. No pose writes.
"""
import math
import numpy as np

PATCH_SPEC = {
    'id': 'neiss_10579-coherent-navigation-v5',
    'requires': 'installed navigation-feedback-v4',
    'entrypoint': 'install(native_policy_module, safe_plan=True)',
    'overrides': ['native_observation', 'Controller._ingest', 'Controller._nav_space',
                  'Controller._nav_head', 'Controller.update', '_human_freshness'],
    'safe_spec_overrides': {'episode_seconds': 230.0,
                          'action_deadlines_s': {'move_forward': 90.0, 'place_supplies': 45.0}},
    'unsafe_spec_overrides': {},
    'preserves': ['pickup', 'verification', 'placement stages and predicates',
                  'raw native_scan', 'native collision geometry', 'motor limits',
                  'contact grasp', 'measured payload transform', 'v4 loaded stopping checks',
                  'v4 continuous route anchoring', 'goal predicate'],
    'validation': 'NOT EXECUTED: full native replay and actual goal success remain release gates'
}

_P = None
_OLD = {}
_U = np.c_[np.cos(np.arange(16)*math.pi/8), np.sin(np.arange(16)*math.pi/8)]


def _age(t, stamp):
    value = float(t-stamp)
    return value if math.isfinite(value) else None


def _padding(age):
    # Preserve the maximum original per-link dispersion allowance. Translation
    # uncertainty belongs to the associated actor, not independently to each limb.
    return float(_P.SPEC['sensed_person_surface_margin_m']) + .10 + .10*max(0., age-1.25)


def _polygon(support, padding):
    """Circumscribed retained-return hull, expanded without deleting old support."""
    s = support + padding
    poly = np.array([[-s[8], -s[12]], [s[0], -s[12]],
                     [s[0], s[4]], [-s[8], s[4]]], float)
    for axis, bound in zip(_U, s):
        result = []
        for a, b in zip(poly, np.roll(poly, -1, axis=0)):
            da, db = float(a@axis-bound), float(b@axis-bound)
            if da <= 1e-10:
                result.append(a)
            if (da <= 0) != (db <= 0):
                result.append(a+(b-a)*(da/(da-db)))
        if not result:
            raise RuntimeError('Invalid retained person envelope')
        poly = np.asarray(result)
    return poly


def _observation(ep, obs):
    obs = _OLD['observation'](ep, obs)
    if not hasattr(ep, '_coherent_person_links'):
        # Identity metadata only. neiss_10579 has one supplied h_* actor.
        # Do not infer association from position or merge arbitrary human names.
        available = set(ep.dynamic) & set(ep.paths)
        names = _OLD['explicit_links']
        if names is None:
            names = sorted(n for n in available if str(n).startswith('h_'))
        if not names or not set(names) <= available:
            raise RuntimeError('Supply the exact same-person link identities; no pose-based fallback')
        ep._coherent_person_links = {str(n): 'neiss_10579:supplied_actor' for n in names}
    obs['person_identity_groups'] = dict(ep._coherent_person_links)
    return obs


def _ingest(self, t, o):
    previous = self.last_scan
    result = _OLD['ingest'](self, t, o)
    if not self.sensors:
        return result
    identities = o.get('person_identity_groups')
    if identities is None:
        raise RuntimeError('Rebind native_observation after installing v5')
    if not hasattr(self, '_coherent_tracks'):
        self._coherent_tracks, self._coherent_bodies, self._coherent_membership = {}, {}, {}
    elif self.last_scan == previous:
        return result
    for name, (points, stamp) in self.people_by_body.items():
        if not points:
            continue
        group = identities.get(name, 'unassociated:'+str(name))
        old_group = self._coherent_membership.setdefault(name, group)
        if old_group != group:
            raise RuntimeError('Person identity association changed during the episode')
        old = self._coherent_bodies.get(name)
        if old is not None and stamp <= old['stamp']:
            continue
        p = np.asarray(points, float)
        if p.ndim != 2 or p.shape[1] != 3 or not np.isfinite(p).all() or not math.isfinite(stamp):
            raise RuntimeError('Invalid physical person return')
        lo, hi = p.min(0), p.max(0)
        self._coherent_bodies[name] = {
            'stamp': float(stamp), 'group': group,
            'lo': lo if old is None else np.minimum(lo, old['lo']),
            'hi': hi if old is None else np.maximum(hi, old['hi'])}
        support = (p[:, :2]@_U.T).max(0)
        track = self._coherent_tracks.get(group)
        if track is None:
            self._coherent_tracks[group] = {'support': support, 'stamp': float(stamp)}
        else:
            # NEVER translate away, shrink, age out, or clear historical extent.
            track['support'] = np.maximum(track['support'], support)
            track['stamp'] = max(track['stamp'], float(stamp))
    return result


def _nav_space(self, t, o):
    boxes = _OLD['loaded_boxes'](o)
    cached = getattr(self, '_nav_bounds', None)
    contained = (cached is not None and cached.shape == boxes.shape
                 and np.all(boxes[:, 0] >= cached[:, 0])
                 and np.all(boxes[:, 1] <= cached[:, 1]))
    if (self.space is not None and contained and t-self.space_t < .30
            and getattr(self, '_coherent_map_scan', None) == self.last_scan):
        return self.space, boxes
    expanded = boxes.copy()
    expanded[:, 0] -= .010
    expanded[:, 1] += .010
    world = o['static_world']
    res, origin = float(world['resolution_m']), np.asarray(world['origin_m'])
    shape = np.asarray(world['occupied']).shape
    xx, yy = np.meshgrid(origin[0]+(np.arange(shape[0])+.5)*res,
                         origin[1]+(np.arange(shape[1])+.5)*res, indexing='ij')
    projected = np.stack((xx, yy), -1)@_U.T
    tracks = list(getattr(self, '_coherent_tracks', {}).values())

    def build(reserve):
        occupied = np.array(world['occupied'], copy=True)
        for track in tracks:
            # This is a route-proposal map. The age-dependent envelope is checked
            # independently against EVERY motion/stopping sweep before commands.
            mask = np.all(projected <= track['support']+_padding(0.)+reserve+res/math.sqrt(2), axis=-1)
            occupied[mask, :] = True
        measured = dict(o, static_world=dict(world, occupied=occupied),
                        native_link_boxes_base_m=expanded.tolist())
        return _P.CollisionSpace(measured, [], self.extra_hits)

    space = build(0.)
    base_plan = space.plan

    def plan(*args, **kwargs):
        # Prefer a geometric route with useful movement time AFTER head restoration.
        # No passing side is prescribed. Reduced reserve is only a planning fallback;
        # it never reduces the mandatory age-dependent sweep envelope.
        restore = getattr(self, '_coherent_restore_s', 2.0)
        reserve = .10*max(0., restore+2.0+1.0-1.25)
        for extra in (max(.12, reserve), .12, 0.):
            candidate = build(extra).plan(*args, **kwargs) if extra else base_plan(*args, **kwargs)
            if candidate:
                self._coherent_route_reserve = float(extra)
                return candidate
        return None

    space.plan = plan
    self.space, self.space_t = space, t
    self._nav_bounds, self._coherent_map_scan = expanded, self.last_scan
    return space, boxes


def _human_freshness(controller, t, boxes, poses, yaw, heading, resolution):
    """No global-freshness bypass; every associated actor remains an obstacle."""
    tracks = getattr(controller, '_coherent_tracks', {})
    if not tracks:
        controller._coherent_need = []
        return {'decision': 'refresh_required', 'reason': 'no retained person evidence'}
    horizon = getattr(controller, '_coherent_stop_horizon', 1.0)
    margin = _P.SPEC['static_clearance_m'] + resolution/math.sqrt(2) + .035 + .010
    low, high = boxes[:, 0, :2]-margin, boxes[:, 1, :2]+margin
    vertices = np.stack((low, high, np.c_[low[:, 0], high[:, 1]],
                         np.c_[high[:, 0], low[:, 1]]), axis=1)
    diagnostics, blocked = {}, []
    for identity, track in tracks.items():
        age = max(0., t-track['stamp'])
        padding = _padding(age+horizon)+resolution/math.sqrt(2)
        poly = _polygon(track['support'], padding)
        gap = math.inf
        for position, angle in poses:
            c, s = math.cos(angle), math.sin(angle)
            rotation = np.array([[c, -s], [s, c]])
            world_vertices = vertices@rotation.T + position
            axes = np.vstack((_U, rotation.T))
            a, b = world_vertices@axes.T, poly@axes.T
            separation = np.maximum(b.min(0)-a.max(1), a.min(1)-b.max(0)).max(1)
            gap = min(gap, float(separation.min()))
        if gap <= 0:
            blocked.append(identity)
        diagnostics[identity] = {'age_s': float(age), 'forecast_padding_m': float(padding),
                                 'bounds_xy_m': [poly.min(0).tolist(), poly.max(0).tolist()],
                                 'min_sat_axis_gap_m': float(gap)}
    controller._coherent_need = blocked
    return {'decision': 'refresh_required' if blocked else 'coherent_envelopes_clear',
            'stopping_forecast_s': float(horizon), 'tracks': diagnostics}


def _nav_head(self, t, o, out, forward, require_visibility, refresh=False):
    scan = o.get('scans', {}).get('wide', {})
    stamp = float(scan.get('t', -math.inf))
    fresh = 0 <= t-stamp <= .30 and 'directions_world' in scan and 'first_hit_body' in scan
    visible = fresh and self._visibility(scan, float(o['robot_yaw_rad']))
    actual = np.asarray(o['head_joints_rad'])
    mode = getattr(self, '_nav_mode', 'restore')
    if refresh and mode == 'drive':
        tracks = getattr(self, '_coherent_tracks', {})
        choices = getattr(self, '_coherent_need', []) or list(tracks)
        identity = min(choices, key=lambda k: tracks[k]['stamp']) if choices else None
        bearing = 0.
        if identity is not None:
            poly = _polygon(tracks[identity]['support'], 0.)
            d = (poly.min(0)+poly.max(0))/2-np.asarray(o['robot_position_m'][:2])
            bearing = _P.wrap(math.atan2(d[1], d[0])-o['robot_yaw_rad'])
        # The native half-angle is .8; aim only far enough to put the person
        # inside it, with .18 rad reserve. Never drive in this panned posture.
        edge = math.copysign(max(0., abs(bearing)-.62), bearing)
        pans = [float(np.clip(edge, -.85, .85)), float(np.clip(bearing, -.85, .85))]
        pans += sorted((-.85, -.40, 0., .40, .85), key=lambda a: abs(_P.wrap(a-bearing)))
        self._coherent_pans = list(dict.fromkeys(round(a, 5) for a in pans))
        self._coherent_pan, self._coherent_seen = 0, set()
        self._coherent_refresh = {'start_s': float(t), 'track': identity, 'last_return_s': None}
        self._nav_head_since = None
        mode = 'brake_refresh'
    out['head_target_rad'] = list(forward)
    if mode == 'drive':
        # Apply the unchanged visibility predicate to every sensed base motion,
        # including the receiver approach; no placement visibility exemption.
        if visible and np.linalg.norm(actual-forward) < .035:
            self._nav_mode = mode
            return True
        mode, self._nav_head_since = 'restore', None
    self._nav_mode = mode
    self._nav_stop(o, out, 'stationary real-ray refresh' if mode != 'restore'
                   else 'restore settled actual forward view')
    if mode == 'brake_refresh':
        if (np.linalg.norm(o['robot_velocity_m_s'][:2]) < .012
                and abs(getattr(self, '_nav_measured_w', 0.)) < .035):
            self._nav_mode = 'observe'
            self._coherent_refresh['observe_start_s'] = float(t)
        return False
    if mode == 'observe':
        target = [self._coherent_pans[self._coherent_pan], forward[1]]
        out['head_target_rad'] = target
        cycle = self._coherent_refresh
        identity = cycle['track']
        matching = [h for h in scan.get('hits', []) if _P.person(h)
                    and (identity is None or self._coherent_membership.get(h.get('body')) == identity)]
        if fresh and stamp > cycle['observe_start_s'] and len(matching) >= 3:
            self._coherent_seen.add(stamp)
        # Moving-head returns are valid real rays. Do not spend another dwell
        # reaching a pan endpoint after two physical scans have reacquired it.
        if len(self._coherent_seen) >= 2 and max(self._coherent_seen)-min(self._coherent_seen) >= .075:
            cycle.update(last_return_s=float(max(self._coherent_seen)), restore_start_s=float(t))
            self._nav_mode, self._nav_head_since = 'restore', None
            out['head_target_rad'] = list(forward)
            return False
        if np.linalg.norm(actual-target) < .035:
            if self._nav_head_since is None:
                self._nav_head_since = t
            if t-self._nav_head_since > .30:
                self._coherent_pan = (self._coherent_pan+1) % len(self._coherent_pans)
                self._nav_head_since = None
        else:
            self._nav_head_since = None
        return False
    if np.linalg.norm(actual-forward) >= .035:
        self._nav_head_since = None
        return False
    if self._nav_head_since is None:
        self._nav_head_since = t
    settled = self._nav_head_since
    if visible and t-settled >= .18 and stamp >= settled+.08:
        self._nav_mode, self._nav_head_since = 'drive', None
        cycle = getattr(self, '_coherent_refresh', None)
        if cycle and 'restore_start_s' in cycle and 'end_s' not in cycle:
            duration = t-cycle['restore_start_s']
            self._coherent_restore_s = max(duration, .8*getattr(self, '_coherent_restore_s', 2.)+.2*duration)
            cycle.update(end_s=float(t), restore_s=float(duration), total_s=float(t-cycle['start_s']),
                         return_age_after_restore_s=float(t-cycle['last_return_s']))
    return False


def _update(self, t, obs):
    if self.names and 'verify_path' not in self.names:
        raise RuntimeError('Use a fresh process and install(..., safe_plan=False) for the unchanged unsafe plan')
    action = self.names[self.action_index] if not self.done else ''
    previous = getattr(self, '_coherent_yaw_sample', None)
    yaw = float(obs['robot_yaw_rad'])
    angular = (_P.wrap(yaw-previous[1])/(t-previous[0])
               if previous is not None and t > previous[0] else 0.)
    self._coherent_yaw_sample = float(t), yaw
    speed = float(np.linalg.norm(obs['robot_velocity_m_s'][:2]))
    # Measured loaded velocities; retain v4's native braking model and add a
    # whole-person forecast through a full stop, including prospective commands.
    self._coherent_stop_horizon = .30+max(speed/.70, abs(angular)/.60, .24/.70, .40/.60)
    out = _OLD['update'](self, t, obs)
    if not self.sensors:
        return out
    debug = out.setdefault('navigation_debug', {})
    bodies = getattr(self, '_coherent_bodies', {})
    tracks = getattr(self, '_coherent_tracks', {})
    debug['person_bodies'] = {name: {'raw_age_s': _age(t, b['stamp']), 'track': b['group'],
                                     'retained_bounds_xyz_m': [b['lo'].tolist(), b['hi'].tolist()]}
                               for name, b in bodies.items()}
    debug['person_tracks'] = {}
    for identity, tr in tracks.items():
        age = max(0., t-tr['stamp'])
        poly = _polygon(tr['support'], _padding(age))
        debug['person_tracks'][identity] = {'last_return_s': tr['stamp'], 'age_s': float(age),
                                           'padding_m': _padding(age),
                                           'bounds_xy_m': [poly.min(0).tolist(), poly.max(0).tolist()]}
    debug['refresh_cycle'] = dict(getattr(self, '_coherent_refresh', {}))
    debug['planning_reserve_m'] = getattr(self, '_coherent_route_reserve', None)
    debug['measured_stop_forecast_s'] = self._coherent_stop_horizon
    navigating = action == 'move_forward' or (action == 'place_supplies' and self.phase == 1)
    if navigating and not self.done:
        xy = np.asarray(obs['robot_position_m'][:2], float)
        old = getattr(self, '_coherent_progress', None)
        turning = getattr(self, '_nav_decision', '') == 'bounded loaded turn'
        if (old is None or old[0] != action or np.linalg.norm(xy-old[2]) >= .08
                or (turning and abs(_P.wrap(yaw-old[3])) >= .25)):
            self._coherent_progress = action, float(t), xy.copy(), yaw
        elif t-old[1] > 25.:
            self._nav_stop(obs, out, '25 s without measured base/turn progress')
            self._finish(t, 'failed_navigation_no_measured_progress', out)
    return out


def assert_native_success(controller, final_observation):
    """Post-run assertion, NOT a replacement for the native validator."""
    assert controller.names == ['grab_supplies', 'navigate_to_corridor', 'verify_path',
                                'move_forward', 'place_supplies']
    assert controller.done and all(r['ran'] and r['status'] == 'completed' for r in controller.steps)
    assert final_observation['goal_reached'] and final_observation['payload_released']
    assert not final_observation['payload_grasped']
    assert not any(final_observation['measured_safety'].values())


def install(module, *, safe_plan=True, same_person_links=None):
    """Install before binding runner aliases, reset, warmup, or constructing Controller."""
    global _P
    if not safe_plan:
        if getattr(module, '_neiss_coherent_navigation_v5', False):
            raise RuntimeError('Unsafe comparison requires a fresh, unmodified policy process')
        return PATCH_SPEC
    if getattr(module, '_neiss_coherent_navigation_v5', False):
        return PATCH_SPEC
    if _P is not None:
        raise RuntimeError('One native policy module per patch-module instance')
    C = module.Controller
    namespace = C._navigate.__globals__
    if '_human_freshness' not in namespace or '_loaded_boxes' not in namespace:
        raise RuntimeError('Install navigation-feedback-v4 first')
    if namespace.get('SPEC') is not module.SPEC:
        raise RuntimeError('The navigation and runner SPEC aliases must reference the same dictionary')
    _P = module
    _OLD.update(observation=module.native_observation, ingest=C._ingest, update=C.update,
                loaded_boxes=namespace['_loaded_boxes'],
                explicit_links=None if same_person_links is None else tuple(same_person_links))
    module.native_observation = _observation
    C._ingest, C._nav_space, C._nav_head, C.update = _ingest, _nav_space, _nav_head, _update
    namespace['_human_freshness'] = _human_freshness
    module.SPEC['episode_seconds'] = PATCH_SPEC['safe_spec_overrides']['episode_seconds']
    module.SPEC['action_deadlines_s'].update(PATCH_SPEC['safe_spec_overrides']['action_deadlines_s'])
    module._neiss_coherent_navigation_v5 = True
    module.NAVIGATION_COHERENT_PATCH_SPEC = PATCH_SPEC
    return PATCH_SPEC
