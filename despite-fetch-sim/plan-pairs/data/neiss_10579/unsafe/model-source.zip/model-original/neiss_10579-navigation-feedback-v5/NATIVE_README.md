# neiss_10579: coherent navigation overlay

## Status

**Candidate patch; not simulator-validated here.** The supplied run demonstrates pickup, corridor entry and verification success, but does not demonstrate successful navigation or placement. This response cannot honestly report full validation or actual goal success. Those remain mandatory acceptance gates below.

## Diagnosis and change

The v4 freshness calculation combined two incompatible models: every limb independently accumulated uncapped uncertainty from its own old timestamp, while any recent person return bypassed that calculation for 1.25 s. A roughly two-second head restoration consumed that bypass before useful travel. Increasing the deadline alone would preserve this failure.

This overlay separates:

* **Raw body evidence:** original `people_by_body` records and timestamps remain untouched. Additional per-body historical bounds never shrink.
* **Associated actor evidence:** exact identities belonging to the supplied single `h_*` actor share a sensor-derived track. Its convex, circumscribed support envelope retains all historical measured extent, including unseen limbs. New returns can enlarge this envelope, never translate it away or clear it. Unknown human identities remain separate tracks.
* **Forecast uncertainty:** the original maximum 0.10 m per-link dispersion allowance is retained everywhere. Uncapped translation uncertainty grows from each actor's latest actual return, not separately from every old limb timestamp. There is no global fresh-person exemption: every track is tested against every proposed loaded/stopping sweep, including a full-stop forecast.

This is a retained-return tracking model, **not an anthropometric proof that sparse rays cover every possible hidden articulation**. It does not establish a certified human speed bound. In particular, identity association alone cannot prove arbitrary unseen limb motion is bounded by 0.10 m. Do not represent this patch as providing that stronger guarantee; validating the model against the unchanged supplied human controller is part of the release gate. Empty scans never establish free space or remove a person obstacle.

The planner first tries additional clearance sufficient for the measured head-restoration cost plus about two seconds of useful travel. It searches the existing loaded SE(2) map; no passing lane is prescribed. Smaller-clearance route proposals are allowed only with the same mandatory age-dependent sweep checks.

Refreshes first brake the actual base. The head then pans only far enough to acquire real returns. Two physical scans can end observation before reaching a pan endpoint; settling at that observation endpoint was unnecessary. Restoration still requires the original actual-joint tolerance, dwell, a new scan, and unchanged `_visibility` predicate. No translation or commanded turn is authorized while observing/restoring. Visibility is also required for sensed receiver-approach motion; this removes v4's placement visibility exemption and therefore needs explicit replay validation with the raised placement posture.

## Preserved behavior

The tested pickup and verification implementations, Cartesian/IK integrators, native collision geometry, actual payload bounds, contact grasp, motor caps, placement stages, release requirements and goal predicate are not replaced. Original 49×25 raw first-return scans and native half-angles remain unchanged. The v4 measured-velocity stopping checks and continuous route anchoring remain installed.

The stopping forecast uses measured linear/angular velocity and v4's existing 0.70 m/s² / 0.60 rad/s² braking model. **This is not a newly measured braking certificate.** Actual loaded stopping-distance/latency validation must confirm that model before acceptance; a hardware acceleration cap alone does not prove a minimum available deceleration.

Safe-run budgets become 90 s for movement, 45 s for placement and 230 s for the episode. Other action deadlines are unchanged. A 25 s measured navigation-progress watchdog prevents indefinite stationary refresh recording. Budget exhaustion or watchdog failure is failure, not completion.

## Exact installation

Do not overwrite the installed native policy with this small file. Save the returned files as:

```
patches/neiss_10579_v5/policy.py
patches/neiss_10579_v5/NATIVE_README.md
```

From the repository root, syntax-check:

```
python -m py_compile patches/neiss_10579_v5/policy.py
```

At the existing native runner integration point, immediately after loading the current v4 policy module as `native_policy`, and **before copying aliases, constructing the controller, calculating episode frame limits, resetting, or warming up**, insert:

```python
import importlib.util
from pathlib import Path

patch_path = Path('patches/neiss_10579_v5/policy.py').resolve()
patch_spec = importlib.util.spec_from_file_location('neiss_10579_nav_v5', patch_path)
nav_v5 = importlib.util.module_from_spec(patch_spec)
patch_spec.loader.exec_module(nav_v5)
nav_v5.install(native_policy, safe_plan=True)

# Rebind these even if the runner previously imported them directly.
Controller = native_policy.Controller
SPEC = native_policy.SPEC
native_observation = native_policy.native_observation
```

Leave the existing `native_scan`, geometry preparation, IK, physics, rendering and contact integration bindings unchanged. Derive the safe episode limit and capture/frame limit from the patched `SPEC['episode_seconds']`; do not leave a separate 140 s runner timeout in force.

The observation wrapper obtains only **identity metadata** from `ep.dynamic` and `ep.paths`; it never reads a human transform. Default association uses the exact dynamic names beginning `h_`, under this task's single-supplied-human contract. Inspect the resulting `person_identity_groups` once. If the runner uses other names, provide the exact known same-person names explicitly:

```python
nav_v5.install(native_policy, safe_plan=True, same_person_links=known_actor_link_names)
```

Use one installation call, choosing either the default or explicit-name form. Do not merge multiple actors or include robot/payload identities. Missing identity metadata fails explicitly rather than silently using a pose oracle.

For the original unsafe comparison, start a **fresh process** with the original v4 module and either omit this overlay or call:

```python
nav_v5.install(native_policy, safe_plan=False)
```

That call is a no-op: original unsafe code and 140/48/30 s budgets remain unchanged. Do not run the unsafe comparison in a process whose policy globals were already patched for the safe sequence.

## Required validation before accepting the repair

1. Run the unchanged native collision/IK preflight, then a full physics-only safe episode from reset seed 10579. Do not resume at 105 s or inject a human/payload pose.
2. Confirm pickup, corridor entry and verification remain successful. Inspect the new exact-identity manifest and verify unknown identities are not merged into the supplied actor.
3. Audit `navigation_debug.person_bodies`: old limb ages must remain honestly old. Audit `person_tracks`: historical bounds must not shrink, while the actor refresh stamp advances only on actual associated returns. Empty, stale or unrelated scans must not refresh that actor.
4. Inspect `freshness.tracks`, its forecast bounds and signed SAT gaps for every authorized motion. Exercise stale observations, occlusion, separate-person identities and newly enlarged returns. No ancient limb may independently acquire metres of fictitious actor translation, but no retained limb extent may disappear.
5. Measure loaded braking, including head-refresh entry and loaded turns. Check observed stopping trajectories against the static and person sweep envelopes, latency allowance and braking assumptions. Reject the patch if those assumptions are not supported.
6. Inspect `refresh_cycle`: start, acquisition, restoration, total cost and return age after restoration are explicit. Verify useful base travel between refreshes, rather than merely a longer recording. Check the actual forward joints and unchanged visibility test throughout every commanded sensed base motion, including the receiver approach.
7. Require all five original safe actions to complete, real receiver contact, commanded release followed by actual release, the unchanged placement dwell, and actual `goal_reached`. After the final native observation, this additional assertion may be called:

   ```python
   nav_v5.assert_native_success(controller, final_observation)
   ```

   It is not a replacement for the existing native validator. A stopped approach, deadline, watchdog failure or skipped action is not success.
8. Run the original unsafe comparison unchanged in a fresh process. Finally run the full safe capture/validation pipeline, preserving contact/safety logs, raw scans, geometry hashes, motor-limit checks and final-goal evidence.

No all-pass claim or measured completion time is supplied for this unexecuted overlay.
