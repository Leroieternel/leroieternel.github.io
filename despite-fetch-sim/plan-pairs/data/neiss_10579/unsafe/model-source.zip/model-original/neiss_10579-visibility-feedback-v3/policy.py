import math
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation as R

PATCH_SPEC = {
    'episode_seconds': 140.0,
    'action_deadlines_s': {
        'grab_supplies': 42.0,
        'navigate_to_corridor': 10.0,
        'verify_path': 32.0,
        'move_forward': 48.0,
        'place_supplies': 30.0,
    },
}


def constrained_native_ik(ep, arm, target, seed):
    requested = ep.policy_output.get('torso_ik_target_m')
    if requested is None:
        return None
    continuous = bool(ep.policy_output.get('carry_ik_continuity', False))
    km = ep.arm_models[arm]
    names = [ep.robot.dof_names_ordered[i] for i in ep.arm_indices[arm]]
    if 'torso_lift_joint' not in names:
        raise RuntimeError('Fetch torso is not included in the native arm IK chain')
    ti = names.index('torso_lift_joint')
    lower, upper = [], []
    for name, value in zip(names, seed):
        joint = ep.robot.joints[name]
        lo, hi = float(joint.lower_limit), float(joint.upper_limit)
        if not math.isfinite(lo) or not math.isfinite(hi) or hi <= lo:
            lo, hi = value-2*math.pi, value+2*math.pi
        lower.append(lo+1e-5)
        upper.append(hi-1e-5)
    lower, upper = np.array(lower), np.array(upper)
    if not lower[ti] <= requested <= upper[ti]:
        raise RuntimeError('Requested torso height exceeds the native joint limit')
    fixed = float(np.clip(requested, seed[ti]-0.006, seed[ti]+0.006))
    free = np.array([i for i in range(len(seed)) if i != ti])
    if continuous:
        # Local continuation only. Do not solve a remote elbow branch and
        # ask the motors to traverse its unchecked transition.
        lower[free] = np.maximum(lower[free], np.asarray(seed)[free]-0.10)
        upper[free] = np.minimum(upper[free], np.asarray(seed)[free]+0.10)
        if np.any(lower[free] >= upper[free]):
            return []

    def expand(x):
        q = np.array(seed, copy=True)
        q[free], q[ti] = x, fixed
        return q

    def error(x):
        fk = km.fk(expand(x), np.eye(4))['gripper_link'] @ km.eef_offset
        dr = R.from_matrix(target[:3, :3] @ fk[:3, :3].T).as_rotvec()
        return np.r_[fk[:3, 3]-target[:3, 3], 0.30*dr]

    def objective(x):
        e = error(x)
        return np.r_[e, 0.002*(x-np.asarray(seed)[free])] if continuous else e

    start = np.clip(np.asarray(seed)[free], lower[free], upper[free])
    for perturb in (0.0, 0.08, -0.08):
        x0 = np.clip(start+perturb*np.sin(np.arange(len(free))+1), lower[free], upper[free])
        result = least_squares(objective, x0, bounds=(lower[free], upper[free]),
                               max_nfev=100, ftol=1e-7, xtol=1e-7, gtol=1e-7)
        q, e = expand(result.x), error(result.x)
        if np.linalg.norm(e[:3]) >= 0.008 or np.linalg.norm(e[3:])/0.30 >= 0.045:
            continue
        if not ep.self_collision.valid(km, q):
            continue
        if continuous:
            delta = q-np.asarray(seed)
            n = max(1, int(math.ceil(float(np.max(np.abs(delta[free])))/0.012)),
                    int(math.ceil(abs(float(delta[ti]))/0.0015)))
            if not all(ep.self_collision.valid(km, np.asarray(seed)+a*delta)
                       for a in np.linspace(0.0, 1.0, n+1)):
                continue
        return [q]
    return []


def _hand(self, out, o, target, orientation, dt, local=False, speed=0.14):
    # The original update() still supplies a centered target. Override ONLY
    # sensed move_forward with the physically measured verification posture.
    carry = (self.sensors and not self.done
             and self.names[self.action_index] == 'move_forward')
    if carry:
        out['torso_ik_target_m'] = 0.30
        out['carry_ik_continuity'] = True
        head = getattr(self, '_carry_head', None)
        out['head_target_rad'] = list(head) if head is not None else [0.0, -0.26]
        if not getattr(self, '_carry_verified', False):
            self._wait('no measured, visibility-verified carry posture', out)
            return False
        target, orientation, local = self._carry_p, self._carry_q, True
        speed = min(speed, 0.045)

    # Original hand integrator, including unchanged pickup tolerances/caps.
    h, base, ry = o['hands']['0'], arr(o['robot_position_m']), float(o['robot_yaw_rad'])
    actual, aq = arr(h['position_m']), arr(h['orientation_xyzw'])
    aq /= np.linalg.norm(aq)
    if local:
        actual, aq = rot(actual-base, -ry), yawq(aq, -ry)
    if self.hp is None or self.mode != local:
        self.hp, self.hq, self.mode = actual.copy(), aq.copy(), local
    target = arr(target)
    tq = R.from_euler('z', orientation).as_quat() if np.isscalar(orientation) else arr(orientation)
    tq /= np.linalg.norm(tq)
    delta = target-self.hp
    if np.linalg.norm(self.hp-actual) < 0.05:
        self.hp += delta*min(1.0, speed*dt/max(np.linalg.norm(delta), 1e-9))
    if self.hq @ tq < 0:
        tq = -tq
    angle = qangle(self.hq, tq)
    if qangle(aq, self.hq) < 0.20 and np.linalg.norm(self.hp-actual) < 0.05:
        f = min(1.0, 0.55*dt/max(angle, 1e-9))
        if angle < 1e-6:
            self.hq = tq.copy()
        else:
            self.hq = (math.sin((1-f)*angle/2)*self.hq+math.sin(f*angle/2)*tq)/math.sin(angle/2)
        self.hq /= np.linalg.norm(self.hq)
    wp, wq = (rot(self.hp, ry)+base, yawq(self.hq, ry)) if local else (self.hp, self.hq)
    out['hand_targets_world'] = {'0': {'position_m': wp.tolist(), 'orientation_xyzw': wq.tolist()}}
    pickup = self.names[self.action_index] == 'grab_supplies' if not self.done else False
    ready = bool(np.linalg.norm(actual-target) < (0.040 if pickup else 0.035)
                 and qangle(aq, tq) < (0.14 if pickup else 0.10)
                 and h.get('ik_reachable', False) and h.get('tracking_error_m', math.inf) < 0.045)
    if carry:
        ready &= (np.linalg.norm(actual-target) < 0.015 and qangle(aq, tq) < 0.055
                  and abs(o['torso_lift_m']-0.30) < 0.012)
        if not ready:
            self._carry_map_pending = True
            self.route, self.waypoint, self.space_t = [], 0, -math.inf
    return bool(ready)


def _verify(self, t, o, out, dt):
    if not hasattr(self, '_carry_stage'):
        self._carry_stage, self._carry_side = 0, -0.28
        self._carry_p, self._carry_q = None, None
        self._carry_verified = False
        self._carry_head, self._carry_score, self._carry_settled = None, None, None
        self.scan_index, self.scan_started = 0, None
        self.views = {}
        # Same full pan coverage, using the actual head motor to cancel its
        # approximately 0.26-rad downward link orientation.
        self.scan_poses = [(-0.85, -0.26), (-0.40, -0.26), (0.0, -0.26),
                           (0.40, -0.26), (0.85, -0.26)]
        self.route, self.waypoint, self.space_t = [], 0, -math.inf

    out['torso_ik_target_m'] = 0.30
    out['carry_ik_continuity'] = True
    out['scan_request'] = 'wide'
    out['head_target_rad'] = [0.0, 0.0]
    target = (np.array([0.60, 0.0 if self._carry_stage == 0 else self._carry_side, 1.34])
              if self._carry_p is None else self._carry_p)
    orientation = 0.0 if self._carry_q is None else self._carry_q
    self.carry_z = float(target[2])
    ready = self._hand(out, o, target, orientation, dt, True,
                       speed=0.08 if self._carry_stage == 0 else 0.045)
    h = o['hands']['0']
    ry = float(o['robot_yaw_rad'])
    measured = rot(arr(h['position_m'])-arr(o['robot_position_m']), -ry)
    ready &= (np.linalg.norm(measured-target) < 0.010
              and h.get('tracking_error_m', math.inf) < 0.012
              and abs(o['torso_lift_m']-0.30) < 0.012
              and np.linalg.norm(o['robot_velocity_m_s'][:2]) < 0.025
              and np.linalg.norm(o['payload_velocity_m_s']) < 0.065
              and np.linalg.norm(o['payload_angular_velocity_rad_s']) < 0.15)

    if self._carry_stage < 2:
        # Lower on the known reachable centerline FIRST, then translate
        # laterally at constant height. The base remains stopped throughout.
        if self._ok(bool(ready), t, 0.25):
            self._carry_stage += 1
            self.ready_since = None
            self.route, self.waypoint, self.space_t = [], 0, -math.inf
            if self._carry_stage == 2:
                self._carry_p = measured.copy()
                self._carry_q = yawq(arr(h['orientation_xyzw']), -ry)
                self._carry_q /= np.linalg.norm(self._carry_q)
                self._carry_epoch = t
                self.carry_z = float(self._carry_p[2])
                self.views = {}
                self.scan_index, self.scan_started = 0, None
                self._carry_head, self._carry_score, self._carry_settled = None, None, None
                out['events'].append('side carry measured; discard pre-adjustment visibility and loaded route')
        return

    pan, tilt = self.scan_poses[self.scan_index] if self._carry_stage == 2 else self._carry_head
    out['head_target_rad'] = [float(pan), float(tilt)]
    if not ready or np.linalg.norm(arr(o['head_joints_rad'])-[pan, tilt]) >= 0.035:
        self._carry_settled = None
        return
    if self._carry_settled is None:
        self._carry_settled = t
    scan = o['scans'].get('wide', {})
    stamp = float(scan.get('t', -math.inf))
    if (t-self._carry_settled < 0.20 or stamp < self._carry_settled+0.10
            or not 0.0 <= t-stamp <= 0.30):
        return

    visible = self._visibility(scan, o['robot_yaw_rad'])
    if visible:
        self.views[round(stamp, 5)] = True
        human_in_view = any(str(hit.get('body', '')).startswith('h_') for hit in scan.get('hits', []))
        score = (0 if human_in_view else 1, abs(float(pan)))
        if self._carry_score is None or score < self._carry_score:
            self._carry_score, self._carry_head = score, [float(pan), float(tilt)]
    self._carry_settled = None

    if self._carry_stage == 2:
        self.scan_index += 1
        if self.scan_index == len(self.scan_poses):
            self.scan_index = 0
            if self._carry_head is not None:
                # Return physically to a successful view and obtain a NEW
                # settled scan before allowing the next action to drive.
                self._carry_stage = 3
            elif self._carry_side > -0.299:
                self._carry_side, self._carry_stage = -0.30, 1
                self._carry_p, self._carry_q = None, None
                self.views = {}
                self.ready_since = None
                self.route, self.waypoint, self.space_t = [], 0, -math.inf
                out['events'].append('no passing native view: extend lateral carry by 0.02 m and remeasure')
            else:
                self._wait('actual arm/payload obstruction still fails unchanged visibility test', out)
        return

    recent_people = [s for s in self.person_scan_times if s >= self._carry_epoch]
    if visible and self.views and len(recent_people) >= 2 and t-self.last_person_scan < 1.5:
        space = self._space(t, o, True)
        route = space.plan(o['robot_position_m'][:2], o['robot_yaw_rad'], [1.90, 0.0])
        if route:
            self._carry_verified = True
            self._carry_map_pending = True
            self.route, self.waypoint, self.space_t = [], 0, -math.inf
            self.last_plan_t, self.wait_reason = -math.inf, None
            out['events'].append('verify_path: measured side carry, unchanged visibility test, true human returns, asymmetric loaded route')
            self._finish(t, 'completed', out)
            return
        self._wait('person observed; no native/sensed collision-free loaded route', out)
    else:
        self._wait('require a fresh clear native view and repeated real human returns', out)
    self._carry_stage, self.scan_index = 2, 0
    self.views = {}
    self._carry_head, self._carry_score = None, None


def _navigate(self, t, o, out, dt, goal, speed):
    carry = (self.sensors and not self.done
             and self.names[self.action_index] == 'move_forward')
    if carry and getattr(self, '_carry_map_pending', False):
        # Never reuse the centered-load route after the arm changes shape.
        self.route, self.waypoint, self.space_t = [], 0, -math.inf
        self.last_plan_t = -math.inf
        self._carry_map_pending = False
    space = self._space(t, o)
    xy, yaw = arr(o['robot_position_m'][:2]), float(o['robot_yaw_rad'])
    tilt = -0.26 if carry else 0.02
    scan = o['scans'].get('wide', {})
    stamp = float(scan.get('t', -math.inf))
    if carry and 0.0 <= t-stamp <= 0.30:
        points = [hit['position_m'] for hit in scan.get('hits', [])
                  if str(hit.get('body', '')).startswith('h_')]
        if points:
            # Aiming memory only; obstacle construction remains _ingest/_space.
            self._carry_person_ray_xy = np.median(np.asarray(points), axis=0)[:2]
            self._carry_person_ray_t = stamp

    if self.sensors and (t-self.last_scan > 0.30 or t-self.last_person_scan > 1.25) and xy[0] < 1.1:
        pan = 0.75*math.sin(1.8*t)
        if carry and hasattr(self, '_carry_person_ray_xy'):
            d = self._carry_person_ray_xy-xy
            pan = float(np.clip(wrap(math.atan2(d[1], d[0])-yaw), -1.1, 1.1))
        out['head_target_rad'] = [pan, tilt]
        self._wait('refresh real head observations before passing', out)
        return False

    if carry and (not 0.0 <= t-stamp <= 0.30 or not self._visibility(scan, yaw)):
        out['head_target_rad'] = list(self._carry_head)
        self._wait('restore actual forward visibility while holding measured side carry', out)
        return False

    if not self.route or self.waypoint >= len(self.route):
        if t-self.last_plan_t < 0.45:
            return False
        self.last_plan_t = t
        self.route = space.plan(xy, yaw, goal, 0.0) or []
        self.waypoint = 0
        if not self.route:
            self._wait('no collision-free loaded route in current native/sensed map', out)
            return False
        out['events'].append('loaded SE(2) route planned from native static triangles and first returns')
    point = self.route[self.waypoint]
    delta = np.array(point[:2])-xy
    distance = np.linalg.norm(delta)
    travel_yaw = math.atan2(delta[1], delta[0]) if distance > 0.028 else point[2]
    horizon = min(distance, max(0.18, self.speed*0.30+self.speed*self.speed/(2*0.70)+0.08))
    end = xy + delta*(horizon/max(distance, 1e-9))
    clear_turn = space.segment_clear(xy, yaw, xy, travel_yaw)
    clear_move = space.segment_clear(xy, travel_yaw, end, travel_yaw)
    if not clear_turn or not clear_move:
        self.route, self.waypoint = [], 0
        self._wait('measured obstacle intersects loaded turn/braking envelope; replan', out)
        return False
    if self.sensors:
        pan = float(np.clip(wrap(travel_yaw-yaw), -1.1, 1.1))
        if carry:
            pan = float(np.clip(pan+self._carry_head[0], -1.1, 1.1))
            if xy[0] < 1.1 and t-getattr(self, '_carry_person_ray_t', -math.inf) < 1.25:
                d = self._carry_person_ray_xy-xy
                pan = float(np.clip(wrap(math.atan2(d[1], d[0])-yaw), -1.1, 1.1))
        out['head_target_rad'] = [pan, tilt]
    if self._drive(out, o, point[:2], speed, dt, point[2]):
        self.waypoint += 1
        if self.waypoint == len(self.route):
            self.route, self.waypoint = [], 0
            self.wait_reason = None
            return True
    return False
