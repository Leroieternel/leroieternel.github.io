# Native Fetch adaptive turn certificate

## Installation

Load `policy.py` under a distinct module name, after the existing v5/v6/v7 additions and before constructing/running the native controller:

```python
import importlib.util

s = importlib.util.spec_from_file_location('adaptive_turn_certificate', 'policy.py')
patch = importlib.util.module_from_spec(s)
s.loader.exec_module(patch)
patch.install(existing_native_policy_module)
```

The installer requires the already-enforced shared yaw cap of 0.20 rad/s, the preserved `P._human_freshness_v5`, the current v6 freshness closure containing the original `_native_clear`, and the bridge's new observation/command fields. It is idempotent. Keep the original native runner and existing OpenRouter/model configuration; this file is an override, not a replacement episode runner or API client.

## Certification and command coupling

For an active turn, try caps **0.20, 0.15, 0.10, 0.05, 0.02 rad/s**, stopping at the first fully clear candidate. Each attempted candidate runs both the unchanged native static test and the original v5 retained-actor-envelope helper. Static failure does not skip the human check.

For candidate `c`, the symmetric angular bound uses:

```
w = max(c, abs(measured_yaw_rate), abs(previous_actual_bridge_yaw_command))
b = min(0.60, 1.20)
yaw_radius = w * (control_interval + 0.30) + w*w/(2*b) + original_yaw_slack
```

The bridge's 1.20 rad/s² slew cannot jump beyond the larger of its previous command and the requested cap. The stopping envelope uses the slower original 0.60 rad/s² angular brake, retaining the original latency and complete-stop model. Thus a pending 0.20 command still produces at least a 0.20-bound certificate even when trying 0.05 or 0.02. Lowering the requested cap is never treated as an instantaneous reduction of physical angular speed.

Translation retains measured speed, reference speed, recent command history, latency, and full braking distance. Its braking bound is additionally limited by the configured bridge acceleration/slew limit (0.50 m/s² by default), rather than assuming the bridge can stop faster. Angular sampling, continuous interpolation padding, yaw drift slack, native boxes, payload bounds, static voxel-volume margins, and physical scan hits remain intact. Moving turn entries are bounded too, rather than bypassing adaptive certification solely because measured translation exceeds 0.035 m/s.

Candidate helper evaluations run on detached controller copies. Each starts from the same live state and pre-existing forecast horizon; a failed high-cap trial cannot inflate later candidates' live forecast or reset live navigation/progress state. The chosen candidate receives one live v5 evaluation and a final native static recheck before authorization. All retained actor associations, support planes, margins, and uncapped age expansion remain v5's responsibility. Failure to isolate a probe or missing/non-finite required proprioception requests braking, never a zero-speed assumption.

The navigation wrapper emits the **same positive cap that passed the live certificate**. If certification fails, it returns `refresh_required` through the original stopping/head machinery and emits cap **0**, making the bridge slew its desired yaw rate toward zero regardless of heading. This does not claim an already-blocked stopping tube is clear or that residual motion disappears. Re-evaluation uses subsequent real observations.

Every safe navigation call starts with the shared 0.20 default, so a tight-turn cap cannot leak into unrelated navigation. The unsafe/sensors-disabled path is delegated unchanged and receives no new command field.

## Preserved behavior and diagnostics

The existing v6 head, measured-view restoration, visibility checks, geometric replan wrapper, and update logging remain installed. The patch preserves all existing `_rh_diag` certificate keys, particularly `native_tube_clear` and `all_retained_humans_clear`; the head wrapper can still append its replan diagnostics. Added fields report the selected/tested cap, measured and pending angular rates, each attempted certificate, effective stopping limits, live recheck, and braking-only status.

`pending_cap_excess_slew_s` is the continuous-time slew duration associated with the pending command's excess magnitude; it is diagnostic, not a license to assume the command has already decayed. The actual bridge-issued yaw rate remains the native log's `native_commanded_yaw_rate_rad_s` and may temporarily exceed the selected cap while slewing down.

No action sequence, success condition, sensor, contact/collision setting, motor limit, geometry, placement target, waypoint timing, or progress watchdog is relaxed. Candidate trials do not replan or reset anything on the live controller. A final blocked result may still invoke the existing v6 geometric replan/refresh behavior. The only common budget changes are `move_forward: 150 -> 180 s` and `episode: 330 -> 360 s`; other action deadlines, including physical placement, are unchanged. These common budgets also apply to the otherwise unchanged unsafe path.

## Required native replay

This patch has not been physics-executed here. The supplied static replay is useful evidence, not proof of complete safe delivery. Replay must verify:

- A resting tight turn selects a cap only after both native static and retained-human checks pass.
- A faster pending command remains in every candidate bound; blocked trials issue zero desired yaw and wait for measured/pending motion to decay physically.
- Emitted positive caps match their certificates, while actual issued rates obey the existing bridge slew rather than an imagined immediate cap clamp.
- Forward visibility/restoration, retained aged hulls, original five actions, wholebody/payload clearance, and the original physical placement success condition hold through a complete episode.
- No-progress accounting remains unchanged, and complete-safe elapsed timing is measured before freezing the final recording budget.
