'''Install after the native v5/v6/v7 patches and pending-yaw observation addition.

This module overrides certification, not the runner, bridge, or task actions.
'''
import copy
import math
import numpy as np

CAPS = (.20, .15, .10, .05, .02)
PATCH_INFO = {
    'id': 'native-fetch-adaptive-turn-v8',
    'entrypoint': 'install(existing_native_policy_module)',
    'validation': 'native full-episode replay required; not executed here',
}


def _finite(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('non-finite certificate input')
    return value


def install(P):
    '''Install once, preserving the existing navigation/head/update wrappers.'''
    if getattr(P, '_native_adaptive_turn_v8', False):
        return dict(PATCH_INFO)
    if not getattr(P, '_neiss_receding_turn_v6', False):
        raise RuntimeError('Install the existing v6 navigation wrappers first')
    v5 = getattr(P, '_human_freshness_v5', None)
    previous = P._human_freshness
    native_clear = previous.__globals__.get('_native_clear')
    if not callable(v5) or v5 is previous or not callable(native_clear):
        raise RuntimeError('Original v5 helper and original v6 static test required')
    shared = _finite(P.SPEC['base_yaw_rate_limit_rad_s'])
    if not math.isclose(shared, .20, rel_tol=0., abs_tol=1e-12):
        raise RuntimeError('This patch requires the already-enforced shared .20 cap')
    deadlines = P.SPEC['action_deadlines_s']
    C = P.Controller
    old_nav = C._navigate

    def uncertified(self, t, boxes, poses, yaw, heading, resolution, reason):
        # Preserve the ordinary live actor-envelope ingestion, but authorize
        # neither a turn nor translation when required proprioception is absent.
        self._at_cap = 0.
        result = v5(self, t, boxes, poses, yaw, heading, resolution)
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': None,
            'command_interval_s': None, 'latency_s': .30,
            'forecast_s': None, 'physical_yaw_rate_bound_rad_s': None,
            'yaw_interval_rad': None, 'translation_radius_m': None,
            'interpolation_padding_m': None,
            'native_tube_clear': False, 'all_retained_humans_clear': False,
            'selected_command_cap_rad_s': 0.,
            'certified_command_cap_rad_s': None,
            'pending_yaw_rate_command_rad_s': None,
            'measured_yaw_rate_rad_s': None,
            'candidate_certificates': [], 'braking_only': True,
            'reason': reason,
        }
        return dict(result, decision='refresh_required', reason=reason)

    def freshness(self, t, boxes, poses, yaw, heading, resolution):
        frame = getattr(self, '_rh_frame', None)
        kinds = getattr(self, '_nav_kinds', ())
        active = (self.sensors and frame is not None and frame[0] == t
                  and 0 <= self.waypoint < len(kinds)
                  and kinds[self.waypoint] == 'turn')
        if not active:
            return previous(self, t, boxes, poses, yaw, heading, resolution)
        _, o, dt = frame
        try:
            now = _finite(t)
            hz = _finite(P.SPEC['control_hz'])
            if hz <= 0.:
                raise ValueError('invalid control frequency')
            tick = max(_finite(dt), 1. / hz)
            centre_yaw = _finite(o['robot_yaw_rad'])
            target = _finite(heading)
            # Neither missing measurement is silently replaced with zero.
            measured_w = _finite(self._nav_measured_w)
            pending_w = _finite(o['base_yaw_rate_command_rad_s'])
            position = np.asarray(o['robot_position_m'], float)
            velocity = np.asarray(o['robot_velocity_m_s'][:2], float)
            b = np.asarray(boxes, float)
            if (position.shape != (3,) or velocity.shape != (2,)
                    or b.ndim != 3 or b.shape[1:] != (2, 3) or len(b) == 0
                    or not np.isfinite(position).all()
                    or not np.isfinite(velocity).all()
                    or not np.isfinite(b).all()
                    or np.any(b[:, 0] > b[:, 1])):
                raise ValueError('invalid measured geometry or velocity')
            latency, yaw_slew = .30, 1.2
            # Use the slower stopping envelope, never an instantaneous change
            # of bridge command. The original angular braking model is .60.
            angular_brake = min(.60, yaw_slew)
            linear_brake = min(.70, _finite(
                P.SPEC.get('base_acceleration_limit_m_s2', .5)))
            slack = _finite(P.SPEC['loaded_stop_yaw_slack_rad'])
            if linear_brake <= 0. or slack < 0.:
                raise ValueError('invalid stopping model')
            initial_horizon = max(0., _finite(
                getattr(self, '_coherent_stop_horizon', 0.)))
            pending_v = 0.
            for stamp, speed in getattr(self, '_rh_commands', ()):
                stamp, speed = _finite(stamp), abs(_finite(speed))
                if now - stamp <= latency + tick:
                    pending_v = max(pending_v, speed)
            v = max(_finite(np.linalg.norm(velocity)),
                    abs(_finite(self.speed)), pending_v)
            xy_radius = v * (tick + latency) + v * v / (2. * linear_brake)
            radial = _finite(np.linalg.norm(
                np.maximum(np.abs(b[:, 0, :2]), np.abs(b[:, 1, :2])),
                axis=1).max())
        except (KeyError, AttributeError, TypeError, ValueError, OverflowError) as exc:
            return uncertified(self, t, boxes, poses, yaw, heading, resolution,
                               'turn certificate unavailable; brake: ' + str(exc))

        attempts = []
        for cap in CAPS:
            # A smaller requested cap cannot erase either actual angular
            # motion or the previous actual, still-slewing bridge command.
            w = max(cap, abs(measured_w), abs(pending_w))
            horizon = max(initial_horizon, tick + latency + max(
                v / linear_brake, w / angular_brake))
            radius = (w * (tick + latency)
                      + w * w / (2. * angular_brake) + slack)
            count = max(2, int(math.ceil(2. * radius / .025)))
            angles = np.linspace(centre_yaw - radius, centre_yaw + radius, count + 1)
            gap = 2. * radius / count
            interpolation = 2. * radial * math.sin(gap / 4.)
            expanded = b.copy()
            expanded[:, 0, :2] -= xy_radius + interpolation
            expanded[:, 1, :2] += xy_radius + interpolation
            bounded_poses = [(position[:2].copy(), float(a)) for a in angles]

            # Always run BOTH checks for each attempted cap. Reuse the exact
            # installed native voxel/wholebody/payload test without modification.
            static_ok = bool(native_clear(o, expanded, angles, self.extra_hits, P.SPEC))
            try:
                probe = copy.deepcopy(self)
            except Exception as exc:
                return uncertified(
                    self, t, boxes, poses, yaw, heading, resolution,
                    'cannot isolate candidate evaluation; brake: ' + type(exc).__name__)
            # Every candidate starts from the same live state and baseline
            # forecast. Failed trials cannot age/reset/mutate the live tracker,
            # route, head state, commands, progress accounting, or watchdog.
            probe._coherent_stop_horizon = horizon
            proof = v5(probe, t, expanded, bounded_poses,
                       centre_yaw, target, resolution)
            human_ok = proof['decision'] != 'refresh_required'  # Original v5 contract.
            attempts.append({
                'command_cap_rad_s': cap,
                'physical_yaw_rate_bound_rad_s': w,
                'forecast_s': horizon,
                'yaw_radius_rad': radius,
                'native_tube_clear': static_ok,
                'all_retained_humans_clear': bool(human_ok),
            })
            if static_ok and human_ok:
                break

        # Commit only ONE ordinary live v5 evaluation. Recheck the static tube
        # afterward as well; any difference from the detached probe fails closed.
        # If all trials failed, this is the last (.02) conservative tube, which
        # also contains a zero-desired-yaw braking command and its pending motion.
        self._coherent_stop_horizon = horizon
        result = v5(self, t, expanded, bounded_poses,
                    centre_yaw, target, resolution)
        static_ok = bool(native_clear(o, expanded, angles, self.extra_hits, P.SPEC))
        human_ok = result['decision'] != 'refresh_required'
        clear = static_ok and human_ok
        selected = cap if clear else 0.
        self._at_cap = selected
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': abs(
                (target - centre_yaw + math.pi) % (2. * math.pi) - math.pi),
            'command_interval_s': tick, 'latency_s': latency,
            'forecast_s': horizon, 'physical_yaw_rate_bound_rad_s': w,
            'yaw_interval_rad': [float(angles[0]), float(angles[-1])],
            'translation_radius_m': xy_radius,
            'interpolation_padding_m': interpolation,
            'native_tube_clear': bool(static_ok),
            'all_retained_humans_clear': bool(human_ok),
            'measured_yaw_rate_rad_s': measured_w,
            'pending_yaw_rate_command_rad_s': pending_w,
            'command_cap_tested_rad_s': cap,
            'selected_command_cap_rad_s': selected,
            'certified_command_cap_rad_s': cap if clear else None,
            'yaw_command_slew_limit_rad_s2': yaw_slew,
            'effective_angular_brake_rad_s2': angular_brake,
            'effective_linear_brake_m_s2': linear_brake,
            'pending_cap_excess_slew_s': max(0., abs(pending_w) - selected) / yaw_slew,
            'candidate_certificates': attempts,
            'live_recheck_clear': bool(clear),
            'braking_only': not clear,
        }
        if not clear:
            reason = ('native pending-aware turn tube blocked; brake first'
                      if not static_ok else
                      'retained human envelope blocks turn tube; brake first')
            self._rh_diag['reason'] = reason
            return dict(result, decision='refresh_required', reason=reason)
        return result

    def navigate(self, t, o, out, dt, goal, speed):
        if not self.sensors:
            # No new field, certification, or control change on the unsafe path.
            return old_nav(self, t, o, out, dt, goal, speed)
        self._at_cap = shared
        try:
            # The existing v6 wrapper supplies _rh_frame and retains its normal
            # head/visibility/replan logic. Its old_nav resolves the helper below.
            return old_nav(self, t, o, out, dt, goal, speed)
        finally:
            out['base_yaw_rate_cap_rad_s'] = float(self._at_cap)
            self._at_cap = shared

    P._human_freshness = freshness
    C._navigate = navigate
    # Only the expressly permitted common finite-budget extension. No progress
    # timer, action start time, route, or placement condition is reset or changed.
    deadlines['move_forward'] = 180.0
    P.SPEC['episode_seconds'] = 360.0
    P._native_adaptive_turn_v8 = True
    return dict(PATCH_INFO)
