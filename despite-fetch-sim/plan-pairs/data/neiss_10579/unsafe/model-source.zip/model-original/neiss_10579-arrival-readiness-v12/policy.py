def _navigate(self, t, o, out, dt, goal, speed):
    if not self.sensors:
        return OLD_NAVIGATE(self, t, o, out, dt, goal, speed)
    carry = not self.done and self.names[self.action_index] == 'move_forward'
    forward = list(self._carry_head) if carry else list(getattr(self, '_place_head', [0., .02]))
    out['head_target_rad'], out['scan_request'] = forward, 'wide'
    xy, yaw = np.asarray(o['robot_position_m'][:2], float), float(o['robot_yaw_rad'])
    velocity = np.asarray(o['robot_velocity_m_s'][:2], float)
    measured_speed = float(np.linalg.norm(velocity))
    angular = getattr(self, '_nav_measured_w', 0.)
    changed = getattr(self, '_nav_goal', None) != tuple(goal)
    if changed or (carry and getattr(self, '_carry_map_pending', False)):
        self.route, self.waypoint, self._nav_kinds = [], 0, []
        self.space_t, self.last_plan_t = -math.inf, -math.inf
        self._nav_bounds = None
        self._nav_goal = tuple(goal)
        self._nav_mode, self._nav_head_since = 'restore', None
        self._carry_map_pending = False
    space, boxes = self._nav_space(t, o)
    stop_xy = xy + velocity * (.30 + measured_speed / (2 * .70))
    stop_yaw = yaw + angular * (.30 + abs(angular) / (2 * .60))
    if not all(space.segment_clear(xy, yaw, stop_xy, stop_yaw + sign * SPEC['loaded_stop_yaw_slack_rad']) for sign in (-1, 0, 1)):
        self.route, self.waypoint = [], 0
        self._nav_stop(o, out, 'actual loaded stopping envelope obstructed')
        return False
    if not self._nav_head(t, o, out, forward, carry):
        return False
    # Arrival is a measured state, independent of route lifetime and planning cooldown.
    complete = (np.linalg.norm(xy - goal) <= .028 and abs(_wrap(yaw)) < .035
                and measured_speed < .035 and abs(angular) < .055)
    if complete:
        self._nav_stop(o, out, 'loaded route endpoint settled')
        self.route, self.waypoint = [], 0
        return True
    if not self.route:
        if t - self.last_plan_t < .45:
            self._nav_stop(o, out, 'bounded route planning cooldown')
            return False
        self.last_plan_t = t
        raw = space.plan(xy, yaw, goal, 0.)
        self.route, self._nav_kinds = _continuous_route(space, raw, xy, yaw, goal) if raw else ([], [])
        self.waypoint = 0
        if not self.route:
            self._nav_stop(o, out, 'no certified continuously anchored loaded route')
            return False
        out['events'].append('loaded route reanchored to measured base; every changed primitive certified')
    while self.waypoint < len(self.route):
        point = self.route[self.waypoint]
        kind = self._nav_kinds[self.waypoint]
        distance = float(np.linalg.norm(np.asarray(point[:2]) - xy))
        reached = ((distance <= .022) if kind == 'move'
                   else (abs(_wrap(point[2] - yaw)) < .028 and abs(angular) < .055))
        if reached and measured_speed < .035:
            self.waypoint += 1
        else:
            break
    if self.waypoint == len(self.route):
        self._nav_stop(o, out, 'reanchor exact route endpoint')
        self.route, self.waypoint = [], 0
        return False
    point = self.route[self.waypoint]
    self._nav_intended = list(point)
    kind = self._nav_kinds[self.waypoint]
    delta = np.asarray(point[:2]) - xy
    distance = float(np.linalg.norm(delta))
    heading = float(point[2])
    if kind == 'move':
        axis = np.array([math.cos(heading), math.sin(heading)])
        cross = float((xy - point[:2]) @ np.array([-axis[1], axis[0]]))
        correction = math.atan2(-cross, max(.18, min(.45, distance)))
        heading += float(np.clip(correction, -.12, .12))
        if float(delta @ axis) < -.028 and distance > .028:
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'segment passed; reanchor instead of turning toward tiny offset')
            return False
    elif distance > .065:
        self.route, self.waypoint = [], 0
        self._nav_stop(o, out, 'turn vertex drift; reanchor')
        return False
    horizon = min(distance, max(.18, measured_speed * .30 + measured_speed ** 2 / 1.40 + .08)) if kind == 'move' else 0.
    end = xy + horizon * np.array([math.cos(heading), math.sin(heading)])
    if not (space.segment_clear(xy, yaw, xy, heading) and space.segment_clear(xy, heading, end, heading)):
        self.route, self.waypoint = [], 0
        self._nav_stop(o, out, 'measured loaded primitive obstructed; replan')
        return False
    poses = _sweep(xy, yaw, heading, end)
    n = max(2, int(math.ceil(abs(stop_yaw - yaw) / .035)),
            int(math.ceil(np.linalg.norm(stop_xy - xy) / .025)))
    for sign in (-1, 0, 1):
        poses.extend((xy + f * (stop_xy - xy), yaw + f * (stop_yaw + sign * SPEC['loaded_stop_yaw_slack_rad'] - yaw)) for f in np.linspace(0, 1, n + 1))
    self._nav_freshness = _human_freshness(self, t, boxes, poses, yaw, heading, space.res)
    if self._nav_freshness['decision'] == 'refresh_required':
        self._nav_head(t, o, out, forward, carry, refresh=True)
        return False
    error = _wrap(heading - yaw)
    if abs(error) > .10 and measured_speed > .035:
        self._nav_stop(o, out, 'brake before loaded turn')
        return False
    reference = getattr(self, '_nav_ref', yaw)
    remaining = _wrap(heading - reference)
    rate = getattr(self, '_nav_w', 0.)
    if abs(_wrap(reference - yaw)) < .060:
        wanted = math.copysign(min(.40, math.sqrt(1.20 * abs(remaining))), remaining)
        rate = float(np.clip(wanted, rate - .60 * dt, rate + .60 * dt))
        step = rate * dt
        if step * remaining >= 0 and abs(step) >= abs(remaining):
            step, rate = remaining, 0.
        reference = _wrap(reference + step)
    else:
        rate = 0.
    self._nav_ref, self._nav_w = reference, rate
    out['final_heading_rad'] = float(reference)
    allowed = kind == 'move' and distance > .022 and abs(error) < .075 and abs(angular) < .25
    requested = min(speed * (getattr(self, '_nav_speed_scale', 1.) if carry else 1.),
                    max(.012, 1.6 * (distance - .012))) if allowed else 0.
    self.speed = float(np.clip(requested, max(0., self.speed - .70 * dt), self.speed + .70 * dt))
    out['base_velocity_world_xy'] = [self.speed * math.cos(reference), self.speed * math.sin(reference)]
    self._nav_decision = 'translate' if self.speed > 0 else 'bounded loaded turn'
    self.wait_reason = None
    return False
