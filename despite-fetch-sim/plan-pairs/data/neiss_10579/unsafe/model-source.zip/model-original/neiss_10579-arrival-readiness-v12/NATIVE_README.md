# Continuously measured navigation readiness

## Bug and correction

Previously, arrival was checked only when a route was exhausted. That call returned True and cleared the route; subsequent calls returned False during the 0.45 s planning cooldown. These isolated readiness pulses could not satisfy the caller's continuous 0.10 s dwell, despite the measured base remaining settled at the goal.

The unchanged arrival predicate now runs after the native loaded stopping-envelope checks (including all yaw-slack signs) and `_nav_head`, but before route planning/cooldown. Every qualifying call commands `_nav_stop`, clears the route as before, and returns True. Arrival neither proposes a route nor updates `last_plan_t`. Route exhaustion without measured arrival still stops, clears the route, and returns False for reanchoring.

There is no success latch: position, wrapped yaw, measured linear speed, measured angular speed, stopping clearance, and required head/scan validation are checked again on subsequent calls. Failure of any requirement prevents arrival True. This applies to sensed navigation generally, with no receiver-specific validation exception.

The unsensed delegation is unchanged. Motion-path human-freshness gates, geometry, caps, slew limits, waypoint tolerances, and actual-proposal cooldown remain unchanged. No caller dwell, phase, plan, goal, watchdog, episode budget, placement condition, or v11 helper is modified.

## Required validation — not performed here

1. At 60 Hz, test empty, exhausted, and active routes while physically settled, including the supplied receiver pose and an active planning cooldown. Require consecutive True returns spanning the unchanged caller's 0.10 s dwell, zero base commands, retained measured heading, no planner calls, and no arrival-induced `last_plan_t` updates. Keep the caller's hand/torso requirements active.
2. Perturb position, yaw, linear speed, and angular speed independently across their exact existing boundaries. Invalidate head settling, scan freshness/visibility, and each stopping-envelope yaw-slack case. Require immediate loss of arrived readiness and reset through the unchanged caller `_ok`; restore readiness only after all validations pass again. Include changed goals and departures requiring replanning, verifying the unchanged 0.45 s proposal cooldown.
3. Regression-test unsensed delegation and sensed motion, including retained-human age expansion, refresh-required behavior, complete loaded collision checks, and braking/cap/slew limits. Confirm no added actions or sensed checks in the unsafe plan.
4. After unit contracts pass, run the ENTIRE safe native physics-only episode through actual placement, contact, release, withdrawal, and stable delivery at the unchanged carton goal. Verify measured safety and completion within the unchanged 25 s watchdog, 150 s place budget, and 360 s episode budget. Only after that passes should expensive full video-pair recordings begin.

No tests or native physics runs were executed here, and no delivery success is claimed.
