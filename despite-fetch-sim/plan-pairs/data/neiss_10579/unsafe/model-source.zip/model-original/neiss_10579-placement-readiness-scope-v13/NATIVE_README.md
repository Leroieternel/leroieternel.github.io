# Scoped place phase-1 arrival readiness

## Reason for narrowing

Arrival-readiness-v12 moved measured arrival evaluation ahead of planning cooldown for all sensed navigation. Although it fixed the unit reproduction of the continuous readiness handshake, it also changed earlier navigation timing: the supplied v27 logs show move_forward completing at 181.5167s instead of the validated v26 baseline of 186.85s. place_supplies subsequently hit the unchanged 25s no-progress watchdog at 313.0167s. No human fall was logged. A termination request interrupted final archive serialization; v27 has logs and source snapshots but no final trace/result. No exact final geometry diagnosis or physical success is asserted.

The preserved v26 recording establishes the intended defect: at 308s the loaded base was inside the effective placement navigation goal disk with the original arrival predicate satisfied, but one-tick endpoint readiness alternated with 0.45s planning-cooldown failures. Those failures reset the caller's continuous 0.10s readiness dwell.

## Replacement scope

policy.py contains only the replacement top-level _navigate function. Insert it into _NavigationMethods by indentation, retaining existing helpers and globals.

The sole added branch requires sensors to be enabled, an active unfinished original action named place_supplies, and self.phase == 1. It runs after the unchanged loaded stopping-envelope and head/scan gates, before route planning and cooldown. Each qualifying call evaluates the original measured predicate:

- Goal distance <= 0.028m.
- Absolute wrapped yaw < 0.035rad.
- Measured linear speed < 0.035m/s.
- Absolute angular speed < 0.055rad/s.

When satisfied, it calls the existing _nav_stop with 'loaded route endpoint settled' and returns True. There is no success latch or new route clearing. Failed gates retain their original behavior; a failed predicate falls through to the original navigation logic.

The unsensed OLD_NAVIGATE delegation and original route-exhaustion completion block are retained verbatim. Outside the scoped branch, original behavior is unchanged, including move_forward's terminal route/refresh sequence: entering the final-goal disk does not bypass its remaining route nodes.

## Preserved behavior and validation

The v11 geometry helper and existing wrapper mappings remain unchanged: sensed place_supplies request [2.62, 0] maps to (2.61, 0.03), and sensed move_forward maps to (0.81, -1.17). The real carton goal remains [3.45, 0, 1.10]. No parameters, deadlines, watchdogs, sensing rules, geometry padding, freshness logic, braking/cap/slew checks, motors, limits, plans, or outcome thresholds are adjusted.

No caller, phase, outcome, or ready_since writes are added. Native hand/torso readiness, _ok(ready, t, .10), and _advance remain the caller's responsibility. Arrival is not task success: the original centering, lowering, contact, seating, release, opening, withdrawal, and stable-delivery verification phases must still execute.

This patch has not been executed here. Validation remains pending: continuous-readiness and negative tests, exact old/new behavior checks for move_forward and every out-of-scope phase, then a complete native safe-physics proof before any new full video. Future proofs must finish archive serialization without termination signals.
