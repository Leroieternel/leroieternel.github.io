"""Navigation-only patch. Install into the supplied native policy module.
All helpers outside _NavigationMethods are module-level functions.
"""
import math
import numpy as np
from scipy.spatial.transform import Rotation as R

PATCH_SPEC = {
    'task_id': 'neiss_10579',
    'entrypoint': 'install(existing_native_policy_module)',
    'replaces': ['Controller._hand', 'Controller._navigate', 'Controller.update'],
    'spec_overrides': {},
    'preserves': ['pickup', 'verification', 'placement', 'native_scan',
                  'native_IK', 'CollisionSpace', 'action_deadlines', 'goal'],
    'verification_status': 'trace-audited; replacement not simulated here'
}


def _wrap(a):
    return (float(a) + math.pi) % (2 * math.pi) - math.pi


def _finite_age(t, stamp):
    age = float(t - stamp)
    return age if math.isfinite(age) else None


def _loaded_boxes(o):
    """Actual native-link bounds and actual measured carton, in base coordinates."""
    boxes = np.asarray(o['native_link_boxes_base_m'], float).copy()
    if o.get('payload_grasped', False):
        half = np.asarray(SPEC['parcel_dimensions_m']) / 2
        vertices = np.array([[x, y, z] for x in (-half[0], half[0])
                             for y in (-half[1], half[1])
                             for z in (-half[2], half[2])])
        vertices = R.from_quat(o['payload_orientation_xyzw']).apply(vertices)
        vertices += np.asarray(o['payload_position_m']) - np.asarray(o['robot_position_m'])
        vertices = R.from_euler('z', -o['robot_yaw_rad']).apply(vertices)
        boxes = np.concatenate((boxes, [[vertices.min(0), vertices.max(0)]]))
    return boxes


def _sweep(xy, yaw, heading, end):
    """Sample the explicitly checked turn-then-translation primitive."""
    turn = _wrap(heading - yaw)
    n = max(2, int(math.ceil(abs(turn) / .035)))
    poses = [(xy, yaw + f * turn) for f in np.linspace(0, 1, n + 1)]
    n = max(2, int(math.ceil(np.linalg.norm(end - xy) / .025)))
    poses.extend((xy + f * (end - xy), heading) for f in np.linspace(0, 1, n + 1))
    return poses


def _continuous_route(space, raw, xy, yaw, goal):
    """Reanchor lattice primitives; never drive toward the root cell centre.

    Correct the terminal cell to the exact requested goal. Every changed
    translation and every turn is checked again in the actual loaded map.
    Returned route entries remain ordinary [x, y, yaw] Controller waypoints.
    """
    root = np.asarray(raw[0][:2])
    terminal = np.asarray(raw[-2][:2]) if len(raw) > 1 else root
    displacement = xy - root
    for offset in (displacement, .5 * displacement, np.zeros(2)):
        route, kinds = [], []
        valid = True

        def emit(p, a, kind, mandatory=False):
            nonlocal valid
            previous = route[-1] if route else [*xy, yaw]
            p = np.asarray(p)
            if not mandatory and np.linalg.norm(p - previous[:2]) < 1e-8 and abs(_wrap(a - previous[2])) < 1e-8:
                return
            if not space.segment_clear(previous[:2], previous[2], p, a):
                valid = False
                return
            value = [float(p[0]), float(p[1]), float(a)]
            if kind == 'turn' and kinds and kinds[-1] == 'turn':
                before = route[-2] if len(route) > 1 else [*xy, yaw]
                if np.linalg.norm(p - route[-1][:2]) < 1e-8 and space.segment_clear(before[:2], before[2], p, a):
                    route[-1] = value
                    return
            route.append(value)
            kinds.append(kind)

        current = xy.copy()
        for i, node in enumerate(raw):
            p = np.asarray(node[:2]) + offset
            if np.linalg.norm(np.asarray(node[:2]) - root) < 1e-8:
                p = xy.copy()
            if i == len(raw) - 1 or np.linalg.norm(np.asarray(node[:2]) - terminal) < 1e-8:
                p = np.asarray(goal, float)
            delta = p - current
            if np.linalg.norm(delta) > 1e-8:
                bearing = math.atan2(delta[1], delta[0])
                emit(current, bearing, 'turn')
                emit(p, bearing, 'move')
            emit(p, float(node[2]), 'turn')
            current = p
            if not valid:
                break
        if valid:
            emit(goal, 0.0, 'turn', mandatory=True)
            if valid:
                return route, kinds
    return [], []


def _human_freshness(controller, t, boxes, poses, yaw, heading, resolution):
    """Freshness from retained first-return envelopes, never human poses.

    Preserve the original obstacle inflation. Beyond 1.25 s add UNCAPPED
    uncertainty growth; stale observations grant motion only while that
    enlarged envelope misses the complete proposed stopping/motion sweep.
    This is a conservative planning forecast, not a claimed human speed bound.
    """
    age = t - controller.last_person_scan
    records = [(np.asarray(points, float), max(0., t - stamp))
               for points, stamp in controller.people_by_body.values() if len(points)]
    if not records:
        return {'decision': 'refresh_required', 'behind_gap_m': None}
    if 0 <= age <= 1.25:
        return {'decision': 'fresh', 'behind_gap_m': None}
    points = np.concatenate([p[:, :2] for p, _ in records])
    radii = np.concatenate([np.full(len(p), SPEC['sensed_person_surface_margin_m']
                         + min(.10, .035 * (a + .30)) + resolution / 2
                         + .10 * max(0., a - 1.25)) for p, a in records])
    # Include native map clearance, footprint cache padding and sweep sampling.
    margin = SPEC['static_clearance_m'] + resolution / math.sqrt(2) + .035
    low, high = boxes[:, 0, :2] - margin, boxes[:, 1, :2] + margin
    vertices = np.stack((low, high, np.c_[low[:, 0], high[:, 1]],
                         np.c_[high[:, 0], low[:, 1]]), axis=1).reshape(-1, 2)
    axis = np.array([math.cos(yaw), math.sin(yaw)])
    rear, intersects = math.inf, False
    for p, a in poses:
        c, s = math.cos(a), math.sin(a)
        rotation = np.array([[c, -s], [s, c]])
        rear = min(rear, float(np.min((vertices @ rotation.T + p) @ axis)))
        local = (points - p) @ rotation
        separation = np.maximum(np.maximum(low[None] - local[:, None],
                                            local[:, None] - high[None]), 0.)
        intersects |= bool(np.any(np.sum(separation * separation, axis=2) <= radii[:, None] ** 2))
    gap = rear - float(np.max(points @ axis + radii))
    behind = gap > .10 and math.cos(_wrap(heading - yaw)) > .25
    decision = 'behind_loaded_sweep' if behind else ('refresh_required' if intersects else 'aged_envelope_clear')
    return {'decision': decision, 'behind_gap_m': float(gap)}


class _NavigationMethods:
    """Only these methods are installed on the existing Controller."""

    def _nav_stop(self, o, out, reason):
        yaw = float(o['robot_yaw_rad'])
        out['final_heading_rad'] = yaw
        self._nav_ref, self._nav_w, self.speed = yaw, 0., 0.
        self._nav_decision = reason
        self._wait(reason, out)

    def _nav_space(self, t, o):
        boxes = _loaded_boxes(o)
        cached = getattr(self, '_nav_bounds', None)
        contained = (cached is not None and cached.shape == boxes.shape
                     and np.all(boxes[:, 0] >= cached[:, 0])
                     and np.all(boxes[:, 1] <= cached[:, 1]))
        if (self.space is None or not contained or t - self.space_t >= .30
                or getattr(self, '_nav_map_scan', None) != self.last_scan):
            expanded = boxes.copy()
            expanded[:, 0] -= .010
            expanded[:, 1] += .010
            measured = dict(o, native_link_boxes_base_m=expanded.tolist())
            people = [(p, max(0., t - stamp) + .30)
                      for p, stamp in self.people_by_body.values()]
            # CollisionSpace also adds the actual carton; neither it nor any
            # native link is removed. Padding covers cache-time motor jitter.
            self.space = SPACE(measured, people, self.extra_hits)
            self.space_t, self._nav_map_scan = t, self.last_scan
            self._nav_bounds = expanded
        return self.space, boxes

    def _nav_head(self, t, o, out, forward, require_visibility, refresh=False):
        scan = o.get('scans', {}).get('wide', {})
        stamp = float(scan.get('t', -math.inf))
        fresh = (0 <= t - stamp <= .30 and 'directions_world' in scan
                 and 'first_hit_body' in scan)
        visible = fresh and self._visibility(scan, float(o['robot_yaw_rad']))
        mode = getattr(self, '_nav_mode', 'restore')
        if refresh and mode == 'drive':
            points = [p for group, _ in self.people_by_body.values() for p in group]
            bearing = 0.
            if points:
                delta = np.median(np.asarray(points), axis=0)[:2] - np.asarray(o['robot_position_m'][:2])
                bearing = _wrap(math.atan2(delta[1], delta[0]) - o['robot_yaw_rad'])
            self._nav_pans = sorted((-.85, -.40, 0., .40, .85), key=lambda a: abs(_wrap(a - bearing)))
            self._nav_pan_index, self._nav_head_since = 0, None
            mode = 'observe'
        if mode == 'drive':
            out['head_target_rad'] = list(forward)
            if fresh and (visible or not require_visibility) and np.linalg.norm(np.asarray(o['head_joints_rad']) - forward) < .035:
                self._nav_mode = mode
                return True
            mode, self._nav_head_since = 'restore', None
        self._nav_mode = mode
        target = ([self._nav_pans[self._nav_pan_index], forward[1]]
                  if mode == 'observe' else list(forward))
        out['head_target_rad'] = list(target)
        self._nav_stop(o, out, 'stationary real-ray refresh' if mode == 'observe' else 'restore settled actual forward view')
        if np.linalg.norm(np.asarray(o['head_joints_rad']) - target) >= .035:
            self._nav_head_since = None
            return False
        if getattr(self, '_nav_head_since', None) is None:
            self._nav_head_since = t
        settled = self._nav_head_since
        if not fresh or t - settled < .18 or stamp < settled + .08:
            return False
        if mode == 'observe':
            if any(PERSON(hit) for hit in scan.get('hits', [])):
                self._nav_mode, self._nav_head_since = 'restore', None
                out['head_target_rad'] = list(forward)
            else:
                self._nav_pan_index = (self._nav_pan_index + 1) % len(self._nav_pans)
                self._nav_head_since = None
        elif visible or not require_visibility:
            self._nav_mode, self._nav_head_since = 'drive', None
        return False

    def _hand(self, out, o, target, orientation, dt, local=False, speed=.14):
        carry = (self.sensors and not self.done and self.names[self.action_index] == 'move_forward'
                 and getattr(self, '_carry_verified', False))
        if not carry:
            return OLD_HAND(self, out, o, target, orientation, dt, local, speed)
        saved = self.route, self.waypoint, self.space_t, getattr(self, '_carry_map_pending', False)
        original_ready = OLD_HAND(self, out, o, target, orientation, dt, local, speed)
        # Preserve the original Cartesian integrator and native IK. A readiness
        # fluctuation is NOT a new arm target and must not erase route progress.
        self.route, self.waypoint, self.space_t, self._carry_map_pending = saved
        h = o['hands']['0']
        inverse = R.from_euler('z', -o['robot_yaw_rad'])
        measured = inverse.apply(np.asarray(h['position_m']) - o['robot_position_m'])
        measured_q = inverse * R.from_quat(h['orientation_xyzw'])
        error = float(np.linalg.norm(measured - self._carry_p))
        angle = float((measured_q.inv() * R.from_quat(self._carry_q)).magnitude())
        latched = getattr(self, '_nav_hand_latched', bool(original_ready))
        ready = bool(error < (.030 if latched else .015) and angle < (.085 if latched else .055)
                     and h.get('ik_reachable', False) and h.get('tracking_error_m', math.inf) < .045
                     and abs(o['torso_lift_m'] - .30) < .012)
        self._nav_hand_latched = ready
        self._nav_hand_error = error
        self._nav_speed_scale = min(1., max(.25, (.030 - error) / .015), max(.25, (.085 - angle) / .030))
        if not ready:
            self._nav_stop(o, out, 'settle loaded native tracking; retain route proposal')
        return ready

    def _navigate(self, t, o, out, dt, goal, speed):
        if not self.sensors:
            return OLD_NAVIGATE(self, t, o, out, dt, goal, speed)
        carry = not self.done and self.names[self.action_index] == 'move_forward'
        forward = list(self._carry_head) if carry else [0., .02]
        out['head_target_rad'], out['scan_request'] = forward, 'wide'
        xy, yaw = np.asarray(o['robot_position_m'][:2], float), float(o['robot_yaw_rad'])
        velocity = np.asarray(o['robot_velocity_m_s'][:2], float)
        measured_speed = float(np.linalg.norm(velocity))
        angular = getattr(self, '_nav_measured_w', 0.)
        changed = getattr(self, '_nav_goal', None) != tuple(goal)
        if changed or (carry and getattr(self, '_carry_map_pending', False)):
            self.route, self.waypoint, self._nav_kinds = [], 0, []
            self.space_t, self.last_plan_t = -math.inf, -math.inf
            self._nav_bounds = None
            self._nav_goal = tuple(goal)
            self._nav_mode, self._nav_head_since = 'restore', None
            self._carry_map_pending = False
        space, boxes = self._nav_space(t, o)
        stop_xy = xy + velocity * (.30 + measured_speed / (2 * .70))
        stop_yaw = yaw + angular * (.30 + abs(angular) / (2 * .60))
        if not space.segment_clear(xy, yaw, stop_xy, stop_yaw):
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'actual loaded stopping envelope obstructed')
            return False
        if not self._nav_head(t, o, out, forward, carry):
            return False
        if not self.route:
            if t - self.last_plan_t < .45:
                self._nav_stop(o, out, 'bounded route planning cooldown')
                return False
            self.last_plan_t = t
            raw = space.plan(xy, yaw, goal, 0.)
            self.route, self._nav_kinds = _continuous_route(space, raw, xy, yaw, goal) if raw else ([], [])
            self.waypoint = 0
            if not self.route:
                self._nav_stop(o, out, 'no certified continuously anchored loaded route')
                return False
            out['events'].append('loaded route reanchored to measured base; every changed primitive certified')
        while self.waypoint < len(self.route):
            point = self.route[self.waypoint]
            kind = self._nav_kinds[self.waypoint]
            distance = float(np.linalg.norm(np.asarray(point[:2]) - xy))
            reached = ((distance <= .022) if kind == 'move'
                       else (abs(_wrap(point[2] - yaw)) < .028 and abs(angular) < .055))
            if reached and measured_speed < .035:
                self.waypoint += 1
            else:
                break
        if self.waypoint == len(self.route):
            complete = (np.linalg.norm(xy - goal) <= .028 and abs(_wrap(yaw)) < .035
                        and measured_speed < .035 and abs(angular) < .055)
            self._nav_stop(o, out, 'loaded route endpoint settled' if complete else 'reanchor exact route endpoint')
            self.route, self.waypoint = [], 0
            return bool(complete)
        point = self.route[self.waypoint]
        self._nav_intended = list(point)
        kind = self._nav_kinds[self.waypoint]
        delta = np.asarray(point[:2]) - xy
        distance = float(np.linalg.norm(delta))
        heading = float(point[2])
        if kind == 'move':
            axis = np.array([math.cos(heading), math.sin(heading)])
            cross = float((xy - point[:2]) @ np.array([-axis[1], axis[0]]))
            correction = math.atan2(-cross, max(.18, min(.45, distance)))
            heading += float(np.clip(correction, -.12, .12))
            if float(delta @ axis) < -.028 and distance > .028:
                self.route, self.waypoint = [], 0
                self._nav_stop(o, out, 'segment passed; reanchor instead of turning toward tiny offset')
                return False
        elif distance > .065:
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'turn vertex drift; reanchor')
            return False
        horizon = min(distance, max(.18, measured_speed * .30 + measured_speed ** 2 / 1.40 + .08)) if kind == 'move' else 0.
        end = xy + horizon * np.array([math.cos(heading), math.sin(heading)])
        if not (space.segment_clear(xy, yaw, xy, heading) and space.segment_clear(xy, heading, end, heading)):
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'measured loaded primitive obstructed; replan')
            return False
        poses = _sweep(xy, yaw, heading, end)
        n = max(2, int(math.ceil(abs(stop_yaw - yaw) / .035)),
                int(math.ceil(np.linalg.norm(stop_xy - xy) / .025)))
        poses.extend((xy + f * (stop_xy - xy), yaw + f * (stop_yaw - yaw)) for f in np.linspace(0, 1, n + 1))
        self._nav_freshness = _human_freshness(self, t, boxes, poses, yaw, heading, space.res)
        if self._nav_freshness['decision'] == 'refresh_required':
            self._nav_head(t, o, out, forward, carry, refresh=True)
            return False
        error = _wrap(heading - yaw)
        if abs(error) > .10 and measured_speed > .035:
            self._nav_stop(o, out, 'brake before loaded turn')
            return False
        reference = getattr(self, '_nav_ref', yaw)
        remaining = _wrap(heading - reference)
        rate = getattr(self, '_nav_w', 0.)
        if abs(_wrap(reference - yaw)) < .060:
            wanted = math.copysign(min(.40, math.sqrt(1.20 * abs(remaining))), remaining)
            rate = float(np.clip(wanted, rate - .60 * dt, rate + .60 * dt))
            step = rate * dt
            if step * remaining >= 0 and abs(step) >= abs(remaining):
                step, rate = remaining, 0.
            reference = _wrap(reference + step)
        else:
            rate = 0.
        self._nav_ref, self._nav_w = reference, rate
        out['final_heading_rad'] = float(reference)
        allowed = kind == 'move' and distance > .022 and abs(error) < .075 and abs(angular) < .25
        requested = min(speed * (getattr(self, '_nav_speed_scale', 1.) if carry else 1.),
                        max(.012, 1.6 * (distance - .012))) if allowed else 0.
        self.speed = float(np.clip(requested, max(0., self.speed - .70 * dt), self.speed + .70 * dt))
        out['base_velocity_world_xy'] = [self.speed * math.cos(reference), self.speed * math.sin(reference)]
        self._nav_decision = 'translate' if self.speed > 0 else 'bounded loaded turn'
        self.wait_reason = None
        return False

    def update(self, t, obs):
        action = self.names[self.action_index] if not self.done else ''
        previous = getattr(self, '_nav_yaw_sample', None)
        yaw = float(obs['robot_yaw_rad'])
        self._nav_measured_w = (_wrap(yaw - previous[1]) / (float(t) - previous[0])
                                if previous is not None and float(t) > previous[0] else 0.)
        self._nav_yaw_sample = float(t), yaw
        self._nav_decision, self._nav_freshness = 'hand_or_action_stage', {'decision': 'not_evaluated'}
        self._nav_intended = None
        out = OLD_UPDATE(self, t, obs)
        if self.sensors and action in ('move_forward', 'place_supplies'):
            scan = obs.get('scans', {}).get('wide', {})
            intended = self._nav_intended
            if intended is None and self.route and self.waypoint < len(self.route):
                intended = self.route[self.waypoint]
            out['navigation_debug'] = {
                'waypoint': None if intended is None else [float(x) for x in intended],
                'route_length': len(self.route), 'route_index': int(self.waypoint),
                'heading_rad': yaw, 'commanded_heading_rad': out.get('final_heading_rad'),
                'head_mode': getattr(self, '_nav_mode', 'not_initialized'),
                'head_actual_rad': [float(x) for x in obs['head_joints_rad']],
                'scan_age_s': _finite_age(t, float(scan.get('t', -math.inf))),
                'real_forward_visible': bool(self._visibility(scan, yaw)),
                'human_return_age_s': _finite_age(t, self.last_person_scan),
                'freshness': self._nav_freshness,
                'hand_error_m': getattr(self, '_nav_hand_error', None),
                'decision': self._nav_decision
            }
        return out


def install(native_policy):
    """Call once before constructing the existing policy's Controller.

    No runtime files, network access, simulator-property edits or SPEC changes.
    """
    global SPEC, SPACE, PERSON, OLD_HAND, OLD_NAVIGATE, OLD_UPDATE
    controller = native_policy.Controller
    if getattr(controller, '_neiss_navigation_patch', False):
        return controller
    SPEC, SPACE, PERSON = native_policy.SPEC, native_policy.CollisionSpace, native_policy.person
    OLD_HAND, OLD_NAVIGATE, OLD_UPDATE = controller._hand, controller._navigate, controller.update
    for name in ('_nav_stop', '_nav_space', '_nav_head', '_hand', '_navigate', 'update'):
        setattr(controller, name, getattr(_NavigationMethods, name))
    controller._neiss_navigation_patch = True
    return controller
