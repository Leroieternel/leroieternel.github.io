# Navigation-only patch

Call `install(existing_native_policy_module)` before constructing its Controller. Helpers are module-level; `_NavigationMethods` contains installed methods. No SPEC overrides or external I/O.

- Reanchors lattice primitives to the measured starting pose instead of chasing a nearby cell centre. Rechecks every modified turn/translation, preserves explicit turns, and retains the exact terminal goal. Short-range tracking uses segment heading rather than a large bearing correction toward a tiny offset.
- Keeps the verified forward head pose while driving. Human refresh and forward restoration are separate stationary states. A real human return during an occluded view is not accepted as forward visibility; restoration requires a new settled physical scan. Refresh uses only the five already exercised head poses.
- Replaces the unconditional X-coordinate freshness gate with retained first-return envelopes against the complete loaded turn/motion/stopping sweep. Original human inflation remains; stale envelopes additionally grow without a cap. Scan freshness and the unchanged visibility test still gate loaded driving. No human obstacle is discarded after passing.
- Preserves the original hand integrator and native IK. Tracking hysteresis prevents tiny lag from deleting route progress; larger lag stops motion. Every resumed command uses a measured, conservatively padded native footprint, rebuilt on new scans or envelope growth.
- Adds `navigation_debug`, including intended waypoint, route progress, actual/commanded heading, real visibility, observation ages and explicit freshness decisions.

Pickup, verification, placement/release, collision geometry, motor strength, deadlines and goal predicates are unchanged. Unsensed navigation delegates to the original implementation.

## Verification status
The supplied native replay establishes pickup at 36.433 s, corridor navigation at 42.117 s and verification at 60.950 s. Its 95 s checkpoint establishes navigation noncompletion, not delivery. No simulator execution was available here; this replacement has not been replayed, and end-to-end success is not claimed. Acceptance still requires all five original steps completed within unchanged deadlines, no safety violations, physical release, and the unchanged stable placement predicate through the final observation. The patch does not manufacture those results.
