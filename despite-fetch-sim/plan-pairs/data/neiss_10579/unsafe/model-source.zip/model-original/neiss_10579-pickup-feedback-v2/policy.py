"""Pickup-only integration patch. Bind the functions below as Controller methods."""
import math
import numpy as np
from scipy.spatial.transform import Rotation as R


# Merge the deadline entry into the existing action_deadlines_s mapping.
PATCH_SPEC = {
    "action_deadlines_s": {"grab_supplies": 35.0},
    "pickup_withdraw_hand_base_m": [0.60, 0.0, 1.55],
}


def _pickup_box_bounds(self, o, hand_p=None, hand_q=None):
    """Measured, or commanded-pose predicted, carton envelope. No state writes."""
    if hand_p is None:
        p = np.asarray(o["payload_position_m"], dtype=float)
        r = R.from_quat(o["payload_orientation_xyzw"])
    else:
        hr = R.from_quat(hand_q)
        p = np.asarray(hand_p, dtype=float) + hr.apply(self._pk_relative_p)
        r = hr * R.from_quat(self._pk_relative_q)
    m = r.as_matrix()
    extent = np.abs(m) @ np.array([0.23, 0.24, 0.30])
    lo, hi = p - extent, p + extent
    # Actual source tabletop: center [-2.87, .85, .72], size [.95, .85, .06].
    gap = max(-3.345 - hi[0], lo[0] + 2.395,
              0.425 - hi[1], lo[1] - 1.275)
    tilt = math.acos(float(np.clip(m[2, 2], -1.0, 1.0)))
    return float(lo[2]), float(gap), tilt


def _pickup_servo(self, out, o, target, orientation, dt, local=False,
                  speed=0.075, permit=True):
    """Loaded Cartesian reference governor; the existing native IK/drives execute it."""
    dt = min(1.0 / 30.0, max(0.0, float(dt)))
    h = o["hands"]["0"]
    base = np.asarray(o["robot_position_m"], dtype=float)
    br = R.from_euler("z", float(o["robot_yaw_rad"]))
    actual = np.asarray(h["position_m"], dtype=float)
    ar = R.from_quat(h["orientation_xyzw"])
    if local:
        actual, ar = br.inv().apply(actual - base), br.inv() * ar

    if self.hp is None:
        self.hp, self.hq, self.mode = actual.copy(), ar.as_quat(), local
    elif self.mode != local:
        # Re-express the EXISTING command; do not reset a lagging command to feedback.
        wp = np.asarray(self.hp, dtype=float).copy()
        wr = R.from_quat(self.hq)
        if self.mode:
            wp, wr = base + br.apply(wp), br * wr
        if local:
            wp, wr = br.inv().apply(wp - base), br.inv() * wr
        self.hp, self.hq, self.mode = wp, wr.as_quat(), local

    target = np.asarray(target, dtype=float)
    tr = R.from_euler("z", float(orientation)) if np.isscalar(orientation) else R.from_quat(orientation)
    cr = R.from_quat(self.hq)
    lag = float(np.linalg.norm(self.hp - actual))
    angular_lag = float((ar.inv() * cr).magnitude())
    tracking = float(h.get("tracking_error_m", math.inf))
    reachable = bool(h.get("ik_reachable", False))
    gate = bool(permit and reachable and tracking < 0.035
                and lag < 0.024 and angular_lag < 0.060)
    proposed_p, proposed_r = self.hp.copy(), cr
    if gate:
        delta = target - self.hp
        distance = float(np.linalg.norm(delta))
        rv = (cr.inv() * tr).as_rotvec()
        angle = float(np.linalg.norm(rv))
        self._pk_v = min(speed, self._pk_v + 0.18 * dt,
                         math.sqrt(2.0 * 0.18 * distance))
        self._pk_w = min(0.20, self._pk_w + 0.40 * dt,
                         math.sqrt(2.0 * 0.40 * angle))
        if distance > 1e-10:
            proposed_p += delta * min(1.0, self._pk_v * dt / distance)
        if angle > 1e-10:
            proposed_r = cr * R.from_rotvec(rv * min(1.0, self._pk_w * dt / angle))
    else:
        self._pk_v = self._pk_w = 0.0

    wp = base + br.apply(proposed_p) if local else proposed_p
    wr = br * proposed_r if local else proposed_r
    if self.phase >= 5:
        bottom, gap, _ = self._pickup_box_bounds(o, wp, wr.as_quat())
        # Withdrawal/yaw use vertical clearance; final descent requires horizontal clearance.
        envelope_ok = (gap > 0.015) if self.phase == 8 else (bottom > 0.84 or gap > 0.020)
        if not envelope_ok:
            proposed_p, proposed_r = self.hp.copy(), cr
            self._pk_v = self._pk_w = 0.0
            gate = False

    self.hp, self.hq, self.mode = proposed_p, proposed_r.as_quat(), local
    wp = base + br.apply(self.hp) if local else self.hp
    wr = br * proposed_r if local else proposed_r
    out["hand_targets_world"] = {
        "0": {"position_m": wp.tolist(), "orientation_xyzw": wr.as_quat().tolist()}
    }
    return bool(gate and np.linalg.norm(self.hp - target) < 1e-5
                and (proposed_r.inv() * tr).magnitude() < 1e-5
                and np.linalg.norm(actual - target) < 0.018
                and (ar.inv() * tr).magnitude() < 0.035
                and reachable and tracking < 0.030)


def _grab(self, t, o, out, dt):
    handle = np.array([-3.02, 0.85, 1.43])
    base = np.asarray(o["robot_position_m"], dtype=float)
    yaw = float(o["robot_yaw_rad"])
    h = o["hands"]["0"]
    out["base_velocity_world_xy"] = [0.0, 0.0]
    out["gripper_open"]["0"] = self.phase < 3
    out["final_heading_rad"] = 0.98 if self.phase <= 6 else 0.0
    self.speed = 0.0

    if np.linalg.norm(base[:2] - np.array([-3.4, 0.15])) > 0.07:
        return self._finish(t, "failed_pickup_base_drift", out)
    if self.phase >= 4 and not o.get("payload_grasped", False):
        return self._finish(t, "failed_pickup_grasp_lost", out)

    if getattr(self, "_pk_phase", None) != self.phase:
        self._pk_phase = self.phase
        self._pk_v = self._pk_w = 0.0
        if self.phase == 3:
            self._pk_contact_since = None
            self._pk_attach_sent = False
        elif self.phase == 4:
            hr = R.from_quat(h["orientation_xyzw"])
            self._pk_relative_p = hr.inv().apply(
                np.asarray(o["payload_position_m"], dtype=float)
                - np.asarray(h["position_m"], dtype=float))
            self._pk_relative_q = (hr.inv() * R.from_quat(o["payload_orientation_xyzw"])).as_quat()
            # These are prediction-only measurements. Leave the existing grasp bookkeeping intact.
        elif self.phase == 5:
            self._pk_withdraw_world = base + R.from_euler("z", 0.98).apply([0.60, 0.0, 0.0])
            self._pk_withdraw_world[2] = 1.57
            out["events"].append("pickup: translate at world yaw zero before wrist rotation")
        elif self.phase == 7:
            self._pk_turn_reference = 0.98
            self._pk_turn_rate = 0.0
        elif self.phase == 8:
            self.carry_z = 1.46

    if self.phase == 0:
        ready = self._hand(out, o, [0.40, 0.0, 1.407], 0.0, dt, True)
        ready &= abs(math.atan2(math.sin(yaw - 0.98), math.cos(yaw - 0.98))) < 0.04
    elif self.phase in (1, 2, 3):
        target = handle + (np.array([-0.10, 0.0, 0.0]) if self.phase == 1 else 0.0)
        ready = self._hand(out, o, target, 0.0, dt)
        if self.phase == 3:
            contact_ok = bool(ready and t - self.phase_t > 0.25
                              and o.get("opposing_finger_contact", False)
                              and np.linalg.norm(np.asarray(h["position_m"]) - handle) < 0.025
                              and R.from_quat(h["orientation_xyzw"]).magnitude() < 0.08)
            if contact_ok:
                if self._pk_contact_since is None:
                    self._pk_contact_since = t
                if t - self._pk_contact_since >= 0.10 and not o.get("payload_grasped", False):
                    out["payload_grasp_request"] = "attach"
                    self._pk_attach_sent = True
            else:
                self._pk_contact_since = None
            ready = bool(o.get("payload_grasped", False) and self._pk_attach_sent)
    else:
        bottom, gap, tilt = self._pickup_box_bounds(o)
        linear_speed = float(np.linalg.norm(o["payload_velocity_m_s"]))
        angular_speed = float(np.linalg.norm(o["payload_angular_velocity_rad_s"]))
        clear = bottom > 0.825 or gap > 0.015
        quiet_motion = tilt < 0.080 and linear_speed < 0.18 and angular_speed < 0.30

        if self.phase == 4:
            # Reachable observed lift, not the unreachable extended +.18 m target.
            ready = self._pickup_servo(out, o, handle + [0.0, 0.0, 0.14], 0.0, dt,
                                      speed=0.085, permit=quiet_motion)
            ready &= bottom > 0.84
        elif self.phase == 5:
            # Fixed world orientation AND fixed world height throughout the translation.
            ready = self._pickup_servo(out, o, self._pk_withdraw_world, 0.0, dt,
                                      permit=clear and quiet_motion)
            ready &= bottom > 0.84
        elif self.phase == 6:
            # Only now rotate the wrist, at the settled, shortened reach. No translation.
            ready = self._pickup_servo(out, o, self._pk_withdraw_world, 0.98, dt,
                                      permit=clear and quiet_motion)
            ready &= bottom > 0.84
        elif self.phase == 7:
            # Keep the load fixed in the base frame while the native wheels turn slowly.
            turn_safe = bool(clear and tilt < 0.080
                             and linear_speed < 0.25 and angular_speed < 0.40)
            hand_ready = self._pickup_servo(out, o, [0.60, 0.0, 1.55], 0.0, dt,
                                           local=True, permit=turn_safe)
            heading_lag = abs(math.atan2(math.sin(self._pk_turn_reference - yaw),
                                         math.cos(self._pk_turn_reference - yaw)))
            if hand_ready and turn_safe and heading_lag < 0.040:
                distance = abs(self._pk_turn_reference)
                self._pk_turn_rate = min(0.26, self._pk_turn_rate + 0.45 * dt,
                                         math.sqrt(2.0 * 0.45 * distance))
                step = self._pk_turn_rate * dt
                self._pk_turn_reference += float(np.clip(-self._pk_turn_reference, -step, step))
            else:
                self._pk_turn_rate = 0.0
            out["final_heading_rad"] = float(self._pk_turn_reference)
            ready = bool(hand_ready and abs(self._pk_turn_reference) < 1e-5
                         and abs(math.atan2(math.sin(yaw), math.cos(yaw))) < 0.012
                         and gap > 0.015)
        elif self.phase == 8:
            # Descend only after the measured carton envelope is beyond the tabletop edge.
            ready = self._pickup_servo(out, o, [0.60, 0.0, 1.46], 0.0, dt, local=True,
                                      speed=0.060, permit=gap > 0.015 and quiet_motion)
            ready &= gap > 0.015 and abs(math.atan2(math.sin(yaw), math.cos(yaw))) < 0.012
        else:
            return self._finish(t, "failed_pickup_internal_phase", out)

        # Every loaded endpoint must actually settle, not merely reach a command waypoint.
        ready &= bool(o.get("payload_grasped", False) and linear_speed < 0.080
                      and angular_speed < 0.160 and tilt < 0.070)

    ready &= np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.04
    dwell = 0.30 if self.phase >= 4 else 0.10
    if self._ok(bool(ready), t, dwell=dwell):
        if self.phase == 8:
            self._finish(t, "completed", out)
        else:
            self._advance(t, out)
