# Native Fetch pickup repair

This is an integration patch, not a replacement policy. Bind `_grab`, `_pickup_servo`, and `_pickup_box_bounds` as Controller methods. Keep the existing `_hand` and every other Controller method. Merge `PATCH_SPEC` recursively: change only `action_deadlines_s.grab_supplies`, preserving all other action deadlines. Retain the existing 120-second episode limit.

## Committed motion sequence

The original action names/order are unchanged. Inside `grab_supplies`:

0–3. Retain the initial base turn and approach. Close the native fingers; request assisted attachment only after 0.10 seconds of continuous measured opposing-finger contact, acceptable hand alignment, and the existing closing delay.

4. Lift vertically by **0.14 m**, to world hand height **1.57 m**, with world wrist orientation identity. Require measured carton bottom above **0.84 m** and settled dynamics.

5. Translate to the shortened **0.60 m forward** reach while retaining world wrist identity and world height **1.57 m**. At the stated base pose this endpoint is approximately **[-3.066, 0.648, 1.570]**. Settle before proceeding.

6. Hold that world position and rotate only the wrist to world yaw **0.98**, at no more than **0.20 rad/s**. Settle again.

7. Hold the hand at base **[0.60, 0, 1.55]**, with base-relative wrist identity. Turn the chassis toward heading zero using a tracking-gated heading reference capped at **0.26 rad/s**. Do not simultaneously retract or lower.

8. After the measured carton envelope clears the tabletop horizontally by **15 mm**, lower to base **[0.60, 0, 1.46]**. Complete only with heading zero within 0.012 rad, native reachability, tight hand tracking, retained grasp, and settled payload motion.

## Physical guards

The phase-5 endpoint is still over the table; its clearance is vertical, not a claimed horizontal withdrawal. Full oriented-carton bounds use the actual 0.46 × 0.48 × 0.60 m geometry and the actual tabletop footprint. Measured bounds gate motion; candidate commands also check the predicted envelope using the measured fixed-grasp transform. Final descent requires horizontal separation instead of spending the lift-clearance margin.

The loaded reference pauses when position lag reaches 24 mm, orientation lag reaches 0.060 rad, native tracking error reaches 35 mm, or IK reports unreachable. Completion is stricter. Frame changes re-express the existing command rather than resetting it to a lagging measured pose. Existing failure counters and grasp-transform checks remain untouched.

Only ordinary hand targets, gripper commands, assisted-grasp requests, and wheel-heading targets are emitted. Native IK, acceleration/speed/effort limits, all masses, collisions, self-collisions, and downstream success checks remain unchanged. No body/joint pose writes, external forces, or navigation/rendering changes are introduced.

The pickup deadline becomes **35 seconds** to accommodate separated translation, wrist rotation, chassis rotation, and measured settling. This patch has not been executed here; runtime reachability and physical checks remain authoritative.
