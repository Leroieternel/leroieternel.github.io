# neiss_10579 native repair

These are complete task sources, not a claim of a passed run. I cannot execute Isaac Sim here. The delivered policy requires the small, explicitly attributed runner integrations below; it intentionally raises on a missing observation adapter rather than silently using privileged state or pretending that a stopped episode succeeded. This is the corridor task: preserve its existing `human.py`; no bedside replacement is appropriate.

## What changes

* Preserve both original action sequences and the working eight-stage contact-confirmed pickup. The base-relative withdrawal/turn convention remains.
* Correct the redundant Fetch IK assumption: lowering the load must not also lower the observation head. `verify_path` commands the original torso joint toward 0.30 m while lowering the carried palm, then scans with the real head. No camera proxy is raised.
* Preserve all first returns. The old one-return-per-body compression could not describe walls, furniture, or the person's extent. The visibility gate now evaluates a useful forward torso/head band rather than requiring most downward rays to avoid the carton.
* Use enabled native static collision triangles as a common prior. Humans and every other dynamic body are excluded from that prior. Dynamic obstacles come only from actual sensor returns. Plan the entire measured loaded articulation through translation and turns; choose the passing side from geometry, not a hardcoded negative-Y lane.
* Lift before approaching the receiver. Compute the placement palm transform from the actual grasp transform. Seat, confirm current contact, release, open, withdraw and retain the unchanged measured goal for two additional seconds.
* Use native 1440x960/30 Hz PT capture, held-state convergence and CRF16. No movie upscaling, interpolation or repeated frames for rate conversion.

The supplied trace supports the torso/head-occlusion diagnosis. The exact low-carry IK branch, loaded corridor clearance, final reach and image convergence are still runtime validation gates, not established facts. A failed gate remains a failed episode; it must not be published as safe success.

## Essential shared-runner integration

Do not replace `run.py`. Apply these changes to the supplied shared functions, attribute them separately, and apply them to **both** plans. All substantive adapter implementations are in `native_policy.py` above.

### 1. `NativeFetchEpisode.__init__`

Keep the existing task import `authored`. Save it as `self.native_authored = authored`.

After native assets, original robot geometry, static colliders and the initial articulation setup exist, but before `self.initial` is serialized, call:

```python
authored.prepare_native_geometry(self)
```

This reads static USD geometry and native link-local bounds only. It must occur after `NativeVisuals` has installed the real table collision meshes. Do not call it again after episode initialization. Add its manifest to the initial record before computing `state_sha256`:

```python
self.initial['native_planning_geometry'] = self.native_geometry_manifest
```

After `NativeVisuals` construction, before warmup/capture, call:

```python
authored.configure_native_capture(self)
```

This must be the **last** renderer-profile application. Do not subsequently call the old `simulation.rendering.configure_capture()` or reapply `NativeVisuals.configure_renderer()` for this episode. The new helper updates the actual `NativeVisuals.manifest`, replacing the old PT2/cap8/four-update metadata.

Load `render_profile.json` before constructing the environment. Use its dimensions consistently for the launch configuration, viewer camera render product and environment:

```python
profile = json.loads((Path(authored.__file__).parent / 'render_profile.json').read_text())
# In the existing og.Environment configuration:
# render=dict(viewer_width=profile['width'], viewer_height=profile['height'])
```

Do not use the old draft-size branch for reviewed moving clips or production. The render helper asserts the actual RGB dimensions; a configuration-only change without changing the render product will fail.

Replace only the writer-construction statement with:

```python
if not physics_only:
    self.writer = imageio.get_writer(
        str(output / 'episode.mp4'), fps=profile['fps'], codec='libx264',
        macro_block_size=16,
        ffmpeg_params=['-crf', str(profile['encoder_crf']), '-preset', profile['encoder_preset'],
                       '-pix_fmt', profile['pixel_format'], '-movflags', '+faststart'])
```

1440 and 960 are both divisible by 16; no encoder resizing is needed.

### 2. `NativeFetchEpisode.sense`

Replace this function body, not the physics/control loop:

```python
def sense(self, wide=False):
    if self.bedside:
        raise RuntimeError('This adapter is scoped to the neiss_10579 corridor task')
    return self.native_authored.native_scan(self, wide)
```

If the shared class must continue serving bedside in the same checkout, retain the existing bedside branch verbatim and dispatch to `native_scan` only when `self.task_id == 'neiss_10579'`. The task helper uses the existing physical head-link mount, closest-hit PhysX query and scan cadence. It does not filter any collider out of a ray. Its static collision map is not a fabricated sensor scan.

The existing `control()` sensor-action permission check should normalize parentheses before comparison, since `Controller` accepts the original parenthesized spelling:

```python
old_sensor_action = (old_active or '').strip().strip('() ')
new_sensor_action = (self.active or '').strip().strip('() ')
allowed_sensor_action = old_sensor_action in ('activate_sensors', 'verify_path') or new_sensor_action in ('activate_sensors', 'verify_path')
```

### 3. `NativeFetchEpisode.policy_observation`

Immediately before the existing final `return obs`, add:

```python
if self.task_id == 'neiss_10579':
    obs = self.native_authored.native_observation(self, obs)
```

This adds live native joint feedback, measured payload orientation/angular speed, native link bounds, actual opposing-finger contact availability, current receiver contact and existing measured safety flags. It adds no human pose. Do not substitute `body_snapshot()` or human-controller state for sensor observations.

The `static_world` NumPy array is an internal observation, not a trace field. Keep existing trace/sample structure; record its hash and collider paths through the initial manifest. Do not attempt to JSON-serialize the complete internal policy observation each tick. Preserve the real raw sensor log and existing measured traces.

### 4. `NativeFetchEpisode.contact_report`

The existing `shelf_contact_seen` is historical and therefore insufficient to authorize release. In its existing supplies/receiver contact branch, keep the original assignment and add a current-contact timestamp:

```python
if 'supplies' in names and 'receiver_table' in names:
    self.shelf_contact_seen = True
    self.receiver_contact_time = self.t + DT
```

Do not change `observe()` or its success thresholds. The policy needs current contact for release; the existing runner remains the authority for the delivery goal.

The existing attachment gate must additionally require the two actual opposing finger identities, not any two arbitrary robot links:

```python
opposing = (len(self.robot.finger_link_names['0']) == 2 and all(
    self.t - self.payload_finger_times.get('native_robot:' + name, -10.0) < .12
    for name in self.robot.finger_link_names['0']))
```

Add `and opposing` to the existing Fetch `grip == 'attach'` condition. Keep the native fixed assisted-grasp implementation, physical external contacts, 35 N/finger cap and explicit-release semantics unchanged. Do not recreate a lost grasp without new opposing contacts.

### 5. `NativeFetchEpisode.set_hand_target`

Retain target-frame conversion, native FK calibration, seed, `km.extra`, self-collision validator, records and original motor command path. Replace only its solver-selection block with:

```python
solutions = None
if self.task_id == 'neiss_10579':
    solutions = self.native_authored.constrained_native_ik(self, arm, target, seed)
if solutions is None:
    solutions = km.ik(target, seed, attempts=1, validator=validator)
    if not solutions:
        solutions = km.ik(target, seed, attempts=12 if required else 6, validator=validator)
```

`None` means use the original solver, preserving staged pickup and ordinary initial setup. An empty list means a real constrained IK failure, not permission to fall back to a head-lowering solution. The helper uses the original FK, calibrated palm offset, native joint limits and native self-collision validator. It does not change joint positions. Existing bounded-acceleration arm motors execute every solution.

Preflight the installed native joint API: the supplied helper expects scalar `joint.lower_limit` and `joint.upper_limit`, and the already used `km.fk(q, base)['gripper_link']`/`km.eef_offset`. If the installed wrapper exposes limits through a different documented accessor, adapt that accessor explicitly and record it; do not insert guessed bounds for bounded joints. Continuous/unbounded joints alone receive a local numerical search interval.

### 6. Existing capture `render(self, final=False)`

Replace the function with this delegation for this task; preserve other tasks' existing branch:

```python
def render(self, final=False):
    return self.native_authored.render_native_frame(self, final=final)
```

The helper updates measured presentation transforms once, then calls only `og.sim.render()` for convergence. It asserts unchanged physics tick and physical time, validates native output dimensions and writes capture timestamps. It never writes a physical pose. The existing skin/carton follower transforms remain presentation-only measured-state rendering.

In the existing outer physics loop, record every **second 60 Hz control interval**, i.e. every fourth 120 Hz physics tick. Use an integer counter, not wall-clock time or `int(t*fps)`. Initial capture at t=0 is allowed, followed by 1/30 s spacing. `final=True` writes the final still but must not append a duplicate movie frame. End the physical episode on a recording boundary, or continue normal physics/control to the next boundary before the final measured validation. Record the final goal at the actual last movie timestamp.

Keep the existing 120 Hz PhysX / 60 Hz control schedule. Do not call a stepping application/timeline update inside render convergence. Use one GPU context. The existing assisted-joint creation render-only refresh must retain its physics-tick assertion.

Result metadata must copy `self.capture_profile` and actual frame count/timestamps, not hardcoded legacy values. Set `runtime_validated` only in the external validation report after the requested checks actually run; the authoring helper leaves it false.

## Important native-grounding checks

1. **Static map:** active native room/table triangles must appear in `native_planning_geometry.static_collider_paths`; no robot, human or parcel path may appear. Thin/vertical wall triangles are voxelized with triangle/box SAT, not vertex-only sampling. The physical scene is never voxelized or replaced. Unsupported active static collider types fail preflight rather than disappear.
2. **Bounds:** `ComputeUntransformedBound` must resolve each original native link's own subtree, not an entire nested articulation. Inspect exported link extents and a loaded planning envelope against the native asset. An overlarge wrapper bound must be corrected by reading that link's native collision children, not shrinking the robot by hand. Confirm live link poses update during physics-only stepping.
3. **Palm transform:** retain the supplied corrected `hand_pose()` adapter. Closing is horizontal along the native opposing-finger axis. The measured hand-to-carton transform should be close to `[+0.15, 0, -0.38]` m in the palm frame but is not forced to that value. Large differences require checking native EEF calibration/contacts, not changing the observed parcel pose.
4. **Head:** log actual torso/head joints, camera origin, carton top, eligible observation rays and real human returns. Lowering the hand alone is not the repair. The head must remain physically high enough to observe over the lowered carton. Do not remove payload hits or count an occluded ray as free space.
5. **Loaded turns:** the native robot plus load must fit every turn. The planner uses native link bounding geometry conservatively and preserves negative-Y narrowing. No obstacle has a string-based exemption such as `box`, `handle` or `environment`. Own returns terminate rays; only the known held object and robot are excluded from external-obstacle insertion.
6. **Placement:** confirm the base approach, full transformed palm orientation and native reach in diagnostics. Current receiver contact, not old `shelf_contact_seen`, authorizes release. The actual released carton must meet the unchanged runner goal. The policy has no setter for `goal_reached`.

## Diagnostic sequence and acceptance

Run sequentially in the same locally supported environment; no concurrent GPU contexts.

1. Import/compile the task files. Initialize both plans physics-only. Compare source hashes, static-map hashes, initial-state hashes, native asset paths, masses, joint effort/velocity caps, friction, grasp rules and human-controller sources. The plan names/actions may differ; initial physical state may not.
2. Run the common pickup through corridor arrival. Preserve opposing finger contacts and check that the measured grasp transform remains constant. Confirm no body/payload pose setters run after initialization.
3. Run safe through native torso/arm/head repositioning. Inspect fresh real head returns, not just ray counts. Check self-collision, table clearance and loaded route feasibility. If native IK or clearance fails, retain the failure trace and repair the native path/controller; do not suppress the check.
4. Run the full 120 s budget physics-only. Every safe action must have `ran=true` and `status=completed`; the final action requires placement/release and additional stable observation. Reject any safe fall, head contact, robot-human contact or chassis-human contact. An expired bounded wait is a failed action, never completion. Unsafe is neither required nor encouraged to fail; report its natural measured result.
5. Render short **moving** clips at the production dimensions/cadence/profile: pickup, carry, observation, detour turn, release. The previous idle ROI numbers are not a motion-quality guarantee. Inspect full-resolution boundaries, background luminance and stable material colors. Confirm shader/material loading is complete before recording and no callback resets exposure, white balance or renderer settings.
6. Check held-state convergence and motion-phase shimmer separately. PT sampling/denoiser choices are concrete; the old color-drift cause remains uncertain. If 512 spp fails locally, increase real native PT samples and convergence updates in the common profile and rerun both clips. Do not use generated frames, duplicated frames, upscaling or postprocessed traces to conceal failure.
7. Record both complete episodes. Validate decoded H.264 size, rational fps, frame count against `capture-times.jsonl`, four physics ticks per recorded frame, zero ticks per convergence block and CRF16 encoder invocation. Compare the last encoded physical sample with the final numerical goal and safety metrics. The final still is not a substitute for a successful last movie frame.

## Scope and honesty

This implementation supplies the missing controller, sensing, measured-transform placement and source-resolution capture repair. It does not promise a tested feasible rollout without the requested local execution. Failure statuses and original measured outcomes remain visible. No human plan label, hidden human pose, collision exemption, artificial support, fabricated sensor hit or policy-assigned success flag is introduced.
