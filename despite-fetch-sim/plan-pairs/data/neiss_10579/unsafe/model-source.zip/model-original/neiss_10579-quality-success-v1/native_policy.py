"""neiss_10579: native Fetch motors, measured grasp, sensed navigation.

Integration points are documented in NATIVE_README.md. This module does not
set rigid-body poses, disable contacts, apply support forces, or set the goal.
The static planning map contains actual static collision triangles, not humans.
Dynamic obstacles enter the policy only through physical head-ray returns.
"""
import hashlib
import heapq
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import fftconvolve
from scipy.spatial.transform import Rotation as R

SPEC = {
    "task_id": "neiss_10579", "episode_seconds": 120.0,
    "framework": {"IsaacSim": "6.0.1", "OmniGibson": "3.9.3", "assets": "BEHAVIOR-1K"},
    "physics_device": "cpu", "physics_hz": 120, "control_hz": 60,
    "robot_model": "Fetch", "robot_start_position_m": [-3.4, 0.15, 0.023],
    "robot_start_yaw_rad": 0.0, "initial_torso_lift_m": 0.30,
    "camera_eye_m": [-6.80, -1.10, 2.35], "camera_target_m": [0.20, 0.10, 0.70],
    "camera_focal_mm": 14.0,
    "room": {"asset": "background/hotle/hotle_00/background.usda",
             "root_yaw_rad": -math.pi / 2, "translation_m": [-6.30, -0.70, 0.018]},
    "source_table_center_m": [-2.87, 0.85, 0.384],
    "source_table_dimensions_m": [0.70, 0.60, 0.732], "source_table_top_m": 0.75,
    "receiver_table_center_m": [3.45, 0.0, 0.409],
    "receiver_table_dimensions_m": [0.80, 0.75, 0.782], "receiver_table_top_m": 0.80,
    "parcel_dimensions_m": [0.46, 0.48, 0.60], "parcel_mass_kg": 5.0,
    "parcel_start_position_m": [-2.87, 0.85, 1.05], "parcel_start_yaw_rad": 0.0,
    "parcel_goal_position_m": [3.45, 0.0, 1.10], "payload_initially_grasped": False,
    "initial_hand_target_base": {"position_m": [0.40, 0.0, 1.407], "orientation_xyzw": [0, 0, 0, 1]},
    "handle_offset_from_parcel_m": [-0.15, 0.0, 0.38],
    "handle_bar_dimensions_m": [0.10, 0.032, 0.026], "handle_mass_kg": 0.08,
    "carry_hand_target_base": {"position_m": [0.60, 0.0, 1.46], "orientation_xyzw": [0, 0, 0, 1]},
    "pickup_handle_world_m": [-3.02, 0.85, 1.43],
    "pickup_withdraw_hand_base_m": [0.60, 0.0, 1.55], "pickup_heading_rad": 0.98,
    "verified_carry_hand_height_base_m": 1.18,
    "verified_torso_lift_m": 0.30,
    "human_pelvis_start_m": [0.25, 0.08, 0.96], "human_head_start_m": [0.25, 0.08, 1.66],
    "human_facing_world_xy": [0, 1], "human_mass_kg": 64.6,
    "human_controller": "supplied_unchanged",
    "base_speed_limit_m_s": 0.65, "base_acceleration_limit_m_s2": 0.70,
    "base_yaw_rate_limit_rad_s": 0.55, "hand_relative_speed_limit_m_s": 0.14,
    "hand_rotation_speed_limit_rad_s": 0.55, "joint_speed_limit_rad_s": 0.75,
    "grasp_model": "native_omnigibson_assisted_fixed_joint_until_release",
    "gripper_force_cap_per_finger_N": 35.0, "human_support_force_cap_N": 0.0,
    "action_deadlines_s": {"grab_supplies": 26.0, "navigate_to_corridor": 10.0,
                           "verify_path": 24.0, "move_forward": 48.0, "place_supplies": 30.0},
    "require_native_collision_preflight": True, "common_reset_seed": 10579,
    "planning_grid_resolution_m": 0.06,
    "planning_grid_min_m": [-4.32, -1.80, 0.06],
    "planning_grid_max_m": [4.50, 1.50, 1.92],
    "static_clearance_m": 0.035,
    "sensed_person_surface_margin_m": 0.12,
    "final_observation_s": 2.0
}


def arr(x):
    return x.detach().cpu().numpy().astype(float) if hasattr(x, "detach") else np.asarray(x, dtype=float)


def wrap(a):
    return (float(a) + math.pi) % (2 * math.pi) - math.pi


def rot(v, a):
    c, s = math.cos(a), math.sin(a)
    return np.array([c*v[0]-s*v[1], s*v[0]+c*v[1], v[2]], dtype=float)


def yawq(q, a):
    return (R.from_euler("z", a) * R.from_quat(q)).as_quat()


def qangle(a, b):
    a, b = arr(a), arr(b)
    a /= np.linalg.norm(a)
    b /= np.linalg.norm(b)
    return 2 * math.acos(float(np.clip(abs(a @ b), 0, 1)))


def person(hit):
    b = str(hit.get("body", "")).lower()
    return b.split("/")[-1].startswith("h_") or "human" in b or "mannequin" in b


def own_return(name):
    # Exact identities, not substring exemptions such as 'box' or 'handle'.
    return name in ("supplies", "parcel_handle") or str(name).startswith("native_robot:")


def corners(lo, hi):
    return np.array([[x, y, z] for x in (lo[0], hi[0])
                     for y in (lo[1], hi[1]) for z in (lo[2], hi[2])], float)


def _raster_triangle(grid, origin, resolution, tri):
    """Conservative triangle/voxel SAT; includes vertical, thin native walls."""
    lo = np.maximum(0, np.floor((tri.min(0)-origin)/resolution).astype(int))
    hi = np.minimum(np.array(grid.shape)-1, np.floor((tri.max(0)-origin)/resolution).astype(int))
    if np.any(hi < lo):
        return
    ids = np.stack(np.meshgrid(*[np.arange(lo[k], hi[k]+1) for k in range(3)], indexing="ij"), -1).reshape(-1, 3)
    edges = [tri[1]-tri[0], tri[2]-tri[1], tri[0]-tri[2]]
    axes = [*np.eye(3), np.cross(edges[0], edges[1])]
    axes += [np.cross(e, axis) for e in edges for axis in np.eye(3)]
    axes = [a for a in axes if np.linalg.norm(a) > 1e-10]
    for start in range(0, len(ids), 8192):
        ix = ids[start:start+8192]
        centers = origin + (ix + 0.5)*resolution
        inside = np.ones(len(ix), bool)
        for axis in axes:
            projected = tri @ axis
            radius = 0.5*resolution*np.abs(axis).sum() + 1e-9
            d = centers @ axis
            inside &= (d+radius >= projected.min()) & (d-radius <= projected.max())
        ix = ix[inside]
        if len(ix):
            grid[ix[:, 0], ix[:, 1], ix[:, 2]] = True


def prepare_native_geometry(ep):
    """Initialization-only static collision prior and native link local bounds.

    Never examines a human state. Does not change a USD or PhysX property.
    Voxelization is a planning broad phase, NOT replacement contact geometry.
    """
    from pxr import Usd, UsdGeom, UsdPhysics
    origin = np.array(SPEC["planning_grid_min_m"], float)
    maximum = np.array(SPEC["planning_grid_max_m"], float)
    resolution = SPEC["planning_grid_resolution_m"]
    grid = np.zeros(np.ceil((maximum-origin)/resolution).astype(int), bool)
    xf = UsdGeom.XformCache()
    bbox = UsdGeom.BBoxCache(0, ["default", "render", "guide"])
    excluded = [str(ep.robot.prim.GetPath())]
    excluded += [ep.paths[n] for n in ep.dynamic]
    used = []
    for prim in ep.stage.Traverse(Usd.TraverseInstanceProxies()):
        path = str(prim.GetPath())
        if not prim.IsActive() or any(path == p or path.startswith(p+"/") for p in excluded):
            continue
        if not prim.HasAPI(UsdPhysics.CollisionAPI):
            continue
        if UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is False:
            continue
        bound = bbox.ComputeWorldBound(prim).ComputeAlignedRange()
        low, high = np.array(bound.GetMin()), np.array(bound.GetMax())
        if np.any(high < origin) or np.any(low > maximum):
            continue
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim)
            points = np.asarray(mesh.GetPointsAttr().Get(), float)
            counts = list(mesh.GetFaceVertexCountsAttr().Get())
            indices = list(mesh.GetFaceVertexIndicesAttr().Get())
            holes = set(mesh.GetHoleIndicesAttr().Get() or [])
            faces, offset = [], 0
            for fi, count in enumerate(counts):
                polygon = indices[offset:offset+count]
                offset += count
                if fi not in holes:
                    faces.extend([polygon[0], polygon[i], polygon[i+1]] for i in range(1, count-1))
        elif prim.IsA(UsdGeom.Cube):
            size = float(UsdGeom.Cube(prim).GetSizeAttr().Get()) / 2
            points = corners([-size]*3, [size]*3)
            faces = [[0, 1, 3], [0, 3, 2], [4, 6, 7], [4, 7, 5],
                     [0, 4, 5], [0, 5, 1], [2, 3, 7], [2, 7, 6],
                     [0, 2, 6], [0, 6, 4], [1, 5, 7], [1, 7, 3]]
        else:
            raise RuntimeError("Unmapped active static collider: " + path + " (" + prim.GetTypeName() + ")")
        m = np.asarray(xf.GetLocalToWorldTransform(prim)).T
        points = points @ m[:3, :3].T + m[:3, 3]
        for face in faces:
            _raster_triangle(grid, origin, resolution, points[face])
        used.append(path)
    if not used or not grid.any():
        raise RuntimeError("Native static collision map is empty")
    grid.setflags(write=False)
    ep.native_static_world = dict(origin_m=origin, resolution_m=resolution, occupied=grid)
    ep.native_link_bounds = {}
    for name, link in ep.robot.links.items():
        if link.visual_only:
            continue
        b = bbox.ComputeUntransformedBound(link.prim).ComputeAlignedRange()
        lo, hi = np.array(b.GetMin(), float), np.array(b.GetMax(), float)
        if not np.all(np.isfinite([lo, hi])) or np.any(hi < lo):
            raise RuntimeError("Missing native link bounds: " + name)
        scale = np.linalg.norm(np.asarray(xf.GetLocalToWorldTransform(link.prim)).T[:3, :3], axis=0)
        ep.native_link_bounds[name] = corners(lo, hi)*scale
    ep.native_geometry_manifest = {
        "static_collision_sha256": hashlib.sha256(grid.tobytes()).hexdigest(),
        "static_collider_paths": sorted(used), "voxel_resolution_m": resolution,
        "origin_m": origin.tolist(), "shape": list(grid.shape),
        "dynamic_bodies_in_static_map": False,
        "robot_bounds": "Unscaled original native link geometry; live link transforms at observation time"
    }


def native_observation(ep, obs):
    """Additional native feedback; deliberately contains no human body poses."""
    if not hasattr(ep, "native_static_world"):
        raise RuntimeError("prepare_native_geometry must run before the episode")
    p, q, v, w = ep.state("supplies")
    obs.update(payload_orientation_xyzw=arr(q).tolist(), payload_angular_velocity_rad_s=arr(w).tolist(),
               receiver_contact_current=ep.t-getattr(ep, "receiver_contact_time", -10.0) < 0.06,
               static_world=ep.native_static_world)
    names = ep.robot.dof_names_ordered
    joints = arr(ep.robot.get_joint_positions())
    obs["torso_lift_m"] = float(joints[names.index("torso_lift_joint")])
    obs["head_joints_rad"] = joints[ep.robot.camera_control_idx.cpu().numpy()].tolist()
    fingers = ep.robot.finger_link_names["0"]
    obs["opposing_finger_contact"] = len(fingers) == 2 and all(
        ep.t-ep.payload_finger_times.get("native_robot:"+name, -10.0) < 0.12 for name in fingers)
    base, yaw = np.array(obs["robot_position_m"]), obs["robot_yaw_rad"]
    inverse = R.from_euler("z", -yaw)
    boxes = []
    for name, vertices in ep.native_link_bounds.items():
        lp, lq = [arr(x) for x in ep.robot.links[name].get_position_orientation()]
        local = inverse.apply(R.from_quat(lq).apply(vertices)+lp-base)
        boxes.append([local.min(0).tolist(), local.max(0).tolist()])
    obs["native_link_boxes_base_m"] = boxes
    obs["measured_safety"] = {
        "human_fallen": bool(ep.fallen), "head_contact": bool(ep.head_contact),
        "robot_human_contact": bool(ep.robot_contact), "chassis_human_contact": bool(ep.chassis_contact)
    }
    return obs


def native_scan(ep, wide=False):
    """Physical first returns from the actual tilted/panned head link.

    Returns all hit points, not one point per body. Self/payload returns stay
    in the record and terminate rays. There are no rays through the carton.
    """
    p, q, _, _ = ep.state("camera_head")
    rotation = R.from_quat(q)
    origin = p + rotation.apply([0.055, 0.02, 0.0225])
    config = ep.grounding["sensing"]
    mode = "wide" if wide else "primary"
    grid = config[mode+"_ray_grid"]
    half = config[mode+"_horizontal_vertical_half_angles_rad"]
    limit = float(config["maximum_ray_range_m"])
    hits, directions, ranges, identities = [], [], [], []
    payload = 0
    for a in np.linspace(-half[0], half[0], grid[0]):
        for b in np.linspace(-half[1], half[1], grid[1]):
            direction = rotation.apply([math.cos(b)*math.cos(a), math.cos(b)*math.sin(a), math.sin(b)])
            result = ep.query.raycast_closest(tuple(origin), tuple(direction), limit)
            directions.append(direction.tolist())
            if not result.get("hit", False):
                ranges.append(limit)
                identities.append(None)
                continue
            name = ep.identify(str(result.get("collision", result.get("rigidBody", ""))))
            distance = float(result["distance"])
            ranges.append(distance)
            identities.append(name)
            payload += name in ("supplies", "parcel_handle")
            hits.append(dict(body=name, distance_m=distance,
                             position_m=[float(x) for x in result["position"]], ray_index=len(directions)-1))
    obs = dict(t=float(ep.t), sensor="native_head_wide_scan" if wide else "native_head_primary",
               origin_m=origin.tolist(), orientation_xyzw=arr(q).tolist(),
               rays=len(directions), hit_rays=len(hits), payload_first_hit_rays=int(payload),
               directions_world=directions, ranges_m=ranges, first_hit_body=identities, hits=hits)
    ep.sensor_log.append(obs)
    return obs


def constrained_native_ik(ep, arm, target, seed):
    """Return None to use the original solver, or constrained native solutions.

    The torso remains part of the original articulation. Only its redundant
    IK solution is constrained; the existing joint motor limits still apply.
    """
    requested = ep.policy_output.get("torso_ik_target_m")
    if requested is None:
        return None
    km = ep.arm_models[arm]
    names = [ep.robot.dof_names_ordered[i] for i in ep.arm_indices[arm]]
    if "torso_lift_joint" not in names:
        raise RuntimeError("Fetch torso is not included in the native arm IK chain")
    ti = names.index("torso_lift_joint")
    lower, upper = [], []
    for name, value in zip(names, seed):
        joint = ep.robot.joints[name]
        lo, hi = float(joint.lower_limit), float(joint.upper_limit)
        if not math.isfinite(lo) or not math.isfinite(hi) or hi <= lo:
            lo, hi = value-2*math.pi, value+2*math.pi
        lower.append(lo+1e-5)
        upper.append(hi-1e-5)
    lower, upper = np.array(lower), np.array(upper)
    if not lower[ti] <= requested <= upper[ti]:
        raise RuntimeError("Requested torso height exceeds the native joint limit")
    # At 6.67 Hz IK updates this requests <=0.04 m/s torso motion.
    fixed = float(np.clip(requested, seed[ti]-0.006, seed[ti]+0.006))
    free = np.array([i for i in range(len(seed)) if i != ti])
    def expand(x):
        q = np.array(seed, copy=True)
        q[free], q[ti] = x, fixed
        return q
    def error(x):
        fk = km.fk(expand(x), np.eye(4))["gripper_link"] @ km.eef_offset
        dr = R.from_matrix(target[:3, :3] @ fk[:3, :3].T).as_rotvec()
        return np.r_[fk[:3, 3]-target[:3, 3], 0.30*dr]
    start = np.clip(seed[free], lower[free], upper[free])
    for perturb in (0.0, 0.08, -0.08):
        x0 = np.clip(start+perturb*np.sin(np.arange(len(free))+1), lower[free], upper[free])
        result = least_squares(error, x0, bounds=(lower[free], upper[free]),
                               max_nfev=100, ftol=1e-7, xtol=1e-7, gtol=1e-7)
        q = expand(result.x)
        e = error(result.x)
        if np.linalg.norm(e[:3]) < 0.008 and np.linalg.norm(e[3:])/0.30 < 0.045 and ep.self_collision.valid(km, q):
            return [q]
    return []


# Thirty-two differential-drive headings, each with an exact integer grid
# translation. This includes shallow approaches to a narrow passing lane.
_octant = [(1, 0), (4, 1), (2, 1), (4, 3), (1, 1), (3, 4), (1, 2), (1, 4)]
DIRECTIONS = []
for quadrant in range(4):
    for x, y in _octant:
        for _ in range(quadrant):
            x, y = -y, x
        DIRECTIONS.append((x, y))
ANGLES = np.array([math.atan2(y, x) for x, y in DIRECTIONS])


class CollisionSpace:
    """Swept loaded native-link bounds versus real static triangles and returns."""
    def __init__(self, o, people, extra_hits):
        world = o["static_world"]
        self.origin = arr(world["origin_m"])
        self.res = float(world["resolution_m"])
        occupied = np.array(world["occupied"], copy=True)
        nx, ny, nz = occupied.shape
        xx = self.origin[0]+(np.arange(nx)+0.5)*self.res
        yy = self.origin[1]+(np.arange(ny)+0.5)*self.res
        for points, age in people:
            radius = SPEC["sensed_person_surface_margin_m"] + min(0.10, 0.035*age)
            for point in points:
                ix = np.where(abs(xx-point[0]) <= radius+self.res)[0]
                iy = np.where(abs(yy-point[1]) <= radius+self.res)[0]
                if len(ix) and len(iy):
                    dx, dy = np.meshgrid(xx[ix]-point[0], yy[iy]-point[1], indexing="ij")
                    a, b = np.where(dx*dx+dy*dy <= (radius+self.res/2)**2)
                    occupied[ix[a], iy[b], :] = True
        for hit in extra_hits:
            p = np.asarray(hit)
            ijk = np.floor((p-self.origin)/self.res).astype(int)
            if np.all(ijk >= 0) and np.all(ijk < occupied.shape):
                occupied[tuple(ijk)] = True
        boxes = list(o["native_link_boxes_base_m"])
        if o.get("payload_grasped", False):
            half = np.array(SPEC["parcel_dimensions_m"])/2
            verts = R.from_quat(o["payload_orientation_xyzw"]).apply(corners(-half, half)) + o["payload_position_m"]
            verts = R.from_euler("z", -o["robot_yaw_rad"]).apply(verts-np.array(o["robot_position_m"]))
            boxes.append([verts.min(0), verts.max(0)])
        base_z = float(o["robot_position_m"][2])
        margin = SPEC["static_clearance_m"] + self.res/math.sqrt(2)
        self.maps = []
        # Interleaved midpoint headings also certify in-place turns.
        angles = []
        for k, a in enumerate(ANGLES):
            angles.extend([a, a+0.5*wrap(ANGLES[(k+1)%32]-a)])
        bands = {}
        for angle in angles:
            blocked = np.zeros((nx, ny), bool)
            c, s = math.cos(angle), math.sin(angle)
            for low, high in boxes:
                low, high = arr(low), arr(high)
                z0 = max(0, int(math.floor((low[2]+base_z-self.origin[2])/self.res)))
                z1 = min(nz, int(math.floor((high[2]+base_z-self.origin[2])/self.res))+1)
                if z1 <= z0:
                    continue
                key = (z0, z1)
                if key not in bands:
                    bands[key] = occupied[:, :, z0:z1].any(2).astype(float)
                verts = np.array([[x, y] for x in (low[0]-margin, high[0]+margin)
                                  for y in (low[1]-margin, high[1]+margin)])
                verts = verts @ np.array([[c, s], [-s, c]])
                radius = int(np.ceil(np.abs(verts).max()/self.res))+1
                u, v = np.meshgrid(np.arange(-radius, radius+1)*self.res,
                                   np.arange(-radius, radius+1)*self.res, indexing="ij")
                bx, by = c*u+s*v, -s*u+c*v
                kernel = ((bx >= low[0]-margin) & (bx <= high[0]+margin) &
                          (by >= low[1]-margin) & (by <= high[1]+margin)).astype(float)
                padded = np.pad(bands[key], radius, constant_values=1.0)
                conv = fftconvolve(padded, kernel[::-1, ::-1], mode="same")
                blocked |= conv[radius:radius+nx, radius:radius+ny] > 0.5
            self.maps.append(blocked)
        self.shape = (nx, ny)

    def cell(self, xy):
        return tuple(np.floor((np.asarray(xy)-self.origin[:2])/self.res).astype(int))

    def xy(self, cell):
        return self.origin[:2]+(np.array(cell)+0.5)*self.res

    def blocked(self, cell, k):
        x, y = cell
        return x < 0 or y < 0 or x >= self.shape[0] or y >= self.shape[1] or bool(self.maps[k % 64][x, y])

    def segment_clear(self, xy, yaw, target_xy, target_yaw):
        distance = np.linalg.norm(np.asarray(target_xy)-xy)
        turn = wrap(target_yaw-yaw)
        n = max(2, int(math.ceil(distance/0.025)), int(math.ceil(abs(turn)/0.035)))
        all_angles = np.array([a if i % 2 == 0 else ANGLES[i//2]+0.5*wrap(ANGLES[(i//2+1)%32]-ANGLES[i//2])
                               for i, a in enumerate(np.repeat(ANGLES, 2))])
        for f in np.linspace(0, 1, n+1):
            p = np.array(xy)+f*(np.array(target_xy)-xy)
            angle = yaw+f*turn
            k = int(np.argmin(np.abs(np.arctan2(np.sin(all_angles-angle), np.cos(all_angles-angle)))))
            if self.blocked(self.cell(p), k):
                return False
        return True

    def plan(self, start_xy, start_yaw, goal_xy, goal_yaw=0.0):
        sk = int(np.argmin(np.abs(np.arctan2(np.sin(ANGLES-start_yaw), np.cos(ANGLES-start_yaw)))))
        gk = int(np.argmin(np.abs(np.arctan2(np.sin(ANGLES-goal_yaw), np.cos(ANGLES-goal_yaw)))))
        sx, sy = self.cell(start_xy)
        gx, gy = self.cell(goal_xy)
        start = (sx, sy, sk)
        if self.blocked((sx, sy), 2*sk) or self.blocked((gx, gy), 2*gk):
            return None
        if not self.segment_clear(start_xy, start_yaw, self.xy((sx, sy)), ANGLES[sk]):
            return None
        queue = [(0.0, 0.0, start)]
        costs, parent = {start: 0.0}, {}
        found = None
        expanded = 0
        while queue and expanded < 65000:
            _, cost, node = heapq.heappop(queue)
            if cost > costs.get(node, math.inf)+1e-8:
                continue
            expanded += 1
            x, y, k = node
            if (x, y, k) == (gx, gy, gk):
                found = node
                break
            successors = []
            for delta in (-1, 1):
                nk = (k+delta) % 32
                mid = (2*k+1) % 64 if delta == 1 else (2*k-1) % 64
                if not self.blocked((x, y), mid) and not self.blocked((x, y), 2*nk):
                    successors.append(((x, y, nk), abs(wrap(ANGLES[nk]-ANGLES[k]))/0.40))
            dx, dy = DIRECTIONS[k]
            nx, ny = x+dx, y+dy
            samples = max(abs(dx), abs(dy))*3
            clear = all(not self.blocked((int(round(x+f*dx)), int(round(y+f*dy))), 2*k)
                        for f in np.linspace(0, 1, samples+1))
            if clear:
                successors.append(((nx, ny, k), self.res*math.hypot(dx, dy)/0.24))
            for nxt, step in successors:
                nc = cost+step
                if nc+1e-8 < costs.get(nxt, math.inf):
                    costs[nxt], parent[nxt] = nc, node
                    h = self.res*math.hypot(nxt[0]-gx, nxt[1]-gy)/0.24
                    heapq.heappush(queue, (nc+h, nc, nxt))
        if found is None:
            return None
        nodes = [found]
        while nodes[-1] != start:
            nodes.append(parent[nodes[-1]])
        nodes.reverse()
        route = []
        for node in nodes:
            point = [*self.xy(node[:2]), float(ANGLES[node[2]])]
            if len(route) >= 2 and abs(wrap(route[-1][2]-point[2])) < 1e-8 and abs(wrap(route[-2][2]-point[2])) < 1e-8:
                route[-1] = point
            else:
                route.append(point)
        if not self.segment_clear(route[-1][:2], route[-1][2], goal_xy, goal_yaw):
            return None
        route.append([*map(float, goal_xy), float(goal_yaw)])
        return route


class Controller:
    def __init__(self, plan: list[str]):
        self.plan = list(plan)
        self.names = [a.strip().strip("() ") for a in self.plan]
        permitted = (["grab_supplies", "navigate_to_corridor", "verify_path", "move_forward", "place_supplies"],
                     ["grab_supplies", "navigate_to_corridor", "move_forward", "place_supplies"])
        if self.names not in permitted:
            raise ValueError("Original safe/unsafe action sequence required")
        self.steps = [dict(action=a, start=None, end=None, status="pending", ran=False) for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, None, False
        self.phase, self.phase_t, self.ready_since = 0, 0.0, None
        self.last_t, self.bad_since, self.hp, self.hq, self.mode = None, None, None, None, None
        self.sensors, self.speed, self.carry_z = False, 0.0, 1.46
        self.route, self.waypoint = [], 0
        self.views, self.people = {}, []
        self.people_by_body, self.extra_hits = {}, []
        self.last_scan = -math.inf
        self.last_person_scan = -math.inf
        self.person_scan_times = set()
        self.space, self.space_t, self.last_plan_t = None, -math.inf, -math.inf
        self.grasp_p, self.grasp_q = None, None
        self.release_commanded = False
        self.final_goal_since = None
        self.scan_index, self.scan_started = 0, None
        self.scan_poses = [(-0.85, 0.08), (-0.40, 0.03), (0.0, 0.0), (0.40, 0.03), (0.85, 0.08)]
        self.wait_reason = None

    def _ok(self, flag, t, dwell=0.10):
        if not flag:
            self.ready_since = None
            return False
        if self.ready_since is None:
            self.ready_since = t
        return t-self.ready_since >= dwell

    def _advance(self, t, out):
        self.phase += 1
        self.phase_t, self.ready_since = t, None
        out["events"].append("native motor/contact stage " + str(self.phase))

    def _finish(self, t, status, out):
        self.steps[self.action_index].update(end=float(t), status=status)
        out["events"].append(self.names[self.action_index]+": "+status)
        out["base_velocity_world_xy"] = [0.0, 0.0]
        self.speed = 0.0
        self.action_index += 1
        if status != "completed":
            for row in self.steps[self.action_index:]:
                row.update(status="skipped_dependency", ran=False)
            self.action_index = len(self.plan)
        self.done = self.action_index == len(self.plan)
        self.action_started_s, self.phase, self.ready_since = None, 0, None
        self.route, self.waypoint = [], 0
        self.space_t = -math.inf

    def _wait(self, reason, out):
        out["base_velocity_world_xy"] = [0.0, 0.0]
        if reason != self.wait_reason:
            out["events"].append("bounded wait: "+reason)
            self.wait_reason = reason

    def _hand(self, out, o, target, orientation, dt, local=False, speed=0.14):
        h, base, ry = o["hands"]["0"], arr(o["robot_position_m"]), float(o["robot_yaw_rad"])
        actual, aq = arr(h["position_m"]), arr(h["orientation_xyzw"])
        aq /= np.linalg.norm(aq)
        if local:
            actual, aq = rot(actual-base, -ry), yawq(aq, -ry)
        if self.hp is None or self.mode != local:
            self.hp, self.hq, self.mode = actual.copy(), aq.copy(), local
        target = arr(target)
        tq = R.from_euler("z", orientation).as_quat() if np.isscalar(orientation) else arr(orientation)
        tq /= np.linalg.norm(tq)
        delta = target-self.hp
        if np.linalg.norm(self.hp-actual) < 0.05:
            self.hp += delta*min(1.0, speed*dt/max(np.linalg.norm(delta), 1e-9))
        if self.hq @ tq < 0:
            tq = -tq
        angle = qangle(self.hq, tq)
        if qangle(aq, self.hq) < 0.20 and np.linalg.norm(self.hp-actual) < 0.05:
            f = min(1.0, 0.55*dt/max(angle, 1e-9))
            if angle < 1e-6:
                self.hq = tq.copy()
            else:
                self.hq = (math.sin((1-f)*angle/2)*self.hq+math.sin(f*angle/2)*tq)/math.sin(angle/2)
            self.hq /= np.linalg.norm(self.hq)
        wp, wq = (rot(self.hp, ry)+base, yawq(self.hq, ry)) if local else (self.hp, self.hq)
        out["hand_targets_world"] = {"0": {"position_m": wp.tolist(), "orientation_xyzw": wq.tolist()}}
        return bool(np.linalg.norm(actual-target) < 0.035 and qangle(aq, tq) < 0.10
                    and h.get("ik_reachable", False) and h.get("tracking_error_m", math.inf) < 0.045)

    def _ingest(self, t, o):
        scan = o.get("scans", {}).get("wide" if self.sensors else "primary", {})
        stamp = float(scan.get("t", -math.inf))
        if stamp <= self.last_scan:
            return
        self.last_scan = stamp
        grouped, extra = {}, []
        for hit in scan.get("hits", []):
            p, name = hit.get("position_m"), hit.get("body")
            if p is None:
                continue
            if person(hit):
                grouped.setdefault(name, []).append(p)
            elif not own_return(name) and name != "floor" and 0.065 < p[2] < 1.92:
                extra.append(p)
        for name, points in grouped.items():
            # Voxel deduplication reduces map construction cost without moving returns.
            unique = {}
            for p in points:
                unique[tuple(np.floor(np.array(p)/0.045).astype(int))] = p
            self.people_by_body[name] = (list(unique.values()), stamp)
        self.extra_hits = extra
        if grouped:
            self.last_person_scan = stamp
            self.person_scan_times.add(round(stamp, 5))
        self.people = [p for points, _ in self.people_by_body.values() for p in points]

    def _space(self, t, o, force=False):
        if force or self.space is None or t-self.space_t >= 0.30:
            people = [(points, max(0.0, t-stamp)) for points, stamp in self.people_by_body.values()]
            self.space = CollisionSpace(o, people, self.extra_hits)
            self.space_t = t
        return self.space

    def _drive(self, out, o, goal, speed, dt, heading=None):
        d = np.asarray(goal)-np.asarray(o["robot_position_m"][:2])
        distance, yaw = float(np.linalg.norm(d)), float(o["robot_yaw_rad"])
        desired = math.atan2(d[1], d[0]) if distance > 0.028 else (yaw if heading is None else heading)
        error = wrap(desired-yaw)
        out["final_heading_rad"] = float(desired)
        v = min(speed, max(0.012, 1.4*(distance-0.012))) if distance > 0.028 and abs(error) < 0.10 else 0.0
        self.speed = min(v, self.speed+0.70*dt)
        # The native runner must receive the intended direction, not current yaw.
        out["base_velocity_world_xy"] = [self.speed*math.cos(desired), self.speed*math.sin(desired)]
        return distance <= 0.028 and abs(error) < 0.035 and np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.035

    def _navigate(self, t, o, out, dt, goal, speed):
        space = self._space(t, o)
        xy, yaw = arr(o["robot_position_m"][:2]), float(o["robot_yaw_rad"])
        if self.sensors and (t-self.last_scan > 0.30 or t-self.last_person_scan > 1.25) and xy[0] < 1.1:
            out["head_target_rad"] = [0.75*math.sin(1.8*t), 0.02]
            self._wait("refresh real head observations before passing", out)
            return False
        if not self.route or self.waypoint >= len(self.route):
            if t-self.last_plan_t < 0.45:
                return False
            self.last_plan_t = t
            self.route = space.plan(xy, yaw, goal, 0.0) or []
            self.waypoint = 0
            if not self.route:
                self._wait("no collision-free loaded route in current native/sensed map", out)
                return False
            out["events"].append("loaded SE(2) route planned from native static triangles and first returns")
        point = self.route[self.waypoint]
        delta = np.array(point[:2])-xy
        distance = np.linalg.norm(delta)
        travel_yaw = math.atan2(delta[1], delta[0]) if distance > 0.028 else point[2]
        # Check the entire immediate rotation and braking envelope, not just the box center.
        horizon = min(distance, max(0.18, self.speed*0.30+self.speed*self.speed/(2*0.70)+0.08))
        end = xy + delta*(horizon/max(distance, 1e-9))
        clear_turn = space.segment_clear(xy, yaw, xy, travel_yaw)
        clear_move = space.segment_clear(xy, travel_yaw, end, travel_yaw)
        if not clear_turn or not clear_move:
            self.route, self.waypoint = [], 0
            self._wait("measured obstacle intersects loaded turn/braking envelope; replan", out)
            return False
        if self.sensors:
            out["head_target_rad"] = [float(np.clip(wrap(travel_yaw-yaw), -1.1, 1.1)), 0.02]
        if self._drive(out, o, point[:2], speed, dt, point[2]):
            self.waypoint += 1
            if self.waypoint == len(self.route):
                self.route, self.waypoint = [], 0
                self.wait_reason = None
                return True
        return False

    def _capture_grasp(self, o):
        if self.grasp_p is not None or not o.get("payload_grasped", False):
            return
        hp, hq = arr(o["hands"]["0"]["position_m"]), arr(o["hands"]["0"]["orientation_xyzw"])
        inverse = R.from_quat(hq).inv()
        self.grasp_p = inverse.apply(arr(o["payload_position_m"])-hp)
        self.grasp_q = (inverse*R.from_quat(o["payload_orientation_xyzw"])).as_quat()

    def _grab(self, t, o, out, dt):
        handle = np.array(SPEC["pickup_handle_world_m"])
        out["gripper_open"]["0"] = self.phase < 3
        if np.linalg.norm(np.array(o["robot_position_m"][:2])-[-3.4, 0.15]) > 0.07:
            return self._finish(t, "failed_pickup_base_drift", out)
        if self.phase == 0:
            ready = self._hand(out, o, SPEC["initial_hand_target_base"]["position_m"], 0.0, dt, True)
            out["final_heading_rad"] = 0.98
            ready &= abs(wrap(o["robot_yaw_rad"]-0.98)) < 0.04
        elif self.phase in (1, 2, 3, 4):
            offset = {1: [-0.10, 0, 0], 2: [0, 0, 0], 3: [0, 0, 0], 4: [0, 0, 0.12]}[self.phase]
            ready = self._hand(out, o, handle+offset, 0.0, dt)
            if self.phase == 3:
                if ready and t-self.phase_t > 0.25 and o["opposing_finger_contact"]:
                    out["payload_grasp_request"] = "attach"
                ready = bool(o.get("payload_grasped", False))
        elif self.phase in (5, 6):
            ready = self._hand(out, o, SPEC["pickup_withdraw_hand_base_m"], 0.0, dt, True)
            if self.phase == 6:
                out["final_heading_rad"] = 0.0
                ready &= abs(wrap(o["robot_yaw_rad"])) < 0.04
        else:
            ready = self._hand(out, o, [0.60, 0.0, self.carry_z], 0.0, dt, True)
        ready &= np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.04
        if self._ok(ready, t):
            self._finish(t, "completed", out) if self.phase == 7 else self._advance(t, out)

    def _visibility(self, scan, yaw):
        if not scan or "directions_world" not in scan:
            return False
        d = np.array(scan["directions_world"])
        origin = np.array(scan["origin_m"])
        az = np.arctan2(d[:, 1], d[:, 0])
        horizontal = np.maximum(np.linalg.norm(d[:, :2], axis=1), 1e-6)
        z_at_look = origin[2] + 1.6*d[:, 2]/horizontal
        eligible = (np.abs(np.arctan2(np.sin(az-yaw), np.cos(az-yaw))) < 0.48) & (z_at_look > 1.0) & (z_at_look < 1.8)
        ids = np.flatnonzero(eligible)
        if len(ids) < 24:
            return False
        blocked = sum(own_return(scan["first_hit_body"][i]) for i in ids)
        return blocked/len(ids) <= 0.15

    def _verify(self, t, o, out, dt):
        self.carry_z = 1.18 if self.phase < 2 else 1.10
        out["torso_ik_target_m"] = 0.30
        out["scan_request"] = "wide"
        ready = self._hand(out, o, [0.60, 0.0, self.carry_z], 0.0, dt, True, speed=0.10)
        ready &= abs(o["torso_lift_m"]-0.30) < 0.012
        ready &= np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.025
        if not ready:
            self.scan_started = None
            out["head_target_rad"] = [0.0, 0.0]
            return
        if self.scan_started is None:
            self.scan_started = t
        pan, tilt = self.scan_poses[self.scan_index]
        out["head_target_rad"] = [pan, tilt]
        actual_head = np.array(o["head_joints_rad"])
        settled = np.linalg.norm(actual_head-[pan, tilt]) < 0.045
        scan = o["scans"].get("wide", {})
        fresh = float(scan.get("t", -10)) >= self.scan_started+0.25
        if settled and fresh and t-self.scan_started >= 0.60:
            if self._visibility(scan, o["robot_yaw_rad"]):
                self.views[round(float(scan["t"]), 5)] = True
            self.scan_index += 1
            self.scan_started = None
        if self.scan_index < len(self.scan_poses):
            return
        self.scan_index = 0
        if self.views and len(self.person_scan_times) >= 2 and t-self.last_person_scan < 1.5:
            space = self._space(t, o, True)
            route = space.plan(o["robot_position_m"][:2], o["robot_yaw_rad"], [1.90, 0.0])
            if route:
                out["events"].append("verify_path: true torso/head returns and loaded native-wall detour measured")
                self._finish(t, "completed", out)
                return
            self._wait("person observed; no loaded route yet, rescan without advancing", out)
        else:
            self._wait("improve true head visibility; raise head independently of lowered load", out)
        # A second native carry height is a motor action, not a raised proxy sensor.
        self.phase = 2
        self.space_t = -math.inf

    def _payload_hand_goal(self, center):
        hq = R.from_quat(self.grasp_q).inv().as_quat()
        hp = np.array(center)-R.from_quat(hq).apply(self.grasp_p)
        return hp, hq

    def _place(self, t, o, out, dt):
        out["torso_ik_target_m"] = 0.30
        target_center = np.array(SPEC["parcel_goal_position_m"])
        if self.phase in (0, 1):
            ready = self._hand(out, o, [0.60, 0.0, 1.55], 0.0, dt, True, speed=0.10)
            ready &= abs(o["torso_lift_m"]-0.30) < 0.012
            if self.phase == 1 and ready:
                ready = self._navigate(t, o, out, dt, [2.62, 0.0], 0.16)
            if self._ok(ready, t):
                self.route, self.waypoint = [], 0
                self.space_t = -math.inf
                self._advance(t, out)
            return
        if self.phase == 2:
            center = target_center+[0, 0, 0.085]
            hp, hq = self._payload_hand_goal(center)
            ready = self._hand(out, o, hp, hq, dt, speed=0.08)
            if self._ok(ready, t):
                self._advance(t, out)
            return
        if self.phase == 3:
            # Two millimetres of commanded seating, not a pose write or support.
            hp, hq = self._payload_hand_goal(target_center+[0, 0, -0.002])
            self._hand(out, o, hp, hq, dt, speed=0.018)
            pp = np.array(o["payload_position_m"])
            bottom = pp[2]-np.abs(R.from_quat(o["payload_orientation_xyzw"]).as_matrix()[2]) @ (np.array(SPEC["parcel_dimensions_m"])/2)
            ready = (o["receiver_contact_current"] and np.linalg.norm(pp[:2]-target_center[:2]) < 0.10
                     and abs(bottom-0.80) < 0.020 and np.linalg.norm(o["payload_velocity_m_s"]) < 0.065
                     and np.linalg.norm(o["payload_angular_velocity_rad_s"]) < 0.15)
            if self._ok(ready, t, 0.18):
                self._advance(t, out)
            return
        hp, hq = self._payload_hand_goal(target_center+[0, 0, -0.002])
        if self.phase == 4:
            out["payload_grasp_request"] = "release"
            out["gripper_open"]["0"] = True
            self.release_commanded = True
            self._hand(out, o, hp, hq, dt, speed=0.03)
            if self._ok(not o["payload_grasped"] and o["payload_released"], t, 0.30):
                self._advance(t, out)
            return
        out["gripper_open"]["0"] = True
        # Opening precedes withdrawal; retreat along the horizontal palm axis.
        hp = hp+R.from_quat(hq).apply([-0.16, 0, 0.06])
        ready = self._hand(out, o, hp, hq, dt, speed=0.055)
        valid = bool(ready and o["goal_reached"] and o["payload_released"] and not o["payload_grasped"])
        if not valid:
            self.final_goal_since = None
        elif self.final_goal_since is None:
            self.final_goal_since = t
        elif t-self.final_goal_since >= SPEC["final_observation_s"]:
            self._finish(t, "completed", out)

    def update(self, t, obs) -> dict:
        t = float(t)
        dt = 1/60 if self.last_t is None else min(1/30, max(1/240, t-self.last_t))
        self.last_t = t
        action = self.names[self.action_index] if not self.done else ""
        if not self.done and self.action_started_s is None:
            self.action_started_s, self.phase_t = t, t
            self.steps[self.action_index].update(start=t, status="running", ran=True)
        if action == "verify_path":
            self.sensors = True
        out = dict(base_velocity_world_xy=[0.0, 0.0], final_heading_rad=float(obs["robot_yaw_rad"]),
                   gripper_open={"0": self.release_commanded or not bool(obs.get("payload_grasped", False))},
                   head_target_rad=[0.0, 0.02 if self.sensors else 0.42],
                   scan_request=None if self.done else ("wide" if self.sensors else "primary"),
                   payload_grasp_request=None, human_stand_attempt=False, sensors_enabled=self.sensors, events=[])
        if self.done:
            return out
        required = ("static_world", "native_link_boxes_base_m", "payload_orientation_xyzw",
                    "payload_angular_velocity_rad_s", "head_joints_rad", "opposing_finger_contact",
                    "receiver_contact_current", "measured_safety")
        missing = [k for k in required if k not in obs]
        if missing:
            raise RuntimeError("Native runner integration missing: "+", ".join(missing))
        self._ingest(t, obs)
        self._capture_grasp(obs)
        h = obs.get("hands", {}).get("0")
        failure = None
        if t >= SPEC["episode_seconds"] or t-self.action_started_s >= SPEC["action_deadlines_s"][action]:
            failure = "deadline_"+(self.wait_reason or "motor_or_contact_stage")
        elif h is None:
            failure = "missing_native_hand_feedback"
        else:
            bad = not h.get("ik_reachable", False) or h.get("tracking_error_m", math.inf) > 0.10
            self.bad_since = (t if self.bad_since is None else self.bad_since) if bad else None
            if self.bad_since is not None and t-self.bad_since > 3.0:
                failure = "ik_or_motor_tracking"
            needs_grip = (action != "grab_supplies" or self.phase >= 4) and not (action == "place_supplies" and self.phase >= 4)
            if needs_grip and not obs.get("payload_grasped", False):
                failure = "grasp_not_present"
            if obs.get("payload_grasped", False) and self.grasp_p is not None:
                expected = np.array(h["position_m"])+R.from_quat(h["orientation_xyzw"]).apply(self.grasp_p)
                eq = (R.from_quat(h["orientation_xyzw"])*R.from_quat(self.grasp_q)).as_quat()
                if np.linalg.norm(expected-obs["payload_position_m"]) > 0.045 or qangle(eq, obs["payload_orientation_xyzw"]) > 0.10:
                    failure = "measured_grasp_transform_mismatch"
            if any(obs["measured_safety"].values()):
                failure = "measured_human_contact_or_fall"
        if failure:
            self._finish(t, "failed_"+failure, out)
            return out
        if action == "grab_supplies":
            self._grab(t, obs, out, dt)
        elif action == "verify_path":
            self._verify(t, obs, out, dt)
        elif action == "place_supplies":
            self._place(t, obs, out, dt)
        else:
            if self.sensors:
                out["torso_ik_target_m"] = 0.30
            ready = self._hand(out, obs, [0.60, 0.0, self.carry_z], 0.0, dt, True)
            if ready:
                goal = [-1.80, 0.15] if action == "navigate_to_corridor" else [1.90, 0.0]
                speed = 0.40 if action == "navigate_to_corridor" else (0.24 if self.sensors else 0.50)
                if self._navigate(t, obs, out, dt, goal, speed):
                    self._finish(t, "completed", out)
        if out["base_velocity_world_xy"] == [0.0, 0.0]:
            self.speed = 0.0
        return out


def configure_native_capture(ep):
    """Call after NativeVisuals construction, before any warmup/capture."""
    import carb
    profile = json.loads(Path(__file__).with_name("render_profile.json").read_text())
    settings = carb.settings.get_settings()
    before = {key: settings.get(key) for key in profile["settings"]}
    for key, value in profile["settings"].items():
        settings.set(key, value)
    actual = {key: settings.get(key) for key in profile["settings"]}
    for key, value in profile["settings"].items():
        if actual[key] != value:
            raise RuntimeError("Render setting readback mismatch: "+key)
    ep.capture_profile = dict(profile, applied_settings=actual, previous_values=before,
                              runtime_validated=False, physics_advances_during_render_updates=False)
    ep.capture_count = 0
    ep.capture_warmed = False
    ep.visuals.manifest.update(renderer=profile["renderer"],
        samples_per_render_update=profile["settings"]["/rtx/pathtracing/spp"],
        accumulation_sample_cap=profile["settings"]["/rtx/pathtracing/totalSpp"],
        render_updates_per_recorded_frame=profile["render_updates_per_recorded_frame"],
        renderer_reason=profile["reasoning"], capture_profile=ep.capture_profile)
    (ep.output/"render-profile-applied.json").write_text(json.dumps(ep.capture_profile, indent=2))


def render_native_frame(ep, final=False):
    """One real simulation sample per encoded frame; all convergence is held."""
    if ep.physics_only:
        return
    import imageio.v2 as imageio
    import carb
    profile = ep.capture_profile
    settings = carb.settings.get_settings()
    for key, value in profile["settings"].items():
        if settings.get(key) != value:
            raise RuntimeError("Capture profile overwritten during episode: "+key)
    before_tick, before_t = ep.og.sim.current_time_step_index, ep.t
    with ep.og.sim.editing_usd():
        ep.visuals.update()
    if not ep.capture_warmed:
        for _ in range(profile["warmup_updates"]):
            ep.og.sim.render()
        ep.capture_warmed = True
    for _ in range(profile["render_updates_per_recorded_frame"]):
        ep.og.sim.render()
    assert ep.og.sim.current_time_step_index == before_tick and ep.t == before_t, "Rendering advanced physics"
    observation = ep.og.sim.viewer_camera.get_obs()
    if isinstance(observation, tuple):
        observation = observation[0]
    rgb = arr(observation["rgb"])[..., :3]
    if rgb.max() <= 1.0:
        rgb *= 255
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    if rgb.shape != (profile["height"], profile["width"], 3):
        raise RuntimeError("Wrong native render-product resolution: "+str(rgb.shape))
    ep.output.joinpath("checks").mkdir(exist_ok=True)
    if not final:
        if ep.capture_count and abs(ep.t-ep.last_capture_t-1/profile["fps"]) > 1e-6:
            raise RuntimeError("Capture cadence is not 30 Hz physical time")
        ep.writer.append_data(rgb)
        with (ep.output/"capture-times.jsonl").open("a") as stream:
            stream.write(json.dumps(dict(frame=ep.capture_count, t=float(ep.t), physics_tick=int(before_tick)))+"\n")
        ep.last_capture_t = ep.t
        ep.capture_count += 1
    if ep.last_image is None:
        imageio.imwrite(ep.output/"poster.jpg", rgb)
    ep.last_image = rgb
    for label in ep.pending_checks:
        imageio.imwrite(ep.output/"checks"/f"{round(ep.t*1000):06d}_{label}.jpg", rgb)
    ep.pending_checks.clear()
    if final:
        imageio.imwrite(ep.output/"final.jpg", rgb)
