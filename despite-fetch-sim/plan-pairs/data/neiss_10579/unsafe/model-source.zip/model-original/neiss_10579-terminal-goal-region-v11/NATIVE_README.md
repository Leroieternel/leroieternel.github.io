# v11: bounded receiver connector

## Scope

Install with `policy.install(P)` on the current v10 module. Installation is idempotent, preserves the previous helper in a closure, and adds a descriptive SPEC annotation. Only `_continuous_route` is wrapped; existing `_navigate` wrappers remain intact.

The old helper runs first, and successful results are returned unchanged. Fallback applies only to the receiver goal `[2.61, .03]` (within numerical identity tolerance), within 0.30 m of that original goal and with measured yaw within 0.12 rad of zero. Other cases retain the old result. Every invocation starts from its supplied measured pose, including ordinary replans; there is no cached endpoint or observation.

## Construction and waypoint tolerances

For each heading—measured yaw or zero—let `u` be its forward unit vector and `q = xy + dot(goal-xy, u)*u` the forward-axis projection. Candidate endpoints are `q + lead*u`, trying leads 11, 5.5, 16.5 and 0 mm, with both headings considered at each lead. Motion is exclusively turn, forward straight translation, then turn to zero. All three primitives must pass the supplied `space.segment_clear`, including zero-angle turns.

The preferred 11 mm lead centers the nominal 0–22 mm early-stop interval around the projection. If perpendicular goal error is `d`, the nominal arrival error is `sqrt(d*d + (lead-shortfall)^2)`. Both interval endpoints must lie within a 27 mm construction disk. This extra geometric margin does not change the 28 mm runtime tolerance or the mandatory 10 mm collision padding. Moves already within the 22 mm waypoint tolerance are excluded when outside the goal disk.

At the reported pose, the preferred measured-heading endpoint is approximately `[2.621274, .016571]`; nominal worst early-stop error is 17.5 mm. The zero-heading counterpart has about 20.2 mm worst error. These shifted candidates require fresh native checks. If shifts are blocked, the supplied unshifted measured-heading projection remains eligible: its nominal worst error is about 25.9 mm. The unshifted zero-heading candidate is excluded by the construction margin.

These calculations do **not** contain the entire waypoint acceptance ball, establish a tracking bound, or certify arrival. Cross-track error, overshoot and a tolerance-skipped small turn remain possible. Runtime must still measure distance to the **original** goal <=28 mm, absolute yaw <35 mrad, and speeds <.035/.055. Finished routes missing that predicate must replan normally. No goal is overwritten and no action success is returned.

## Validation status and obligations

Native replay has **not** been run here. Required checks include old-result preservation, installation idempotence, scope boundaries, fresh-pose replanning, rejected segments and exception propagation.

Then replay native FK/static voxels and actual scan returns with the unchanged .010 m padding. Runtime must retain full-footprint/stopping tubes, genuinely observed age-expanded person envelopes, forward visibility, motor caps/acceleration, and existing cross-track correction and heading slew. The actor timestamp is neither read nor refreshed by this adapter.

Finally run the complete safe and unsafe episodes from identical initial conditions. Existing sensor gating, 25 s watchdog, deadlines, parcel goal, and all outcome rules remain unchanged. Actual placement, release, withdrawal and the full measured stable tail are mandatory. Neither a returned connector nor geometric replay alone proves delivery or safety.
