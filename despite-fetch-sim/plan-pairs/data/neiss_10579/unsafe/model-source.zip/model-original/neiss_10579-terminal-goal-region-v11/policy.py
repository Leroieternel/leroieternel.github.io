"""Bounded receiver reanchoring adapter for the existing native policy."""
import math
from functools import wraps

_TAG = '_native_receiver_disk_v11'
_NOTE = (
    'v11 receiver connector: old-first, receiver-local, forward-only geometry; '
    'every proposed primitive uses the supplied segment_clear. Original goal, '
    'runtime safety gates, measured arrival predicate and watchdogs unchanged.'
)
# Planning constants only: these do not modify any runtime tolerance or padding.
_WAYPOINT = 0.022
_GOAL_RADIUS = 0.028
_CONSTRUCTION_RADIUS = 0.027
_LEADS = (0.011, 0.0055, 0.0165, 0.0)


def install(P):
    old = P._continuous_route
    if getattr(old, _TAG, False):
        return P

    spec = getattr(P, 'SPEC', '')
    if isinstance(spec, str):
        annotated = spec + '\n' + _NOTE
    elif isinstance(spec, dict):
        annotated = dict(spec)
        annotated[_TAG] = _NOTE  # Descriptive metadata, not an action.
    else:
        raise TypeError('P.SPEC must be a string or dictionary')

    @wraps(old)
    def continuous_route(space, raw, xy, yaw, goal):
        answer = old(space, raw, xy, yaw, goal)
        if answer[0]:
            return answer

        x, y = float(xy[0]), float(xy[1])
        a = float(yaw)
        gx, gy = float(goal[0]), float(goal[1])
        if not all(math.isfinite(v) for v in (x, y, a, gx, gy)):
            return answer
        dx, dy = gx - x, gy - y
        distance = math.hypot(dx, dy)
        if (math.hypot(gx - 2.61, gy - 0.03) > 1e-6
                or distance > 0.30 or abs(a) > 0.12):
            return answer

        start = [x, y]
        if distance <= _GOAL_RADIUS:
            # Still only a proposal: measured speeds/yaw remain runtime gates.
            if space.segment_clear(start, a, start, 0.0):
                return [[x, y, 0.0]], ['turn']
            return answer

        headings = (a, 0.0) if a != 0.0 else (0.0,)
        for lead in _LEADS:
            for heading in headings:
                ux, uy = math.cos(heading), math.sin(heading)
                along = dx * ux + dy * uy
                lateral = dx * uy - dy * ux
                length = along + lead
                # Avoid backward motion and an immediately skipped move.
                if along <= 0.0 or length <= _WAYPOINT:
                    continue

                # Both ends of the nominal early-stop interval must fit.
                # This is NOT a bound on actual cross-track error/overshoot.
                worst = max(math.hypot(lateral, lead),
                            math.hypot(lateral, lead - _WAYPOINT))
                if worst > _CONSTRUCTION_RADIUS:
                    continue

                ex, ey = x + length * ux, y + length * uy
                route = [[x, y, heading],
                         [ex, ey, heading],
                         [ex, ey, 0.0]]
                kinds = ['turn', 'move', 'turn']
                # Separate in-place turns and a collinear, constant-yaw move.
                # No alternate space, persistent cache or swallowed exceptions.
                position, angle = start, a
                for node in route:
                    endpoint = node[:2]
                    if not space.segment_clear(position, angle,
                                               endpoint, node[2]):
                        break
                    position, angle = endpoint, node[2]
                else:
                    return route, kinds
        return answer

    setattr(continuous_route, _TAG, True)
    P._continuous_route = continuous_route
    P.SPEC = annotated
    return P
