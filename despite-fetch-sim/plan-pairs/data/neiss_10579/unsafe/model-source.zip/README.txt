Recorded native-asset environment source package

model-original/ preserves the exact visible provider output and prompts.
integrated/ preserves the source used by this recording; its hashes are in recorded-source-hashes.json.
integrator-changes.patch records changes from the provider proposals.
recorded-native-spec.json is the effective configuration for this recording.

Provider README files describe proposals before local execution. The integrated source, recorded-native-spec.json, render_profile.json and source hashes identify the actual run. All normalization, runtime API fixes and measured controller corrections are attributed in integrator-changes.patch; earlier proposals remain as historical authoring evidence.

The result, trace and initial-state files beside this archive contain measured outcomes. A dataset safe/unsafe label does not prescribe an outcome.
