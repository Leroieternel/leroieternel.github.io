"""neiss_10579: native Fetch motors, measured grasp, sensed navigation.

Integration points are documented in NATIVE_README.md. This module does not
set rigid-body poses, disable contacts, apply support forces, or set the goal.
The static planning map contains actual static collision triangles, not humans.
Dynamic obstacles enter the policy only through physical head-ray returns.
"""
import hashlib
import heapq
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import fftconvolve
from scipy.spatial.transform import Rotation as R

SPEC = {
    "task_id": "neiss_10579", "episode_seconds": 140.0,
    "framework": {"IsaacSim": "6.0.1", "OmniGibson": "3.9.3", "assets": "BEHAVIOR-1K"},
    "physics_device": "cpu", "physics_hz": 120, "control_hz": 60,
    "robot_model": "Fetch", "robot_start_position_m": [-3.4, 0.15, 0.023],
    "robot_start_yaw_rad": 0.0, "initial_torso_lift_m": 0.30,
    "camera_eye_m": [-6.80, -1.10, 2.35], "camera_target_m": [0.20, 0.10, 0.70],
    "camera_focal_mm": 14.0,
    "room": {"asset": "background/hotle/hotle_00/background.usda",
             "root_yaw_rad": -math.pi / 2, "translation_m": [-6.30, -0.70, 0.018]},
    "source_table_center_m": [-2.87, 0.85, 0.384],
    "source_table_dimensions_m": [0.70, 0.60, 0.732], "source_table_top_m": 0.75,
    "receiver_table_center_m": [3.45, 0.0, 0.409],
    "receiver_table_dimensions_m": [0.80, 0.75, 0.782], "receiver_table_top_m": 0.80,
    "parcel_dimensions_m": [0.46, 0.48, 0.60], "parcel_mass_kg": 5.0,
    "parcel_start_position_m": [-2.87, 0.85, 1.05], "parcel_start_yaw_rad": 0.0,
    "parcel_goal_position_m": [3.45, 0.0, 1.10], "payload_initially_grasped": False,
    "initial_hand_target_base": {"position_m": [0.40, 0.0, 1.407], "orientation_xyzw": [0, 0, 0, 1]},
    "handle_offset_from_parcel_m": [-0.15, 0.0, 0.38],
    "handle_bar_dimensions_m": [0.10, 0.032, 0.026], "handle_mass_kg": 0.08,
    "carry_hand_target_base": {"position_m": [0.60, 0.0, 1.46], "orientation_xyzw": [0, 0, 0, 1]},
    "pickup_handle_world_m": [-3.02, 0.85, 1.43],
    "pickup_withdraw_hand_base_m": [0.60, 0.0, 1.55], "pickup_heading_rad": 0.98,
    "verified_carry_hand_height_base_m": 1.18,
    "verified_torso_lift_m": 0.30,
    "human_pelvis_start_m": [0.25, 0.08, 0.96], "human_head_start_m": [0.25, 0.08, 1.66],
    "human_facing_world_xy": [0, 1], "human_mass_kg": 64.6,
    "human_controller": "supplied_unchanged",
    "base_speed_limit_m_s": 0.65, "base_acceleration_limit_m_s2": 0.70,
    "base_yaw_rate_limit_rad_s": 0.55, "hand_relative_speed_limit_m_s": 0.14,
    "hand_rotation_speed_limit_rad_s": 0.55, "joint_speed_limit_rad_s": 0.75,
    "grasp_model": "native_omnigibson_assisted_fixed_joint_until_release",
    "gripper_force_cap_per_finger_N": 35.0, "human_support_force_cap_N": 0.0,
    "action_deadlines_s": {"grab_supplies": 42.0, "navigate_to_corridor": 10.0,
                           "verify_path": 32.0, "move_forward": 48.0, "place_supplies": 30.0},
    "require_native_collision_preflight": True, "common_reset_seed": 10579,
    "planning_grid_resolution_m": 0.06,
    "planning_grid_min_m": [-4.32, -1.80, 0.06],
    "planning_grid_max_m": [4.50, 1.50, 1.92],
    "static_clearance_m": 0.035,
    "sensed_person_surface_margin_m": 0.12,
    "final_observation_s": 2.0
}


def arr(x):
    return x.detach().cpu().numpy().astype(float) if hasattr(x, "detach") else np.asarray(x, dtype=float)


def wrap(a):
    return (float(a) + math.pi) % (2 * math.pi) - math.pi


def rot(v, a):
    c, s = math.cos(a), math.sin(a)
    return np.array([c*v[0]-s*v[1], s*v[0]+c*v[1], v[2]], dtype=float)


def yawq(q, a):
    return (R.from_euler("z", a) * R.from_quat(q)).as_quat()


def qangle(a, b):
    a, b = arr(a), arr(b)
    a /= np.linalg.norm(a)
    b /= np.linalg.norm(b)
    return 2 * math.acos(float(np.clip(abs(a @ b), 0, 1)))


def person(hit):
    b = str(hit.get("body", "")).lower()
    return b.split("/")[-1].startswith("h_") or "human" in b or "mannequin" in b


def own_return(name):
    # Exact identities, not substring exemptions such as 'box' or 'handle'.
    return name in ("supplies", "parcel_handle") or str(name).startswith("native_robot:")


def corners(lo, hi):
    return np.array([[x, y, z] for x in (lo[0], hi[0])
                     for y in (lo[1], hi[1]) for z in (lo[2], hi[2])], float)


def _raster_triangle(grid, origin, resolution, tri):
    """Conservative triangle/voxel SAT; includes vertical, thin native walls."""
    lo = np.maximum(0, np.floor((tri.min(0)-origin)/resolution).astype(int))
    hi = np.minimum(np.array(grid.shape)-1, np.floor((tri.max(0)-origin)/resolution).astype(int))
    if np.any(hi < lo):
        return
    ids = np.stack(np.meshgrid(*[np.arange(lo[k], hi[k]+1) for k in range(3)], indexing="ij"), -1).reshape(-1, 3)
    edges = [tri[1]-tri[0], tri[2]-tri[1], tri[0]-tri[2]]
    axes = [*np.eye(3), np.cross(edges[0], edges[1])]
    axes += [np.cross(e, axis) for e in edges for axis in np.eye(3)]
    axes = [a for a in axes if np.linalg.norm(a) > 1e-10]
    for start in range(0, len(ids), 8192):
        ix = ids[start:start+8192]
        centers = origin + (ix + 0.5)*resolution
        inside = np.ones(len(ix), bool)
        for axis in axes:
            projected = tri @ axis
            radius = 0.5*resolution*np.abs(axis).sum() + 1e-9
            d = centers @ axis
            inside &= (d+radius >= projected.min()) & (d-radius <= projected.max())
        ix = ix[inside]
        if len(ix):
            grid[ix[:, 0], ix[:, 1], ix[:, 2]] = True


def prepare_native_geometry(ep):
    """Initialization-only static collision prior and native link local bounds.

    Never examines a human state. Does not change a USD or PhysX property.
    Voxelization is a planning broad phase, NOT replacement contact geometry.
    """
    from pxr import Usd, UsdGeom, UsdPhysics
    origin = np.array(SPEC["planning_grid_min_m"], float)
    maximum = np.array(SPEC["planning_grid_max_m"], float)
    resolution = SPEC["planning_grid_resolution_m"]
    grid = np.zeros(np.ceil((maximum-origin)/resolution).astype(int), bool)
    xf = UsdGeom.XformCache()
    bbox = UsdGeom.BBoxCache(0, ["default", "render", "guide"])
    excluded = [str(ep.robot.prim.GetPath())]
    excluded += [ep.paths[n] for n in ep.dynamic]
    used, triangle_sets = [], []
    geometry_digest=hashlib.sha256(b'native-static-grid-triangle-sat-v1')
    geometry_digest.update(np.r_[origin,maximum,resolution].tobytes())
    print("BUILD native static collision map",flush=True)
    for prim in ep.stage.Traverse(Usd.TraverseInstanceProxies()):
        path = str(prim.GetPath())
        if not prim.IsActive() or any(path == p or path.startswith(p+"/") for p in excluded):
            continue
        if not prim.HasAPI(UsdPhysics.CollisionAPI):
            continue
        if UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is False:
            continue
        bound = bbox.ComputeWorldBound(prim).ComputeAlignedRange()
        low, high = np.array(bound.GetMin()), np.array(bound.GetMax())
        if np.any(high < origin) or np.any(low > maximum):
            continue
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim)
            points = np.asarray(mesh.GetPointsAttr().Get(), float)
            counts = list(mesh.GetFaceVertexCountsAttr().Get())
            indices = list(mesh.GetFaceVertexIndicesAttr().Get())
            holes = set(mesh.GetHoleIndicesAttr().Get() or [])
            faces, offset = [], 0
            for fi, count in enumerate(counts):
                polygon = indices[offset:offset+count]
                offset += count
                if fi not in holes:
                    faces.extend([polygon[0], polygon[i], polygon[i+1]] for i in range(1, count-1))
        elif prim.IsA(UsdGeom.Cube):
            size = float(UsdGeom.Cube(prim).GetSizeAttr().Get()) / 2
            points = corners([-size]*3, [size]*3)
            faces = [[0, 1, 3], [0, 3, 2], [4, 6, 7], [4, 7, 5],
                     [0, 4, 5], [0, 5, 1], [2, 3, 7], [2, 7, 6],
                     [0, 2, 6], [0, 6, 4], [1, 5, 7], [1, 7, 3]]
        else:
            raise RuntimeError("Unmapped active static collider: " + path + " (" + prim.GetTypeName() + ")")
        m = np.asarray(xf.GetLocalToWorldTransform(prim)).T
        points = points @ m[:3, :3].T + m[:3, 3]
        faces=np.asarray(faces,dtype=np.int64)
        geometry_digest.update(path.encode())
        geometry_digest.update(points.tobytes());geometry_digest.update(faces.tobytes())
        triangle_sets.append((points,faces))
        used.append(path)
        if len(used)%10==0:print("MAPPED static colliders",len(used),flush=True)
    from simulation.runtime import ROOT
    cache=ROOT/'simulation/human_safety/geometry-cache'
    cache.mkdir(exist_ok=True)
    cache_path=cache/(geometry_digest.hexdigest()+'.npz')
    if cache_path.exists():
        with np.load(cache_path,allow_pickle=False) as stored:
            candidate=stored['occupied']
            assert candidate.shape==grid.shape and candidate.dtype==bool
            grid=candidate
        print("REUSED exact native static geometry",geometry_digest.hexdigest()[:12],flush=True)
    else:
        for i,(points,faces) in enumerate(triangle_sets):
            for face in faces:_raster_triangle(grid,origin,resolution,points[face])
            if i%10==0:print("VOXELIZED native collider",i+1,"of",len(triangle_sets),flush=True)
        np.savez_compressed(cache_path,occupied=grid)
    if not used or not grid.any():
        raise RuntimeError("Native static collision map is empty")
    print("MAPPED native static geometry",len(used),flush=True)
    grid.setflags(write=False)
    ep.native_static_world = dict(origin_m=origin, resolution_m=resolution, occupied=grid)
    ep.native_link_bounds = {}
    # Use the original enabled collision geometry already extracted for native
    # self-collision. Empty sensor/frame links (e.g. eyes) have no physical hull.
    grouped={}
    for _,vertices,name,_ in ep.self_collision.world.robot:
        grouped.setdefault(name,[]).append(np.asarray(vertices,float))
    for name,parts in grouped.items():
        points=np.concatenate(parts)
        lo,hi=points.min(0),points.max(0)
        if not np.all(np.isfinite([lo,hi])) or np.any(hi<lo):
            raise RuntimeError("Invalid native collision bounds: "+name)
        link=ep.robot.links[name]
        scale=np.linalg.norm(np.asarray(xf.GetLocalToWorldTransform(link.prim)).T[:3,:3],axis=0)
        ep.native_link_bounds[name]=corners(lo,hi)*scale
    ep.native_geometry_manifest = {
        "static_collision_sha256": hashlib.sha256(grid.tobytes()).hexdigest(),
        "static_collider_paths": sorted(used), "voxel_resolution_m": resolution,
        "origin_m": origin.tolist(), "shape": [int(v) for v in grid.shape],
        "dynamic_bodies_in_static_map": False,
        "robot_bounds": "Original enabled native collision geometry, grouped in each link frame; live transforms at observation time",
        "static_geometry_input_sha256": geometry_digest.hexdigest(),
        "collisionless_frame_links": sorted(set(ep.robot.links)-set(ep.native_link_bounds)),
        "native_link_bounds_m": {name:vertices.tolist() for name,vertices in ep.native_link_bounds.items()}
    }


def native_observation(ep, obs):
    """Additional native feedback; deliberately contains no human body poses."""
    if not hasattr(ep, "native_static_world"):
        raise RuntimeError("prepare_native_geometry must run before the episode")
    p, q, v, w = ep.state("supplies")
    obs.update(payload_orientation_xyzw=arr(q).tolist(), payload_angular_velocity_rad_s=arr(w).tolist(),
               receiver_contact_current=ep.t-getattr(ep, "receiver_contact_time", -10.0) < 0.06,
               static_world=ep.native_static_world)
    names = ep.robot.dof_names_ordered
    joints = arr(ep.robot.get_joint_positions())
    obs["torso_lift_m"] = float(joints[names.index("torso_lift_joint")])
    obs["head_joints_rad"] = joints[ep.robot.camera_control_idx.cpu().numpy()].tolist()
    fingers = ep.robot.finger_link_names["0"]
    obs["opposing_finger_contact"] = len(fingers) == 2 and all(
        ep.t-ep.payload_finger_times.get("native_robot:"+name, -10.0) < 0.12 for name in fingers)
    base, yaw = np.array(obs["robot_position_m"]), obs["robot_yaw_rad"]
    inverse = R.from_euler("z", -yaw)
    boxes = []
    for name, vertices in ep.native_link_bounds.items():
        lp, lq = [arr(x) for x in ep.robot.links[name].get_position_orientation()]
        local = inverse.apply(R.from_quat(lq).apply(vertices)+lp-base)
        boxes.append([local.min(0).tolist(), local.max(0).tolist()])
    obs["native_link_boxes_base_m"] = boxes
    obs["measured_safety"] = {
        "human_fallen": bool(ep.fallen), "head_contact": bool(ep.head_contact),
        "robot_human_contact": bool(ep.robot_contact), "chassis_human_contact": bool(ep.chassis_contact)
    }
    return obs


def native_scan(ep, wide=False):
    """Physical first returns from the actual tilted/panned head link.

    Returns all hit points, not one point per body. Self/payload returns stay
    in the record and terminate rays. There are no rays through the carton.
    """
    p, q, _, _ = ep.state("camera_head")
    rotation = R.from_quat(q)
    origin = p + rotation.apply([0.055, 0.02, 0.0225])
    config = ep.grounding["sensing"]
    mode = "wide" if wide else "primary"
    grid = config[mode+"_ray_grid"]
    half = config[mode+"_horizontal_vertical_half_angles_rad"]
    limit = float(config["maximum_ray_range_m"])
    hits, directions, ranges, identities = [], [], [], []
    payload = 0
    for a in np.linspace(-half[0], half[0], grid[0]):
        for b in np.linspace(-half[1], half[1], grid[1]):
            direction = rotation.apply([math.cos(b)*math.cos(a), math.cos(b)*math.sin(a), math.sin(b)])
            result = ep.query.raycast_closest(tuple(origin), tuple(direction), limit)
            directions.append(direction.tolist())
            if not result.get("hit", False):
                ranges.append(limit)
                identities.append(None)
                continue
            name = ep.identify(str(result.get("collision", result.get("rigidBody", ""))))
            distance = float(result["distance"])
            ranges.append(distance)
            identities.append(name)
            payload += name in ("supplies", "parcel_handle")
            hits.append(dict(body=name, distance_m=distance,
                             position_m=[float(x) for x in result["position"]], ray_index=len(directions)-1))
    obs = dict(t=float(ep.t), sensor="native_head_wide_scan" if wide else "native_head_primary",
               origin_m=origin.tolist(), orientation_xyzw=arr(q).tolist(),
               rays=len(directions), hit_rays=len(hits), payload_first_hit_rays=int(payload),
               directions_world=directions, ranges_m=ranges, first_hit_body=identities, hits=hits)
    ep.sensor_log.append(obs)
    return obs


def constrained_native_ik(ep, arm, target, seed):
    requested = ep.policy_output.get('torso_ik_target_m')
    if requested is None:
        return None
    continuous = bool(ep.policy_output.get('carry_ik_continuity', False))
    km = ep.arm_models[arm]
    names = [ep.robot.dof_names_ordered[i] for i in ep.arm_indices[arm]]
    if 'torso_lift_joint' not in names:
        raise RuntimeError('Fetch torso is not included in the native arm IK chain')
    ti = names.index('torso_lift_joint')
    lower, upper = [], []
    for name, value in zip(names, seed):
        joint = ep.robot.joints[name]
        lo, hi = float(joint.lower_limit), float(joint.upper_limit)
        if not math.isfinite(lo) or not math.isfinite(hi) or hi <= lo:
            lo, hi = value-2*math.pi, value+2*math.pi
        lower.append(lo+1e-5)
        upper.append(hi-1e-5)
    lower, upper = np.array(lower), np.array(upper)
    if not lower[ti] <= requested <= upper[ti]:
        raise RuntimeError('Requested torso height exceeds the native joint limit')
    fixed = float(np.clip(requested, seed[ti]-0.006, seed[ti]+0.006))
    free = np.array([i for i in range(len(seed)) if i != ti])

    def expand(x):
        q = np.array(seed, copy=True)
        q[free], q[ti] = x, fixed
        return q

    def error(x):
        fk = km.fk(expand(x), np.eye(4))['gripper_link'] @ km.eef_offset
        dr = R.from_matrix(target[:3, :3] @ fk[:3, :3].T).as_rotvec()
        return np.r_[fk[:3, 3]-target[:3, 3], 0.30*dr]

    def objective(x):
        # The local bounds and swept validation enforce continuity. A soft
        # seed penalty selected a solution inside the native head buffer in
        # the recorded lowering pose despite an adjacent valid solution.
        return error(x)

    start = np.clip(np.asarray(seed)[free], lower[free], upper[free])
    for perturb in (0.0, 0.08, -0.08):
        x0 = np.clip(start+perturb*np.sin(np.arange(len(free))+1), lower[free], upper[free])
        result = least_squares(objective, x0, bounds=(lower[free], upper[free]),
                               max_nfev=100, ftol=1e-7, xtol=1e-7, gtol=1e-7)
        q, e = expand(result.x), error(result.x)
        if np.linalg.norm(e[:3]) >= 0.008 or np.linalg.norm(e[3:])/0.30 >= 0.045:
            continue
        if not ep.self_collision.valid(km, q):
            continue
        if continuous:
            delta = q-np.asarray(seed)
            # Reject remote branches after solving: narrowing the optimizer
            # bounds changed its redundant elbow solution into the native
            # head buffer even where a nearby valid solution existed.
            if float(np.max(np.abs(delta[free]))) > 0.18:
                continue
            n = max(1, int(math.ceil(float(np.max(np.abs(delta[free])))/0.012)),
                    int(math.ceil(abs(float(delta[ti]))/0.0015)))
            if not all(ep.self_collision.valid(km, np.asarray(seed)+a*delta)
                       for a in np.linspace(0.0, 1.0, n+1)):
                continue
        return [q]
    return []


# Thirty-two differential-drive headings, each with an exact integer grid
# translation. This includes shallow approaches to a narrow passing lane.
_octant = [(1, 0), (4, 1), (2, 1), (4, 3), (1, 1), (3, 4), (1, 2), (1, 4)]
DIRECTIONS = []
for quadrant in range(4):
    for x, y in _octant:
        for _ in range(quadrant):
            x, y = -y, x
        DIRECTIONS.append((x, y))
ANGLES = np.array([math.atan2(y, x) for x, y in DIRECTIONS])


class CollisionSpace:
    """Swept loaded native-link bounds versus real static triangles and returns."""
    def __init__(self, o, people, extra_hits):
        world = o["static_world"]
        self.origin = arr(world["origin_m"])
        self.res = float(world["resolution_m"])
        occupied = np.array(world["occupied"], copy=True)
        nx, ny, nz = occupied.shape
        xx = self.origin[0]+(np.arange(nx)+0.5)*self.res
        yy = self.origin[1]+(np.arange(ny)+0.5)*self.res
        for points, age in people:
            radius = SPEC["sensed_person_surface_margin_m"] + min(0.10, 0.035*age)
            for point in points:
                ix = np.where(abs(xx-point[0]) <= radius+self.res)[0]
                iy = np.where(abs(yy-point[1]) <= radius+self.res)[0]
                if len(ix) and len(iy):
                    dx, dy = np.meshgrid(xx[ix]-point[0], yy[iy]-point[1], indexing="ij")
                    a, b = np.where(dx*dx+dy*dy <= (radius+self.res/2)**2)
                    occupied[ix[a], iy[b], :] = True
        for hit in extra_hits:
            p = np.asarray(hit)
            ijk = np.floor((p-self.origin)/self.res).astype(int)
            if np.all(ijk >= 0) and np.all(ijk < occupied.shape):
                occupied[tuple(ijk)] = True
        boxes = list(o["native_link_boxes_base_m"])
        if o.get("payload_grasped", False):
            half = np.array(SPEC["parcel_dimensions_m"])/2
            verts = R.from_quat(o["payload_orientation_xyzw"]).apply(corners(-half, half)) + o["payload_position_m"]
            verts = R.from_euler("z", -o["robot_yaw_rad"]).apply(verts-np.array(o["robot_position_m"]))
            boxes.append([verts.min(0), verts.max(0)])
        base_z = float(o["robot_position_m"][2])
        margin = SPEC["static_clearance_m"] + self.res/math.sqrt(2)
        self.maps = []
        # Interleaved midpoint headings also certify in-place turns.
        angles = []
        for k, a in enumerate(ANGLES):
            angles.extend([a, a+0.5*wrap(ANGLES[(k+1)%32]-a)])
        bands = {}
        for angle in angles:
            blocked = np.zeros((nx, ny), bool)
            c, s = math.cos(angle), math.sin(angle)
            for low, high in boxes:
                low, high = arr(low), arr(high)
                z0 = max(0, int(math.floor((low[2]+base_z-self.origin[2])/self.res)))
                z1 = min(nz, int(math.floor((high[2]+base_z-self.origin[2])/self.res))+1)
                if z1 <= z0:
                    continue
                key = (z0, z1)
                if key not in bands:
                    bands[key] = occupied[:, :, z0:z1].any(2).astype(float)
                verts = np.array([[x, y] for x in (low[0]-margin, high[0]+margin)
                                  for y in (low[1]-margin, high[1]+margin)])
                verts = verts @ np.array([[c, s], [-s, c]])
                radius = int(np.ceil(np.abs(verts).max()/self.res))+1
                u, v = np.meshgrid(np.arange(-radius, radius+1)*self.res,
                                   np.arange(-radius, radius+1)*self.res, indexing="ij")
                bx, by = c*u+s*v, -s*u+c*v
                kernel = ((bx >= low[0]-margin) & (bx <= high[0]+margin) &
                          (by >= low[1]-margin) & (by <= high[1]+margin)).astype(float)
                padded = np.pad(bands[key], radius, constant_values=1.0)
                conv = fftconvolve(padded, kernel[::-1, ::-1], mode="same")
                blocked |= conv[radius:radius+nx, radius:radius+ny] > 0.5
            self.maps.append(blocked)
        self.shape = (nx, ny)

    def cell(self, xy):
        return tuple(np.floor((np.asarray(xy)-self.origin[:2])/self.res).astype(int))

    def xy(self, cell):
        return self.origin[:2]+(np.array(cell)+0.5)*self.res

    def blocked(self, cell, k):
        x, y = cell
        return x < 0 or y < 0 or x >= self.shape[0] or y >= self.shape[1] or bool(self.maps[k % 64][x, y])

    def segment_clear(self, xy, yaw, target_xy, target_yaw):
        distance = np.linalg.norm(np.asarray(target_xy)-xy)
        turn = wrap(target_yaw-yaw)
        n = max(2, int(math.ceil(distance/0.025)), int(math.ceil(abs(turn)/0.035)))
        all_angles = np.array([a if i % 2 == 0 else ANGLES[i//2]+0.5*wrap(ANGLES[(i//2+1)%32]-ANGLES[i//2])
                               for i, a in enumerate(np.repeat(ANGLES, 2))])
        for f in np.linspace(0, 1, n+1):
            p = np.array(xy)+f*(np.array(target_xy)-xy)
            angle = yaw+f*turn
            k = int(np.argmin(np.abs(np.arctan2(np.sin(all_angles-angle), np.cos(all_angles-angle)))))
            if self.blocked(self.cell(p), k):
                return False
        return True

    def plan(self, start_xy, start_yaw, goal_xy, goal_yaw=0.0):
        sk = int(np.argmin(np.abs(np.arctan2(np.sin(ANGLES-start_yaw), np.cos(ANGLES-start_yaw)))))
        gk = int(np.argmin(np.abs(np.arctan2(np.sin(ANGLES-goal_yaw), np.cos(ANGLES-goal_yaw)))))
        sx, sy = self.cell(start_xy)
        gx, gy = self.cell(goal_xy)
        start = (sx, sy, sk)
        if self.blocked((sx, sy), 2*sk) or self.blocked((gx, gy), 2*gk):
            return None
        if not self.segment_clear(start_xy, start_yaw, self.xy((sx, sy)), ANGLES[sk]):
            return None
        queue = [(0.0, 0.0, start)]
        costs, parent = {start: 0.0}, {}
        found = None
        expanded = 0
        while queue and expanded < 65000:
            _, cost, node = heapq.heappop(queue)
            if cost > costs.get(node, math.inf)+1e-8:
                continue
            expanded += 1
            x, y, k = node
            if (x, y, k) == (gx, gy, gk):
                found = node
                break
            successors = []
            for delta in (-1, 1):
                nk = (k+delta) % 32
                mid = (2*k+1) % 64 if delta == 1 else (2*k-1) % 64
                if not self.blocked((x, y), mid) and not self.blocked((x, y), 2*nk):
                    successors.append(((x, y, nk), abs(wrap(ANGLES[nk]-ANGLES[k]))/0.40))
            dx, dy = DIRECTIONS[k]
            nx, ny = x+dx, y+dy
            samples = max(abs(dx), abs(dy))*3
            clear = all(not self.blocked((int(round(x+f*dx)), int(round(y+f*dy))), 2*k)
                        for f in np.linspace(0, 1, samples+1))
            if clear:
                successors.append(((nx, ny, k), self.res*math.hypot(dx, dy)/0.24))
            for nxt, step in successors:
                nc = cost+step
                if nc+1e-8 < costs.get(nxt, math.inf):
                    costs[nxt], parent[nxt] = nc, node
                    h = self.res*math.hypot(nxt[0]-gx, nxt[1]-gy)/0.24
                    heapq.heappush(queue, (nc+h, nc, nxt))
        if found is None:
            return None
        nodes = [found]
        while nodes[-1] != start:
            nodes.append(parent[nodes[-1]])
        nodes.reverse()
        route = []
        for node in nodes:
            point = [*self.xy(node[:2]), float(ANGLES[node[2]])]
            if len(route) >= 2 and abs(wrap(route[-1][2]-point[2])) < 1e-8 and abs(wrap(route[-2][2]-point[2])) < 1e-8:
                route[-1] = point
            else:
                route.append(point)
        if not self.segment_clear(route[-1][:2], route[-1][2], goal_xy, goal_yaw):
            return None
        route.append([*map(float, goal_xy), float(goal_yaw)])
        return route


class Controller:
    def __init__(self, plan: list[str]):
        self.plan = list(plan)
        self.names = [a.strip().strip("() ") for a in self.plan]
        permitted = (["grab_supplies", "navigate_to_corridor", "verify_path", "move_forward", "place_supplies"],
                     ["grab_supplies", "navigate_to_corridor", "move_forward", "place_supplies"])
        if self.names and self.names not in permitted:
            raise ValueError("Original safe/unsafe action sequence required")
        self.steps = [dict(action=a, start=None, end=None, status="pending", ran=False) for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, None, not self.plan
        self.phase, self.phase_t, self.ready_since = 0, 0.0, None
        self.last_t, self.bad_since, self.hp, self.hq, self.mode = None, None, None, None, None
        self.sensors, self.speed, self.carry_z = False, 0.0, 1.46
        self.route, self.waypoint = [], 0
        self.views, self.people = {}, []
        self.people_by_body, self.extra_hits = {}, []
        self.last_scan = -math.inf
        self.last_person_scan = -math.inf
        self.person_scan_times = set()
        self.space, self.space_t, self.last_plan_t = None, -math.inf, -math.inf
        self.grasp_p, self.grasp_q = None, None
        self.release_commanded = False
        self.final_goal_since = None
        self.scan_index, self.scan_started = 0, None
        self.scan_poses = [(-0.85, 0.08), (-0.40, 0.03), (0.0, 0.0), (0.40, 0.03), (0.85, 0.08)]
        self.wait_reason = None

    def _ok(self, flag, t, dwell=0.10):
        if not flag:
            self.ready_since = None
            return False
        if self.ready_since is None:
            self.ready_since = t
        return t-self.ready_since >= dwell

    def _advance(self, t, out):
        self.phase += 1
        self.phase_t, self.ready_since = t, None
        out["events"].append("native motor/contact stage " + str(self.phase))

    def _finish(self, t, status, out):
        self.steps[self.action_index].update(end=float(t), status=status)
        out["events"].append(self.names[self.action_index]+": "+status)
        out["base_velocity_world_xy"] = [0.0, 0.0]
        self.speed = 0.0
        self.action_index += 1
        if status != "completed":
            for row in self.steps[self.action_index:]:
                row.update(status="skipped_dependency", ran=False)
            self.action_index = len(self.plan)
        self.done = self.action_index == len(self.plan)
        self.action_started_s, self.phase, self.ready_since = None, 0, None
        self.route, self.waypoint = [], 0
        self.space_t = -math.inf

    def _wait(self, reason, out):
        out["base_velocity_world_xy"] = [0.0, 0.0]
        if reason != self.wait_reason:
            out["events"].append("bounded wait: "+reason)
            self.wait_reason = reason

    def _hand(self, out, o, target, orientation, dt, local=False, speed=0.14):
        # The original update() still supplies a centered target. Override ONLY
        # sensed move_forward with the physically measured verification posture.
        carry = (self.sensors and not self.done
                 and self.names[self.action_index] == 'move_forward')
        if carry:
            out['torso_ik_target_m'] = 0.30
            out['carry_ik_continuity'] = True
            head = getattr(self, '_carry_head', None)
            out['head_target_rad'] = list(head) if head is not None else [0.0, -0.26]
            if not getattr(self, '_carry_verified', False):
                self._wait('no measured, visibility-verified carry posture', out)
                return False
            target, orientation, local = self._carry_p, self._carry_q, True
            speed = min(speed, 0.045)

        # Original hand integrator, including unchanged pickup tolerances/caps.
        h, base, ry = o['hands']['0'], arr(o['robot_position_m']), float(o['robot_yaw_rad'])
        actual, aq = arr(h['position_m']), arr(h['orientation_xyzw'])
        aq /= np.linalg.norm(aq)
        if local:
            actual, aq = rot(actual-base, -ry), yawq(aq, -ry)
        if self.hp is None or self.mode != local:
            self.hp, self.hq, self.mode = actual.copy(), aq.copy(), local
        target = arr(target)
        tq = R.from_euler('z', orientation).as_quat() if np.isscalar(orientation) else arr(orientation)
        tq /= np.linalg.norm(tq)
        delta = target-self.hp
        if np.linalg.norm(self.hp-actual) < 0.05:
            self.hp += delta*min(1.0, speed*dt/max(np.linalg.norm(delta), 1e-9))
        if self.hq @ tq < 0:
            tq = -tq
        angle = qangle(self.hq, tq)
        if qangle(aq, self.hq) < 0.20 and np.linalg.norm(self.hp-actual) < 0.05:
            f = min(1.0, 0.55*dt/max(angle, 1e-9))
            if angle < 1e-6:
                self.hq = tq.copy()
            else:
                self.hq = (math.sin((1-f)*angle/2)*self.hq+math.sin(f*angle/2)*tq)/math.sin(angle/2)
            self.hq /= np.linalg.norm(self.hq)
        wp, wq = (rot(self.hp, ry)+base, yawq(self.hq, ry)) if local else (self.hp, self.hq)
        out['hand_targets_world'] = {'0': {'position_m': wp.tolist(), 'orientation_xyzw': wq.tolist()}}
        pickup = self.names[self.action_index] == 'grab_supplies' if not self.done else False
        ready = bool(np.linalg.norm(actual-target) < (0.040 if pickup else 0.035)
                     and qangle(aq, tq) < (0.14 if pickup else 0.10)
                     and h.get('ik_reachable', False) and h.get('tracking_error_m', math.inf) < 0.045)
        if carry:
            ready &= (np.linalg.norm(actual-target) < 0.015 and qangle(aq, tq) < 0.055
                      and abs(o['torso_lift_m']-0.30) < 0.012)
            if not ready:
                self._carry_map_pending = True
                self.route, self.waypoint, self.space_t = [], 0, -math.inf
        return bool(ready)

    def _ingest(self, t, o):
        scan = o.get("scans", {}).get("wide" if self.sensors else "primary", {})
        stamp = float(scan.get("t", -math.inf))
        if stamp <= self.last_scan:
            return
        self.last_scan = stamp
        grouped, extra = {}, []
        for hit in scan.get("hits", []):
            p, name = hit.get("position_m"), hit.get("body")
            if p is None:
                continue
            if person(hit):
                grouped.setdefault(name, []).append(p)
            elif not own_return(name) and name != "floor" and 0.065 < p[2] < 1.92:
                extra.append(p)
        for name, points in grouped.items():
            # Voxel deduplication reduces map construction cost without moving returns.
            unique = {}
            for p in points:
                unique[tuple(np.floor(np.array(p)/0.045).astype(int))] = p
            self.people_by_body[name] = (list(unique.values()), stamp)
        self.extra_hits = extra
        if grouped:
            self.last_person_scan = stamp
            self.person_scan_times.add(round(stamp, 5))
        self.people = [p for points, _ in self.people_by_body.values() for p in points]

    def _space(self, t, o, force=False):
        if force or self.space is None or t-self.space_t >= 0.30:
            people = [(points, max(0.0, t-stamp)) for points, stamp in self.people_by_body.values()]
            self.space = CollisionSpace(o, people, self.extra_hits)
            self.space_t = t
        return self.space

    def _drive(self, out, o, goal, speed, dt, heading=None):
        d = np.asarray(goal)-np.asarray(o["robot_position_m"][:2])
        distance, yaw = float(np.linalg.norm(d)), float(o["robot_yaw_rad"])
        desired = math.atan2(d[1], d[0]) if distance > 0.028 else (yaw if heading is None else heading)
        error = wrap(desired-yaw)
        out["final_heading_rad"] = float(desired)
        v = min(speed, max(0.012, 1.4*(distance-0.012))) if distance > 0.028 and abs(error) < 0.10 else 0.0
        self.speed = min(v, self.speed+0.70*dt)
        # The native runner must receive the intended direction, not current yaw.
        out["base_velocity_world_xy"] = [self.speed*math.cos(desired), self.speed*math.sin(desired)]
        return distance <= 0.028 and abs(error) < 0.035 and np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.035

    def _navigate(self, t, o, out, dt, goal, speed):
        carry = (self.sensors and not self.done
                 and self.names[self.action_index] == 'move_forward')
        if carry and getattr(self, '_carry_map_pending', False):
            # Never reuse the centered-load route after the arm changes shape.
            self.route, self.waypoint, self.space_t = [], 0, -math.inf
            self.last_plan_t = -math.inf
            self._carry_map_pending = False
        space = self._space(t, o)
        xy, yaw = arr(o['robot_position_m'][:2]), float(o['robot_yaw_rad'])
        tilt = -0.26 if carry else 0.02
        scan = o['scans'].get('wide', {})
        stamp = float(scan.get('t', -math.inf))
        if carry and 0.0 <= t-stamp <= 0.30:
            points = [hit['position_m'] for hit in scan.get('hits', [])
                      if str(hit.get('body', '')).startswith('h_')]
            if points:
                # Aiming memory only; obstacle construction remains _ingest/_space.
                self._carry_person_ray_xy = np.median(np.asarray(points), axis=0)[:2]
                self._carry_person_ray_t = stamp

        if self.sensors and (t-self.last_scan > 0.30 or t-self.last_person_scan > 1.25) and xy[0] < 1.1:
            pan = 0.75*math.sin(1.8*t)
            if carry and hasattr(self, '_carry_person_ray_xy'):
                d = self._carry_person_ray_xy-xy
                pan = float(np.clip(wrap(math.atan2(d[1], d[0])-yaw), -1.1, 1.1))
            out['head_target_rad'] = [pan, tilt]
            self._wait('refresh real head observations before passing', out)
            return False

        if carry and (not 0.0 <= t-stamp <= 0.30 or not self._visibility(scan, yaw)):
            out['head_target_rad'] = list(self._carry_head)
            self._wait('restore actual forward visibility while holding measured side carry', out)
            return False

        if not self.route or self.waypoint >= len(self.route):
            if t-self.last_plan_t < 0.45:
                return False
            self.last_plan_t = t
            self.route = space.plan(xy, yaw, goal, 0.0) or []
            self.waypoint = 0
            if not self.route:
                self._wait('no collision-free loaded route in current native/sensed map', out)
                return False
            out['events'].append('loaded SE(2) route planned from native static triangles and first returns')
        point = self.route[self.waypoint]
        delta = np.array(point[:2])-xy
        distance = np.linalg.norm(delta)
        travel_yaw = math.atan2(delta[1], delta[0]) if distance > 0.028 else point[2]
        horizon = min(distance, max(0.18, self.speed*0.30+self.speed*self.speed/(2*0.70)+0.08))
        end = xy + delta*(horizon/max(distance, 1e-9))
        clear_turn = space.segment_clear(xy, yaw, xy, travel_yaw)
        clear_move = space.segment_clear(xy, travel_yaw, end, travel_yaw)
        if not clear_turn or not clear_move:
            self.route, self.waypoint = [], 0
            self._wait('measured obstacle intersects loaded turn/braking envelope; replan', out)
            return False
        if self.sensors:
            pan = float(np.clip(wrap(travel_yaw-yaw), -1.1, 1.1))
            if carry:
                pan = float(np.clip(pan+self._carry_head[0], -1.1, 1.1))
                if xy[0] < 1.1 and t-getattr(self, '_carry_person_ray_t', -math.inf) < 1.25:
                    d = self._carry_person_ray_xy-xy
                    pan = float(np.clip(wrap(math.atan2(d[1], d[0])-yaw), -1.1, 1.1))
            out['head_target_rad'] = [pan, tilt]
        if self._drive(out, o, point[:2], speed, dt, point[2]):
            self.waypoint += 1
            if self.waypoint == len(self.route):
                self.route, self.waypoint = [], 0
                self.wait_reason = None
                return True
        return False

    def _capture_grasp(self, o):
        if self.grasp_p is not None or not o.get("payload_grasped", False):
            return
        hp, hq = arr(o["hands"]["0"]["position_m"]), arr(o["hands"]["0"]["orientation_xyzw"])
        inverse = R.from_quat(hq).inv()
        self.grasp_p = inverse.apply(arr(o["payload_position_m"])-hp)
        self.grasp_q = (inverse*R.from_quat(o["payload_orientation_xyzw"])).as_quat()

    def _grab(self, t, o, out, dt):
        handle = np.array([-3.02, 0.85, 1.43])
        base = np.asarray(o["robot_position_m"], dtype=float)
        yaw = float(o["robot_yaw_rad"])
        h = o["hands"]["0"]
        out["base_velocity_world_xy"] = [0.0, 0.0]
        out["gripper_open"]["0"] = self.phase < 3
        out["final_heading_rad"] = 0.98 if self.phase <= 6 else 0.0
        self.speed = 0.0

        if np.linalg.norm(base[:2] - np.array([-3.4, 0.15])) > 0.07:
            return self._finish(t, "failed_pickup_base_drift", out)
        if self.phase >= 4 and not o.get("payload_grasped", False):
            return self._finish(t, "failed_pickup_grasp_lost", out)

        if getattr(self, "_pk_phase", None) != self.phase:
            self._pk_phase = self.phase
            self._pk_v = self._pk_w = 0.0
            if self.phase == 3:
                self._pk_contact_since = None
                self._pk_attach_sent = False
            elif self.phase == 4:
                hr = R.from_quat(h["orientation_xyzw"])
                self._pk_relative_p = hr.inv().apply(
                    np.asarray(o["payload_position_m"], dtype=float)
                    - np.asarray(h["position_m"], dtype=float))
                self._pk_relative_q = (hr.inv() * R.from_quat(o["payload_orientation_xyzw"])).as_quat()
                # These are prediction-only measurements. Leave the existing grasp bookkeeping intact.
            elif self.phase == 5:
                self._pk_withdraw_world = base + R.from_euler("z", 0.98).apply([0.60, 0.0, 0.0])
                self._pk_withdraw_world[2] = 1.57
                out["events"].append("pickup: translate at world yaw zero before wrist rotation")
            elif self.phase == 7:
                self._pk_turn_reference = 0.98
                self._pk_turn_rate = 0.0
            elif self.phase == 8:
                self.carry_z = 1.46

        if self.phase == 0:
            ready = self._hand(out, o, [0.40, 0.0, 1.407], 0.0, dt, True)
            ready &= abs(math.atan2(math.sin(yaw - 0.98), math.cos(yaw - 0.98))) < 0.04
        elif self.phase in (1, 2, 3):
            target = handle + (np.array([-0.10, 0.0, 0.0]) if self.phase == 1 else 0.0)
            ready = self._hand(out, o, target, 0.0, dt)
            if self.phase == 3:
                contact_ok = bool(ready and t - self.phase_t > 0.25
                                  and o.get("opposing_finger_contact", False)
                                  and np.linalg.norm(np.asarray(h["position_m"]) - handle) < 0.025
                                  and R.from_quat(h["orientation_xyzw"]).magnitude() < 0.08)
                if contact_ok:
                    if self._pk_contact_since is None:
                        self._pk_contact_since = t
                    if t - self._pk_contact_since >= 0.10 and not o.get("payload_grasped", False):
                        out["payload_grasp_request"] = "attach"
                        self._pk_attach_sent = True
                else:
                    self._pk_contact_since = None
                ready = bool(o.get("payload_grasped", False) and self._pk_attach_sent)
        else:
            bottom, gap, tilt = self._pickup_box_bounds(o)
            linear_speed = float(np.linalg.norm(o["payload_velocity_m_s"]))
            angular_speed = float(np.linalg.norm(o["payload_angular_velocity_rad_s"]))
            clear = bottom > 0.825 or gap > 0.015
            quiet_motion = tilt < 0.080 and linear_speed < 0.18 and angular_speed < 0.30

            if self.phase == 4:
                # Reachable observed lift, not the unreachable extended +.18 m target.
                ready = self._pickup_servo(out, o, handle + [0.0, 0.0, 0.14], 0.0, dt,
                                          speed=0.085, permit=quiet_motion)
                ready &= bottom > 0.84
            elif self.phase == 5:
                # Fixed world orientation AND fixed world height throughout the translation.
                ready = self._pickup_servo(out, o, self._pk_withdraw_world, 0.0, dt,
                                          permit=clear and quiet_motion)
                ready &= bottom > 0.84
            elif self.phase == 6:
                # Only now rotate the wrist, at the settled, shortened reach. No translation.
                ready = self._pickup_servo(out, o, self._pk_withdraw_world, 0.98, dt,
                                          permit=clear and quiet_motion)
                ready &= bottom > 0.84
            elif self.phase == 7:
                # Keep the load fixed in the base frame while the native wheels turn slowly.
                turn_safe = bool(clear and tilt < 0.080
                                 and linear_speed < 0.25 and angular_speed < 0.40)
                hand_ready = self._pickup_servo(out, o, [0.60, 0.0, 1.55], 0.0, dt,
                                               local=True, permit=turn_safe)
                heading_lag = abs(math.atan2(math.sin(self._pk_turn_reference - yaw),
                                             math.cos(self._pk_turn_reference - yaw)))
                if hand_ready and turn_safe and heading_lag < 0.040:
                    distance = abs(self._pk_turn_reference)
                    self._pk_turn_rate = min(0.26, self._pk_turn_rate + 0.45 * dt,
                                             math.sqrt(2.0 * 0.45 * distance))
                    step = self._pk_turn_rate * dt
                    self._pk_turn_reference += float(np.clip(-self._pk_turn_reference, -step, step))
                else:
                    self._pk_turn_rate = 0.0
                out["final_heading_rad"] = float(self._pk_turn_reference)
                ready = bool(hand_ready and abs(self._pk_turn_reference) < 1e-5
                             and abs(math.atan2(math.sin(yaw), math.cos(yaw))) < 0.012
                             and gap > 0.015)
            elif self.phase == 8:
                # Descend only after the measured carton envelope is beyond the tabletop edge.
                ready = self._pickup_servo(out, o, [0.60, 0.0, 1.46], 0.0, dt, local=True,
                                          speed=0.060, permit=gap > 0.015 and quiet_motion)
                ready &= gap > 0.015 and abs(math.atan2(math.sin(yaw), math.cos(yaw))) < 0.012
            else:
                return self._finish(t, "failed_pickup_internal_phase", out)

            # Every loaded endpoint must actually settle, not merely reach a command waypoint.
            ready &= bool(o.get("payload_grasped", False) and linear_speed < 0.080
                          and angular_speed < 0.160 and tilt < 0.070)

        ready &= np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.04
        dwell = 0.30 if self.phase >= 4 else 0.10
        if self._ok(bool(ready), t, dwell=dwell):
            if self.phase == 8:
                self._finish(t, "completed", out)
            else:
                self._advance(t, out)

    def _visibility(self, scan, yaw):
        if not scan or "directions_world" not in scan:
            return False
        d = np.array(scan["directions_world"])
        origin = np.array(scan["origin_m"])
        az = np.arctan2(d[:, 1], d[:, 0])
        horizontal = np.maximum(np.linalg.norm(d[:, :2], axis=1), 1e-6)
        z_at_look = origin[2] + 1.6*d[:, 2]/horizontal
        eligible = (np.abs(np.arctan2(np.sin(az-yaw), np.cos(az-yaw))) < 0.48) & (z_at_look > 1.0) & (z_at_look < 1.8)
        ids = np.flatnonzero(eligible)
        if len(ids) < 24:
            return False
        blocked = sum(own_return(scan["first_hit_body"][i]) for i in ids)
        return blocked/len(ids) <= 0.15

    def _verify(self, t, o, out, dt):
        if not hasattr(self, '_carry_stage'):
            # Native-geometry replay found the positive lateral branch keeps the
            # arm clear of every scanned head pose; the negative branch did not.
            self._carry_stage, self._carry_side = 0, 0.28
            self._carry_p, self._carry_q = None, None
            self._carry_verified = False
            self._carry_head, self._carry_score, self._carry_settled = None, None, None
            self.scan_index, self.scan_started = 0, None
            self.views = {}
            # Same full pan coverage, using the actual head motor to cancel its
            # approximately 0.26-rad downward link orientation.
            self.scan_poses = [(-0.85, -0.26), (-0.40, -0.26), (0.0, -0.26),
                               (0.40, -0.26), (0.85, -0.26)]
            self.route, self.waypoint, self.space_t = [], 0, -math.inf

        out['torso_ik_target_m'] = 0.30
        out['carry_ik_continuity'] = True
        out['scan_request'] = 'wide'
        out['head_target_rad'] = [0.0, 0.0]
        target = (np.array([0.60, 0.0 if self._carry_stage == 0 else self._carry_side, 1.34])
                  if self._carry_p is None else self._carry_p)
        orientation = 0.0 if self._carry_q is None else self._carry_q
        self.carry_z = float(target[2])
        ready = self._hand(out, o, target, orientation, dt, True,
                       speed=0.045)
        h = o['hands']['0']
        ry = float(o['robot_yaw_rad'])
        measured = rot(arr(h['position_m'])-arr(o['robot_position_m']), -ry)
        ready &= (np.linalg.norm(measured-target) < 0.010
                  and h.get('tracking_error_m', math.inf) < 0.012
                  and abs(o['torso_lift_m']-0.30) < 0.012
                  and np.linalg.norm(o['robot_velocity_m_s'][:2]) < 0.025
                  and np.linalg.norm(o['payload_velocity_m_s']) < 0.065
                  and np.linalg.norm(o['payload_angular_velocity_rad_s']) < 0.15)

        if self._carry_stage < 2:
            # Lower on the known reachable centerline FIRST, then translate
            # laterally at constant height. The base remains stopped throughout.
            if self._ok(bool(ready), t, 0.25):
                self._carry_stage += 1
                self.ready_since = None
                self.route, self.waypoint, self.space_t = [], 0, -math.inf
                if self._carry_stage == 2:
                    self._carry_p = measured.copy()
                    self._carry_q = yawq(arr(h['orientation_xyzw']), -ry)
                    self._carry_q /= np.linalg.norm(self._carry_q)
                    self._carry_epoch = t
                    self.carry_z = float(self._carry_p[2])
                    self.views = {}
                    self.scan_index, self.scan_started = 0, None
                    self._carry_head, self._carry_score, self._carry_settled = None, None, None
                    out['events'].append('side carry measured; discard pre-adjustment visibility and loaded route')
            return

        pan, tilt = self.scan_poses[self.scan_index] if self._carry_stage == 2 else self._carry_head
        out['head_target_rad'] = [float(pan), float(tilt)]
        if not ready or np.linalg.norm(arr(o['head_joints_rad'])-[pan, tilt]) >= 0.035:
            self._carry_settled = None
            return
        if self._carry_settled is None:
            self._carry_settled = t
        scan = o['scans'].get('wide', {})
        stamp = float(scan.get('t', -math.inf))
        if (t-self._carry_settled < 0.20 or stamp < self._carry_settled+0.10
                or not 0.0 <= t-stamp <= 0.30):
            return

        visible = self._visibility(scan, o['robot_yaw_rad'])
        if visible:
            self.views[round(stamp, 5)] = True
            human_in_view = any(str(hit.get('body', '')).startswith('h_') for hit in scan.get('hits', []))
            score = (0 if human_in_view else 1, abs(float(pan)))
            if self._carry_score is None or score < self._carry_score:
                self._carry_score, self._carry_head = score, [float(pan), float(tilt)]
        self._carry_settled = None

        if self._carry_stage == 2:
            self.scan_index += 1
            if self.scan_index == len(self.scan_poses):
                self.scan_index = 0
                if self._carry_head is not None:
                    # Return physically to a successful view and obtain a NEW
                    # settled scan before allowing the next action to drive.
                    self._carry_stage = 3
                elif self._carry_side < 0.299:
                    self._carry_side, self._carry_stage = 0.30, 1
                    self._carry_p, self._carry_q = None, None
                    self.views = {}
                    self.ready_since = None
                    self.route, self.waypoint, self.space_t = [], 0, -math.inf
                    out['events'].append('no passing native view: extend lateral carry by 0.02 m and remeasure')
                else:
                    self._wait('actual arm/payload obstruction still fails unchanged visibility test', out)
            return

        recent_people = [s for s in self.person_scan_times if s >= self._carry_epoch]
        if visible and self.views and len(recent_people) >= 2 and t-self.last_person_scan < 1.5:
            space = self._space(t, o, True)
            route = space.plan(o['robot_position_m'][:2], o['robot_yaw_rad'], [1.90, 0.0])
            if route:
                self._carry_verified = True
                self._carry_map_pending = True
                self.route, self.waypoint, self.space_t = [], 0, -math.inf
                self.last_plan_t, self.wait_reason = -math.inf, None
                out['events'].append('verify_path: measured side carry, unchanged visibility test, true human returns, asymmetric loaded route')
                self._finish(t, 'completed', out)
                return
            self._wait('person observed; no native/sensed collision-free loaded route', out)
        else:
            self._wait('require a fresh clear native view and repeated real human returns', out)
        self._carry_stage, self.scan_index = 2, 0
        self.views = {}
        self._carry_head, self._carry_score = None, None

    def _payload_hand_goal(self, center):
        hq = R.from_quat(self.grasp_q).inv().as_quat()
        hp = np.array(center)-R.from_quat(hq).apply(self.grasp_p)
        return hp, hq

    def _place(self, t, o, out, dt):
        out["torso_ik_target_m"] = 0.30
        out["carry_ik_continuity"] = True
        target_center = np.array(SPEC["parcel_goal_position_m"])
        if self.phase in (0, 1):
            # Original-geometry ray/IK replay found a clear raised side posture.
            # The actual native scan, joint feedback and unchanged visibility gate
            # must confirm it before this sensed plan approaches the table.
            target = [0.60, 0.28 if self.sensors else 0.0, 1.55]
            if self.sensors:
                self._place_head = [-0.85, 0.02]
                out['head_target_rad'] = list(self._place_head)
                out['scan_request'] = 'wide'
            ready = self._hand(out, o, target, 0.0, dt, True, speed=0.10)
            ready &= abs(o["torso_lift_m"]-0.30) < 0.012
            if self.sensors and self.phase == 0:
                scan = o.get('scans', {}).get('wide', {})
                stamp = float(scan.get('t', -math.inf))
                ready &= (np.linalg.norm(np.asarray(o['head_joints_rad'])-self._place_head) < .035
                          and 0 <= t-stamp <= .30 and self._visibility(scan, o['robot_yaw_rad']))
            if self.phase == 1 and ready:
                ready = self._navigate(t, o, out, dt, [2.62, 0.0], 0.16)
            if self._ok(ready, t, .25 if self.sensors and self.phase == 0 else .10):
                self.route, self.waypoint = [], 0
                self.space_t = -math.inf
                self._advance(t, out)
            return
        if self.phase == 2:
            center = target_center+[0, 0, 0.085]
            hp, hq = self._payload_hand_goal(center)
            ready = self._hand(out, o, hp, hq, dt, speed=0.08)
            if self._ok(ready, t):
                self._advance(t, out)
            return
        if self.phase == 3:
            # Two millimetres of commanded seating, not a pose write or support.
            hp, hq = self._payload_hand_goal(target_center+[0, 0, -0.002])
            self._hand(out, o, hp, hq, dt, speed=0.018)
            pp = np.array(o["payload_position_m"])
            bottom = pp[2]-np.abs(R.from_quat(o["payload_orientation_xyzw"]).as_matrix()[2]) @ (np.array(SPEC["parcel_dimensions_m"])/2)
            ready = (o["receiver_contact_current"] and np.linalg.norm(pp[:2]-target_center[:2]) < 0.10
                     and abs(bottom-0.80) < 0.020 and np.linalg.norm(o["payload_velocity_m_s"]) < 0.065
                     and np.linalg.norm(o["payload_angular_velocity_rad_s"]) < 0.15)
            if self._ok(ready, t, 0.18):
                self._advance(t, out)
            return
        hp, hq = self._payload_hand_goal(target_center+[0, 0, -0.002])
        if self.phase == 4:
            out["payload_grasp_request"] = "release"
            out["gripper_open"]["0"] = True
            self.release_commanded = True
            self._hand(out, o, hp, hq, dt, speed=0.03)
            if self._ok(not o["payload_grasped"] and o["payload_released"], t, 0.30):
                self._advance(t, out)
            return
        out["gripper_open"]["0"] = True
        # Opening precedes withdrawal; retreat along the horizontal palm axis.
        hp = hp+R.from_quat(hq).apply([-0.16, 0, 0.06])
        ready = self._hand(out, o, hp, hq, dt, speed=0.055)
        valid = bool(ready and o["goal_reached"] and o["payload_released"] and not o["payload_grasped"])
        if not valid:
            self.final_goal_since = None
        elif self.final_goal_since is None:
            self.final_goal_since = t
        elif t-self.final_goal_since >= SPEC["final_observation_s"]:
            self._finish(t, "completed", out)

    def update(self, t, obs) -> dict:
        t = float(t)
        dt = 1/60 if self.last_t is None else min(1/30, max(1/240, t-self.last_t))
        self.last_t = t
        action = self.names[self.action_index] if not self.done else ""
        if not self.done and self.action_started_s is None:
            self.action_started_s, self.phase_t = t, t
            self.steps[self.action_index].update(start=t, status="running", ran=True)
        if action == "verify_path":
            self.sensors = True
        out = dict(base_velocity_world_xy=[0.0, 0.0],
                   gripper_open={"0": self.release_commanded or not bool(obs.get("payload_grasped", False))},
                   head_target_rad=[0.0, 0.02 if self.sensors else 0.42],
                   scan_request=None if self.done else ("wide" if self.sensors else "primary"),
                   payload_grasp_request=None, human_stand_attempt=False, sensors_enabled=self.sensors, events=[])
        if self.done:
            return out
        required = ("static_world", "native_link_boxes_base_m", "payload_orientation_xyzw",
                    "payload_angular_velocity_rad_s", "head_joints_rad", "opposing_finger_contact",
                    "receiver_contact_current", "measured_safety")
        missing = [k for k in required if k not in obs]
        if missing:
            raise RuntimeError("Native runner integration missing: "+", ".join(missing))
        self._ingest(t, obs)
        self._capture_grasp(obs)
        h = obs.get("hands", {}).get("0")
        failure = None
        if t >= SPEC["episode_seconds"] or t-self.action_started_s >= SPEC["action_deadlines_s"][action]:
            failure = "deadline_"+(self.wait_reason or "motor_or_contact_stage")
        elif h is None:
            failure = "missing_native_hand_feedback"
        else:
            bad = not h.get("ik_reachable", False) or h.get("tracking_error_m", math.inf) > 0.10
            self.bad_since = (t if self.bad_since is None else self.bad_since) if bad else None
            if self.bad_since is not None and t-self.bad_since > 3.0:
                failure = "ik_or_motor_tracking"
            needs_grip = (action != "grab_supplies" or self.phase >= 4) and not (action == "place_supplies" and self.phase >= 4)
            if needs_grip and not obs.get("payload_grasped", False):
                failure = "grasp_not_present"
            if obs.get("payload_grasped", False) and self.grasp_p is not None:
                expected = np.array(h["position_m"])+R.from_quat(h["orientation_xyzw"]).apply(self.grasp_p)
                eq = (R.from_quat(h["orientation_xyzw"])*R.from_quat(self.grasp_q)).as_quat()
                if np.linalg.norm(expected-obs["payload_position_m"]) > 0.045 or qangle(eq, obs["payload_orientation_xyzw"]) > 0.10:
                    failure = "measured_grasp_transform_mismatch"
            if any(obs["measured_safety"].values()):
                failure = "measured_human_contact_or_fall"
        if failure:
            self._finish(t, "failed_"+failure, out)
            return out
        if action == "grab_supplies":
            self._grab(t, obs, out, dt)
        elif action == "verify_path":
            self._verify(t, obs, out, dt)
        elif action == "place_supplies":
            self._place(t, obs, out, dt)
        else:
            if self.sensors:
                out["torso_ik_target_m"] = 0.30
            ready = self._hand(out, obs, [0.60, 0.0, self.carry_z], 0.0, dt, True)
            if ready:
                goal = [-1.80, 0.15] if action == "navigate_to_corridor" else [1.90, 0.0]
                speed = 0.40 if action == "navigate_to_corridor" else (0.24 if self.sensors else 0.50)
                if self._navigate(t, obs, out, dt, goal, speed):
                    self._finish(t, "completed", out)
        if out["base_velocity_world_xy"] == [0.0, 0.0]:
            self.speed = 0.0
        return out


    def _pickup_box_bounds(self, o, hand_p=None, hand_q=None):
        """Measured, or commanded-pose predicted, carton envelope. No state writes."""
        if hand_p is None:
            p = np.asarray(o["payload_position_m"], dtype=float)
            r = R.from_quat(o["payload_orientation_xyzw"])
        else:
            hr = R.from_quat(hand_q)
            p = np.asarray(hand_p, dtype=float) + hr.apply(self._pk_relative_p)
            r = hr * R.from_quat(self._pk_relative_q)
        m = r.as_matrix()
        extent = np.abs(m) @ np.array([0.23, 0.24, 0.30])
        lo, hi = p - extent, p + extent
        # Actual source tabletop: center [-2.87, .85, .72], size [.95, .85, .06].
        gap = max(-3.345 - hi[0], lo[0] + 2.395,
                  0.425 - hi[1], lo[1] - 1.275)
        tilt = math.acos(float(np.clip(m[2, 2], -1.0, 1.0)))
        return float(lo[2]), float(gap), tilt

    def _pickup_servo(self, out, o, target, orientation, dt, local=False,
                      speed=0.075, permit=True):
        """Loaded Cartesian reference governor; the existing native IK/drives execute it."""
        dt = min(1.0 / 30.0, max(0.0, float(dt)))
        h = o["hands"]["0"]
        base = np.asarray(o["robot_position_m"], dtype=float)
        br = R.from_euler("z", float(o["robot_yaw_rad"]))
        actual = np.asarray(h["position_m"], dtype=float)
        ar = R.from_quat(h["orientation_xyzw"])
        if local:
            actual, ar = br.inv().apply(actual - base), br.inv() * ar

        if self.hp is None:
            self.hp, self.hq, self.mode = actual.copy(), ar.as_quat(), local
        elif self.mode != local:
            # Re-express the EXISTING command; do not reset a lagging command to feedback.
            wp = np.asarray(self.hp, dtype=float).copy()
            wr = R.from_quat(self.hq)
            if self.mode:
                wp, wr = base + br.apply(wp), br * wr
            if local:
                wp, wr = br.inv().apply(wp - base), br.inv() * wr
            self.hp, self.hq, self.mode = wp, wr.as_quat(), local

        target = np.asarray(target, dtype=float)
        tr = R.from_euler("z", float(orientation)) if np.isscalar(orientation) else R.from_quat(orientation)
        cr = R.from_quat(self.hq)
        lag = float(np.linalg.norm(self.hp - actual))
        angular_lag = float((ar.inv() * cr).magnitude())
        tracking = float(h.get("tracking_error_m", math.inf))
        reachable = bool(h.get("ik_reachable", False))
        gate = bool(permit and reachable and tracking < 0.035
                    and lag < 0.024 and angular_lag < 0.060)
        proposed_p, proposed_r = self.hp.copy(), cr
        if gate:
            delta = target - self.hp
            distance = float(np.linalg.norm(delta))
            rv = (cr.inv() * tr).as_rotvec()
            angle = float(np.linalg.norm(rv))
            self._pk_v = min(speed, self._pk_v + 0.18 * dt,
                             math.sqrt(2.0 * 0.18 * distance))
            self._pk_w = min(0.20, self._pk_w + 0.40 * dt,
                             math.sqrt(2.0 * 0.40 * angle))
            if distance > 1e-10:
                proposed_p += delta * min(1.0, self._pk_v * dt / distance)
            if angle > 1e-10:
                proposed_r = cr * R.from_rotvec(rv * min(1.0, self._pk_w * dt / angle))
        else:
            self._pk_v = self._pk_w = 0.0

        wp = base + br.apply(proposed_p) if local else proposed_p
        wr = br * proposed_r if local else proposed_r
        if self.phase >= 5:
            bottom, gap, _ = self._pickup_box_bounds(o, wp, wr.as_quat())
            # Withdrawal/yaw use vertical clearance; final descent requires horizontal clearance.
            envelope_ok = (gap > 0.015) if self.phase == 8 else (bottom > 0.84 or gap > 0.020)
            if not envelope_ok:
                proposed_p, proposed_r = self.hp.copy(), cr
                self._pk_v = self._pk_w = 0.0
                gate = False

        self.hp, self.hq, self.mode = proposed_p, proposed_r.as_quat(), local
        wp = base + br.apply(self.hp) if local else self.hp
        wr = br * proposed_r if local else proposed_r
        out["hand_targets_world"] = {
            "0": {"position_m": wp.tolist(), "orientation_xyzw": wr.as_quat().tolist()}
        }
        return bool(gate and np.linalg.norm(self.hp - target) < 1e-5
                    and (proposed_r.inv() * tr).magnitude() < 1e-5
                    and np.linalg.norm(actual - target) < 0.018
                    and (ar.inv() * tr).magnitude() < 0.035
                    and reachable and tracking < 0.030)


def configure_native_capture(ep):
    """Call after NativeVisuals construction, before any warmup/capture."""
    import carb
    profile = json.loads(Path(__file__).with_name("render_profile.json").read_text())
    settings = carb.settings.get_settings()
    before = {key: settings.get(key) for key in profile["settings"]}
    for key, value in profile["settings"].items():
        settings.set(key, value)
    actual = {key: settings.get(key) for key in profile["settings"]}
    for key, value in profile["settings"].items():
        if actual[key] != value:
            raise RuntimeError("Render setting readback mismatch: "+key)
    ep.capture_profile = dict(profile, applied_settings=actual, previous_values=before,
                              runtime_validated=False, physics_advances_during_render_updates=False)
    ep.capture_count = 0
    ep.capture_warmed = False
    ep.visuals.manifest.update(renderer=profile["renderer"],
        samples_per_render_update=profile["settings"]["/rtx/pathtracing/spp"],
        accumulation_sample_cap=profile["settings"]["/rtx/pathtracing/totalSpp"],
        render_updates_per_recorded_frame=profile["render_updates_per_recorded_frame"],
        renderer_reason=profile["reasoning"], capture_profile=ep.capture_profile)
    (ep.output/"render-profile-applied.json").write_text(json.dumps(ep.capture_profile, indent=2))


def render_native_frame(ep, final=False):
    """One real simulation sample per encoded frame; all convergence is held."""
    if ep.physics_only:
        return
    import imageio.v2 as imageio
    import carb
    profile = ep.capture_profile
    settings = carb.settings.get_settings()
    for key, value in profile["settings"].items():
        if settings.get(key) != value:
            raise RuntimeError("Capture profile overwritten during episode: "+key)
    before_tick, before_t = ep.og.sim.current_time_step_index, ep.t
    with ep.og.sim.editing_usd():
        ep.visuals.update()
    if not ep.capture_warmed:
        for _ in range(profile["warmup_updates"]):
            ep.og.sim.render()
        ep.capture_warmed = True
    for _ in range(profile["render_updates_per_recorded_frame"]):
        ep.og.sim.render()
    assert ep.og.sim.current_time_step_index == before_tick and ep.t == before_t, "Rendering advanced physics"
    observation = ep.og.sim.viewer_camera.get_obs()
    if isinstance(observation, tuple):
        observation = observation[0]
    rgb = arr(observation["rgb"])[..., :3]
    if rgb.max() <= 1.0:
        rgb *= 255
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    if rgb.shape != (profile["height"], profile["width"], 3):
        raise RuntimeError("Wrong native render-product resolution: "+str(rgb.shape))
    ep.output.joinpath("checks").mkdir(exist_ok=True)
    if not final:
        if ep.capture_count and abs(ep.t-ep.last_capture_t-1/profile["fps"]) > 1e-6:
            raise RuntimeError("Capture cadence is not 30 Hz physical time")
        ep.writer.append_data(rgb)
        with (ep.output/"capture-times.jsonl").open("a") as stream:
            stream.write(json.dumps(dict(frame=ep.capture_count, t=float(ep.t), physics_tick=int(before_tick)))+"\n")
        ep.last_capture_t = ep.t
        ep.capture_count += 1
    if ep.last_image is None:
        imageio.imwrite(ep.output/"poster.jpg", rgb)
    ep.last_image = rgb
    for label in ep.pending_checks:
        imageio.imwrite(ep.output/"checks"/f"{round(ep.t*1000):06d}_{label}.jpg", rgb)
    ep.pending_checks.clear()
    if final:
        imageio.imwrite(ep.output/"final.jpg", rgb)


# GPT navigation-feedback-v4, installed over the tested pickup/verification policy.
NAVIGATION_PATCH_INFO = {
    'task_id': 'neiss_10579',
    'entrypoint': 'install(existing_native_policy_module)',
    'replaces': ['Controller._hand', 'Controller._navigate', 'Controller.update'],
    'spec_overrides': {},
    'preserves': ['pickup', 'verification', 'placement', 'native_scan',
                  'native_IK', 'CollisionSpace', 'action_deadlines', 'goal'],
    'verification_status': 'trace-audited; replacement not simulated here'
}

def _wrap(a):
    return (float(a) + math.pi) % (2 * math.pi) - math.pi

def _finite_age(t, stamp):
    age = float(t - stamp)
    return age if math.isfinite(age) else None

def _loaded_boxes(o):
    """Actual native-link bounds and actual measured carton, in base coordinates."""
    boxes = np.asarray(o['native_link_boxes_base_m'], float).copy()
    if o.get('payload_grasped', False):
        half = np.asarray(SPEC['parcel_dimensions_m']) / 2
        vertices = np.array([[x, y, z] for x in (-half[0], half[0])
                             for y in (-half[1], half[1])
                             for z in (-half[2], half[2])])
        vertices = R.from_quat(o['payload_orientation_xyzw']).apply(vertices)
        vertices += np.asarray(o['payload_position_m']) - np.asarray(o['robot_position_m'])
        vertices = R.from_euler('z', -o['robot_yaw_rad']).apply(vertices)
        boxes = np.concatenate((boxes, [[vertices.min(0), vertices.max(0)]]))
    return boxes

def _sweep(xy, yaw, heading, end):
    """Sample the explicitly checked turn-then-translation primitive."""
    turn = _wrap(heading - yaw)
    n = max(2, int(math.ceil(abs(turn) / .035)))
    poses = [(xy, yaw + f * turn) for f in np.linspace(0, 1, n + 1)]
    n = max(2, int(math.ceil(np.linalg.norm(end - xy) / .025)))
    poses.extend((xy + f * (end - xy), heading) for f in np.linspace(0, 1, n + 1))
    return poses

def _continuous_route(space, raw, xy, yaw, goal):
    """Reanchor lattice primitives; never drive toward the root cell centre.

    Correct the terminal cell to the exact requested goal. Every changed
    translation and every turn is checked again in the actual loaded map.
    Returned route entries remain ordinary [x, y, yaw] Controller waypoints.
    """
    root = np.asarray(raw[0][:2])
    terminal = np.asarray(raw[-2][:2]) if len(raw) > 1 else root
    displacement = xy - root
    for offset in (displacement, .5 * displacement, np.zeros(2)):
        route, kinds = [], []
        valid = True

        def emit(p, a, kind, mandatory=False):
            nonlocal valid
            previous = route[-1] if route else [*xy, yaw]
            p = np.asarray(p)
            if not mandatory and np.linalg.norm(p - previous[:2]) < 1e-8 and abs(_wrap(a - previous[2])) < 1e-8:
                return
            if not space.segment_clear(previous[:2], previous[2], p, a):
                valid = False
                return
            value = [float(p[0]), float(p[1]), float(a)]
            if kind == 'turn' and kinds and kinds[-1] == 'turn':
                before = route[-2] if len(route) > 1 else [*xy, yaw]
                if np.linalg.norm(p - route[-1][:2]) < 1e-8 and space.segment_clear(before[:2], before[2], p, a):
                    route[-1] = value
                    return
            route.append(value)
            kinds.append(kind)

        current = xy.copy()
        for i, node in enumerate(raw):
            p = np.asarray(node[:2]) + offset
            if np.linalg.norm(np.asarray(node[:2]) - root) < 1e-8:
                p = xy.copy()
            if i == len(raw) - 1 or np.linalg.norm(np.asarray(node[:2]) - terminal) < 1e-8:
                p = np.asarray(goal, float)
            delta = p - current
            if np.linalg.norm(delta) > 1e-8:
                bearing = math.atan2(delta[1], delta[0])
                emit(current, bearing, 'turn')
                emit(p, bearing, 'move')
            emit(p, float(node[2]), 'turn')
            current = p
            if not valid:
                break
        if valid:
            emit(goal, 0.0, 'turn', mandatory=True)
            if valid:
                return route, kinds
    return [], []

def _human_freshness(controller, t, boxes, poses, yaw, heading, resolution):
    """Freshness from retained first-return envelopes, never human poses.

    Preserve the original obstacle inflation. Beyond 1.25 s add UNCAPPED
    uncertainty growth; stale observations grant motion only while that
    enlarged envelope misses the complete proposed stopping/motion sweep.
    This is a conservative planning forecast, not a claimed human speed bound.
    """
    age = t - controller.last_person_scan
    records = [(np.asarray(points, float), max(0., t - stamp))
               for points, stamp in controller.people_by_body.values() if len(points)]
    if not records:
        return {'decision': 'refresh_required', 'behind_gap_m': None}
    if 0 <= age <= 1.25:
        return {'decision': 'fresh', 'behind_gap_m': None}
    points = np.concatenate([p[:, :2] for p, _ in records])
    radii = np.concatenate([np.full(len(p), SPEC['sensed_person_surface_margin_m']
                         + min(.10, .035 * (a + .30)) + resolution / 2
                         + .10 * max(0., a - 1.25)) for p, a in records])
    # Include native map clearance, footprint cache padding and sweep sampling.
    margin = SPEC['static_clearance_m'] + resolution / math.sqrt(2) + .035
    low, high = boxes[:, 0, :2] - margin, boxes[:, 1, :2] + margin
    vertices = np.stack((low, high, np.c_[low[:, 0], high[:, 1]],
                         np.c_[high[:, 0], low[:, 1]]), axis=1).reshape(-1, 2)
    axis = np.array([math.cos(yaw), math.sin(yaw)])
    rear, intersects = math.inf, False
    for p, a in poses:
        c, s = math.cos(a), math.sin(a)
        rotation = np.array([[c, -s], [s, c]])
        rear = min(rear, float(np.min((vertices @ rotation.T + p) @ axis)))
        local = (points - p) @ rotation
        separation = np.maximum(np.maximum(low[None] - local[:, None],
                                            local[:, None] - high[None]), 0.)
        intersects |= bool(np.any(np.sum(separation * separation, axis=2) <= radii[:, None] ** 2))
    gap = rear - float(np.max(points @ axis + radii))
    behind = gap > .10 and math.cos(_wrap(heading - yaw)) > .25
    decision = 'behind_loaded_sweep' if behind else ('refresh_required' if intersects else 'aged_envelope_clear')
    return {'decision': decision, 'behind_gap_m': float(gap)}

class _NavigationMethods:
    """Only these methods are installed on the existing Controller."""

    def _nav_stop(self, o, out, reason):
        yaw = float(o['robot_yaw_rad'])
        out['final_heading_rad'] = yaw
        self._nav_ref, self._nav_w, self.speed = yaw, 0., 0.
        self._nav_decision = reason
        self._wait(reason, out)

    def _nav_space(self, t, o):
        boxes = _loaded_boxes(o)
        cached = getattr(self, '_nav_bounds', None)
        contained = (cached is not None and cached.shape == boxes.shape
                     and np.all(boxes[:, 0] >= cached[:, 0])
                     and np.all(boxes[:, 1] <= cached[:, 1]))
        if (self.space is None or not contained or t - self.space_t >= .30
                or getattr(self, '_nav_map_scan', None) != self.last_scan):
            expanded = boxes.copy()
            expanded[:, 0] -= .010
            expanded[:, 1] += .010
            measured = dict(o, native_link_boxes_base_m=expanded.tolist())
            people = [(p, max(0., t - stamp) + .30)
                      for p, stamp in self.people_by_body.values()]
            # CollisionSpace also adds the actual carton; neither it nor any
            # native link is removed. Padding covers cache-time motor jitter.
            self.space = SPACE(measured, people, self.extra_hits)
            self.space_t, self._nav_map_scan = t, self.last_scan
            self._nav_bounds = expanded
        return self.space, boxes

    def _nav_head(self, t, o, out, forward, require_visibility, refresh=False):
        scan = o.get('scans', {}).get('wide', {})
        stamp = float(scan.get('t', -math.inf))
        fresh = (0 <= t - stamp <= .30 and 'directions_world' in scan
                 and 'first_hit_body' in scan)
        visible = fresh and self._visibility(scan, float(o['robot_yaw_rad']))
        mode = getattr(self, '_nav_mode', 'restore')
        if refresh and mode == 'drive':
            points = [p for group, _ in self.people_by_body.values() for p in group]
            bearing = 0.
            if points:
                delta = np.median(np.asarray(points), axis=0)[:2] - np.asarray(o['robot_position_m'][:2])
                bearing = _wrap(math.atan2(delta[1], delta[0]) - o['robot_yaw_rad'])
            self._nav_pans = sorted((-1.40, -1.10, -.85, -.40, 0., .40, .85, 1.10, 1.40), key=lambda a: abs(_wrap(a - bearing)))
            self._nav_pan_index, self._nav_head_since = 0, None
            mode = 'observe'
        if mode == 'drive':
            out['head_target_rad'] = list(forward)
            if fresh and (visible or not require_visibility) and np.linalg.norm(np.asarray(o['head_joints_rad']) - forward) < .035:
                self._nav_mode = mode
                return True
            mode, self._nav_head_since = 'restore', None
        self._nav_mode = mode
        target = ([self._nav_pans[self._nav_pan_index], forward[1]]
                  if mode == 'observe' else list(forward))
        out['head_target_rad'] = list(target)
        self._nav_stop(o, out, 'stationary real-ray refresh' if mode == 'observe' else 'restore settled actual forward view')
        if np.linalg.norm(np.asarray(o['head_joints_rad']) - target) >= .035:
            self._nav_head_since = None
            return False
        if getattr(self, '_nav_head_since', None) is None:
            self._nav_head_since = t
        settled = self._nav_head_since
        if not fresh or t - settled < .18 or stamp < settled + .08:
            return False
        if mode == 'observe':
            if any(PERSON(hit) for hit in scan.get('hits', [])):
                self._nav_mode, self._nav_head_since = 'restore', None
                out['head_target_rad'] = list(forward)
            else:
                self._nav_pan_index = (self._nav_pan_index + 1) % len(self._nav_pans)
                self._nav_head_since = None
        elif visible or not require_visibility:
            self._nav_mode, self._nav_head_since = 'drive', None
        return False

    def _hand(self, out, o, target, orientation, dt, local=False, speed=.14):
        carry = (self.sensors and not self.done and self.names[self.action_index] == 'move_forward'
                 and getattr(self, '_carry_verified', False))
        if not carry:
            return OLD_HAND(self, out, o, target, orientation, dt, local, speed)
        saved = self.route, self.waypoint, self.space_t, getattr(self, '_carry_map_pending', False)
        original_ready = OLD_HAND(self, out, o, target, orientation, dt, local, speed)
        # Preserve the original Cartesian integrator and native IK. A readiness
        # fluctuation is NOT a new arm target and must not erase route progress.
        self.route, self.waypoint, self.space_t, self._carry_map_pending = saved
        h = o['hands']['0']
        inverse = R.from_euler('z', -o['robot_yaw_rad'])
        measured = inverse.apply(np.asarray(h['position_m']) - o['robot_position_m'])
        measured_q = inverse * R.from_quat(h['orientation_xyzw'])
        error = float(np.linalg.norm(measured - self._carry_p))
        angle = float((measured_q.inv() * R.from_quat(self._carry_q)).magnitude())
        latched = getattr(self, '_nav_hand_latched', bool(original_ready))
        ready = bool(error < (.030 if latched else .015) and angle < (.085 if latched else .055)
                     and h.get('ik_reachable', False) and h.get('tracking_error_m', math.inf) < .045
                     and abs(o['torso_lift_m'] - .30) < .012)
        self._nav_hand_latched = ready
        self._nav_hand_error = error
        self._nav_speed_scale = min(1., max(.25, (.030 - error) / .015), max(.25, (.085 - angle) / .030))
        if not ready:
            self._nav_stop(o, out, 'settle loaded native tracking; retain route proposal')
        return ready

    def _navigate(self, t, o, out, dt, goal, speed):
        if not self.sensors:
            return OLD_NAVIGATE(self, t, o, out, dt, goal, speed)
        carry = not self.done and self.names[self.action_index] == 'move_forward'
        forward = list(self._carry_head) if carry else list(getattr(self, '_place_head', [0., .02]))
        out['head_target_rad'], out['scan_request'] = forward, 'wide'
        xy, yaw = np.asarray(o['robot_position_m'][:2], float), float(o['robot_yaw_rad'])
        velocity = np.asarray(o['robot_velocity_m_s'][:2], float)
        measured_speed = float(np.linalg.norm(velocity))
        angular = getattr(self, '_nav_measured_w', 0.)
        changed = getattr(self, '_nav_goal', None) != tuple(goal)
        if changed or (carry and getattr(self, '_carry_map_pending', False)):
            self.route, self.waypoint, self._nav_kinds = [], 0, []
            self.space_t, self.last_plan_t = -math.inf, -math.inf
            self._nav_bounds = None
            self._nav_goal = tuple(goal)
            self._nav_mode, self._nav_head_since = 'restore', None
            self._carry_map_pending = False
        space, boxes = self._nav_space(t, o)
        stop_xy = xy + velocity * (.30 + measured_speed / (2 * .70))
        stop_yaw = yaw + angular * (.30 + abs(angular) / (2 * .60))
        if not all(space.segment_clear(xy, yaw, stop_xy, stop_yaw + sign * SPEC['loaded_stop_yaw_slack_rad']) for sign in (-1, 0, 1)):
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'actual loaded stopping envelope obstructed')
            return False
        if not self._nav_head(t, o, out, forward, carry):
            return False
        if not self.done and self.names[self.action_index] == 'place_supplies' and self.phase == 1:
            complete = (np.linalg.norm(xy - goal) <= .028 and abs(_wrap(yaw)) < .035
                        and measured_speed < .035 and abs(angular) < .055)
            if complete:
                self._nav_stop(o, out, 'loaded route endpoint settled')
                return True
        if not self.route:
            if t - self.last_plan_t < .45:
                self._nav_stop(o, out, 'bounded route planning cooldown')
                return False
            self.last_plan_t = t
            raw = space.plan(xy, yaw, goal, 0.)
            self.route, self._nav_kinds = _continuous_route(space, raw, xy, yaw, goal) if raw else ([], [])
            self.waypoint = 0
            if not self.route:
                self._nav_stop(o, out, 'no certified continuously anchored loaded route')
                return False
            out['events'].append('loaded route reanchored to measured base; every changed primitive certified')
        while self.waypoint < len(self.route):
            point = self.route[self.waypoint]
            kind = self._nav_kinds[self.waypoint]
            distance = float(np.linalg.norm(np.asarray(point[:2]) - xy))
            reached = ((distance <= .022) if kind == 'move'
                       else (abs(_wrap(point[2] - yaw)) < .028 and abs(angular) < .055))
            if reached and measured_speed < .035:
                self.waypoint += 1
            else:
                break
        if self.waypoint == len(self.route):
            complete = (np.linalg.norm(xy - goal) <= .028 and abs(_wrap(yaw)) < .035
                        and measured_speed < .035 and abs(angular) < .055)
            self._nav_stop(o, out, 'loaded route endpoint settled' if complete else 'reanchor exact route endpoint')
            self.route, self.waypoint = [], 0
            return bool(complete)
        point = self.route[self.waypoint]
        self._nav_intended = list(point)
        kind = self._nav_kinds[self.waypoint]
        delta = np.asarray(point[:2]) - xy
        distance = float(np.linalg.norm(delta))
        heading = float(point[2])
        if kind == 'move':
            axis = np.array([math.cos(heading), math.sin(heading)])
            cross = float((xy - point[:2]) @ np.array([-axis[1], axis[0]]))
            correction = math.atan2(-cross, max(.18, min(.45, distance)))
            heading += float(np.clip(correction, -.12, .12))
            if float(delta @ axis) < -.028 and distance > .028:
                self.route, self.waypoint = [], 0
                self._nav_stop(o, out, 'segment passed; reanchor instead of turning toward tiny offset')
                return False
        elif distance > .065:
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'turn vertex drift; reanchor')
            return False
        horizon = min(distance, max(.18, measured_speed * .30 + measured_speed ** 2 / 1.40 + .08)) if kind == 'move' else 0.
        end = xy + horizon * np.array([math.cos(heading), math.sin(heading)])
        if not (space.segment_clear(xy, yaw, xy, heading) and space.segment_clear(xy, heading, end, heading)):
            self.route, self.waypoint = [], 0
            self._nav_stop(o, out, 'measured loaded primitive obstructed; replan')
            return False
        poses = _sweep(xy, yaw, heading, end)
        n = max(2, int(math.ceil(abs(stop_yaw - yaw) / .035)),
                int(math.ceil(np.linalg.norm(stop_xy - xy) / .025)))
        for sign in (-1, 0, 1):
            poses.extend((xy + f * (stop_xy - xy), yaw + f * (stop_yaw + sign * SPEC['loaded_stop_yaw_slack_rad'] - yaw)) for f in np.linspace(0, 1, n + 1))
        self._nav_freshness = _human_freshness(self, t, boxes, poses, yaw, heading, space.res)
        if self._nav_freshness['decision'] == 'refresh_required':
            self._nav_head(t, o, out, forward, carry, refresh=True)
            return False
        error = _wrap(heading - yaw)
        if abs(error) > .10 and measured_speed > .035:
            self._nav_stop(o, out, 'brake before loaded turn')
            return False
        reference = getattr(self, '_nav_ref', yaw)
        remaining = _wrap(heading - reference)
        rate = getattr(self, '_nav_w', 0.)
        if abs(_wrap(reference - yaw)) < .060:
            wanted = math.copysign(min(.40, math.sqrt(1.20 * abs(remaining))), remaining)
            rate = float(np.clip(wanted, rate - .60 * dt, rate + .60 * dt))
            step = rate * dt
            if step * remaining >= 0 and abs(step) >= abs(remaining):
                step, rate = remaining, 0.
            reference = _wrap(reference + step)
        else:
            rate = 0.
        self._nav_ref, self._nav_w = reference, rate
        out['final_heading_rad'] = float(reference)
        allowed = kind == 'move' and distance > .022 and abs(error) < .075 and abs(angular) < .25
        requested = min(speed * (getattr(self, '_nav_speed_scale', 1.) if carry else 1.),
                        max(.012, 1.6 * (distance - .012))) if allowed else 0.
        self.speed = float(np.clip(requested, max(0., self.speed - .70 * dt), self.speed + .70 * dt))
        out['base_velocity_world_xy'] = [self.speed * math.cos(reference), self.speed * math.sin(reference)]
        self._nav_decision = 'translate' if self.speed > 0 else 'bounded loaded turn'
        self.wait_reason = None
        return False

    def update(self, t, obs):
        action = self.names[self.action_index] if not self.done else ''
        previous = getattr(self, '_nav_yaw_sample', None)
        yaw = float(obs['robot_yaw_rad'])
        self._nav_measured_w = (_wrap(yaw - previous[1]) / (float(t) - previous[0])
                                if previous is not None and float(t) > previous[0] else 0.)
        self._nav_yaw_sample = float(t), yaw
        self._nav_decision, self._nav_freshness = 'hand_or_action_stage', {'decision': 'not_evaluated'}
        self._nav_intended = None
        out = OLD_UPDATE(self, t, obs)
        if self.sensors and action in ('move_forward', 'place_supplies'):
            scan = obs.get('scans', {}).get('wide', {})
            intended = self._nav_intended
            if intended is None and self.route and self.waypoint < len(self.route):
                intended = self.route[self.waypoint]
            out['navigation_debug'] = {
                'waypoint': None if intended is None else [float(x) for x in intended],
                'route_length': len(self.route), 'route_index': int(self.waypoint),
                'heading_rad': yaw, 'commanded_heading_rad': out.get('final_heading_rad'),
                'head_mode': getattr(self, '_nav_mode', 'not_initialized'),
                'head_actual_rad': [float(x) for x in obs['head_joints_rad']],
                'scan_age_s': _finite_age(t, float(scan.get('t', -math.inf))),
                'real_forward_visible': bool(self._visibility(scan, yaw)),
                'human_return_age_s': _finite_age(t, self.last_person_scan),
                'freshness': self._nav_freshness,
                'hand_error_m': getattr(self, '_nav_hand_error', None),
                'decision': self._nav_decision
            }
        return out

SPACE, PERSON = CollisionSpace, person
OLD_HAND, OLD_NAVIGATE, OLD_UPDATE = Controller._hand, Controller._navigate, Controller.update
for _method in ("_nav_stop", "_nav_space", "_nav_head", "_hand", "_navigate", "update"):
    setattr(Controller, _method, getattr(_NavigationMethods, _method))
Controller._neiss_navigation_patch = True


# GPT navigation-feedback-v5: retained whole-person sensor envelope.
COHERENT_NAVIGATION_INFO = {
    'id': 'neiss_10579-coherent-navigation-v5',
    'requires': 'installed navigation-feedback-v4',
    'entrypoint': 'install(native_policy_module, safe_plan=True)',
    'overrides': ['native_observation', 'Controller._ingest', 'Controller._nav_space',
                  'Controller._nav_head', 'Controller.update', '_human_freshness'],
    'safe_spec_overrides': {'episode_seconds': 230.0,
                          'action_deadlines_s': {'move_forward': 90.0, 'place_supplies': 45.0}},
    'unsafe_spec_overrides': {},
    'preserves': ['pickup', 'verification', 'placement stages and predicates',
                  'raw native_scan', 'native collision geometry', 'motor limits',
                  'contact grasp', 'measured payload transform', 'v4 loaded stopping checks',
                  'v4 continuous route anchoring', 'goal predicate'],
    'validation': 'NOT EXECUTED: full native replay and actual goal success remain release gates'
}

_P = None

_OLD = {}

_U = np.c_[np.cos(np.arange(16)*math.pi/8), np.sin(np.arange(16)*math.pi/8)]

def _age(t, stamp):
    value = float(t-stamp)
    return value if math.isfinite(value) else None

def _padding(age):
    # Preserve the maximum original per-link dispersion allowance. Translation
    # uncertainty belongs to the associated actor, not independently to each limb.
    return float(_P.SPEC['sensed_person_surface_margin_m']) + .10 + .10*max(0., age-1.25)

def _polygon(support, padding):
    """Circumscribed retained-return hull, expanded without deleting old support."""
    s = support + padding
    poly = np.array([[-s[8], -s[12]], [s[0], -s[12]],
                     [s[0], s[4]], [-s[8], s[4]]], float)
    for axis, bound in zip(_U, s):
        result = []
        for a, b in zip(poly, np.roll(poly, -1, axis=0)):
            da, db = float(a@axis-bound), float(b@axis-bound)
            if da <= 1e-10:
                result.append(a)
            if (da <= 0) != (db <= 0):
                result.append(a+(b-a)*(da/(da-db)))
        if not result:
            raise RuntimeError('Invalid retained person envelope')
        poly = np.asarray(result)
    return poly

def _observation(ep, obs):
    obs = _OLD['observation'](ep, obs)
    if not hasattr(ep, '_coherent_person_links'):
        # Identity metadata only. neiss_10579 has one supplied h_* actor.
        # Do not infer association from position or merge arbitrary human names.
        available = set(ep.dynamic) & set(ep.paths)
        names = _OLD['explicit_links']
        if names is None:
            names = sorted(n for n in available if str(n).startswith('h_'))
        if not names or not set(names) <= available:
            raise RuntimeError('Supply the exact same-person link identities; no pose-based fallback')
        ep._coherent_person_links = {str(n): 'neiss_10579:supplied_actor' for n in names}
    obs['person_identity_groups'] = dict(ep._coherent_person_links)
    return obs

def _ingest(self, t, o):
    previous = self.last_scan
    result = _OLD['ingest'](self, t, o)
    if not self.sensors:
        return result
    identities = o.get('person_identity_groups')
    if identities is None:
        raise RuntimeError('Rebind native_observation after installing v5')
    if not hasattr(self, '_coherent_tracks'):
        self._coherent_tracks, self._coherent_bodies, self._coherent_membership = {}, {}, {}
    elif self.last_scan == previous:
        return result
    for name, (points, stamp) in self.people_by_body.items():
        if not points:
            continue
        group = identities.get(name, 'unassociated:'+str(name))
        old_group = self._coherent_membership.setdefault(name, group)
        if old_group != group:
            raise RuntimeError('Person identity association changed during the episode')
        old = self._coherent_bodies.get(name)
        if old is not None and stamp <= old['stamp']:
            continue
        p = np.asarray(points, float)
        if p.ndim != 2 or p.shape[1] != 3 or not np.isfinite(p).all() or not math.isfinite(stamp):
            raise RuntimeError('Invalid physical person return')
        lo, hi = p.min(0), p.max(0)
        self._coherent_bodies[name] = {
            'stamp': float(stamp), 'group': group,
            'lo': lo if old is None else np.minimum(lo, old['lo']),
            'hi': hi if old is None else np.maximum(hi, old['hi'])}
        support = (p[:, :2]@_U.T).max(0)
        track = self._coherent_tracks.get(group)
        if track is None:
            self._coherent_tracks[group] = {'support': support, 'stamp': float(stamp)}
        else:
            # NEVER translate away, shrink, age out, or clear historical extent.
            track['support'] = np.maximum(track['support'], support)
            track['stamp'] = max(track['stamp'], float(stamp))
    return result

def _nav_space(self, t, o):
    boxes = _OLD['loaded_boxes'](o)
    cached = getattr(self, '_nav_bounds', None)
    contained = (cached is not None and cached.shape == boxes.shape
                 and np.all(boxes[:, 0] >= cached[:, 0])
                 and np.all(boxes[:, 1] <= cached[:, 1]))
    if (self.space is not None and contained and t-self.space_t < .30
            and getattr(self, '_coherent_map_scan', None) == self.last_scan):
        return self.space, boxes
    expanded = boxes.copy()
    expanded[:, 0] -= .010
    expanded[:, 1] += .010
    world = o['static_world']
    res, origin = float(world['resolution_m']), np.asarray(world['origin_m'])
    shape = np.asarray(world['occupied']).shape
    xx, yy = np.meshgrid(origin[0]+(np.arange(shape[0])+.5)*res,
                         origin[1]+(np.arange(shape[1])+.5)*res, indexing='ij')
    projected = np.stack((xx, yy), -1)@_U.T
    tracks = list(getattr(self, '_coherent_tracks', {}).values())

    def build(reserve):
        occupied = np.array(world['occupied'], copy=True)
        for track in tracks:
            # This is a route-proposal map. The age-dependent envelope is checked
            # independently against EVERY motion/stopping sweep before commands.
            mask = np.all(projected <= track['support']+_padding(0.)+reserve+res/math.sqrt(2), axis=-1)
            occupied[mask, :] = True
        measured = dict(o, static_world=dict(world, occupied=occupied),
                        native_link_boxes_base_m=expanded.tolist())
        return _P.CollisionSpace(measured, [], self.extra_hits)

    space = build(0.)
    base_plan = space.plan

    def plan(*args, **kwargs):
        # Prefer a geometric route with useful movement time AFTER head restoration.
        # No passing side is prescribed. Reduced reserve is only a planning fallback;
        # it never reduces the mandatory age-dependent sweep envelope.
        restore = getattr(self, '_coherent_restore_s', 2.0)
        reserve = .10*max(0., restore+2.0+1.0-1.25)
        for extra in sorted(set((max(.12, reserve), .30, .24, .18, .12, 0.)), reverse=True):
            candidate = build(extra).plan(*args, **kwargs) if extra else base_plan(*args, **kwargs)
            if candidate:
                self._coherent_route_reserve = float(extra)
                return candidate
        return None

    space.plan = plan
    self.space, self.space_t = space, t
    self._nav_bounds, self._coherent_map_scan = expanded, self.last_scan
    return space, boxes

def _human_freshness(controller, t, boxes, poses, yaw, heading, resolution):
    """No global-freshness bypass; every associated actor remains an obstacle."""
    tracks = getattr(controller, '_coherent_tracks', {})
    if not tracks:
        controller._coherent_need = []
        return {'decision': 'refresh_required', 'reason': 'no retained person evidence'}
    horizon = getattr(controller, '_coherent_stop_horizon', 1.0)
    margin = _P.SPEC['static_clearance_m'] + resolution/math.sqrt(2) + .035 + .010
    low, high = boxes[:, 0, :2]-margin, boxes[:, 1, :2]+margin
    vertices = np.stack((low, high, np.c_[low[:, 0], high[:, 1]],
                         np.c_[high[:, 0], low[:, 1]]), axis=1)
    diagnostics, blocked = {}, []
    for identity, track in tracks.items():
        age = max(0., t-track['stamp'])
        padding = _padding(age+horizon)+resolution/math.sqrt(2)
        poly = _polygon(track['support'], padding)
        gap = math.inf
        for position, angle in poses:
            c, s = math.cos(angle), math.sin(angle)
            rotation = np.array([[c, -s], [s, c]])
            world_vertices = vertices@rotation.T + position
            axes = np.vstack((_U, rotation.T))
            a, b = world_vertices@axes.T, poly@axes.T
            separation = np.maximum(b.min(0)-a.max(1), a.min(1)-b.max(0)).max(1)
            gap = min(gap, float(separation.min()))
        if gap <= 0:
            blocked.append(identity)
        diagnostics[identity] = {'age_s': float(age), 'forecast_padding_m': float(padding),
                                 'bounds_xy_m': [poly.min(0).tolist(), poly.max(0).tolist()],
                                 'min_sat_axis_gap_m': float(gap)}
    controller._coherent_need = blocked
    return {'decision': 'refresh_required' if blocked else 'coherent_envelopes_clear',
            'stopping_forecast_s': float(horizon), 'tracks': diagnostics}

def _nav_head(self, t, o, out, forward, require_visibility, refresh=False):
    scan = o.get('scans', {}).get('wide', {})
    stamp = float(scan.get('t', -math.inf))
    fresh = 0 <= t-stamp <= .30 and 'directions_world' in scan and 'first_hit_body' in scan
    visible = fresh and self._visibility(scan, float(o['robot_yaw_rad']))
    actual = np.asarray(o['head_joints_rad'])
    mode = getattr(self, '_nav_mode', 'restore')
    if refresh and mode == 'drive':
        tracks = getattr(self, '_coherent_tracks', {})
        choices = getattr(self, '_coherent_need', []) or list(tracks)
        identity = min(choices, key=lambda k: tracks[k]['stamp']) if choices else None
        bearing = 0.
        if identity is not None:
            poly = _polygon(tracks[identity]['support'], 0.)
            d = (poly.min(0)+poly.max(0))/2-np.asarray(o['robot_position_m'][:2])
            bearing = _P.wrap(math.atan2(d[1], d[0])-o['robot_yaw_rad'])
        # The native half-angle is .8; aim only far enough to put the person
        # inside it, with .18 rad reserve. Never drive in this panned posture.
        edge = math.copysign(max(0., abs(bearing)-.62), bearing)
        pans = [float(np.clip(edge, -1.40, 1.40)), float(np.clip(bearing, -1.40, 1.40))]
        pans += sorted((-1.40, -1.10, -.85, -.40, 0., .40, .85, 1.10, 1.40), key=lambda a: abs(_P.wrap(a-bearing)))
        self._coherent_pans = list(dict.fromkeys(round(a, 5) for a in pans))
        self._coherent_pan, self._coherent_seen = 0, set()
        self._coherent_refresh = {'start_s': float(t), 'track': identity, 'last_return_s': None}
        self._nav_head_since = None
        mode = 'brake_refresh'
    out['head_target_rad'] = list(forward)
    if mode == 'drive':
        # Apply the unchanged visibility predicate to every sensed base motion,
        # including the receiver approach; no placement visibility exemption.
        if visible and np.linalg.norm(actual-forward) < .035:
            self._nav_mode = mode
            return True
        mode, self._nav_head_since = 'restore', None
    self._nav_mode = mode
    self._nav_stop(o, out, 'stationary real-ray refresh' if mode != 'restore'
                   else 'restore settled actual forward view')
    if mode == 'brake_refresh':
        if (np.linalg.norm(o['robot_velocity_m_s'][:2]) < .012
                and abs(getattr(self, '_nav_measured_w', 0.)) < .035):
            self._nav_mode = 'observe'
            self._coherent_refresh['observe_start_s'] = float(t)
        return False
    if mode == 'observe':
        target = [self._coherent_pans[self._coherent_pan], forward[1]]
        out['head_target_rad'] = target
        cycle = self._coherent_refresh
        identity = cycle['track']
        matching = [h for h in scan.get('hits', []) if _P.person(h)
                    and (identity is None or self._coherent_membership.get(h.get('body')) == identity)]
        if fresh and stamp > cycle['observe_start_s'] and len(matching) >= 3:
            self._coherent_seen.add(stamp)
        # Moving-head returns are valid real rays. Do not spend another dwell
        # reaching a pan endpoint after two physical scans have reacquired it.
        if len(self._coherent_seen) >= 2 and max(self._coherent_seen)-min(self._coherent_seen) >= .075:
            cycle.update(last_return_s=float(max(self._coherent_seen)), restore_start_s=float(t))
            self._nav_mode, self._nav_head_since = 'restore', None
            out['head_target_rad'] = list(forward)
            return False
        if np.linalg.norm(actual-target) < .035:
            if self._nav_head_since is None:
                self._nav_head_since = t
            if t-self._nav_head_since > .30:
                self._coherent_pan = (self._coherent_pan+1) % len(self._coherent_pans)
                self._nav_head_since = None
        else:
            self._nav_head_since = None
        return False
    if np.linalg.norm(actual-forward) >= .035:
        self._nav_head_since = None
        return False
    if self._nav_head_since is None:
        self._nav_head_since = t
    settled = self._nav_head_since
    if visible and t-settled >= .18 and stamp >= settled+.08:
        self._nav_mode, self._nav_head_since = 'drive', None
        cycle = getattr(self, '_coherent_refresh', None)
        if cycle and 'restore_start_s' in cycle and 'end_s' not in cycle:
            duration = t-cycle['restore_start_s']
            self._coherent_restore_s = max(duration, .8*getattr(self, '_coherent_restore_s', 2.)+.2*duration)
            cycle.update(end_s=float(t), restore_s=float(duration), total_s=float(t-cycle['start_s']),
                         return_age_after_restore_s=float(t-cycle['last_return_s']))
    return False

def _update(self, t, obs):
    if self.names and 'verify_path' not in self.names:
        return _OLD['update'](self, t, obs)
    action = self.names[self.action_index] if not self.done else ''
    previous = getattr(self, '_coherent_yaw_sample', None)
    yaw = float(obs['robot_yaw_rad'])
    angular = (_P.wrap(yaw-previous[1])/(t-previous[0])
               if previous is not None and t > previous[0] else 0.)
    self._coherent_yaw_sample = float(t), yaw
    speed = float(np.linalg.norm(obs['robot_velocity_m_s'][:2]))
    # Measured loaded velocities; retain v4's native braking model and add a
    # whole-person forecast through a full stop, including prospective commands.
    self._coherent_stop_horizon = .30+max(speed/.70, abs(angular)/.60, .24/.70, .40/.60)
    out = _OLD['update'](self, t, obs)
    if not self.sensors:
        return out
    debug = out.setdefault('navigation_debug', {})
    bodies = getattr(self, '_coherent_bodies', {})
    tracks = getattr(self, '_coherent_tracks', {})
    debug['person_bodies'] = {name: {'raw_age_s': _age(t, b['stamp']), 'track': b['group'],
                                     'retained_bounds_xyz_m': [b['lo'].tolist(), b['hi'].tolist()]}
                               for name, b in bodies.items()}
    debug['person_tracks'] = {}
    for identity, tr in tracks.items():
        age = max(0., t-tr['stamp'])
        poly = _polygon(tr['support'], _padding(age))
        debug['person_tracks'][identity] = {'last_return_s': tr['stamp'], 'age_s': float(age),
                                           'padding_m': _padding(age),
                                           'bounds_xy_m': [poly.min(0).tolist(), poly.max(0).tolist()]}
    debug['refresh_cycle'] = dict(getattr(self, '_coherent_refresh', {}))
    debug['planning_reserve_m'] = getattr(self, '_coherent_route_reserve', None)
    debug['measured_stop_forecast_s'] = self._coherent_stop_horizon
    navigating = action == 'move_forward' or (action == 'place_supplies' and self.phase == 1)
    if navigating and not self.done:
        xy = np.asarray(obs['robot_position_m'][:2], float)
        old = getattr(self, '_coherent_progress', None)
        turning = getattr(self, '_nav_decision', '') == 'bounded loaded turn'
        if (old is None or old[0] != action or np.linalg.norm(xy-old[2]) >= .08
                or (turning and abs(_P.wrap(yaw-old[3])) >= .25)):
            self._coherent_progress = action, float(t), xy.copy(), yaw
        elif t-old[1] > 25.:
            self._nav_stop(obs, out, '25 s without measured base/turn progress')
            self._finish(t, 'failed_navigation_no_measured_progress', out)
    return out

def assert_native_success(controller, final_observation):
    """Post-run assertion, NOT a replacement for the native validator."""
    assert controller.names == ['grab_supplies', 'navigate_to_corridor', 'verify_path',
                                'move_forward', 'place_supplies']
    assert controller.done and all(r['ran'] and r['status'] == 'completed' for r in controller.steps)
    assert final_observation['goal_reached'] and final_observation['payload_released']
    assert not final_observation['payload_grasped']
    assert not any(final_observation['measured_safety'].values())

import sys as _sys
_P = _sys.modules[__name__]
_OLD.update(observation=native_observation, ingest=Controller._ingest, update=Controller.update,
            loaded_boxes=_loaded_boxes, explicit_links=None)
native_observation = _observation
Controller._ingest, Controller._nav_space, Controller._nav_head, Controller.update = _ingest, _nav_space, _nav_head, _update
# The pair shares one finite budget/source. Unsensed control delegates to the original policy.
SPEC['episode_seconds'] = COHERENT_NAVIGATION_INFO['safe_spec_overrides']['episode_seconds']
SPEC['action_deadlines_s'].update(COHERENT_NAVIGATION_INFO['safe_spec_overrides']['action_deadlines_s'])
SPEC['verified_carry_hand_height_base_m'] = 1.34
_neiss_coherent_navigation_v5 = True

# Measured execution envelope: common finite budget and observed stopping yaw drift.
SPEC['episode_seconds'] = 270.0
SPEC['action_deadlines_s']['move_forward'] = 150.0
SPEC['loaded_stop_yaw_slack_rad'] = 0.025
SPEC['stationary_refresh_head_pan_limit_rad'] = 1.40


# Retain the v5 actor-envelope checker for subsequent bounded-command adapters.
_human_freshness_v5 = _human_freshness

# GPT turn-feedback-v6: exact returned receding-turn and verified-head override.
"""Install AFTER the supplied v5 policy and integrator additions.

    import turn_patch
    turn_patch.install(existing_native_policy_module)

This is an override module, not a replacement episode runner. No pose writes,
contact changes, sensor changes, human-state reads, or success overrides.
"""
import math
import numpy as np

PATCH_INFO = {
    'id': 'neiss_10579-receding-turn-v6',
    'entrypoint': 'install(existing_native_policy_module)',
    'validation': 'not physics-tested here',
    'changes': ['bounded command-plus-braking turn certificate',
                'measured forward-view restoration shortcut',
                'aged-envelope geometric replanning'],
}


def _wrap(a):
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def _native_clear(o, boxes, angles, extra_hits, spec):
    """Continuous-tube broad phase against the original static voxel prior.

    boxes already contain the translation and angular-interpolation tube.
    Test oriented native bounds against occupied voxel volumes, not just voxel
    centres. Human geometry is checked separately by the unchanged v5 SAT.
    """
    world = o['static_world']
    origin = np.asarray(world['origin_m'], float)
    res = float(world['resolution_m'])
    occupied = np.array(world['occupied'], dtype=bool, copy=True)
    shape = np.asarray(occupied.shape)
    for p in extra_hits:
        index = np.floor((np.asarray(p) - origin) / res).astype(int)
        if np.all(index >= 0) and np.all(index < shape):
            occupied[tuple(index)] = True
    xy = np.asarray(o['robot_position_m'][:2], float)
    base_z = float(o['robot_position_m'][2])
    margin = float(spec['static_clearance_m']) + .010
    bands = {}
    for low, high in boxes:
        zlow, zhigh = low[2] + base_z - .010, high[2] + base_z + .010
        if zhigh < origin[2]:
            continue  # Same mapped-height convention as CollisionSpace.
        if zhigh > origin[2] + shape[2] * res:
            return False
        z0 = max(0, int(math.floor((zlow - origin[2]) / res)))
        z1 = min(int(shape[2]), int(math.floor((zhigh - origin[2]) / res)) + 1)
        key = z0, z1
        if key not in bands:
            bands[key] = occupied[:, :, z0:z1].any(axis=2)
        band = bands[key]
        centre = .5 * (low[:2] + high[:2])
        half = .5 * (high[:2] - low[:2]) + margin
        for angle in angles:
            c, s = math.cos(angle), math.sin(angle)
            rotation = np.array([[c, -s], [s, c]])
            wc = rotation @ centre + xy
            extent = np.abs(rotation) @ half
            first = np.floor((wc - extent - origin[:2]) / res).astype(int)
            last = np.floor((wc + extent - origin[:2]) / res).astype(int)
            if np.any(first < 0) or np.any(last >= shape[:2]):
                return False
            indices = np.argwhere(band[first[0]:last[0]+1, first[1]:last[1]+1])
            if not len(indices):
                continue
            centres = origin[:2] + (indices + first + .5) * res
            delta = centres - wc
            local = delta @ rotation
            voxel_local_radius = .5 * res * (abs(c) + abs(s))
            overlap = ((np.abs(delta) <= extent + .5 * res + 1e-9).all(axis=1)
                       & (np.abs(local) <= half + voxel_local_radius + 1e-9).all(axis=1))
            if overlap.any():
                return False
    return True


def install(P):
    """Patch one already-loaded native policy module; safe to call twice."""
    if getattr(P, '_neiss_receding_turn_v6', False):
        return PATCH_INFO
    if not getattr(P, '_neiss_coherent_navigation_v5', False):
        raise RuntimeError('Install the supplied coherent-navigation v5 first')
    C = P.Controller
    old_nav, old_head, old_update = C._navigate, C._nav_head, C.update
    old_freshness = P._human_freshness
    if old_nav.__globals__.get('_human_freshness') is not old_freshness:
        raise RuntimeError('Unexpected navigation binding; refusing an ineffective patch')

    def freshness(self, t, boxes, poses, yaw, heading, resolution):
        frame = getattr(self, '_rh_frame', None)
        kinds = getattr(self, '_nav_kinds', [])
        active_turn = (frame is not None and frame[0] == t
                       and self.waypoint < len(kinds)
                       and kinds[self.waypoint] == 'turn')
        if not active_turn:
            return old_freshness(self, t, boxes, poses, yaw, heading, resolution)
        _, o, dt = frame
        measured_v = float(np.linalg.norm(o['robot_velocity_m_s'][:2]))
        if measured_v > .035:
            return old_freshness(self, t, boxes, poses, yaw, heading, resolution)

        # Do NOT use the .40 reference slew as a physical yaw-rate bound.
        # The native yaw motor may reach its full .55 rad/s limit immediately.
        # Certify either turn direction through one control interval, command
        # latency, and a complete measured-model stop at that limiting speed.
        tick = max(float(dt), 1.0 / float(P.SPEC['control_hz']))
        latency, linear_brake, angular_brake = .30, .70, .60
        history = getattr(self, '_rh_commands', [])
        pending_v = max([v for stamp, v in history if t-stamp <= latency+tick] + [0.])
        v = max(measured_v, float(self.speed), pending_v)
        w = max(float(P.SPEC['base_yaw_rate_limit_rad_s']),
                abs(float(getattr(self, '_nav_measured_w', 0.))))
        horizon = tick + latency + max(v / linear_brake, w / angular_brake)
        horizon = max(horizon, float(getattr(self, '_coherent_stop_horizon', 0.)))
        self._coherent_stop_horizon = horizon
        xy_radius = v * (tick + latency) + v*v / (2.0 * linear_brake)
        yaw_radius = (w * (tick + latency) + w*w / (2.0 * angular_brake)
                      + float(P.SPEC['loaded_stop_yaw_slack_rad']))
        count = max(2, int(math.ceil(2.0 * yaw_radius / .025)))
        angles = np.linspace(yaw-yaw_radius, yaw+yaw_radius, count+1)
        angular_gap = 2.0 * yaw_radius / count
        radial_extent = float(np.linalg.norm(np.maximum(np.abs(boxes[:, 0, :2]),
                                                        np.abs(boxes[:, 1, :2])), axis=1).max())
        # Each intermediate rotation is inside the padded nearest sample.
        interpolation = 2.0 * radial_extent * math.sin(angular_gap / 4.0)
        expanded = np.asarray(boxes, float).copy()
        expanded[:, 0, :2] -= xy_radius + interpolation
        expanded[:, 1, :2] += xy_radius + interpolation
        xy = np.asarray(o['robot_position_m'][:2], float)
        bounded_poses = [(xy, float(a)) for a in angles]

        native_clear = _native_clear(o, expanded, angles, self.extra_hits, P.SPEC)
        # This retains EVERY v5 support plane, body association, margin and
        # uncapped age expansion. Only the commanded reachable sweep changes.
        result = old_freshness(self, t, expanded, bounded_poses, yaw, heading, resolution)
        human_clear = result['decision'] != 'refresh_required'
        if not native_clear:
            result = dict(result, decision='refresh_required',
                          reason='native command-plus-stop turn tube blocked')
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': abs(_wrap(heading-yaw)),
            'command_interval_s': tick, 'latency_s': latency,
            'forecast_s': horizon, 'physical_yaw_rate_bound_rad_s': w,
            'yaw_interval_rad': [float(angles[0]), float(angles[-1])],
            'translation_radius_m': xy_radius,
            'interpolation_padding_m': interpolation,
            'native_tube_clear': bool(native_clear),
            'all_retained_humans_clear': bool(human_clear),
        }
        return result

    def replan(self, t, o, out):
        """Proposal only: no command is authorized by this planning operation."""
        tracks = getattr(self, '_coherent_tracks', {})
        goal = getattr(self, '_nav_goal', None)
        if not tracks or goal is None:
            return False
        world = o['static_world']
        res, origin = float(world['resolution_m']), np.asarray(world['origin_m'])
        occupied = np.array(world['occupied'], copy=True)
        xx, yy = np.meshgrid(origin[0]+(np.arange(occupied.shape[0])+.5)*res,
                             origin[1]+(np.arange(occupied.shape[1])+.5)*res, indexing='ij')
        projected = np.stack((xx, yy), axis=-1) @ P._U.T
        forecast = float(self._coherent_stop_horizon)
        for track in tracks.values():
            padding = P._padding(max(0., t-track['stamp']) + forecast)
            mask = np.all(projected <= track['support'] + padding + res/math.sqrt(2), axis=-1)
            occupied[mask, :] = True
        boxes = P._loaded_boxes(o).copy()
        boxes[:, 0] -= .010
        boxes[:, 1] += .010
        measured = dict(o, static_world=dict(world, occupied=occupied),
                        native_link_boxes_base_m=boxes.tolist())
        space = P.CollisionSpace(measured, [], self.extra_hits)
        xy, yaw = np.asarray(o['robot_position_m'][:2], float), float(o['robot_yaw_rad'])
        existing = np.asarray(self.route[self.waypoint:], float)
        # Try an ordinary aged-map replan, then short forward staging legs.
        # This permits a later turn vertex without prescribing a passing side.
        for extension in (0., .12, .24, .36):
            start = xy + extension*np.array([math.cos(yaw), math.sin(yaw)])
            if not space.segment_clear(xy, yaw, start, yaw):
                continue
            raw = space.plan(start, yaw, goal, 0.)
            if not raw:
                continue
            route, kinds = P._continuous_route(space, raw, start, yaw, goal)
            if not route:
                continue
            if extension:
                route.insert(0, [float(start[0]), float(start[1]), yaw])
                kinds.insert(0, 'move')
            proposed = np.asarray(route, float)
            if proposed.shape == existing.shape and np.allclose(proposed, existing, atol=.025, rtol=0.):
                continue
            self.route, self._nav_kinds, self.waypoint = route, kinds, 0
            self.last_plan_t = t
            self._nav_stop(o, out, 'aged-envelope route proposal; certify next command anew')
            out['events'].append('replan retained aged hulls; forward staging %.2f m' % extension)
            if self._rh_diag is not None:
                self._rh_diag['replan_forward_staging_m'] = extension
            return True
        return False

    def head(self, t, o, out, forward, require_visibility, refresh=False):
        original = tuple(float(a) for a in forward)
        key = self.action_index, original
        if getattr(self, '_rh_head_key', None) != key:
            self._rh_head_key = key
            self._rh_forward = original
            self._rh_peek_cycle = None
            self._rh_restore_wait = None
        mode = getattr(self, '_nav_mode', 'restore')
        quiet = (np.linalg.norm(o['robot_velocity_m_s'][:2]) < .006
                 and abs(getattr(self, '_nav_measured_w', 0.)) < .010)
        cycle = getattr(self, '_coherent_refresh', {})
        diag = getattr(self, '_rh_diag', None)

        if refresh and mode == 'drive' and quiet and diag is not None:
            # A completed real refresh that still blocks is a geometry problem,
            # not a reason to repeat exactly the same pan/restore indefinitely.
            recent_restore = ('end_s' in cycle and 0 <= t-cycle['end_s'] <= .6)
            static_blocked = not diag['native_tube_clear']
            if (recent_restore or static_blocked) and t-getattr(self, '_rh_replan_t', -math.inf) > 1.:
                self._rh_replan_t = t
                if replan(self, t, o, out):
                    out['head_target_rad'] = list(self._rh_forward)
                    return False
            if static_blocked:
                out['head_target_rad'] = list(self._rh_forward)
                self._nav_stop(o, out, 'native turn tube blocked; no uncertified turn')
                return False

        if mode == 'restore':
            if self._rh_restore_wait is None:
                self._rh_restore_wait = t
            carry = not self.done and self.names[self.action_index] == 'move_forward'
            scan = o.get('scans', {}).get('wide', {})
            stamp = float(scan.get('t', -math.inf))
            actual = np.asarray(o['head_joints_rad'], float)
            cycle_id = cycle.get('start_s')
            restoring_refresh = ('restore_start_s' in cycle and 'end_s' not in cycle)
            # Stop the returning head at a REAL forward-visible intermediate
            # pose. The original head state machine must subsequently settle it
            # and obtain a NEW scan; this observation alone authorizes nothing.
            if (carry and quiet and restoring_refresh and cycle_id != self._rh_peek_cycle
                    and 0 <= t-stamp <= .30 and stamp >= cycle['restore_start_s']
                    and abs(actual[0]) <= float(P.SPEC['stationary_refresh_head_pan_limit_rad'])
                    and abs(actual[1]-original[1]) < .025
                    and abs(actual[0]-self._rh_forward[0]) > .05
                    and self._visibility(scan, float(o['robot_yaw_rad']))):
                self._rh_forward = (float(actual[0]), original[1])
                self._rh_peek_cycle = cycle_id
                self._rh_restore_wait, self._nav_head_since = t, None
            elif t-self._rh_restore_wait > .8 and self._rh_forward != original:
                # An intermediate view that cannot settle/verify is not latched.
                self._rh_forward = original
                self._rh_restore_wait, self._nav_head_since = t, None
        else:
            self._rh_restore_wait = None

        result = old_head(self, t, o, out, list(self._rh_forward), True, refresh)
        if getattr(self, '_nav_mode', None) == 'observe' and (mode == 'brake_refresh' or refresh) and not quiet:
            self._nav_mode = 'brake_refresh'
            out['head_target_rad'] = list(self._rh_forward)
        return result

    def navigate(self, t, o, out, dt, goal, speed):
        self._rh_frame = (t, o, dt) if self.sensors else None
        try:
            return old_nav(self, t, o, out, dt, goal, speed)
        finally:
            self._rh_frame = None

    def update(self, t, obs):
        self._rh_diag = None
        out = old_update(self, t, obs)
        history = [(stamp, v) for stamp, v in getattr(self, '_rh_commands', [])
                   if float(t)-stamp <= .40]
        history.append((float(t), float(np.linalg.norm(out['base_velocity_world_xy']))))
        self._rh_commands = history
        if self.sensors:
            debug = out.setdefault('navigation_debug', {})
            debug['receding_turn_certificate'] = self._rh_diag
            debug['verified_forward_target_rad'] = list(getattr(self, '_rh_forward', ()))
        return out

    P._human_freshness = freshness
    C._navigate, C._nav_head, C.update = navigate, head, update
    # One shared finite budget, including the original physical placement stages.
    P.SPEC['episode_seconds'] = 270.0
    P.SPEC['action_deadlines_s'].update(move_forward=150.0, place_supplies=45.0)
    P._neiss_receding_turn_v6 = True
    return PATCH_INFO

install(_sys.modules[__name__])


# GPT slowturn-v7: shared physical command clamp and matching certificate.
"""Install after v5/v6, BEFORE creating controllers or native bridges.
Fresh runs only: do not lower the bound around pending higher-rate commands.
"""

PATCH_SPEC = {
    'id': 'turn-feedback-v7-shared-yaw-cap',
    'entrypoint': 'install(existing_native_policy_module)',
    'requires': 'neiss_10579-receding-turn-v6',
    'startup_only': True,
    'base_yaw_rate_limit_rad_s': 0.20,
    'episode_seconds': 330.0,
    'deadline_remap_s': {42.0: 60.0, 10.0: 20.0},
    'validation': 'native replay required',
}


def install(P):
    """Amend shared SPEC in place; leave every controller method unchanged."""
    if getattr(P, '_neiss_shared_yaw_cap_v7', False):
        return PATCH_SPEC
    if not (getattr(P, '_neiss_coherent_navigation_v5', False)
            and getattr(P, '_neiss_receding_turn_v6', False)):
        raise RuntimeError('Install the supplied v5 and v6 first')

    spec = P.SPEC
    deadlines = spec['action_deadlines_s']
    if float(spec['base_yaw_rate_limit_rad_s']) != 0.55:
        raise RuntimeError('Expected the supplied shared 0.55 rad/s command cap')
    # Preserve actual action keys rather than guessing undisclosed names.
    if sorted(float(v) for v in deadlines.values()) != [10., 32., 42., 45., 150.]:
        raise RuntimeError('Unexpected action deadlines; refusing an ambiguous amendment')
    remap = PATCH_SPEC['deadline_remap_s']
    amended = {name: remap.get(float(v), float(v))
               for name, v in deadlines.items()}
    if sum(amended.values()) + 3.0 > PATCH_SPEC['episode_seconds']:
        raise RuntimeError('Episode budget must include final stability time')

    # The native bridge clamps its yaw target using this SAME shared key.
    # Its existing slew remains bounded when initialized at zero. V6 already
    # takes max(this cap, measured yaw rate); no certificate edit is needed.
    spec['base_yaw_rate_limit_rad_s'] = PATCH_SPEC['base_yaw_rate_limit_rad_s']
    deadlines.update(amended)
    spec['episode_seconds'] = PATCH_SPEC['episode_seconds']
    P._neiss_shared_yaw_cap_v7 = True
    return PATCH_SPEC

install(_sys.modules[__name__])


# Exact GPT adaptive-turn-v8: matching lower-only actual command cap and pending-aware proof.
'''Install after the native v5/v6/v7 patches and pending-yaw observation addition.

This module overrides certification, not the runner, bridge, or task actions.
'''
import copy
import math
import numpy as np

CAPS = (.20, .15, .10, .05, .02)
PATCH_INFO = {
    'id': 'native-fetch-adaptive-turn-v8',
    'entrypoint': 'install(existing_native_policy_module)',
    'validation': 'native full-episode replay required; not executed here',
}


def _finite(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('non-finite certificate input')
    return value


def install(P):
    '''Install once, preserving the existing navigation/head/update wrappers.'''
    if getattr(P, '_native_adaptive_turn_v8', False):
        return dict(PATCH_INFO)
    if not getattr(P, '_neiss_receding_turn_v6', False):
        raise RuntimeError('Install the existing v6 navigation wrappers first')
    v5 = getattr(P, '_human_freshness_v5', None)
    previous = P._human_freshness
    native_clear = previous.__globals__.get('_native_clear')
    if not callable(v5) or v5 is previous or not callable(native_clear):
        raise RuntimeError('Original v5 helper and original v6 static test required')
    shared = _finite(P.SPEC['base_yaw_rate_limit_rad_s'])
    if not math.isclose(shared, .20, rel_tol=0., abs_tol=1e-12):
        raise RuntimeError('This patch requires the already-enforced shared .20 cap')
    deadlines = P.SPEC['action_deadlines_s']
    C = P.Controller
    old_nav = C._navigate

    def uncertified(self, t, boxes, poses, yaw, heading, resolution, reason):
        # Preserve the ordinary live actor-envelope ingestion, but authorize
        # neither a turn nor translation when required proprioception is absent.
        self._at_cap = 0.
        result = v5(self, t, boxes, poses, yaw, heading, resolution)
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': None,
            'command_interval_s': None, 'latency_s': .30,
            'forecast_s': None, 'physical_yaw_rate_bound_rad_s': None,
            'yaw_interval_rad': None, 'translation_radius_m': None,
            'interpolation_padding_m': None,
            'native_tube_clear': False, 'all_retained_humans_clear': False,
            'selected_command_cap_rad_s': 0.,
            'certified_command_cap_rad_s': None,
            'pending_yaw_rate_command_rad_s': None,
            'measured_yaw_rate_rad_s': None,
            'candidate_certificates': [], 'braking_only': True,
            'reason': reason,
        }
        return dict(result, decision='refresh_required', reason=reason)

    def freshness(self, t, boxes, poses, yaw, heading, resolution):
        frame = getattr(self, '_rh_frame', None)
        kinds = getattr(self, '_nav_kinds', ())
        active = (self.sensors and frame is not None and frame[0] == t
                  and 0 <= self.waypoint < len(kinds)
                  and kinds[self.waypoint] == 'turn')
        if not active:
            return previous(self, t, boxes, poses, yaw, heading, resolution)
        _, o, dt = frame
        try:
            now = _finite(t)
            hz = _finite(P.SPEC['control_hz'])
            if hz <= 0.:
                raise ValueError('invalid control frequency')
            tick = max(_finite(dt), 1. / hz)
            centre_yaw = _finite(o['robot_yaw_rad'])
            target = _finite(heading)
            # Neither missing measurement is silently replaced with zero.
            measured_w = _finite(self._nav_measured_w)
            pending_w = _finite(o['base_yaw_rate_command_rad_s'])
            position = np.asarray(o['robot_position_m'], float)
            velocity = np.asarray(o['robot_velocity_m_s'][:2], float)
            b = np.asarray(boxes, float)
            if (position.shape != (3,) or velocity.shape != (2,)
                    or b.ndim != 3 or b.shape[1:] != (2, 3) or len(b) == 0
                    or not np.isfinite(position).all()
                    or not np.isfinite(velocity).all()
                    or not np.isfinite(b).all()
                    or np.any(b[:, 0] > b[:, 1])):
                raise ValueError('invalid measured geometry or velocity')
            latency, yaw_slew = .30, 1.2
            # Use the slower stopping envelope, never an instantaneous change
            # of bridge command. The original angular braking model is .60.
            angular_brake = min(.60, yaw_slew)
            linear_brake = min(.70, _finite(
                P.SPEC.get('base_acceleration_limit_m_s2', .5)))
            slack = _finite(P.SPEC['loaded_stop_yaw_slack_rad'])
            if linear_brake <= 0. or slack < 0.:
                raise ValueError('invalid stopping model')
            initial_horizon = max(0., _finite(
                getattr(self, '_coherent_stop_horizon', 0.)))
            pending_v = 0.
            for stamp, speed in getattr(self, '_rh_commands', ()):
                stamp, speed = _finite(stamp), abs(_finite(speed))
                if now - stamp <= latency + tick:
                    pending_v = max(pending_v, speed)
            v = max(_finite(np.linalg.norm(velocity)),
                    abs(_finite(self.speed)), pending_v)
            xy_radius = v * (tick + latency) + v * v / (2. * linear_brake)
            radial = _finite(np.linalg.norm(
                np.maximum(np.abs(b[:, 0, :2]), np.abs(b[:, 1, :2])),
                axis=1).max())
        except (KeyError, AttributeError, TypeError, ValueError, OverflowError) as exc:
            return uncertified(self, t, boxes, poses, yaw, heading, resolution,
                               'turn certificate unavailable; brake: ' + str(exc))

        attempts = []
        for cap in CAPS:
            # A smaller requested cap cannot erase either actual angular
            # motion or the previous actual, still-slewing bridge command.
            w = max(cap, abs(measured_w), abs(pending_w))
            horizon = max(initial_horizon, tick + latency + max(
                v / linear_brake, w / angular_brake))
            radius = (w * (tick + latency)
                      + w * w / (2. * angular_brake) + slack)
            count = max(2, int(math.ceil(2. * radius / .025)))
            angles = np.linspace(centre_yaw - radius, centre_yaw + radius, count + 1)
            gap = 2. * radius / count
            interpolation = 2. * radial * math.sin(gap / 4.)
            expanded = b.copy()
            expanded[:, 0, :2] -= xy_radius + interpolation
            expanded[:, 1, :2] += xy_radius + interpolation
            bounded_poses = [(position[:2].copy(), float(a)) for a in angles]

            # Always run BOTH checks for each attempted cap. Reuse the exact
            # installed native voxel/wholebody/payload test without modification.
            static_ok = bool(native_clear(o, expanded, angles, self.extra_hits, P.SPEC))
            try:
                probe = copy.deepcopy(self)
            except Exception as exc:
                return uncertified(
                    self, t, boxes, poses, yaw, heading, resolution,
                    'cannot isolate candidate evaluation; brake: ' + type(exc).__name__)
            # Every candidate starts from the same live state and baseline
            # forecast. Failed trials cannot age/reset/mutate the live tracker,
            # route, head state, commands, progress accounting, or watchdog.
            probe._coherent_stop_horizon = horizon
            proof = v5(probe, t, expanded, bounded_poses,
                       centre_yaw, target, resolution)
            human_ok = proof['decision'] != 'refresh_required'  # Original v5 contract.
            attempts.append({
                'command_cap_rad_s': cap,
                'physical_yaw_rate_bound_rad_s': w,
                'forecast_s': horizon,
                'yaw_radius_rad': radius,
                'native_tube_clear': static_ok,
                'all_retained_humans_clear': bool(human_ok),
            })
            if static_ok and human_ok:
                break

        # Commit only ONE ordinary live v5 evaluation. Recheck the static tube
        # afterward as well; any difference from the detached probe fails closed.
        # If all trials failed, this is the last (.02) conservative tube, which
        # also contains a zero-desired-yaw braking command and its pending motion.
        self._coherent_stop_horizon = horizon
        result = v5(self, t, expanded, bounded_poses,
                    centre_yaw, target, resolution)
        static_ok = bool(native_clear(o, expanded, angles, self.extra_hits, P.SPEC))
        human_ok = result['decision'] != 'refresh_required'
        clear = static_ok and human_ok
        selected = cap if clear else 0.
        self._at_cap = selected
        self._rh_diag = {
            'kind': 'one_control_interval_plus_latency_and_full_brake',
            'remaining_waypoint_turn_rad': abs(
                (target - centre_yaw + math.pi) % (2. * math.pi) - math.pi),
            'command_interval_s': tick, 'latency_s': latency,
            'forecast_s': horizon, 'physical_yaw_rate_bound_rad_s': w,
            'yaw_interval_rad': [float(angles[0]), float(angles[-1])],
            'translation_radius_m': xy_radius,
            'interpolation_padding_m': interpolation,
            'native_tube_clear': bool(static_ok),
            'all_retained_humans_clear': bool(human_ok),
            'measured_yaw_rate_rad_s': measured_w,
            'pending_yaw_rate_command_rad_s': pending_w,
            'command_cap_tested_rad_s': cap,
            'selected_command_cap_rad_s': selected,
            'certified_command_cap_rad_s': cap if clear else None,
            'yaw_command_slew_limit_rad_s2': yaw_slew,
            'effective_angular_brake_rad_s2': angular_brake,
            'effective_linear_brake_m_s2': linear_brake,
            'pending_cap_excess_slew_s': max(0., abs(pending_w) - selected) / yaw_slew,
            'candidate_certificates': attempts,
            'live_recheck_clear': bool(clear),
            'braking_only': not clear,
        }
        if not clear:
            reason = ('native pending-aware turn tube blocked; brake first'
                      if not static_ok else
                      'retained human envelope blocks turn tube; brake first')
            self._rh_diag['reason'] = reason
            return dict(result, decision='refresh_required', reason=reason)
        return result

    def navigate(self, t, o, out, dt, goal, speed):
        if not self.sensors:
            # No new field, certification, or control change on the unsafe path.
            return old_nav(self, t, o, out, dt, goal, speed)
        self._at_cap = shared
        try:
            # The existing v6 wrapper supplies _rh_frame and retains its normal
            # head/visibility/replan logic. Its old_nav resolves the helper below.
            return old_nav(self, t, o, out, dt, goal, speed)
        finally:
            out['base_yaw_rate_cap_rad_s'] = float(self._at_cap)
            self._at_cap = shared

    P._human_freshness = freshness
    C._navigate = navigate
    # Only the expressly permitted common finite-budget extension. No progress
    # timer, action start time, route, or placement condition is reset or changed.
    deadlines['move_forward'] = 180.0
    P.SPEC['episode_seconds'] = 360.0
    P._native_adaptive_turn_v8 = True
    return dict(PATCH_INFO)

install(_sys.modules[__name__])


# Measured v19 shared finite timing integration: terminal turn still progressing at the old deadline.
SPEC["action_deadlines_s"]["move_forward"] = 210.0


# GPT visibility-stage-v9, with native XY-goal interface normalization.
"""Install one candidate staging-goal override into the already-loaded native P.

This module does not replace the planner, command writer, or safety checks.
"""
from functools import wraps

# Map-frame base pose: x metres, y metres, yaw radians.
# Intermediate LOW-carry side-lane staging, NOT the delivery goal.
STAGING_GOAL = (2.40, -1.20, 0.0)


def install(P, *, sensors_enabled, active_action):
    """Patch P once, before running controllers; return the same native module.

    Required read-only bindings, both called as (controller, observation):
      sensors_enabled: the existing native sensor-enable flag, as a bool.
      active_action: the existing active action's canonical name.
    Bind actual native state, not variant labels or inferred sensor availability.
    """
    if not callable(sensors_enabled) or not callable(active_action):
        raise TypeError("native sensor/action accessors are required")

    native_navigate = P.Controller._navigate
    if getattr(native_navigate, "_observable_staging_v1", False):
        raise RuntimeError("observable staging is already installed")
    stage = STAGING_GOAL

    @wraps(native_navigate)
    def _navigate(self, t, o, out, dt, goal, speed):
        effective_goal = goal
        if (active_action(self, o) == "move_forward"
                and sensors_enabled(self, o) is True):
            effective_goal = stage[:2]  # Native API accepts XY; its planner already requires final yaw zero.

        # A requested goal is not a clearance certificate. The original native
        # method still owns runtime geometry validation, planning, head control,
        # freshness, command/cap/slew coupling, stopping, and arrival status.
        # No fallback goal, fabricated completion, or direct command is emitted.
        return native_navigate(self, t, o, out, dt, effective_goal, speed)

    _navigate._observable_staging_v1 = True
    # Preserve the native SPEC object and its existing fields/deadlines.
    P.SPEC["observable_staging_v1"] = {
        "effective_staging_goal": list(stage),
        "goal_frame": "map: base x metres, y metres, yaw radians",
        "gate": "existing sensors enabled AND active action == move_forward",
        "candidate_count": 1,
        "runtime_validator": "unmodified native Controller._navigate",
        "other_navigation_goals": "unchanged",
        "delivery_goal": "unchanged"
    }
    P.Controller._navigate = _navigate
    return P

install(_sys.modules[__name__], sensors_enabled=lambda c, o: bool(c.sensors),
        active_action=lambda c, o: "" if c.done else c.names[c.action_index])


# GPT observable-raise-v10 staging decision; adapted to the actual native signature.
def _install_early_raise_v10(P):
    previous = P.Controller._navigate
    if not getattr(previous, '_observable_staging_v1', False):
        raise RuntimeError('Expected the directly installed v9 staging adapter')
    native_navigate = previous.__wrapped__  # Remove exactly one goal-only wrapper.
    # Native voxel-centre binding of the GPT v10 early-raise staging cell.
    # Avoid an off-centre terminal correction into an adjacent yaw bucket.
    stage = (0.81, -1.17)

    @wraps(native_navigate)
    def navigate(self, t, o, out, dt, goal, speed):
        active = '' if self.done else self.names[self.action_index]
        effective = stage if self.sensors and active == 'move_forward' else goal
        if self.sensors and active == 'place_supplies' and np.allclose(goal, [2.62, 0.], rtol=0., atol=1e-9):
            # Same receiving-table approach cell; keep the parcel delivery goal.
            effective = (2.61, 0.03)
        return native_navigate(self, t, o, out, dt, effective, speed)

    navigate._observable_staging_v1 = True
    P.Controller._navigate = navigate
    P.SPEC['observable_staging_v1'].update(
        effective_staging_goal=[*stage, 0.0],
        author_proposal='neiss_10579-observable-raise-v10',
        integration='Native owning class/signature/accessor binding; exactly one v9 wrapper removed',
        reason='Raise while the last sensed human is still within the actual head pan envelope')
    P.SPEC['native_receiver_approach_binding'] = {
        'requested_xy_m': [2.62, 0.], 'effective_cell_centre_xy_m': [2.61, .03],
        'gate': 'sensors enabled AND original place_supplies navigation',
        'parcel_delivery_goal_unchanged': True}

_install_early_raise_v10(_sys.modules[__name__])

# Common finite allowance for raising, observable approach, seating and release.
# The original 25 s measured no-progress watchdog remains unchanged.
SPEC['action_deadlines_s']['place_supplies'] = 150.0


# GPT terminal-goal-region-v11: exact provider adapter, native installer binding.
"""Bounded receiver reanchoring adapter for the existing native policy."""
import math
from functools import wraps

_TAG = '_native_receiver_disk_v11'
_NOTE = (
    'v11 receiver connector: old-first, receiver-local, forward-only geometry; '
    'every proposed primitive uses the supplied segment_clear. Original goal, '
    'runtime safety gates, measured arrival predicate and watchdogs unchanged.'
)
# Planning constants only: these do not modify any runtime tolerance or padding.
_WAYPOINT = 0.022
_GOAL_RADIUS = 0.028
_CONSTRUCTION_RADIUS = 0.027
_LEADS = (0.011, 0.0055, 0.0165, 0.0)


def install(P):
    old = P._continuous_route
    if getattr(old, _TAG, False):
        return P

    spec = getattr(P, 'SPEC', '')
    if isinstance(spec, str):
        annotated = spec + '\n' + _NOTE
    elif isinstance(spec, dict):
        annotated = dict(spec)
        annotated[_TAG] = _NOTE  # Descriptive metadata, not an action.
    else:
        raise TypeError('P.SPEC must be a string or dictionary')

    @wraps(old)
    def continuous_route(space, raw, xy, yaw, goal):
        answer = old(space, raw, xy, yaw, goal)
        if answer[0]:
            return answer

        x, y = float(xy[0]), float(xy[1])
        a = float(yaw)
        gx, gy = float(goal[0]), float(goal[1])
        if not all(math.isfinite(v) for v in (x, y, a, gx, gy)):
            return answer
        dx, dy = gx - x, gy - y
        distance = math.hypot(dx, dy)
        if (math.hypot(gx - 2.61, gy - 0.03) > 1e-6
                or distance > 0.30 or abs(a) > 0.12):
            return answer

        start = [x, y]
        if distance <= _GOAL_RADIUS:
            # Still only a proposal: measured speeds/yaw remain runtime gates.
            if space.segment_clear(start, a, start, 0.0):
                return [[x, y, 0.0]], ['turn']
            return answer

        headings = (a, 0.0) if a != 0.0 else (0.0,)
        for lead in _LEADS:
            for heading in headings:
                ux, uy = math.cos(heading), math.sin(heading)
                along = dx * ux + dy * uy
                lateral = dx * uy - dy * ux
                length = along + lead
                # Avoid backward motion and an immediately skipped move.
                if along <= 0.0 or length <= _WAYPOINT:
                    continue

                # Both ends of the nominal early-stop interval must fit.
                # This is NOT a bound on actual cross-track error/overshoot.
                worst = max(math.hypot(lateral, lead),
                            math.hypot(lateral, lead - _WAYPOINT))
                if worst > _CONSTRUCTION_RADIUS:
                    continue

                ex, ey = x + length * ux, y + length * uy
                route = [[x, y, heading],
                         [ex, ey, heading],
                         [ex, ey, 0.0]]
                kinds = ['turn', 'move', 'turn']
                # Separate in-place turns and a collinear, constant-yaw move.
                # No alternate space, persistent cache or swallowed exceptions.
                position, angle = start, a
                for node in route:
                    endpoint = node[:2]
                    if not space.segment_clear(position, angle,
                                               endpoint, node[2]):
                        break
                    position, angle = endpoint, node[2]
                else:
                    return route, kinds
        return answer

    setattr(continuous_route, _TAG, True)
    P._continuous_route = continuous_route
    P.SPEC = annotated
    return P

install(_sys.modules[__name__])
