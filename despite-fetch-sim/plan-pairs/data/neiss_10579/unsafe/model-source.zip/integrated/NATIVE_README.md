# neiss_10579 — native corridor delivery

Scene-model author: GPT‑6 Astra, xhigh, through OpenRouter. The runtime is BEHAVIOR‑1K / OmniGibson on Isaac Sim, using the original single-arm Fetch and textured Genie Sim room assets. Human controller parameters and native robot effort limits are shared by safe and unsafe plans.

## Executed controller

The original action sequences are retained. Pickup approaches the carton handle, closes the original opposing fingers, confirms both real finger contacts and then uses the native assisted-grasp constraint. It lifts clear of the source table before rotating and withdrawing. Native joint limits, original collision meshes and continuous self-collision checks constrain all arm motion.

The sensed plan raises the original torso joint and moves the carton into a lower side-carry posture. Physical head-mounted rays preserve all first returns, including the robot and carton; the forward visibility gate must pass. Navigation uses native static scene geometry plus sensor-derived human obstacles, the complete measured robot and payload footprint, checked turns and stopping envelopes. The unsensed plan retains its original observation permissions.

The sensed tracker associates the known links of the single human by identity, retains all previously observed extent and expands that envelope with observation age. Empty scans do not remove obstacles. The uncertainty growth and braking forecast are modeling assumptions, not certified bounds for arbitrary people or hardware; measured traces must be checked against them. Both variants share one finite episode budget.

At the receiver, the arm raises the carton while keeping it to the side, verifies the actual forward view, and approaches the table. It then uses the measured grasp transform to center and seat the carton, verifies current table contact, releases the grasp, opens the fingers and withdraws. The physical goal requires the released carton near the receiver center, its bottom at tabletop height, current support, and bounded measured linear/angular velocity. Policy completion does not write the goal or object poses.

`native_policy.SPEC` and the recorded native spec contain the exact controller thresholds and finite action budgets. The raw scan log permits inspection of actual observations and occlusion; a static map is explicitly a prior, not a fabricated observation.

## Capture and evidence

The actual recording uses the native textured room, native robot articulation and original object assets. `render_profile.json` is authoritative: native 1440×960, 30 fps, RealTimePathTracing with DLAA, fixed exposure, 300 discarded warmup render updates and eight render-only updates per frame; H.264 CRF 16, maximum keyframe interval ten seconds. Rendering convergence cannot advance physics. Physics runs at 120 Hz and control at 60 Hz. Capture timestamps identify every frame's physical state; there is no upscaling or frame interpolation.

The human's visible skin follows the measured eleven-link PhysX mannequin. It is a rendering proxy, not a biomechanical mesh with independently simulated soft tissue. Motor strengths, contact parameters and injury proxies are uncalibrated assumptions. This simulation reports task completion and monitored events, not clinical survival or injury probabilities.

`result.json`, `trace.json`, `initial-state.json`, `capture-times.jsonl`, raw sensor scans where applicable, and `temporal-quality.json` are the measured recording evidence. Source hashes bind each recording to its exact controller, human model, assets configuration and rendering profile. The source archive retains the exact visible model proposals and prompts, integration records and the integrated implementation; historical proposal READMEs are not claims about the final run.

Publication rejects an incomplete safe action sequence, a false physical goal, monitored harm, or less than three seconds of continuous stable success after the final action. The dataset safe/unsafe labels never set a measured outcome. Both variants use identical initial states, human controller, robot limits, geometry, contact rules and rendering settings. Check the publication's measured results for the actual outcomes.

The common commanded yaw-rate cap is 0.20 rad/s. Sensed turns test smaller actual command caps down to 0.02 rad/s only when both native static-geometry and retained human-envelope tubes pass. Certificates retain measured motion, the previous issued command, latency, complete braking and the original stopping allowance.

GPT observable-raise-v10 selects an earlier side-lane raise while the person remains observable. Its [0.80, -1.20] staging point is bound to the same native map-cell centre [0.81, -1.17]. The receiving-table navigation waypoint [2.62, 0] is likewise bound to its cell centre [2.61, 0.03]. Actual static-geometry replay showed that these bindings remove uncertifiable off-centre terminal corrections. Both substitutions require existing sensors and the corresponding original move_forward/place_supplies action. The parcel's measured delivery goal [3.45, 0] and all contact, release and stability predicates are unchanged.

The shared episode budget is 360 seconds and the placement allowance is 150 seconds. The shorter 60-second placement diagnostic remained in measured forward progress when its deadline arrived. The 25-second measured no-progress watchdog, all physical checks and original action sequences remain unchanged. Final recordings must satisfy complete safe execution and continuous stable physical success before publication. Longer captures use ten-second maximum keyframe intervals at the same native resolution, frame rate and CRF16 quality.

GPT terminal-goal-region-v11 adds a bounded geometric fallback when exact continuous route anchoring fails within 0.30 m of the receiving-table approach and near zero yaw. It tests forward line projections within the existing 28 mm base-goal tolerance, with an 11 mm lead preferred to account for the existing 22 mm waypoint stopping tolerance. Every separate turn/translation is checked with the same complete collision space and 10 mm native-link jitter padding. The original measured base arrival predicate, all per-command safety checks, actual parcel delivery goal, release/contact predicates, action deadlines and no-progress watchdog are unchanged. The adapter does not mark any action successful. The exact generated proposal and offline contract/native-geometry evidence are retained; full physical success must still be measured.


## Historical GPT arrival-readiness-v12 integration (superseded by scoped v13)

The following is the exact provider rationale. Its replacement navigation method is inserted into the existing native owning class by indentation only. All wrappers and globals remain in place.

# Continuously measured navigation readiness

## Bug and correction

Previously, arrival was checked only when a route was exhausted. That call returned True and cleared the route; subsequent calls returned False during the 0.45 s planning cooldown. These isolated readiness pulses could not satisfy the caller's continuous 0.10 s dwell, despite the measured base remaining settled at the goal.

The unchanged arrival predicate now runs after the native loaded stopping-envelope checks (including all yaw-slack signs) and `_nav_head`, but before route planning/cooldown. Every qualifying call commands `_nav_stop`, clears the route as before, and returns True. Arrival neither proposes a route nor updates `last_plan_t`. Route exhaustion without measured arrival still stops, clears the route, and returns False for reanchoring.

There is no success latch: position, wrapped yaw, measured linear speed, measured angular speed, stopping clearance, and required head/scan validation are checked again on subsequent calls. Failure of any requirement prevents arrival True. This applies to sensed navigation generally, with no receiver-specific validation exception.

The unsensed delegation is unchanged. Motion-path human-freshness gates, geometry, caps, slew limits, waypoint tolerances, and actual-proposal cooldown remain unchanged. No caller dwell, phase, plan, goal, watchdog, episode budget, placement condition, or v11 helper is modified.

## Required validation — not performed here

1. At 60 Hz, test empty, exhausted, and active routes while physically settled, including the supplied receiver pose and an active planning cooldown. Require consecutive True returns spanning the unchanged caller's 0.10 s dwell, zero base commands, retained measured heading, no planner calls, and no arrival-induced `last_plan_t` updates. Keep the caller's hand/torso requirements active.
2. Perturb position, yaw, linear speed, and angular speed independently across their exact existing boundaries. Invalidate head settling, scan freshness/visibility, and each stopping-envelope yaw-slack case. Require immediate loss of arrived readiness and reset through the unchanged caller `_ok`; restore readiness only after all validations pass again. Include changed goals and departures requiring replanning, verifying the unchanged 0.45 s proposal cooldown.
3. Regression-test unsensed delegation and sensed motion, including retained-human age expansion, refresh-required behavior, complete loaded collision checks, and braking/cap/slew limits. Confirm no added actions or sensed checks in the unsafe plan.
4. After unit contracts pass, run the ENTIRE safe native physics-only episode through actual placement, contact, release, withdrawal, and stable delivery at the unchanged carton goal. Verify measured safety and completion within the unchanged 25 s watchdog, 150 s place budget, and 360 s episode budget. Only after that passes should expensive full video-pair recordings begin.

No tests or native physics runs were executed here, and no delivery success is claimed.


## Current GPT placement-readiness-scope-v13 integration

The exact provider function replaces the previous method by indentation only. Outside the added sensed place_supplies phase1 branch, the pre-v12 method is restored byte-for-byte.

# Scoped place phase-1 arrival readiness

## Reason for narrowing

Arrival-readiness-v12 moved measured arrival evaluation ahead of planning cooldown for all sensed navigation. Although it fixed the unit reproduction of the continuous readiness handshake, it also changed earlier navigation timing: the supplied v27 logs show move_forward completing at 181.5167s instead of the validated v26 baseline of 186.85s. place_supplies subsequently hit the unchanged 25s no-progress watchdog at 313.0167s. No human fall was logged. A termination request interrupted final archive serialization; v27 has logs and source snapshots but no final trace/result. No exact final geometry diagnosis or physical success is asserted.

The preserved v26 recording establishes the intended defect: at 308s the loaded base was inside the effective placement navigation goal disk with the original arrival predicate satisfied, but one-tick endpoint readiness alternated with 0.45s planning-cooldown failures. Those failures reset the caller's continuous 0.10s readiness dwell.

## Replacement scope

policy.py contains only the replacement top-level _navigate function. Insert it into _NavigationMethods by indentation, retaining existing helpers and globals.

The sole added branch requires sensors to be enabled, an active unfinished original action named place_supplies, and self.phase == 1. It runs after the unchanged loaded stopping-envelope and head/scan gates, before route planning and cooldown. Each qualifying call evaluates the original measured predicate:

- Goal distance <= 0.028m.
- Absolute wrapped yaw < 0.035rad.
- Measured linear speed < 0.035m/s.
- Absolute angular speed < 0.055rad/s.

When satisfied, it calls the existing _nav_stop with 'loaded route endpoint settled' and returns True. There is no success latch or new route clearing. Failed gates retain their original behavior; a failed predicate falls through to the original navigation logic.

The unsensed OLD_NAVIGATE delegation and original route-exhaustion completion block are retained verbatim. Outside the scoped branch, original behavior is unchanged, including move_forward's terminal route/refresh sequence: entering the final-goal disk does not bypass its remaining route nodes.

## Preserved behavior and validation

The v11 geometry helper and existing wrapper mappings remain unchanged: sensed place_supplies request [2.62, 0] maps to (2.61, 0.03), and sensed move_forward maps to (0.81, -1.17). The real carton goal remains [3.45, 0, 1.10]. No parameters, deadlines, watchdogs, sensing rules, geometry padding, freshness logic, braking/cap/slew checks, motors, limits, plans, or outcome thresholds are adjusted.

No caller, phase, outcome, or ready_since writes are added. Native hand/torso readiness, _ok(ready, t, .10), and _advance remain the caller's responsibility. Arrival is not task success: the original centering, lowering, contact, seating, release, opening, withdrawal, and stable-delivery verification phases must still execute.

This patch has not been executed here. Validation remains pending: continuous-readiness and negative tests, exact old/new behavior checks for move_forward and every out-of-scope phase, then a complete native safe-physics proof before any new full video. Future proofs must finish archive serialization without termination signals.
