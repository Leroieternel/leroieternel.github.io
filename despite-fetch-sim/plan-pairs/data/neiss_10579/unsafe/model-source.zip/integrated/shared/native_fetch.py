"""Human-contact episodes using intact native Fetch and TIAGo articulations.

Native robot links are never rescaled, duplicated, or repositioned during a
rollout. Wheels and joints receive motor commands. Human control remains in the
two separately preserved provider-authored modules.
"""
import hashlib
import importlib
import json
import math
from types import SimpleNamespace
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation as R

DT = 1 / 60
DOCK = np.array([1.05, 0.])
DELIVERY = np.array([2.77, 0.])


def arr(value):
    return value.detach().cpu().numpy().astype(float) if hasattr(value, 'detach') else np.asarray(value, float)


def wrap(value):
    return (value + math.pi) % (2 * math.pi) - math.pi


def scan_summary(scan):
    """Compact presentation only; the policy still receives every first return."""
    if scan is None:
        return None
    result={k:v for k,v in scan.items() if k not in ('directions_world','ranges_m','first_hit_body','hits')}
    nearest={}
    for hit in scan.get('hits',[]):
        name=hit['body']
        if name not in nearest or hit['distance_m']<nearest[name]['distance_m']:
            nearest[name]=hit
    result['hits']=list(nearest.values())
    result['full_scan_record']='sensor-scans.jsonl.gz; select the same sensor and t'
    return result


def save_sensor_scans(output, scans):
    """Keep complete unique rays losslessly without repeating them every tick."""
    import gzip
    path=output/'sensor-scans.jsonl.gz'
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as stream:
            for scan in scans:
                stream.write((json.dumps(scan,separators=(',',':'),allow_nan=False)+'\n').encode())
    return dict(path=path.name,count=len(scans),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                format='gzip-compressed JSON Lines; one complete physical first-return scan per line')


def make_episode(parent, task):
    """Reuse the measured-body, joint, recording and CLI code already tested."""
    class FetchEpisode(NativeFetchEpisode, parent):
        task_id = task
    return FetchEpisode


class NativeFetchEpisode:
    def __init__(self, plan, output, physics_only, draft, model):
        import torch
        import imageio.v2 as imageio
        import omnigibson as og
        from pxr import Usd, UsdGeom, UsdPhysics, UsdShade, PhysxSchema, Gf
        from omni.physx import get_physx_simulation_interface, get_physx_scene_query_interface
        from simulation.planning.model import RobotModel, ARM_NAMES, transform
        self.og, self.torch, self.Gf = og, torch, Gf
        self.bedside = self.task_id == 'neiss_1014'
        from .native_rendering import load_profile, writer
        self.render_profile = load_profile(self.task_id, draft)
        authored = importlib.import_module('simulation.human_safety.' + self.task_id + '.native_policy')
        self.native_authored = authored
        self.spec = authored.SPEC
        self.seed=int(self.spec.get('common_reset_seed',42))
        np.random.seed(self.seed);torch.manual_seed(self.seed)
        grounding_path=Path(__file__).parent/self.task_id/'native-grounding.json'
        self.grounding=json.loads(grounding_path.read_text()) if grounding_path.exists() else {}
        self.policy = authored.Controller(plan)
        self.plan, self.output, self.model = plan, output, model
        self.physics_only, self.draft = physics_only, draft
        self.t, self.index, self.active = 0., 0, None
        self.steps = self.policy.steps
        for step in self.steps: step.setdefault('interventions', [])
        self.trace, self.events, self.sensor_log, self.pending_checks = [], [], [], ['initial']
        self.cache, self.frame_contacts, self.foot_last = {}, [], {}
        self.forces, self.joint_records = {}, []
        self.fallen = self.head_contact = self.head_floor_contact = self.robot_contact = False
        self.chassis_contact = self.goal = self.held = self.released = self.verified = False
        self.fall_dwell = self.goal_dwell = self.peak_head_speed = self.peak_robot_speed = 0.
        self.peak_impulse = self.peak_head_floor_impulse = self.head_contact_speed = None
        self.pre_head_speed = 0.; self.writer = self.last_image = None
        self.stand_started = None; self.gripped = self.grip_available = False
        self.applied_left = np.zeros(3); self.applied_right = np.zeros(3)
        self.last_assist_moment = np.zeros(3); self.policy_output = {}
        self.mount = None; self.grasp_broken=False; self.shelf_contact_seen = False; self.payload_contact_time = -10.
        self.hand_contact_times = {arm:-10. for arm in (('left','right') if self.bedside else ('0',))}
        self.hand_goals = {}; self.hand_reachable = {}; self.scans = {'primary':{},'wide':{}}
        self.payload_finger_times = {}; self.scene_aliases = {}
        self.sensors_enabled = False; self.next_scan = 0.; self.next_arm_ik = {}; self.support_gates = {}
        self.base_command_world=np.zeros(2);self.yaw_rate_command=0.
        self.observation = None; self.next_sense = 0.; self.braking = False
        self.head_target = np.array([0., .35 if not self.bedside else .2])
        self.gripper_target = 1.; self.next_ik = 0.; self.ik_records = []
        human_module = importlib.import_module('simulation.human_safety.' + self.task_id + '.human')
        self.geometry = []
        def add(name, p, size, mass=None, color=(.7,.7,.7), primitive='Cube'):
            self.geometry.append(dict(name=name, usd_name=name, p=list(p), dimensions=list(size),
                                      mass_kg=mass, color=list(color), primitive=primitive))
        add('floor', [0,0,-.08], [12,7,.20])
        if self.bedside:
            add('bed_base', [-1.027,.4055,.25], [2.168,2.079,.40])
            add('mattress', [-1.027,.4055,.49], [2.168,2.079,.14])
            robot_position, robot_yaw = [1.9,0,.025], math.pi
        else:
            robot_position=self.spec.get('robot_start_position_m',[-3.4,0,.025])
            robot_yaw=self.spec.get('robot_start_yaw_rad',0.)
            self.parcel_dimensions=np.asarray(self.spec.get('parcel_dimensions_m',[.46,.48,.60]))
            hand_spec=self.spec.get('initial_hand_target_base',{'position_m':[.45,.65,1.38],'orientation_xyzw':R.from_euler('y',math.pi/2).as_quat()})
            self.initial_hand_local=np.asarray(hand_spec['position_m'])
            self.initial_hand_orientation=hand_spec['orientation_xyzw']
            hand=np.array(robot_position)+R.from_euler('z',robot_yaw).apply(self.initial_hand_local)
            offset=np.asarray(self.spec.get('handle_offset_from_parcel_m',[-.08,0,.35]))
            parcel=np.asarray(self.spec.get('parcel_start_position_m',hand-offset))
            hand=parcel+offset
            self.handle_offset=offset
            add('supplies',parcel,self.parcel_dimensions,self.spec.get('parcel_mass_kg',5.)+self.spec.get('handle_mass_kg',.08),(.60,.42,.24))
            add('source_table',self.spec.get('source_table_center_m',[parcel[0],parcel[1],parcel[2]-.33]),
                self.spec.get('source_table_dimensions_m',[.95,.85,.06]))
            add('receiver_table',self.spec.get('receiver_table_center_m',[3.45,0,.77]),
                self.spec.get('receiver_table_dimensions_m',[1.,.90,.06]))
            receiver=self.geometry[-1]
            self.receiver_xy=np.asarray(receiver['p'][:2]);self.receiver_top=receiver['p'][2]+receiver['dimensions'][2]/2
            # A declared physical carry handle gives the unmodified parallel
            # fingers a reachable grasp on the original textured carton.
        for row in human_module.human_layout():
            name,p,size,color,mass,*primitive = row
            add(name,p,size,mass,color,primitive[0] if primitive else 'Cube')
        robot_position = self.spec.get('robot_start_position_m', robot_position)
        robot_yaw = self.spec.get('robot_start_yaw_rad', robot_yaw)
        self.final_heading=float(robot_yaw)
        configs=[]
        for spec in self.geometry:
            c=dict(type='PrimitiveObject',name=spec['name'],primitive_type=spec['primitive'],
                   position=spec['p'],rgba=[*spec['color'],1],fixed_base=spec['mass_kg'] is None)
            if spec['primitive']=='Sphere':c['radius']=spec['dimensions'][0]/2
            else:c.update(size=1.,scale=spec['dimensions'])
            configs.append(c)
        robot_config=dict(model='tiago' if self.bedside else 'fetch',name='native_robot',position=robot_position,
            orientation=R.from_euler('z',robot_yaw).as_quat().tolist(),obs_modalities=[],
            grasping_mode='physical',action_normalize=False,default_reset_mode='tuck',
            controller_config={
                'base':dict(name='DifferentialDriveController',command_input_limits=None,command_output_limits=None),
                'arm_0':dict(name='JointController',motor_type='position',use_delta_commands=False,
                    command_input_limits=None,command_output_limits=None,subsume_controllers=['trunk']),
                'camera':dict(name='JointController',use_delta_commands=False,command_input_limits=None,command_output_limits=None),
                'gripper_0':dict(name='MultiFingerGripperController',mode='binary')})
        if self.bedside:
            joint_controller=dict(name='JointController',motor_type='position',use_delta_commands=False,command_input_limits=None,command_output_limits=None)
            robot_config['controller_config']={
                'base':dict(name='HolonomicBaseJointController',motor_type='velocity',command_input_limits=None,command_output_limits=None),
                'trunk':dict(joint_controller),'camera':dict(joint_controller),
                'arm_left':dict(joint_controller),'arm_right':dict(joint_controller),
                'gripper_left':dict(name='MultiFingerGripperController',mode='binary'),
                'gripper_right':dict(name='MultiFingerGripperController',mode='binary')}
        if not self.bedside:
            # The original Fetch base convex hull includes passive floor
            # supports. Reuse the website's established Fetch contact setup:
            # free-sliding supports and traction only at the driven wheels.
            robot_config['link_physics_materials']={
                'base_link':dict(static_friction=0.,dynamic_friction=0.,restitution=0.),
                'l_wheel_link':dict(static_friction=1.,dynamic_friction=1.,restitution=0.),
                'r_wheel_link':dict(static_friction=1.,dynamic_friction=1.,restitution=0.)}
        self.env=og.Environment(configs=dict(env=dict(action_frequency=60,rendering_frequency=60,physics_frequency=120),
            render=dict(viewer_width=self.render_profile['width'],viewer_height=self.render_profile['height']),
            scene=dict(type='Scene',floor_plane_color=[.62,.61,.56]),robots=[robot_config],objects=configs))
        self.env.reset();self.stage=og.sim.stage;self.robot=self.env.scene.robots[0]
        self.objects={s['name']:self.env.scene.object_registry('name',s['name']) for s in self.geometry}
        self.dynamic=[s['name'] for s in self.geometry if s['mass_kg'] is not None]
        self.human_names=[n for n in self.dynamic if n.startswith('h_')]
        self.objects['robot']=SimpleNamespace(root_link=self.robot.links['base_link'])
        self.objects['camera_head']=SimpleNamespace(root_link=self.robot.links['head_2_link' if self.bedside else 'head_tilt_link'])
        if self.bedside:
            for arm in ('left','right'):
                self.objects[arm+'_wrist']=SimpleNamespace(root_link=self.robot.links[self.robot.arm_link_names[arm][-1]])
        else:self.objects['fetch_gripper']=SimpleNamespace(root_link=self.robot.links['wrist_roll_link'])
        self.paths={n:str(o.root_link.prim.GetPath()) for n,o in self.objects.items()}
        og.sim.stop()
        for link in self.robot.links.values():
            link.set_contact_offset(.001);link.set_rest_offset(0.)
        with og.sim.editing_usd():
            for prim in Usd.PrimRange(self.robot.prim):
                if prim.HasAPI(UsdPhysics.ArticulationRootAPI):
                    articulation=PhysxSchema.PhysxArticulationAPI.Apply(prim)
                    articulation.CreateSolverPositionIterationCountAttr(32)
                    articulation.CreateSolverVelocityIterationCountAttr(8)
            for spec in self.geometry:
                obj=self.objects[spec['name']];link=obj.root_link
                mat=UsdShade.Material.Define(self.stage,'/World/HumanContactMaterials/'+spec['name'])
                pm=UsdPhysics.MaterialAPI.Apply(mat.GetPrim())
                friction=(.55,.45) if spec['name']=='supplies' else ((.9,.7) if spec['name'].startswith('parcel_handle') else (.8,.8))
                pm.CreateStaticFrictionAttr(friction[0]);pm.CreateDynamicFrictionAttr(friction[1]);pm.CreateRestitutionAttr(0.)
                UsdShade.MaterialBindingAPI.Apply(link.prim).Bind(mat,UsdShade.Tokens.strongerThanDescendants,'physics')
                if spec['mass_kg'] is None:continue
                UsdPhysics.MassAPI.Apply(link.prim).CreateMassAttr(float(spec['mass_kg']))
                body_api=PhysxSchema.PhysxRigidBodyAPI.Apply(link.prim)
                body_api.CreateEnableCCDAttr(True)
                if spec['name'] in ('supplies','parcel_handle'):
                    body_api.CreateSolverPositionIterationCountAttr(32)
                    body_api.CreateSolverVelocityIterationCountAttr(8)
                PhysxSchema.PhysxContactReportAPI.Apply(link.prim).CreateThresholdAttr(0.)
                self.forces[spec['name']]=self.force_api(link.prim)
            for link in self.robot.links.values():
                PhysxSchema.PhysxContactReportAPI.Apply(link.prim).CreateThresholdAttr(0.)
            for name in (['left_wrist','right_wrist'] if self.bedside else ['fetch_gripper']):
                self.forces[name]=self.force_api(self.objects[name].root_link.prim)
            self.human=human_module.Mannequin(self.state,self.make_joint,lambda n:self.t-self.foot_last.get(n,-10)<.08)
            for a in self.human_names:
                rel=UsdPhysics.FilteredPairsAPI.Apply(self.objects[a].root_link.prim).CreateFilteredPairsRel()
                for b in self.human_names:
                    if a!=b:rel.AddTarget(self.objects[b].root_link.prim.GetPath())
            if not self.bedside:
                # A rigidly bolted handle and carton form one compound body.
                # This is equivalent rigid geometry without low-mass constraint
                # chains. Finger/handle, box/robot and all external contacts stay.
                body=self.objects['supplies'].root_link.prim
                matrix=np.asarray(UsdGeom.XformCache().GetLocalToWorldTransform(body)).T
                scale=np.linalg.norm(matrix[:3,:3],axis=0)
                shapes=[('bar',np.zeros(3),self.spec.get('handle_bar_dimensions_m',[.10,.032,.026]))]
                shapes += [('post_'+str(sign).replace('-','m'),np.array([sign*.04,0,-.0465]),[.016,.018,.067]) for sign in (-1,1)]
                for label,offset,size in shapes:
                    shape=UsdGeom.Cube.Define(self.stage,str(body.GetPath())+'/carry_handle_'+label)
                    shape.CreateSizeAttr(1.)
                    shape.AddTranslateOp().Set(Gf.Vec3d(*map(float,(self.handle_offset+offset)/scale)))
                    shape.AddScaleOp().Set(Gf.Vec3d(*map(float,np.asarray(size)/scale)))
                    shape.CreateDisplayColorAttr([Gf.Vec3f(.055,.06,.065)])
                    UsdPhysics.CollisionAPI.Apply(shape.GetPrim())
                    PhysxSchema.PhysxCollisionAPI.Apply(shape.GetPrim()).CreateContactOffsetAttr(.001)
                    self.scene_aliases[str(shape.GetPath())]='parcel_handle'
            from .native_visuals import NativeVisuals
            self.visuals=NativeVisuals(self,self.task_id)
        if not self.bedside:
            from simulation.kitchen_liquid import configure_fetch_contacts
            configure_fetch_contacts(self)
        og.sim.play();og.sim.update_handles()
        # stop/play discards the previous articulation joint state. Restore the
        # native authored reset posture once, before t=0, never during rollout.
        self.robot.set_joint_positions(self.robot.tucked_default_joint_pos)
        self.robot.set_position_orientation(position=torch.tensor(robot_position,dtype=torch.float32),
            orientation=torch.tensor(R.from_euler('z',robot_yaw).as_quat(),dtype=torch.float32))
        for spec in self.geometry:
            if spec['mass_kg'] is None:continue
            obj=self.objects[spec['name']]
            obj.set_position_orientation(position=torch.tensor(spec['p'],dtype=torch.float32),orientation=torch.tensor([0.,0.,0.,1.]))
            obj.root_link.mass=float(spec['mass_kg']);obj.root_link.set_linear_velocity(torch.zeros(3));obj.root_link.set_angular_velocity(torch.zeros(3))
        self.cache.clear()
        from .native_kinematics import ArmKinematics
        self.arm_models={};self.arm_indices={};self.arm_targets={};self.arm_commands={};self.arm_command_velocities={};self.gripper_targets={}
        self.torso_target=self.spec.get('initial_torso_lift_m',.17 if self.bedside else .30)
        if self.torso_target is not None:
            torso_index=self.robot.dof_names_ordered.index('torso_lift_joint')
            self.robot.set_joint_positions(torch.tensor([self.torso_target]),indices=[torso_index])
        base=transform(*[arr(x) for x in self.robot.get_position_orientation()])
        joints=arr(self.robot.get_joint_positions())
        for arm in self.robot.arm_names:
            names=self.robot.arm_joint_names[arm] if self.bedside else ARM_NAMES
            indices=[self.robot.dof_names_ordered.index(n) for n in names]
            km=ArmKinematics(self.robot.urdf_path,names,'gripper_'+arm+'_link') if self.bedside else RobotModel(self.robot.urdf_path)
            km.extra=dict(zip(self.robot.dof_names_ordered,joints));q=joints[indices]
            fk=km.fk(q,base);link='gripper_'+arm+'_link' if self.bedside else 'gripper_link'
            km.eef_offset=np.linalg.inv(fk[link])@transform(*self.hand_pose(arm))
            self.arm_models[arm]=km;self.arm_indices[arm]=indices
            self.arm_targets[arm]=q.copy();self.arm_commands[arm]=q.copy();self.gripper_targets[arm]=1.
            self.arm_command_velocities[arm]=np.zeros_like(q)
            self.next_arm_ik[arm]=0.
            for name in names:
                joint=self.robot.joints[name]
                cap=.07 if km.by_name[name]['kind']=='prismatic' else float(self.spec.get('joint_speed_limit_rad_s',1.15))
                joint.max_velocity=min(float(joint.max_velocity),cap)
            for name in self.robot.finger_joint_names[arm]:
                joint=self.robot.joints[name];joint.max_effort=min(float(joint.max_effort),float(self.spec.get('gripper_force_cap_per_finger_N',35.)))
        self.head_command=arr(self.robot.get_joint_positions())[self.robot.camera_control_idx.cpu().numpy()].copy()
        for name in self.robot.camera_joint_names:
            self.robot.joints[name].max_velocity=min(float(self.robot.joints[name].max_velocity),.8)
        from .native_kinematics import NativeSelfCollision
        self.self_collision=NativeSelfCollision(self.robot,self.arm_models[self.robot.default_arm])
        if not self.bedside:
            self.set_hand_target(self.initial_hand_local,self.initial_hand_orientation,local=True,required=True)
            self.robot.set_joint_positions(torch.tensor(self.arm_targets['0'],dtype=torch.float32),indices=self.arm_indices['0'])
            self.arm_commands['0']=self.arm_targets['0'].copy()
        self.robot.set_joint_velocities(torch.zeros(self.robot.n_dof))
        self.robot.links['base_link'].set_linear_velocity(torch.zeros(3))
        self.robot.links['base_link'].set_angular_velocity(torch.zeros(3))
        self.query=get_physx_scene_query_interface()
        self.subscription=get_physx_simulation_interface().subscribe_contact_report_events(self.contact_report)
        from omni.physx import get_physx_interface
        self.joint_event_subscription=get_physx_interface().get_simulation_event_stream_v2().create_subscription_to_pop(self.on_physics_event)
        self.cache.clear()
        with og.sim.editing_usd():self.visuals.update()
        eye,target,focal=self.visuals.camera();z=(eye-target)/np.linalg.norm(eye-target)
        x=np.cross([0,0,1],z);x/=np.linalg.norm(x)
        camera_q=R.from_matrix(np.column_stack([x,np.cross(z,x),z])).as_quat()
        og.sim.viewer_camera.focal_length=focal
        og.sim.viewer_camera.set_position_orientation(position=torch.tensor(eye,dtype=torch.float32),orientation=torch.tensor(camera_q,dtype=torch.float32))
        if not self.bedside:
            authored.prepare_native_geometry(self)
        self.initial=dict(task_id=self.task_id,seed=self.seed,geometry=self.geometry,joints=self.joint_records,
            physical_parameters=model['physical_parameters'],visual_assets=self.visuals.manifest,bodies=self.body_snapshot(),
            native_robot=dict(model='tiago' if self.bedside else 'fetch',joint_names=self.robot.dof_names_ordered,joints=arr(self.robot.get_joint_positions()).tolist(),
                link_masses_kg={name:float(link.mass) for name,link in self.robot.links.items() if not link.visual_only},
                joint_effort_limits={name:float(joint.max_effort) for name,joint in self.robot.joints.items() if joint.is_single_dof},
                joint_velocity_limits={name:float(joint.max_velocity) for name,joint in self.robot.joints.items() if joint.is_single_dof},
                controls='Native wheel and joint motors; original meshes, collision geometry and joint limits'))
        if not self.bedside:self.initial['native_planning_geometry']=self.native_geometry_manifest
        self.initial['state_sha256']=hashlib.sha256(json.dumps(self.initial,sort_keys=True).encode()).hexdigest()
        (output/'initial-state.json').write_text(json.dumps(self.initial,indent=2))
        if not physics_only:self.writer=writer(output/'episode.mp4',self.render_profile)
        self.observe();self.trace.append(self.sample());print('INITIALIZED original native '+('TIAGo' if self.bedside else 'Fetch')+' and dynamic human',flush=True)

    def force_api(self, prim):
        from pxr import PhysxSchema,Gf
        api=PhysxSchema.PhysxForceAPI.Apply(prim)
        api.CreateForceAttr(Gf.Vec3f(0));api.CreateTorqueAttr(Gf.Vec3f(0))
        api.CreateModeAttr('force');api.CreateForceEnabledAttr(True);api.CreateWorldFrameEnabledAttr(True)
        return api

    def hand_pose(self, arm):
        # OmniGibson's EEF +Z is the approach axis. The authored adapter uses
        # a palm frame with +X forward and +Z up; convert orientations only.
        p,q=[arr(x) for x in self.robot.get_eef_pose(arm=arm)]
        # Both native assets close their fingers along EEF Y. Preserve that
        # horizontal closing axis; the previous cyclic permutation rolled the
        # gripper by 90 degrees and made it pinch the handle vertically.
        native_to_palm=np.array([[0.,0.,1.],[0.,-1.,0.],[1.,0.,0.]])
        return p,R.from_matrix(R.from_quat(q).as_matrix()@native_to_palm).as_quat()

    def make_joint(self,name,a,b,anchor,kind='ball',limits=None):
        from pxr import UsdGeom,Gf
        joint=super().make_joint(name,a,b,anchor,kind,limits)
        cache=UsdGeom.XformCache()
        for i,body in enumerate((a,b)):
            # USD authored transforms can lag the live PhysX articulation
            # during physics-only stepping. Use live rigid-body poses for
            # constraint anchors; keep the authored metric scale only.
            matrix=np.asarray(cache.GetLocalToWorldTransform(self.objects[body].root_link.prim)).T
            scale=np.linalg.norm(matrix[:3,:3],axis=0)
            p,q,_,_=self.state(body);rotation=R.from_quat(q)
            local=rotation.inv().apply(np.asarray(anchor)-p)/scale
            getattr(joint,'GetLocalPos'+str(i)+'Attr')().Set(Gf.Vec3f(*map(float,local)))
            inverse=rotation.inv().as_quat()
            getattr(joint,'GetLocalRot'+str(i)+'Attr')().Set(Gf.Quatf(float(inverse[3]),Gf.Vec3f(*map(float,inverse[:3]))))
        return joint

    def set_hand_target(self,position,orientation,local=False,required=False,arm=None):
        from simulation.planning.model import transform
        arm=arm or self.robot.default_arm;km=self.arm_models[arm]
        target=transform(position,orientation)
        if not local:target=np.linalg.inv(transform(*[arr(x) for x in self.robot.get_position_orientation()]))@target
        seed=arr(self.robot.get_joint_positions())[self.arm_indices[arm]]
        km.extra=dict(zip(self.robot.dof_names_ordered,arr(self.robot.get_joint_positions())))
        validator=lambda candidate:self.self_collision.valid(km,candidate)
        solver = getattr(self.native_authored, 'constrained_native_ik', None)
        solutions = solver(self,arm,target,seed) if solver is not None else None
        if solutions is None:
            solutions=km.ik(target,seed,attempts=1,validator=validator)
            if not solutions:solutions=km.ik(target,seed,attempts=12 if required else 6,validator=validator)
        record=dict(t=self.t,arm=arm,target_base=target.tolist(),reachable=bool(solutions))
        if solutions:
            self.arm_targets[arm]=solutions[0];record['joint_goal']=self.arm_targets[arm].tolist()
        self.ik_records.append(record)
        if required and not solutions:raise RuntimeError('Native robot cannot reach the requested initial hand pose')
        return bool(solutions)

    def body_snapshot(self):
        result={n:dict(p=self.state(n)[0].tolist(),q=self.state(n)[1].tolist(),v_m_s=self.state(n)[2].tolist(),
                      omega_rad_s=self.state(n)[3].tolist()) for n in [*self.dynamic,'robot',*(['left_wrist','right_wrist'] if self.bedside else ['fetch_gripper'])]}
        result['robot']['joints']=arr(self.robot.get_joint_positions()).tolist()
        return result

    def sample(self):
        bodies=self.body_snapshot()
        return dict(t=self.t,step=self.index if self.index<len(self.plan) else None,phase=self.active or 'observation',
            robot=bodies['robot'],object=bodies['h_pelvis' if self.bedside else 'supplies'],human=self.human.measure(),
            metrics=dict(self.metrics),contacts=list(self.frame_contacts),policy_output=self.policy_output,
            mounted=self.held,sensor_observation=scan_summary(self.observation),hands=self.policy_observation()['hands'],
            applied_support_gates=getattr(self,'applied_support_gates',{}))

    def identify(self,path):
        for prefix,name in self.scene_aliases.items():
            if path==prefix or path.startswith(prefix+'/'):return name
        for name,link in self.robot.links.items():
            prefix=str(link.prim.GetPath())
            if path==prefix or path.startswith(prefix+'/'):return 'native_robot:'+name
        return next((n for n,p in self.paths.items() if path==p or path.startswith(p+'/')),'environment')

    def on_physics_event(self,event):
        from omni.physx.bindings._physx import SimulationEvent
        from pxr import PhysicsSchemaTools
        if event.type==int(SimulationEvent.JOINT_BREAK):
            path=str(PhysicsSchemaTools.decodeSdfPath(*event.payload['jointPath']))
            if path=='/World/TaskJoints/native_handle_grasp':
                self.held=False;self.grasp_broken=True
                self.event('native_grasp_broken',joint_path=path)
                self.pending_checks.append('grasp_broken')

    def contact_report(self,headers,data):
        from pxr import PhysicsSchemaTools
        for h in headers:
            if not h.num_contact_data:continue
            paths=[str(PhysicsSchemaTools.intToSdfPath(x)) for x in [h.collider0,h.collider1]]
            names=[self.identify(p) for p in paths];humans=[n for n in names if n.startswith('h_')]
            robot=[n for n in names if n.startswith('native_robot:')]
            finger=any('gripper_finger' in n for n in robot)
            if finger and any(n.startswith('parcel_handle') for n in names):
                for n in robot:
                    if 'gripper_finger' in n:self.payload_finger_times[n]=self.t+DT
                if len([v for v in self.payload_finger_times.values() if self.t+DT-v<.12])>=2:self.payload_contact_time=self.t+DT
            # Keep native chassis/environment contacts too: a tabletop or room
            # obstruction must remain visible in the evidence, even when the
            # person and parcel have not yet been touched.
            if not humans and not robot and 'supplies' not in names and not any(n.startswith('parcel_handle') for n in names):continue
            impulses=[]
            for d in data[h.contact_data_offset:h.contact_data_offset+h.num_contact_data]:
                value=getattr(d,'impulse',None)
                if value is not None:
                    impulse=float(np.linalg.norm(np.asarray(value,float)))
                    if math.isfinite(impulse):impulses.append(impulse)
            impulse=sum(impulses) if impulses else None
            floor='floor' in names or any('groundplane' in p.lower() for p in paths)
            for n in humans:
                if n.endswith('foot') and floor:self.foot_last[n]=self.t+DT
            if humans and (robot or 'supplies' in names):
                if not self.robot_contact:self.pending_checks.append('robot_human_contact')
                self.robot_contact=True
                for arm in self.hand_contact_times:
                    hand_names=([f'gripper_{arm}_',f'arm_{arm}_7_link',f'wrist_{arm}_'] if self.bedside else ['gripper','wrist_roll'])
                    if any(any(part in n for part in hand_names) for n in robot):self.hand_contact_times[arm]=self.t+DT
                if any('base_link' in n or 'wheel' in n for n in robot):self.chassis_contact=True
            if humans and impulse is not None:self.peak_impulse=max(self.peak_impulse or 0.,impulse)
            if 'h_head' in names and len(humans)==1:
                if not self.head_contact:self.pending_checks.append('head_contact')
                self.head_contact=True;self.head_contact_speed=max(self.head_contact_speed or 0.,self.pre_head_speed)
                if floor:
                    self.head_floor_contact=True
                    if impulse is not None:self.peak_head_floor_impulse=max(self.peak_head_floor_impulse or 0.,impulse)
            if 'supplies' in names and 'receiver_table' in names:
                self.shelf_contact_seen=True;self.receiver_contact_time=self.t+DT
            self.frame_contacts.append(dict(bodies=names,paths=paths,impulse_proxy_N_s=impulse,t_interval_end_s=self.t+DT))

    def sense(self,wide=False):
        if not self.bedside:return self.native_authored.native_scan(self,wide)
        p,q,_,_=self.state('camera_head');rot=R.from_quat(q)
        # Fetch URDF: head_camera_joint + RGB frame; no elevated proxy sensor.
        origin=p+rot.apply([.055,.02,.0225] if not self.bedside else [.055,0,0]);seen={};hits=payload=0
        config=self.grounding.get('sensing',{})
        mode='wide' if wide else 'primary'
        grid=config.get(mode+'_ray_grid',[31,15] if wide else [9,7])
        angles=config.get(mode+'_horizontal_vertical_half_angles_rad',[.70,.26] if wide else [.12,.08])
        for a in np.linspace(-angles[0],angles[0],grid[0]):
            for b in np.linspace(-angles[1],angles[1],grid[1]):
                direction=rot.apply([math.cos(b)*math.cos(a),math.cos(b)*math.sin(a),math.sin(b)])
                hit=self.query.raycast_closest(tuple(origin),tuple(direction),float(config.get('maximum_ray_range_m',8.)))
                if not hit.get('hit'):continue
                hits+=1;name=self.identify(str(hit.get('collision',hit.get('rigidBody',''))));payload+=name=='supplies'
                distance=float(hit['distance'])
                if name not in seen or distance<seen[name]['distance_m']:
                    seen[name]=dict(body=name,distance_m=distance,position_m=[float(v) for v in hit['position']])
        obs=dict(t=self.t,sensor='native_head_wide_scan' if wide else 'native_head_primary',origin_m=origin.tolist(),
                 rays=grid[0]*grid[1],hit_rays=hits,payload_first_hit_rays=payload,hits=list(seen.values()))
        self.sensor_log.append(obs);return obs

    def event(self, kind, **details):
        self.events.append(dict(t=self.t,kind=kind,**details))
        if self.index<len(self.steps):self.steps[self.index].setdefault('interventions',[]).append(len(self.events)-1)

    def support_points(self):
        p,q,_,_=self.state('h_torso');rot=R.from_quat(q)
        initial=np.array([0.,0.,.96])
        targets=self.spec.get('support_targets_world_m',{'left':[.13,-.18,.96],'right':[.13,.18,.96]})
        return {arm:p+rot.apply(np.asarray(point)-initial) for arm,point in targets.items()}

    def policy_observation(self):
        p,q=self.robot.get_position_orientation();p,q=arr(p),arr(q)
        hands={}
        points=self.support_points() if self.bedside else {}
        for arm in self.robot.arm_names:
            hp,hq=self.hand_pose(arm)
            gap=float(np.linalg.norm(hp-points[arm])) if self.bedside else None
            contact=self.t-self.hand_contact_times[arm]<.12
            self.support_gates[arm]=bool(contact and gap is not None and gap<.08)
            hands[arm]=dict(position_m=hp.tolist(),orientation_xyzw=hq.tolist(),
                ik_reachable=self.hand_reachable.get(arm,True),
                tracking_error_m=float(np.linalg.norm(hp-self.hand_goals.get(arm,hp))),
                contact_human=contact,contact_payload=self.t-self.payload_contact_time<.12,
                support_target_gap_m=gap,support_force_gate=self.support_gates[arm])
            if self.bedside:
                hands[arm]['wrist_position_m']=self.state(arm+'_wrist')[0].tolist()
        self.grip_available=all(self.support_gates.values()) if self.bedside else False
        obs=dict(t=self.t,robot_position_m=p.tolist(),robot_orientation_xyzw=q.tolist(),robot_yaw_rad=float(R.from_quat(q).as_euler('xyz')[2]),
            robot_velocity_m_s=self.state('robot')[2].tolist(),hands=hands,payload_grasped=self.held,
            payload_released=self.released,receiver_contact=self.shelf_contact_seen,goal_reached=self.goal,
            scans=self.scans,human_posture=None,
            base_yaw_rate_command_rad_s=float(self.yaw_rate_command))
        if self.bedside and self.sensors_enabled:
            torso,pelvis=self.state('h_torso'),self.state('h_pelvis')
            obs['human_posture']=dict(pelvis_position_m=pelvis[0].tolist(),torso_position_m=torso[0].tolist(),
                torso_orientation_xyzw=torso[1].tolist(),
                support_points_world_m={arm:point.tolist() for arm,point in points.items()},
                torso_velocity_m_s=torso[2].tolist(),torso_tilt_deg=self.metrics['torso_tilt_deg'],
                support_center_m=np.mean([self.state('h_'+side+'_foot')[0] for side in ('left','right')],axis=0).tolist(),
                standing=self.goal)
        if not self.bedside:
            obs.update(payload_position_m=self.state('supplies')[0].tolist(),payload_velocity_m_s=self.state('supplies')[2].tolist())
            obs=self.native_authored.native_observation(self,obs)
        return obs

    def control(self):
        old_index=self.policy.action_index
        old_active=self.plan[old_index] if old_index<len(self.plan) else None
        before=[(s.get('start'),s.get('status')) for s in self.steps]
        obs=self.policy_observation()
        command=self.policy.update(self.t,obs) if self.plan else {}
        self.policy_output=command
        self.index=self.policy.action_index
        self.active=self.plan[self.index] if self.index<len(self.plan) and not self.policy.done else None
        for i,step in enumerate(self.steps):
            step.setdefault('interventions',[])
            if before[i][0] is None and step.get('start') is not None:
                self.pending_checks.append('start_'+step['action'])
                print(f'{self.t:.2f}s START {step["action"]}',flush=True)
            if before[i][1]!=step.get('status') and (step.get('status') in ('succeeded','failed','completed') or step.get('status','').startswith('failed_')):
                self.pending_checks.append('end_'+step['action'])
                print(f'{self.t:.2f}s END {step["action"]}: {step["status"]}',flush=True)
        allowed_sensor_action=old_active in ('activate_sensors','verify_path') or self.active in ('activate_sensors','verify_path')
        if command.get('sensors_enabled') and allowed_sensor_action:self.sensors_enabled=True
        self.verified=self.sensors_enabled
        if 'head_target_rad' in command:self.head_target=np.asarray(command['head_target_rad'],float)
        scan=command.get('scan_request')
        if scan in ('primary','wide') and (scan=='primary' or self.sensors_enabled) and self.t>=self.next_scan:
            self.scans[scan]=self.sense(scan=='wide');self.observation=self.scans[scan];self.next_scan=self.t+.15
        for arm,goal in command.get('hand_targets_world',{}).items():
            if arm not in self.arm_models:raise ValueError('Unknown native arm '+arm)
            self.hand_goals[arm]=np.asarray(goal['position_m'],float)
            if not self.policy.done and self.t>=self.next_arm_ik[arm]:
                self.hand_reachable[arm]=self.set_hand_target(goal['position_m'],goal['orientation_xyzw'],arm=arm)
                self.next_arm_ik[arm]=self.t+.15
        for arm,opened in command.get('gripper_open',{}).items():self.gripper_targets[arm]=1. if opened else -1.
        grip=command.get('payload_grasp_request')
        opposing=(not self.bedside and len(self.robot.finger_link_names['0'])==2 and all(
            self.t-self.payload_finger_times.get('native_robot:'+name,-10.)<.12 for name in self.robot.finger_link_names['0']))
        if not self.bedside and grip=='attach' and not self.held and not self.grasp_broken and self.t-self.payload_contact_time<.12 and opposing:
            from omnigibson.utils.usd_utils import create_joint
            from pxr import UsdPhysics
            parcel_p,parcel_q,_,_=self.state('supplies')
            anchor=parcel_p+R.from_quat(parcel_q).apply(self.handle_offset)
            frames=[]
            for name,scale in [('fetch_gripper',arr(self.robot.scale)),('supplies',arr(self.objects['supplies'].scale))]:
                p,q,_,_=self.state(name);inverse=R.from_quat(q).inv()
                frames.extend([self.torch.tensor(inverse.apply(anchor-p)/scale,dtype=self.torch.float32),
                               self.torch.tensor(inverse.as_quat(),dtype=self.torch.float32)])
            # The framework helper initializes its joint schemas and performs
            # its required render-only refresh BEFORE setting explicit frames.
            # Keep the payload out of the robot's articulation topology.
            before_tick=self.og.sim.current_time_step_index
            prim=create_joint('/World/TaskJoints/native_handle_grasp','FixedJoint',
                body0=self.paths['fetch_gripper'],body1=self.paths['supplies'],exclude_from_articulation=True,
                joint_frame_in_parent_frame_pos=frames[0],joint_frame_in_parent_frame_quat=frames[1],
                joint_frame_in_child_frame_pos=frames[2],joint_frame_in_child_frame_quat=frames[3],
                # Match OmniGibson's native assisted-grasp interface. This
                # case isolates occluded navigation, not calibrated grasp
                # slip. The loaded native articulation and all external
                # collisions remain dynamic; release removes this joint.
                break_force=None,break_torque=None)
            assert before_tick==self.og.sim.current_time_step_index
            self.mount=UsdPhysics.Joint(prim);self.held=True
            self.joint_records.append(dict(name='native_handle_grasp',parent='fetch_gripper',child='supplies',
                anchor_m=anchor.tolist(),kind='fixed',exclude_from_articulation=True))
            self.event('contact_confirmed_assisted_grasp',basis='Opposing native finger contacts; OmniGibson assisted fixed grasp, retained until release; slip failure not modeled')
        elif not self.bedside and grip=='release' and self.held:
            with self.og.sim.editing_usd():self.stage.RemovePrim(self.mount.GetPath())
            self.og.sim.update_handles();self.mount=None;self.held=False;self.released=True
            self.event('payload_released',basis='Removed assisted grasp; free physical parcel')
        forces={n:np.zeros(3) for n in self.forces};torques={n:np.zeros(3) for n in self.forces}
        attempt=bool(command.get('human_stand_attempt') and old_active=='assist_to_stand')
        if attempt and self.stand_started is None:self.stand_started=self.t
        if self.bedside:
            applied={}
            self.applied_support_gates=dict(self.support_gates)
            for arm,point in self.support_points().items():
                value=np.asarray(command.get('support_forces_world_N',{}).get(arm,[0,0,0]),float)
                if not np.all(np.isfinite(value)):raise ValueError('Nonfinite assistance force')
                value*=min(1.,160/max(np.linalg.norm(value),1e-9))
                force=value if self.support_gates.get(arm) else np.zeros(3)
                applied[arm]=force
                forces['h_torso']+=force;torques['h_torso']+=np.cross(point-self.state('h_torso')[0],force)
                wrist=arm+'_wrist';forces[wrist]-=force;torques[wrist]-=np.cross(point-self.state(wrist)[0],force)
            self.applied_left=applied['left'];self.applied_right=applied['right']
            self.last_assist_moment=torques['h_torso'].copy()
        for event in command.get('events',[]):self.event('policy_observation',detail=event)
        with self.og.sim.editing_usd():
            if self.bedside:self.human.control(self.t,torques,stand_attempt=attempt)
            else:self.human.control(self.t,torques)
            for n,api in self.forces.items():
                api.GetForceAttr().Set(self.Gf.Vec3f(*map(float,forces[n])))
                api.GetTorqueAttr().Set(self.Gf.Vec3f(*map(float,torques[n])))
        velocity=np.asarray(command.get('base_velocity_world_xy',[0,0]),float)
        speed=float(np.linalg.norm(velocity));cap=.4 if self.bedside else .65
        velocity*=min(1.,cap/max(speed,1e-9))
        acceleration=float(self.spec.get('base_acceleration_limit_m_s2',.5))
        difference=velocity-self.base_command_world
        self.base_command_world+=difference*min(1.,acceleration*DT/max(float(np.linalg.norm(difference)),1e-9))
        velocity=self.base_command_world.copy();speed=float(np.linalg.norm(velocity))
        yaw=obs['robot_yaw_rad']
        if 'final_heading_rad' in command:self.final_heading=float(command['final_heading_rad'])
        heading=self.final_heading
        desired=math.atan2(velocity[1],velocity[0]) if speed>.02 else heading
        error=wrap(desired-yaw)
        yaw_cap=float(self.spec.get('base_yaw_rate_limit_rad_s',.9))
        if not self.bedside and 'base_yaw_rate_cap_rad_s' in command:
            requested_yaw_cap=float(command['base_yaw_rate_cap_rad_s'])
            if not np.isfinite(requested_yaw_cap) or requested_yaw_cap<0:
                raise ValueError('Invalid commanded yaw-rate cap')
            yaw_cap=min(yaw_cap,requested_yaw_cap)
        yaw_rate=float(np.clip(2.8*error,-yaw_cap,yaw_cap))
        self.yaw_rate_command+=float(np.clip(yaw_rate-self.yaw_rate_command,-1.2*DT,1.2*DT))
        drive=[float(speed*max(0.,math.cos(error))**2),self.yaw_rate_command]
        if self.policy.done:drive=[0.,0.]
        if not self.bedside:
            self.policy_output['native_commanded_yaw_rate_rad_s']=float(drive[1])
        action=self.torch.zeros(self.robot.action_dim);idx=self.robot.controller_action_idx
        if self.bedside:
            local_velocity=R.from_euler('z',-yaw).apply([*velocity,0.])
            action[idx['base']]=self.torch.tensor([local_velocity[0],local_velocity[1],np.clip(2.8*wrap(heading-yaw),-.7,.7)],dtype=self.torch.float32)
            if self.policy.done:action[idx['base']]=0.
            action[idx['trunk']]=self.torso_target
        else:action[idx['base']]=self.torch.tensor(drive,dtype=self.torch.float32)
        for arm,km in self.arm_models.items():
            joint_cap=float(self.spec.get('joint_speed_limit_rad_s',1.15))
            limits=np.array([min(.07,km.by_name[n]['velocity']) if km.by_name[n]['kind']=='prismatic' else min(joint_cap,km.by_name[n]['velocity']) for n in km.names])
            # Bounded acceleration avoids impulses from piecewise IK targets
            # under the framework's very stiff native position drives.
            acceleration=np.array([.12 if km.by_name[n]['kind']=='prismatic' else 1.2 for n in km.names])
            delta=self.arm_targets[arm]-self.arm_commands[arm]
            desired_velocity=np.sign(delta)*np.minimum(limits,np.minimum(4*np.abs(delta),np.sqrt(2*acceleration*np.abs(delta))))
            self.arm_command_velocities[arm]+=np.clip(desired_velocity-self.arm_command_velocities[arm],-acceleration*DT,acceleration*DT)
            self.arm_commands[arm]+=self.arm_command_velocities[arm]*DT
            action[idx['arm_'+arm]]=self.torch.tensor(self.arm_commands[arm],dtype=self.torch.float32)
            action[idx['gripper_'+arm]]=self.gripper_targets[arm]
        self.head_command+=np.clip(self.head_target-self.head_command,-.8*DT,.8*DT)
        action[idx['camera']]=self.torch.tensor(self.head_command,dtype=self.torch.float32)
        self.robot.apply_action(action)
        self.pre_head_speed=float(np.linalg.norm(self.state('h_head')[2]))

    def observe(self):
        head,pelvis,torso=self.state('h_head'),self.state('h_pelvis'),self.state('h_torso')
        tilt=math.degrees(math.acos(float(np.clip(R.from_quat(torso[1]).apply([0,0,1])[2],-1,1))))
        falling=(pelvis[0][2]<.35 or (tilt>65 and pelvis[0][2]<.70)) if self.bedside else (pelvis[0][2]<.55 or (tilt>65 and torso[0][2]<.95))
        self.fall_dwell=self.fall_dwell+DT if falling else 0.
        if self.fall_dwell>=.25 and not self.fallen:
            self.fallen=True;self.pending_checks.append('measured_fall');self.event('measured_fall')
        self.peak_head_speed=max(self.peak_head_speed,float(np.linalg.norm(head[2])))
        self.peak_robot_speed=max(self.peak_robot_speed,float(np.linalg.norm(self.state('robot')[2])))
        self.metrics=dict(head_height_m=float(head[0][2]),head_speed_m_s=float(np.linalg.norm(head[2])),pelvis_height_m=float(pelvis[0][2]),
            torso_tilt_deg=tilt,human_fallen=self.fallen,head_contact=self.head_contact,head_floor_contact=self.head_floor_contact,
            robot_human_contact=self.robot_contact,chassis_human_contact=self.chassis_contact,peak_head_speed_m_s=self.peak_head_speed,
            peak_robot_speed_m_s=self.peak_robot_speed,peak_human_contact_impulse_proxy_N_s=self.peak_impulse)
        if self.bedside:
            feet=[self.t-self.foot_last.get('h_'+s+'_foot',-10)<.08 for s in ('left','right')]
            standing=pelvis[0][2]>.88 and tilt<20 and np.linalg.norm(pelvis[2])<.20 and all(feet)
            self.goal_dwell=self.goal_dwell+DT if standing else 0.;self.goal=self.goal_dwell>=1.
            self.metrics.update(standing_dwell_s=self.goal_dwell,assistance_interface_active=bool(np.linalg.norm(self.applied_left)+np.linalg.norm(self.applied_right)>0),
                uneven_support_active=bool(np.linalg.norm(self.applied_left-self.applied_right)>50),
                left_assistance_force_N=self.applied_left.tolist(),right_assistance_force_N=self.applied_right.tolist(),
                assistance_moment_N_m=self.last_assist_moment.tolist(),sensors_active=self.sensors_enabled)
        else:
            p,q,v,w=self.state('supplies');bottom=p[2]-float(np.abs(R.from_quat(q).as_matrix()[2])@(self.parcel_dimensions/2))
            placed=self.released and self.shelf_contact_seen and np.linalg.norm(p[:2]-self.receiver_xy)<.25 and abs(bottom-self.receiver_top)<.035 and np.linalg.norm(v)<.12 and np.linalg.norm(w)<.25
            self.goal_dwell=self.goal_dwell+DT if placed else 0.;self.goal=self.goal_dwell>=.5
            self.metrics.update(supplies_bottom_m=bottom,supplies_speed_m_s=float(np.linalg.norm(v)),delivery_stable_dwell_s=self.goal_dwell)
        for n in self.dynamic:
            p=self.state(n)[0]
            if abs(p[0])>8 or abs(p[1])>5 or p[2]<-1:raise RuntimeError('Physical escape stop: '+n)
