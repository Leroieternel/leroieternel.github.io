"""Native Genie rooms and CAD/skin visuals driven by measured rigid-body poses.

The renderer cannot influence the human controller or choose an outcome. USD
skin/CAD poses are presentation only; contact proxies remain dynamic PhysX
bodies. Native room walls/furniture are static triangle-mesh colliders. The
floor and compliant mattress use explicitly documented flat contact proxies.
"""
from pathlib import Path
import math
import numpy as np
from scipy.spatial.transform import Rotation as R
from pxr import Usd, UsdGeom, UsdShade, UsdPhysics, UsdLux, UsdSkel, PhysxSchema, Gf, Sdf, Vt

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / '.runtime/genie-assets'
FETCH = ROOT / '.runtime/datasets/omnigibson-robot-assets/models/fetch/usd/fetch.usda'
PERSON = ROOT / '.runtime/staff-assets/F_Business_02/F_Business_02.usd'
REVISION = '12f41e388a953cc2aeb0fe5b8eb516750c8321d9'


def align(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    a /= np.linalg.norm(a); b /= np.linalg.norm(b)
    v = np.cross(a, b); c = float(a @ b)
    if c < -.99999:
        axis = np.cross(a, [0, 0, 1])
        if np.linalg.norm(axis) < 1e-5: axis = np.cross(a, [0, 1, 0])
        return R.from_rotvec(axis / np.linalg.norm(axis) * math.pi).as_matrix()
    k = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + k + k @ k / (1 + c)


def pose_ops(xform):
    xform.ClearXformOpOrder()
    return xform.AddTranslateOp(), xform.AddOrientOp()


def put_pose(ops, p, matrix):
    q = R.from_matrix(matrix).as_quat()
    ops[0].Set(Gf.Vec3d(*map(float, p)))
    ops[1].Set(Gf.Quatf(float(q[3]), Gf.Vec3f(*map(float, q[:3]))))


def visual_only(root):
    for p in Usd.PrimRange(root):
        p.SetMetadata('apiSchemas', Sdf.TokenListOp.CreateExplicit([
            schema for schema in p.GetAppliedSchemas() if not schema.startswith(('Physics', 'Physx'))]))
        if p.IsA(UsdPhysics.Joint): p.SetActive(False)
        if p.IsA(UsdGeom.Mesh) and ('collision' in str(p.GetPath()).lower() or UsdGeom.Imageable(p).ComputePurpose() == 'guide'):
            UsdGeom.Imageable(p).CreateVisibilityAttr('invisible')


class HumanSkin:
    """Retarget the eleven measured bodies to a textured, continuous skin."""
    def __init__(self, ep, bedside):
        self.ep, self.bedside = ep, bedside
        self.scale = 1.22 if bedside else 1.10
        root = UsdGeom.Xform.Define(ep.stage, '/World/HumanSkin')
        root.GetPrim().GetReferences().AddReference(str(PERSON))
        root.ClearXformOpOrder(); root.AddScaleOp(opSuffix='humanFit').Set(Gf.Vec3d(self.scale))
        visual_only(root.GetPrim())
        self.skel = next(UsdSkel.Skeleton(p) for p in Usd.PrimRange(root.GetPrim()) if p.IsA(UsdSkel.Skeleton))
        self.names = list(self.skel.GetJointsAttr().Get())
        self.index = {n.split('/')[-1]: i for i, n in enumerate(self.names)}
        lookup = {n: i for i, n in enumerate(self.names)}
        self.parents = [lookup.get(n.rsplit('/', 1)[0], -1) if '/' in n else -1 for n in self.names]
        self.rest = np.asarray(self.skel.GetRestTransformsAttr().Get()).transpose(0, 2, 1).copy()
        self.bind = self.fk(self.rest)
        self.facing = R.from_euler('z', 90 if bedside else 180, degrees=True).as_matrix()
        anim = UsdSkel.Animation.Define(ep.stage, '/World/HumanSkin/MeasuredPhysicsPose')
        anim.CreateJointsAttr(self.names)
        self.trans = anim.CreateTranslationsAttr(); self.rots = anim.CreateRotationsAttr()
        anim.CreateScalesAttr(Vt.Vec3hArray([Gf.Vec3h(1)] * len(self.names)))
        UsdSkel.BindingAPI.Apply(self.skel.GetPrim()).CreateAnimationSourceRel().SetTargets([anim.GetPath()])

    def fk(self, local):
        world = np.empty_like(local)
        for i, p in enumerate(self.parents): world[i] = local[i] if p < 0 else world[p] @ local[i]
        return world

    def update(self):
        local = self.rest.copy(); world = np.empty_like(local)
        targets = {}
        def state(n):
            p, q, _, _ = self.ep.state(n)
            return p, R.from_quat(q).as_matrix()
        def point(n, offset):
            p, q = state(n); return p + q @ np.asarray(offset)
        def target(bone, body, p, child=None, initial_dir=None):
            i = self.index[bone]; _, q = state(body); basis = self.facing
            if child:
                direction = self.bind[self.index[child], :3, 3] - self.bind[i, :3, 3]
                basis = align(self.facing @ direction, initial_dir) @ self.facing
            m = np.eye(4); m[:3, 3] = np.asarray(p) / self.scale
            m[:3, :3] = q @ basis @ self.bind[i, :3, :3]
            targets[i] = m
        target('Hip', 'h_pelvis', state('h_pelvis')[0] + [0, 0, -.03 if self.bedside else .03])
        target('Waist', 'h_torso', point('h_torso', [0, 0, -.22]))
        target('Spine01', 'h_torso', point('h_torso', [0, 0, -.10]))
        target('Spine02', 'h_torso', point('h_torso', [0, 0, .06]))
        target('NeckTwist01', 'h_torso', point('h_torso', [0, 0, .225]))
        target('NeckTwist02', 'h_head', point('h_head', [0, 0, -.12]))
        target('Head', 'h_head', point('h_head', [0, 0, -.08]))
        for side, prefix in [('left', 'L'), ('right', 'R')]:
            thigh, shin, foot, arm = ['h_' + side + '_' + x for x in ['thigh', 'shin', 'foot', 'arm']]
            hip_offset = [-.20, 0, 0] if self.bedside else [0, 0, .20]
            thigh_dir = [1, 0, 0] if self.bedside else [0, 0, -1]
            shin_half = .245 if self.bedside else .20
            target(prefix + '_Thigh', thigh, point(thigh, hip_offset), prefix + '_Calf', thigh_dir)
            target(prefix + '_Calf', shin, point(shin, [0, 0, shin_half]), prefix + '_Foot', [0, 0, -1])
            target(prefix + '_Foot', foot, point(shin, [0, 0, -shin_half]))
            upper_dir = [.12, 0, -.993] if self.bedside else [0, 0, -1]
            fore_dir = [.86, 0, -.51] if self.bedside else [0, 0, -1]
            hand_dir = [1., 0, -.10] if self.bedside else [0, 0, -1]
            target(prefix + '_Upperarm', arm, point(arm, [0, 0, .20]), prefix + '_Forearm', upper_dir)
            target(prefix + '_Forearm', arm, point(arm, [0, 0, 0]), prefix + '_Hand', fore_dir)
            target(prefix + '_Hand', arm, point(arm, [0, 0, -.20]), prefix + '_Mid1', hand_dir)
        for i, parent in enumerate(self.parents):
            if i in targets:
                desired = (np.linalg.inv(world[parent]) if parent >= 0 else np.eye(4)) @ targets[i]
                local[i, :3, :3] = desired[:3, :3]
                if self.names[i].split('/')[-1] == 'Hip': local[i, :3, 3] = desired[:3, 3]
                # Preserve the native skeleton's bone lengths; only the hip
                # translates. Segment orientations come from rigid-body motion.
            world[i] = local[i] if parent < 0 else world[parent] @ local[i]
        if self.bedside:
            # Match the skin's mean ankle height to the measured ankle height.
            # The rigid-link mannequin and native skin have different leg lengths.
            # Translate only the display skeleton: preserve all native bone lengths
            # and rotations, with no writes to physics, contact or task state.
            feet = [self.index['L_Foot'], self.index['R_Foot']]
            dz = float(np.mean([targets[i][2, 3] - world[i][2, 3] for i in feet]))
            if not hasattr(self, '_initial_ankle_offset'):
                self._initial_ankle_offset = dz
            dz -= self._initial_ankle_offset
            hip = self.index['Hip']; parent = self.parents[hip]
            rotation = world[parent, :3, :3] if parent >= 0 else np.eye(3)
            local[hip, :3, 3] += rotation.T @ np.array([0., 0., dz])
            self.ankle_alignment_offset_m = dz * self.scale
        quats = R.from_matrix(local[:, :3, :3]).as_quat()
        self.trans.Set(Vt.Vec3fArray([Gf.Vec3f(*map(float, v)) for v in local[:, :3, 3]]))
        self.rots.Set(Vt.QuatfArray([Gf.Quatf(float(q[3]), Gf.Vec3f(*map(float, q[:3]))) for q in quats]))


class NativeVisuals:
    def __init__(self, ep, task):
        self.ep, self.bedside = ep, task == 'neiss_1014'
        self.followers = []
        # Hide only rendered geometry: dynamic bodies and contacts stay intact.
        for name, o in ep.objects.items():
            if name in ('robot','fetch_gripper','left_wrist','right_wrist','camera_head') or name.startswith('parcel_handle'): continue
            for p in Usd.PrimRange(o.prim):
                if p.IsA(UsdGeom.Gprim) and not p.GetName().startswith('carry_handle_'): UsdGeom.Imageable(p).CreateVisibilityAttr('invisible')
        ground = ep.stage.GetPrimAtPath('/World/ground_plane')
        if ground: UsdGeom.Imageable(ground).CreateVisibilityAttr('invisible')
        self.room()
        self.skin = HumanSkin(ep, self.bedside)
        self.robot()
        if not self.bedside:
            from simulation.genie_scene import prepared_object
            file, size = prepared_object('carton', physical=False, refined=False)
            self.follow_asset('Parcel', file, 'supplies', ep.parcel_dimensions, size)
            for body,name in [('receiver_table','ReceivingTable'),('source_table','SourceTable')]:
                spec=next(row for row in ep.geometry if row['name']==body)
                p,size=spec['p'],spec['dimensions']
                self.receiving_table(name,p[0],p[2]+size[2]/2,p[1],size[:2])
                # Use original table legs and tabletop for contact geometry.
                for prim in Usd.PrimRange(ep.objects[body].prim):
                    if prim.HasAPI(UsdPhysics.CollisionAPI):UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Set(False)
                ep.scene_aliases['/World/'+name]=body
        import carb
        settings = carb.settings.get_settings()
        settings.set_float('/rtx/sceneDb/ambientLightIntensity', 0.)
        settings.set_int('/rtx/post/dlss/execMode', 2)
        settings.set_int('/rtx/directLighting/sampledLighting/samplesPerPixel', 4)
        settings.set_bool('/rtx/ambientOcclusion/enabled', False)
        settings.set_bool('/rtx/indirectDiffuse/enabled', True)
        self.configure_renderer()
        self.manifest = dict(revision='native-human-scenes-v1', asset_repository='agibot-world/GenieSimAssets',
            asset_revision=REVISION, license='CC-BY-NC-SA-4.0', room_asset=self.room_path,
            original_uvs_preserved=True, character_asset=str(PERSON.relative_to(ROOT)),
            character_source='NVIDIA Isaac Sim F_Business_02; adult appearance proxy, not age calibrated',
            human_animation='Native bone lengths retained; measured segment rotations and pelvis motion only; no prerecorded fall animation',
            robot_visual=('Original native TIAGo dual-arm wheeled articulation' if self.bedside else 'Original native single-arm Fetch articulation') + '; original joint lengths, collision meshes and motor controllers; no copied or scaled links',
            collision_model='Native room meshes; flat floor/mattress contact proxies; eleven dynamic human links',
            room_transform=self.room_transform, appearance_does_not_choose_outcome=True,
            renderer=self.ep.render_profile['renderer'], rendering=self.ep.rendering)

    def configure_renderer(self):
        from .native_rendering import configure, record
        self.ep.rendering = record(self.ep.render_profile, configure(self.ep.render_profile))

    def room(self):
        ep = self.ep
        self.room_path = 'background/home/home_b/background.usda' if self.bedside else 'background/hotle/hotle_00/background.usda'
        root = UsdGeom.Xform.Define(ep.stage, '/World/NativeRoom')
        root.GetPrim().GetReferences().AddReference(str(ASSETS / self.room_path))
        root.ClearXformOpOrder()
        pos, yaw = ([1.20, 2.79, .02], 180) if self.bedside else ([-6.30, -.70, .018], -90)
        root.AddTranslateOp().Set(Gf.Vec3d(*pos)); root.AddRotateZOp().Set(yaw)
        self.room_transform = dict(translation_m=pos, yaw_deg=yaw)
        for p in Usd.PrimRange(root.GetPrim()):
            p.SetMetadata('apiSchemas', Sdf.TokenListOp.CreateExplicit([
                schema for schema in p.GetAppliedSchemas() if not schema.startswith(('Physics', 'Physx'))]))
            if p.IsA(UsdPhysics.Joint): p.SetActive(False)
            if p.IsA(UsdGeom.Mesh):
                visible = UsdGeom.Imageable(p).ComputeVisibility() != 'invisible'
                path = str(p.GetPath()).lower()
                # The original authored collision guides must not be visible.
                if 'collider' in path or 'collision' in path:
                    UsdGeom.Imageable(p).CreateVisibilityAttr('invisible'); continue
                b = UsdGeom.BBoxCache(0, ['default', 'render']).ComputeWorldBound(p).ComputeAlignedRange()
                lo, hi = np.asarray(b.GetMin()), np.asarray(b.GetMax())
                # Native textile bedding retains its folds visually; a flat,
                # declared compliant-support proxy supplies mattress contacts.
                flat_floor = hi[2] < .09
                mattress = self.bedside and 'benchmark_bed_001/' in path
                soft_curtain = 'curtain' in path
                if visible and not flat_floor and not mattress and not soft_curtain:
                    UsdPhysics.CollisionAPI.Apply(p).CreateCollisionEnabledAttr(True)
                    UsdPhysics.MeshCollisionAPI.Apply(p).CreateApproximationAttr('none')
                    api = PhysxSchema.PhysxCollisionAPI.Apply(p)
                    api.CreateContactOffsetAttr(.001); api.CreateRestOffsetAttr(0.)
            if p.HasAPI(UsdLux.LightAPI):
                p.CreateAttribute('visibleInPrimaryRay', Sdf.ValueTypeNames.Bool).Set(False)
                light = UsdLux.LightAPI(p)
                light.CreateExposureAttr((light.GetExposureAttr().Get() or 0) - .65)
                for attr in p.GetAttributes():
                    value = attr.Get()
                    if isinstance(value, Sdf.AssetPath) and value.resolvedPath:
                        attr.Set(Sdf.AssetPath(value.resolvedPath))
                if p.IsA(UsdLux.DomeLight):
                    # Use one constant environment fill; native practical
                    # fixtures retain their original positions and colours.
                    light.CreateIntensityAttr(0.)
        sky = ep.stage.GetPrimAtPath('/World/skybox/base_link/light')
        if sky: UsdLux.LightAPI(sky).CreateIntensityAttr(0.)
        # Soft interior fill complements the room's native practical lights.
        dome = UsdLux.DomeLight.Define(ep.stage, '/World/NativeFill')
        dome.CreateIntensityAttr(130 if self.bedside else 100)
        dome.CreateColorAttr(Gf.Vec3f(.92, .95, 1.))

    def follow_asset(self, name, file, body, dimensions, native_size):
        root = UsdGeom.Xform.Define(self.ep.stage, '/World/RenderAssets/' + name)
        ops = pose_ops(root)
        model = UsdGeom.Xform.Define(self.ep.stage, str(root.GetPath()) + '/Model')
        model.GetPrim().GetReferences().AddReference(str(file))
        model.AddScaleOp(opSuffix='fit').Set(Gf.Vec3d(*map(float, np.asarray(dimensions) / native_size)))
        visual_only(model.GetPrim())
        self.followers.append((body, ops, np.zeros(3), np.eye(3)))

    def receiving_table(self, name='ReceivingTable', x=3.45, top=.8, y=0., footprint=(1.,.9)):
        source = ASSETS / 'background/common/table/benchmark_table_006/Aligned.usd'
        root = UsdGeom.Xform.Define(self.ep.stage, '/World/'+name)
        asset = UsdGeom.Xform.Define(self.ep.stage, str(root.GetPath()) + '/Asset')
        asset.GetPrim().GetReferences().AddReference(str(source)); asset.AddRotateXOp(opSuffix='up').Set(90)
        visual_only(asset.GetPrim())
        b = UsdGeom.BBoxCache(0, ['default', 'render']).ComputeWorldBound(asset.GetPrim()).ComputeAlignedRange()
        lo, hi = np.asarray(b.GetMin()), np.asarray(b.GetMax())
        scale = np.array([*footprint, top-.02]) / (hi - lo)
        root.AddTranslateOp().Set(Gf.Vec3d(*map(float, np.array([x, y, .02]) - scale * np.array([(lo[0]+hi[0])/2, (lo[1]+hi[1])/2, lo[2]]))))
        root.AddScaleOp().Set(Gf.Vec3d(*map(float, scale)))
        for prim in Usd.PrimRange(asset.GetPrim()):
            if prim.IsA(UsdGeom.Mesh) and UsdGeom.Imageable(prim).ComputeVisibility()!='invisible':
                UsdPhysics.CollisionAPI.Apply(prim).CreateCollisionEnabledAttr(True)
                UsdPhysics.MeshCollisionAPI.Apply(prim).CreateApproximationAttr('none')
                PhysxSchema.PhysxCollisionAPI.Apply(prim).CreateContactOffsetAttr(.001)

    def robot(self):
        # The original OmniGibson Fetch is already in ep.env.scene.robots.
        # Its native articulation, meshes, UVs and joint lengths are untouched.
        if not hasattr(self.ep, 'robot'):
            raise RuntimeError('A native Fetch articulation is required; CAD proxy rendering is disabled')
        from simulation.detail_assets import refine_fetch
        from simulation.genie_scene import smooth_robot_normals
        if not self.bedside: refine_fetch(self.ep.stage, self.ep.robot)
        smooth_robot_normals(self.ep.robot)

    def update(self):
        self.skin.update()
        for body, ops, offset, basis in self.followers:
            p, q, _, _ = self.ep.state(body); rot = R.from_quat(q).as_matrix()
            put_pose(ops, p + rot @ offset, rot @ basis)

    def camera(self):
        spec=getattr(self.ep,'spec',{})
        if 'camera_eye_m' in spec:
            return np.asarray(spec['camera_eye_m']),np.asarray(spec['camera_target_m']),float(spec['camera_focal_mm'])
        if self.bedside:
            return np.array([3.40, 1.40, 2.25]), np.array([.25, -.10, .70]), 12.
        return np.array([-6.80, -1.10, 2.35]), np.array([.20, .10, .70]), 14.

    def lighting_state(self):
        return {str(p.GetPath()): {a.GetName(): str(a.Get()) for a in p.GetAttributes()
                if a.GetName().startswith('inputs:')}
                for p in self.ep.stage.Traverse() if p.HasAPI(UsdLux.LightAPI)}
