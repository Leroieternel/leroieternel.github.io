"""Apply each scene author's capture profile without advancing physics.

The profile and effective renderer settings are retained with every recording.
No resampling or frame interpolation is used in the encoding path.
"""
import json
from pathlib import Path


def install_signal_handlers():
    """Let the episode's finally block preserve an interrupted diagnostic."""
    import signal
    def stop(signum, frame):
        raise KeyboardInterrupt('Simulation interrupted by signal ' + str(signum))
    signal.signal(signal.SIGTERM, stop)


def load_profile(task, draft=False):
    profile = json.loads((Path(__file__).parent / task / 'render_profile.json').read_text())
    for key in ('width', 'height', 'fps', 'render_updates_per_frame', 'warmup_updates', 'crf'):
        if not isinstance(profile[key], int):
            raise ValueError(f'Render profile {key} must be an integer')
    assert profile['width'] >= 1440 and profile['height'] >= 960
    assert profile['width'] % 16 == profile['height'] % 16 == 0
    assert profile['fps'] >= 30 and 60 % profile['fps'] == 0
    assert profile['render_updates_per_frame'] >= 1 and profile['warmup_updates'] >= 1
    assert 0 <= profile['crf'] <= 16
    assert isinstance(profile.get('keyframe_interval_s', 2), int) and 1 <= profile.get('keyframe_interval_s', 2) <= 10
    assert profile['renderer'] in ('PathTracing', 'RealTimePathTracing')
    if draft:
        profile = {**profile, 'width': 640, 'height': 448, 'diagnostic_draft': True}
    return profile


def configure(profile):
    import carb
    settings = carb.settings.get_settings()
    requested = {**profile['settings'], '/rtx/rendermode': profile['renderer']}
    for key, value in requested.items():
        if not key.startswith(('/rtx', '/app/', '/omni.kit.plugin/')) or not isinstance(value, (bool, int, float, str)):
            raise ValueError('Invalid renderer setting: ' + key)
        settings.set(key, value)
    effective = {key: settings.get(key) for key in requested}
    assert effective == requested, 'Renderer did not retain the requested settings'
    return effective


def settle(sim, updates):
    before = sim.current_time_step_index
    for _ in range(updates):
        sim.render()
    assert sim.current_time_step_index == before, 'Capture warmup advanced physics'


def writer(path, profile):
    import imageio.v2 as imageio
    return imageio.get_writer(str(path), fps=profile['fps'], codec='libx264',
                             macro_block_size=16, quality=None,
                             ffmpeg_params=['-crf', str(profile['crf']), '-preset', 'slow',
                                            '-movflags', '+faststart', '-g', str(profile.get('keyframe_interval_s', 2) * profile['fps'])])


def record(profile, effective):
    import carb
    settings=carb.settings.get_settings()
    keys=profile.get('read_back_only',[
        '/rtx/post/tonemap/op','/rtx/post/tonemap/filmIso',
        '/rtx/post/tonemap/cameraShutter','/rtx/post/tonemap/fNumber',
        '/rtx/post/tonemap/whitepoint'])
    return {**profile, 'effective_settings': effective,
            'fixed_camera_settings_readback':{key:settings.get(key) for key in keys},
            'native_resolution': True, 'frame_interpolation': False,
            'control_steps_per_video_frame': 60 // profile['fps'],
            'physics_steps_per_video_frame': 120 // profile['fps'],
            'encoding': 'H.264, yuv420p, native raster size'}


def render_frame(ep, final=False):
    if ep.physics_only:
        return
    import carb
    import imageio.v2 as imageio
    import numpy as np
    profile = ep.render_profile
    settings = carb.settings.get_settings()
    for key, value in ep.rendering['effective_settings'].items():
        assert settings.get(key) == value, 'Capture setting changed: ' + key
    for key,value in ep.rendering['fixed_camera_settings_readback'].items():
        assert settings.get(key)==value, 'Camera exposure/color setting changed: '+key
    before_tick = ep.og.sim.current_time_step_index
    with ep.og.sim.editing_usd():
        ep.visuals.update()
    settle(ep.og.sim, profile['render_updates_per_frame'])
    assert ep.og.sim.current_time_step_index == before_tick
    obs = ep.og.sim.viewer_camera.get_obs()
    obs = obs[0] if isinstance(obs, tuple) else obs
    rgb = obs['rgb']
    rgb = rgb.detach().cpu().numpy() if hasattr(rgb, 'detach') else np.asarray(rgb)
    rgb = rgb[..., :3]
    if np.issubdtype(rgb.dtype, np.floating) and rgb.max() <= 1:
        rgb = rgb * 255
    rgb = np.clip(rgb, 0, 255).astype('uint8')
    assert rgb.shape == (profile['height'], profile['width'], 3), 'Non-native capture resolution'
    if not final:
        count = getattr(ep, 'capture_count', 0)
        if count:
            assert abs(ep.t - ep.last_capture_t - 1 / profile['fps']) < 1e-6
        ep.writer.append_data(rgb)
        with (ep.output / 'capture-times.jsonl').open('a') as stream:
            stream.write(json.dumps(dict(frame=count, t=float(ep.t), physics_tick=int(before_tick))) + '\n')
        ep.capture_count, ep.last_capture_t = count + 1, ep.t
    if ep.last_image is None:
        imageio.imwrite(ep.output / 'poster.jpg', rgb)
    for label in ep.pending_checks:
        imageio.imwrite(ep.output / 'checks' / f'{round(ep.t * 1000):06d}_{label}.jpg', rgb)
    ep.pending_checks.clear()
    ep.last_image = rgb
    if final:
        imageio.imwrite(ep.output / 'final.jpg', rgb)
