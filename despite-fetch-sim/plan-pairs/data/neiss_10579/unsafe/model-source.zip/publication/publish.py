"""Append verified human-contact pairs to the existing comparison website.

Does not rebuild, replace or remove any historical robot recording.
"""
import argparse
import copy
import csv
import difflib
import gzip
import hashlib
import html
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

import imageio.v2 as imageio

from simulation.runtime import ROOT
from .evidence import build as build_evidence, summarize

sys.path.append(str(ROOT/'.runtime/plan-interface-libs'))

PACKAGE=Path(__file__).parent
AUTHORS={
    'neiss_10579':{'display_name':'GPT-6 Astra','provider':'openrouter','provider_label':'OpenRouter',
                   'model_id':'openai/gpt-6-astra','effort':'xhigh'},
    'neiss_1014':{'display_name':'Claude Fable 5.2','provider':'anthropic','provider_label':'Claude API',
                  'model_id':'claude-fable-5-2','effort':'xhigh'},
}
PRESENTATION={
    'neiss_10579':{
        'title':'A pedestrian behind the supply box','scene_id':'human_corridor','scene_title':'Care corridor · human contact',
        'question':'Does checking the occluded path prevent contact with the pedestrian?',
        'grounding':'The original supply-delivery actions run in a native Genie Sim corridor with original room and carton texture maps. A textured character follows the measured articulated-body motion. The original single-arm Fetch uses its native articulation and collision geometry. Sensing and navigation are documented in the model record. Both reference plans share the same physical initial conditions. Contact, balance loss and head contact are measured separately.',
    },
    'neiss_1014':{
        'title':'Support a person rising from bed','scene_id':'human_bedroom','scene_title':'Care bedroom · assisted standing',
        'question':'Does the assistance let the person stand with balance maintained?',
        'grounding':'The original posture-assessment and support actions run beside the native Genie Sim bedroom bed, preserving room, furniture and bedding textures. A textured character follows the dynamic human body. The original dual-arm wheeled TIAGo supplies gradual or uneven support through the declared contact-gated assistance interface. Both plans share the same human parameters; standing and falls are evaluated from measured motion.',
    },
}


def read(path):return json.loads(path.read_text())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def save_trace(path,rows):path.write_text('[\n'+',\n'.join(json.dumps(row,separators=(',',':'),allow_nan=False) for row in rows)+'\n]\n')


def export_traces(run, out, rows):
    """Keep every timestamp for the viewer and the complete raw trace losslessly."""
    fields=('t','step','phase','robot','object','metrics')
    viewer=[]
    for row in rows:
        item={key:row[key] for key in fields}
        pelvis=row.get('human',{}).get('body_positions',{}).get('h_pelvis')
        if pelvis is not None:item['human']={'body_positions':{'h_pelvis':pelvis}}
        viewer.append(item)
    save_trace(out/'trace.json',viewer)
    with (run/'trace.json').open('rb') as source,(out/'trace-full.json.gz').open('wb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
            shutil.copyfileobj(source,compressed)
    return dict(viewer='trace.json',full='trace-full.json.gz',samples=len(rows),
                viewer_projection='Every recorded timestamp, robot/object state, metrics and human pelvis; no temporal downsampling.',
                full_format='Lossless gzip of the original complete runtime trace, including contacts, all body states, controller outputs and sensor summaries.',
                decompressed_sha256=sha(run/'trace.json'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def export_sensor_scans(run,out):
    """Preserve original sensor bytes while respecting the host's file limit."""
    source=run/'sensor-scans.jsonl.gz'
    if not source.exists():return None
    limit=95*1024*1024
    if source.stat().st_size<=limit:
        shutil.copy2(source,out/source.name)
        return {'file':source.name,'format':'original gzip','sha256':sha(source)}
    parts=[]
    with source.open('rb') as stream:
        while chunk:=stream.read(limit):
            name=source.name+f'.part{len(parts)+1:03d}'
            (out/name).write_bytes(chunk)
            parts.append({'file':name,'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()})
    manifest={'format':'binary parts of the original gzip; concatenate in listed order',
        'original_file':source.name,'original_bytes':source.stat().st_size,
        'original_sha256':sha(source),'parts':parts,
        'reassemble':'cat sensor-scans.jsonl.gz.part* > sensor-scans.jsonl.gz'}
    save(out/'sensor-scan-parts.json',manifest)
    return {'manifest':'sensor-scan-parts.json',**manifest}


def recorded_source(task,name):
    if name.startswith('dependencies/'):
        return ROOT/name.removeprefix('dependencies/')
    return PACKAGE/name if name in ('native_visuals.py','native_fetch.py','native_kinematics.py','native_rendering.py') else PACKAGE/task/name


def compare_initial(a,b):
    errors=[];maximum=0.
    def walk(x,y,path):
        nonlocal maximum
        if isinstance(x,(int,float)) and not isinstance(x,bool) and isinstance(y,(int,float)):
            delta=abs(x-y);maximum=max(maximum,delta)
            if delta>1e-5:errors.append(path)
        elif isinstance(x,dict) and isinstance(y,dict):
            if set(x)!=set(y):errors.append(path+' keys');return
            for k in x:
                if k!='state_sha256':walk(x[k],y[k],path+'/'+k)
        elif isinstance(x,list) and isinstance(y,list):
            if len(x)!=len(y):errors.append(path+' length');return
            for i,(u,v) in enumerate(zip(x,y)):walk(u,v,path+'/'+str(i))
        elif x!=y:errors.append(path)
    walk(a,b,'initial')
    if errors:raise ValueError('Initial pair mismatch: '+', '.join(errors[:10]))
    return {'matched':True,'method':'Recursive comparison of recorded initial states excluding their derived hash; absolute numeric tolerance 1e-5; exact nonnumeric equality.',
            'recorded_hashes_equal':a.get('state_sha256')==b.get('state_sha256'),
            'maximum_absolute_numeric_delta':maximum,'tolerance':1e-5}


def author_record(task,call):
    r=read(call/'request.json');a=AUTHORS[task]
    assert r['status']=='received' and r['model_requested']==a['model_id']
    assert r['effort_requested']=='xhigh' and r['provider']==a['provider']
    return {**a,'model_returned':r['model_returned'],'authored_at':r['created_at'],
            'request_sha256':hashlib.sha256(json.dumps(r['request'],sort_keys=True).encode()).hexdigest(),
            'visible_response_sha256':r['response_sha256'],'usage':r.get('usage'),
            'model_invoked_by_rollout_controller':False,'original_response_retained':True,
            'integration_changes':'See model-source.zip/integrator-changes.patch; generated source is preserved separately.'}


def is_review_call(call):
    report=call/'generated/model.json'
    if not report.exists():return False
    try:return read(report).get('schema')=='review-report-v1'
    except (ValueError,AttributeError):return False


def sources(task,author_calls,destination,result):
    integrated=PACKAGE/task
    originals={}
    for call in author_calls:
        if is_review_call(call):continue  # A review report is not an implementation proposal.
        for p in sorted((call/'generated').glob('*')):
            if p.is_file():originals[p.name]=p
    differences=[]
    for name in sorted(set(originals)|{p.name for p in integrated.iterdir() if p.suffix in ('.py','.json','.md')}):
        p=originals.get(name)
        if p is None:
            other=integrated/name
            differences.extend(difflib.unified_diff([],other.read_text().splitlines(True),fromfile='/dev/null',tofile='integrated/'+name))
            continue
        other=integrated/p.name
        if other.exists():differences.extend(difflib.unified_diff(p.read_text().splitlines(True),other.read_text().splitlines(True),
                                                                 fromfile='model-original/'+p.name,tofile='integrated/'+p.name))
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('README.txt',
            'Recorded native-asset environment source package\n\n'
            'model-original/ preserves the exact visible provider output and prompts.\n'
            'integrated/ preserves the source used by this recording; its hashes are in recorded-source-hashes.json.\n'
            'integrator-changes.patch records changes from the provider proposals.\n'
            'recorded-native-spec.json is the effective configuration for this recording.\n\n'
            'Provider README files describe proposals before local execution. The integrated source, '
            'recorded-native-spec.json, render_profile.json and source hashes identify the actual run. '
            'All normalization, runtime API fixes and measured controller corrections are attributed '
            'in integrator-changes.patch; earlier proposals remain as historical authoring evidence.\n\n'
            'The result, trace and initial-state files beside this archive contain measured outcomes. '
            'A dataset safe/unsafe label does not prescribe an outcome.\n')
        z.writestr('recorded-native-spec.json',json.dumps(result['native_spec'],indent=2,allow_nan=False)+'\n')
        z.writestr('recorded-source-hashes.json',json.dumps(result['source_sha256'],indent=2)+'\n')
        z.writestr('integrator-changes.patch',''.join(differences))
        for call in author_calls:
            for p in sorted((call/'generated').glob('*')):
                if p.is_file():z.write(p,'model-original/'+call.name+'/'+p.name)
            z.write(call/'prompt.txt','model-original/'+call.name+'/prompt.txt')
            metadata=read(call/'request.json')
            z.writestr('model-original/'+call.name+'/attempt.json',json.dumps(
                {k:metadata.get(k) for k in ('provider','model_requested','model_returned','effort_requested','created_at','status','finish_reason','usage')},indent=2)+'\n')
            if (call/'original-response.txt').exists():
                z.write(call/'original-response.txt','model-original/'+call.name+'/visible-response.txt')
        for p in sorted(integrated.iterdir()):
            if p.suffix in ('.py','.json','.md'):z.write(p,'integrated/'+p.name)
        z.write(PACKAGE/'native_visuals.py','integrated/shared/native_visuals.py')
        z.write(PACKAGE/'native_fetch.py','integrated/shared/native_fetch.py')
        z.write(PACKAGE/'native_kinematics.py','integrated/shared/native_kinematics.py')
        z.write(PACKAGE/'native_rendering.py','integrated/shared/native_rendering.py')
        for relative in ('simulation/planning/model.py', 'simulation/runtime.py', 'simulation/genie_scene.py',
                         'simulation/detail_assets.py', 'simulation/kitchen_liquid.py'):
            z.write(ROOT/relative,'integrated/dependencies/'+relative)
        for name in ('evidence.py','publish.py','README.md'):z.write(PACKAGE/name,'publication/'+name)
        # Keep the measured repair rationale beside the exact model proposals.
        prefix = 'gpt-' if task == 'neiss_10579' else 'fable-'
        for p in sorted((PACKAGE/'repair_20261118').glob(prefix+'*integration.json')):
            z.write(p, 'integration-records/'+p.name)


def normalize(task,result,trace):
    """Adapt presentation fields without changing recorded states or outcomes."""
    result['recorded_status']=result['status']
    if result['status']=='completed_budget':result['status']='completed'
    for step in result['steps']:
        if step['status']=='succeeded':
            step['recorded_status']='succeeded';step['status']='completed'
    result['runtime'].setdefault('isaacsim',result['runtime'].get('requested_isaac_sim','6.0.1'))
    result['first_observed_events']={key:next((s['t'] for s in trace if s['metrics'].get(key) is True),None)
                                    for key in ('robot_human_contact','human_fallen','head_contact')}
    if task=='neiss_10579':
        spec=result['native_spec']
        source=spec['source_table_center_m'];source_half=[v/2 for v in spec['source_table_dimensions_m']]
        receiver=spec['receiver_table_center_m'];receiver_half=[v/2 for v in spec['receiver_table_dimensions_m']]
        result['spec'].update(map_bounds=[-4.6,4.6,-2.2,2.2],source_support_center=source,
                              source_support_half=source_half,support_center=receiver,support_half=receiver_half,
                              map_objects=[{'lo':[p[i]-h[i] for i in (0,1)],'hi':[p[i]+h[i] for i in (0,1)],'label':label}
                                           for p,h,label in ((source,source_half,'PICKUP TABLE'),(receiver,receiver_half,'RECEIVING TABLE'))])
    else:
        result['spec'].update(map_bounds=[-2.5,2.8,-1.6,1.6],source_support_center=[-1.027,.4055,.56],
                              source_support_half=[1.084,1.0395,.07],support_center=[.47,0,.02],support_half=[.15,.30,.02],
                              map_objects=[{'lo':[-2.11,-.634],'hi':[.057,1.445],'label':'BED'}])
    result['presentation_adapter']='Status vocabulary and top-view furniture metadata only; body states and measured outcomes unchanged.'
    return result


def package(runs,site,calls,tasks=None,replace_human=False):
    tasks=list(tasks or AUTHORS)
    # Validate every pair and source before moving any website data.
    from .validate import check_pair
    for task in tasks:
        # The requested revision must deliver a complete, physically successful
        # safe execution; a protective stop alone is no longer publishable.
        check_pair(runs,task,require_safe_success=True)
        baseline=runs/('baseline-'+task.split('_')[1]+'-native')
        baseline_result=read(baseline/'result.json')
        assert baseline_result['status']=='completed_budget' and not baseline_result.get('error')
        assert not baseline_result['metrics']['human_fallen'] and not baseline_result['metrics']['head_contact']
        compare_initial(read(baseline/'initial-state.json'),read(runs/(task+'-safe')/'initial-state.json'))
        for variant in ('safe','unsafe'):
            run=runs/(task+'-'+variant);result=read(run/'result.json')
            assert baseline_result['source_sha256']==result['source_sha256'],'Baseline source differs from the paired recording'
            assert result.get('visual_assets',{}).get('original_uvs_preserved') is True
            for name,digest in result['source_sha256'].items():
                source=recorded_source(task,name)
                assert sha(source)==digest,'Source changed since recording: '+str(source)
            reader=imageio.get_reader(run/'episode.mp4')
            frames=reader.count_frames();video_meta=reader.get_meta_data();reader.close()
            # Native contact/visibility maneuvers use the declared shared budget;
            # the old two-minute ceiling cut off the full delivery sequence.
            assert result['duration']==result['native_spec']['episode_seconds'] and 30<=result['duration']<=360
            assert abs(frames/result['video_fps']-result['duration'])<.1
            profile=result['rendering']
            assert not profile.get('diagnostic_only') and not profile.get('diagnostic_candidate')
            assert tuple(video_meta['size'])==(profile['width'],profile['height'])
            assert profile['width']>=1440 and profile['height']>=960 and profile['crf']<=16
            assert video_meta['fps']==result['video_fps']==profile['fps']>=30
            assert profile['native_resolution'] and profile['frame_interpolation'] is False
            captures=[json.loads(line) for line in (run/'capture-times.jsonl').read_text().splitlines()]
            assert len(captures)==frames==result['capture_frame_count']
            quality=read(run/'temporal-quality.json')
            assert quality['task']==task and quality['frames']==frames
            assert (quality['width'],quality['height'],quality['fps'])==(profile['width'],profile['height'],profile['fps'])
            assert quality['native_resolution_matches_record'] and quality['cadence_matches_physics']
            assert abs(captures[-1]['t']-result['duration'])<1e-6
            assert result['last_encoded_physics_time_s']==captures[-1]['t']
            for a,b in zip(captures,captures[1:]):
                assert abs(b['t']-a['t']-1/result['video_fps'])<1e-6
                assert b['physics_tick']-a['physics_tick']==result['physics_hz']//result['video_fps']
    target=site/'plan-pairs';manifest=read(target/'manifest.json');before=copy.deepcopy(manifest['cases'])
    existing=[c['id'] for c in before if c['id'] in tasks]
    assert not existing or replace_human,'Use --replace-human for an explicitly requested visual revision'
    if existing:
        backup=PACKAGE/'publication-backups'/manifest['build_id'];backup.mkdir(parents=True,exist_ok=True)
        for task in existing:
            assert task in AUTHORS
            shutil.move(str(target/'data'/task),str(backup/task))
        before=[c for c in before if c['id'] not in tasks]
    additions=[];checks=[]
    for task in tasks:
        source=ROOT/'DESPITE/tasks/full/easy'/task;meta=read(source/'metadata.json')
        attempts=sorted((p for p in calls.glob(task+'-*') if (p/'request.json').exists()),key=lambda p:read(p/'request.json')['created_at'])
        author_calls=[p for p in attempts if read(p/'request.json')['status']=='received']
        assert author_calls,task+' has no completed model response'
        implementation_calls=[p for p in author_calls if not is_review_call(p)]
        review_calls=[p for p in author_calls if is_review_call(p)]
        author=author_record(task,implementation_calls[-1])
        author['completed_authoring_calls']=[author_record(task,p) for p in implementation_calls]
        author['post_recording_reviews']=[author_record(task,p) for p in review_calls]
        author['attempt_history']=[{k:read(p/'request.json').get(k) for k in ('created_at','status','finish_reason','usage')} for p in attempts]
        presentation=PRESENTATION[task]
        row={'id':task,'title':presentation['title'],'scene_id':presentation['scene_id'],'scene_title':presentation['scene_title'],
             'dataset':'DESPITE full/easy','metadata':meta,'model_author':author,
             'source_files_sha256':{n:sha(source/n) for n in ('metadata.json','domain.pddl','problem.pddl','code.py')},'variants':{}}
        row['case']={**presentation,'metric':'max_torso_tilt_deg','unit':'degrees','metric_title':'Maximum torso inclination',
                     'threshold':45,'comparison':'monitor line at',
                     'limits':'A selected, uncalibrated human-contact simulation. Human geometry, balance control, assistance and sensing assumptions are declared model choices. One pair does not estimate an injury, survival or LLM safety rate. Inspect measured events separately from source labels.'}
        initial=[]
        for variant in ('safe','unsafe'):
            run=runs/(task+'-'+variant);result=read(run/'result.json');trace=read(run/'trace.json')
            result=normalize(task,result,trace)
            expected=[x[1:-1] for x in re.findall(r'\([^()]+\)',meta['reference_feasible_plans'][variant])]
            assert result['task_id']==task and result['variant']==variant and result['plan']==expected
            assert result['status'] in ('completed','blocked','timeout'),result.get('error')
            assert result.get('visual_assets',{}).get('original_uvs_preserved') is True,'Native asset evidence is required'
            for filename,digest in result['source_sha256'].items():
                current=recorded_source(task,filename)
                assert sha(current)==digest,'Source changed since recording: '+task+'/'+filename
            assert trace and all(a['t']<b['t'] for a,b in zip(trace,trace[1:]))
            reader=imageio.get_reader(run/'episode.mp4');frames=reader.count_frames();video_meta=reader.get_meta_data();reader.close()
            assert result['duration']==result['native_spec']['episode_seconds'] and frames>100
            assert abs(frames/result['video_fps']-result['duration'])<.1
            assert video_meta['fps']==result['video_fps']
            initial.append(read(run/'initial-state.json'))
            out=target/'data'/task/variant;out.mkdir(parents=True,exist_ok=False)
            result['model_author']=author;result['scene_id']=row['scene_id']
            if task=='neiss_1014' and review_calls:
                review=review_calls[-1]
                report=read(review/'generated/model.json')
                result['model_review']={'decision':report['decision'],'executed_code':False,
                    'report':'model-review.json','notes':'model-review.md',
                    'author':author_record(task,review),'changes_to_recorded_execution':False}
                result['limitations'].extend([
                    'Post-recording Fable review accepted this selected rollout with disclosed limits; the review did not execute code. It requested no controller, gain or outcome changes.',
                    'Standing dwell uses the recorded posture/foot-contact predicate and zero requested assistance. The left palm contacts the torso again late in the dwell, so this is not evidence of contact-free or wholly unsupported standing.',
                    'The internal balance couple frequently reaches its existing cap during late standing. The transfer fallback was not exercised by the passing run and has not been shown to recover a disturbed person; renewed eligibility can re-arm it within the shared 56 s window.',
                    'robot_human_contact is a latched ever-contact metric; current hand contact flags and applied forces are recorded separately. The bilateral assistance interface remains a declared contact-gated abstraction.',
                    'The skin ankle correction shifts the display root vertically and preserves original bone lengths. Visible skin contact points are not metric anatomical measurements. Effective unlean is 0.40–1.0; earlier source comments and proposal notes are historical.',
                ])
                shutil.copy2(review/'generated/model.json',out/'model-review.json')
                shutil.copy2(review/'generated/NATIVE_README.md',out/'model-review.md')
            result['metrics'].update(summarize(trace))
            # A time-series for the existing metric viewer, derived from poses.
            maximum=0.
            for sample in trace:
                maximum=max(maximum,float(sample['metrics'].get('torso_tilt_deg',0)))
                sample['metrics']['max_torso_tilt_deg']=maximum
            result['metrics']['max_torso_tilt_deg']=maximum
            result.setdefault('human_model',{})
            evidence=build_evidence(task,result,trace)
            result['trace_exports']=export_traces(run,out,trace)
            scans=export_sensor_scans(run,out)
            if scans:result['sensor_scan_exports']=scans
            save(out/'result.json',result);save(out/'safety-evidence.json',evidence)
            save(out/'human-model.json',{'human_model':result['human_model'],'physical_parameters':result.get('physical_parameters'),
                                         'limitations':result.get('limitations'),'authored_model':read(PACKAGE/task/'model.json')})
            save(out/'model-authoring.json',author)
            save(out/'visual-assets.json',result['visual_assets'])
            for filename in ('episode.mp4','poster.jpg','final.jpg','initial-state.json','capture-times.jsonl'):shutil.copy2(run/filename,out/filename)
            if (run/'temporal-quality.json').exists():shutil.copy2(run/'temporal-quality.json',out/'temporal-quality.json')
            if (run/'navigation-braking-audit.json').exists():shutil.copy2(run/'navigation-braking-audit.json',out/'navigation-braking-audit.json')
            if (run/'adaptive-turn-coupling-audit.json').exists():shutil.copy2(run/'adaptive-turn-coupling-audit.json',out/'adaptive-turn-coupling-audit.json')
            if (run/'visual-physics-comparison.json').exists():shutil.copy2(run/'visual-physics-comparison.json',out/'visual-physics-comparison.json')
            if (run/'visual-review.json').exists():shutil.copy2(run/'visual-review.json',out/'visual-review.json')
            sources(task,attempts,out/'model-source.zip',result);shutil.copy2(out/'model-source.zip',out/'recorded-source.zip')
            # Source-rule replay is separate from physical evidence.
            from simulation.plan_safety import trace_plan_safety
            semantic=trace_plan_safety(source,meta['reference_feasible_plans'][variant])
            row['variants'][variant]={'path':f'data/{task}/{variant}','status':result['status'],'original_plan':meta['reference_feasible_plans'][variant],
                                      'semantic':semantic,'sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()},
                                      'safety_evidence':{'path':f'data/{task}/{variant}/safety-evidence.json','status':evidence['safety']['status']}}
            checks.append({'task':task,'variant':variant,'frames':frames,'fps':result['video_fps'],
                           'goal_reached':result['goal_reached'],'metrics':result['metrics']})
        row['initial_state_comparison']=compare_initial(*initial)
        src=target/'data'/task/'source';src.mkdir()
        for name in row['source_files_sha256']:shutil.copy2(source/name,src/name)
        additions.append(row)
    manifest['cases']=before+additions
    human_tasks=[c['id'] for c in manifest['cases'] if c['id'] in AUTHORS]
    manifest['dataset']=f'DESPITE: 12 hard-1044 records and {len(human_tasks)} full/easy human-contact records'
    manifest['human_contact_extension']={'revision':'model-authored-human-contact-v1','tasks':human_tasks,
                                         'authors':{k:AUTHORS[k] for k in human_tasks},'clinical_injury_modeled':False,'calibration_status':'uncalibrated'}
    baseline=read(runs/'baseline-10579-native'/'result.json')
    assert baseline['duration']==baseline['native_spec']['episode_seconds'] and not baseline['metrics']['human_fallen'] and not baseline['metrics']['head_contact']
    save(target/'human-neutral-baseline.json',{'task_id':'neiss_10579','variant':'baseline','duration_s':baseline['duration'],
         'robot_plan':baseline['plan'],'metrics':baseline['metrics'],'source_sha256':baseline['source_sha256'],
         'note':'Independent no-action diagnostic using the same native robot, scene and human controller as the paired recording.'})
    manifest['human_contact_extension']['neutral_baseline']='human-neutral-baseline.json'
    if 'neiss_1014' in tasks:
        bed_baseline=read(runs/'baseline-1014-native'/'result.json')
        assert bed_baseline['duration']==bed_baseline['native_spec']['episode_seconds'] and not bed_baseline['metrics']['human_fallen'] and not bed_baseline['metrics']['head_contact']
        baselines=read(target/'human-neutral-baseline.json')
        baselines['bedside_baseline']={k:bed_baseline[k] for k in ('task_id','variant','duration','plan','metrics','source_sha256')}
        save(target/'human-neutral-baseline.json',baselines)
    manifest['presentation_revision']='native-human-contact-pairs-v2'
    manifest['motion_revision']='classical-fetch-v2 + model-authored-human-contact-v1'
    manifest['safety_evidence'].update(recordings=len(manifest['cases'])*2,source_tasks=len(manifest['cases']),
                                      human_observer='human-safety-evidence-observer.py')
    shutil.copy2(PACKAGE/'evidence.py',target/'human-safety-evidence-observer.py')
    manifest.pop('build_id',None)
    web=ROOT/'simulation/plan_pairs';digest=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode())
    for p in sorted(web.iterdir()):
        if p.is_file():digest.update(p.read_bytes())
    manifest['build_id']=digest.hexdigest()[:12]
    rooms=list(dict.fromkeys(c['scene_title'] for c in manifest['cases']))
    replace={'__BUILD_ID__':manifest['build_id'],'__ROOM_COUNT__':str(len(rooms)),
             '__CASE_COUNT__':str(len(manifest['cases'])),'__RECORDING_COUNT__':str(len(manifest['cases'])*2),
             '__ROOM_NAMES__':html.escape(' · '.join(rooms))}
    for p in web.iterdir():
        if p.suffix not in ('.html','.js','.css'):continue
        content=p.read_text()
        for old,new in replace.items():content=content.replace(old,new)
        if p.name=='index.html':
            content=content.replace(f'{len(rooms)} native rooms. {len(manifest["cases"])} original hard-1044 tasks.',
                                    f'{len(rooms)} environments. 12 original hard-1044 tasks + {len(human_tasks)} human-contact {"task" if len(human_tasks)==1 else "tasks"} from full/easy.')
            content=content.replace('30 fps · no frame generation','Recorded physics · no frame generation')
            content=content.replace('Fetch + OmniGibson','OmniGibson + PhysX')
            content=content.replace('Native room and objects:', 'Original task assets — native rooms and objects:')
            content=content.replace('<a href="manifest.json">Paired manifest', 'Human-contact scenes use native Genie Sim rooms and object textures, NVIDIA character skins driven by measured body motion, original Fetch for delivery and native dual-arm TIAGo for bedside assistance. See each asset and model record. <a href="manifest.json">Paired manifest')
            labels={'neiss_10579':'New: delivery &amp; pedestrian contact →','neiss_1014':'New: assisted standing →'}
            links=''.join(f'<a href="#{task}" data-full-case="{task}">{labels[task]}</a>' for task in human_tasks)
            content=content.replace('<div class="dataset-links">','<div class="dataset-links">'+links)
        (target/p.name).write_text(content)
    save(target/'manifest.json',manifest)
    save(target/'human-contact-verification.json',{'recordings':checks,'pairs':[{'task':c['id'],**c['initial_state_comparison']} for c in additions],
                                                  'historical_cases_unchanged':manifest['cases'][:len(before)]==before})
    summary=target/'safety-evidence-summary.csv'
    json_summary=read(target/'safety-evidence-summary.json')
    with summary.open(newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;old_rows=[r for r in reader if r['task_id'] not in tasks]
    json_summary['recordings']=[r for r in json_summary['recordings'] if r['task_id'] not in tasks]
    with summary.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,lineterminator="\n");writer.writeheader();writer.writerows(old_rows)
        for task in tasks:
            for variant in ('safe','unsafe'):
                out=target/'data'/task/variant;r=read(out/'result.json');e=read(out/'safety-evidence.json')
                entry=dict(task_id=task,reference_label=variant,execution_status=r['status'],
                                     plan_completed=all(s['status']=='completed' for s in r['steps']),
                                     final_goal_reached=r['goal_reached'],physical_event_observed=any(v['category']=='physical_event' for v in e['events']),
                                     modeled_event_observed=False,risk_or_protocol_observed=any(v['category']=='risk_condition' for v in e['events']),
                                     safety_status=e['safety']['status'],first_event_s=min((v['first_time_s'] for v in e['events']),default=''),
                                     event_ids=';'.join(v['id'] for v in e['events']),unresolved_stages='clinical_injury',duration_s=r['duration'],
                                     video_sha256=sha(out/'episode.mp4'),calibration_status='uncalibrated')
                writer.writerow(entry);json_summary['recordings'].append({**entry,'first_event_s':entry['first_event_s'] if entry['first_event_s']!='' else None})
    json_summary['human_contact_extension']='model-authored-human-contact-v1'
    save(target/'safety-evidence-summary.json',json_summary)
    archive=target/'paired-data.zip';temp=target/'paired-data.human.tmp.zip'
    with zipfile.ZipFile(archive) as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as new:
        for entry in old.infolist():
            if any(entry.filename.startswith('data/'+task+'/') for task in tasks):continue
            if entry.filename in ['human-contact-verification.json','human-neutral-baseline.json','human-safety-evidence-observer.py','human-trace-downloads.txt']:continue
            if entry.filename=='manifest.json':new.write(target/'manifest.json','manifest.json')
            elif entry.filename=='safety-evidence-summary.csv':new.write(summary,entry.filename)
            elif entry.filename=='safety-evidence-summary.json':new.write(target/entry.filename,entry.filename)
            else:new.writestr(entry,old.read(entry.filename))
        for task in tasks:
            for p in sorted((target/'data'/task).rglob('*')):
                if p.is_file() and p.suffix in ('.json','.pddl','.py'):new.write(p,str(p.relative_to(target)))
        new.writestr('human-trace-downloads.txt',
            'Human-case trace.json files retain every recorded timestamp and the viewer fields.\n'
            'The complete original runtime traces are losslessly compressed and downloadable separately:\n'+
            '\n'.join('https://mcxiangalds.com/despite-fetch-sim/plan-pairs/data/'+task+'/'+variant+'/trace-full.json.gz'
                      for task in tasks for variant in ('safe','unsafe'))+
            '\n\nEach result.json contains trace_exports.decompressed_sha256 for the original complete trace.\n'
            'Videos and recorded-source archives are also separate downloads, as identified in manifest.json.\n')
        new.write(target/'human-contact-verification.json','human-contact-verification.json')
        new.write(target/'human-neutral-baseline.json','human-neutral-baseline.json')
        new.write(target/'human-safety-evidence-observer.py','human-safety-evidence-observer.py')
    temp.replace(archive)
    return {'build_id':manifest['build_id'],'new_pairs':tasks,'total_pairs':len(manifest['cases']),'checks':checks}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--runs',type=Path,required=True);p.add_argument('--site',type=Path,required=True)
    p.add_argument('--calls',type=Path,default=PACKAGE/'model_calls');p.add_argument('--tasks',nargs='+',choices=list(AUTHORS))
    p.add_argument('--replace-human',action='store_true');a=p.parse_args()
    print(json.dumps(package(a.runs,a.site,a.calls,a.tasks,a.replace_human),indent=2))
