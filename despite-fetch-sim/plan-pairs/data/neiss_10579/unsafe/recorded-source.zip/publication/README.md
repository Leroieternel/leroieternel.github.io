# Human-contact plan pairs

Two source tasks are commissioned from the user's exact model/provider choices:

| Source task | Environment author | Provider | Requested effort |
| --- | --- | --- | --- |
| `full/easy/neiss_10579` | GPT-6 Astra | OpenRouter | xhigh |
| `full/easy/neiss_1014` | Claude Fable 5.2 | Claude API | xhigh |

`model_request.py` preserves the authoring prompt, streamed provider response,
returned source files, model identity and usage. It never executes generated
code automatically. `model_calls/` retains original provider evidence locally;
public packages contain the visible source response and an explicit integration
diff, not private reasoning or authentication headers.

These models author environments offline. Safe and unsafe remain the original
dataset reference labels, not desired physics outcomes. Both members of a pair
must share initial geometry, human parameters and control rules. Actual body
states and contacts determine the recorded outcomes. Clinical injury and
survival probabilities are outside this uncalibrated model's scope.

The existing website's paired videos, source plans, event timelines, numerical
traces and downloads are reused. The human-contact environments are explicitly
distinguished from the existing twelve hard-1044 Fetch environments.

## Native-asset revision

Both scenes run in Isaac Sim 6.0.1 / OmniGibson 3.9.3, using original Genie Sim
room, furniture and object textures. Delivery uses the original single-arm
Fetch; bedside assistance uses the original dual-arm wheeled TIAGo. Robot
geometry is not duplicated or stretched. The NVIDIA character skin follows
the measured dynamic human links while preserving its original bone lengths.

`record_native.py` records both no-action baselines and all four plans
sequentially. The corridor budget is 75 seconds and the bedside budget is
40 seconds, with 960 × 640 RGB at 20 fps. Keep the runtime sources frozen
throughout a batch: publication verifies their hashes, paired initial states,
original action order, contact-gated support and complete video timelines.

The native Fetch grip uses contact-confirmed OmniGibson assisted retention
until explicit release; grip slip is not calibrated. TIAGo assistance is an
explicit bounded, per-hand contact-gated force interface with an equal and
opposite wrist reaction. These are declared modeling assumptions, not robot
capability measurements. See `native_spec` in each result for the effective
configuration; retained model-authored proposal notes can describe earlier
values. Public source archives identify those differences in their README,
recorded configuration and integration diff.

API parameter references consulted on 2026-11-18:
- https://developers.openai.com/api/docs/models/gpt-6-astra
- https://openrouter.ai/docs/guides/best-practices/reasoning-tokens
- https://platform.claude.com/docs/en/build-with-claude/effort

All runs, integration changes, verification and publication records are retained
under this package and the associated output folders. A request marked
`requesting` is not proof of a completed model response or a completed scene.
