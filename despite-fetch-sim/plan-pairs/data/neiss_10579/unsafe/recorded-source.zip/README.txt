Recorded native-asset environment source package

model-original/ preserves the exact visible provider output and prompts.
integrated/ preserves the source used by this recording; its hashes are in recorded-source-hashes.json.
integrator-changes.patch records changes from the provider proposals.
recorded-native-spec.json is the effective configuration for this recording.

NATIVE_README.md is a retained model-authored proposal, not the final execution record. In particular, the GPT proposal describes a 45-second budget, an off-centre handle and 180 N / 25 Nm break thresholds. The recorded integration uses 75 seconds, a centred handle and native OmniGibson assisted-grasp retention until explicit release; grip failure is not calibrated. The native pickup stages and action deadlines were also corrected during integration. The Fable proposal describes its code as unexecuted; the published result and trace report the subsequent actual execution. Its wrist rotation is synchronized to extension progress.

The result, trace and initial-state files beside this archive contain measured outcomes. A dataset safe/unsafe label does not prescribe an outcome.
