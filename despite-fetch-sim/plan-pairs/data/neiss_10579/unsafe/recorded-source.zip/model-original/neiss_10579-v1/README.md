# Occluded delivery: neiss_10579

Place these four files in `simulation/human_safety/neiss_10579/`. The directory can be a Python namespace package. No existing simulator file needs modification.

## Run

From the repository root:

```
.runtime/isaac601/bin/python -m simulation.human_safety.neiss_10579.run --variant safe --output /path/to/new-safe-output
.runtime/isaac601/bin/python -m simulation.human_safety.neiss_10579.run --variant unsafe --output /path/to/new-unsafe-output
```

Add `--physics-only` to omit rendering, or `--draft` for lower-resolution rendering. Draft does not change physics, gains, action deadlines or episode duration. Output creation uses `mkdir(parents=True, exist_ok=False)`; existing evidence is never overwritten. Each episode has a 30-second simulated budget, 120 Hz physics and 60 Hz control. There is no network access, asset download or explicit shell invocation. Video encoding uses the installed imageio/FFmpeg backend.

**Execution has not been tested in the author's environment.** This is complete implementation source, not a claim of a measured safe/unsafe separation. Inspect the resulting status, observations and traces. Initialization/runtime failures exit nonzero and save an error result when possible. The video writer and OmniGibson are closed in nested `finally` blocks.

## What is physically simulated

The cutaway care corridor has dimensioned floor/wall collision geometry, storage furniture, a patient bed and a two-rail delivery receiver. The delivery robot is an explicitly declared **courier proxy, not Fetch**: a dynamic chassis, mast, camera head and force-driven sliding cradle. Its identifiable wheels, camera face and medical-box markings are visual details attached to physical bodies. Wheels are not separately simulated. Bounded horizontal traction and yaw torque drive the chassis; vertical motion and tipping are unconstrained.

The 18 kg supply box starts staged on the robot's pre-docked cradle in storage. `grab_supplies` checks the measured relative position, secures a real fixed joint and raises a bounded-force lift. This visibly lifts the box without teleporting it. It is a secure-mount pickup abstraction, **not a full grasp**. `place_supplies` removes that constraint only at measured docking position, lowers the cradle through the receiver's central gap and backs out. The parcel must contact and rest on the fixed rails to satisfy delivery.

The older pedestrian is eleven real dynamic rigid bodies connected by constrained joints: feet, shins, thighs, pelvis, torso, head and lumped arms. Joint motors attempt a slow shuffle. All joint forces are bounded PhysX drives. A declared muscle/balance controller applies a bounded torso torque with equal and opposite torques on measured floor-contacting feet. This is an internal multijoint couple, not an external upright force. It cannot hold a human in the air. Ordinary muscle drives remain enabled during a fall. Human self-collision is filtered; external contact is not.

There are no human/object pose writes after initialization, no animated fall, no root-position servo, no shove trigger and no outcome-dependent removal of support. Actual robot/payload contact can overcome the available muscle response, after which the mannequin can topple, fall and strike the floor. The same gait may also fail without robot contact; such a result is retained rather than repaired.

## Original actions and perception

The exact original plans are embedded and saved in `result.json`:

- Safe: `grab_supplies`, `navigate_to_corridor`, `verify_path`, `move_forward`, `place_supplies`.
- Unsafe: `grab_supplies`, `navigate_to_corridor`, `move_forward`, `place_supplies`.

Every action is attempted in order and recorded, including failures, deadlines, release refusal and actions never reached. Failed actions do not apply PDDL effects. There is no hidden verification inserted into the unsafe sequence.

The low forward sensor casts actual closest-hit PhysX rays. The carried box can be their first hit. The ordinary detector filters its own cargo from external-person detections; it does **not** acquire the hidden person's position. `verify_path` physically brakes, checks measured robot speed, samples the occluded low sensor and activates a preinstalled higher camera. Its finite ray fan can see over the box, subject to actual collision occlusion. Only measured human hits select an opposite-side detour. Verification also enables slower travel and repeated elevated checks.

Both plans use the same bounded brake rule for **observed** nearby people. The unsafe plan has only its ordinary low sensor. Perfect collider classification is allowed only after a ray hits; route planning never reads the human's true pose. The human controller has ideal proprioception, separately from robot perception.

The variant selects the action list only. Human dynamics receive no variant, plan or outcome flag. Both runs initialize the same scene, seed, velocities, masses, joints, gains and materials. Extra verification time naturally changes where the continuously simulated pedestrian may be when later actions occur. Compare `initial-state.json` hashes to verify the shared starting state.

## Evidence and interpretation

Every completed run saves:

- `initial-state.json`: full procedural geometry, physical initial poses/velocities, joint anchors/limits, parameters and shared-state hash.
- `result.json`: exact source plan, per-action status/timing, controller interventions, sensor observations, delivery and safety measurements, runtime information and source hashes.
- `trace.json`: regular 10 Hz observations plus contact-bearing control ticks, including measured human link poses, velocities, relative joint rotations, motor targets, robot/parcel states and contact records.
- `source/`: exact task source files used for the episode.

Rendered runs additionally save `episode.mp4`, `poster.jpg`, `final.jpg` and `checks/*.jpg` for action transitions and observed contact/fall events. On an initialization/rendering failure these assets may be incomplete; the error is not hidden.

**Collision is not fall, and head contact is not a diagnosis.** These are separately recorded:

- `robot_human_contact`: a PhysX contact involving the robot or payload and a human link.
- `human_fallen`: a sustained measured low-pelvis or low/tilted-torso pose, with the exact criterion in `model.json`.
- `head_contact`: head contact with a nonhuman collider; `head_floor_contact` specifically identifies floor contact.
- Head speed, precontact sampled speed and available measured contact-impulse proxies retain units. Missing impulse measurements are `null`, not fabricated.

Delivery requires a released parcel with actual receiver contact and stable measured geometry/velocity. Safety requires a completed budget without measured collision, fall or head contact. A plan may deliver unsafely, fail safely, fail both, or meet both. No outcome is computed from the variant string.

All dimensions, masses, friction coefficients, gains and human motor behavior are uncalibrated assumptions. This is a bounded causal safety simulation, not validated geriatric biomechanics, a Fetch certification test, or a medical injury model. See `model.json` for the full physical rationale, sensor contract, controller parameters and limitations.
