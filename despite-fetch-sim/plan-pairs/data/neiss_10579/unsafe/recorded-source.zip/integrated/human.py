"""Eleven dynamic links; bounded PhysX muscle drives and internal balance couples.
This module has no plan, variant, navigation, or outcome input.
"""
import math
import numpy as np
from scipy.spatial.transform import Rotation as R
from pxr import UsdPhysics


def human_layout():
    skin, sweater, trousers, shoes = [.72, .52, .39], [.39, .57, .57], [.22, .28, .36], [.20, .16, .13]
    rows = [
        ('h_pelvis', [.25, .08, .96], [.31, .23, .18], trousers, 10),
        ('h_torso', [.25, .08, 1.27], [.30, .25, .46], sweater, 24),
        ('h_head', [.25, .08, 1.66], [.26, .26, .26], skin, 4.6, 'Sphere'),
    ]
    for side, sign in [('left', -1), ('right', 1)]:
        x = .25 + sign * .12
        rows += [
            ('h_' + side + '_thigh', [x, .08, .73], [.105, .12, .40], trousers, 6),
            ('h_' + side + '_shin', [x, .08, .33], [.085, .10, .40], trousers, 3.6),
            ('h_' + side + '_foot', [x, .08, .075], [.17, .30, .11], shoes, 1.2),
            ('h_' + side + '_arm', [.25 + sign * .25, .08, 1.25], [.10, .11, .40], sweater, 2.2),
        ]
    return rows


class Mannequin:
    def __init__(self, state_reader, joint_factory, floor_contact_reader):
        self.state, self.contact = state_reader, floor_contact_reader
        self.names = [r[0] for r in human_layout()]
        self.masses = {r[0]: r[4] for r in human_layout()}
        self.joints, self.targets, self.balance_torque = {}, {}, [0., 0., 0.]
        self.balance_saturated_ticks = 0
        def add(name, a, b, anchor, limits, kp, kd, cap):
            joint = joint_factory(name, a, b, anchor, 'ball', limits)
            drives = []
            for axis in ['rotX', 'rotY', 'rotZ']:
                d = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), axis)
                d.CreateTypeAttr('force'); d.CreateStiffnessAttr(kp); d.CreateDampingAttr(kd)
                d.CreateMaxForceAttr(cap); d.CreateTargetPositionAttr(0.0); d.CreateTargetVelocityAttr(0.0)
                drives.append(d)
            self.joints[name] = (a, b, drives)
            self.targets[name] = [0., 0., 0.]
        add('waist', 'h_pelvis', 'h_torso', [.25, .08, 1.05], [[-40, 40], [-35, 35], [-35, 35]], 160, 18, 50)
        add('neck', 'h_torso', 'h_head', [.25, .08, 1.51], [[-50, 50], [-50, 50], [-65, 65]], 30, 3, 8)
        for side, sign in [('left', -1), ('right', 1)]:
            x, prefix = .25 + sign * .12, 'h_' + side + '_'
            add(side + '_hip', 'h_pelvis', prefix + 'thigh', [x, .08, .93], [[-60, 60], [-40, 40], [-25, 25]], 120, 12, 45)
            add(side + '_knee', prefix + 'thigh', prefix + 'shin', [x, .08, .53], [[-75, 10], [1, -1], [1, -1]], 140, 12, 40)
            add(side + '_ankle', prefix + 'shin', prefix + 'foot', [x, .08, .13], [[-45, 45], [-40, 40], [-20, 20]], 80, 8, 20)
            add(side + '_shoulder', 'h_torso', prefix + 'arm', [.25 + sign * .21, .08, 1.45], [[-80, 80], [-65, 65], [-50, 50]], 15, 2, 5)

    def control(self, t, torques):
        # Slow shuffling gait: stance leg sweeps backward; the other knee flexes.
        # These are motor targets, not prescribed body poses or foot trajectories.
        ramp = float(np.clip((t - 1) / 2, 0, 1))
        for side, offset in [('left', 0), ('right', math.pi)]:
            phase = 2 * math.pi * max(0, t - 1) / 3.2 + offset
            # Integration calibration: smaller shuffle avoids unsupported
            # single-leg excursions in the neutral no-robot baseline.
            knee = -.06 * max(0., -math.sin(phase)) * ramp
            hip = .015 * math.cos(phase) * ramp - .5 * knee
            values = {'hip': hip, 'knee': knee, 'ankle': -hip - knee}
            for joint, value in values.items():
                name = side + '_' + joint
                self.targets[name][0] = math.degrees(value)
                self.joints[name][2][0].GetTargetPositionAttr().Set(math.degrees(value))
        total_mass = sum(self.masses.values())
        com = sum(self.state(n)[0] * m for n, m in self.masses.items()) / total_mass
        velocity = sum(self.state(n)[2] * m for n, m in self.masses.items()) / total_mass
        feet = [n for n in self.names if n.endswith('_foot') and self.contact(n)]
        torque = np.zeros(3)
        if feet:
            support = np.mean([self.state(n)[0] for n in feet], axis=0)
            torso = self.state('h_torso')
            torque = -950 * R.from_quat(torso[1]).as_rotvec() - 110 * torso[3]
            torque += [420 * (com[1] - support[1]) + 65 * (velocity[1] - .025 * ramp),
                       -420 * (com[0] - support[0]) - 65 * velocity[0], 0]
            cap = 20.0 * len(feet)
            norm = float(np.linalg.norm(torque))
            self.balance_saturated_ticks += int(norm > cap)
            torque *= min(1., cap / max(norm, 1e-9))
            # Internal equal/opposite couple, not an external upright constraint.
            torques['h_torso'] += torque
            for n in feet: torques[n] -= torque / len(feet)
        self.balance_torque = torque.tolist()

    def measure(self):
        angles = {}
        for name, (a, b, _) in self.joints.items():
            relative = R.from_quat(self.state(a)[1]).inv() * R.from_quat(self.state(b)[1])
            angles[name] = np.degrees(relative.as_rotvec()).tolist()
        return dict(body_positions={n: self.state(n)[0].tolist() for n in self.names},
                    body_orientations_xyzw={n: self.state(n)[1].tolist() for n in self.names},
                    body_velocities_m_s={n: self.state(n)[2].tolist() for n in self.names},
                    joint_relative_rotation_vectors_deg=angles,
                    joint_motor_targets_deg={k: list(v) for k, v in self.targets.items()},
                    balance_torso_torque_N_m=list(self.balance_torque),
                    balance_saturation_ticks=self.balance_saturated_ticks)
