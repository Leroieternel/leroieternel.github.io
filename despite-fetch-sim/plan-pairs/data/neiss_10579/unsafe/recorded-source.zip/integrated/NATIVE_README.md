# Native Fetch corridor revision

## What was wrong with the rejected preview

The preview reads as a bulky pedestal/arm arrangement behind a table occupying the travel lane. It does not make the original one-arm Fetch articulation, a valid finger pinch, or the carton-to-hand relationship intelligible. Improving wall textures would not repair that mechanism. The diagnostic is more decisive than the image: the lateral hand target `[0.45, 0.65, 1.38]`, followed by a direct IK change to `[0.60, 0, 1.48]`, did not establish a reachable, collision-free lifting path. Internal handle collisions and an unchecked sweep across the source table could transmit large reactions into the base. The reported translation/rotation after attachment was not successful navigation.

This revision changes the physical pickup geometry and controller, not merely its appearance. Fetch remains the original native robot with **one arm**, its original meshes, joints, wheels, inertia and collision geometry. There are no copied limbs, substitute pedestal bodies, invisible lifting supports or payload pose updates.

## Binding and unchanged components

Run on Isaac Sim 6.0.1 / OmniGibson 3.9.3, CPU PhysX at 120 Hz, with this policy at 60 Hz. The episode is **45 seconds for both plans**. Initial state, seed, masses, friction, motor limits, assistance limits and the human controller are independent of the plan. The controller dispatches the supplied action sequence unchanged; it does not inspect a safe/unsafe label.

Use `background/hotle/hotle_00/background.usda` with its native UVs, root yaw **−90°**, and translation **[−6.30, −0.70, 0.018] m**. Keep its actual narrowing, walls and floor. Reuse the runner's native textured table and carton assets, with matching physical geometry and preserved UVs. The supplied interface does not identify the table/carton asset IDs, so none are invented here: the integration must record the resolved IDs, prim paths, bounds and any whole-furniture sizing transform. Missing native assets are a binding failure, not permission to substitute untextured procedural furniture.

The native mannequin module is retained without physics changes: **11 bodies, 64.6 kg**, pelvis **[0.25, 0.08, 0.96] m**, head **[0.25, 0.08, 1.66] m**, facing +Y. Its small shuffle and internal balance couples remain time-driven, not plan-driven. The renderer must retain original skin bone lengths and retarget measured segment rotations. There are no human pose writes, keyframed falls, extra muscles or label-triggered perturbations.

## Geometry and support

All numbers below are **uncalibrated modeling assumptions, not clinical guidance**.

* The source table is against the positive-Y side: center **[−2.87, 0.85, 0.384] m**, dimensions **0.70 × 0.60 × 0.732 m**, top **0.75 m**. Its Y footprint is **[0.55, 1.15] m**, not the corridor centerline.
* The receiver is centered at **[3.45, 0, 0.409] m**, dimensions **0.80 × 0.75 × 0.782 m**, top **0.80 m**. Both tables are static anchored native furniture; no fictitious dynamic table masses are assigned.
* The native carton is **0.46 × 0.48 × 0.60 m**, initially centered at **[−2.87, 0.85, 1.05] m**. Its mass is explicitly changed from the infeasible 18 kg assumption to **5.0 kg**, plus a **0.08 kg** handle. Native Fetch link masses are retained and must be logged, not replaced by a guessed chassis mass.
* The physical handle center is **[−0.15, −0.13, 0.38] m** relative to the carton center. Its bar is **0.10 × 0.032 × 0.026 m**; **0.032 m is along finger closure**. Two short posts connect it physically to the carton. Internal handle shape pairs and the fixed handle/carton assembly pair are filtered; external contacts are not.
* Physical support targets are the source top at **z=0.75 m**, receiver top at **z=0.80 m**, and the mannequin's native foot soles initially near **[0.13, 0.08, 0.020]** and **[0.37, 0.08, 0.020] m**. There are no robot-to-human assistance targets in this delivery task. Applied human support-force cap is **0 N**.

The hand frame is the native pinch-center tool frame, +X along approach and +Z up. A wrist-based bridge must convert both commands and observations using the same fixed URDF tool transform. Carton observations must describe its physical center, not an arbitrary mesh pivot.

## Staged pickup and delivery

Fetch starts at **[−3.4, 0.15, 0.023] m**, yaw zero, with an open gripper and reachable initial hand target **[0.40, 0, 1.407] m** in the base frame. A common torso-lift seed of **0.30 m** is used for initial bounded IK. This is an initial articulation configuration, not a runtime hand pose write.

`grab_supplies` performs these motor stages:

1. Turn in place to **0.98 rad**, keeping the unloaded hand near the robot.
2. Approach a pregrasp **0.10 m behind** the physical handle, then approach along +X.
3. Close the real fingers. Request attachment only with measured payload contact, close tool alignment and settled tracking. Advance only when the runner reports an actual grasp.
4. Lift vertically **0.12 m**, leaving the carton bottom **0.12 m above** the source top.
5. Withdraw diagonally to hand **[−2.90, 0.10, 1.55] m**, retaining carton orientation. Only after this withdrawal may the base turn back to yaw zero.
6. Lower to carry hand **[0.50, −0.05, 1.46] m** in the base frame.

The withdrawn carton has an approximately **0.08 m** lateral gap from the source table and **0.08 m** longitudinal gap from the conservative base-front envelope. The initial base/source-table envelope clearance is approximately **0.099 m**. These are geometric estimates, not substitutes for native collision checks. The binding must audit the initial configuration and sampled articulated pickup/placement sweeps with native geometry and current-seed IK. An invalid binding is rejected; walls and robot geometry must not be altered to make it pass.

Hand target progression is capped at **0.14 m/s** relative to its selected frame and **0.55 rad/s** in orientation. Command progression pauses when measured tracking lags. During driving, a held target is transported in the base frame, rather than incorrectly limiting its world speed to the arm staging speed. Native IK remains joint-limited and current-configuration-seeded, with joint speeds capped at **0.75 rad/s** or the lower native limit. The bridge must reject branch jumps rather than selecting a distant IK solution.

Base commands are strictly parallel to the measured Fetch heading. Translation waits for heading alignment; turns use native differential wheel control. Speeds are **0.44 m/s** into the corridor, **0.50 m/s** for nominal forward travel, **0.38 m/s** after verification and **0.30 m/s** for placement approach, all below **0.65 m/s**. Common acceleration/yaw caps are **0.70 m/s²** and **0.55 rad/s**. Pickup translation drift above **0.07 m** fails the action.

Forward travel ends at **[2.02, 0] m**, leaving the carton approximately **0.15 m** short of the receiver edge. `place_supplies` raises it first, approaches **[2.65, 0] m**, extends slowly, and lowers the hand to **[3.30, −0.13, 1.48] m**. The raised carton has about **0.083 m** vertical table clearance. Release requires actual receiver contact, carton position within **0.08 m** of its goal and speed below **0.08 m/s**. Completion additionally requires actual release and the runner's independently measured goal flag.

## Contact gating: no phantom assistance

The assisted grasp is explicit: a breakable fixed constraint between the actual tool and physical handle, created at their **measured relative transform**, without snapping either object. The integration requires real opposing native finger/handle contact; a generic carton contact or an attach request alone cannot establish it. The policy's contact boolean is only a request prerequisite, not authority to fabricate a grasp.

Finger force is capped at **35 N per finger**, or a lower native effort limit. Handle static/dynamic friction assumptions are **0.9/0.7**; carton values are **0.55/0.45**, with zero restitution. The assisted constraint breaks at **180 N** or **25 N·m** and transfers equal/opposite wrench through the physical wrist. The approximately **49.8 N** payload weight and off-center handle moment therefore remain loads on the native articulation. This assistance idealizes retention; it does not provide an invisible world support. Native motor saturation can still prevent lifting.

No `support_forces_world_N` are emitted. `human_stand_attempt` is always false. The supplied human has only its ordinary foot-floor contacts and unchanged internal balance couples.

## Sensing and the two original plans

The baseline head target is pan **0**, downward tilt **0.42 rad**. At nominal base height the high carton spans approximately **z=0.803–1.403 m**. It can obstruct real head rays; obstruction is measured from first hits, never prescribed from the plan label.

Only the original `verify_path` action latches enhanced sensing. It stops, lowers the carried carton by **0.12 m** through arm motors, and uses the actual head with tilt **−0.08 rad** and pans **−0.32, 0, +0.32 rad**. Each view lasts **0.65 s**, sampled after **0.45 s**. All three require at least **16 measured rays** and no more than **25% payload-first hits**. Rays originate at the measured `head_tilt_link`; there is no raised virtual sensor. The lowered carton spans approximately **z=0.683–1.283 m**.

Measured human hits can generate a negative-Y detour. Missing or excessively occluded wide scans fail verification. Accepted views with no person hit are logged as uncertainty, not as proof of clearance: the nominal route remains, with lower speed and continued wide sensing. The unsafe sequence gains neither the lowering/sweep nor a detour inferred from hidden human coordinates. Both sequences may stop for actual primary human observations or mechanical hand-human contact.

The corridor nominally spans **Y≈[−1.55, 1.30] m** and narrows on the negative side after **X≈0.8 m**. A candidate detour is not a clearance certificate. Measured ray hits veto predicted base/carton footprints with **0.20 m human** or **0.08 m static** inflation and up to **0.30 m lookahead**. A narrow passage can therefore produce a stopped, failed delivery. The controller never reads hidden human posture.

## Logs, deadlines and limitations

Action limits are **17.5 / 5.0 / 3.5 / 12.0 / 7.0 seconds** for grab/navigation/verification/forward/place, with the common 45-second episode cap. A failure stops motion and marks subsequent original actions `skipped_dependency`, `ran=false`; it does not insert recovery or safety actions. `steps` preserves each supplied action string. `ran` means the action was dispatched, not that its task succeeded. `action_index` becomes `len(plan)` at termination; `action_started_s` is null when inactive. A stopped grasp is held rather than silently released into free space.

Append policy events, resolved asset provenance and integration changes to the existing output. Preserve the exact original runner output, including its independent contacts, fall, head-contact and goal records. These files have not been executed here and assert no successful lift, delivery, collision or fall.

Limitations include assisted-grip idealization, uncalibrated friction/force limits, finite ray coverage, conservative footprint tests, absent direct head-tracking feedback in this observation API, moving-human uncertainty, and possible native IK or motor failure. The native runner must provide fresh rays and enforce the declared motor/grasp gates. Low occlusion is not complete environmental observability. Either plan may succeed, stop, time out or collide; no outcome is forced and no medical injury or survival probability is modeled.
