"""URDF IK for an intact native robot; candidate poses never touch physics."""
import math
import xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
from scipy.optimize import least_squares
from simulation.planning.model import transform


class ArmKinematics:
    def __init__(self, urdf, names, hand_link):
        self.path=Path(urdf);root=ET.parse(urdf).getroot()
        self.names=list(names);self.hand_link=hand_link;self.extra={};self.eef_offset=np.eye(4)
        self.joints=[];children=set()
        for node in root.findall('joint'):
            origin=node.find('origin');axis=node.find('axis');limit=node.find('limit')
            xyz=np.fromstring(origin.get('xyz','0 0 0'),sep=' ') if origin is not None else np.zeros(3)
            rpy=np.fromstring(origin.get('rpy','0 0 0'),sep=' ') if origin is not None else np.zeros(3)
            joint=dict(name=node.get('name'),kind=node.get('type'),parent=node.find('parent').get('link'),
                child=node.find('child').get('link'),origin=transform(xyz,R.from_euler('xyz',rpy).as_quat()),
                axis=np.fromstring(axis.get('xyz','1 0 0'),sep=' ') if axis is not None else np.array([1.,0,0]),
                lo=float(limit.get('lower',-math.pi)) if limit is not None else -math.pi,
                hi=float(limit.get('upper',math.pi)) if limit is not None else math.pi,
                velocity=float(limit.get('velocity',.5)) if limit is not None else .5)
            self.joints.append(joint);children.add(joint['child'])
        self.root=next(node.get('name') for node in root.findall('link') if node.get('name') not in children)
        self.by_name={j['name']:j for j in self.joints}
        by_child={j['child']:j for j in self.joints}
        self.hand_chain=[];link=self.hand_link
        while link in by_child:
            joint=by_child[link];self.hand_chain.append(joint);link=joint['parent']
        self.hand_chain.reverse()
        self.lower=np.array([self.by_name[n]['lo'] for n in self.names])
        self.upper=np.array([self.by_name[n]['hi'] for n in self.names])

    def fk(self,q,base=None):
        values={**self.extra,**dict(zip(self.names,q))}
        poses={self.root:np.eye(4) if base is None else base};remaining=list(self.joints)
        while remaining:
            pending=[]
            for j in remaining:
                if j['parent'] not in poses:pending.append(j);continue
                motion=np.eye(4);value=values.get(j['name'],0.)
                if j['kind'] in ('revolute','continuous'):motion[:3,:3]=R.from_rotvec(j['axis']*value).as_matrix()
                elif j['kind']=='prismatic':motion[:3,3]=j['axis']*value
                poses[j['child']]=poses[j['parent']]@j['origin']@motion
            if len(pending)==len(remaining):raise ValueError('Unrooted native URDF')
            remaining=pending
        poses['eef_link']=poses[self.hand_link]@self.eef_offset
        return poses

    def hand_fk(self,q):
        """The identical FK product restricted to the requested hand chain."""
        values={**self.extra,**dict(zip(self.names,q))};pose=np.eye(4)
        for j in self.hand_chain:
            motion=np.eye(4);value=values.get(j['name'],0.)
            if j['kind'] in ('revolute','continuous'):motion[:3,:3]=R.from_rotvec(j['axis']*value).as_matrix()
            elif j['kind']=='prismatic':motion[:3,3]=j['axis']*value
            pose=pose@j['origin']@motion
        return pose@self.eef_offset

    def ik(self,target,seed,attempts=4,validator=None):
        seed=np.clip(seed,self.lower+1e-6,self.upper-1e-6);rng=np.random.default_rng(42)
        starts=[seed]+[np.clip(seed+rng.normal(0,.45,len(seed)),self.lower+1e-6,self.upper-1e-6) for _ in range(attempts-1)]
        solutions=[]
        for initial in starts:
            def residual(q):
                hand=self.hand_fk(q)
                return np.r_[4*(hand[:3,3]-target[:3,3]),R.from_matrix(target[:3,:3].T@hand[:3,:3]).as_rotvec(),.002*(q-seed)]
            out=least_squares(residual,initial,bounds=(self.lower,self.upper),max_nfev=100,ftol=2e-6,xtol=2e-6,gtol=2e-6)
            hand=self.hand_fk(out.x)
            if np.linalg.norm(hand[:3,3]-target[:3,3])<.004 and R.from_matrix(target[:3,:3].T@hand[:3,:3]).magnitude()<.035:
                if validator is not None and not validator(out.x):continue
                solutions.append(out.x)
                if len(solutions)>=2:break
        return sorted(solutions,key=lambda q:np.linalg.norm(q-seed))


class NativeSelfCollision:
    """Conservative native collision hulls, evaluated without moving PhysX."""
    def __init__(self,robot,model):
        from pxr import Usd,UsdGeom,UsdPhysics
        import trimesh
        from simulation.planning.model import CollisionWorld
        cache=UsdGeom.XformCache();parts=[]
        for name,link in robot.links.items():
            inverse=np.linalg.inv(np.array(cache.GetLocalToWorldTransform(link.prim)).T)
            for prim in Usd.PrimRange(link.prim):
                if not prim.HasAPI(UsdPhysics.CollisionAPI):continue
                if UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is False:continue
                if prim.IsA(UsdGeom.Mesh):
                    mesh=UsdGeom.Mesh(prim);vertices=np.array(mesh.GetPointsAttr().Get())
                    indices=np.array(mesh.GetFaceVertexIndicesAttr().Get());faces=[];offset=0
                    for count in mesh.GetFaceVertexCountsAttr().Get():
                        faces.extend([[indices[offset],indices[offset+i],indices[offset+i+1]] for i in range(1,count-1)])
                        offset+=count
                elif prim.IsA(UsdGeom.Sphere):
                    mesh=trimesh.creation.icosphere(subdivisions=2,radius=float(UsdGeom.Sphere(prim).GetRadiusAttr().Get()))
                    vertices,faces=mesh.vertices,mesh.faces
                elif prim.IsA(UsdGeom.Cube):
                    mesh=trimesh.creation.box(extents=[float(UsdGeom.Cube(prim).GetSizeAttr().Get())]*3)
                    vertices,faces=mesh.vertices,mesh.faces
                elif prim.IsA(UsdGeom.Cylinder) or prim.IsA(UsdGeom.Capsule):
                    capsule=prim.IsA(UsdGeom.Capsule)
                    shape=UsdGeom.Capsule(prim) if capsule else UsdGeom.Cylinder(prim)
                    height,radius=float(shape.GetHeightAttr().Get()),float(shape.GetRadiusAttr().Get())
                    mesh=(trimesh.creation.capsule(height=height,radius=radius) if capsule else
                          trimesh.creation.cylinder(height=height,radius=radius,sections=24))
                    if capsule:mesh.apply_translation([0,0,-height/2])
                    axis=shape.GetAxisAttr().Get()
                    if axis=='X':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,1,0]))
                    elif axis=='Y':mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
                    vertices,faces=mesh.vertices,mesh.faces
                else:raise ValueError('Unsupported native collider '+str(prim.GetPath()))
                matrix=inverse@np.array(cache.GetLocalToWorldTransform(prim)).T
                vertices=np.asarray(vertices)@matrix[:3,:3].T+matrix[:3,3]
                parts.append(dict(link=name,path=str(prim.GetPath()),vertices=vertices.tolist(),faces=np.asarray(faces).tolist()))
        self.world=CollisionWorld(model,dict(world=[],robot=parts,disabled_pairs=robot.disabled_collision_pairs))
        self.world.lo=self.world.hi=np.empty((0,3))

    def valid(self,model,q):
        self.world.model=model
        if not self.world.valid(q,np.eye(4),margin=0.):return False
        # Leave a tracking buffer between Fetch's head and its overhead arm.
        # Native motor lag under the carried load consumes a zero-gap IK fit.
        head=[p for p in self.world.robot if p[2]=='head_tilt_link']
        upper=[p for p in self.world.robot if p[2] in ('upperarm_roll_link','forearm_roll_link')]
        return not any(self.world.colliding(a[0],b[0],.025) for a in head for b in upper)
