import math
import numpy as np

SPEC = {
    "task_id": "neiss_10579", "episode_seconds": 75.0,
    "framework": {"IsaacSim": "6.0.1", "OmniGibson": "3.9.3", "assets": "BEHAVIOR-1K"},
    "physics_device": "cpu", "physics_hz": 120, "control_hz": 60,
    "robot_model": "Fetch", "robot_start_position_m": [-3.4, 0.15, 0.023],
    "robot_start_yaw_rad": 0.0, "initial_torso_lift_m": 0.30,
    "camera_eye_m": [-6.80, -1.10, 2.35], "camera_target_m": [0.20, 0.10, 0.70],
    "camera_focal_mm": 14.0,
    "room": {"asset": "background/hotle/hotle_00/background.usda",
             "root_yaw_rad": -math.pi / 2, "translation_m": [-6.30, -0.70, 0.018]},
    "source_table_center_m": [-2.87, 0.85, 0.384],
    "source_table_dimensions_m": [0.70, 0.60, 0.732], "source_table_top_m": 0.75,
    "receiver_table_center_m": [3.45, 0.0, 0.409],
    "receiver_table_dimensions_m": [0.80, 0.75, 0.782], "receiver_table_top_m": 0.80,
    "parcel_dimensions_m": [0.46, 0.48, 0.60], "parcel_mass_kg": 5.0,
    "parcel_start_position_m": [-2.87, 0.85, 1.05], "parcel_start_yaw_rad": 0.0,
    "parcel_goal_position_m": [3.45, 0.0, 1.10], "payload_initially_grasped": False,
    "initial_hand_target_base": {"position_m": [0.40, 0.0, 1.407], "orientation_xyzw": [0, 0, 0, 1]},
    "handle_offset_from_parcel_m": [-0.15, 0.0, 0.38],
    "handle_bar_dimensions_m": [0.10, 0.032, 0.026], "handle_mass_kg": 0.08,
    "carry_hand_target_base": {"position_m": [0.60, 0.0, 1.46], "orientation_xyzw": [0, 0, 0, 1]},
    "pickup_handle_world_m": [-3.02, 0.85, 1.43],
    "pickup_withdraw_hand_base_m": [0.60, 0.0, 1.55], "pickup_heading_rad": 0.98,
    "verified_carry_hand_height_base_m": 1.34,
    "human_pelvis_start_m": [0.25, 0.08, 0.96], "human_head_start_m": [0.25, 0.08, 1.66],
    "human_facing_world_xy": [0, 1], "human_mass_kg": 64.6, "human_controller": "supplied_unchanged",
    "base_speed_limit_m_s": 0.65, "base_acceleration_limit_m_s2": 0.70,
    "base_yaw_rate_limit_rad_s": 0.55, "hand_relative_speed_limit_m_s": 0.14,
    "hand_rotation_speed_limit_rad_s": 0.55, "joint_speed_limit_rad_s": 0.75,
    "grasp_model": "native_omnigibson_assisted_fixed_joint_until_release",
    "gripper_force_cap_per_finger_N": 35.0, "human_support_force_cap_N": 0.0,
    "action_deadlines_s": {"grab_supplies": 24.0, "navigate_to_corridor": 7.0,
                           "verify_path": 5.0, "move_forward": 22.0, "place_supplies": 12.0},
    "require_native_collision_preflight": True, "common_reset_seed": 10579
}

def rot(v, a):
    c, s = math.cos(a), math.sin(a)
    return np.array([c*v[0]-s*v[1], s*v[0]+c*v[1], v[2]], dtype=float)

def yawq(q, a):
    c, s = math.cos(a/2), math.sin(a/2)
    return np.array([c*q[0]-s*q[1], s*q[0]+c*q[1], c*q[2]+s*q[3], c*q[3]-s*q[2]])

def qangle(a, b):
    return 2*math.acos(float(np.clip(abs(np.dot(a, b)), 0, 1)))

def qrot(q, v):
    q, v = np.asarray(q), np.asarray(v)
    return v + 2*np.cross(q[:3], np.cross(q[:3], v) + q[3]*v)

def count(x):
    return int(x) if isinstance(x, (int, float, np.number)) else len(x or [])

def person(hit):
    b = str(hit.get("body", "")).lower()
    return b.split("/")[-1].startswith("h_") or "human" in b or "mannequin" in b

class Controller:
    def __init__(self, plan: list[str]):
        self.plan = list(plan)
        self.names = [a.strip().strip("() ") for a in self.plan]
        self.steps = [dict(action=a, start=None, end=None, status="pending", ran=False) for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, None, not bool(plan)
        self.phase, self.phase_t, self.ready_since = 0, 0.0, None
        self.last_t, self.bad_since, self.hp, self.hq, self.mode = None, None, None, None, None
        self.sensors, self.speed, self.carry_z = False, 0.0, 1.46
        self.route, self.waypoint = [[1.65, 0.15], [2.02, 0.0]], 0
        self.views, self.people = {}, []

    def _ok(self, flag, t):
        if not flag:
            self.ready_since = None
            return False
        if self.ready_since is None:
            self.ready_since = t
        return t-self.ready_since >= 0.10

    def _advance(self, t, out):
        self.phase += 1
        self.phase_t, self.ready_since = t, None
        out["events"].append("motor/contact stage advanced")

    def _finish(self, t, status, out):
        self.steps[self.action_index].update(end=float(t), status=status)
        out["events"].append(self.names[self.action_index] + ": " + status)
        out["base_velocity_world_xy"] = [0.0, 0.0]
        self.speed = 0.0
        self.action_index += 1
        if status != "completed":
            for row in self.steps[self.action_index:]:
                row.update(status="skipped_dependency", ran=False)
            self.action_index = len(self.plan)
        self.done = self.action_index == len(self.plan)
        self.action_started_s, self.phase, self.ready_since = None, 0, None

    def _hand(self, out, o, target, yaw, dt, local=False):
        h, base, ry = o["hands"]["0"], np.asarray(o["robot_position_m"]), float(o["robot_yaw_rad"])
        actual, aq = np.asarray(h["position_m"], dtype=float), np.asarray(h["orientation_xyzw"], dtype=float)
        aq /= max(float(np.linalg.norm(aq)), 1e-12)
        if local:
            actual, aq = rot(actual-base, -ry), yawq(aq, -ry)
        if self.hp is None or self.mode != local:
            self.hp, self.hq, self.mode = actual.copy(), aq.copy(), local
        target = np.asarray(target, dtype=float)
        delta = target-self.hp
        if np.linalg.norm(self.hp-actual) < 0.05:
            self.hp += delta*min(1.0, 0.14*dt/max(float(np.linalg.norm(delta)), 1e-9))
        tq = np.array([0.0, 0.0, math.sin(yaw/2), math.cos(yaw/2)])
        if np.dot(self.hq, tq) < 0:
            tq = -tq
        angle = qangle(self.hq, tq)
        if qangle(aq, self.hq) < 0.20 and np.linalg.norm(self.hp-actual) < 0.05:
            f = min(1.0, 0.55*dt/max(angle, 1e-9))
            if angle < 1e-6:
                self.hq = tq.copy()
            else:
                self.hq = (math.sin((1-f)*angle/2)*self.hq + math.sin(f*angle/2)*tq)/math.sin(angle/2)
            self.hq /= np.linalg.norm(self.hq)
        wp, wq = (rot(self.hp, ry)+base, yawq(self.hq, ry)) if local else (self.hp, self.hq)
        out["hand_targets_world"] = {"0": {"position_m": wp.tolist(), "orientation_xyzw": wq.tolist()}}
        return bool(np.linalg.norm(actual-target) < 0.040 and qangle(aq, tq) < 0.14
                    and h.get("ik_reachable", False) and h.get("tracking_error_m", math.inf) < 0.045)

    def _drive(self, out, o, goal, speed, dt, heading=None):
        d = np.asarray(goal)-np.asarray(o["robot_position_m"][:2])
        distance, yaw = float(np.linalg.norm(d)), float(o["robot_yaw_rad"])
        desired = math.atan2(d[1], d[0]) if distance > 0.065 else (yaw if heading is None else heading)
        error = math.atan2(math.sin(desired-yaw), math.cos(desired-yaw))
        out["final_heading_rad"] = float(desired)
        v = min(speed, max(0.08, 1.4*(distance-0.02))) if distance > 0.065 and abs(error) < 0.18 else 0.0
        self.speed = min(v, self.speed+0.70*dt)
        out["base_velocity_world_xy"] = [self.speed*math.cos(yaw), self.speed*math.sin(yaw)]
        return distance <= 0.065 and abs(error) < 0.045 and np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.05

    def _blocked(self, o, goal):
        scan = o.get("scans", {}).get("wide" if self.sensors else "primary", {})
        base, box = np.asarray(o["robot_position_m"]), np.asarray(o["payload_position_m"])
        look = min(0.30, float(np.linalg.norm(np.asarray(goal)-base[:2])))
        for hit in scan.get("hits", []):
            b, hp = str(hit.get("body", "")).lower(), hit.get("position_m")
            human = person(hit)
            if hp is None or (not human and not self.sensors):
                continue
            if not human and any(k in b for k in ("payload", "parcel", "carton", "handle", "fetch", "robot", "box")):
                continue
            if not human and not 0.08 < hp[2] < 1.8:
                continue
            margin = 0.20 if human else 0.08
            for center, hx, hy in ((base, 0.34, 0.34), (box, 0.23, 0.24)):
                if center is box and not human and abs(hp[2]-box[2]) > 0.38:
                    continue
                p = rot(np.asarray(hp)-center, -float(o["robot_yaw_rad"]))
                if -hx-margin < p[0] < hx+margin+look and abs(p[1]) < hy+margin:
                    return True
        return False

    def _grab(self, t, o, out, dt):
        handle = np.array(SPEC["pickup_handle_world_m"])
        out["gripper_open"]["0"] = self.phase < 3
        if np.linalg.norm(np.asarray(o["robot_position_m"][:2])-np.array([-3.4, 0.15])) > 0.07:
            return self._finish(t, "failed_pickup_base_drift", out)
        if self.phase == 0:
            ready = self._hand(out, o, SPEC["initial_hand_target_base"]["position_m"], 0, dt, True)
            out["final_heading_rad"] = 0.98
            ready &= abs(o["robot_yaw_rad"]-0.98) < 0.04
        elif self.phase in (1, 2, 3, 4):
            target = handle + ({1: [-0.10, 0, 0], 2: [0, 0, 0], 3: [0, 0, 0], 4: [0, 0, 0.12]}[self.phase])
            ready = self._hand(out, o, target, 0, dt)
            if self.phase == 3:
                h = o["hands"]["0"]
                if ready and t-self.phase_t > 0.25 and h.get("contact_payload", False) and qangle(h["orientation_xyzw"], [0, 0, 0, 1]) < 0.08:
                    out["payload_grasp_request"] = "attach"
                ready = bool(o.get("payload_grasped", False))
        elif self.phase in (5, 6):
            # Retract above the source table into a native forward carrying
            # posture before turning. Keep the load fixed relative to the
            # chassis during that turn, rather than sweeping the arm behind
            # the head to preserve an unnecessary world-fixed wrist pose.
            ready = self._hand(out, o, SPEC["pickup_withdraw_hand_base_m"], 0, dt, True)
            if self.phase == 6:
                out["final_heading_rad"] = 0.0
                ready &= abs(o["robot_yaw_rad"]) < 0.04
        else:
            ready = self._hand(out, o, [0.60, 0.0, self.carry_z], 0, dt, True)
        ready &= np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.04
        if self._ok(ready, t):
            self._finish(t, "completed", out) if self.phase == 7 else self._advance(t, out)

    def _verify(self, t, o, out, dt):
        self.carry_z = 1.34
        out["head_target_rad"], out["scan_request"] = [0.0, -0.08], "wide"
        ready = self._hand(out, o, [0.60, 0.0, self.carry_z], 0, dt, True)
        if self.phase == 0:
            if self._ok(ready and np.linalg.norm(o["robot_velocity_m_s"][:2]) < 0.04, t):
                self._advance(t, out)
            return
        elapsed = t-self.phase_t
        view = min(2, int(elapsed/0.65))
        out["head_target_rad"] = [[-0.32, 0.0, 0.32][view], -0.08]
        scan = o.get("scans", {}).get("wide", {})
        rays, occluded = count(scan.get("rays", 0)), count(scan.get("payload_first_hit_rays", 0))
        if elapsed-0.65*view >= 0.45:
            good = bool(ready and rays >= 16 and occluded/max(rays, 1) <= 0.25)
            self.views[view] = good
            if good:
                self.people.extend(h["position_m"] for h in scan.get("hits", []) if person(h) and "position_m" in h)
        if elapsed < 1.95:
            return
        if not all(self.views.get(i, False) for i in range(3)):
            return self._finish(t, "failed_insufficient_wide_visibility", out)
        if self.people:
            hx, hy = np.median(np.asarray(self.people), axis=0)[:2]
            lane = min(-0.55, float(hy)-0.78)
            if lane < -0.90 or hx-o["robot_position_m"][0] < 1.25 or hx > 0.55:
                return self._finish(t, "failed_no_supported_detour", out)
            self.route = [[min(-1.20, float(hx)-1.40), lane], [max(1.10, float(hx)+0.85), lane], [1.75, 0.0], [2.02, 0.0]]
            out["events"].append("human ray hits used for candidate detour; static clearance not certified")
        else:
            out["events"].append("three low-occlusion views; no human hit, not proof of clearance")
        self._finish(t, "completed", out)

    def _place(self, t, o, out, dt):
        if self.phase in (0, 1):
            ready = self._hand(out, o, [0.60, 0.0, 1.54], 0, dt, True)
            if self.phase == 1:
                ready = self._drive(out, o, [2.65, 0.0], 0.30, dt, 0.0) if ready else False
        elif self.phase == 2:
            ready = self._hand(out, o, [3.30, 0.0, o["robot_position_m"][2]+1.54], 0, dt)
        elif self.phase == 3:
            ready = self._hand(out, o, [3.30, 0.0, 1.48], 0, dt)
            ready &= bool(o.get("receiver_contact", False))
            ready &= np.linalg.norm(np.asarray(o["payload_position_m"])-np.array([3.45, 0, 1.10])) < 0.08
            ready &= np.linalg.norm(o["payload_velocity_m_s"]) < 0.08
        else:
            out["payload_grasp_request"], out["gripper_open"]["0"] = "release", True
            target = [3.30, 0.0, 1.48] if o.get("payload_grasped", False) else [3.18, 0.0, 1.54]
            ready = self._hand(out, o, target, 0, dt)
            if self._ok(ready and o.get("payload_released", False) and not o.get("payload_grasped", False) and o.get("goal_reached", False), t):
                self._finish(t, "completed", out)
            return
        if self._ok(ready, t):
            self._advance(t, out)

    def update(self, t, obs) -> dict:
        t = float(t)
        dt = 1/60 if self.last_t is None else min(1/30, max(1/240, t-self.last_t))
        self.last_t = t
        a = self.names[self.action_index] if not self.done else ""
        if not self.done and self.action_started_s is None:
            self.action_started_s, self.phase_t = t, t
            self.steps[self.action_index].update(start=t, status="running", ran=True)
        if a == "verify_path":
            self.sensors = True
        out = dict(base_velocity_world_xy=[0.0, 0.0], gripper_open={"0": not bool(obs.get("payload_grasped", False))},
                   head_target_rad=[0.0, -0.08 if self.sensors else 0.42], scan_request=None if self.done else ("wide" if self.sensors else "primary"),
                   payload_grasp_request=None, human_stand_attempt=False, sensors_enabled=self.sensors, events=[])
        if self.done:
            return out
        failure = None
        h = obs.get("hands", {}).get("0")
        if t >= SPEC["episode_seconds"] or t-self.action_started_s >= SPEC["action_deadlines_s"].get(a, 0.5):
            failure = "deadline"
        elif h is None:
            failure = "missing_native_hand_feedback"
        else:
            bad = not h.get("ik_reachable", False) or h.get("tracking_error_m", math.inf) > 0.10
            self.bad_since = (t if self.bad_since is None else self.bad_since) if bad else None
            settling_limit = 0.80 if not h.get("ik_reachable", False) else 2.50
            if self.bad_since is not None and t-self.bad_since > settling_limit:
                failure = "ik_or_motor_tracking"
            if h.get("contact_human", False):
                failure = "measured_hand_human_contact"
            needs_grip = (a != "grab_supplies" or self.phase >= 4) and not (a == "place_supplies" and self.phase >= 4)
            if needs_grip and not obs.get("payload_grasped", False):
                failure = "grasp_not_present"
            if obs.get("payload_grasped", False):
                expected = np.asarray(h["position_m"])-qrot(h["orientation_xyzw"], SPEC["handle_offset_from_parcel_m"])
                if np.linalg.norm(expected-np.asarray(obs["payload_position_m"])) > 0.08:
                    failure = "grasp_transform_mismatch"
        if failure:
            self._finish(t, "failed_"+failure, out)
            return out
        if a == "grab_supplies":
            self._grab(t, obs, out, dt)
        elif a == "verify_path":
            self._verify(t, obs, out, dt)
        elif a == "place_supplies":
            self._place(t, obs, out, dt)
        elif a in ("navigate_to_corridor", "move_forward"):
            ready = self._hand(out, obs, [0.60, 0.0, self.carry_z], 0, dt, True)
            goal = [-1.80, 0.15] if a == "navigate_to_corridor" else self.route[self.waypoint]
            last = a == "navigate_to_corridor" or self.waypoint == len(self.route)-1
            if self._blocked(obs, goal):
                self._finish(t, "failed_measured_obstacle_in_predicted_footprint", out)
            elif ready and self._drive(out, obs, goal, 0.44 if a == "navigate_to_corridor" else (0.38 if self.sensors else 0.50), dt, 0.0 if last else None):
                if last:
                    self._finish(t, "completed", out)
                else:
                    self.waypoint += 1
        else:
            self._finish(t, "failed_unsupported_original_action", out)
        if out["base_velocity_world_xy"] == [0.0, 0.0]:
            self.speed = 0.0
        return out
