"""Validate original plans, matched interventions and separated evidence types."""
import argparse
import hashlib
import json
from pathlib import Path
from simulation.initial_state_check import compare_initial_states
from simulation.planning.audit import audit_run


def verify(root, require_demo_outcomes=False):
    records=[];reports=[]
    for variant in ('safe','unsafe'):
        folder=root/('neiss_2888-'+variant)
        r=json.loads((folder/'result.json').read_text());t=json.loads((folder/'trace.json').read_text())
        c=r['consequence_simulation'];events=c['events'];cfg=c['config']['rule']
        assert r['status']=='completed',r.get('error')
        assert r['variant']==variant and r['grasping_mode']=='physical'
        source=json.loads((Path(__file__).resolve().parents[1]/'tasks/provenance.json').read_text())
        expected=next(x for x in source['tasks'] if x['id']=='neiss_2888')['plans'][variant]
        assert r['plan']==expected
        assert c['outcome_reads_reference_label'] is False
        assert r['spec']['danger_consequence']['reference_label_input'] is False
        trigger=next((e for e in events if e['type']=='edge_threshold_disturbance_requested'),None)
        gravity=cfg.get('mode')=='gravity_overhang'
        release=c.get('release_state')
        free=c.get('first_free_state')
        if gravity:
            assert trigger is None and cfg['force_n']==0
            assert c['external_force_api_applied'] is False
            assert not any('disturbance' in e['type'] for e in events)
            assert release and free and free['t']>=release['t']
            assert release['step_index']==2 and release['action']==r['plan'][2]
        if trigger:
            assert trigger['edge_margin_m']<cfg['threshold_m']
            assert trigger['step_index']==2 and trigger['action']==r['plan'][2]
            assert trigger['basis']=='declared_rule_intervention'
        for sample in t:
            m=sample['metrics']
            assert abs(m['rule_liquid_remaining_ml']+m['rule_liquid_spilled_ml']-cfg['initial_liquid_ml'])<.002
            assert abs(m['rule_liquid_airborne_ml']+m['rule_liquid_floor_ml']+m['rule_liquid_support_ml']-m['rule_liquid_spilled_ml'])<.002
            assert 'spilled_volume_ml' not in m,'Modeled spill was mislabeled as measured PBD volume'
            if not cfg['container_open'] or cfg['initial_liquid_ml']==0:
                assert m['rule_liquid_spilled_ml']==0
        assert bool(trigger)==r['metrics']['rule_triggered']
        if r['metrics']['physical_fallen']:
            assert any(s['object']['p'][2]<r['spec']['support_top']-.08 for s in t)
            assert any(e['type']=='physical_fall_observed' for e in events)
        # A configuration sweep must be allowed to contradict the source label.
        # Expected outcomes are an explicit regression check for this one demo,
        # never a precondition for accepting other threshold/cap/force settings.
        if require_demo_outcomes:
            if variant=='safe':
                assert trigger is None and r['goal_reached']
                assert not r['metrics']['physical_fallen'] and r['metrics']['rule_liquid_spilled_ml']==0
                if gravity:assert release['com_support_margin_m']>0
            else:
                assert r['metrics']['physical_fallen'] and not r['goal_reached']
                assert r['metrics']['rule_liquid_spilled_ml']>1 and r['metrics']['rule_liquid_floor_ml']>1
                if gravity:
                    assert release['com_support_margin_m']<0 and free['com_support_margin_m']<0
                    fallen=next(e for e in events if e['type']=='physical_fall_observed')
                    assert 0<fallen['t']-release['t']<2.,'Fall must follow release, not a delayed intervention'
                    falling=[s for s in t if free['t']<=s['t']<=fallen['t']]
                    assert falling and all(not s['metrics']['robot_contact'] for s in falling),'Robot recontacted bottle before fall'
                    assert any(s['metrics']['support_contact'] and s['metrics']['com_support_margin_m']<0 for s in falling),'Missing unstable support contact before fall'
                    cause_t=release['t']
                else:
                    assert trigger
                    cause_t=trigger['t']
                for sample in t:
                    if sample['t']<cause_t:
                        assert not sample['metrics']['physical_fallen'] and sample['metrics']['rule_liquid_spilled_ml']==0
        motion=audit_run(folder)
        assert abs(c['floor_film']['volume_error_ml'])<1e-7
        assert abs(c['table_film']['volume_error_ml'])<1e-7
        assert abs(c['floor_film']['film_volume_ml']-r['metrics']['rule_liquid_floor_ml'])<.002
        assert abs(c['table_film']['film_volume_ml']-r['metrics']['rule_liquid_support_ml'])<.002
        reports.append({'variant':variant,'status':r['status'],'goal_reached':r['goal_reached'],
            'physical_fall_observed':r['metrics']['physical_fallen'],
            'modeled_spill_ml':r['metrics']['rule_liquid_spilled_ml'],
            'trigger':trigger,'release_state':release,'first_free_state':free,'motion_audit':motion,
            'video_sha256':hashlib.sha256((folder/'episode.mp4').read_bytes()).hexdigest() if (folder/'episode.mp4').exists() else None})
        records.append(r)
    assert records[0]['simulation_code_sha256']==records[1]['simulation_code_sha256']
    assert records[0]['spec']==records[1]['spec']
    initial=compare_initial_states(*records)
    return {'revision':'physical-release-audit-v3','initial_state_check':initial,'records':reports,
            'demo_outcomes_required':require_demo_outcomes,
            'calibration_status':'uncalibrated','interpretation':('Authored unstable edge placement; no external disturbance; measured rigid-body fall.' if gravity else 'Authored threshold disturbance; measured rigid-body fall;')+' Reduced-order liquid visualization. Not a calibrated failure probability.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('runs',type=Path);p.add_argument('--output',type=Path)
    p.add_argument('--require-demo-outcomes',action='store_true')
    a=p.parse_args();r=verify(a.runs,a.require_demo_outcomes);text=json.dumps(r,indent=2)+'\n'
    if a.output:a.output.write_text(text)
    print(text)
