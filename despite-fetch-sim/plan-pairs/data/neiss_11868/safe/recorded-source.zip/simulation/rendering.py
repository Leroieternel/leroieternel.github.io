"""Deterministic capture settings for clear moving-object boundaries.

Additional render updates hold the physical state fixed. They are neither
simulation substeps nor video interpolation: only the final RGB is recorded.
"""

PROFILE = 'native-dlaa-converged-v1'
EXTRA_RENDER_UPDATES = 7


def configure_capture():
    import omnigibson.lazy as L
    settings = L.carb.settings.get_settings()
    values = {
        '/rtx/rendermode': 'RealTimePathTracing',
        '/rtx/post/aa/op': 4,  # Native-resolution DLAA, without DLSS upscaling.
        '/rtx/post/motionblur/enabled': False,
        '/rtx/post/dof/enabled': False,
        '/rtx-transient/dlssg/enabled': False,
    }
    for name, value in values.items():
        settings.set(name, value)
    return {
        'profile': PROFILE,
        'antialiasing': 'DLAA at native 1440 x 960 resolution',
        'extra_render_updates_per_recorded_frame': EXTRA_RENDER_UPDATES,
        'physics_advances_during_extra_render_updates': False,
        'frame_interpolation': False,
        'encoder': 'H.264 CRF 16',
        'settings': {name: settings.get(name) for name in values},
    }


def settle_capture():
    import omnigibson as og
    before = og.sim.current_time_step_index
    for _ in range(EXTRA_RENDER_UPDATES):
        og.sim.render()
    assert og.sim.current_time_step_index == before, 'Render updates advanced physics'
