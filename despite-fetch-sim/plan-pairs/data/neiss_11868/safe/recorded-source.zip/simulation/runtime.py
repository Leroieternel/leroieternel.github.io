"""Configure OmniGibson before its first import."""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".runtime"


def configure(headless=True):
    os.environ.setdefault("OMP_NUM_THREADS", "8")
    os.environ.setdefault("OMNI_KIT_ACCEPT_EULA", "YES")
    os.environ.setdefault("OMNIGIBSON_DATA_PATH", str(RUNTIME / "datasets"))
    os.environ.setdefault("OMNIGIBSON_APPDATA_PATH", str(RUNTIME / "appdata"))
    os.environ.setdefault("OMNIGIBSON_HEADLESS", str(headless))
    os.environ.setdefault("OMNIGIBSON_NO_OMNI_LOGS", "True")
