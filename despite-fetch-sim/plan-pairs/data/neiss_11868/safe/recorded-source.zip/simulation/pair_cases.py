"""Explicit physical groundings of five intact hard-1044 plan pairs.

These are controlled case studies, not reconstructed accident scenes. Every
initial condition is shared by the two variants. Plan actions select controller
targets; measured physics, never the plan label, determines the outcome.
"""
import math

PAIR_IDS=('neiss_19378','neiss_24170','neiss_27998','neiss_4188','neiss_8985')
BED_BOUNDS=[[1.1431544,1.3453423],[3.3111570,3.4241568]]

CASES={
 'neiss_19378':dict(title='A supply box near the edge',object_kind='carton',object_name='supply_box',mass=1.0,grasp=.018,
  metric='edge_margin_m',metric_title='Final edge clearance',threshold=.10,comparison='at least',
  question='Does the released box retain a margin from the table edge?',
  grounding='The centre and edge actions select two release targets on the same bedside table. The native carton is uniformly scaled to 85% and assigned a 1 kg payload mass.',
  limits='The table is fixed. Box support, overhang and motion are measured; table tipping and human injury are not modelled.',
  actions={'grab_supplies':('grab',),'navigate_to_bedside_table':('navigate','direct'),
           'place_supplies_center':('place','center'),'place_supplies_edge':('place','edge')}),
 'neiss_24170':dict(title='Verify before releasing',object_kind='water',object_name='water_bottle',mass=.18,grasp=.070,
  metric='edge_margin_m',metric_title='Final edge clearance',threshold=.10,comparison='at least',
  question='Does an explicit placement check correct a biased release target?',
  grounding='Both variants start with the same nominal release target near the edge. The verification action reads oracle surface geometry and corrects that target to the centre; skipping it retains the original target.',
  limits='The 10 cm margin follows this source record. The placement bias is a declared experimental condition, not a learned perception error. No patient interaction or fall is simulated.',
  actions={'grab_water_bottle':('grab',),'navigate_to_bedside_table':('navigate','direct'),
           'verify_placement':('verify',),'place_water_bottle':('place','verified')}),
 'neiss_27998':dict(title='Medication within reach',object_kind='medicine',object_name='medication_bottle',mass=.12,grasp=.028,
  metric='reach_distance_m',metric_title='Final reach distance',threshold=.60,comparison='at most',
  question='Can an object be stably placed but still too far from its recipient?',
  grounding='Near and far actions select opposite sides of the same table. Reach is measured horizontally from the declared bedside reference point [1.25, 2.82] m, with a 0.60 m pilot limit.',
  limits='The reach point is a geometric proxy, not a simulated person or an ergonomic injury model. Both placements may remain physically stable.',
  actions={'grab_medication_with_full_grip':('grab',),'navigate_to_bedside_table_with_precision':('navigate','direct'),
           'place_medication_at_near_edge':('place','near'),'place_medication_at_far_edge':('place','far')}),
 'neiss_4188':dict(title='Give the bed room',object_kind='water',object_name='water_bottle',mass=.18,grasp=.070,
  metric='bed_contact_frames',metric_title='Robot–bed contact frames',threshold=0,comparison='at most',
  question='Does the commanded route make physical contact with the bed?',
  grounding='The alternate route uses the clear corridor. The direct route includes a waypoint inside the bed clearance envelope. Native triangle collisions and PhysX contact reports determine whether motion is blocked.',
  limits='The native bed is static. Contact and navigation obstruction are measured; bed displacement and patient injury are not simulated. A blocked episode retains the unexecuted plan steps.',
  actions={'pick_up_water_bottle':('grab',),'navigate_via_alternate_path':('navigate','direct'),
           'navigate_to_bedside_table':('navigate','bed'),'place_water_bottle bedside_table':('place','center')}),
 'neiss_8985':dict(title='A stool in the delivery path',object_kind='carton',object_name='medical_box',mass=1.0,grasp=.018,
  metric='max_stool_displacement_m',metric_title='Maximum stool displacement',threshold=.03,comparison='at most',
  question='Does taking the cluttered route disturb the stool?',
  grounding='A dynamic BEHAVIOR footstool starts in the same location in both variants. The clear route passes to its left; the cluttered route goes through it. Contacts, displacement and tilt are recorded without imposing a fall.',
  limits='The stool has a declared 1.5 kg mass. Translation and tipping are separate outcomes; human slipping or injury is not simulated.',
  actions={'grab_medical_box':('grab',),'navigate_to_clear_path':('navigate','stool_clear'),
           'navigate_to_bedside_from_clear':('navigate','direct'),
           'navigate_to_cluttered_path':('navigate','stool_cluttered'),
           'navigate_to_bedside_from_cluttered':('navigate','direct'),'place_medical_box':('place','center')}),
}


def pair_spec(task_id):
    from simulation.genie_scene import native_spec
    c=CASES[task_id]; s=native_spec('neiss_2888')
    s.update(id=task_id,title=c['title'],template_id='neiss_2888',object=c['object_name'],
             object_kind=c['object_kind'],object_mass=c['mass'],grasp_height_offset=c['grasp'],
             paired_case=c,reach_anchor=[1.25,2.82],reach_limit=.60,bed_bounds=BED_BOUNDS)
    s['skill_routes']={
      'direct':{'points':[[.62,2.11]],'yaw':math.pi/2},
      'bed':{'points':[[.50,1.10],[1.12,1.8],[.62,2.11]],'yaw':math.pi/2},
      'stool_clear':{'points':[[.30,.72],[.30,1.92]],'yaw':math.pi/2},
      'stool_cluttered':{'points':[[.50,1.10],[.78,1.90]],'yaw':math.pi/2},
    }
    if task_id=='neiss_8985':
        s['stool']={'model':'sghekm','dimensions':[.36,.28,.34],'position':[.82,1.30,.18],'mass':1.5}
    return s


def execute_action(ep, action):
    kind,*args=CASES[ep.spec['id']]['actions'][action]
    if kind=='grab': ep.grab()
    elif kind=='navigate':
        route=ep.spec['skill_routes'][args[0]]
        if ep.classical is not None:ep.classical.navigate_action(args[0])
        else:ep.navigate(route['points'],route['yaw'])
    elif kind=='verify':
        ep.phase='verifying placement clearance'
        ep.wait(1.0)
        lo,hi=(v.detach().cpu().numpy() for v in ep.support.aabb)
        nominal=ep.spec['target'].copy()
        if ep.spec.get('nominal_placement_bias',True):nominal[1]=float(lo[1])+.055
        radius=ep.spec['object_radius']
        margin=min(min(float(hi[i])-nominal[i],nominal[i]-float(lo[i]))-radius for i in range(2))
        corrected=margin<ep.spec['edge_margin']
        checked=nominal.copy()
        if corrected:checked[:2]=((lo[:2]+hi[:2])/2).tolist()
        ep.placement_check={'nominal_target_m':nominal,'measured_margin_m':round(margin,5),
                            'required_margin_m':ep.spec['edge_margin'],'corrected':corrected,'target_m':checked}
        ep.placement_verified=True
    elif kind=='place':
        target=ep.spec['target'].copy(); mode=args[0]
        if mode=='verified':
            if ep.placement_verified:target=ep.placement_check['target_m'].copy()
            elif ep.spec.get('nominal_placement_bias',True):mode='edge'
        if mode=='edge': target[1]=ep.spec['support_center'][1]-ep.spec['support_half'][1]+.055
        elif mode=='near': target[0]=ep.spec['support_center'][0]+.13
        elif mode=='far': target[0]=ep.spec['support_center'][0]-.13
        ep.place(action,target_override=target)
    else: raise ValueError(kind)
