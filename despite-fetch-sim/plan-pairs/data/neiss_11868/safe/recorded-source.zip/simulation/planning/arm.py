"""Pose IK, collision-checked Cartesian candidates, OMPL RRT-Connect, Ruckig.

Ruckig is phase synchronized, so each segment follows the checked joint-space
line. Its actual sampled output is checked again before any motor command.
"""
import math
import time
import numpy as np
from scipy.spatial.transform import Rotation, Slerp
from .model import transform


def joint_samples(a,b,step=.008):
    n=max(1,int(np.ceil(np.max(np.abs(np.asarray(b)-a)/np.array([.002]+[step]*7)))))
    return np.linspace(a,b,n+1)


def edge_valid(a,b,valid):
    return all(valid(q) for q in joint_samples(a,b))


class ArmPlanner:
    initialized_seed=None
    def __init__(self, model, world, seed=41):
        self.model=model;self.world=world;self.seed=seed
        from ompl import util as ou
        if ArmPlanner.initialized_seed is None:
            ou.RNG.setSeed(seed);ArmPlanner.initialized_seed=seed
        elif ArmPlanner.initialized_seed!=seed:
            raise ValueError('Use a fresh process to change the OMPL random seed')

    def plan(self,start,target,base,*,upright=False,allowed_payload=(),timeout=12.):
        begun=time.monotonic();before=self.world.checks
        valid=lambda q:self.world.valid(q,base,arm_only=True,upright=upright,allowed_payload=allowed_payload)
        if not valid(start):raise RuntimeError(f'Arm planning start is in collision: {self.world.last_collision}')
        goals=self.model.ik(np.linalg.inv(base)@target,start,validator=valid)
        goals=[q for q in goals if valid(q)]
        if not goals:raise RuntimeError(f'No collision-free IK at requested hand pose: {self.world.last_collision}')
        path,detail=self.connect(start,goals,base,upright=upright,allowed_payload=allowed_payload,timeout=timeout)
        detail.update(planning_seconds=time.monotonic()-begun,collision_checks=self.world.checks-before,
                      target_world=target.tolist(),ik_goal=path[-1].tolist())
        return path,detail

    def plan_joints(self,start,goal,base,*,timeout=12.):
        goal=np.asarray(goal,dtype=float)
        if goal.shape!=(8,) or np.any(goal<self.model.lower) or np.any(goal>self.model.upper):
            raise ValueError('Joint goal is outside the Fetch model limits')
        return self.connect(start,[goal],base,timeout=timeout)

    def connect(self,start,goals,base,*,upright=False,allowed_payload=(),timeout=12.):
        begun=time.monotonic();before=self.world.checks
        valid=lambda q:self.world.valid(q,base,arm_only=True,upright=upright,allowed_payload=allowed_payload)
        if not valid(start):raise RuntimeError(f'Arm planning start is in collision: {self.world.last_collision}')
        goals=[q for q in goals if valid(q)]
        if not goals:raise RuntimeError(f'No collision-free joint goal: {self.world.last_collision}')
        # Prefer the short straight configuration path. Check every substep,
        # not only its IK endpoint. No Cartesian interpolation is assumed safe.
        for goal in goals:
            if edge_valid(start,goal,valid):
                path=[np.asarray(start),goal];method='checked joint-space connection';break
        else:
            from ompl import base as ob, geometric as og
            space=ob.RealVectorStateSpace(8);bounds=ob.RealVectorBounds(8)
            for i in range(8):bounds.setLow(i,float(self.model.lower[i]));bounds.setHigh(i,float(self.model.upper[i]))
            space.setBounds(bounds);ss=og.SimpleSetup(space)
            ss.setStateValidityChecker(lambda s:valid(np.array([s[i] for i in range(8)])))
            ss.getSpaceInformation().setStateValidityCheckingResolution(.0003)
            a=space.allocState();b=space.allocState()
            for i in range(8):a[i]=float(start[i]);b[i]=float(goals[0][i])
            ss.setStartAndGoalStates(a,b,1e-5)
            planner=og.RRTConnect(ss.getSpaceInformation());planner.setRange(.20);ss.setPlanner(planner)
            status=ss.solve(timeout)
            if not status or not ss.haveExactSolutionPath():raise RuntimeError('Arm RRT-Connect found no exact collision-free path')
            raw=[np.array([s[i] for i in range(8)]) for s in ss.getSolutionPath().getStates()]
            # Deterministic farthest-visible shortcut, always collision checked.
            path=[raw[0]];i=0
            while i<len(raw)-1:
                j=len(raw)-1
                while j>i+1 and not edge_valid(raw[i],raw[j],valid):j-=1
                path.append(raw[j]);i=j
            method='OMPL RRTConnect + checked shortcuts'
        if not all(edge_valid(a,b,valid) for a,b in zip(path,path[1:])):
            raise RuntimeError('Arm final path failed dense collision validation')
        return path,{'algorithm':method,'planning_seconds':time.monotonic()-begun,
                     'collision_checks':self.world.checks-before,'waypoints':[q.tolist() for q in path],
                     'upright_constraint':upright,
                     'allowed_payload_supports':list(allowed_payload)}

    def retime(self,path,base,hz,*,upright=False,allowed_payload=(),minimum_duration=0,payload_mass_kg=0.):
        from ruckig import Ruckig, InputParameter, Trajectory, Synchronization, Result
        output=[];segments=[]
        # Conservative pilot limits, inside Fetch's URDF velocity bounds.
        velocity=[.075,.55,.55,.7,.55,.7,.55,.7]
        acceleration=[.18,.9,.9,1.1,.9,1.1,.9,1.1]
        jerk=[.55,2.,2.,2.5,2.,2.5,2.,2.5]
        # Heavy payloads slipped under the light-cup timing. Uniform time
        # dilation reduces velocity, acceleration and jerk consistently.
        # This is an explicit, uncalibrated execution limit, not a force proof.
        scale=min(1.,max(.35,math.sqrt(.18/max(.18,payload_mass_kg))))
        velocity=(np.array(velocity)*scale).tolist()
        acceleration=(np.array(acceleration)*scale**2).tolist()
        jerk=(np.array(jerk)*scale**3).tolist()
        for a,b in zip(path,path[1:]):
            if np.max(abs(b-a))<1e-5:continue
            inp=InputParameter(8);inp.current_position=a.tolist();inp.current_velocity=[0.]*8;inp.current_acceleration=[0.]*8
            inp.target_position=b.tolist();inp.target_velocity=[0.]*8;inp.target_acceleration=[0.]*8
            inp.max_velocity=velocity;inp.max_acceleration=acceleration;inp.max_jerk=jerk
            inp.synchronization=Synchronization.Phase
            inp.minimum_duration=max(0.,minimum_duration/max(1,len(path)-1))
            trajectory=Trajectory(8);result=Ruckig(8).calculate(inp,trajectory)
            if result not in (Result.Working,Result.Finished):raise RuntimeError(f'Ruckig failed: {result}')
            n=max(1,math.ceil(trajectory.duration*hz));previous=a
            for i in range(1,n+1):
                q,v,acc=trajectory.at_time(min(i/hz,trajectory.duration));q=np.asarray(q)
                if not edge_valid(previous,q,lambda x:self.world.valid(x,base,arm_only=True,upright=upright,allowed_payload=allowed_payload)):
                    raise RuntimeError(f'Retimed arm trajectory collides: {self.world.last_collision}')
                output.append(q);previous=q
            segments.append({'duration_s':trajectory.duration,'samples':n})
        return output,{'algorithm':'Ruckig phase-synchronized jerk-limited trajectory',
                       'velocity_limits':velocity,'acceleration_limits':acceleration,'jerk_limits':jerk,
                       'payload_mass_kg':payload_mass_kg,'payload_time_scale':scale,
                       'payload_scaling_rule':'s=clip(sqrt(0.18/max(0.18,m)),0.35,1); v*s, a*s^2, j*s^3; uncalibrated',
                       'units':'torso: metres; other joints: radians','segments':segments,'all_samples_collision_checked':True}
