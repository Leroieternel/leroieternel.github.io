"""Summarize all task engines without conflating integration with success."""
import argparse
import hashlib
import json
from pathlib import Path
from simulation.pair_cases import PAIR_IDS
from simulation.scene_cases import SCENE_IDS
from simulation.initial_state_check import compare_initial_states
from .audit import audit_run
from .grounding import REVISION

TASKS=('neiss_2888','alfred_2757',*PAIR_IDS,*SCENE_IDS)
SOURCE=Path(__file__).resolve().parents[1]


def validate(folder):
    rows=[];pairs=[]
    for task in TASKS:
        records={}
        for variant in ('safe','unsafe'):
            run=folder/(task+'-'+variant);file=run/'result.json'
            row={'task':task,'variant':variant,'path':str(run),'recorded':file.exists()}
            rows.append(row)
            if not file.exists():continue
            r=json.loads(file.read_text());records[variant]=r
            changed=[n for n,h in r['simulation_code_sha256'].items()
                     if not (SOURCE/n).exists() or hashlib.sha256((SOURCE/n).read_bytes()).hexdigest()!=h]
            row.update(backend=r.get('motion_backend','legacy'),revision=r.get('planning',{}).get('revision'),
                       status=r['status'],goal_reached=r['goal_reached'],
                       physical_conditions_met=r['physical_safety_conditions_met'],
                       duration_s=r['duration'],physics_only=r.get('physics_only',False),
                       differs_from_current_source=changed,error=r['error'])
            try:
                report=audit_run(run);row['motion_audit_passed']=True
                (run/'motion-audit.json').write_text(json.dumps(report,indent=2)+'\n')
                row['navigation_m']=sum(x['distance_m'] for x in report['navigation'])
                row['turn_deg']=sum(x['turn_deg'] for x in report['navigation'])
                row['completed_arm_motions']=sum(x.get('status')!='stopped_before_motor_execution' for x in report['arm'])
            except (AssertionError,KeyError,ValueError) as error:
                row['motion_audit_passed']=False;row['audit_error']=str(error)
        if len(records)==2:
            try:initial=compare_initial_states(records['safe'],records['unsafe'])
            except AssertionError as error:initial={'matched':False,'error':str(error)}
            pairs.append({'task':task,'initial_state':initial,
                          'same_code':records['safe']['simulation_code_sha256']==records['unsafe']['simulation_code_sha256']})
    return {'revision':REVISION,'expected_runs':len(TASKS)*2,'recorded_runs':sum(x['recorded'] for x in rows),
            'current_backend_runs':sum(x.get('backend')=='classical' and not x.get('differs_from_current_source') for x in rows),
            'motion_audit_passed_runs':sum(x.get('motion_audit_passed',False) for x in rows),
            'completed_goal_runs':sum(x.get('goal_reached',False) for x in rows),
            'calibration_status':'uncalibrated',
            'interpretation':'Integration coverage, motion validity, task success and monitored safety are separate. A planner stop is not a task success.',
            'runs':rows,'pairs':pairs}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('runs',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();report=validate(a.runs)
    out=a.output or a.runs/'validation.json';out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('runs','pairs')}))
