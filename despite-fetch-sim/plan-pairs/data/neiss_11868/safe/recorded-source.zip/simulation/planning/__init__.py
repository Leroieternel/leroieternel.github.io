"""Classical, label-blind motion planning for the physical Fetch executor."""
