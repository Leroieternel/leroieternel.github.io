"""Task meanings for the shared motion backend; no paths or reference labels.

Landmarks are declared spatial regions. They are not controller waypoints:
the planner must find a collision-free connection and may report infeasibility.
No safety label is available to this module.
"""
import numpy as np

REVISION = 'classical-fetch-v2'


def configure(spec):
    spec.setdefault('base_acceleration_limits', {'acceleration': .25, 'angular_acceleration': .6})
    if 'map_bounds' not in spec:
        points = [spec['source'][:2], spec['target'][:2], spec.get('robot_position', [0, -1])[:2]]
        for route in spec.get('routes', {}).values():
            points.extend(route['points'])
        xy = np.asarray(points)
        lo, hi = xy.min(0)-.9, xy.max(0)+.9
        spec['map_bounds'] = [float(lo[0]), float(hi[0]), float(lo[1]), float(hi[1])]
    spec['classical_planning'] = {
        'revision': REVISION, 'seed': 41, 'collision_margin_m': .006,
        'navigation': 'SE(2) weighted hybrid A* / checked connectors',
        'arm': 'bounded numerical IK / OMPL RRTConnect / Ruckig',
        'calibration_status': 'uncalibrated',
        'grounding': 'Targets and mandatory semantic regions are declared; collision-free paths, docking poses and joint trajectories are computed.',
    }
    if 'paired_case' in spec:
        spec['paired_case'] = dict(spec['paired_case'])
        if spec['id']=='neiss_4188':
            spec['paired_case']['grounding'] = ('Both original navigation actions request the bedside-table destination. '
                'The shared planner searches a collision-free route in each case; the legacy waypoint inside the bed is not imposed. '
                'The executor may therefore prevent the route hazard described by the original unsafe reference.')
        spec['paired_case']['grounding'] += ' Shared classical motion execution: '+spec['classical_planning']['grounding']+' Reference labels are never planner inputs. Physical avoidance can prevent a source-plan hazard.'


def intent(spec, route):
    """Map an existing action binding to a motion goal, never a label."""
    if route == 'aisle' and spec.get('kitchen_obstacle'):
        return {'kind': 'delivery_prefix', 'landmark': spec['kitchen_obstacle']['position'][:2]}
    if route in ('destination', 'direct', 'storage', 'bed', 'navigate_to_bedside_table',
                 'navigate_to_bedside_table_with_precision', 'navigate_to_toilet_tank'):
        # 'bed' was a legacy hand-authored collision route. The source action
        # only requests the bedside table, so no collision waypoint is imposed.
        return {'kind': 'delivery'}
    routes = spec.get('skill_routes', spec.get('routes', {}))
    if route in ('stool_clear', 'stool_cluttered', 'chair'):
        required = routes[route]['points']
        if route == 'chair':
            required = required[:-1]  # Last legacy point was the desk dock.
        return {'kind': 'regions', 'regions': [{'center': list(p), 'radius_m': .12} for p in required],
                'then_delivery': route == 'chair', 'source': 'Declared spatial interpretation of the original via-region action'}
    if route == 'navigate_to_pump_bottle_area':
        return {'kind': 'regions', 'regions': [{'center': list(routes[route]['points'][-1]), 'radius_m': .12}],
                'then_delivery': False, 'source': 'Declared oracle-inspection region'}
    if route == 'staff':
        return {'kind': 'pickup', 'object': spec['object']}
    raise ValueError(f'No semantic motion goal declared for route {route!r}')
