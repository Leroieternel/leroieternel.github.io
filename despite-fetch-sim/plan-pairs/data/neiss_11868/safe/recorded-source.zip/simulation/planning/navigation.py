"""SE(2) hybrid A* with forward/reverse arcs and in-place rotation.

All primitive sweeps and final connections are checked using the complete
robot and payload collision model. The search has no reference-plan label.
"""
import heapq
import itertools
import math
import time
import numpy as np
from .model import se2,wrap


def sweep(a,b,linear=.025,angular=.06):
    a=np.asarray(a);b=np.asarray(b);delta=b-a;delta[2]=wrap(delta[2])
    n=max(1,math.ceil(np.linalg.norm(delta[:2])/linear),math.ceil(abs(delta[2])/angular))
    return [a+delta*t for t in np.linspace(0,1,n+1)]


def path_cost(path):
    return sum(np.linalg.norm(b[:2]-a[:2])+.18*abs(wrap(b[2]-a[2])) for a,b in zip(path,path[1:]))


def position_headings(start,point):
    """A position-only waypoint must not reset to an old chassis heading."""
    delta=np.asarray(point)-np.asarray(start)[:2]
    if np.linalg.norm(delta)<.01:return [float(start[2])]
    angle=math.atan2(delta[1],delta[0])
    return sorted([angle,wrap(angle+math.pi)],key=lambda yaw:abs(wrap(yaw-start[2])))


def stopping_sweep(state,current,requested,acceleration,reaction=.10,dt=1/60):
    """Predict one reaction interval followed by acceleration-limited braking.

    Holding the requested speed for an entire stopping horizon is not a
    braking trajectory and rejects reachable goals near furniture.
    """
    p=np.asarray(state,dtype=float).copy();command=np.asarray(current,dtype=float).copy()
    acceleration=np.asarray(acceleration,dtype=float);requested=np.asarray(requested,dtype=float)
    points=[p.copy()];elapsed=0.
    for _ in range(math.ceil((reaction+np.max(np.maximum(abs(command),abs(requested))/acceleration)+.1)/dt)):
        target=requested if elapsed<reaction else np.zeros(2)
        command+=np.clip(target-command,-acceleration*dt,acceleration*dt)
        p[:2]+=command[0]*dt*np.array([math.cos(p[2]+command[1]*dt/2),math.sin(p[2]+command[1]*dt/2)])
        p[2]+=command[1]*dt;points.append(p.copy());elapsed+=dt
        if elapsed>=reaction and np.max(abs(command))<1e-8:break
    return points


class Navigator:
    def __init__(self,world,bounds,z,arm):
        self.world=world;self.bounds=bounds;self.z=z;self.arm=np.asarray(arm)
        self.cache={}

    def valid(self,p):
        if not(self.bounds[0]<=p[0]<=self.bounds[1] and self.bounds[2]<=p[1]<=self.bounds[3]):return False
        # Cache only identical sampled states; quantized cache entries could
        # incorrectly accept an unchecked nearby pose beside a thin obstacle.
        key=tuple(np.round(p,7))
        if key not in self.cache:
            check=getattr(self.world,'navigation_valid',self.world.valid)
            self.cache[key]=check(self.arm,se2(p,self.z))
        return self.cache[key]

    def edge(self,a,b):
        points=sweep(a,b)
        return points if all(self.valid(p) for p in points) else None

    def connect(self,a,b):
        a=np.asarray(a);b=np.asarray(b);delta=b[:2]-a[:2]
        if np.linalg.norm(delta)<.01:
            return self.edge(a,b)
        angle=math.atan2(delta[1],delta[0]);options=[]
        for direction in (1,-1):
            heading=wrap(angle+(math.pi if direction<0 else 0))
            corners=[a,np.r_[a[:2],heading],np.r_[b[:2],heading],b]
            if any(self.edge(x,y) is None for x,y in zip(corners,corners[1:])):continue
            path=[a]
            for x,y in zip(corners,corners[1:]):path.extend(sweep(x,y)[1:])
            options.append(path)
        return min(options,key=path_cost) if options else None

    def plan(self,start,goal,timeout=40.):
        begun=time.monotonic();start=np.asarray(start);goal=np.asarray(goal)
        if not self.valid(start):raise RuntimeError(f'Navigation starts in collision: {self.world.last_collision}')
        if not self.valid(goal):raise RuntimeError(f'Navigation goal is in collision: {self.world.last_collision}')
        direct=self.connect(start,goal)
        if direct is not None:return direct,{'algorithm':'SE(2) hybrid A* / checked direct connector','expanded':0,'cost':path_cost(direct)}
        heading_step=math.pi/12;step=.09
        key=lambda p:(round(p[0]/.045),round(p[1]/.045),round(wrap(p[2])/heading_step)%24)
        heuristic=lambda p:np.linalg.norm(p[:2]-goal[:2])+.12*abs(wrap(goal[2]-p[2]))
        # Weighted A* is deliberately bounded-time, not an optimality claim.
        heuristic_weight=1.6
        counter=itertools.count();queue=[(heuristic_weight*heuristic(start),next(counter),0,start,None)]
        visited={};nodes=[];solution=None
        while queue and time.monotonic()-begun<timeout:
            _,_,cost,p,parent=heapq.heappop(queue);k=key(p)
            if visited.get(k,float('inf'))<=cost:continue
            visited[k]=cost;index=len(nodes);nodes.append((p,parent))
            if np.linalg.norm(p[:2]-goal[:2])<.24 or len(nodes)%40==0:
                connector=self.connect(p,goal)
                if connector is not None:solution=(index,connector);break
            successors=[]
            for turn in (-1,1):successors.append(np.r_[p[:2],wrap(p[2]+turn*heading_step)])
            for direction in (1,-1):
                for turn in (-1,0,1):
                    dyaw=turn*heading_step
                    # Exact differential-drive constant-curvature primitive.
                    if turn:
                        radius=direction*step/dyaw
                        xy=p[:2]+radius*np.array([math.sin(p[2]+dyaw)-math.sin(p[2]),-math.cos(p[2]+dyaw)+math.cos(p[2])])
                    else:xy=p[:2]+direction*step*np.array([math.cos(p[2]),math.sin(p[2])])
                    successors.append(np.r_[xy,wrap(p[2]+dyaw)])
            for end in successors:
                new_cost=cost+path_cost([p,end])
                if visited.get(key(end),float('inf'))<=new_cost:continue
                # Dense linear sweep also bounds the small-arc chord error
                # (<3 mm for these primitives), within the 6 mm clearance.
                if self.edge(p,end) is None:continue
                heapq.heappush(queue,(new_cost+heuristic_weight*heuristic(end),next(counter),new_cost,end,index))
        if solution is None:raise RuntimeError(f'Navigation search found no route ({len(nodes)} states, {time.monotonic()-begun:.1f}s)')
        index,connector=solution;path=[]
        while index is not None:
            p,index=nodes[index];path.append(p)
        path.reverse();path.extend(connector[1:])
        # Remove avoidable bends with a checked differential-drive connector.
        reduced=[path[0]];i=0
        while i<len(path)-1:
            chosen=None
            for j in range(len(path)-1,i,-1):
                candidate=self.connect(path[i],path[j])
                if candidate is not None and path_cost(candidate)<=path_cost(path[i:j+1])+.001:
                    chosen=(j,candidate);break
            if chosen is None:chosen=(i+1,sweep(path[i],path[i+1]))
            i,connection=chosen;reduced.extend(connection[1:])
        if not all(self.valid(p) for p in reduced):raise RuntimeError('Final navigation path failed validation')
        return reduced,{'algorithm':'SE(2) weighted hybrid A* + checked shortcuts','heuristic_weight':heuristic_weight,'expanded':len(nodes),
                        'planning_seconds':time.monotonic()-begun,'cost':path_cost(reduced)}


def segments(path):
    """Condense dense samples into constant-direction commands for tracking."""
    groups=[]
    for a,b in zip(path,path[1:]):
        if np.linalg.norm(b[:2]-a[:2])<1e-5:
            mode='rotate';sign=int(np.sign(wrap(b[2]-a[2])))
            if sign==0:continue
        else:
            mode='drive';sign=1 if np.dot(b[:2]-a[:2],[math.cos(a[2]),math.sin(a[2])])>=0 else -1
        if groups and groups[-1]['mode']==mode and groups[-1]['direction']==sign:
            groups[-1]['points'].append(b.tolist())
        else:groups.append({'mode':mode,'direction':sign,'points':[a.tolist(),b.tolist()]})
    return groups
