"""Check measured motion against its stored planned routes and motor logs."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from .model import wrap


def audit_run(folder):
    r=json.loads((folder/'result.json').read_text());trace=json.loads((folder/'trace.json').read_text())
    planning=json.loads((folder/'planning.json').read_text())
    assert planning==r['planning']
    planned_stop=r['status']=='blocked' and r.get('planning_stop') is not None
    assert r['status']=='completed' or planned_stop,r['error']
    if r['status']=='completed':assert len(r['steps'])==len(r['plan']) and all(x['status']=='completed' for x in r['steps'])
    assert not planning['reference_label_input'] and planning['calibration_status']=='uncalibrated'
    assert not planning['interventions'],planning['interventions']
    assert planning['max_fk_live_position_error_m']<.005
    assert planning['max_joint_tracking_error_rad_or_m']<=.18
    if planning.get('joint_tracking'):
        assert np.all(np.array(planning['joint_tracking']['maximum_absolute_error'])<=planning['joint_tracking']['stop_limits'])
    for name,digest in r['simulation_code_sha256'].items():
        assert hashlib.sha256((folder/'source'/name).read_bytes()).hexdigest()==digest,name
    report={'task':r['task_id'],'variant':r['variant'],'navigation':[],'arm':[],'calibration_status':'uncalibrated',
            'episode_status':r['status'],'task_goal_reached':r['goal_reached'],
            'planning_stop':r.get('planning_stop'),'infeasibility_proven':False}
    for record in planning['records']:
        if record['kind']=='arm':
            if planned_stop and record['status']=='failed' and 'timing' not in record:
                assert record['step']==r['planning_stop']['step']
                report['arm'].append({'phase':record['phase'],'status':'stopped_before_motor_execution','reason':record['error']})
                continue
            assert record['status']=='completed'
            assert record['timing']['all_samples_collision_checked']
            assert record['endpoint_error_m']<=.035
            report['arm'].append({'phase':record['phase'],'algorithm':record['plan']['algorithm'],
                                  'endpoint_error_m':record['endpoint_error_m'],
                                  'collision_checks':record['plan']['collision_checks']})
        elif record['kind']=='navigation':
            assert record['status']=='completed'
            samples=[s for s in trace if record['start_s']-.001<=s['t']<=record['end_s']+.001]
            position=np.array([s['robot']['p'][:2] for s in samples]);q=np.array([s['robot']['q'] for s in samples])
            yaw=np.unwrap(Rotation.from_quat(q).as_euler('xyz')[:,2]);path=np.array(record['planned_path'])
            length=float(np.linalg.norm(np.diff(position,axis=0),axis=1).sum())
            planned_length=float(np.linalg.norm(np.diff(path[:,:2],axis=0),axis=1).sum())
            turn=float(np.abs(np.diff(yaw)).sum());planned_turn=float(sum(abs(wrap(b[2]-a[2])) for a,b in zip(path,path[1:])))
            assert length<=planned_length*1.20+.05,('Unplanned detour',length,planned_length)
            assert turn<=planned_turn+np.radians(12),('Unplanned rotation',turn,planned_turn)
            assert np.linalg.norm(position[-1]-path[-1,:2])<=.045
            maxv=max(abs(s['base_command']['linear_m_s']) for s in samples)
            maxw=max(abs(s['base_command']['angular_rad_s']) for s in samples)
            assert maxv<=record['limits']['speed']+1e-5 and maxw<=record['limits']['turn']+1e-5
            report['navigation'].append({'distance_m':length,'planned_distance_m':planned_length,
                'turn_deg':float(np.degrees(turn)),'planned_turn_deg':float(np.degrees(planned_turn)),
                'position_error_m':record['position_error_m'],'max_linear_m_s':maxv,'max_angular_rad_s':maxw})
    # Independent check of physical contact reports, including the chassis.
    scene=json.load(gzip.open(folder/'planning-scene.json.gz','rt'))
    floors=[]
    for item in scene['world']:
        v=np.array(item['vertices']);size=np.ptp(v,axis=0)
        if v[:,2].max()<.045 and size[0]>1 and size[1]>1:floors.append(item['path'])
    unexpected=[]
    for state in trace:
        for pair in state.get('contacts',[]):
            paths=[p for p in pair if 'controllable__fetch' in p]
            if len(paths)!=1:continue
            rp=paths[0];other=next(p for p in pair if p!=rp)
            rolling=any('/'+name+'/' in rp for name in ('base_link','l_wheel_link','r_wheel_link'))
            if rolling and ('ground_plane' in other or any(p in other for p in floors)):continue
            if '/'+r['spec']['object']+'/' in other and any('/'+name+'/' in rp for name in ('l_gripper_finger_link','r_gripper_finger_link')):continue
            unexpected.append({'t':state['t'],'pair':pair})
    assert not unexpected,unexpected[:3]
    report['unexpected_contact_frames']=len(unexpected)
    report['source_hashes_verified']=True
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run',type=Path);parser.add_argument('--output',type=Path);args=parser.parse_args()
    report=audit_run(args.run);text=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(text)
    print(text)
