"""Export a live planning scene and verify model agreement without rendering."""
from pathlib import Path
import json
from simulation.run_episode import Episode, og, ROOT

def main():
    ep=Episode('neiss_11868','safe',ROOT/'simulation/runs/planning-probe','physical',True,True,True,physics_only=True)
    try:
        ep.wait(.2)
        from .snapshot import extract,save
        from .model import CollisionWorld
        model,snapshot=extract(ep);save(snapshot,ep.output/'scene.json.gz')
        world=CollisionWorld(model,snapshot)
        valid=world.valid(snapshot['initial_arm'],__import__('numpy').array(snapshot['base']))
        print('PLANNING_PROBE',json.dumps({'valid':valid,'collision':world.last_collision,'world':len(snapshot['world']),
              'robot':len(snapshot['robot']),'disabled_pairs':snapshot['disabled_pairs'],'fk':snapshot['fk_position_errors_m'],
              'joints':snapshot['initial_joints'],'eef_offset':snapshot['eef_offset']}),flush=True)
    finally:og.shutdown()

if __name__=='__main__':main()
