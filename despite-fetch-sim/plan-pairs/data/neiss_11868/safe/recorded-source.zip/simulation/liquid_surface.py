"""Render a surface reconstructed only from measured PBD particle positions.

This mesh has no collision or rigid-body API. It never changes the fluid state.
Connected particle clusters are meshed separately to avoid a room-sized voxel
grid. The same reconstruction is used for both reference plans.
"""
import numpy as np
from scipy.ndimage import gaussian_filter, label


class LiquidSurface:
    def __init__(self,material):
        import omnigibson as og
        from pxr import UsdGeom, UsdShade, Sdf
        self.mesh=UsdGeom.Mesh.Define(og.sim.stage,'/World/MeasuredLiquidSurface')
        self.mesh.CreateSubdivisionSchemeAttr('none')
        self.mesh.CreateDoubleSidedAttr(True)
        # Optical material only. The PBD material and all its solver parameters
        # remain unchanged. Beer absorption depends on real geometric thickness.
        mat=UsdShade.Material.Define(og.sim.stage,'/World/Looks/MeasuredHotLiquid')
        shader=UsdShade.Shader.Define(og.sim.stage,'/World/Looks/MeasuredHotLiquid/Shader')
        shader.SetSourceAsset(Sdf.AssetPath('OmniSurface.mdl'),'mdl')
        shader.SetSourceAssetSubIdentifier('OmniSurface','mdl')
        shader.CreateOutput('out',Sdf.ValueTypeNames.Token)
        for name,typ,value in [
            ('diffuse_reflection_weight',Sdf.ValueTypeNames.Float,.015),
            ('diffuse_reflection_color',Sdf.ValueTypeNames.Color3f,(.25,.09,.025)),
            ('specular_reflection_weight',Sdf.ValueTypeNames.Float,1.),
            ('specular_reflection_roughness',Sdf.ValueTypeNames.Float,.045),
            ('specular_reflection_ior',Sdf.ValueTypeNames.Float,1.333),
            ('enable_specular_transmission',Sdf.ValueTypeNames.Bool,True),
            ('specular_transmission_weight',Sdf.ValueTypeNames.Float,.985),
            ('specular_transmission_color',Sdf.ValueTypeNames.Color3f,(.92,.74,.36)),
            ('specular_transmission_scattering_depth',Sdf.ValueTypeNames.Float,1.),
            ('thin_walled',Sdf.ValueTypeNames.Bool,False)]:
            shader.CreateInput(name,typ).Set(value)
        mat.CreateSurfaceOutput('mdl').ConnectToSource(shader.ConnectableAPI(),'out')
        UsdShade.MaterialBindingAPI.Apply(self.mesh.GetPrim()).Bind(mat)
        self.film_mesh=UsdGeom.Mesh.Define(og.sim.stage,'/World/MeasuredFloorFilm')
        self.film_mesh.CreateSubdivisionSchemeAttr('none')
        self.film_mesh.CreateDoubleSidedAttr(True)
        UsdShade.MaterialBindingAPI.Apply(self.film_mesh.GetPrim()).Bind(mat)
        # RTX treats custom transmitting meshes as opaque shadow casters.
        # Match OmniGibson's native fluid-isosurface convention: transmission
        # and reflection remain visible, without the false black shadow slab.
        for mesh in (self.mesh,self.film_mesh):
            UsdGeom.PrimvarsAPI(mesh.GetPrim()).CreatePrimvar(
                'doNotCastShadows',Sdf.ValueTypeNames.Bool).Set(True)
        self.film=None

    def update(self,positions):
        import omnigibson as og
        with og.sim.editing_usd():
            self._update(positions)

    def _update(self,positions):
        import warp as wp
        from pxr import Vt
        p=np.asarray(positions,dtype=np.float32)
        if self.film is not None:
            self._update_film()
            p=p[~self.film.deposited]
        if not len(p):
            self.mesh.GetPointsAttr().Set([]);self.mesh.GetFaceVertexIndicesAttr().Set([]);self.mesh.GetFaceVertexCountsAttr().Set([])
            return
        # Separate disconnected droplets / floor pools from the cup volume.
        lo=p.min(0)-.025;cells=np.floor((p-lo)/.025).astype(int)
        occupancy=np.zeros(tuple(cells.max(0)+2),bool)
        occupancy[tuple(cells.T)]=True
        groups,_=label(occupancy,np.ones((3,3,3),bool))
        ids=groups[tuple(cells.T)]
        vertices=[];triangles=[];offset=0
        for group in np.unique(ids):
            points=p[ids==group]
            extent=np.maximum(np.ptp(points,axis=0),.006)
            h=max(.001,float((np.prod(extent)/2000000)**(1/3)))
            lower=points.min(0)-6*h
            shape=np.maximum(np.ceil((points.max(0)-lower)/h).astype(int)+7,13)
            field=np.zeros(tuple(shape),np.float32)
            q=(points-lower)/h
            ijk=np.floor(q).astype(int);fraction=q-ijk
            for x in (0,1):
                for y in (0,1):
                    for z in (0,1):
                        d=np.array([x,y,z]);weight=np.prod(np.where(d,fraction,1-fraction),axis=1)
                        np.add.at(field,tuple((ijk+d).T),weight)
            # Overlapping kernels connect neighboring fluid samples. The old
            # narrow kernel resolved each sample as a separate opaque bead.
            # Disconnected drops still remain disconnected; no time blending.
            field=gaussian_filter(field,2.)
            # Kernel level controls visualization only; spill volume is counted
            # directly from particles, never from this interpolated surface.
            if field.max()<.006:continue
            verts,faces=wp.MarchingCubes.extract_surface_marching_cubes(wp.array(field,dtype=wp.float32,device='cuda:0'),.006)
            v=verts.numpy()*h+lower;f=faces.numpy().reshape(-1,3)
            if not len(f):continue
            vertices.append(v);triangles.append(f+offset);offset+=len(v)
        if not vertices:
            self.mesh.GetPointsAttr().Set([]);self.mesh.GetFaceVertexIndicesAttr().Set([]);self.mesh.GetFaceVertexCountsAttr().Set([])
            return
        v=np.concatenate(vertices).astype(np.float32);f=np.concatenate(triangles).astype(np.int32)
        # Density fields increase inward, so reverse winding for outward normals.
        f=f[:,::-1].copy()
        n=np.zeros_like(v);face_n=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
        for i in range(3):np.add.at(n,f[:,i],face_n)
        n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-12)
        self.mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(v))
        self.mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(f.ravel()))
        self.mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(np.full(len(f),3,np.int32)))
        self.mesh.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(n));self.mesh.SetNormalsInterpolation('vertex')
        self.mesh.CreateExtentAttr([v.min(0).tolist(),v.max(0).tolist()])

    def _update_film(self):
        from pxr import Vt
        grid=self.film.surface_grid()
        if grid is None:return
        origin,h=grid;dx=self.film.dx;cfg=self.film.cfg
        # Height is used at its physical scale, without enlarging the puddle.
        nx,ny=h.shape
        keep=(h[:-1,:-1]+h[1:,:-1]+h[:-1,1:]+h[1:,1:])/4>cfg['visible_depth_m']
        cells=np.argwhere(keep)
        if not len(cells):return
        a=cells[:,0]*ny+cells[:,1]
        faces=np.concatenate([np.column_stack([a,a+ny,a+1]),np.column_stack([a+1,a+ny,a+ny+1])])
        used=np.unique(faces);remap=np.full(nx*ny,-1,int);remap[used]=np.arange(len(used));faces=remap[faces]
        x=origin[0]+used//ny*dx;y=origin[1]+used%ny*dx
        z0=cfg['floor_z_m']+cfg['surface_offset_m']
        v=np.column_stack([x,y,z0+h.ravel()[used]])
        gx,gy=np.gradient(h,dx)
        normals=np.column_stack([-gx.ravel()[used],-gy.ravel()[used],np.ones(len(used))])
        normals/=np.linalg.norm(normals,axis=1,keepdims=True)
        # Close the layer for thickness-aware transmission; the base is above
        # the dry floor by 60 micrometres solely to avoid z fighting.
        edges=np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]])
        keys=np.sort(edges,axis=1);_,inv,count=np.unique(keys,axis=0,return_inverse=True,return_counts=True)
        boundary=edges[count[inv]==1];n=len(v)
        sides=np.concatenate([np.column_stack([boundary[:,1],boundary[:,0],boundary[:,0]+n]),
                              np.column_stack([boundary[:,1],boundary[:,0]+n,boundary[:,1]+n])])
        f=np.concatenate([faces,faces[:,::-1]+n,sides]).astype(np.int32)
        v=np.concatenate([v,np.column_stack([x,y,np.full(n,z0)])]).astype(np.float32)
        normals=np.concatenate([normals,np.tile([0,0,-1],(n,1))]).astype(np.float32)
        self.film_mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(v))
        self.film_mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(f.ravel()))
        self.film_mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(np.full(len(f),3,np.int32)))
        self.film_mesh.CreateNormalsAttr(Vt.Vec3fArray.FromNumpy(normals));self.film_mesh.SetNormalsInterpolation('vertex')
        self.film_mesh.CreateExtentAttr([v.min(0).tolist(),v.max(0).tolist()])
