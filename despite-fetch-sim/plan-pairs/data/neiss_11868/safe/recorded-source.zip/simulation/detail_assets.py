"""Deterministic, metre-scale product meshes and material refinements.

Bottle collision hulls follow the same outer profile as their render mesh.
The visible water fill is static geometry, not a fluid simulation. Generated
labels are typographic artwork; no photographed or AI-generated backdrop is used.
"""
import math
from pathlib import Path

import numpy as np

from simulation.runtime import RUNTIME

GENERATED = RUNTIME / "generated/details"


def pbr(stage, path, color, roughness=.3, metal=0, texture=None):
    from pxr import UsdShade, Sdf, Gf
    mat = UsdShade.Material.Define(stage, path)
    sh = UsdShade.Shader.Define(stage, path + '/Shader')
    sh.SetSourceAsset(Sdf.AssetPath('OmniPBR.mdl'), 'mdl')
    sh.SetSourceAssetSubIdentifier('OmniPBR', 'mdl')
    sh.CreateOutput('out', Sdf.ValueTypeNames.Token)
    mat.CreateSurfaceOutput('mdl').ConnectToSource(sh.ConnectableAPI(), 'out')
    sh.CreateInput('diffuse_color_constant', Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
    sh.CreateInput('reflection_roughness_constant', Sdf.ValueTypeNames.Float).Set(roughness)
    sh.CreateInput('metallic_constant', Sdf.ValueTypeNames.Float).Set(metal)
    if texture:
        sh.CreateInput('diffuse_texture', Sdf.ValueTypeNames.Asset).Set(Sdf.AssetPath(str(texture)))
    # OG overrides roughness on load. Retain the intended finish for restoration.
    mat.GetPrim().CreateAttribute('despite:roughness', Sdf.ValueTypeNames.Float).Set(roughness)
    return mat


def glass(stage, path, color=(.97,.99,1), ior=1.47, roughness=.07, thin=True):
    from pxr import UsdShade, Sdf, Gf
    mat = UsdShade.Material.Define(stage, path)
    sh = UsdShade.Shader.Define(stage, path+'/Shader')
    sh.SetSourceAsset(Sdf.AssetPath('OmniGlass.mdl'), 'mdl')
    sh.SetSourceAssetSubIdentifier('OmniGlass', 'mdl')
    sh.CreateOutput('out', Sdf.ValueTypeNames.Token)
    mat.CreateSurfaceOutput('mdl').ConnectToSource(sh.ConnectableAPI(), 'out')
    for name, typ, value in [('glass_color',Sdf.ValueTypeNames.Color3f,Gf.Vec3f(*color)),
                             ('glass_ior',Sdf.ValueTypeNames.Float,ior),
                             ('frosting_roughness',Sdf.ValueTypeNames.Float,roughness),
                             ('thin_walled',Sdf.ValueTypeNames.Bool,thin),
                             ('depth',Sdf.ValueTypeNames.Float,.15)]:
        sh.CreateInput(name,typ).Set(value)
    return mat


def lathe(stage, path, profile, mat=None, segments=128, ribbing=0, center=(0,0,0)):
    """Revolve (z,radius) rings, with explicit smooth normals and cylindrical UVs."""
    from pxr import UsdGeom, UsdShade, Sdf
    p=np.asarray(profile,float); points=[]; normals=[]; uv=[]; idx=[]
    for j,(z,r) in enumerate(p):
        dz,dr=p[min(j+1,len(p)-1)]-p[max(j-1,0)]
        for i in range(segments+1):
            a=2*math.pi*i/segments
            rr=r+ribbing*(.5+.5*math.cos(64*a))
            points.append([center[0]+rr*math.cos(a),center[1]+rr*math.sin(a),center[2]+z])
            normal=np.array([dz*math.cos(a),dz*math.sin(a),-dr]); normal/=max(np.linalg.norm(normal),1e-9)
            normals.append(normal.tolist());uv.append([i/segments,(z-p[0,0])/max(p[-1,0]-p[0,0],1e-9)])
    for j in range(len(p)-1):
        for i in range(segments):
            a=j*(segments+1)+i;idx.extend([a,a+1,a+segments+2,a+segments+1])
    mesh=UsdGeom.Mesh.Define(stage,path)
    mesh.CreatePointsAttr(points);mesh.CreateFaceVertexCountsAttr([4]*(len(idx)//4));mesh.CreateFaceVertexIndicesAttr(idx)
    mesh.CreateNormalsAttr([normals[i] for i in idx]);mesh.SetNormalsInterpolation('faceVarying')
    mesh.CreateSubdivisionSchemeAttr('none')
    UsdGeom.PrimvarsAPI(mesh).CreatePrimvar('st',Sdf.ValueTypeNames.TexCoord2fArray,'faceVarying').Set([uv[i] for i in idx])
    if mat: UsdShade.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(mat)
    return mesh


def tube(stage,path,centers,radius,mat,sides=48):
    from pxr import UsdGeom, UsdShade
    centers=np.asarray(centers);points=[];normals=[];idx=[]
    for j,c in enumerate(centers):
        tangent=centers[min(j+1,len(centers)-1)]-centers[max(j-1,0)];tangent/=np.linalg.norm(tangent)
        a=np.cross(tangent,[0,1,0] if abs(tangent[1])<.95 else [1,0,0]);a/=np.linalg.norm(a)
        b=np.cross(tangent,a)
        for i in range(sides):
            n=a*math.cos(2*math.pi*i/sides)+b*math.sin(2*math.pi*i/sides)
            points.append((c+radius*n).tolist());normals.append(n.tolist())
    for j in range(len(centers)-1):
        for i in range(sides):
            k=(i+1)%sides;idx.extend([j*sides+i,j*sides+k,(j+1)*sides+k,(j+1)*sides+i])
    face_normals=[normals[i] for i in idx];counts=[4]*(len(idx)//4)
    for end,sign in [(0,-1),(len(centers)-1,1)]:
        tangent=centers[min(end+1,len(centers)-1)]-centers[max(end-1,0)];tangent/=np.linalg.norm(tangent)
        ring=list(range(end*sides,(end+1)*sides))
        if sign<0:ring.reverse()
        idx.extend(ring);counts.append(sides);face_normals.extend([(sign*tangent).tolist()]*sides)
    mesh=UsdGeom.Mesh.Define(stage,path);mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr(counts);mesh.CreateFaceVertexIndicesAttr(idx)
    mesh.CreateNormalsAttr(face_normals);mesh.SetNormalsInterpolation('faceVarying');mesh.CreateSubdivisionSchemeAttr('none')
    UsdShade.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(mat)
    return mesh


def label_image(kind):
    """Rasterize exact label typography, like other code-authored UI artwork."""
    from PIL import Image, ImageDraw, ImageFont
    GENERATED.mkdir(parents=True,exist_ok=True)
    path=GENERATED/(kind+'_label.png')
    image=Image.new('RGB',(1536,512),(239,237,225));d=ImageDraw.Draw(image)
    font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    color=(35,73,84) if kind=='water' else (65,58,47)
    for y in [18,26,486,494]: d.line([(0,y),(1536,y)],fill=color,width=3)
    # Repeat around the circumference so a label is legible from either camera.
    for x in [384,1152]:
        d.text((x,95),'STILL' if kind=='water' else 'BOTANICAL',fill=color,font=ImageFont.truetype(font,34),anchor='mm')
        d.text((x,210),'WATER' if kind=='water' else 'HAND WASH',fill=color,font=ImageFont.truetype(bold,66 if kind=='water' else 54),anchor='mm')
        d.line([(x-135,285),(x+135,285)],fill=color,width=2)
        d.text((x,350),'500 mL' if kind=='water' else 'GENTLE SOAP  /  300 mL',fill=color,font=ImageFont.truetype(font,27),anchor='mm')
        d.text((x,405),'PURIFIED DRINKING WATER' if kind=='water' else 'DAILY CARE',fill=color,font=ImageFont.truetype(font,18),anchor='mm')
    image.save(path)
    return path


def create_bottle(kind):
    """Build one dynamic, closed rigid body with a profile-matched collision hull."""
    # Start Kit before importing its USD modules; loading system USD first can
    # produce ABI/symbol conflicts when Isaac's plugins are loaded afterwards.
    import omnigibson as og
    if og.sim is None:
        og.launch(physics_dt=1/120,rendering_dt=1/30,sim_step_dt=1/30,viewer_width=1440,viewer_height=960)
    from pxr import Usd, UsdGeom, UsdPhysics
    GENERATED.mkdir(parents=True,exist_ok=True)
    path=GENERATED/(kind+'.usda')
    stage=Usd.Stage.CreateNew(str(path))
    root=stage.DefinePrim('/object','Xform');stage.SetDefaultPrim(root)
    UsdGeom.SetStageUpAxis(stage,'Z');UsdGeom.SetStageMetersPerUnit(stage,1)
    stage.DefinePrim('/object/base_link','Xform')
    stage.DefinePrim('/object/base_link/visuals','Xform')
    base='/object/base_link/visuals/'
    if kind=='water':
        # A PET body with moulded bands, tapered shoulder and a sealed screw cap.
        profile=[(-.11,0),(-.11,.025),(-.108,.0295),(-.103,.032)]
        for z in np.linspace(-.10,.045,116):
            r=.0314
            if z<-.040 or z>.020:r-=.0010*(.5+.5*math.cos((z+.1)*2*math.pi/.010))**4
            profile.append((float(z),r))
        profile += [(.051,.031),(.058,.029),(.065,.025),(.073,.020),(.080,.0155),(.087,.0155),(.089,.017),(.091,.017),(.091,0)]
        pet=glass(stage,'/object/Looks/PET',(.97,.99,1),1.47,.11,True)
        lathe(stage,base+'Body',profile,pet)
        water=glass(stage,'/object/Looks/Water',(.985,.996,1),1.333,.025,False)
        # Approx. 170 mL of water plus PET/cap matches the pilot's 0.18 kg mass.
        lathe(stage,base+'WaterFill',[(-.105,0),(-.105,.025),(-.100,.0298),(-.046,.0298),(-.044,.0295),(-.044,0)],water)
        cap=pbr(stage,'/object/Looks/Cap',[.12,.24,.28],.31)
        lathe(stage,base+'Cap',[(.09,0),(.09,.0163),(.092,.017),(.106,.017),(.109,.016),(.11,0)],cap,segments=256,ribbing=.00035)
        lathe(stage,base+'TamperRing',[(.085,.016),(.086,.0174),(.089,.0174),(.090,.016)],cap)
        paper=pbr(stage,'/object/Looks/Paper',[1,1,1],.48,texture=label_image('water'))
        lathe(stage,base+'Label',[(-.039,.03155),(.019,.03155)],paper)
        # Paper has an opaque, unprinted inner side visible through the PET.
        backing=pbr(stage,'/object/Looks/LabelBacking',[.87,.85,.78],.7)
        inner=lathe(stage,base+'LabelBacking',[(-.039,.03148),(.019,.03148)],backing)
        ids=np.asarray(inner.GetFaceVertexIndicesAttr().Get()).reshape(-1,4)[:,::-1]
        inner.GetFaceVertexIndicesAttr().Set(ids.ravel().tolist())
        ns=-np.asarray(inner.GetNormalsAttr().Get()).reshape(-1,4,3)[:,::-1,:]
        inner.GetNormalsAttr().Set(ns.reshape(-1,3).tolist())
        collision=[(-.11,0),(-.11,.025),(-.103,.032),(.050,.032),(.076,.020),(.089,.0175),(.11,.0175),(.11,0)]
    else:
        body=pbr(stage,'/object/Looks/GlazedBottle',[.23,.14,.075],.22)
        profile=[(-.14,0),(-.14,.028),(-.138,.032),(-.133,.035),(.038,.035),(.052,.034),(.066,.028),(.076,.018),(.088,.017),(.088,0)]
        lathe(stage,base+'Body',profile,body)
        chrome=pbr(stage,'/object/Looks/PumpMetal',[.65,.67,.64],.22,.95)
        lathe(stage,base+'Collar',[(.078,0),(.078,.019),(.082,.020),(.099,.020),(.103,.017),(.103,0)],chrome,segments=192,ribbing=.00022)
        lathe(stage,base+'PumpStem',[(.099,.006),(.124,.006)],chrome)
        tube(stage,base+'PumpSpout',[[0,0,.126],[-.008,0,.132],[-.025,0,.132],[-.046,0,.129],[-.049,0,.123]],.006,chrome)
        rubber=pbr(stage,'/object/Looks/Nozzle',[.025,.025,.023],.55)
        lathe(stage,base+'Nozzle',[(.117,0),(.117,.0048),(.123,.0048),(.123,0)],rubber,center=(-.049,0,0))
        paper=pbr(stage,'/object/Looks/SoapLabel',[1,1,1],.6,texture=label_image('soap'))
        lathe(stage,base+'Label',[(-.092,.03515),(.010,.03515)],paper)
        collision=profile
    collider=lathe(stage,'/object/base_link/collisions/body',collision,segments=64)
    collider.CreatePurposeAttr('guide')
    UsdPhysics.CollisionAPI.Apply(collider.GetPrim())
    UsdPhysics.MeshCollisionAPI.Apply(collider.GetPrim()).CreateApproximationAttr('convexHull')
    og.sim.physics_backend.apply_collision_schemas(collider.GetPrim())
    if kind=='soap':
        # The nozzle also occupies collision space; do not hide it in the metric.
        nozzle=UsdGeom.Cube.Define(stage,'/object/base_link/collisions/nozzle')
        nozzle.CreateSizeAttr(1);nozzle.AddTranslateOp().Set((-.025,0,.126));nozzle.AddScaleOp().Set((.060,.013,.022))
        nozzle.CreatePurposeAttr('guide');UsdPhysics.CollisionAPI.Apply(nozzle.GetPrim())
        og.sim.physics_backend.apply_collision_schemas(nozzle.GetPrim())
    stage.GetRootLayer().Save()
    return str(path)


def refine_fetch(stage, robot):
    """Keep Fetch CAD/UVs/kinematics; separate shell, rubber and exposed metal."""
    from pxr import Usd, UsdShade, UsdGeom, Sdf, Gf
    from PIL import Image
    root=robot.prim
    for prim in Usd.PrimRange(root):
        if not prim.IsA(UsdShade.Shader):continue
        sh=UsdShade.Shader(prim)
        sh.CreateInput('reflection_roughness_constant',Sdf.ValueTypeNames.Float).Set(.21)
        if sh.GetInput('diffuse_texture'):
            sh.CreateInput('diffuse_color_constant',Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(.84,.85,.86))
    rubber=pbr(stage,'/World/DetailMaterials/FetchRubber',[.024,.027,.029],.68)
    metal=pbr(stage,'/World/DetailMaterials/FetchMetal',[.31,.33,.35],.27,.85)
    for name,link in robot.links.items():
        for prim in Usd.PrimRange(link.prim):
            if not prim.IsA(UsdGeom.Mesh) or 'visual' not in str(prim.GetPath()):continue
            if name in ('l_wheel_link','r_wheel_link'):
                UsdShade.MaterialBindingAPI.Apply(prim).Bind(rubber)
                continue
            mat,_=UsdShade.MaterialBindingAPI(prim).ComputeBoundMaterial()
            if not mat:continue
            shader=UsdShade.Shader(stage.GetPrimAtPath(str(mat.GetPath())+'/Shader'))
            tex=shader.GetInput('diffuse_texture').Get() if shader else None
            if not tex:
                if name=='base_link' and prim.GetName()=='mesh_2':
                    UsdShade.MaterialBindingAPI.Apply(prim).Bind(metal)
                continue
            # Classify existing CAD texture islands, preserving every RGB texel.
            image=np.asarray(Image.open(tex.resolvedPath or tex.path).convert('RGB'))/255
            mesh=UsdGeom.Mesh(prim);uvvar=UsdGeom.PrimvarsAPI(mesh).GetPrimvar('st')
            if not uvvar:continue
            uv=np.asarray(uvvar.ComputeFlattened());counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get());ids=np.asarray(mesh.GetFaceVertexIndicesAttr().Get())
            if uvvar.GetInterpolation()=='vertex':uv=uv[ids]
            if len(uv)!=len(ids):continue
            xs=(np.mod(uv[:,0],1)*(image.shape[1]-1)).astype(int)
            ys=((1-np.mod(uv[:,1],1))*(image.shape[0]-1)).astype(int)
            samples=image[ys,xs];starts=np.r_[0,np.cumsum(counts)[:-1]]
            colors=np.add.reduceat(samples,starts)/counts[:,None]
            dark=np.max(colors,axis=1)<.32
            if not dark.any():continue
            dark_mat=pbr(stage,str(mat.GetPath())+'_Rubber',[1,1,1],.12 if name=='head_tilt_link' else .48,texture=tex.resolvedPath or tex.path)
            subset=UsdGeom.Subset.Define(stage,str(prim.GetPath())+'/RubberFaces')
            subset.CreateElementTypeAttr('face');subset.CreateFamilyNameAttr('materialBind');subset.CreateIndicesAttr(np.flatnonzero(dark).tolist())
            UsdShade.MaterialBindingAPI.Apply(subset.GetPrim()).Bind(dark_mat)


def refine_faucet(stage, vanity):
    """Replace the flat native faucet finish; remove simulator toggle markers."""
    from pxr import Usd, UsdGeom, UsdShade, Gf
    chrome=pbr(stage,'/World/DetailMaterials/FaucetChrome',[.72,.75,.78],.18,.97)
    surface_triangles=[]
    for name,link in vanity.links.items():
        if name.startswith('meta__'):
            UsdGeom.Imageable(link.prim).MakeInvisible()
            continue
        for prim in Usd.PrimRange(link.prim):
            if not prim.IsA(UsdGeom.Mesh) or 'visual' not in str(prim.GetPath()):continue
            mesh=UsdGeom.Mesh(prim);pts=np.asarray(mesh.GetPointsAttr().Get())
            transform=UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)
            world=np.array([transform.Transform(Gf.Vec3d(*map(float,p))) for p in pts])
            counts=np.array(mesh.GetFaceVertexCountsAttr().Get());ids=np.array(mesh.GetFaceVertexIndicesAttr().Get())
            starts=np.r_[0,np.cumsum(counts)[:-1]]
            # The original integrated faucet rises above the .80 m countertop.
            # Remove whole disconnected faucet components, including the foot.
            # The basin/cabinet mesh remains intact with its original UVs.
            parents=list(range(len(pts)))
            def find(i):
                while parents[i]!=i:
                    parents[i]=parents[parents[i]];i=parents[i]
                return i
            for start,count in zip(starts,counts):
                face=ids[start:start+count]
                for i in face[1:]: parents[find(int(i))]=find(int(face[0]))
            components={}
            for i in range(len(pts)):components.setdefault(find(i),[]).append(i)
            high={find(int(i)) for i in np.flatnonzero(world[:,2]>.805)}
            for component,vertices in components.items():
                cloud=world[vertices];lo=cloud.min(axis=0);hi=cloud.max(axis=0)
                if lo[2]>.72 and max(hi[:2]-lo[:2])<.22 and np.linalg.norm((hi[:2]+lo[:2])/2-[2.245,-.728])<.18:
                    high.add(component)
            remove=[i for i,start in enumerate(starts) if find(int(ids[start])) in high]
            mesh.CreateHoleIndicesAttr(remove)
            removed=set(remove)
            for face,(start,count) in enumerate(zip(starts,counts)):
                if face in removed:continue
                vertices=ids[start:start+count]
                for i in range(1,count-1):
                    surface_triangles.append(world[[vertices[0],vertices[i],vertices[i+1]]])
    # Intersect the actual rendered basin/counter mesh, not its nominal bbox.
    # This model's deck is at 0.75294 m; the old guessed 0.793 m floated 4 cm.
    tri=np.asarray(surface_triangles);a=tri[:,0];u=tri[:,1]-a;v=tri[:,2]-a
    determinant=u[:,0]*v[:,1]-u[:,1]*v[:,0]
    valid=abs(determinant)>1e-10
    a,u,v,determinant=a[valid],u[valid],v[valid],determinant[valid]
    def surface_height(x,y,ceiling=.805):
        dx=x-a[:,0];dy=y-a[:,1]
        s=(dx*v[:,1]-dy*v[:,0])/determinant;t=(u[:,0]*dy-u[:,1]*dx)/determinant
        heights=a[:,2]+s*u[:,2]+t*v[:,2]
        hits=(s>=-1e-7)&(t>=-1e-7)&(s+t<=1+1e-7)&(heights<ceiling)
        assert hits.any(), 'No sink support beneath faucet mounting point'
        return float(heights[hits].max())
    x,y=2.18,-.728
    contact_samples=[surface_height(x+r*math.cos(t),cy+r*math.sin(t))
                     for cy,r in [(y,.032),(y-.065,.022)] for t in np.linspace(0,2*math.pi,32,endpoint=False)]
    spread=max(contact_samples)-min(contact_samples)
    assert spread<.0002, 'Faucet base straddles a sink opening or uneven rim'
    # A half-millimetre seating overlap eliminates gaps and coplanar flicker.
    deck=min(contact_samples);z=deck-.0005
    # Curved, smooth spout with collar, mixer lever and a separate aerator.
    foot=lathe(stage,'/World/Decor/FaucetFoot',[(0,0),(0,.030),(.003,.031),(.009,.030),(.015,.018),(.016,.014)],chrome,center=(x,y,z))
    foot.GetPrim().SetCustomDataByKey('despiteMount',{'surface_z_m':deck,'base_bottom_z_m':z,
                                                   'rim_samples':len(contact_samples),'surface_spread_m':spread,
                                                   'seating_overlap_m':deck-z})
    centers=[[x,y,z+.01],[x,y,z+.11]]
    reach=.095
    for angle in np.linspace(math.pi,0,48):centers.append([x+reach+reach*math.cos(angle),y,z+.11+reach*math.sin(angle)])
    centers.append([x+2*reach,y,z+.085])
    tube(stage,'/World/Decor/FaucetSpout',centers,.014,chrome)
    lathe(stage,'/World/Decor/FaucetAerator',[(0,0),(0,.013),(.005,.015),(.021,.015),(.024,.013)],chrome,center=(x+2*reach,y,z+.068))
    dark=pbr(stage,'/World/DetailMaterials/AeratorMesh',[.07,.075,.08],.55,.4)
    lathe(stage,'/World/Decor/FaucetOutlet',[(0,0),(0,.011),(.001,.011)],dark,center=(x+2*reach,y,z+.068))
    lathe(stage,'/World/Decor/FaucetMixer',[(0,0),(0,.021),(.045,.021),(.05,.018),(.05,0)],chrome,center=(x,y-.065,z))
    tube(stage,'/World/Decor/FaucetLever',[[x,y-.065,z+.047],[x+.015,y-.065,z+.050],[x+.068,y-.065,z+.054]],.006,chrome)
    # Locate the recessed horizontal bowl floor in the imported geometry.
    # The model's basin is offset within its bbox, so do not use the bbox centre.
    cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1)
    horizontal=(abs(cross[:,2])>.999*area)&(area>1e-7)
    recessed=(tri[:,:,2].min(axis=1)>.60)&(tri[:,:,2].max(axis=1)<.70)
    candidates=tri[horizontal&recessed];weights=area[horizontal&recessed]
    assert len(candidates), 'No recessed basin floor found'
    drain=np.average(candidates.mean(axis=1),axis=0,weights=weights)
    drain_x,drain_y=map(float,drain[:2]);drain_z=surface_height(drain_x,drain_y,ceiling=.70)
    for angle in np.linspace(0,2*math.pi,32,endpoint=False):
        assert abs(surface_height(drain_x+.024*math.cos(angle),drain_y+.024*math.sin(angle),ceiling=.70)-drain_z)<.0005
    print('DRAIN_MOUNT',drain_x,drain_y,drain_z,flush=True)
    lathe(stage,'/World/Decor/SinkDrain',[(0,0),(0,.024),(.002,.024),(.004,.017),(.004,0)],chrome,center=(drain_x,drain_y,drain_z-.0003))
    lathe(stage,'/World/Decor/DrainInset',[(0,0),(0,.014),(.001,.014)],dark,center=(drain_x,drain_y,drain_z+.004))
    for i in [-1,0,1]:
        d=i*.006;half=math.sqrt(.013**2-d*d)
        tube(stage,'/World/Decor/DrainGrille'+str(i+1),[[drain_x-half,drain_y+d,drain_z+.005],[drain_x+half,drain_y+d,drain_z+.005]],.001,chrome,sides=12)


def finish_details(env,task_id):
    """Call inside one paused USD edit transaction after all objects are loaded."""
    import omnigibson as og
    from pxr import UsdShade, Sdf
    stage=og.sim.stage
    for prim in stage.Traverse():
        attr=prim.GetAttribute('despite:roughness')
        if attr and attr.HasValue():
            UsdShade.Shader(stage.GetPrimAtPath(str(prim.GetPath())+'/Shader')).CreateInput('reflection_roughness_constant',Sdf.ValueTypeNames.Float).Set(attr.Get())
    refine_fetch(stage,env.scene.robots[0])
    if task_id=='alfred_2757':refine_faucet(stage,env.scene.object_registry('name','bathroom_vanity'))


def capture_details(output,task_id):
    """Actual RTX close-ups at the settled initial state, without physics steps."""
    import omnigibson as og
    import torch
    import imageio.v2 as imageio
    from scipy.spatial.transform import Rotation
    camera=og.sim.viewer_camera
    old_pose=camera.get_position_orientation();old_focal=camera.focal_length
    views=[('detail-fetch',[1.6,-2.65,1.8],[0,-1,.85],23)]
    if task_id=='neiss_2888':
        views += [('detail-object',[.14,-1.65,1.10],[.65,-.97,.85],46),
                  ('detail-room',[1.4,-2.6,1.55],[-1.8,-.3,.85],18)]
    else:
        views += [('detail-object',[.15,.55,1.18],[.8,1.2,.94],34),
                  ('detail-fixture',[1.72,-1.3,1.25],[2.34,-.66,.83],34),
                  ('detail-mount',[1.83,-1.08,.86],[2.19,-.76,.77],46),
                  ('detail-room',[-1.35,-2.2,1.55],[1.30,.3,.9],19)]
    for name,position,target,focal in views:
        pos=np.array(position);z=pos-np.array(target);z/=np.linalg.norm(z)
        x=np.cross([0,0,1],z);x/=np.linalg.norm(x);y=np.cross(z,x)
        camera.set_position_orientation(torch.tensor(pos,dtype=torch.float32),torch.tensor(Rotation.from_matrix(np.column_stack([x,y,z])).as_quat(),dtype=torch.float32))
        camera.focal_length=focal
        for _ in range(32):og.sim.render()
        imageio.imwrite(output/(name+'.jpg'),camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3])
    camera.set_position_orientation(*old_pose);camera.focal_length=old_focal
    for _ in range(16):og.sim.render()
