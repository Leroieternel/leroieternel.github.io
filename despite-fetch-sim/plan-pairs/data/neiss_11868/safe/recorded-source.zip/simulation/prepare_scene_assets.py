"""Resolve pinned Genie room packages without executing dataset scripts."""
import concurrent.futures
import hashlib
import json
import posixpath
import re
import urllib.parse
import urllib.request
from pathlib import Path

from simulation.runtime import ROOT, RUNTIME

REVISION = '12f41e388a953cc2aeb0fe5b8eb516750c8321d9'
SCENES = {
    'kitchen': 'background/kitchen/kitchen_1/background.usda',
    'study': 'background/study_room/study_1/background.usda',
    'lobby': 'background/hotle/hotle_00/background.usda',
}
SUFFIXES = {'.usd', '.usda', '.usdc', '.usdz', '.png', '.jpg', '.jpeg', '.exr', '.hdr', '.mdl'}


def main():
    cache = RUNTIME/'genie-assets'
    metadata_path = RUNTIME/'genie-metadata.json'
    if not metadata_path.exists():
        url = 'https://huggingface.co/api/datasets/agibot-world/GenieSimAssets/revision/'+REVISION
        with urllib.request.urlopen(url, timeout=60) as response:
            metadata_path.write_bytes(response.read())
    metadata = json.loads(metadata_path.read_text())
    assert metadata['sha'] == REVISION
    available = {x['rfilename'] for x in metadata['siblings']}
    base = 'https://huggingface.co/datasets/agibot-world/GenieSimAssets/resolve/'+REVISION+'/'
    selected = set(SCENES.values())

    def download(path):
        target = cache/path
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            request = urllib.request.Request(base+urllib.parse.quote(path), headers={'User-Agent':'DESPITE scene diversity pilot'})
            with urllib.request.urlopen(request, timeout=120) as response:
                temporary = target.with_suffix(target.suffix+'.partial')
                with temporary.open('wb') as output:
                    while chunk := response.read(1024*1024): output.write(chunk)
                temporary.replace(target)
        return path

    done = set()
    while selected-done:
        pending = sorted(selected-done)
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            for i,path in enumerate(pool.map(download, pending),1):
                if i%20 == 0: print('DOWNLOADED',len(done)+i,'files',flush=True)
        done.update(pending)
        # USDA scene references select complete asset directories, including
        # textures used inside binary USD crates. Ignore stale assetInfo paths
        # that are not members of the pinned repository.
        for path in pending:
            if not path.endswith('.usda'): continue
            text = (cache/path).read_text()
            for ref in re.findall(r'@([^@]+)@',text):
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(path),ref))
                if resolved not in available: continue
                selected.add(resolved)
                directory = posixpath.dirname(resolved)+'/'
                if resolved.endswith(('.usd','.usda','.usdc','.usdz')):
                    selected.update(x for x in available if x.startswith(directory) and Path(x).suffix.lower() in SUFFIXES)
    files=[]
    for path in sorted(done):
        target=cache/path
        with target.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
        files.append({'path':path,'size':target.stat().st_size,'sha256':digest})
    manifest={'repository':'agibot-world/GenieSimAssets','revision':REVISION,'license':'CC-BY-NC-SA-4.0','scenes':SCENES,'files':files}
    (ROOT/'simulation/scene_assets.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'files':len(files),'bytes':sum(x['size'] for x in files),'scenes':SCENES}),flush=True)


if __name__=='__main__':main()
