"""Furnished, enclosed interiors rendered by Isaac Sim RTX.

BEHAVIOR furniture, CC0 Poly Haven materials and USD assets. Task supports
retain dimensioned collision proxies; decorative meshes never drive results.
"""
import json
import math
from pathlib import Path
from simulation.runtime import RUNTIME
from simulation.scenes import box

ASSETS = RUNTIME / 'datasets/behavior-1k-assets/objects'
MATERIALS = RUNTIME / 'materials'
MODELS = RUNTIME / 'models'


def furniture(name, category, model, center, size, yaw=0):
    metadata = json.loads((ASSETS / category / model / 'misc/metadata.json').read_text())
    offset = [size[i] / metadata['bbox_size'][i] * metadata['base_link_offset'][i] for i in range(3)]
    c, s = math.cos(yaw), math.sin(yaw)
    rotated = [c*offset[0]-s*offset[1], s*offset[0]+c*offset[1], offset[2]]
    return dict(type='DatasetObject', name=name, category=category, model=model, bounding_box=size,
                position=[center[i]-rotated[i] for i in range(3)],
                orientation=[0,0,math.sin(yaw/2),math.cos(yaw/2)], fixed_base=True, visual_only=True)


def upgrade_config(config, task_id):
    from simulation.detail_assets import create_bottle
    bedroom = task_id == 'neiss_2888'
    rear=1.65 if bedroom else 2.6
    length=rear+3.3;middle=(rear-3.3)/2
    # Replace the open test stage with a complete architectural shell.
    objects = [o for o in config['objects'] if o['name'] not in {'back_wall','end_wall','baseboard'}]
    hidden = {'storage_top','storage_body','storage_handle','bed_frame','mattress','blanket','pillow',
              'bedside_table','bedside_base','sink_cabinet','sink_top','mirror','toilet_bowl','toilet_foot','tank_plinth','toilet_tank'}
    for obj in objects:
        if obj['name'] in hidden: obj['visible'] = False
    # Render meshes and collision hulls are authored together, in metres.
    for index,obj in enumerate(objects):
        if obj['name'] in ('water_bottle','pump_bottle'):
            kind='water' if obj['name']=='water_bottle' else 'soap'
            objects[index]=dict(type='USDObject',name=obj['name'],usd_path=create_bottle(kind),
                                position=obj['position'],fixed_base=False,
                                link_physics_materials={'base_link':{'static_friction':1.0,'dynamic_friction':.8,'restitution':0}})
    plaster = [.85,.82,.75]
    trim = [.91,.89,.83]
    objects += [
        box('textured_floor', [-.10,-.35,-.018], [5.8,5.9,.035], [1,1,1], visual_only=True),
        box('end_wall', [-.1,rear,1.5], [5.8,.12,3.0], [.56,.64,.57] if bedroom else plaster),
        box('entry_wall', [-.1,-3.3,1.5], [5.8,.12,3.0], plaster),
        box('left_wall', [-3.0,middle,1.5], [.12,length,3.0], plaster),
        box('ceiling', [-.1,middle,3.02], [5.8,length,.08], [.91,.89,.83]),
        # A real window opening in the east wall, with light entering the room.
        box('east_wall_low', [2.8,middle,.48], [.12,length,.96], plaster),
        box('east_wall_high', [2.8,middle,2.76], [.12,length,.48], plaster),
        box('east_wall_left', [2.8,-2.35,1.74], [.12,1.9,1.56], plaster),
        box('east_wall_right', [2.8,(rear+.4)/2,1.74], [.12,rear-.4,1.56], plaster),
        box('window_sill', [2.70,-.50,.96], [.34,1.9,.07], trim),
        box('window_frame_top', [2.74,-.50,2.5], [.10,1.84,.07], trim),
        box('window_frame_left', [2.74,-1.4,1.73], [.10,.07,1.54], trim),
        box('window_frame_right', [2.74,.40,1.73], [.10,.07,1.54], trim),
        box('window_mullion', [2.74,-.50,1.73], [.07,.035,1.54], trim),
        box('window_crossbar', [2.74,-.50,1.7], [.07,1.80,.035], trim),
        furniture('plant','pot_plant','mqhlkf',[2.20,-2.35,.70],[.60,.64,1.40]),
        box('sideboard_collision',[-2.57,-1.0,.39],[.44,1.90,.78],[.3,.3,.3],visible=False),
    ]
    for name, pos, size in [
        ('skirting_east',[2.72,-.35,.065],[.04,5.78,.13]),
        ('skirting_end',[-.1,rear-.08,.065],[5.65,.04,.13]),
        ('skirting_left',[-2.92,-.35,.065],[.04,5.78,.13]),
        ('cornice_east',[2.71,-.35,2.94],[.12,5.78,.12]),
        ('cornice_end',[-.1,rear-.09,2.94],[5.65,.12,.12]),
    ]: objects.append(box(name,pos,size,trim))
    if bedroom:
        objects += [
            furniture('bed_visual','bed','mpgavt',[1.91,.12,.39],[2.08,1.50,.78],yaw=-math.pi/2),
            furniture('reading_lamp','table_lamp','qgdwbh',[.94,1.27,.985],[.28,.28,.49]),
            furniture('console_lamp','table_lamp','qgdwbh',[-2.56,-.45,1.065],[.33,.33,.57]),
            furniture('sofa_visual','sofa','bskyog',[-1.67,1.10,.43],[.90,1.85,.86],yaw=-math.pi/2),
            furniture('wall_art','painting','jykkya',[1.90,rear-.1,1.85],[.025,.90,.78],yaw=-math.pi/2),
            furniture('bedside_rug','carpet','ctclvd',[.65,.02,.008],[1.45,2.65,.012]),
            box('sofa_collision',[-1.67,1.10,.43],[1.85,.9,.86],[.3,.3,.3],visible=False),
            box('coffee_table_collision',[-1.55,-.08,.24],[.95,.55,.48],[.3,.3,.3],visible=False),
            box('reading_lamp_collision',[.94,1.27,.985],[.23,.23,.49],[.3,.3,.3],visible=False),
        ]
    else:
        objects += [
            furniture('bathroom_vanity','furniture_sink','czyfhq',[2.40,-.55,.51],[.60,.90,1.02]),
            furniture('toilet_visual','toilet','obhimx',[1.24,1.0,.36],[.78,.50,.72],yaw=math.pi),
            furniture('bath_mat','carpet','ctclvd',[.80,-.05,.008],[.65,.85,.012]),
            furniture('bathroom_mirror','mirror','edxfnt',[-.65,2.51,1.8],[.02,1.05,.76],yaw=-math.pi/2),
            furniture('towel_rail','towel_rack','pqhsry',[-.65,2.46,1.12],[.07,.56,.08],yaw=-math.pi/2),
            box('flush_button',[.81,1.0,.808],[.045,.085,.008],[.5,.53,.54],visual_only=True),
        ]
    config['objects'] = objects
    # Keep background collision proxies aligned with the visible furniture.
    # Task support tops and original plan coordinates stay dimensioned above.
    for obj in objects:
        if obj['name']=='bed_frame': obj.update(position=[1.91,.12,.26],scale=[1.50,2.08,.36])
        if obj['name']=='mattress': obj.update(position=[1.91,.12,.51],scale=[1.48,2.04,.20])
        if obj['name']=='sink_cabinet': obj.update(position=[2.4,-.55,.36],scale=[.60,.90,.72])
        if obj['name']=='sink_top': obj.update(position=[2.4,-.55,.73794],scale=[.60,.90,.03])
    config['scene'].update(floor_plane_visible=False, use_skybox=False)
    config['render'] = {'viewer_width':1440,'viewer_height':960}
    return config


def _pbr(stage, name, color, roughness=.6, metal=0):
    import omnigibson.lazy as L
    S=L.pxr.UsdShade; T=L.pxr.Sdf.ValueTypeNames
    mat=S.Material.Define(stage, '/World/DecorMaterials/'+name)
    shader=S.Shader.Define(stage, mat.GetPath().AppendChild('Shader'))
    shader.CreateIdAttr('UsdPreviewSurface')
    shader.CreateInput('diffuseColor',T.Color3f).Set(L.pxr.Gf.Vec3f(*color))
    shader.CreateInput('roughness',T.Float).Set(roughness)
    shader.CreateInput('metallic',T.Float).Set(metal)
    mat.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(),'surface')
    return mat


def _textured_pbr(stage, name, asset, color=(1,1,1), scale=(1,1), normal_strength=.4):
    """Use all three PBR maps, including the roughness map OG normally disables."""
    from simulation.detail_assets import pbr
    import omnigibson.lazy as L
    T=L.pxr.Sdf.ValueTypeNames
    mat=pbr(stage,'/World/DecorMaterials/'+name,color,.7)
    sh=L.pxr.UsdShade.Shader(stage.GetPrimAtPath(str(mat.GetPath())+'/Shader'))
    for channel,input_name in [('Diffuse','diffuse_texture'),('nor_gl','normalmap_texture'),('Rough','reflectionroughness_texture')]:
        sh.CreateInput(input_name,T.Asset).Set(L.pxr.Sdf.AssetPath(str(MATERIALS/asset/(channel+'.jpg'))))
    sh.CreateInput('texture_scale',T.Float2).Set(L.pxr.Gf.Vec2f(*scale))
    sh.CreateInput('bump_factor',T.Float).Set(normal_strength)
    sh.CreateInput('diffuse_tint',T.Color3f).Set(L.pxr.Gf.Vec3f(*color))
    sh.CreateInput('reflection_roughness_texture_influence',T.Float).Set(1)
    return mat


def _planar_uv(mesh):
    """Project each face in world metres; primitive cube UVs stretch on walls."""
    import numpy as np
    import omnigibson.lazy as L
    transform=L.pxr.UsdGeom.Xformable(mesh).ComputeLocalToWorldTransform(0)
    points=np.array([transform.Transform(L.pxr.Gf.Vec3d(*map(float,p))) for p in mesh.GetPointsAttr().Get()])
    counts=mesh.GetFaceVertexCountsAttr().Get();indices=mesh.GetFaceVertexIndicesAttr().Get()
    uv=[];offset=0
    for count in counts:
        face=points[list(indices[offset:offset+count])];offset+=count
        normal=np.cross(face[1]-face[0],face[2]-face[0]);axis=np.argmax(abs(normal))
        axes=[i for i in range(3) if i!=axis];uv.extend(face[:,axes].tolist())
    st=L.pxr.UsdGeom.PrimvarsAPI(mesh).CreatePrimvar('st',L.pxr.Sdf.ValueTypeNames.TexCoord2fArray,'faceVarying')
    st.SetInterpolation('faceVarying');st.Set(uv);st.BlockIndices()


def _cloth(stage,name,points,nx,nz,material,uv_size):
    """Dense draped mesh with smooth normals and metre-scaled textile UVs."""
    import numpy as np
    import omnigibson.lazy as L
    U,S,T=L.pxr.UsdGeom,L.pxr.UsdShade,L.pxr.Sdf.ValueTypeNames
    grid=np.asarray(points).reshape(nz+1,nx+1,3)
    normal=np.cross(np.gradient(grid,axis=1),np.gradient(grid,axis=0))
    normal/=np.maximum(np.linalg.norm(normal,axis=2,keepdims=True),1e-8)
    normals=normal.reshape(-1,3).tolist()
    uv=[(i/nx*uv_size[0],j/nz*uv_size[1]) for j in range(nz+1) for i in range(nx+1)]
    indices=[]
    for j in range(nz):
        for i in range(nx):
            a=j*(nx+1)+i;indices.extend([a,a+1,a+nx+2,a+nx+1])
    mesh=U.Mesh.Define(stage,'/World/Decor/'+name)
    mesh.CreatePointsAttr(points);mesh.CreateFaceVertexCountsAttr([4]*(nx*nz));mesh.CreateFaceVertexIndicesAttr(indices)
    mesh.CreateNormalsAttr([normals[i] for i in indices]);mesh.SetNormalsInterpolation('faceVarying')
    mesh.CreateSubdivisionSchemeAttr('none');mesh.CreateDoubleSidedAttr(True)
    U.PrimvarsAPI(mesh).CreatePrimvar('st',T.TexCoord2fArray,'faceVarying').Set([uv[i] for i in indices])
    S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(material)
    return mesh


def _usd_asset(stage, name, asset, center, size, yaw=0):
    """Reference an external USD and fit its visual bounds without exporting it."""
    import omnigibson as og
    import omnigibson.lazy as L
    U,G=L.pxr.UsdGeom,L.pxr.Gf
    outer=U.Xform.Define(stage,'/World/Decor/'+name)
    content=U.Xform.Define(stage,outer.GetPath().AppendChild('Fit'))
    source=U.Xform.Define(stage,content.GetPath().AppendChild('Asset'))
    source.GetPrim().GetReferences().AddReference(str(MODELS/asset/f'{asset}_2k.usdc'))
    # Use native OmniPBR for consistent RTX support instead of relying on a
    # Blender MaterialX graph. Preserve the downloaded mesh and its UVs.
    material_path=f'/World/DecorMaterials/{name}PBR'
    material=L.pxr.UsdShade.Material.Define(stage,material_path)
    shader=L.pxr.UsdShade.Shader.Define(stage,material_path+'/Shader')
    shader.SetSourceAsset(L.pxr.Sdf.AssetPath('OmniPBR.mdl'),'mdl')
    shader.SetSourceAssetSubIdentifier('OmniPBR','mdl')
    shader.CreateOutput('out',L.pxr.Sdf.ValueTypeNames.Token)
    material.CreateSurfaceOutput('mdl').ConnectToSource(shader.ConnectableAPI(),'out')
    for input_name,pattern in [('diffuse_texture','*_diff_2k.*'),
                                ('normalmap_texture','*_nor_gl_2k.*'),
                                ('reflectionroughness_texture','*_rough*_2k.*'),
                                ('metallic_texture','*_metal_2k.*')]:
        files=sorted((MODELS/asset/'textures').glob(pattern))
        if files:
            shader.CreateInput(input_name,L.pxr.Sdf.ValueTypeNames.Asset).Set(L.pxr.Sdf.AssetPath(str(files[0])))
    shader.CreateInput('diffuse_color_constant',L.pxr.Sdf.ValueTypeNames.Color3f).Set(G.Vec3f(1,1,1))
    shader.CreateInput('reflection_roughness_constant',L.pxr.Sdf.ValueTypeNames.Float).Set(.4)
    shader.CreateInput('reflection_roughness_texture_influence',L.pxr.Sdf.ValueTypeNames.Float).Set(1)
    shader.CreateInput('metallic_texture_influence',L.pxr.Sdf.ValueTypeNames.Float).Set(1)
    # Poly Haven's MaterialX network references EXR roughness, while its USD
    # download manifest supplies JPEG. Resolve that packaging mismatch locally.
    for prim in L.pxr.Usd.PrimRange(content.GetPrim()):
        # Blender exports this cabinet's door-motion guide curves as renderable
        # curves with a default tube width. They are rig helpers, not furniture.
        if prim.GetTypeName() in ('BasisCurves','NurbsCurves'):
            U.Imageable(prim).MakeInvisible()
        if prim.IsA(U.Mesh):
            L.pxr.UsdShade.MaterialBindingAPI.Apply(prim).Bind(material, bindingStrength=L.pxr.UsdShade.Tokens.strongerThanDescendants)
        for attr in prim.GetAttributes():
            if attr.GetTypeName() == L.pxr.Sdf.ValueTypeNames.Asset:
                value=attr.Get()
                if value and value.path.startswith('./textures/'):
                    path=MODELS/asset/value.path
                    if not path.exists() and path.with_suffix('.jpg').exists():
                        attr.Set(L.pxr.Sdf.AssetPath(str(path.with_suffix('.jpg'))))
    cache=U.BBoxCache(L.pxr.Usd.TimeCode.Default(),[U.Tokens.default_,U.Tokens.render])
    bounds=cache.ComputeLocalBound(content.GetPrim()).ComputeAlignedRange()
    lo,hi=bounds.GetMin(),bounds.GetMax(); native=hi-lo
    scale=G.Vec3d(*[size[i]/native[i] for i in range(3)])
    mid=(lo+hi)*.5
    content.AddTranslateOp().Set(G.Vec3d(*[-mid[i]*scale[i] for i in range(3)]))
    content.AddScaleOp().Set(scale)
    outer.AddTranslateOp().Set(G.Vec3d(*center));outer.AddRotateZOp().Set(yaw)
    fitted=U.BBoxCache(L.pxr.Usd.TimeCode.Default(),[U.Tokens.default_,U.Tokens.render]).ComputeWorldBound(outer.GetPrim()).ComputeAlignedRange()
    actual=(fitted.GetMin()+fitted.GetMax())*.5
    assert max(abs(actual[i]-center[i]) for i in range(3))<1e-4, f'Asset centre mismatch: {asset}'
    print('VISUAL_ASSET',asset,'native_bounds',list(native),flush=True)
    return outer


def _rounded_box(stage,name,center,size,radius,material):
    """Bevelled ceramic geometry; dimensions match the controlled support."""
    import numpy as np
    import omnigibson.lazy as L
    U,S=L.pxr.UsdGeom,L.pxr.UsdShade
    points=[];normals=[];uv=[];indices=[];counts=[];n=16
    half=np.array(size)/2; inner=half-radius
    for axis in range(3):
        other=[a for a in range(3) if a!=axis]
        for sign in [-1,1]:
            start=len(points)
            for j in range(n+1):
                for i in range(n+1):
                    p=np.zeros(3);p[axis]=sign*half[axis]
                    p[other[0]]=(i/n*2-1)*half[other[0]];p[other[1]]=(j/n*2-1)*half[other[1]]
                    q=np.clip(p,-inner,inner);delta=p-q
                    normal=delta/np.linalg.norm(delta)
                    p=q+radius*normal+center;points.append(p.tolist());normals.append(normal.tolist())
                    uv.append([p[other[0]],p[other[1]]])
            for j in range(n):
                for i in range(n):
                    a=start+j*(n+1)+i;indices.extend([a,a+1,a+n+2,a+n+1]);counts.append(4)
    mesh=U.Mesh.Define(stage,'/World/Decor/'+name);mesh.CreatePointsAttr(points)
    mesh.CreateFaceVertexCountsAttr(counts);mesh.CreateFaceVertexIndicesAttr(indices)
    mesh.CreateSubdivisionSchemeAttr('none');mesh.CreateDoubleSidedAttr(True)
    mesh.CreateNormalsAttr([normals[i] for i in indices]);mesh.SetNormalsInterpolation('faceVarying')
    U.PrimvarsAPI(mesh).CreatePrimvar('st',L.pxr.Sdf.ValueTypeNames.TexCoord2fArray,'faceVarying').Set([uv[i] for i in indices])
    S.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(material)


def finish_lighting(env, task_id='neiss_2888'):
    import omnigibson as og
    import omnigibson.lazy as L
    U,S,G,T=L.pxr.UsdGeom,L.pxr.UsdShade,L.pxr.Gf,L.pxr.Sdf.ValueTypeNames
    stage=og.sim.stage
    settings=L.carb.settings.get_settings()
    settings.set_int('/rtx/raytracing/showLights',0)
    settings.set_int('/rtx/post/dlss/execMode',1)
    settings.set_int('/rtx/directLighting/sampledLighting/samplesPerPixel',4)
    # RTX indirect light supplies contact shading; extra SSAO dirties corners.
    settings.set_bool('/rtx/ambientOcclusion/enabled',False)
    settings.set_int('/rtx/translucency/maxRefractionBounces',12)
    with og.sim.editing_usd():
        # Restore imported roughness maps and hide simulator affordance markers.
        for obj in env.scene.objects:
            for name,link in obj.links.items():
                if name.startswith('meta__'): U.Imageable(link.prim).MakeInvisible()
        for prim in stage.Traverse():
            if prim.IsA(S.Shader):
                sh=S.Shader(prim);tex=sh.GetInput('reflectionroughness_texture')
                if tex and tex.Get() and tex.Get().path:
                    sh.CreateInput('reflection_roughness_texture_influence',T.Float).Set(1)
        floor=env.scene.object_registry('name','textured_floor')
        shader=S.Shader(stage.GetPrimAtPath(f'{floor.prim_path}/Looks/default/Shader'))
        material='wood_floor' if task_id=='neiss_2888' else 'large_floor_tiles_02'
        for channel,input_name in [('Diffuse','diffuse_texture'),('nor_gl','normalmap_texture'),('Rough','reflectionroughness_texture')]:
            shader.CreateInput(input_name,T.Asset).Set(L.pxr.Sdf.AssetPath(str(MATERIALS/material/(channel+'.jpg'))))
        shader.CreateInput('texture_scale',T.Float2).Set(G.Vec2f(3.0,3.0))
        shader.CreateInput('reflection_roughness_constant',T.Float).Set(.42)
        shader.CreateInput('diffuse_color_constant',T.Color3f).Set(G.Vec3f(1,1,1))
        # Preserve the already-approved floor finish.
        shader.CreateInput('reflection_roughness_texture_influence',T.Float).Set(0)
        for obj in env.scene.objects:
            if obj.name.endswith('wall') or obj.name.startswith('east_wall_'):
                color=(.56,.64,.57) if obj.name=='end_wall' and task_id=='neiss_2888' else (.85,.82,.75)
                wallmat=_textured_pbr(stage,obj.name+'Plaster','white_plaster_02',color,(1,1),.12)
                wallshader=S.Shader(stage.GetPrimAtPath(str(wallmat.GetPath())+'/Shader'))
                # Painted plaster retains fine relief, not the source scan's
                # large stains. Pigment color is independent of microgeometry.
                wallshader.GetPrim().RemoveProperty('inputs:diffuse_texture')
                wallshader.CreateInput('diffuse_tint',T.Color3f).Set(G.Vec3f(1,1,1))
                wallshader.CreateInput('reflection_roughness_texture_influence',T.Float).Set(.35)
                for prim in L.pxr.Usd.PrimRange(obj.prim):
                    if prim.IsA(U.Mesh) and 'visual' in str(prim.GetPath()):
                        _planar_uv(U.Mesh(prim))
                        S.MaterialBindingAPI.Apply(prim).Bind(wallmat,bindingStrength=S.Tokens.strongerThanDescendants)
        # Remove dataset lamp overrides: imported lights otherwise get 10,000
        # intensity, regardless of their shade, radius or intended wattage.
        for prim in stage.Traverse():
            if prim.HasAPI(L.pxr.UsdLux.LightAPI):
                prim.GetAttribute('inputs:intensity').Set(0)
        # Overcast window and broad reflected wall/ceiling illumination.
        for name,pos,intensity,color,w,h,rotation in [
            ('WindowKey',[2.60,-.50,1.80],2000,[.92,.96,1],1.65,1.8,[0,90,0]),
            ('CeilingFill',[-.15,-.85,2.92],600,[1,.96,.90],4.7,3.9,[0,0,0]),
            ('CameraFill',[-1.8,-2.0,2.2],700,[1,.97,.93],1.6,1.4,[35,0,-40]),
            ('WallBounce',[-2.85,-.6,1.5],200,[.95,.97,1],2.5,3.4,[0,-90,0]),
        ]:
            light=L.pxr.UsdLux.RectLight.Define(stage,'/World/'+name)
            light.CreateIntensityAttr(intensity);light.CreateColorAttr(G.Vec3f(*color))
            light.CreateWidthAttr(w);light.CreateHeightAttr(h)
            xf=U.Xformable(light);xf.AddTranslateOp().Set(G.Vec3d(*pos));xf.AddRotateXYZOp().Set(G.Vec3f(*rotation))
            light.GetPrim().CreateAttribute('visibleInPrimaryRay',T.Bool).Set(False)
            if name in ('CameraFill','WallBounce'):
                # These represent broad room bounce, not additional spotlights.
                L.pxr.UsdLux.LightAPI(light).GetShadowLinkCollectionAPI().CreateIncludeRootAttr().Set(False)
        # RT 2.0 ignores the legacy ambientLightIntensity setting. A modest,
        # unshadowed dome supplies the missing diffuse room fill. Key, ceiling
        # and practical lights continue to cast contact shadows.
        ambient=L.pxr.UsdLux.DomeLight.Define(stage,'/World/SoftAmbient')
        ambient.CreateIntensityAttr(100);ambient.CreateColorAttr(G.Vec3f(.96,.98,1))
        L.pxr.UsdLux.LightAPI(ambient).GetShadowLinkCollectionAPI().CreateIncludeRootAttr().Set(False)
        ambient.GetPrim().CreateAttribute('visibleInPrimaryRay',T.Bool).Set(False)
        from simulation.detail_assets import finish_details
        finish_details(env,task_id)
        _usd_asset(stage,'SourceTable','side_table_01',[.70,-1,.37],[.70,.70,.74],yaw=90)
        _usd_asset(stage,'Sideboard','modern_wooden_cabinet',[-2.57,-1.0,.39],[1.90,.44,.78],yaw=90)
        # Draped linen curtains: actual pleated meshes, with cast shadows.
        fabric=_textured_pbr(stage,'CurtainLinen','cotton_jersey',(.82,.77,.66),normal_strength=.45)
        blind_mat=_pbr(stage,'PaintedBlinds',[.90,.88,.82],.6)
        glass_mat=_pbr(stage,'FrostedWindow',[.80,.86,.91],.35)
        glass_shader=S.Shader(stage.GetPrimAtPath('/World/DecorMaterials/FrostedWindow/Shader'))
        glass_shader.CreateInput('emissiveColor',T.Color3f).Set(G.Vec3f(.7,.75,.8))
        for name,position,scale,mat in [('FrostedGlass',[2.83,-.5,1.73],[.01,1.8,1.48],glass_mat)]+[
            (f'Blind{i}',[2.70,-.50,1.02+i*.039],[.06,1.78,.005],blind_mat) for i in range(37)]:
            cube=U.Cube.Define(stage,'/World/Decor/'+name);cube.CreateSizeAttr(1)
            cube.AddTranslateOp().Set(G.Vec3d(*position));cube.AddRotateYOp().Set(40 if name.startswith('Blind') else 0)
            cube.AddScaleOp().Set(G.Vec3d(*scale));S.MaterialBindingAPI.Apply(cube.GetPrim()).Bind(mat)
        for side,y0 in [('Left',-1.70),('Right',.42)]:
            points=[];nx,nz=96,96
            for j in range(nz+1):
                z=.10+2.60*j/nz
                for i in range(nx+1):
                    t=i/nx;v=j/nz
                    y=y0+.40*t+.008*math.sin(9*t+4*v)*(1-v)
                    x=2.51+(.045+.012*(1-v))*math.cos(t*math.pi*10+.18*math.sin(v*7+t*4))
                    x+=.009*math.sin(t*37+v*8)*(1-v)+.014*math.sin(v*math.pi)
                    points.append((x,y,z))
            _cloth(stage,'Curtain'+side,points,nx,nz,fabric,(.6/.264,2.6/.264))
        if task_id=='neiss_2888':
            _usd_asset(stage,'BedsideTable','side_table_01',[.70,1,.37],[.70,.72,.74],yaw=90)
            _usd_asset(stage,'CoffeeTable','modern_coffee_table_01',[-1.55,-.08,.24],[.95,.55,.48])
            pillows=_usd_asset(stage,'BedPillows','throw_pillows_01',[1.91,.78,.67],[1.10,.47,.26],yaw=0)
            pillowmat=_textured_pbr(stage,'PillowLinen','cotton_jersey',(.94,.91,.84),(3,3),.45)
            for prim in L.pxr.Usd.PrimRange(pillows.GetPrim()):
                if prim.IsA(U.Mesh):S.MaterialBindingAPI.Apply(prim).Bind(pillowmat,bindingStrength=S.Tokens.strongerThanDescendants)
            # Practical lamps: warm local illumination from within real shades.
            for name,pos in [('BedsideBulb',[.94,1.27,1.04]),('ConsoleBulb',[-2.56,-.45,1.13])]:
                light=L.pxr.UsdLux.SphereLight.Define(stage,'/World/'+name)
                light.CreateRadiusAttr(.035);light.CreateIntensityAttr(3800)
                light.CreateColorAttr(G.Vec3f(1,.77,.48))
                U.Xformable(light).AddTranslateOp().Set(G.Vec3d(*pos))
                light.GetPrim().CreateAttribute('visibleInPrimaryRay',T.Bool).Set(False)
                down=L.pxr.UsdLux.DiskLight.Define(stage,'/World/'+name+'Downlight')
                down.CreateRadiusAttr(.085);down.CreateIntensityAttr(2200);down.CreateColorAttr(G.Vec3f(1,.77,.48))
                U.Xformable(down).AddTranslateOp().Set(G.Vec3d(pos[0],pos[1],pos[2]-.075))
                down.GetPrim().CreateAttribute('visibleInPrimaryRay',T.Bool).Set(False)
            # A folded linen duvet with a draped hem and small, geometric folds.
            duvet=_textured_pbr(stage,'Duvet','cotton_jersey',(.94,.94,.88),normal_strength=.5)
            points=[];n=110
            for j in range(n+1):
                y=-1.02+1.62*j/n
                for i in range(n+1):
                    x=1.10+1.62*i/n
                    side=max(0,(abs(x-1.91)-.65)/.16)
                    foot=max(0,(-.82-y)/.20)
                    fold=.014*math.sin(8*x+4*y)+.009*math.sin(19*x-5*y)*math.exp(-((y+.55)/.5)**2)
                    fold+=.009*math.sin(42*x+7*y)*(min(1,side+foot))
                    fold+=.028*math.exp(-((y-.47+.035*math.sin(x*9))/.07)**2)
                    z=.55-.24*max(side,foot)**1.35+fold
                    points.append((x,y,z))
            _cloth(stage,'Duvet',points,n,n,duvet,(1.62/.264,1.62/.264))
        else:
            ceramic=_pbr(stage,'Ceramic',[.88,.88,.84],.22)
            _rounded_box(stage,'Cistern',[.72,1.0,.60],[.38,.68,.40],.035,ceramic)
            _rounded_box(stage,'CisternLid',[.72,1.0,.789],[.39,.69,.022],.010,ceramic)
            _rounded_box(stage,'RearPedestal',[.79,1.0,.24],[.30,.40,.48],.065,ceramic)
            walnut=_textured_pbr(stage,'VanityWalnut','walnut_veneer',scale=(1,1),normal_strength=.25)
            for i in range(2):
                _rounded_box(stage,'VanityDoor'+str(i),[2.089,-.768+i*.435,.418],[.035,.423,.65],.008,walnut)
            # Fine drawer gaps, bevels and metal pulls catch the soft window light.
            from simulation.detail_assets import tube,pbr
            pulls=pbr(stage,'/World/DecorMaterials/BrushedNickel',[.65,.67,.66],.26,.9)
            for i in range(2):
                y=-.768+i*.435
                tube(stage,'/World/Decor/VanityPull'+str(i),[[2.055,y-.075,.66],[2.055,y+.075,.66]],.005,pulls)
            towel=_textured_pbr(stage,'CottonTowel','cotton_jersey',(.71,.80,.76),normal_strength=.7)
            pts=[];idx=[];cnt=[]
            for j in range(25):
                for i in range(31):
                    pts.append([-.88+.46*i/30,2.38+.018*math.cos(i/30*math.pi*8),.52+.62*j/24])
            _cloth(stage,'HangingTowel',pts,30,24,towel,(.46/.264,.62/.264))
    # Allow RTX material and camera buffers to converge before recording.
    for _ in range(16): og.sim.render()
