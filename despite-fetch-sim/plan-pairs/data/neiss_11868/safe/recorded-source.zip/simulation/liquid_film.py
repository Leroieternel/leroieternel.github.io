"""Conservative subgrid floor-film model driven by PBD contact samples.

This is a one-way, uncalibrated surface model, not a second PhysX solver.
Each contacting particle contributes its nominal volume exactly once. The
height field levels under a lubrication-style gravity flux plus an explicit
phenomenological wetting diffusivity. Positivity-limited face fluxes conserve
volume. No labels, action names, or desired outcomes enter this module.
It does not change the PBD trajectories or the benchmark's spill measurements.
"""
import numpy as np


FILM_CONFIG = dict(revision='conservative-floor-film-v1', cell_size_m=.0015,
                   kinematic_viscosity_m2_s=4e-6, wetting_diffusivity_m2_s=1.5e-6,
                   max_leveling_diffusivity_m2_s=1e-3,
                   max_substep_s=1/240, floor_z_m=0., surface_offset_m=.00006,
                   visible_depth_m=2e-6, calibration_status='uncalibrated',
                   coupling='one-way PBD contacts to conservative surface film',
                   limitations='No two-way particle coupling, evaporation, absorption, measured contact angle, or slip-friction feedback.')


class FloorFilm:
    def __init__(self, particle_count, particle_volume_ml, bounds=(-1.35,1.35,-1.33,1.37),
                 obstacles=(), config=None):
        self.cfg={**FILM_CONFIG,**(config or {})}
        self.dx=self.cfg['cell_size_m'];self.origin=np.array([bounds[0],bounds[2]])
        self.shape=tuple(np.ceil((np.array([bounds[1],bounds[3]])-self.origin)/self.dx).astype(int)+1)
        self.height=np.zeros(self.shape,np.float64)
        self.blocked=np.zeros(self.shape,bool)
        for obstacle in obstacles:
            lo=np.maximum(np.floor((np.array(obstacle['lo'])-self.origin)/self.dx).astype(int),0)
            hi=np.minimum(np.ceil((np.array(obstacle['hi'])-self.origin)/self.dx).astype(int),self.shape)
            self.blocked[lo[0]:hi[0],lo[1]:hi[1]]=True
        self.deposited=np.zeros(particle_count,bool)
        self.particle_volume_m3=particle_volume_ml*1e-6
        self.deposits=[];self.time=0.;self.substeps=0
        self.active_lo=np.array(self.shape);self.active_hi=np.zeros(2,dtype=int)

    def update(self, positions, contact_ids, time_s):
        if time_s < self.time-1e-8:raise ValueError('Film time cannot move backwards')
        self.advance(time_s-self.time)
        p=np.asarray(positions)
        ids=np.asarray(contact_ids,dtype=int)
        ids=ids[~self.deposited[ids]]
        if len(ids):
            cells=np.rint((p[ids,:2]-self.origin)/self.dx).astype(int)
            for particle,cell in zip(ids,cells):
                # Deposit over a small impact kernel with exactly the supplied
                # volume. Truncate at no-flux solid boundaries and normalize.
                lo=cell-2;hi=cell+3
                if np.any(lo<0) or np.any(hi>=self.shape):continue
                sl=tuple(slice(a,b) for a,b in zip(lo,hi))
                x,y=np.mgrid[-2:3,-2:3]
                weights=np.exp(-(x*x+y*y)/1.6)*(~self.blocked[sl])
                if not weights.sum():continue
                self.height[sl]+=weights/weights.sum()*self.particle_volume_m3/self.dx**2
                self.deposited[particle]=True
                self.active_lo=np.minimum(self.active_lo,lo)
                self.active_hi=np.maximum(self.active_hi,hi)
                self.deposits.append({'particle_id':int(particle),'time_s':float(time_s),
                                      'position_m':p[particle].tolist()})
        self.time=float(time_s)

    def advance(self, duration):
        if duration<=0 or not self.deposited.any():return
        stable_dt=.20*self.dx**2/(self.cfg['max_leveling_diffusivity_m2_s']+self.cfg['wetting_diffusivity_m2_s'])
        n=max(1,int(np.ceil(duration/min(self.cfg['max_substep_s'],stable_dt))))
        dt=duration/n
        for _ in range(n):
            lo=np.maximum(self.active_lo-2,0);hi=np.minimum(self.active_hi+2,self.shape)
            sl=tuple(slice(a,b) for a,b in zip(lo,hi))
            h=self.height[sl];blocked=self.blocked[sl]
            # Height gradients drive volume flux across cell faces. The extra
            # diffusivity regularizes the unresolved moving contact line.
            mobility=9.81*h**3/(3*self.cfg['kinematic_viscosity_m2_s'])
            # Thick impact heaps lie outside the lubrication approximation.
            # A documented mobility cap keeps the explicit thin-layer model
            # monotone instead of producing checkerboard height spikes.
            D=np.minimum(mobility,self.cfg['max_leveling_diffusivity_m2_s'])+self.cfg['wetting_diffusivity_m2_s']
            fx=dt/self.dx**2*.5*(D[:-1]+D[1:])*(h[:-1]-h[1:])
            fy=dt/self.dx**2*.5*(D[:,:-1]+D[:,1:])*(h[:,:-1]-h[:,1:])
            fx[blocked[:-1]|blocked[1:]]=0;fy[blocked[:,:-1]|blocked[:,1:]]=0
            outgoing=np.zeros_like(h)
            outgoing[:-1]+=np.maximum(fx,0);outgoing[1:]+=np.maximum(-fx,0)
            outgoing[:,:-1]+=np.maximum(fy,0);outgoing[:,1:]+=np.maximum(-fy,0)
            scale=np.minimum(1.,np.divide(.24*h,outgoing,out=np.ones_like(h),where=outgoing>0))
            fx*=np.where(fx>=0,scale[:-1],scale[1:]);fy*=np.where(fy>=0,scale[:,:-1],scale[:,1:])
            h[:-1]-=fx;h[1:]+=fx;h[:,:-1]-=fy;h[:,1:]+=fy
            # Do not delete sub-visible fluid: the ledger includes all depths.
            wet=np.argwhere(h>1e-14)
            if len(wet):
                self.active_lo=lo+wet.min(0);self.active_hi=lo+wet.max(0)+1
            self.substeps+=1

    def snapshot(self):
        expected=self.deposited.sum()*self.particle_volume_m3
        volume=self.height.sum()*self.dx**2
        return {'deposited_particles':int(self.deposited.sum()),'film_volume_ml':float(volume*1e6),
                'input_volume_ml':float(expected*1e6),'volume_error_ml':float((volume-expected)*1e6),
                'visible_area_cm2':float((self.height>self.cfg['visible_depth_m']).sum()*self.dx**2*1e4),
                'max_depth_mm':float(self.height.max()*1e3),'substeps':self.substeps}

    def surface_grid(self):
        """Return a compact view including the dry edge of every active cell."""
        if not self.deposited.any():return None
        lo=np.maximum(self.active_lo-1,0);hi=np.minimum(self.active_hi+1,self.shape)
        sl=tuple(slice(a,b) for a,b in zip(lo,hi))
        return self.origin+lo*self.dx,self.height[sl]
