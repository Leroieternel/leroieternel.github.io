"""Native Genie Sim apartment, measured support surfaces and unchanged asset UVs."""
import json
import math
from pathlib import Path
import numpy as np
from simulation.runtime import ROOT, RUNTIME
from simulation.scenes import box, task_spec

ASSETS = RUNTIME / 'genie-assets'
ROOM = ASSETS / 'background/home/home_b/background.usda'
GENERATED = RUNTIME / 'generated/genie'
MODELS = {
    'water': 'objects/benchmark/bottle/benchmark_bottle_017/Aligned.usd',
    'soap': 'objects/benchmark/cleaning_products/benchmark_cleaning_products_007/Aligned.usd',
    'sponge': 'objects/benchmark/cleaning_products/benchmark_cleaning_products_009/Aligned.usd',
    'nightstand': 'background/common/nightstand/benchmark_nightstand_002/Aligned.usd',
    'pepsi': 'objects/benchmark/beverage_bottle/benchmark_beverage_bottle_095/Aligned.usd',
    'carton': 'objects/benchmark/carton/benchmark_carton_005/Aligned.usd',
    'cup': 'objects/benchmark/cup/benchmark_cup_105/Aligned.usd',
    'medicine': 'objects/benchmark/medicine_bottle/benchmark_medicine_bottle_000/Aligned.usd',
    'storage_bin': 'objects/benchmark/storage_box/benchmark_storage_box_000/Aligned.usd',
    'storage_pen': 'objects/benchmark/pen/benchmark_pen_008/Aligned.usd',
}


def native_spec(task_id):
    spec = task_spec(task_id)
    if task_id == 'neiss_2888':
        spec.update(source=[1.15, .45, .7241], target=[.62, 2.82, .7241],
                    half_height=.0817025, support_top=.6424, support_center=[.62, 2.82],
                    support_half=[.2191, .2782], object_radius=.040,
                    grasp_height_offset=.070, robot_position=[.50, .45, 0],
                    carry_position=[.90, .45, 1.13],
                    source_support_center=[1.15, .45], source_support_half=[.2191, .2782],
                    source_support_top=.6424,
                    routes={'navigate_to_bedside_table': {'points': [[.62, 2.11]], 'yaw': math.pi/2}},
                    camera={'eye': [-.85, -.45, 1.9], 'target': [1.25, 1.75, .80], 'focal': 14})
    else:
        spec.update(source=[2.88, -2.64, .770], target=[3.17, -2.13, .788],
                    half_height=.015422, support_top=.77228, support_center=[3.17, -2.0],
                    support_half=[.065, .175], object_radius=.073, object_half_xy=[.060276, .040177],
                    grasp_height_offset=.030, hazard_position=[3.17, -1.875, .884], hazard_radius=.055,
                    robot_position=[2.20, -2.97, 0], carry_position=[2.52, -2.97, 1.13],
                    source_support_center=[2.88, -2.64], source_support_half=[.065, .043],
                    source_support_top=.75442,
                    routes={'navigate_to_pump_bottle_area': {'points': [[2.20, -1.45]], 'yaw': 0},
                            'navigate_to_toilet_tank': {'points': [[2.85, -1.45]], 'yaw': -1.13}},
                    camera={'eye': [1.78, -1.0, 1.84], 'target': [2.92, -2.66, .82], 'focal': 14})
        spec['initial_geometry_revision'] = {
            'revision': 'vanity-pickup-clearance-v3',
            'previous_source_xy_m': [2.88, -3.28], 'source_xy_m': [2.88, -2.64],
            'previous_grasp_height_offset_m': .024, 'grasp_height_offset_m': .030,
            'grasp_reason': 'Raise the declared pinch point by 6 mm. Offline FK measures about 10.8 mm fingertip/table clearance while retaining overlap with the thin sponge; the old point left only 4.8 mm against a 6 mm planning margin.',
            'reason': 'Move the initial sponge from the narrow wall-side rim to the opposite supported rim of the same vanity. The original location conflicts with forearm clearance; the intervening basin is not a flat support.',
            'paired_initialization': True, 'source_dataset_specifies_metric_pose': False,
        }
    return spec


def prepared_object(kind, *, physical=True, refined=True):
    """Bake only coordinate transforms; retain native topology, UVs and materials."""
    import omnigibson as og
    if og.sim is None:
        from omnigibson.macros import gm
        og.launch(physics_dt=1/(480 if gm.ENABLE_HQ_RENDERING else 120), rendering_dt=1/(60 if gm.ENABLE_HQ_RENDERING else 30), sim_step_dt=1/(60 if gm.ENABLE_HQ_RENDERING else 30), viewer_width=1440, viewer_height=960)
    from pxr import Usd, UsdGeom, UsdPhysics, UsdShade, Gf, Sdf, PhysxSchema
    GENERATED.mkdir(parents=True, exist_ok=True)
    file = GENERATED / (kind + ('-refined' if refined else '-original') + '.usda')
    stage = Usd.Stage.CreateInMemory()
    root = stage.DefinePrim('/object', 'Xform'); stage.SetDefaultPrim(root)
    UsdGeom.SetStageMetersPerUnit(stage, 1); UsdGeom.SetStageUpAxis(stage, 'Z')
    stage.DefinePrim('/object/base_link', 'Xform')
    stage.DefinePrim('/object/base_link/visuals', 'Xform')
    asset = UsdGeom.Xform.Define(stage, '/object/base_link/visuals/Asset')
    asset.GetPrim().GetReferences().AddReference(str(ASSETS / MODELS[kind]))
    asset.AddRotateXOp().Set(90)
    if kind == 'sponge': asset.AddRotateYOp().Set(90)
    if kind == 'carton':
        # Fit the native carton across Fetch's parallel fingers. Preserve UVs.
        asset.AddRotateYOp().Set(90)
        asset.AddScaleOp(opSuffix='pilot').Set((.85,.85,.85))
    if kind == 'storage_bin':
        asset.AddScaleOp(opSuffix='pilot').Set((1.3,1.3,1.3))
    for prim in Usd.PrimRange(asset.GetPrim()):
        # Merely disabling CollisionAPI makes OG classify and hide the original
        # rendered mesh. Remove source simulation schemas from the visuals.
        for schema in prim.GetAppliedSchemas():
            if schema.startswith(('Physics','Physx')): prim.RemoveAPI(schema)
        if prim.IsA(UsdShade.Shader) and kind == 'pepsi' and refined:
            for attr in UsdShade.Shader(prim).GetInputs():
                value = attr.Get()
                if isinstance(value,Sdf.AssetPath) and value.path.endswith('T_body_Alb.jpg'):
                    attr.Set(Sdf.AssetPath(str(ROOT/'simulation/assets/pepsi-label-refined-v1.png')))
    b=UsdGeom.BBoxCache(0,['default','render']).ComputeWorldBound(asset.GetPrim()).ComputeAlignedRange()
    lo,hi=np.array(b.GetMin()),np.array(b.GetMax());size=hi-lo;center=(hi+lo)/2
    # A flattened local derivative avoids incompatible nested Y-up transforms
    # in OG's rigid-link loader. Texture references resolve to the pinned cache.
    stage=Usd.Stage.Open(stage.Flatten());root=stage.GetDefaultPrim()
    meshes=[]
    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Mesh):continue
        mesh=UsdGeom.Mesh(prim);transform=UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)
        points=np.array([transform.Transform(Gf.Vec3d(*map(float,p))) for p in mesh.GetPointsAttr().Get()])-center
        normals=mesh.GetNormalsAttr().Get()
        if normals:
            normals=np.array([transform.TransformDir(Gf.Vec3d(*map(float,n))) for n in normals])
            normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-10)
        meshes.append((str(prim.GetPath()),points,normals))
    for prim in stage.Traverse():
        if prim.IsA(UsdGeom.Xformable):UsdGeom.Xformable(prim).ClearXformOpOrder()
    for i,(path,points,normals) in enumerate(meshes):
        prim=stage.GetPrimAtPath(path);mesh=UsdGeom.Mesh(prim)
        mesh.GetPointsAttr().Set(points.tolist())
        mesh.CreateExtentAttr([points.min(axis=0).tolist(),points.max(axis=0).tolist()])
        if normals is not None and len(normals):mesh.GetNormalsAttr().Set(normals.tolist())
        # OG indexes each link's meshes by leaf name; source assets reuse visual.
        edits=Sdf.BatchNamespaceEdit();new=prim.GetPath().GetParentPath().AppendChild(f'mesh_{i}')
        edits.Add(prim.GetPath(),new);assert stage.GetRootLayer().Apply(edits)
        mesh=UsdGeom.Mesh(stage.GetPrimAtPath(new))
        if physical and UsdGeom.Imageable(mesh.GetPrim()).ComputeVisibility()!='invisible':
            hull=UsdGeom.Mesh.Define(stage,f'/object/base_link/collisions/part_{i}')
            hull.CreatePointsAttr(points.tolist());hull.CreateFaceVertexCountsAttr(mesh.GetFaceVertexCountsAttr().Get())
            hull.CreateFaceVertexIndicesAttr(mesh.GetFaceVertexIndicesAttr().Get());hull.CreatePurposeAttr('guide')
            UsdPhysics.CollisionAPI.Apply(hull.GetPrim())
            UsdPhysics.MeshCollisionAPI.Apply(hull.GetPrim()).CreateApproximationAttr('convexHull')
            PhysxSchema.PhysxCollisionAPI.Apply(hull.GetPrim())
    root.SetCustomDataByKey('despiteDimensions',Gf.Vec3d(*map(float,size)))
    root.SetCustomDataByKey('despiteSource',MODELS[kind])
    stage.GetRootLayer().Export(str(file))
    return str(file),size


def measure_surface(token, samples, ceiling, room=ROOM):
    """Intersect authored triangles vertically; do not infer height from a bbox."""
    from pxr import Usd, UsdGeom, Gf
    stage = Usd.Stage.Open(str(room))
    bounds=UsdGeom.BBoxCache(0,['default','render'])
    sample_lo=np.min(np.asarray(samples),axis=0);sample_hi=np.max(np.asarray(samples),axis=0)
    triangles = []
    for prim in stage.Traverse():
        if token not in str(prim.GetPath()) or not prim.IsA(UsdGeom.Mesh): continue
        if UsdGeom.Imageable(prim).ComputeVisibility()=='invisible': continue
        bound=bounds.ComputeWorldBound(prim).ComputeAlignedRange()
        lo,hi=np.array(bound.GetMin()),np.array(bound.GetMax())
        if lo[2]>=ceiling or np.any(lo[:2]>sample_hi) or np.any(hi[:2]<sample_lo):continue
        mesh = UsdGeom.Mesh(prim)
        transform = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)
        vertices = np.array([transform.Transform(Gf.Vec3d(*map(float,p))) for p in mesh.GetPointsAttr().Get()])
        ids = mesh.GetFaceVertexIndicesAttr().Get(); offset = 0
        for count in mesh.GetFaceVertexCountsAttr().Get():
            face = ids[offset:offset+count]; offset += count
            for i in range(1,count-1): triangles.append(vertices[[face[0],face[i],face[i+1]]])
    tri = np.asarray(triangles); a = tri[:,0]; u = tri[:,1]-a; v = tri[:,2]-a
    det = u[:,0]*v[:,1]-u[:,1]*v[:,0]; valid = np.abs(det)>1e-10
    a,u,v,det = [x[valid] for x in (a,u,v,det)]
    heights = []
    for x,y in samples:
        d = np.array([x,y])-a[:,:2]
        s=(d[:,0]*v[:,1]-d[:,1]*v[:,0])/det; t=(u[:,0]*d[:,1]-u[:,1]*d[:,0])/det
        h=a[:,2]+s*u[:,2]+t*v[:,2]
        hits=(s>=-1e-7)&(t>=-1e-7)&(s+t<=1+1e-7)&(h<ceiling)
        assert hits.any(), f'No native support at {(x,y)}'
        heights.append(float(h[hits].max()))
    spread=max(heights)-min(heights)
    assert spread < .0005, f'Uneven support: {token} ({spread:.4f} m)'
    return {'surface_z_m': max(heights), 'surface_spread_m': spread, 'samples': len(heights)}


def native_config(config, spec):
    # All measured positions below are initialization, before the episode starts.
    if spec.get('scene_id'):
        from simulation.scene_cases import scene_config
        return scene_config(config, spec)
    task = spec['id']; water = spec.get('template_id',task) == 'neiss_2888'
    if water:
        path, dims = prepared_object(spec.get('object_kind','water'))
        table, td = prepared_object('nightstand', physical=False)
        spec['support_top'] = spec['source_support_top'] = float(td[2])
        spec['support_half'] = spec['source_support_half'] = (td[:2]/2).tolist()
        spec['surface_measurements'] = {'table_top_m':float(td[2]),'table_dimensions_m':td.tolist()}
    else:
        pump, pd = prepared_object('soap')
        # Genie 009 is labelled as a sponge in its description, but its rendered
        # geometry is a soap dish. Use the visually verified BEHAVIOR sponge.
        dims=np.array([.105,.070,.021])
        def samples(center, half):
            return [(center[0]+x,center[1]+y) for x in np.linspace(-half[0],half[0],5) for y in np.linspace(-half[1],half[1],5)]
        source = measure_surface('bathroom_vanity',samples(spec['source'][:2],dims[:2]/2),.80)
        target = measure_surface('toilet_000',samples(spec['target'][:2],dims[:2]/2),.80)
        hazard = measure_surface('toilet_000',samples(spec['hazard_position'][:2],[.034,.038]),.80)
        spec['source_support_top'] = source['surface_z_m']+.0003
        spec['support_top'] = max(target['surface_z_m'],hazard['surface_z_m'])+.0003
        spec['surface_measurements'] = {'source':source,'target':target,'hazard':hazard,'contact_overlay_m':.0003}
    spec['half_height'] = float(dims[2]/2)
    spec['source'][2] = spec['source_support_top'] + spec['half_height'] + .001
    spec['target'][2] = spec['support_top'] + spec['half_height']
    if not water:
        spec['object_half_xy'] = (dims[:2]/2).tolist()
        spec['object_radius'] = float(np.linalg.norm(dims[:2]/2))
    else:
        spec['object_radius'] = float(max(dims[:2])/2)
        if spec.get('object_kind')=='carton': spec['object_half_xy']=(dims[:2]/2).tolist()
    task_object=dict(name=spec['object'],position=spec['source'],fixed_base=False,
                     link_physics_materials={'base_link': {'static_friction':1.0,'dynamic_friction':.8,'restitution':0}})
    if water:task_object.update(type='USDObject',usd_path=path)
    else:task_object.update(type='DatasetObject',category='sponge',model='aewrov',bounding_box=dims.tolist())
    objects = [task_object]
    for name, center, half, top in [('storage_top', spec['source_support_center'], spec['source_support_half'], spec['source_support_top']),
                                   (spec['support'], spec['support_center'], spec['support_half'], spec['support_top'])]:
        objects.append(box(name, [*center, top-.012], [2*half[0],2*half[1],.024], [.5,.5,.5], visible=False))
    if water:
        for name, center in [('NativeSourceTable',spec['source_support_center']),('NativeBedsideTable',spec['support_center'])]:
            objects.append(dict(type='USDObject',name=name,usd_path=table,position=[*center,float(td[2]/2)],fixed_base=True,visual_only=True))
            objects.append(box(name+'_collision',[*center,float(td[2]/2)-.02], [float(td[0]),float(td[1]),float(td[2])-.04],[.5,.5,.5],visible=False))
        can, cd = prepared_object('pepsi', physical=False)
        objects.append(dict(type='USDObject',name='RefinedPepsiCan',usd_path=can,position=[1.00,.28,spec['source_support_top']+float(cd[2]/2)],orientation=[0,0,math.sin(.65/2),math.cos(.65/2)],fixed_base=True,visual_only=True))
    else:
        spec['hazard_position'][2] = spec['support_top']+float(pd[2]/2)+.001
        objects.append(dict(type='USDObject',name=spec['hazard'],usd_path=pump,position=spec['hazard_position'],fixed_base=False))
    config['objects'] = objects
    if spec.get('stool'):
        s=spec['stool']
        config['objects'].append(dict(type='DatasetObject',name='path_stool',category='footstool',model=s['model'],
                                      bounding_box=s['dimensions'],position=s['position'],fixed_base=False))
    config['robots'][0]['position'] = spec['robot_position']
    config['scene'].update(floor_plane_visible=False, use_skybox=False)
    config['render'] = {'viewer_width':1440,'viewer_height':960}
    return config


def finish_native_scene(env, spec):
    import omnigibson as og
    from pxr import Usd, UsdGeom, UsdPhysics, UsdLux, UsdShade, Gf, Sdf, PhysxSchema
    import omnigibson.lazy as L
    stage=og.sim.stage
    floor_proxy=None
    with og.sim.editing_usd():
        room=stage.DefinePrim('/World/NativeRoom','Xform');room.GetReferences().AddReference(str(ASSETS/spec['room_asset'] if spec.get('room_asset') else ROOM))
        # Experimental removal is initialization only and removes both visible
        # geometry and collisions. The named destination table is independent.
        for token in spec.get('pilot_remove_native_tokens',[]):
            matches=[p for p in Usd.PrimRange(room) if token in p.GetName()]
            assert matches, f'No native obstacle matching {token}'
            for prim in matches:prim.SetActive(False)
        for name,offset in spec.get('native_prop_offsets',{}).items():
            prim=next((p for p in Usd.PrimRange(room) if p.GetName()==name),None)
            assert prim is not None and prim.IsValid(),name
            op=next(x for x in UsdGeom.Xformable(prim).GetOrderedXformOps() if x.GetOpType()==UsdGeom.XformOp.TypeTranslate)
            op.Set(op.Get()+Gf.Vec3d(*offset))
        door = open_bathroom_door(stage) if not spec.get('scene_id') else None
        for prim in Usd.PrimRange(room):
            if prim.HasAPI(UsdPhysics.RigidBodyAPI):prim.RemoveAPI(UsdPhysics.RigidBodyAPI)
            if prim.HasAPI(UsdPhysics.ArticulationRootAPI):prim.RemoveAPI(UsdPhysics.ArticulationRootAPI)
            if prim.IsA(UsdPhysics.Joint):UsdPhysics.Joint(prim).CreateJointEnabledAttr(False)
            if prim.IsA(UsdGeom.Mesh):
                visible=UsdGeom.Imageable(prim).ComputeVisibility()!='invisible' and prim.GetName() not in spec.get('native_collision_exclusions',[])
                # Keep native static mesh collisions, including the bowl and
                # cabinet. A 0.3 mm named overlay provides OG support telemetry.
                flatten_floor=prim.GetName()==spec.get('native_floor_contact_mesh')
                col=UsdPhysics.CollisionAPI.Apply(prim);col.CreateCollisionEnabledAttr(visible and not flatten_floor)
                if flatten_floor:
                    bounds=UsdGeom.BBoxCache(Usd.TimeCode.Default(),[UsdGeom.Tokens.default_]).ComputeWorldBound(prim).ComputeAlignedRange()
                    lo,hi=np.asarray(bounds.GetMin()),np.asarray(bounds.GetMax())
                    assert hi[2]-lo[2]<.002,'Only sub-millimetre decorative floor bevels may be flattened'
                    floor_proxy={'source_mesh':str(prim.GetPath()),'method':'continuous contact surface at native tile tops',
                                 'bounds_xy_m':[lo[:2].tolist(),hi[:2].tolist()], 'top_m':float(hi[2]),
                                 'decorative_relief_m':float(hi[2]-lo[2]),'thickness_m':.04}
                if visible:
                    UsdPhysics.MeshCollisionAPI.Apply(prim).CreateApproximationAttr('none')
                    collision = PhysxSchema.PhysxCollisionAPI.Apply(prim)
                    collision.CreateContactOffsetAttr(.001)
                    collision.CreateRestOffsetAttr(0.)
            if prim.HasAPI(UsdLux.LightAPI):
                prim.CreateAttribute('visibleInPrimaryRay',Sdf.ValueTypeNames.Bool).Set(False)
                light=UsdLux.LightAPI(prim);exp=light.GetExposureAttr().Get() or 0
                light.CreateExposureAttr(exp-.65)
        if floor_proxy:
            lo,hi=np.array(floor_proxy['bounds_xy_m'])
            cube=UsdGeom.Cube.Define(stage,'/World/NativeRoom/FloorContactSurface')
            cube.CreateSizeAttr(1.);cube.AddTranslateOp().Set(Gf.Vec3d(*((lo+hi)/2),floor_proxy['top_m']-.02))
            cube.AddScaleOp().Set(Gf.Vec3d(*(hi-lo),.04));cube.CreateVisibilityAttr('invisible')
            UsdPhysics.CollisionAPI.Apply(cube.GetPrim())
            collision=PhysxSchema.PhysxCollisionAPI.Apply(cube.GetPrim())
            collision.CreateContactOffsetAttr(.001);collision.CreateRestOffsetAttr(0.)
        if spec.get('native_floor_only'):
            ground=stage.GetPrimAtPath('/World/ground_plane')
            if ground.IsValid():
                for prim in Usd.PrimRange(ground):
                    if prim.HasAPI(UsdPhysics.CollisionAPI):UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(False)
        # Preserve the manufacturer's material maps that OG normally suppresses.
        for prim in stage.Traverse():
            if prim.IsA(UsdShade.Shader) and not str(prim.GetPath()).startswith('/World/NativeRoom'):
                sh=UsdShade.Shader(prim);rough=sh.GetInput('reflectionroughness_texture')
                if rough and rough.Get():sh.CreateInput('reflection_roughness_texture_influence',Sdf.ValueTypeNames.Float).Set(1)
        from simulation.detail_assets import refine_fetch
        refine_fetch(stage,env.scene.robots[0])
        smooth_robot_normals(env.scene.robots[0])
        if spec.get('storage_bin'):
            from simulation.reception_storage import finish_storage_visuals
            finish_storage_visuals(stage,spec)
    settings=L.carb.settings.get_settings()
    settings.set_float('/rtx/sceneDb/ambientLightIntensity',0.)
    settings.set_int('/rtx/post/dlss/execMode',2)
    settings.set_int('/rtx/directLighting/sampledLighting/samplesPerPixel',4)
    settings.set_bool('/rtx/ambientOcclusion/enabled',False)
    settings.set_int('/rtx/translucency/maxRefractionBounces',12)
    # Read actual source surfaces, retaining the curved bowl and original faucet.
    return {'asset_repository':'agibot-world/GenieSimAssets',
            'asset_revision':'12f41e388a953cc2aeb0fe5b8eb516750c8321d9',
            'license':'CC-BY-NC-SA-4.0', 'layout':spec.get('scene_id','home_b'), 'room_asset':spec.get('room_asset','background/home/home_b/background.usda'), 'original_uvs_preserved':True,
            'recording':'30 fps native simulation frames; no frame interpolation',
            'task_object_source':MODELS[spec.get('object_kind','water')] if spec.get('template_id',spec['id'])=='neiss_2888' else 'BEHAVIOR-1K objects/sponge/aewrov (research asset license)',
            'surface_measurements':spec['surface_measurements'],
            'initial_door_pose':door, 'native_floor_only':spec.get('native_floor_only',False), 'collision_exclusions':spec.get('native_collision_exclusions',[]),
            'floor_collision_proxy':floor_proxy,
            'texture_edit':None if spec.get('scene_id') else 'Pepsi decorative can: retypeset, demonstration label; original texture retained'}


def open_bathroom_door(stage):
    """Initialize the native door fully open at its measured hinge, frame fixed."""
    from pxr import Usd,UsdGeom,Gf
    shell=stage.GetPrimAtPath('/World/NativeRoom/background/home_b')
    pivot=np.array([1.26284,-2.24781,0.]);rotation=np.array([[0,-1,0],[1,0,0],[0,0,1]])
    moved=0
    for prim in Usd.PrimRange(shell):
        if not prim.IsA(UsdGeom.Mesh):continue
        m=UsdGeom.Mesh(prim);transform=UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)
        world=np.array([transform.Transform(Gf.Vec3d(*map(float,p))) for p in m.GetPointsAttr().Get()])
        unique,groups=np.unique(np.round(world,5),axis=0,return_inverse=True);parents=list(range(len(unique)))
        def find(i):
            while parents[i]!=i:parents[i]=parents[parents[i]];i=parents[i]
            return i
        ids=np.asarray(m.GetFaceVertexIndicesAttr().Get());counts=np.asarray(m.GetFaceVertexCountsAttr().Get());starts=np.r_[0,np.cumsum(counts)[:-1]]
        for start,count in zip(starts,counts):
            face=groups[ids[start:start+count]]
            for i in face[1:]:parents[find(int(i))]=find(int(face[0]))
        components={}
        for i,g in enumerate(groups):components.setdefault(find(int(g)),[]).append(i)
        mask=np.zeros(len(world),dtype=bool)
        for vertices in components.values():
            cloud=world[vertices];lo=cloud.min(axis=0);hi=cloud.max(axis=0)
            if lo[0]>1.25 and 1.30<hi[0]<2.4 and lo[1]>-2.6 and hi[1]<-2.0:
                mask[vertices]=True;moved+=1
        if not mask.any():continue
        world[mask]=(world[mask]-pivot)@rotation.T+pivot
        inverse=transform.GetInverse();points=np.array([inverse.Transform(Gf.Vec3d(*map(float,p))) for p in world])
        m.GetPointsAttr().Set(points.tolist());m.CreateExtentAttr([points.min(axis=0).tolist(),points.max(axis=0).tolist()])
        normals=m.GetNormalsAttr().Get()
        if normals:
            normals=np.asarray(normals,dtype=float)
            if len(normals)==len(world):nmask=mask
            elif len(normals)==len(ids):nmask=mask[ids]
            elif len(normals)==len(counts):nmask=mask[ids[starts]]
            else:raise ValueError('Unrecognized native door normal interpolation')
            nworld=np.array([transform.TransformDir(Gf.Vec3d(*map(float,n))) for n in normals[nmask]])@rotation.T
            normals[nmask]=np.array([inverse.TransformDir(Gf.Vec3d(*map(float,n))) for n in nworld])
            m.GetNormalsAttr().Set(normals.tolist())
    assert moved,'Native door leaf was not found'
    return {'hinge_world_m':pivot.tolist(),'additional_opening_deg':90,'moved_components':moved,'frame_unchanged':True,'set_before_episode':True}


def smooth_robot_normals(robot):
    """Smooth CAD tessellation within 40 degrees; preserve edges and geometry."""
    from pxr import Usd,UsdGeom,UsdShade,Sdf
    for link in robot.links.values():
        for prim in Usd.PrimRange(link.prim):
            if not prim.IsA(UsdGeom.Mesh) or 'visual' not in str(prim.GetPath()):continue
            mesh=UsdGeom.Mesh(prim);points=np.asarray(mesh.GetPointsAttr().Get(),dtype=float)
            counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get());ids=np.asarray(mesh.GetFaceVertexIndicesAttr().Get())
            starts=np.r_[0,np.cumsum(counts)[:-1]]
            face=[]
            for start,count in zip(starts,counts):
                p=points[ids[start:start+count]]
                face.append(np.cross(p,np.roll(p,-1,axis=0)).sum(axis=0))
            face=np.asarray(face);unit=face/np.maximum(np.linalg.norm(face,axis=1,keepdims=True),1e-12)
            _,groups=np.unique(np.round(points,6),axis=0,return_inverse=True)
            corners=np.repeat(np.arange(len(counts)),counts);adjacency={}
            for vertex,f in zip(groups[ids],corners):adjacency.setdefault(int(vertex),set()).add(int(f))
            normals=[];threshold=math.cos(math.radians(40))
            for vertex,f in zip(groups[ids],corners):
                neighbours=np.array(list(adjacency[int(vertex)]));close=neighbours[(unit[neighbours]@unit[f])>=threshold]
                n=face[close].sum(axis=0);normals.append((n/max(np.linalg.norm(n),1e-12)).tolist())
            mesh.CreateNormalsAttr(normals);mesh.SetNormalsInterpolation('faceVarying')
            mat,_=UsdShade.MaterialBindingAPI(prim).ComputeBoundMaterial()
            if mat:
                for child in Usd.PrimRange(mat.GetPrim()):
                    if child.IsA(UsdShade.Shader):
                        UsdShade.Shader(child).CreateInput('reflection_roughness_constant',Sdf.ValueTypeNames.Float).Set(.34)


def capture_native_details(output, spec):
    import omnigibson as og
    import imageio.v2 as imageio
    from simulation.preview_native import camera
    original=og.sim.viewer_camera.get_position_orientation();focal=og.sim.viewer_camera.focal_length
    if spec.get('scene_id'):
        c=spec['camera'];p=spec['source'];r=spec['robot_position']
        views=[('detail-room',c['eye'],c['target'],c['focal']),
               ('detail-object',[p[0]-.4,p[1]-.35,p[2]+.3],p,24)]
        if spec.get('kitchen_obstacle'):
            o=spec['kitchen_obstacle']['position']
            views.append(('detail-obstacle',[o[0]-.55,o[1]+.45,o[2]+.60],o,22))
    elif spec.get('template_id',spec['id'])=='neiss_2888':
        views=[('detail-room',[.65,.8,1.45],[2.2,2.35,.7],22),
               ('detail-fetch',[1.4,-.04,1.4],[.5,.45,.85],25),
               ('detail-object',[.83,.02,.84],[1.15,.45,.64],28),
               ('detail-label',[.75,-.10,.72],[1.00,.28,.615],28),
               ('detail-living',[-.25,-.8,1.5],[-1.9,1.8,.8],22)]
    else:
        views=[('detail-room',[1.85,-1.2,1.5],[2.9,-2.8,.85],22),
               ('detail-fetch',[2.80,-1.5,1.5],[2.2,-3.01,.85],22),
               ('detail-object',[2.7,-1.4,1.15],[3.14,-1.86,.90],30),
               ('detail-fixture',[2.35,-2.4,1.18],[3.06,-3.03,.92],28)]
    for name,eye,target,lens in views:
        camera(eye,target,lens)
        for _ in range(24):og.sim.render()
        rgb=og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3]
        imageio.imwrite(output/(name+'.jpg'),rgb)
        if name=='detail-label':
            from pxr import UsdShade,Sdf
            changed=[]
            with og.sim.editing_usd():
                for prim in og.sim.stage.Traverse():
                    if not prim.IsA(UsdShade.Shader):continue
                    for inp in UsdShade.Shader(prim).GetInputs():
                        value=inp.Get()
                        if isinstance(value,Sdf.AssetPath) and value.path.endswith('pepsi-label-refined-v1.png'):
                            changed.append((inp,value))
                            inp.Set(Sdf.AssetPath(str(ASSETS/'objects/benchmark/beverage_bottle/benchmark_beverage_bottle_095/textures/T_body_Alb.jpg')))
            assert changed,'Refined label material override was not found'
            for _ in range(24):og.sim.render()
            imageio.imwrite(output/'detail-label-original.jpg',og.sim.viewer_camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3])
            with og.sim.editing_usd():
                for inp,value in changed:inp.Set(value)
    og.sim.viewer_camera.focal_length=focal
    og.sim.viewer_camera.set_position_orientation(*original)
    for _ in range(12):og.sim.render()
