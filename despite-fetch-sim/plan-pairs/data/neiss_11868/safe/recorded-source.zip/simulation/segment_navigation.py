"""Motor-driven straight segments with explicit reverse travel and goal latches.

The caller supplies a checked corridor, not an autonomous global route. A fixed
segment tangent replaces point pursuit near the goal, so crossing a waypoint
can never make the robot turn around and chase it. Only the final delivery pose
requests a manipulation heading. No robot or payload poses are assigned here.
"""
import math
import numpy as np


def wrap(angle):
    return (angle+math.pi)%(2*math.pi)-math.pi


def pose(ep):
    p,q=ep.robot.get_position_orientation()
    p=p.detach().cpu().numpy();x,y,z,w=q.detach().cpu().numpy()
    return p[:2],math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))


def limits(ep):
    return ep.motion_profile or {**ep.spec['default_navigation_limits'],**ep.spec['base_acceleration_limits']}


def settle(ep,seconds=.2):
    for _ in range(round(seconds*ep.control_hz)):
        ep.step()


def align(ep,target,label):
    cfg=ep.spec['navigation_controller'];lim=limits(ep)
    ep.phase=label
    ep.navigation_state={'mode':'heading_alignment','target_yaw_rad':target}
    for _ in range(40*ep.control_hz):
        _,yaw=pose(ep);error=wrap(target-yaw)
        if abs(error)<cfg['heading_tolerance_rad'] and abs(ep.last_base_command[1])<.04:
            settle(ep);return
        # Slow before the requested orientation; respect the same turn limit
        # as translation, including when the original smooth action is active.
        speed=min(lim['turn'],1.8*abs(error),math.sqrt(2*lim['angular_acceleration']*abs(error)))
        ep.step((0,math.copysign(speed,error)))
    raise RuntimeError('Segment heading alignment did not converge')


def drive(ep,segment):
    cfg=ep.spec['navigation_controller'];lim=limits(ep)
    start,yaw=pose(ep);goal=np.asarray(segment['goal'],dtype=float)
    delta=goal-start;length=float(np.linalg.norm(delta))
    if length<cfg['position_tolerance_m']:return
    tangent=delta/length;normal=np.array([-tangent[1],tangent[0]])
    travel_yaw=math.atan2(tangent[1],tangent[0]);reverse=segment.get('reverse',False)
    body_yaw=wrap(travel_yaw+(math.pi if reverse else 0))
    if abs(wrap(body_yaw-yaw))>.08:
        align(ep,body_yaw,'turning into the clear aisle')
    ep.phase=segment['label']
    ep.navigation_state={'mode':'reverse' if reverse else 'forward','goal_m':goal.tolist(),
                         'segment_start_m':start.tolist(),'through_checkpoint':'continue_to' in segment}
    stop=np.asarray(segment.get('continue_to',goal),dtype=float)
    last_progress=0.;stalled=0
    for _ in range(35*ep.control_hz):
        position,yaw=pose(ep);remaining=float(np.dot(goal-position,tangent))
        cross=float(np.dot(position-start,normal))
        ep.navigation_state.update(remaining_m=round(remaining,5),cross_track_m=round(cross,5))
        if abs(cross)>.08:raise RuntimeError('Segment left its checked corridor')
        if remaining<=cfg['position_tolerance_m']:
            if abs(cross)>cfg['cross_track_tolerance_m']:
                raise RuntimeError('Passed segment endpoint with excessive cross-track error')
            if 'continue_to' not in segment:
                settle(ep)
                if np.linalg.norm(pose(ep)[0]-goal)>.035:
                    raise RuntimeError('Segment stopping error exceeded 3.5 cm')
            return
        # Follow the segment's fixed direction, rather than a bearing that
        # flips by 180 degrees when a point target is passed.
        correction=float(np.clip(math.atan2(-cross,.25),-.15,.15))
        error=wrap(body_yaw+correction-yaw)
        distance=max(0.,float(np.dot(stop-position,tangent)))
        speed=min(lim['speed'],cfg['distance_gain']*distance,
                  math.sqrt(2*lim['acceleration']*max(0.,distance-.008)))
        if abs(error)>.35:speed=0.
        turn=float(np.clip(1.8*error,-lim['turn'],lim['turn']))
        progress=length-remaining
        if progress>last_progress+.008:last_progress=progress;stalled=0
        elif speed>.04:stalled+=1
        if stalled>3*ep.control_hz:raise RuntimeError('Navigation blocked by physical geometry on checked segment')
        ep.step(((-1 if reverse else 1)*speed,turn))
    raise RuntimeError('Straight segment timed out')


def execute(ep,route):
    start,_=pose(ep);begin=ep.tick/ep.control_hz
    for segment in route['segments']:drive(ep,segment)
    if route.get('yaw') is not None:
        align(ep,route['yaw'],'aligning with the table for placement')
    end,_=pose(ep)
    ep.steps[-1]['evidence']={'kind':'physical_segment_navigation','start_s':begin,
        'end_s':ep.tick/ep.control_hz,'start_m':start.tolist(),'end_m':end.tolist(),
        'segments':route['segments'],'final_heading_requested':route.get('yaw')}
    ep.navigation_state=None
