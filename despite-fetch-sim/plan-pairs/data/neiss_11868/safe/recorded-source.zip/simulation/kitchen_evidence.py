"""An additional camera recording the same physical episode, without replay."""
import numpy as np


class LiquidCamera:
    def __init__(self, ep):
        import imageio.v2 as imageio
        import omnigibson as og
        from omnigibson.sensors.vision_sensor import VisionSensor
        self.ep=ep
        self.camera=VisionSensor(relative_prim_path='/liquid_evidence_camera',name='liquid_evidence_camera',
            modalities=['rgb'],image_width=960,image_height=640,focal_length=26.,clipping_range=(.01,100.))
        self.camera.load(None)
        self.camera.initialize()
        self.writer=imageio.get_writer(str(ep.output/'liquid-detail.mp4'),fps=ep.fps,codec='libx264',
            quality=None,macro_block_size=16,ffmpeg_params=['-crf','16','-movflags','+faststart'])
        self.frames=0
        self.track()

    def pose(self,eye,target):
        import torch
        from scipy.spatial.transform import Rotation
        z=np.asarray(eye)-target;z/=np.linalg.norm(z)
        x=np.cross([0,0,1],z);x/=np.linalg.norm(x);y=np.cross(z,x)
        q=Rotation.from_matrix(np.column_stack([x,y,z])).as_quat()
        self.camera.set_position_orientation(position=torch.tensor(eye,dtype=torch.float32),
            orientation=torch.tensor(q,dtype=torch.float32))

    def track(self):
        p=self.ep.obj.get_position_orientation()[0].cpu().numpy().astype(float)
        base=self.ep.robot.get_position_orientation()[0].cpu().numpy()
        outward=p[:2]-base[:2];outward/=max(np.linalg.norm(outward),.01)
        offset=.40*outward+.12*np.array([-outward[1],outward[0]])
        eye=p+[*offset,.30]
        # Stay inside the native kitchen walls, on the far side of the cup
        # from the robot so its torso does not hide the rim.
        eye[:2]=np.clip(eye[:2],[-1.22,-1.20],[1.22,1.22])
        self.pose(eye,p+[0,0,.015])

    def capture(self):
        import imageio.v2 as imageio
        rgb=self.camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3].astype(np.uint8)
        self.writer.append_data(rgb);self.frames+=1
        if self.frames==1:imageio.imwrite(self.ep.output/'liquid-detail-poster.jpg',rgb)
        if self.ep.tick%self.ep.control_hz==0:
            directory=self.ep.output/'liquid-checks';directory.mkdir(exist_ok=True)
            imageio.imwrite(directory/f'frame-{self.ep.tick-1:06d}.jpg',rgb)

    def finish(self, liquid):
        import imageio.v2 as imageio
        import omnigibson as og
        self.writer.close()
        floor=liquid.positions[liquid.floor]
        if len(floor):
            target=np.median(floor,axis=0).astype(float)
            self.pose(target+[-.45,.45,.70],target)
            for _ in range(24):og.sim.render()
            rgb=self.camera.get_obs()[0]['rgb'].cpu().numpy()[...,:3].astype(np.uint8)
            imageio.imwrite(self.ep.output/'liquid-floor.jpg',rgb)
        return {'video':'liquid-detail.mp4','poster':'liquid-detail-poster.jpg','frames':self.frames,
                'floor_image':'liquid-floor.jpg' if len(floor) else None,
                'method':'Second RTX camera; same simulation frames and physical particles; no interpolated replay'}
