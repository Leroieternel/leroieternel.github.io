"""URDF kinematics and explicit collision geometry; no simulator mutations.

All candidate configurations live in this CPU planning model. Evaluating an IK
solution or a collision never moves the simulated robot or its payload.
"""
from pathlib import Path
import math
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares

ARM_NAMES = ['torso_lift_joint', 'shoulder_pan_joint', 'shoulder_lift_joint',
             'upperarm_roll_joint', 'elbow_flex_joint', 'forearm_roll_joint',
             'wrist_flex_joint', 'wrist_roll_joint']


def transform(p=(0, 0, 0), q=(0, 0, 0, 1)):
    t = np.eye(4); t[:3, :3] = Rotation.from_quat(q).as_matrix(); t[:3, 3] = p
    return t


def se2(p, z=0):
    return transform([p[0], p[1], z], Rotation.from_euler('z', p[2]).as_quat())


def wrap(x):
    return (x + math.pi) % (2 * math.pi) - math.pi


class RobotModel:
    def __init__(self, urdf):
        self.path = Path(urdf)
        root = ET.parse(urdf).getroot()
        self.links = [e.attrib['name'] for e in root.findall('link')]
        self.joints = []
        self.parents = {}
        for e in root.findall('joint'):
            origin = e.find('origin')
            xyz = np.fromstring(origin.get('xyz', '0 0 0'), sep=' ') if origin is not None else np.zeros(3)
            rpy = np.fromstring(origin.get('rpy', '0 0 0'), sep=' ') if origin is not None else np.zeros(3)
            axis = e.find('axis'); limit = e.find('limit')
            j = dict(name=e.get('name'), kind=e.get('type'), parent=e.find('parent').get('link'),
                     child=e.find('child').get('link'), origin=transform(xyz, Rotation.from_euler('xyz', rpy).as_quat()),
                     axis=np.fromstring(axis.get('xyz'), sep=' ') if axis is not None else np.array([1., 0, 0]),
                     lo=float(limit.get('lower', -math.pi)) if limit is not None else -math.pi,
                     hi=float(limit.get('upper', math.pi)) if limit is not None else math.pi,
                     velocity=float(limit.get('velocity', .5)) if limit is not None else .5)
            self.joints.append(j); self.parents[j['child']] = j['parent']
        self.root = next(l for l in self.links if l not in self.parents)
        self.by_name = {j['name']: j for j in self.joints}
        self.names = ARM_NAMES
        self.lower = np.array([self.by_name[n]['lo'] for n in self.names])
        self.upper = np.array([self.by_name[n]['hi'] for n in self.names])
        self.eef_offset = np.eye(4)
        self.extra = {}

    def fk(self, q, base=None, extra=None):
        values = dict(self.extra); values.update(extra or {}); values.update(zip(self.names, q))
        poses = {self.root: np.eye(4) if base is None else base}
        pending = list(self.joints)
        while pending:
            rest = []
            for j in pending:
                if j['parent'] not in poses:
                    rest.append(j); continue
                m = np.eye(4); v = values.get(j['name'], 0.)
                if j['kind'] in ('revolute', 'continuous'):
                    m[:3, :3] = Rotation.from_rotvec(j['axis'] * v).as_matrix()
                elif j['kind'] == 'prismatic': m[:3, 3] = j['axis'] * v
                poses[j['child']] = poses[j['parent']] @ j['origin'] @ m
            if len(rest) == len(pending): raise ValueError('URDF is not a rooted tree')
            pending = rest
        poses['eef_link'] = poses['gripper_link'] @ self.eef_offset
        return poses

    def ik(self, target, seed, attempts=6):
        """Bounded pose IK with a small seed bias; return multiple valid branches."""
        seed = np.clip(seed, self.lower + 1e-7, self.upper - 1e-7)
        rng = np.random.default_rng(41)
        starts = [seed]
        for _ in range(attempts - 1):
            starts.append(np.clip(seed + rng.normal(size=8) * [ .07, .4, .4, .9, .5, .9, .4, .9], self.lower+1e-7, self.upper-1e-7))
        found = []
        for initial in starts:
            def residual(q):
                pose = self.fk(q)['eef_link']
                return np.r_[3*(pose[:3, 3]-target[:3, 3]),
                             Rotation.from_matrix(target[:3, :3].T @ pose[:3, :3]).as_rotvec(),
                             .001*(q-seed)]
            solution = least_squares(residual, initial, bounds=(self.lower, self.upper), max_nfev=100,
                                     ftol=2e-6, xtol=2e-6, gtol=2e-6)
            q = solution.x; pose = self.fk(q)['eef_link']
            if np.linalg.norm(pose[:3, 3]-target[:3, 3]) < .003 and Rotation.from_matrix(target[:3, :3].T@pose[:3, :3]).magnitude() < .025:
                if not any(np.linalg.norm(q-old)<.08 for old in found): found.append(q)
                if len(found) >= 3: break
        return sorted(found, key=lambda q: np.linalg.norm((q-seed)*[3,1,1,.6,1,.6,1,.6]))


def convex_geometry(vertices, faces):
    import fcl
    import trimesh
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=False).convex_hull
    v = np.asarray(mesh.vertices, dtype=np.float64)
    f = np.column_stack([np.full(len(mesh.faces), 3), mesh.faces]).reshape(-1).astype(np.int32)
    return fcl.Convex(v, len(mesh.faces), f)


class CollisionWorld:
    def __init__(self, model, snapshot):
        import fcl
        self.fcl = fcl; self.model = model; self.snapshot = snapshot
        self.world = []; self.robot = []; self.payload = None
        self.last_collision = None; self.checks = 0
        for item in snapshot['world']:
            v, f = np.asarray(item['vertices']), np.asarray(item['faces'], dtype=np.int32)
            if item.get('convex'):
                geo = convex_geometry(v, f)
            else:
                geo = fcl.BVHModel(); geo.beginModel(len(v), len(f)); geo.addSubModel(v, f); geo.endModel()
            size=np.ptp(v,axis=0)
            floor=bool(v[:,2].max()<.045 and size[0]>1 and size[1]>1)
            self.world.append((fcl.CollisionObject(geo), v.min(0), v.max(0), item['path'],floor))
        self.lo = np.array([x[1] for x in self.world]); self.hi = np.array([x[2] for x in self.world])
        for item in snapshot['robot']:
            v = np.asarray(item['vertices']); f = np.asarray(item['faces'], dtype=np.int32)
            self.robot.append((fcl.CollisionObject(convex_geometry(v, f)), v, item['link'], item['path']))
        self.disabled = {frozenset(p) for p in snapshot['disabled_pairs']}
        self.disabled.update(frozenset((j['parent'],j['child'])) for j in model.joints)
        self.request = fcl.CollisionRequest(num_max_contacts=1)
        self.distance_request = fcl.DistanceRequest()
        self.margin = .006
        self.payload_local = None
        self.payload_allowed = set()
        self.free_object = None
        self.free_object_pose = None
        self.payload_floor = None
        self.base_disc=self.fcl.CollisionObject(self.fcl.Cylinder(.32,.35))
        self.touch_links = {'r_gripper_finger_link','l_gripper_finger_link'}

    def attach(self, item, eef_to_object):
        fcl=self.fcl
        v=np.asarray(item['vertices']); f=np.asarray(item['faces'], dtype=np.int32)
        self.payload=(fcl.CollisionObject(convex_geometry(v,f)),v,'payload',item['path'])
        self.payload_local=np.asarray(eef_to_object)

    def detach(self):
        self.payload=None; self.payload_local=None

    def navigation_valid(self,q,base):
        """Conservative 0.29 m chassis disc plus a 3 cm tracking buffer."""
        center=base[:3,3]+[0,0,.20]
        self.base_disc.setTransform(self.fcl.Transform(center))
        lo=center-[.32,.32,.175];hi=center+[.32,.32,.175]
        candidates=np.flatnonzero(np.all(self.hi>=lo,axis=1)&np.all(self.lo<=hi,axis=1))
        for i in candidates:
            other,_,_,path,floor=self.world[i]
            if floor:continue
            if self.colliding(self.base_disc,other,0):
                self.last_collision=['inflated chassis footprint',path];return False
        return self.valid(q,base,margin=.015)

    def colliding(self, a, b, margin):
        fcl=self.fcl
        if fcl.collide(a,b,self.request,fcl.CollisionResult()): return True
        return margin>0 and fcl.distance(a,b,self.distance_request,fcl.DistanceResult()) < margin

    def valid(self, q, base, *, arm_only=False, allowed_payload=(), margin=None, upright=False):
        self.checks += 1; self.last_collision = None
        margin=self.margin if margin is None else margin
        poses=self.model.fk(q,base)
        if upright and self.payload is not None:
            if (poses['eef_link']@self.payload_local)[2,2] < math.cos(math.radians(12)):
                self.last_collision=['payload','upright transport constraint'];return False
        parts=list(self.robot)
        if self.payload is not None: parts.append(self.payload); poses['payload']=poses['eef_link']@self.payload_local
        active=[]
        for obj, vertices, link, path in parts:
            t=poses[link];obj.setTransform(self.fcl.Transform(t[:3,:3],t[:3,3]))
            points=vertices@t[:3,:3].T+t[:3,3];lo=points.min(0);hi=points.max(0)
            if link=='payload' and self.payload_floor is not None and lo[2]<self.payload_floor:
                self.last_collision=['payload','support plane penetration'];return False
            active.append((obj,lo,hi,link))
            if arm_only and link in ('base_link','r_wheel_link','l_wheel_link','laser_link','estop_link','torso_fixed_link'):continue
            candidates=np.flatnonzero(np.all(self.hi>=lo-margin,axis=1)&np.all(self.lo<=hi+margin,axis=1))
            for i in candidates:
                other,_,_,other_path,floor=self.world[i]
                if floor and link in ('base_link','l_wheel_link','r_wheel_link'):continue
                if link=='payload' and any(token in other_path for token in allowed_payload):continue
                if self.colliding(obj,other,margin):
                    self.last_collision=[link,other_path];return False
        lows=np.array([x[1] for x in active]);highs=np.array([x[2] for x in active])
        pairs=np.argwhere(np.triu(np.all(highs[:,None,:]>=lows[None,:,:],axis=2)&np.all(lows[:,None,:]<=highs[None,:,:],axis=2),1))
        for i,j in pairs:
            obj,_,_,link=active[i];other,_,_,olink=active[j]
            if link==olink or frozenset((link,olink)) in self.disabled:continue
            if 'payload' in (link,olink) and any(x in (link,olink) for x in ('gripper_link','wrist_roll_link','r_gripper_finger_link','l_gripper_finger_link')):continue
            if self.colliding(obj,other,0):self.last_collision=[link,olink];return False
        if self.free_object is not None and self.payload is None:
            for obj,lo,hi,link in active:
                if link in self.touch_links:continue
                if self.colliding(obj,self.free_object,0):
                    self.last_collision=[link,'ungrasped task object'];return False
        return True
