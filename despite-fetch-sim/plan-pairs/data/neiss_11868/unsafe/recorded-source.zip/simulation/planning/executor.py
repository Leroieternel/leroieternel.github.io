"""Bridge classical planners to OmniGibson motor controllers and evidence logs."""
import importlib.metadata
import json
import math
import time
import numpy as np
from scipy.spatial.transform import Rotation
from .model import ARM_NAMES, CollisionWorld, transform, se2, wrap
from .snapshot import arr, extract, save, manifest
from .arm import ArmPlanner, edge_valid
from .navigation import Navigator, segments, path_cost, stopping_sweep


class ClassicalMotion:
    def __init__(self,ep):
        self.ep=ep;self.model,self.snapshot=extract(ep)
        self.world=CollisionWorld(self.model,self.snapshot);self.arm=ArmPlanner(self.model,self.world)
        self.records=[];self.docking=None;self.route_remainder=None;self.current_record=None
        self.qidx=[ep.robot.dof_names_ordered.index(n) for n in ARM_NAMES]
        self.maximum_tracking_error=0.;self.interventions=[]
        self.joint_tracking_max=np.zeros(8)
        self.joint_tracking_limits=np.array([.015]+[.12]*7)
        save(self.snapshot,ep.output/'planning-scene.json.gz')
        (ep.output/'planning-scene-manifest.json').write_text(json.dumps(manifest(self.snapshot),indent=2)+'\n')
        self.flush()

    def state(self):
        robot=self.ep.robot
        joints=arr(robot.get_joint_positions());self.model.extra.update(zip(robot.dof_names_ordered,joints))
        p,q=[arr(v) for v in robot.get_position_orientation()]
        return joints[self.qidx],transform(p,q),np.r_[p[:2],Rotation.from_quat(q).as_euler('xyz')[2]]

    def sync_object(self):
        import fcl
        from .model import convex_geometry
        ep=self.ep
        pose=transform(*[arr(v) for v in ep.obj.root_link.get_position_orientation()])
        if ep.gripper<0 and not ep.release_commanded:
            if not ep.metrics()['robot_contact']:raise RuntimeError('Planner cannot attach a payload without physical gripper contact')
            eef=transform(*[arr(v) for v in ep.robot.get_eef_pose()])
            self.world.attach(self.snapshot['payload'],np.linalg.inv(eef)@pose)
            self.world.free_object=None
        else:
            self.world.detach()
            item=self.snapshot['payload']
            self.world.free_object=fcl.CollisionObject(convex_geometry(item['vertices'],item['faces']),fcl.Transform(pose[:3,:3],pose[:3,3]))

    def flush(self):
        data=self.result()
        (self.ep.output/'planning.json').write_text(json.dumps(data,indent=2)+'\n')

    def result(self):
        return {'revision':'classical-fetch-v1','navigation':'SE(2) hybrid A* + collision-checked connectors + regulated path tracking',
                'docking':'sample target-facing base poses; reject collision and unreachable placement; compare route cost',
                'arm':'bounded pose IK + checked direct connection / OMPL RRTConnect + Ruckig',
                'packages':{n:importlib.metadata.version(n) for n in ('ompl','python-fcl','ruckig')},
                'seed':41,'geometry_source':self.snapshot['geometry_source'],'world_colliders':len(self.snapshot['world']),
                'robot_collision_parts':len(self.snapshot['robot']),'collision_margin_m':self.world.margin,
                'navigation_clearance':{'chassis_disc_radius_m':.29,'tracking_buffer_m':.03,'other_links_clearance_m':.015},
                'max_fk_live_position_error_m':max(self.snapshot['fk_position_errors_m'].values()),
                'max_joint_tracking_error_rad_or_m':self.maximum_tracking_error,
                'joint_tracking':{'names':ARM_NAMES,'maximum_absolute_error':self.joint_tracking_max.tolist(),
                                  'stop_limits':self.joint_tracking_limits.tolist(),'units':['m']+['rad']*7},
                'physics_execution':'wheel velocity and arm joint position motor targets; no pose teleportation',
                'reference_label_input':False,'calibration_status':'uncalibrated','records':self.records,
                'interventions':self.interventions,
                'limitations':['Oracle geometry and localization; no perception or SLAM.',
                    'Static scene snapshot; unexpected changes stop execution rather than claiming dynamic-obstacle prediction.',
                    'Discrete swept collision checks, conservative convex robot/payload hulls; not a continuous-time safety proof.',
                    'Collision avoidance can prevent a source-plan hazard; source unsafe labels are not measured outcomes.']}

    def move_hand(self,position,quaternion=None,seconds=2.,tolerance=.035,follow_object=False):
        ep=self.ep;self.sync_object();q,base,_=self.state()
        quat=arr(ep.robot.get_eef_orientation()) if quaternion is None else quaternion
        target=transform(position,quat)
        allowed=[]
        self.world.payload_floor=None
        # Only payload/support contact is permitted while lifting away from
        # its initial support or lowering onto the named destination surface.
        # Robot-to-counter collisions remain forbidden in every phase.
        if ep.phase=='lifting':
            # Whitelist only colliders already touching the supported cup,
            # and enforce the measured support plane throughout the lift.
            object_pose=transform(*[arr(v) for v in ep.obj.root_link.get_position_orientation()])
            obj=self.world.payload[0]
            obj.setTransform(self.world.fcl.Transform(object_pose[:3,:3],object_pose[:3,3]))
            allowed=[path for other,lo,hi,path,floor in self.world.world if self.world.colliding(obj,other,.007)]
            self.world.payload_floor=ep.spec['source_support_top']-.003
        if ep.phase=='lowering object':
            allowed=[ep.support.prim_path];self.world.payload_floor=ep.spec['support_top']-.003
        upright=self.world.payload is not None
        record={'kind':'arm','phase':ep.phase,'step':ep.active_step,'start_s':ep.tick/ep.control_hz,
                'status':'planning','follow_object':follow_object,'payload_min_height_m':self.world.payload_floor}
        self.records.append(record);self.current_record=record;self.flush()
        try:
            path,detail=self.arm.plan(q,target,base,upright=upright,allowed_payload=allowed)
            commands,timing=self.arm.retime(path,base,ep.control_hz,upright=upright,allowed_payload=allowed,minimum_duration=seconds)
            record.update(plan=detail,timing=timing,status='executing');self.flush()
            for command in commands:
                ep.arm_target=command;ep.step()
                actual,_,_=self.state()
                joint_error=abs(actual-command);self.joint_tracking_max=np.maximum(self.joint_tracking_max,joint_error)
                error=float(np.max(joint_error));self.maximum_tracking_error=max(self.maximum_tracking_error,error)
                if np.any(joint_error>self.joint_tracking_limits):raise RuntimeError(f'Joint tracking tolerance exceeded: {joint_error.tolist()}')
            ep.wait(.18)
            error=float(np.linalg.norm(arr(ep.robot.get_eef_position())-position))
            if error>tolerance:raise RuntimeError(f'Planned arm endpoint missed by {error:.4f} m')
            actual,actual_base,_=self.state()
            if not self.world.valid(actual,actual_base,arm_only=True,allowed_payload=allowed,margin=0):
                raise RuntimeError(f'Actual arm endpoint in collision: {self.world.last_collision}')
            record.update(status='completed',endpoint_error_m=error)
            print('CLASSICAL_ARM',ep.phase,detail['algorithm'],round(error,4),flush=True)
        except Exception as error:
            record.update(status='failed',error=str(error));raise
        finally:record['end_s']=ep.tick/ep.control_hz;self.flush()

    def choose_dock(self):
        ep=self.ep;self.sync_object();q,base,start=self.state()
        nav=Navigator(self.world,ep.spec['map_bounds'],float(base[2,3]),q)
        target=np.asarray(ep.spec['target']);offset=arr(ep.robot.get_eef_position())-arr(ep.obj.get_position_orientation()[0])
        hand_target=transform(target+offset+[0,0,.008],ep.grasp_quat)
        approach=hand_target.copy();approach[2,3]+=.20
        candidates=[];rejected=[]
        for radius in (.50,.60,.70):
            for angle in np.linspace(-math.pi,math.pi,32,endpoint=False):
                pos=target[:2]+radius*np.array([math.cos(angle),math.sin(angle)])
                candidate=np.r_[pos,wrap(angle+math.pi)]
                if not nav.valid(candidate):continue
                score=np.linalg.norm(pos-start[:2])+.18*abs(wrap(candidate[2]-start[2]))+.3*abs(radius-.60)
                candidates.append((score,candidate))
        candidates.sort(key=lambda x:x[0]);success=[]
        for _,candidate in candidates[:12]:
            b=se2(candidate,base[2,3]);approach_q=self.model.ik(np.linalg.inv(b)@approach,q,attempts=2)
            approach_q=[v for v in approach_q if self.world.valid(v,b,arm_only=True,upright=True)]
            if not approach_q:rejected.append({'pose':candidate.tolist(),'reason':'approach IK / collision'});continue
            try:
                approach_path,approach_plan=self.arm.plan(q,approach,b,upright=True,timeout=3.)
                approach_q=[approach_path[-1]]
            except RuntimeError as error:
                rejected.append({'pose':candidate.tolist(),'reason':'carry-to-approach path: '+str(error)});continue
            goal_q=self.model.ik(np.linalg.inv(b)@hand_target,approach_q[0],attempts=2)
            goal_q=[v for v in goal_q if self.world.valid(v,b,arm_only=True,upright=True,allowed_payload=[ep.support.prim_path])]
            if not goal_q:rejected.append({'pose':candidate.tolist(),'reason':'placement IK / collision'});continue
            if not edge_valid(approach_q[0],goal_q[0],lambda x:self.world.valid(x,b,arm_only=True,upright=True,allowed_payload=[ep.support.prim_path])):
                rejected.append({'pose':candidate.tolist(),'reason':'placement descent blocked'});continue
            try:path,detail=nav.plan(start,candidate,timeout=20.)
            except RuntimeError as error:rejected.append({'pose':candidate.tolist(),'reason':str(error)});continue
            detail['arm_approach_algorithm']=approach_plan['algorithm']
            success.append((path_cost(path),path,candidate,detail))
            if len(success)>=3:break
        if not success:raise RuntimeError(f'No reachable, collision-free docking pose: {rejected}')
        _,path,goal,detail=min(success,key=lambda x:x[0]);self.docking=goal
        record={'kind':'docking','step':ep.active_step,'target_m':target.tolist(),'candidates_collision_free':len(candidates),
                'rejected_candidates':rejected,'selected_pose':goal.tolist(),'route':[p.tolist() for p in path],
                'placement_ik_and_descent_checked':True,'navigation_plan':detail}
        self.records.append(record);self.flush();return path

    def limits(self):
        return self.ep.motion_profile or {**self.ep.spec.get('default_navigation_limits',{'speed':.25,'turn':.55}),
                                           **self.ep.spec.get('base_acceleration_limits',{'acceleration':.25,'angular_acceleration':.6})}

    def check_contacts(self):
        ep=self.ep
        floors=[p for _,_,_,p,is_floor in self.world.world if is_floor]
        for pair in ep.frame_contacts:
            robot_paths=[p for p in pair if ep.robot.prim_path in p]
            if len(robot_paths)!=1:continue
            robot_path=robot_paths[0];other=next(p for p in pair if p!=robot_path)
            rolling=any('/'+link+'/' in robot_path for link in ('base_link','r_wheel_link','l_wheel_link'))
            if rolling and ('ground_plane' in other or any(p in other for p in floors)):continue
            finger=any('/'+link+'/' in robot_path for link in self.world.touch_links)
            if finger and ep.obj.prim_path in other:continue
            event={'t':ep.tick/ep.control_hz,'reason':'unexpected physical contact','pair':list(pair),'phase':ep.phase}
            self.interventions.append(event);self.flush()
            raise RuntimeError(f'Unexpected contact during planned execution: {pair}')

    def command_checked(self,v,w,nav):
        ep=self.ep;_,_,state=self.state();lim=self.limits()
        for p in stopping_sweep(state,ep.last_base_command,[v,w],
                               [lim['acceleration'],lim['angular_acceleration']],dt=1/ep.control_hz):
            if not nav.valid(p):
                self.interventions.append({'t':ep.tick/ep.control_hz,'reason':'predicted collision','collision':self.world.last_collision})
                ep.last_base_command[:]=0;ep.step((0,0))
                raise RuntimeError(f'Navigation stopped before predicted collision: {self.world.last_collision}')
        ep.step((v,w))

    def track(self,path):
        ep=self.ep;arm,base,_=self.state();nav=Navigator(self.world,ep.spec['map_bounds'],base[2,3],arm)
        lim=self.limits();record={'kind':'navigation','step':ep.active_step,'start_s':ep.tick/ep.control_hz,
                               'planned_path':[p.tolist() for p in path],'status':'executing','limits':lim,'segments':segments(path)}
        self.records.append(record);self.flush()
        try:
            for seg in record['segments']:
                points=np.asarray(seg['points']);goal=points[-1];mode=seg['mode'];direction=seg['direction']
                ep.phase='following planned route' if mode=='drive' else 'aligning along planned route'
                ep.navigation_state={'mode':('reverse' if direction<0 else 'forward') if mode=='drive' else 'heading_alignment',
                    'planner':'SE(2) hybrid A*','goal_m':goal[:2].tolist(),'target_yaw_rad':float(goal[2])}
                progress=0;station=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points[:,:2],axis=0),axis=1))]
                last_movement=ep.tick;last_position=self.state()[2][:2].copy()
                for _ in range(60*ep.control_hz):
                    _,_,p=self.state()
                    if ep.tick%ep.control_hz==0:
                        print('CLASSICAL_NAV',round(ep.tick/ep.control_hz,2),mode,np.round(p,3).tolist(),flush=True)
                    if mode=='rotate':
                        error=wrap(goal[2]-p[2])
                        if abs(error)<.025 and abs(ep.last_base_command[1])<.05:break
                        v=0.;w=math.copysign(min(lim['turn'],1.7*abs(error),math.sqrt(2*lim['angular_acceleration']*abs(error))),error)
                    else:
                        nearest=progress+int(np.argmin(np.linalg.norm(points[progress:,:2]-p[:2],axis=1)))
                        progress=max(progress,nearest)
                        remaining=station[-1]-station[progress]
                        enddist=float(np.linalg.norm(goal[:2]-p[:2]))
                        tangent=points[-1,:2]-points[-2,:2];tangent/=np.linalg.norm(tangent)
                        passed=float(np.dot(goal[:2]-p[:2],tangent))<.012
                        if (enddist<.022 or passed) and remaining<.05:
                            if enddist>.045:raise RuntimeError('Passed planned endpoint outside its capture region')
                            break
                        carrot_index=min(len(points)-1,int(np.searchsorted(station,station[progress]+.13)))
                        delta=points[carrot_index,:2]-p[:2]
                        lateral=-math.sin(p[2])*delta[0]+math.cos(p[2])*delta[1]
                        curvature=2*lateral/max(float(delta@delta),.025**2)
                        desired=wrap(math.atan2(delta[1],delta[0])+(math.pi if direction<0 else 0))
                        yaw_error=wrap(desired-p[2])
                        # Reserve reaction distance and brake before the end
                        # of the segment, even in the faster source plan.
                        brake_distance=max(0.,float(np.dot(goal[:2]-p[:2],tangent))-.012)
                        decel=lim['acceleration'];reaction=.10
                        braking_speed=math.sqrt((decel*reaction)**2+2*decel*brake_distance)-decel*reaction
                        speed=min(lim['speed'],1.4*enddist,braking_speed,
                                  math.sqrt(.18/max(abs(curvature),1e-5)),lim['turn']/max(abs(curvature),1e-5))
                        v=direction*speed;w=float(np.clip(v*curvature,-lim['turn'],lim['turn']))
                        if abs(yaw_error)>.45:v=0.;w=float(np.clip(1.6*yaw_error,-lim['turn'],lim['turn']))
                        if np.linalg.norm(p[:2]-last_position)>.008:last_movement=ep.tick;last_position=p[:2].copy()
                        if ep.tick-last_movement>4*ep.control_hz:raise RuntimeError('Planned route tracking stalled')
                    self.command_checked(v,w,nav)
                else:raise RuntimeError('Planned route tracking timed out')
                # Finish braking before changing direction or starting an
                # arm action. A fixed quarter-second wait is insufficient
                # for high-speed plans with acceleration limits.
                for _ in range(2*ep.control_hz):
                    if max(abs(ep.last_base_command))<.005:break
                    self.command_checked(0.,0.,nav)
                ep.wait(.15)
            _,_,p=self.state();position_error=float(np.linalg.norm(p[:2]-path[-1][:2]))
            if position_error>.045:raise RuntimeError(f'Navigation endpoint error {position_error:.3f} m')
            record.update(status='completed',position_error_m=position_error,heading_error_rad=abs(wrap(p[2]-path[-1][2])))
        except Exception as error:record.update(status='failed',error=str(error));raise
        finally:
            record['end_s']=ep.tick/ep.control_hz;ep.navigation_state=None;self.flush()
        ep.steps[-1]['evidence']={'kind':'classical_collision_checked_navigation','planning_record':len(self.records)-1,
                                'position_error_m':position_error,'endpoint_pose':p.tolist()}

    def navigate_action(self,route_name):
        # Both original kitchen navigation actions partition one globally
        # planned delivery route, avoiding an arbitrary intermediate heading.
        if route_name=='aisle':
            path=self.choose_dock()
            points=np.asarray(path);station=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points[:,:2],axis=0),axis=1))]
            obstacle=np.asarray(self.ep.spec['kitchen_obstacle']['position'][:2])
            nearest=int(np.argmin(np.linalg.norm(points[:,:2]-obstacle,axis=1)))
            # After the chassis has passed the obstacle's station, the second
            # source action continues the remaining approach to the table.
            # This is a semantic boundary on the searched path, not a hand-set
            # route point or an intermediate requested heading.
            boundary=float(np.clip(station[nearest]+.32,.30*station[-1],.80*station[-1]))
            cut=min(len(path)-2,max(1,int(np.searchsorted(station,boundary))))
            self.records.append({'kind':'semantic_route_boundary','step':self.ep.active_step,
                'method':'obstacle nearest path station + inflated chassis radius; bounded to preserve both navigation actions',
                'obstacle_center_m':obstacle.tolist(),'boundary_station_m':float(station[cut]),
                'total_route_distance_m':float(station[-1]),'boundary_pose':path[cut].tolist()})
            self.route_remainder=path[cut:];self.track(path[:cut+1])
        elif route_name=='destination':
            if self.docking is None:path=self.choose_dock()
            else:
                q,base,start=self.state();nav=Navigator(self.world,self.ep.spec['map_bounds'],base[2,3],q)
                path,_=nav.plan(start,self.docking)
            self.track(path)
        else:raise RuntimeError(f'Classical semantic grounding is not yet validated for route {route_name}')
