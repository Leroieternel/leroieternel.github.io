"""Read the live USD collision scene into a portable planning snapshot."""
import json
from pathlib import Path
import numpy as np
from .model import ARM_NAMES, RobotModel, transform


def arr(x):
    return x.detach().cpu().numpy() if hasattr(x,'detach') else np.asarray(x)


def extract(ep):
    # Import only after SimulationApp/OmniGibson have initialized.
    import omnigibson as og
    from pxr import Usd, UsdGeom, UsdPhysics
    import trimesh
    robot=ep.robot;model=RobotModel(robot.urdf_path)
    joints=dict(zip(robot.dof_names_ordered,arr(robot.get_joint_positions()).tolist()))
    model.extra=joints.copy(); q=np.array([joints[n] for n in ARM_NAMES])
    base=transform(*[arr(v) for v in robot.get_position_orientation()])
    live={n:transform(*[arr(v) for v in l.get_position_orientation()]) for n,l in robot.links.items()}
    fk=model.fk(q,base)
    errors={n:float(np.linalg.norm(fk[n][:3,3]-live[n][:3,3])) for n in fk if n in live and n!='eef_link'}
    if max(errors.values())>.005:raise RuntimeError(f'URDF/live-link mismatch: {errors}')
    eef=transform(*[arr(v) for v in robot.get_eef_pose()])
    model.eef_offset=np.linalg.inv(fk['gripper_link'])@eef
    cache=UsdGeom.XformCache(); records=[];rparts=[];payload=[];skipped=[]
    for prim in Usd.PrimRange(og.sim.stage.GetPrimAtPath('/World')):
        if not prim.HasAPI(UsdPhysics.CollisionAPI):continue
        if UsdPhysics.CollisionAPI(prim).GetCollisionEnabledAttr().Get() is False:continue
        path=str(prim.GetPath())
        if 'ground_plane' in path:continue # Native floor colliders remain in the model.
        t=np.array(cache.GetLocalToWorldTransform(prim)).T
        if prim.IsA(UsdGeom.Mesh):
            mesh=UsdGeom.Mesh(prim);v=np.array(mesh.GetPointsAttr().Get());idx=np.array(mesh.GetFaceVertexIndicesAttr().Get());counts=mesh.GetFaceVertexCountsAttr().Get()
            faces=[];k=0
            for count in counts:
                for j in range(1,count-1):faces.append([idx[k],idx[k+j],idx[k+j+1]])
                k+=count
            f=np.asarray(faces,dtype=int)
        elif prim.IsA(UsdGeom.Cube):
            m=trimesh.creation.box(extents=[float(UsdGeom.Cube(prim).GetSizeAttr().Get())]*3);v=m.vertices;f=m.faces
        elif prim.IsA(UsdGeom.Sphere):
            m=trimesh.creation.icosphere(subdivisions=2,radius=float(UsdGeom.Sphere(prim).GetRadiusAttr().Get()));v=m.vertices;f=m.faces
        elif prim.IsA(UsdGeom.Cylinder) or prim.IsA(UsdGeom.Capsule):
            shape=UsdGeom.Cylinder(prim) if prim.IsA(UsdGeom.Cylinder) else UsdGeom.Capsule(prim)
            m=trimesh.creation.cylinder(radius=float(shape.GetRadiusAttr().Get()),height=float(shape.GetHeightAttr().Get()),sections=24)
            axis=shape.GetAxisAttr().Get()
            if axis=='X':m.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[0,1,0]))
            elif axis=='Y':m.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[1,0,0]))
            v=m.vertices;f=m.faces
        else:skipped.append(path);continue
        if not len(v) or not len(f):continue
        world=np.asarray(v)@t[:3,:3].T+t[:3,3]
        convex=UsdPhysics.MeshCollisionAPI(prim).GetApproximationAttr().Get() in ('convexHull','convexDecomposition') if prim.IsA(UsdGeom.Mesh) else True
        item={'path':path,'vertices':world.tolist(),'faces':np.asarray(f).tolist(),'convex':convex}
        if path.startswith(robot.prim_path+'/'):
            link=next((n for n,l in robot.links.items() if path.startswith(l.prim_path+'/')),None)
            if link is None or link not in fk or link=='eef_link':continue
            # USD rigid-body transforms are synchronized by the renderer. Use
            # the authored link frame for mesh-local geometry, live FK for pose.
            lt=np.array(cache.GetLocalToWorldTransform(robot.links[link].prim)).T
            inv=np.linalg.inv(lt);item['vertices']=(world@inv[:3,:3].T+inv[:3,3]).tolist();item['link']=link;rparts.append(item)
        elif path.startswith(ep.obj.prim_path+'/'):
            ot=np.array(cache.GetLocalToWorldTransform(ep.obj.root_link.prim)).T
            inv=np.linalg.inv(ot);item['vertices']=(world@inv[:3,:3].T+inv[:3,3]).tolist();payload.append(item)
        else:
            # Restrict static geometry to the configured room's working volume.
            b=ep.spec.get('map_bounds')
            if b and (world[:,0].max()<b[0]-.5 or world[:,0].min()>b[1]+.5 or world[:,1].max()<b[2]-.5 or world[:,1].min()>b[3]+.5):continue
            if world[:,2].min()>2.5:continue
            records.append(item)
    if skipped:raise RuntimeError(f'Unsupported enabled collision geometry: {skipped}')
    # A conservative convex envelope for the carried object (including rim).
    pv=np.concatenate([np.asarray(i['vertices']) for i in payload]);pm=trimesh.Trimesh(vertices=pv).convex_hull
    payload={'path':ep.obj.prim_path,'vertices':pm.vertices.tolist(),'faces':pm.faces.tolist(),'convex':True}
    snapshot={'world':records,'robot':rparts,'payload':payload,'disabled_pairs':robot.disabled_collision_pairs,
              'urdf':str(model.path),'joint_names':robot.dof_names_ordered,'initial_joints':joints,'initial_arm':q.tolist(),
              'base':base.tolist(),'eef_offset':model.eef_offset.tolist(),'fk_position_errors_m':errors,
              'spec':ep.spec,'geometry_source':'Enabled live USD collision geometry; convex robot and payload hulls; static triangle meshes'}
    return model,snapshot


def save(snapshot,path):
    import gzip
    with gzip.open(path,'wt') as f:json.dump(snapshot,f,separators=(',',':'))


def manifest(snapshot):
    """Share geometry identity and bounds, not licensed mesh vertex arrays."""
    import hashlib
    items=[]
    for group in ('world','robot'):
        for shape in snapshot[group]:
            v=np.asarray(shape['vertices'],dtype='<f8');f=np.asarray(shape['faces'],dtype='<i4')
            items.append({'group':group,'path':shape['path'],'link':shape.get('link'),
                'vertices':len(v),'triangles':len(f),'bounds_m':[v.min(0).tolist(),v.max(0).tolist()],
                'geometry_sha256':hashlib.sha256(v.tobytes()+f.tobytes()).hexdigest()})
    return {'geometry_source':snapshot['geometry_source'],'colliders':items,
            'fk_position_errors_m':snapshot['fk_position_errors_m'],'joint_names':snapshot['joint_names'],
            'urdf_sha256':hashlib.sha256(Path(snapshot['urdf']).read_bytes()).hexdigest(),
            'reproduction':'Load the licensed native assets locally and run simulation.planning.probe. Full collision vertices remain local.'}
