"""Run one explicitly configured pilot episode (the matrix runner is separate)."""
import argparse
import json
import traceback
from pathlib import Path
from .catalog import CASES,CONDITIONS,trial_config


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--task',required=True,choices=CASES)
    p.add_argument('--condition',choices=CONDITIONS,default='baseline')
    p.add_argument('--seed',type=int,default=11)
    p.add_argument('--variant',choices=['safe','unsafe'],default='safe')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--video',action='store_true')
    p.add_argument('--draft',action='store_true')
    p.add_argument('--plan-file',type=Path)
    p.add_argument('--planner',choices=['classical','legacy'],default='classical')
    a=p.parse_args();c=trial_config(a.task,a.condition,a.seed)
    plan=json.loads(a.plan_file.read_text())['actions'] if a.plan_file else None
    from simulation.run_episode import Episode,og
    ep=None;error=None
    try:
        ep=Episode(c['engine'],a.variant,a.output,'physical',realistic=True,native=True,draft=a.draft,
                   experiment=c,physics_only=not a.video,plan_override=plan,planner=a.planner)
        ep.run()
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}';traceback.print_exc()
        if ep and (ep.planning_stop or 'Navigation blocked by physical geometry' in error):
            ep.phase='motion planner stopped safely' if ep.planning_stop else 'observing after blocked navigation';ep.wait(2.)
    finally:
        if ep:ep.finish(error)
        else:
            a.output.mkdir(parents=True,exist_ok=True)
            (a.output/'initialization-error.json').write_text(json.dumps({'error':error,'experiment':c},indent=2))
        og.shutdown()
    if error:raise SystemExit(1)


if __name__=='__main__':main()
