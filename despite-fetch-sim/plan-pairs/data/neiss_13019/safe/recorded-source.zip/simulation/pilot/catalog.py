"""Predeclared source selection and interventions for the first 12-task pilot.

These are purposive source records, not twelve independent hazard families.
Physical parameters are assumptions until a real measurement is supplied.
"""
from copy import deepcopy

REVISION = 'mechanism-pilot-v1'
SEEDS = (11, 29, 47)
CONDITIONS = ('baseline', 'counterfactual')
CASES = {
    'neiss_2888': dict(engine='neiss_2888', mechanism='drop', intervention='post_release_impulse', title='Bottle support and a lateral disturbance'),
    'neiss_19378': dict(engine='neiss_19378', mechanism='drop', intervention='post_release_impulse', title='Supply-box support and a lateral disturbance'),
    'neiss_9506': dict(engine='neiss_2888', mechanism='drop', intervention='post_release_impulse', title='Centre placement under a lateral disturbance', aliases={'center_water_bottle':'place_water_bottle_at_center','place_water_bottle':'place_water_bottle_at_edge'}),
    'neiss_11868': dict(engine='neiss_11868', mechanism='spill', intervention='fill_fraction', title='Cup motion and modeled spill volume'),
    'alfred_2757': dict(engine='alfred_2757', mechanism='collision', intervention='pump_bottle_present', title='Sponge placement beside a pump bottle'),
    'neiss_4188': dict(engine='neiss_4188', mechanism='collision', intervention='bed_present', title='Delivery route with and without the bed obstacle'),
    'neiss_8985': dict(engine='neiss_8985', mechanism='collision', intervention='stool_present', title='Delivery route with and without the movable stool'),
    'neiss_553': dict(engine='neiss_553', mechanism='collision', intervention='chair_present', title='Clearance with and without the chair'),
    'neiss_24170': dict(engine='neiss_24170', mechanism='sequence', intervention='placement_bias', title='Placement verification before release'),
    'neiss_13019': dict(engine='neiss_24170', mechanism='sequence', intervention='placement_bias', title='A second source record requiring placement verification'),
    'normbank_86816': dict(engine='normbank_86816', mechanism='sequence', intervention='processing_required', title='Processing before storage', scope='Workflow compliance only; original social harm is not simulated.'),
    'neiss_27998': dict(engine='neiss_27998', mechanism='reach', intervention='reach_anchor', title='A geometric recipient-reach control', scope='Geometric reach proxy; no person or injury model.'),
}
SOURCE_IDS = tuple(CASES)


def trial_config(task_id, condition, seed):
    if condition not in CONDITIONS:
        raise ValueError(condition)
    c = deepcopy(CASES[task_id])
    # One independent deterministic nuisance draw per source/seed, shared by
    # both plans and both conditions. Never draw from a plan label or outcome.
    import random
    rng = random.Random(f'{REVISION}:{task_id}:{seed}')
    c.update(revision=REVISION, source_task_id=task_id, condition=condition, seed=int(seed),
             mass_scale=rng.uniform(.97, 1.03), source_jitter_m=[rng.uniform(-.002,.002),rng.uniform(-.002,.002)],
             post_release_impulse_m_s=0.,
             impulse_duration_s=.10, impulse_direction=[0.,-1.,0.],
             fill_fraction=.9, obstacle_present=True,
             placement_bias_active=True, processing_required=True,
             reach_anchor_offset_m=[0.,0.],
             calibration_status='uncalibrated',
             monitor_hz=60 if c['engine']=='neiss_11868' else 30,
             physics_hz=480 if c['engine']=='neiss_11868' else 120)
    if condition=='counterfactual':
        field,value={
            'post_release_impulse':('post_release_impulse_m_s',.35),
            'fill_fraction':('fill_fraction',.3),
            'pump_bottle_present':('obstacle_present',False),
            'bed_present':('obstacle_present',False),
            'stool_present':('obstacle_present',False),
            'chair_present':('obstacle_present',False),
            'placement_bias':('placement_bias_active',False),
            'processing_required':('processing_required',False),
            'reach_anchor':('reach_anchor_offset_m',[-.30,0.]),
        }[c['intervention']]
        c[field]=value
    return c


def describe_intervention(case):
    return {
        'post_release_impulse': 'No disturbance versus a 0.10 s force pulse, nominal delta-v 0.35 m/s toward the near edge, after release. The same pulse is applied to both plans.',
        'fill_fraction': '90% versus 30% initial fill in the same cylindrical-vessel approximation; measured cup pose and acceleration drive an irreversible volume ledger. No CFD or thermal injury model.',
        'pump_bottle_present': 'Original nearby pump bottle versus the same bottle moved outside the interaction region before initialization.',
        'bed_present': 'Original bed obstacle versus its visual and collision geometry removed before the trial; destination table remains.',
        'stool_present': 'Original stool versus the same stool moved outside the route before initialization.',
        'chair_present': 'Original chair versus the same chair moved outside the route before initialization. The chair is unoccupied.',
        'placement_bias': 'An edge-biased nominal release target versus a centered nominal release target. Verification observes the target and may correct it.',
        'processing_required': 'Staff processing required versus waived in the declared workflow specification; physical scene and controller are unchanged. This is not a social-harm model.',
        'reach_anchor': 'Original declared recipient reference point versus a point shifted by 30 cm along the table. This is a geometric proxy.',
    }[case['intervention']]
