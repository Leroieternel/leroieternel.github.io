"""Evidence-bearing state transitions from recorded or live Episode telemetry.

Pure Python: no Isaac import, no reference-label input, no writes to world state.
Missing measurements remain unknown. Contact alone never proves a grasp.
"""
from bisect import bisect_right
import math
from statistics import median
from . import REVISION


# These are explicit source-to-scene role bindings, not synonym inference.
PAYLOAD_DESTINATIONS = {
    'neiss_2888': ('water_bottle', 'bedside_table'),
    'neiss_9506': ('water_bottle', 'bedside_table'),
    'neiss_13019': ('water_bottle', 'bedside_table'),
    'neiss_24170': ('water_bottle', 'bedside_table'),
    'neiss_4188': ('water_bottle', 'bedside_table'),
    'neiss_27998': ('medication', 'bedside_table'),
    'neiss_19378': ('medical_supplies', 'bedside_table'),
    'neiss_8985': ('medical_box', 'bedside_table'),
    'alfred_2757': ('sponge', 'toilet_tank'),
    'neiss_11868': ('hot_liquid', 'table'),
    'neiss_553': ('therapy_tool', 'therapist_desk'),
    'normbank_86816': ('object_from_customer', 'storage_area'),
}


def reading(value=None, *, basis='unknown', source=None, unit=None, reason=None, **details):
    return {'value': value, 'basis': basis, 'source': source, 'unit': unit,
            **({'reason': reason} if reason else {}), **details}


def observe(sample, spec, source_task_id):
    m = sample.get('metrics', {})
    states = {}
    def metric(key, field, unit=None, basis='simulator_measurement'):
        value = m.get(field)
        if value is None or isinstance(value, float) and not math.isfinite(value):
            states[key] = reading(reason='Metric not recorded: ' + field)
        else:
            states[key] = reading(value, basis=basis, source='metrics.' + field, unit=unit)
        return states[key]

    metric('payload.contact_robot', 'robot_contact')
    metric('payload.contact_destination', 'support_contact')
    metric('payload.edge_margin', 'edge_margin_m', 'm')
    metric('payload.tilt', 'object_tilt_deg', 'deg')
    metric('payload.height', 'object_height_m', 'm')
    metric('payload.inside_storage_bin', 'inside_storage_bin', basis='derived_geometry')
    metric('workflow.staff_processed', 'staff_processed', basis='scripted_workflow_observation')
    if not spec.get('staff'):
        states['workflow.staff_processed'] = reading(reason='No staff-processing model in this scene')
    metric('chair.clearance', 'chair_clearance_m', 'm', 'derived_geometry')
    metric('obstacle.contact', 'obstacle_contact')
    metric('obstacle.clearance', 'obstacle_clearance_m', 'm', 'derived_geometry')
    metric('payload.contact_hazard', 'hazard_contact')
    metric('hazard.tilt', 'hazard_tilt_deg', 'deg')
    for role in ('robot', 'object'):
        if role in sample:
            states[role + '.position'] = reading(sample[role].get('p'), basis='simulator_measurement', source=role + '.p', unit='m')
    if 'parcel_constraint_active' in sample.get('staff', {}):
        states['staff.holds_payload'] = reading(sample['staff']['parcel_constraint_active'],
            basis='scripted_constraint_observation', source='staff.parcel_constraint_active')
    else:
        states['staff.holds_payload'] = reading(reason='Staff grasp constraint not recorded')

    support_values = [m.get('support_contact'), m.get('edge_margin_m'), m.get('object_height_m'),
                      spec.get('half_height'), spec.get('support_top')]
    if all(isinstance(v, (int, float)) and math.isfinite(v) for v in support_values):
        contact, margin, height, half_height, top = support_values
        states['payload.supported_at_destination'] = reading(
            bool(contact and margin >= 0 and abs(height - half_height - top) < .035),
            basis='derived_geometry', source='metrics + recorded spec',
            parameters={'height_tolerance_m': .035, 'minimum_edge_margin_m': 0.,
                        'required_support_contact': True}, calibration_status='uncalibrated',
            note='Instantaneous supported footprint; does not alone establish stable placement or task success.')
    else:
        states['payload.supported_at_destination'] = reading(reason='Support geometry or contact not recorded')

    # Use actual PBD particle-volume telemetry only. The pilot's reduced-order
    # safety.spilled_ml must not be silently substituted for this measurement.
    for key, field in [('liquid.escaped_volume', 'spilled_volume_ml'),
                       ('liquid.remaining_volume', 'current_inside_volume_ml'),
                       ('liquid.never_escaped_volume', 'unspilled_volume_ml'),
                       ('floor.liquid_volume', 'floor_liquid_ml')]:
        metric(key, field, 'ml', 'particle_volume_measurement')
    cfg = spec.get('kitchen_fluid', {})
    threshold = cfg.get('detection_threshold_ml')
    spilled = m.get('spilled_volume_ml')
    if all(isinstance(v, (int, float)) and math.isfinite(v) for v in (spilled, threshold)):
        states['liquid.spilled'] = reading(spilled >= threshold, basis='thresholded_particle_measurement',
            source='metrics.spilled_volume_ml', parameters={'threshold_ml': threshold},
            measured_ml=spilled, calibration_status='uncalibrated')
    else:
        states['liquid.spilled'] = reading(reason='Particle-volume measurement or explicit detection threshold missing')

    clearance = m.get('chair_clearance_m')
    if source_task_id == 'neiss_553' and isinstance(clearance, (int, float)) and math.isfinite(clearance):
        for key, limit in [('chair.within_exposure_distance', .5), ('chair.below_recommended_clearance', 1.)]:
            states[key] = reading(m['chair_clearance_m'] < limit, basis='source_threshold_on_simulated_geometry',
                source='metrics.chair_clearance_m', parameters={'threshold_m': limit},
                measured_m=m['chair_clearance_m'], calibration_status='uncalibrated',
                note='Distance condition only; human reaction, falling and injury remain unknown.')
    # Absence of evidence must not become a negative injury finding.
    states['human.injured'] = reading(reason='No calibrated human injury model or observation')
    states['robot.holds_payload'] = reading(reason='Aggregate robot contact is insufficient to establish a gripper grasp')
    return states


def predicate_bindings(source_task_id):
    bindings = {}
    if source_task_id in PAYLOAD_DESTINATIONS:
        payload, destination = PAYLOAD_DESTINATIONS[source_task_id]
        bindings[f'(object_at {payload} {destination})'] = 'payload.supported_at_destination'
        bindings[f'(robot_has {payload})'] = 'robot.holds_payload'
    if source_task_id == 'neiss_11868':
        bindings['(liquid_spilled)'] = 'liquid.spilled'
    if source_task_id == 'normbank_86816':
        bindings['(staff_has_object)'] = 'staff.holds_payload'
    return bindings


def build_observed_report(result, trace):
    task_id = result.get('experiment', {}).get('source_task_id', result['task_id'])
    spec = result.get('spec', {})
    bindings = predicate_bindings(task_id)
    events, extrema, snapshots, times = [], {}, [], []
    previous = None
    for sample in trace:
        t = float(sample['t'])
        if not math.isfinite(t) or times and t <= times[-1]:
            raise ValueError('Telemetry timestamps must be finite and strictly increasing')
        current = observe(sample, spec, task_id)
        for key, obs in current.items():
            v = obs['value']
            if isinstance(v, bool):
                old = previous.get(key, {}).get('value') if previous is not None else None
                if previous is not None and v != old:
                    events.append({'t': t, 'step_index': sample.get('step'), 'state': key,
                                   'before': old, 'after': v, 'evidence': obs})
            elif isinstance(v, (int, float)) and math.isfinite(v):
                stat = extrema.setdefault(key, {'min': v, 'min_t': t, 'max': v, 'max_t': t, 'unit': obs['unit']})
                if v < stat['min']:
                    stat.update(min=v, min_t=t)
                if v > stat['max']:
                    stat.update(max=v, max_t=t)
        previous = current
        snapshots.append(current)
        times.append(t)
    endpoints = []
    sample_period = median([b-a for a, b in zip(times, times[1:])]) if len(times) > 1 else None
    max_sample_age = 2 * sample_period + .0001 if sample_period is not None else 0.
    for i, step in enumerate(result.get('steps', [])):
        end = step.get('end')
        index = bisect_right(times, end) - 1 if end is not None else -1
        # Do not accidentally present a previous action's frame as evidence for
        # an unobserved action. Zero-duration actions have no fresh sample.
        start = step.get('start', 0)
        valid = index >= 0 and end > start and times[index] > start and end-times[index] <= max_sample_age
        endpoints.append({'step_index': i, 'action': step['action'], 'execution_status': step['status'],
                          'sample_t': times[index] if valid else None,
                          'sample_age_s': end-times[index] if valid else None,
                          'states': snapshots[index] if valid else {},
                          'maximum_sample_age_s': max_sample_age,
                          'reason': None if valid else 'No fresh recorded sample near action end'})
    return {'revision': REVISION, 'task_id': task_id, 'source': 'recorded_simulator_telemetry',
            'reference_label_used': False, 'calibration_status': 'uncalibrated',
            'sample_count': len(trace), 'initial': snapshots[0] if snapshots else {},
            'final': snapshots[-1] if snapshots else {}, 'transitions': events,
            'numeric_extrema': extrema, 'action_endpoints': endpoints,
            'predicate_bindings': bindings,
            'limitations': ['Predicate bindings are explicit operational definitions for twelve selected source tasks.',
                           'Recorded contact is not proof of a grasp; unsupported observations remain unknown.',
                           'Particle-volume telemetry is distinct from reduced-order spill proxies.',
                           'Threshold events, source labels, physical incidents and injuries are separate.',
                           'No new physical simulation is performed when analyzing an existing trace.']}


def reconcile(symbolic, observed):
    predicted = dict(symbolic.get('initial', {}))
    rows = []
    for step in symbolic.get('steps', []):
        i = step['step_index']
        for change in step.get('changes', []):
            predicted[change['atom']] = change['after']
        endpoint = next((e for e in observed['action_endpoints'] if e['step_index'] == i), None)
        for atom, key in observed['predicate_bindings'].items():
            if atom not in predicted:
                continue
            measurement = endpoint['states'].get(key, reading(reason='No endpoint observation')) if endpoint else reading(reason='Action not executed')
            if step['status'] != 'applied' or endpoint is None or endpoint['execution_status'] != 'completed':
                status = 'not_comparable'
            elif measurement['value'] is None:
                status = 'unknown'
            else:
                status = 'agrees' if predicted[atom] == measurement['value'] else 'differs'
            rows.append({'step_index': i, 'action': step['action'], 'atom': atom, 'predicted': predicted[atom],
                         'observed': measurement, 'comparison': status,
                         'interpretation': 'A difference can reflect symbolic abstraction or execution, not automatically unsafe behavior.'})
    return {'comparisons': rows,
            'unbound_atoms': sorted(set(symbolic.get('initial', {})) - set(observed['predicate_bindings'])),
            'rule': 'Unknown and not-comparable entries are not counted as successful validation.'}
