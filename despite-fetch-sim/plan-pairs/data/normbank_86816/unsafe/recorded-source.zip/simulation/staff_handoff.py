"""Visible scripted staff interaction with a dynamic, constraint-held parcel.

The character uses skeletal IK, not a human policy or a dynamic human-body
model. Only the staff hold is constrained. Fetch uses its physical fingers.
"""
import math
import json
import numpy as np
import torch
from scipy.spatial.transform import Rotation
from pxr import Usd, UsdGeom, UsdSkel, UsdPhysics, Gf, Vt
import omnigibson as og
from omnigibson.utils.usd_utils import create_joint
from simulation.prepare_staff_asset import DEST


def smooth(u):
    return u*u*u*(10+u*(-15+6*u))


def align(a,b):
    a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
    v=np.cross(a,b);c=float(a@b)
    if c<-.99999:
        axis=np.cross(a,[0,0,1])
        if np.linalg.norm(axis)<1e-5:axis=np.cross(a,[0,1,0])
        return Rotation.from_rotvec(axis/np.linalg.norm(axis)*math.pi).as_matrix()
    k=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
    return np.eye(3)+k+k@k/(1+c)


class StaffActor:
    def __init__(self,ep):
        self.ep=ep;self.position=np.array(ep.spec['staff']['position'],dtype=float)
        self.events=[];self.held=False;self.joint=None;self.max_tracking_error=0.
        self.anchor=ep.env.scene.object_registry('name','staff_grip_anchor')
        self.stage=og.sim.stage
        with og.sim.editing_usd():
            # An enabled kinematic rigid body drives only the staff's grasp.
            # The parcel itself stays dynamic, with its collisions enabled.
            UsdPhysics.RigidBodyAPI(self.anchor.root_link.prim).CreateKinematicEnabledAttr(True)
            root=UsdGeom.Xform.Define(self.stage,'/World/ReceptionStaff')
            root.GetPrim().GetReferences().AddReference(str(DEST/'F_Business_02.usd'))
            root.ClearXformOpOrder();root.AddTranslateOp().Set(Gf.Vec3d(*self.position))
            self.skel=next(UsdSkel.Skeleton(p) for p in Usd.PrimRange(root.GetPrim()) if p.IsA(UsdSkel.Skeleton))
            self.names=list(self.skel.GetJointsAttr().Get())
            self.index={s.split('/')[-1]:i for i,s in enumerate(self.names)}
            lookup={s:i for i,s in enumerate(self.names)}
            self.parents=[lookup.get(s.rsplit('/',1)[0],-1) if '/' in s else -1 for s in self.names]
            self.rest=np.array(self.skel.GetRestTransformsAttr().Get()).transpose(0,2,1).copy()
            self.bind=self.fk(self.rest)
            anim=UsdSkel.Animation.Define(self.stage,'/World/ReceptionStaff/ScriptedHandoff')
            anim.CreateJointsAttr(self.names)
            self.trans=anim.CreateTranslationsAttr();self.rots=anim.CreateRotationsAttr();self.scales=anim.CreateScalesAttr()
            UsdSkel.BindingAPI.Apply(self.skel.GetPrim()).CreateAnimationSourceRel().SetTargets([anim.GetPath()])
            self.scales.Set(Vt.Vec3hArray([Gf.Vec3h(1)]*len(self.names)))
        self.idle=np.array([[self.position[0]+.17,self.position[1]-.16,1.03],
                            [self.position[0]-.17,self.position[1]-.16,1.03]])
        self.wrists=self.idle.copy();self.lean=5.;self.curl=.12;self.box_yaw=0.
        self.pose(self.wrists,self.lean,self.curl)

    def fk(self,local):
        world=np.empty_like(local)
        for i,p in enumerate(self.parents):world[i]=local[i] if p<0 else world[p]@local[i]
        return world

    def set_global_rotation(self,local,i,rotation):
        world=self.fk(local);parent=self.parents[i]
        local[i,:3,:3]=(world[parent,:3,:3].T if parent>=0 else np.eye(3))@rotation

    def pose(self,wrists,lean,curl,yaw=0.):
        local=self.rest.copy()
        # Bend the torso forward at three joints; feet stay at their rest pose.
        for name,weight in [('Waist',.55),('Spine01',.30),('Spine02',.15)]:
            i=self.index[name];world=self.fk(local)
            axis=world[i,:3,:3].T@np.array([1.,0,0])
            local[i,:3,:3]=local[i,:3,:3]@Rotation.from_rotvec(axis*math.radians(lean*weight)).as_matrix()
        for k,side in enumerate(['L','R']):
            upper=self.index[side+'_Upperarm'];fore=self.index[side+'_Forearm'];hand=self.index[side+'_Hand']
            world=self.fk(local);s=world[upper,:3,3];target=np.asarray(wrists[k])-self.position
            a=np.linalg.norm(self.bind[fore,:3,3]-self.bind[upper,:3,3]);b=np.linalg.norm(self.bind[hand,:3,3]-self.bind[fore,:3,3])
            delta=target-s;d=np.linalg.norm(delta)
            if d>a+b-.002:raise RuntimeError(f'Staff {side} wrist out of reach: {d:.3f} > {a+b-.002:.3f}')
            direction=delta/d
            pole=np.array([.6 if side=='L' else -.6,.2,-1.])
            pole-=direction*(pole@direction);pole/=np.linalg.norm(pole)
            along=(a*a-b*b+d*d)/(2*d);height=math.sqrt(max(0,a*a-along*along))
            elbow=s+along*direction+height*pole
            self.set_global_rotation(local,upper,align(self.bind[fore,:3,3]-self.bind[upper,:3,3],elbow-s)@self.bind[upper,:3,:3])
            self.set_global_rotation(local,fore,align(self.bind[hand,:3,3]-self.bind[fore,:3,3],target-elbow)@self.bind[fore,:3,:3])
            roll=-90*np.clip((lean-5)/20,0,1)
            hand_r=Rotation.from_euler('z',(-90 if side=='L' else 90)+yaw,degrees=True).as_matrix()@Rotation.from_euler('x',roll,degrees=True).as_matrix()@self.bind[hand,:3,:3]
            self.set_global_rotation(local,hand,hand_r)
            for name,i in self.index.items():
                if name.startswith(side+'_') and any(s in name for s in ['Index','Mid','Ring','Pinky','Thumb']):
                    axis=self.bind[i,:3,:3].T@np.array([0,1 if side=='L' else -1.,0])
                    local[i,:3,:3]=local[i,:3,:3]@Rotation.from_rotvec(axis*math.radians(25*curl)).as_matrix()
        world=self.fk(local)
        self.wrists=np.array([world[self.index[s+'_Hand'],:3,3]+self.position for s in ['L','R']])
        self.lean=float(lean);self.curl=float(curl);self.box_yaw=float(yaw)
        translations=[Gf.Vec3f(*p[:3,3]) for p in local]
        quats=Rotation.from_matrix(local[:,:3,:3]).as_quat()
        with og.sim.editing_usd():
            self.trans.Set(Vt.Vec3fArray(translations))
            self.rots.Set(Vt.QuatfArray([Gf.Quatf(float(q[3]),Gf.Vec3f(*q[:3])) for q in quats]))

    def grip_wrists(self,center,yaw=0.):
        r=Rotation.from_euler('z',yaw,degrees=True)
        return np.array([np.asarray(center)+r.apply([s*.080,.105,.012]) for s in [1,-1]])

    def drive_anchor(self,position,quaternion):
        # A kinematic target participates in the solver; setting a transform
        # alone teleports the anchor and does not drive a connected parcel.
        view=self.anchor.root_link._rigid_prim_view._physics_view
        target=torch.as_tensor(np.r_[position,quaternion][None],dtype=torch.float32,device=og.sim.device)
        view.set_kinematic_targets(target,torch.tensor([0],dtype=torch.int32,device=og.sim.device))

    def move(self,wrists,seconds,lean=None,curl=None,center=None,yaw=0.):
        start=self.wrists.copy();l0=self.lean;c0=self.curl;y0=self.box_yaw
        lean=l0 if lean is None else lean;curl=c0 if curl is None else curl
        anchor0=np.array(self.anchor.get_position_orientation()[0].cpu())
        for j in range(round(seconds*30)):
            u=smooth((j+1)/round(seconds*30));current_yaw=y0+(yaw-y0)*u
            if center is not None:
                p=anchor0+(np.asarray(center)-anchor0)*u
                q=Rotation.from_euler('z',current_yaw,degrees=True).as_quat()
                hands=self.grip_wrists(p,current_yaw)
            else:hands=start+(np.asarray(wrists)-start)*u
            self.pose(hands,l0+(lean-l0)*u,c0+(curl-c0)*u,current_yaw)
            if center is not None:self.drive_anchor(p,q)
            self.ep.step()
            if self.held:
                error=float(np.linalg.norm(np.array(self.ep.obj.get_position_orientation()[0].cpu())-p))
                self.max_tracking_error=max(error,self.max_tracking_error)
                if error>.035:raise RuntimeError(f'Staff hold constraint did not track parcel: {error:.3f} m; anchor={self.anchor.get_position_orientation()[0].tolist()}; target={p.tolist()}')

    def event(self,name,**detail):
        self.events.append({'event':name,'t':round(self.ep.tick/30,4),**detail})

    def process(self):
        ep=self.ep
        base=np.array(ep.robot.get_position_orientation()[0].cpu())
        expected=getattr(ep,'staff_arrival_pose',ep.spec['staff_stop'])[:2]
        if np.linalg.norm(base[:2]-expected)>.04:raise RuntimeError('Staff processing requires actual counter arrival')
        p=np.array(ep.obj.get_position_orientation()[0].cpu())
        ep.phase='staff reaching for parcel';self.move(self.grip_wrists(p)+[0,.045,.075],1.8,lean=31,curl=.10)
        ep.phase='staff taking parcel';self.move(self.grip_wrists(p),1.,lean=31,curl=.65)
        self.anchor.set_position_orientation(torch.tensor(p,dtype=torch.float32),torch.tensor([0,0,0,1.],dtype=torch.float32))
        self.drive_anchor(p,[0,0,0,1.]);ep.step()
        self.joint=create_joint('/World/StaffParcelConstraint','FixedJoint',body0=self.anchor.root_link.prim_path,body1=ep.obj.root_link.prim_path,
                                exclude_from_articulation=True,joint_frame_in_parent_frame_pos=torch.zeros(3),joint_frame_in_parent_frame_quat=torch.tensor([0.,0,0,1]),
                                joint_frame_in_child_frame_pos=torch.zeros(3),joint_frame_in_child_frame_quat=torch.tensor([0.,0,0,1]))
        self.held=True;self.event('staff_grasp_constraint_engaged',wrist_positions_m=self.wrists.tolist())
        ep.phase='staff lifting parcel for inspection';self.move(None,1.8,lean=25,curl=.65,center=p+[0,.06,.15])
        lifted=np.array(ep.obj.get_position_orientation()[0].cpu())
        if lifted[2]-p[2]<.12:raise RuntimeError('Staff did not visibly lift parcel')
        self.event('parcel_lift_verified',lift_m=float(lifted[2]-p[2]))
        ep.phase='staff inspecting parcel';self.move(None,1.5,lean=25,curl=.65,center=p+[0,.06,.15],yaw=18)
        self.event('parcel_inspected',yaw_deg=18)
        self.move(None,.8,lean=25,curl=.65,center=p+[0,.06,.15],yaw=0)
        ep.phase='staff presenting parcel at handoff point';self.move(None,1.8,lean=31,curl=.65,center=p+[0,0,.006])
        with og.sim.editing_usd():self.joint.GetAttribute('physics:jointEnabled').Set(False)
        self.held=False;self.event('staff_released_parcel')
        ep.phase='staff withdrawing hands';self.move(self.grip_wrists(p)+[0,.08,.08],.9,lean=28,curl=.10)
        self.move(self.idle,1.6,lean=5,curl=.12)
        ep.wait(.5)
        final=np.array(ep.obj.get_position_orientation()[0].cpu())
        if np.linalg.norm(final-p)>.025:raise RuntimeError('Staff parcel did not settle at handoff position')
        if min(np.linalg.norm(w-final) for w in self.wrists)<.18:raise RuntimeError('Staff hands did not clear Fetch pickup')
        ep.staff_processed=True;self.event('handoff_ready',parcel_position_m=final.tolist(),hand_clearance_m=float(min(np.linalg.norm(w-final) for w in self.wrists)))

    def state(self):
        return {'position_m':self.position.tolist(),'wrist_positions_m':self.wrists.round(5).tolist(),
                'torso_lean_deg':round(self.lean,3),'finger_curl':round(self.curl,3),
                'hand_yaw_deg':round(self.box_yaw,3),'parcel_constraint_active':self.held}

    def result(self):
        return {'model':'NVIDIA F_Business_02','control':'scripted skeletal IK; kinematic staff grip with a PhysX fixed constraint; dynamic parcel',
                'events':self.events,'max_constraint_tracking_error_m':self.max_tracking_error,
                'constraint_released':not self.held,'processing_completed':self.ep.staff_processed,
                'limitations':'Staff animation and grasp constraint are scripted. No human force control, human decision-making, or social-safety outcome is inferred.'}
