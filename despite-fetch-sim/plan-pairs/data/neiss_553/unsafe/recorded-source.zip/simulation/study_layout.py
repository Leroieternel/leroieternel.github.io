"""Source-grounded office layout; initialization geometry, never an outcome script.

Genie office shell and desk UVs remain unchanged. The same occupied chair,
storage source and destination are used for both reference plans. Distances
describe exposure, not a simulated human fall or injury.
"""
import math
from pathlib import Path
import numpy as np

REVISION = 'occupied-chair-between-endpoints-v1'
OFFICE = 'background/office/office_00/background.usda'


def configure(spec):
    from simulation.runtime import RUNTIME
    spec.update(
        room_asset=str(RUNTIME/'generated/study-spatial/office.usda'),
        spatial_revision=REVISION,
        original_room_asset=OFFICE,
        source=[-2.42,-.75,.9], source_support_center=[-2.65,-.75], source_support_half=[.3272,.6985],
        source_surface_token='SourceStorage', source_surface_ceiling=.90,
        target=[2.42,-.75,.9], support_center=[2.65,-.75], support_half=[.3272,.6985], support='therapist_desk_surface',
        target_surface_token='TherapistDesk', target_surface_ceiling=.90,
        robot_position=[-1.76,-.75,.025], robot_orientation=[0,0,1,0],
        carry_position=[-2.24,-.75,1.22],
        chair={'category':'straight_chair','model':'xtqgrr','dimensions':[.55,.58,.95],
               'position':[0,0,.503], 'orientation':[0,0,-math.sqrt(.5),math.sqrt(.5)], 'occupied':True},
        occupant={'seat_position_m':[0,-.04,.52], 'asset':'F_Business_02',
                  'control':'static seated skeletal pose; conservative static body colliders',
                  'human_response_simulated':False},
        skill_routes={'direct':{'points':[[1.76,-.75]],'yaw':0},
                      'chair':{'points':[[0,-1.0],[1.76,-.75]],'yaw':0}},
        navigation_action_constraints={'direct':[{'object':'office_chair', 'minimum_clearance_m':1.,
            'planning_buffer_m':.08, 'tracking_buffer_m':.03,
            'source':'Source instantaneous_solution: maintain at least 1 metre from the chair.'}]},
        camera={'eye':[0,-2.27,2.90], 'target':[0,0,.20], 'focal':8.5},
        map_bounds=[-3.02,3.13,-2.30,2.30],
        map_objects=[{'lo':[-2.98,-1.45],'hi':[-2.32,-.05],'label':'TOOL STORAGE'},
                     {'lo':[2.32,-1.45],'hi':[2.98,-.05],'label':'THERAPIST DESK'},
                     {'lo':[-.294,-.353],'hi':[.294,.205],'label':'OCCUPIED CHAIR'}],
        spatial_contract={'revision':REVISION, 'paired_initialization':True,
            'source_danger_distance_m':.5, 'source_recommended_clearance_m':1.,
            'distance_definition':'Horizontal distance from 0.29 m chassis disc to chair footprint; source does not specify the distance convention.',
            'route_semantics':'Direct requests the desk with the source-prescribed 1 m chair clearance. Via-chair requires the chair-side passing region, then the same desk, using the common physical collision margins. These are explicit action groundings, not learned human avoidance. Paths and docking poses are searched by v2.',
            'via_chair_region':{'center':[0,-1.0],'radius_m':.12},
            'calibration_status':'uncalibrated', 'injury_model':False})
    return spec


def prepare_room(spec):
    from pxr import Usd,UsdGeom,Gf
    from simulation.genie_scene import ASSETS
    path=Path(spec['room_asset']);path.parent.mkdir(parents=True,exist_ok=True)
    stage=Usd.Stage.CreateNew(str(path)) if not path.exists() else Usd.Stage.Open(str(path))
    stage.GetRootLayer().Clear()
    root=UsdGeom.Xform.Define(stage,'/World');stage.SetDefaultPrim(root.GetPrim())
    UsdGeom.SetStageUpAxis(stage,'Z');UsdGeom.SetStageMetersPerUnit(stage,1.)
    root.GetPrim().GetReferences().AddReference(str(ASSETS/OFFICE))
    root.AddTranslateOp().Set(Gf.Vec3d(0,0,1.485))
    for p in stage.GetPrimAtPath('/World/background').GetChildren():
        if p.GetName().startswith(('benchmark_table_','benchmark_chair_','benchmark_tv_')):
            p.SetActive(False)
    # The two desks retain their native geometry, dimensions and texture UVs.
    table=ASSETS/'background/common/table/benchmark_table_006/Aligned.usda'
    for name,x in [('SourceStorage',-2.65),('TherapistDesk',2.65)]:
        p=UsdGeom.Xform.Define(stage,'/World/'+name)
        p.GetPrim().GetReferences().AddReference(str(table))
        p.ClearXformOpOrder();p.AddTranslateOp().Set(Gf.Vec3d(x,-.75,-1.054))
    stage.GetRootLayer().Save()
    return str(path)


def seated_character(path,seat):
    """Author a static pose via bone transforms; preserve the licensed skin."""
    from pxr import Usd,UsdGeom,UsdSkel,Gf,Vt
    from scipy.spatial.transform import Rotation
    from simulation.prepare_staff_asset import DEST
    stage=Usd.Stage.CreateInMemory();root=UsdGeom.Xform.Define(stage,'/Occupant')
    stage.SetDefaultPrim(root.GetPrim());UsdGeom.SetStageUpAxis(stage,'Z')
    root.GetPrim().GetReferences().AddReference(str(DEST/'F_Business_02.usd'))
    sk=next(UsdSkel.Skeleton(p) for p in Usd.PrimRange(root.GetPrim()) if p.IsA(UsdSkel.Skeleton))
    names=list(sk.GetJointsAttr().Get());idx={n.split('/')[-1]:i for i,n in enumerate(names)}
    parents=list(UsdSkel.Topology(names).GetParentIndices())
    rest=np.array(sk.GetRestTransformsAttr().Get()).transpose(0,2,1).copy();local=rest.copy()
    def fk():
        w=local.copy()
        for i,p in enumerate(parents):
            if p>=0:w[i]=w[p]@local[i]
        return w
    bind=fk()
    def rotate_global(i,r):
        w=fk();local[i,:3,:3]=(w[parents[i],:3,:3].T if parents[i]>=0 else np.eye(3))@r
    def align(a,b):
        a=a/np.linalg.norm(a);b=b/np.linalg.norm(b);v=np.cross(a,b);c=float(a@b)
        k=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
        return np.eye(3)+k+k@k/(1+c)
    # Hip height = seat + pelvis clearance. Calves hang vertically; feet flat.
    local[idx['Hip'],2,3]+=(seat[2]+.085)-bind[idx['Hip'],2,3]
    for side in ['L','R']:
        thigh,calf,foot=[idx[side+'_'+n] for n in ['Thigh','Calf','Foot']]
        rotate_global(thigh,align(bind[calf,:3,3]-bind[thigh,:3,3],[0,-1,-.30])@bind[thigh,:3,:3])
        rotate_global(calf,align(bind[foot,:3,3]-bind[calf,:3,3],[0,0,-1])@bind[calf,:3,:3])
        rotate_global(foot,bind[foot,:3,:3])
        upper,fore,hand=[idx[side+'_'+n] for n in ['Upperarm','Forearm','Hand']]
        sign=1 if side=='L' else -1
        rotate_global(upper,align(bind[fore,:3,3]-bind[upper,:3,3],[sign*.08,-.15,-1])@bind[upper,:3,:3])
        rotate_global(fore,align(bind[hand,:3,3]-bind[fore,:3,3],[0,-1,-.15])@bind[fore,:3,:3])
        rotate_global(hand,Rotation.from_euler('y',sign*90,degrees=True).as_matrix()@bind[hand,:3,:3])
    root.ClearXformOpOrder();root.AddTranslateOp().Set(Gf.Vec3d(seat[0],seat[1],0))
    anim=UsdSkel.Animation.Define(stage,'/Occupant/SeatedPose');anim.CreateJointsAttr(names)
    anim.CreateTranslationsAttr(Vt.Vec3fArray([Gf.Vec3f(*m[:3,3]) for m in local]))
    q=Rotation.from_matrix(local[:,:3,:3]).as_quat()
    anim.CreateRotationsAttr(Vt.QuatfArray([Gf.Quatf(float(v[3]),Gf.Vec3f(*v[:3])) for v in q]))
    anim.CreateScalesAttr(Vt.Vec3hArray([Gf.Vec3h(1)]*len(names)))
    UsdSkel.BindingAPI.Apply(sk.GetPrim()).CreateAnimationSourceRel().SetTargets([anim.GetPath()])
    stage.GetRootLayer().Export(str(path))
    return str(path)


def install_occupant(stage,spec):
    from pxr import UsdGeom,UsdPhysics,Gf
    from simulation.runtime import RUNTIME
    folder=RUNTIME/'generated/study-spatial';folder.mkdir(parents=True,exist_ok=True)
    seat=spec['occupant']['seat_position_m']
    asset=seated_character(folder/'occupant.usda',seat)
    root=stage.DefinePrim('/World/StudyOccupant','Xform');root.GetReferences().AddReference(asset)
    # Conservative proxies are explicit, shared physics/planning obstacles.
    # They model a stationary occupied chair, not articulated human dynamics.
    proxies=[('Torso',[seat[0],seat[1],.93],[.42,.26,.70]),
             ('Head',[seat[0],seat[1]-.02,1.36],[.25,.25,.28]),
             ('Thighs',[seat[0],seat[1]-.20,.54],[.42,.46,.22]),
             ('LowerLegs',[seat[0],seat[1]-.39,.25],[.36,.17,.46]),
             ('Feet',[seat[0],seat[1]-.48,.06],[.36,.30,.12])]
    for name,center,dims in proxies:
        p=UsdGeom.Cube.Define(stage,'/World/StudyOccupantCollision/'+name)
        p.CreateSizeAttr(1.);p.AddTranslateOp().Set(Gf.Vec3d(*center));p.AddScaleOp().Set(Gf.Vec3d(*dims))
        p.CreateVisibilityAttr('invisible');UsdPhysics.CollisionAPI.Apply(p.GetPrim())
    spec['occupant']['collision_proxies']=[{'name':n,'center_m':c,'dimensions_m':d} for n,c,d in proxies]


def summarize(ep,metrics):
    """Measure an independently checkable route/exposure record from physics."""
    nav=[s for s in ep.trace if s['step']==1]
    if ep.initial_state and 'chair' in ep.initial_state:
        bounds=np.asarray(ep.initial_state['chair']['bounds_m'])[:,:2]
        ep.spec['chair_footprint_m']=bounds.tolist()
        for obj in ep.spec['map_objects']:
            if obj['label']=='OCCUPIED CHAIR':obj.update(lo=bounds[0].tolist(),hi=bounds[1].tolist())
    # Geometric exposure is separate from a human response or injury.
    exposure=[s for s in nav if s['metrics']['chair_clearance_m']<.5]
    moving_exposure=[]
    for a,b in zip(nav,nav[1:]):
        dt=b['t']-a['t']
        if dt>0 and b['metrics']['chair_clearance_m']<.5 and np.linalg.norm(np.array(b['robot']['p'][:2])-a['robot']['p'][:2])/dt>.01:
            moving_exposure.append(dt)
    closest=min(nav,key=lambda s:s['metrics']['chair_clearance_m']) if nav else None
    c=np.array(ep.spec['chair']['position'][:2]);a=np.array(ep.spec['source'][:2]);b=np.array(ep.spec['target'][:2])
    axis=b-a;progress=float((c-a)@axis/(axis@axis))
    metrics.update(chair_between_endpoints=0<progress<1,chair_route_progress_fraction=progress,
        source_to_destination_distance_m=float(np.linalg.norm(axis)),chair_occupied=True,
        below_source_danger_distance=bool(exposure),
        chair_danger_exposure_s=round(len(exposure)/ep.fps,3),
        chair_moving_danger_exposure_s=round(sum(moving_exposure),3),
        closest_chair_pass_time_s=closest['t'] if closest else None,
        chair_or_occupant_contact_frames=sum(any(any('office_chair' in p or 'StudyOccupantCollision' in p for p in pair) for pair in s.get('contacts',[])) for s in ep.trace),
        first_chair_danger_time_s=exposure[0]['t'] if exposure else None,
        min_navigation_chair_clearance_m=min((s['metrics']['chair_clearance_m'] for s in nav),default=None))


def download_assets():
    """Reproduce the pinned room cache from its recorded file hashes."""
    import hashlib,json,urllib.request,urllib.parse
    from simulation.runtime import ROOT,RUNTIME
    manifest=json.loads((ROOT/'simulation/study_office_assets.json').read_text())
    base='https://huggingface.co/datasets/agibot-world/GenieSimAssets/resolve/'+manifest['revision']+'/'
    for item in manifest['files']:
        dest=RUNTIME/'genie-assets'/item['path']
        if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==item['sha256']:continue
        dest.parent.mkdir(parents=True,exist_ok=True)
        with urllib.request.urlopen(base+urllib.parse.quote(item['path']),timeout=120) as response:data=response.read()
        assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
        temp=dest.with_suffix(dest.suffix+'.partial');temp.write_bytes(data);temp.replace(dest)
    print('Verified',len(manifest['files']),'pinned Genie office asset files.')


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--download-assets',action='store_true')
    args=parser.parse_args()
    if args.download_assets:download_assets()
