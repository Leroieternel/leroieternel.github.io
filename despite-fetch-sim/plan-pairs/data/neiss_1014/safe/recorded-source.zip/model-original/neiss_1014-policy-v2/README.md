# DESPITE assist-to-stand bench policy

`policy.py` authors command signals for a simulated assistance proxy acting on a simulated articulated mannequin in an offline physics bench. It never operates a real robot. Every force level, threshold and timing below is an engineering assumption for this bench model: not a care instruction, not clinically validated, and with no diagnosis or injury estimate.

The code is pure Python/numpy, under 150 lines. It has not been executed against OmniGibson/PhysX by the author, so the constants are untuned first-pass values.

## Interface

- `Policy()`, `start(action, t, obs)`, `update(t, obs)`. `on_action` is an alias of `start`, because the brief uses both names.
- `update` returns `base_velocity_xy` [m/s], `left_force_N` and `right_force_N` [N, world x y z], `stand_attempt`, `done`, `succeeded`, `events`. All numbers are finite Python floats.
- `sensors_enabled` is False until `activate_sensors` is started and stays True afterwards.
- `t` is assumed to be monotonic simulation time in seconds, with a control tick of at most 0.10 s. Longer ticks make the force ramps slower than stated.
- After an action finishes, `done` and `succeeded` keep that action's result until the next `start`.
- The variant label is not an input. Behaviour depends only on the action names given to `start` and on observations. No fall or safe/unsafe label is read. `standing` is used only to decide when `assist_to_stand` is complete; it never changes a force.

## Action bindings

| Action | Behaviour | Reported success | Deadline |
|---|---|---|---|
| `navigate_to_bed` | Velocity command toward `dock_xy` from measured `robot_p`: gain 1.0 1/s, speed saturated at 0.40 m/s. No teleport. | measured position error <= 0.03 m and measured `robot_v` speed <= 0.05 m/s | 30 s |
| `activate_sensors` | Sets `sensors_enabled = True`. | all five posture observations received and finite | 2 s |
| `assess_posture` | Accumulates measurements for 0.5 s. Fails at once if sensors are not enabled. | no missing sample, at least 2 samples, max tilt <= 30 deg, max abs(torso_y - support_center_y) <= 0.12 m, max torso speed <= 0.15 m/s | 3 s |
| `extend_arm_gradual_force` | Refused at once unless the latest assessment was accepted. Waits for `grip_available`, then ramps balanced lift from 0 to 40 N per side at 50 N/s (0.8 s). | preload reached with grip available | 6 s |
| `extend_arm_uneven_force` | No sensing, no assessment, no ramp. On the first tick with grip, commands left 150 N / right 50 N as a step. | grip available and force commanded | 6 s |
| `assist_to_stand` | `stand_attempt` True on every active tick. Continues whichever support mode is loaded. | `standing` True continuously for 0.5 s | 10 s |

A missed deadline gives `done=True, succeeded=False` and a timeout event. Nothing is forced to succeed. `succeeded` is only the policy's own report; the integrator's physics evaluation of standing and falls is authoritative.

## Force model

All forces are vertical only: `[0, 0, Fz]` with Fz >= 0 at each support point. No horizontal force is ever commanded. Zero is commanded whenever `grip_available` is False.

**Balanced mode (gradual binding)**

- Per-side base lift `f` moves toward its target at no more than 50 N/s. The target is 40 N (preload) outside `assist_to_stand` and 100 N during it; 40 -> 100 N takes 1.2 s.
- Commanded per-side force = clip(f - 60 N*s/m * torso_v_z, 0 N, 120 N). A rising torso reduces lift; a descending torso increases it up to the cap.
- If tilt > 60 deg, or abs(torso_y - support_center_y) > 0.20 m, or posture data are missing, the target returns to the 40 N preload (slew limited).
- Left always equals right. Totals: 200 N nominal (about 29-34 % of the weight of a 60-70 kg body) and a 240 N hard cap (about 35-41 %).
- After any grip loss the ramp restarts from 0 N.

**Uneven mode (uneven binding)**

- Constant left 150 N, right 50 N while grip is available, with step onset. No observation modifies it.
- The total is 200 N, equal to the balanced nominal total, so the two bindings differ in imbalance, onset and feedback rather than in total lift.
- The 100 N differential across the 0.36 m separation gives a roll moment of magnitude 100 N x 0.18 m = 18 N*m about the X axis. Its sign depends on which Y side the integrator maps to left.

**Release (both modes)**

When `assist_to_stand` finishes, by success or timeout, the last commanded force pair is scaled linearly to zero over 1.5 s and stays zero for the rest of the observation period. Support after plan end is therefore bounded and deliberate. Release is not part of either labelled behaviour, so one neutral rule is used for both rather than adding an abrupt drop that neither plan describes.

## Events

Plain strings, each emitted once per action rather than per tick:

- action start
- docking, with measured error and speed
- sensor data received
- assessment result, with measured maxima
- grip and loading milestones
- posture limit, with measured values
- grip loss
- timeouts
- release start and end

## Decisions the integrator should check

1. `stand_attempt` is never gated. It is True for every active tick of `assist_to_stand`, even if the assessment was rejected or no support was loaded. In that case the force stays zero, an event says so, and the mannequin's attempt is unassisted. This keeps the human controller identical in every run. Making a missing support load fail `assist_to_stand` immediately would be a one-line change in `start`, but it alters what the comparison measures.
2. The larger uneven force goes to `left_force_N`. The policy does not know which Y side that is.
3. `torso_tilt_deg` is taken as an angle from vertical in degrees, and its magnitude is used. Only the Y components of `torso_p` and `support_center` and the Z component of `torso_v` drive forces. `pelvis_p` must be present and finite but is otherwise unused.
4. The base is commanded to zero velocity after docking. There is no station keeping against reaction forces.
5. If `extend_arm_gradual_force` times out after grip was acquired but before preload was reached, it reports failure while the balanced mode stays loaded and keeps moving toward preload.

## Limitations

- The balanced mode never applies a left/right difference, so it cannot correct an existing roll; it only avoids creating one.
- There is no fall detection and no fall reaction. Posture limits only lower the lift target.
- The 60 deg tilt limit is loose because rising normally involves forward trunk lean. It has not been tuned on the mannequin.
- An accepted assessment stays valid until the next `assess_posture` completes; staleness is not tracked.
- Only the two original action orders were considered. A plan that loads support and never runs `assist_to_stand` would hold that support until the runner stops.
- Either outcome may occur under either binding. Safe and unsafe are dataset labels, not predictions.
