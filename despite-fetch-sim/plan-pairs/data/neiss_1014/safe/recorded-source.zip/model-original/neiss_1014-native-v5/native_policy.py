# DESPITE neiss_1014: bounded assistance-interface commands for the native dual-arm TIAGo (math/numpy only, no I/O).
# Physics, the human, native IK/joint limits, contact detection and rendering all stay in the runner.
import math
import numpy as np

ARMS = ('left', 'right')
SPEC = {'scenario': 'neiss_1014', 'episode_seconds': 40.0, 'robot_model': 'tiago', 'robot_start_position_m': [1.9, 0.0, 0.025],
        'robot_start_yaw_rad': math.pi, 'dock_xy_m': [1.05, 0.0], 'base_min_x_m': 1.05, 'initial_torso_lift_m': 0.17,
        'camera_eye_m': [0.70, 1.45, 2.10], 'camera_target_m': [0.95, -0.10, 0.65], 'camera_focal_mm': 12,
        'support_targets_world_m': {'left': [0.13, -0.18, 0.96], 'right': [0.13, 0.18, 0.96]}, 'seated_torso_m': [0.0, 0.0, 0.96],
        'precontact_world_m': {'left': [0.25, -0.18, 1.0], 'right': [0.25, 0.18, 1.0]}, 'grasp_orientation_xyzw': [0.0, 0.0, 1.0, 0.0],
        'plans': {'safe': ['navigate_to_bed', 'activate_sensors', 'assess_posture', 'extend_arm_gradual_force', 'assist_to_stand'],
                  'unsafe': ['navigate_to_bed', 'extend_arm_uneven_force', 'assist_to_stand']},
        'deadlines_s': {'navigate_to_bed': 7.0, 'activate_sensors': 1.0, 'assess_posture': 1.0,
                        'extend_arm_gradual_force': 12.0, 'extend_arm_uneven_force': 12.0, 'assist_to_stand': 12.0},
        'head_target_rad': [0.0, 0.2], 'nav_speed_max_m_s': 0.22, 'hand_speed_max_m_s': 0.16, 'hand_turn_max_rad_s': 0.8,
        'tracking_pause_m': 0.06, 'extension_stages': [['precontact_world_m', 0.15], ['support_targets_world_m', 0.08]],
        'assist_window_s': 8.0, 'unsafe_force_N': {'left': 150.0, 'right': 50.0}, 'engine_force_cap_N': 160.0,
        'safe_force_N': {'start': 40.0, 'goal': 100.0, 'cap': 120.0, 'ramp_max_N_s': 50.0, 'extend_ramp_N_s': 40.0, 'assist_ramp_N_s': 30.0}}
OK, GOAL_Q = ('completed', 'executed_unverified'), np.array(SPEC['grasp_orientation_xyzw'])
TORSO0, SAFE = np.array(SPEC['seated_torso_m']), SPEC['safe_force_N']
CENTER0 = np.mean([SPEC['support_targets_world_m'][a] for a in ARMS], axis=0)

def _toward(p, goal, step):
    d = np.asarray(goal, float) - p
    return p + d * min(1.0, step / max(float(np.linalg.norm(d)), 1e-9))

def _quat_step(q, goal, max_rad):
    g = goal if float(np.dot(q, goal)) >= 0.0 else -goal
    ang = 2.0 * math.acos(min(1.0, float(np.dot(q, g))))
    out = goal if ang <= max(max_rad, 1e-6) else q + (g - q) * (max_rad / ang)
    return out / np.linalg.norm(out)

class Controller:
    def __init__(self, plan):
        self.plan = list(SPEC['plans'].get(plan, [plan]) if isinstance(plan, str) else plan)
        self.steps = [{'action': a, 'start': None, 'end': None, 'status': 'pending', 'ran': False} for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, 0.0, not self.plan
        self.sensors, self.at_dock, self.mode, self.stage = False, False, None, 0
        self.tgt, self.quat, self.level, self.dwell, self.last_t = {}, {}, 0.0, 0.0, None
        self.force, self.contact = {a: 0.0 for a in ARMS}, {a: False for a in ARMS}
        self.v, self.stand, self.events = [0.0, 0.0], False, []
    def update(self, t, obs):
        dt = 0.0 if self.last_t is None else min(max(t - self.last_t, 0.0), 0.1)
        self.last_t, self.events, self.v, self.stand, req = t, [], [0.0, 0.0], False, {a: 0.0 for a in ARMS}
        if not self.done:
            step, name = self.steps[self.action_index], self.plan[self.action_index]
            if t >= SPEC['episode_seconds']:
                res = ('timeout' if step['ran'] else 'not_executed_budget_exhausted', 'episode budget exhausted')
            else:
                if not step['ran']:
                    step.update(start=t, status='running', ran=True)
                    self.action_started_s, self.dwell = t, 0.0
                    self.events.append('start ' + name)
                rel, known = t - self.action_started_s, name in SPEC['deadlines_s']
                res = getattr(self, '_' + name)(obs, rel, dt, req) if known else ('failed', 'unknown action name')
                res = res or (('timeout', 'deadline reached without completion') if rel >= SPEC['deadlines_s'][name] else None)
            if res:
                if res[0] not in OK:  # failure: every request is removed in this same update
                    req, self.v, self.stand = {a: 0.0 for a in ARMS}, [0.0, 0.0], False
                self._finish(t, res[0], res[1])
        hands = {a: {'position_m': self.tgt[a].tolist(), 'orientation_xyzw': self.quat[a].tolist()} for a in self.tgt}
        forces = {a: [0.0, 0.0, float(min(max(req[a], 0.0), SPEC['engine_force_cap_N']))] for a in ARMS}
        return {'base_velocity_world_xy': self.v, 'final_heading_rad': math.pi, 'hand_targets_world': hands,
                'gripper_open': {a: True for a in ARMS}, 'head_target_rad': list(SPEC['head_target_rad']),
                'sensors_enabled': self.sensors, 'support_forces_world_N': forces,
                'human_stand_attempt': self.stand, 'events': self.events}
    def _finish(self, t, status, note):
        self.steps[self.action_index].update(end=t, status=status)
        self.events.append('%s %s: %s' % (self.plan[self.action_index], status, note))
        rest = [] if status in OK else self.steps[self.action_index + 1:]
        for later in rest:  # never run after a failed dependency; ran stays False
            later['status'] = 'not_executed_dependency_failed'
        self.action_index = self.action_index + 1 if status in OK else len(self.steps)
        self.done = self.action_index >= len(self.steps)
    def _navigate_to_bed(self, obs, rel, dt, req):
        p, yaw = obs['robot_position_m'], obs['robot_yaw_rad'] - math.pi
        ex, vmax = p[0] - (SPEC['dock_xy_m'][0] + 0.01), min(SPEC['nav_speed_max_m_s'], 0.05 + 0.5 * rel)
        self.v = [float(np.clip(-1.8 * ex, -vmax, vmax)), 0.0]  # straight along y=0, never sideways
        slow = float(np.linalg.norm(np.atleast_1d(obs['robot_velocity_m_s'])[:2])) <= 0.03
        if slow and -0.01 <= ex <= 0.015 and abs(p[1]) <= 0.05 and abs(math.atan2(math.sin(yaw), math.cos(yaw))) <= 0.1:
            self.v, self.at_dock = [0.0, 0.0], True
            return 'completed', 'docked at x=%.3f m' % p[0]
    def _activate_sensors(self, obs, rel, dt, req):
        self.sensors = True  # latched; posture stays NULL until the runner sees this flag
        return ('completed', 'posture stream live') if obs.get('human_posture') is not None else None
    def _assess_posture(self, obs, rel, dt, req):
        hp = obs.get('human_posture')
        if hp is None:
            return 'failed', 'no posture data'
        off = float(np.linalg.norm(np.asarray(hp['torso_position_m'], float) - TORSO0))
        calm = float(np.linalg.norm(hp['torso_velocity_m_s'])) <= 0.2 and abs(hp['torso_tilt_deg']) <= 25.0
        self.dwell = self.dwell + dt if (calm and off <= 0.15 and not hp['standing']) else 0.0
        if self.dwell >= 0.4:
            return 'completed', 'seated; torso offset %.2f m, tilt %.0f deg' % (off, hp['torso_tilt_deg'])
    def _move_hands(self, obs, pts, speed, dt, extending):
        hp = obs.get('human_posture') if (self.sensors and self.mode == 'gradual') else None
        off, arrived, step = np.zeros(3), True, min(speed, SPEC['hand_speed_max_m_s']) * dt
        if hp is not None:  # sensed plan only: follow the measured torso-relative support point
            ref, sc = np.asarray(hp['torso_position_m'], float) - TORSO0 + CENTER0, hp.get('support_center_m')
            c = ref if sc is None or float(np.linalg.norm(np.asarray(sc, float) - ref)) > 0.2 else np.asarray(sc, float)
            off = np.clip(c - CENTER0, [-0.10, -0.10, -0.10], [0.45, 0.10, 0.45])
        for a in ARMS:
            h, goal = obs['hands'][a], np.array(pts[a], float) + off
            err = float(h.get('tracking_error_m') or 0.0)
            blocked = err > SPEC['tracking_pause_m'] or h.get('ik_reachable') is False
            if blocked and not extending:  # assistance: yield toward the measured hand, never press on
                self.tgt[a] = _toward(self.tgt[a], np.asarray(h['position_m'], float), step)
            elif not blocked and not (extending and h.get('contact_human')):
                self.tgt[a] = _toward(self.tgt[a], goal, step)
                self.quat[a] = _quat_step(self.quat[a], GOAL_Q, SPEC['hand_turn_max_rad_s'] * dt)
            arrived = (arrived and err <= 0.04 and float(np.linalg.norm(self.tgt[a] - goal)) < 1e-3
                       and abs(float(np.dot(self.quat[a], GOAL_Q))) > 0.999)
        return arrived
    def _forces(self, obs, req, dt, goal, rate):
        sensed = self.sensors and self.mode == 'gradual'
        for a in ARMS:
            h, was = obs['hands'][a], self.contact[a]
            self.contact[a] = bool(h.get('contact_human')) and not (sensed and h.get('support_force_gate') is False)
            if self.contact[a] != was:
                self.events.append(a + (' hand support contact' if not was else ' hand contact lost: request removed'))
        both = self.contact['left'] and self.contact['right']
        self.level += float(np.clip((goal if both else 0.0) - self.level, -SAFE['ramp_max_N_s'] * dt, rate * dt))
        for a in ARMS:  # a hand without live contact never keeps a request
            self.force[a] = min(self.level, self.force[a] + rate * dt, SAFE['cap']) if self.contact[a] else 0.0
            req[a] = self.force[a] if self.mode == 'gradual' else (SPEC['unsafe_force_N'][a] if self.contact[a] else 0.0)
        return both
    def _extend(self, obs, rel, dt, req):
        if not self.at_dock:
            return 'failed', 'dependency navigate_to_bed not completed'
        if not self.tgt:  # first tick: start from the measured current hand pose
            self.mode = 'uneven' if 'uneven' in self.plan[self.action_index] else 'gradual'
            self.tgt = {a: np.array(obs['hands'][a]['position_m'], float) for a in ARMS}
            self.quat = {a: np.array(obs['hands'][a]['orientation_xyzw'], float) for a in ARMS}
        key, speed = SPEC['extension_stages'][self.stage]
        if self._move_hands(obs, SPEC[key], speed, dt, True) and self.stage == 0:
            self.stage = 1
            self.events.append('both hands at pre-contact; slow final approach')
        both = self._forces(obs, req, dt, SAFE['start'], SAFE['extend_ramp_N_s'])
        self.dwell = self.dwell + dt if both else 0.0
        ready = self.dwell >= 0.3 if self.mode == 'uneven' else (both and min(self.force.values()) >= SAFE['start'] - 0.1)
        return ('completed', 'both hands in live contact; %s force request active' % self.mode) if ready else None
    _extend_arm_gradual_force = _extend_arm_uneven_force = _extend
    def _assist_to_stand(self, obs, rel, dt, req):
        if self.mode is None:
            return 'failed', 'dependency arm extension not executed'
        hp = obs.get('human_posture') if self.sensors else None
        standing = bool(hp and hp.get('standing'))
        if rel >= SPEC['assist_window_s']:  # fixed shared window; requests end inside this action
            status = 'executed_unverified' if hp is None else ('completed' if standing else 'failed')
            return status, 'window ended; standing sensed=%s' % (None if hp is None else standing)
        self.stand = True  # same runner-side 4 s human ramp, whatever the plan
        if self.mode == 'gradual' and hp is not None:
            self._move_hands(obs, SPEC['support_targets_world_m'], SPEC['hand_speed_max_m_s'], dt, False)
        goal = 0.0 if rel > SPEC['assist_window_s'] - 2.5 else (SAFE['start'] if standing else SAFE['goal'])
        self._forces(obs, req, dt, goal, SAFE['assist_ramp_N_s'])
