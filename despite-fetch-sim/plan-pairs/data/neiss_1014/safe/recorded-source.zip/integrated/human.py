'''Seated-to-standing PhysX mannequin: eleven dynamic links, bounded PhysX muscle
drives and one bounded internal balance couple (structure reused from the tested
API example). No plan, variant, robot-action, navigation, or outcome input.
All strengths and gains are uncalibrated assumptions; standing is not guaranteed.
'''
import math
import numpy as np
from scipy.spatial.transform import Rotation as R
from pxr import UsdPhysics

LEG_Y, ARM_Y = .12, .185
RAMP_S = 4.0                 # common muscle-target ramp after the first stand_attempt
HIP_LEAN_DEG = 20.0          # peak forward pelvis pitch taken at the hips
WAIST_LEAN_DEG = 25.0        # peak additional forward torso pitch taken at the waist
RESIDUAL_LEAN = .15          # fraction of the lean kept at the end of the ramp
K_TILT, D_TILT = 600., 60.   # N m/rad and N m s/rad on torso tilt error
K_COM, D_COM = 300., 40.     # N m/m and N m s/m on horizontal centre-of-mass error
BALANCE_CAP_PER_FOOT = 15.   # N m of internal couple per foot touching the floor
COM_END_OFFSET = -.05        # final CoM reference vs mean foot centre along heading, m
# joint kind: (stiffness, damping, max torque N m) in USD angular-drive units
DRIVES = {'waist': (160, 18, 90), 'neck': (30, 3, 8), 'hip': (140, 14, 60),
          'knee': (140, 14, 60), 'ankle': (80, 8, 30), 'shoulder': (15, 2, 6)}
SIDES = [('left', 1), ('right', -1)]   # facing +X, left is +Y


def _smooth(x):
    x = min(1., max(0., x))
    return x * x * (3. - 2. * x)


def human_layout():
    skin, sweater, trousers, shoes = [.72, .52, .39], [.39, .57, .57], [.22, .28, .36], [.20, .16, .13]
    rows = [
        ('h_pelvis', [0., 0., .65], [.31, .23, .18], trousers, 10),
        ('h_torso', [0., 0., .96], [.30, .25, .46], sweater, 24),
        ('h_head', [0., 0., 1.35], [.26, .26, .26], skin, 4.6, 'Sphere'),
    ]
    for side, sign in SIDES:
        y = sign * LEG_Y
        rows += [
            ('h_' + side + '_thigh', [.20, y, .62], [.40, .105, .11], trousers, 6),
            ('h_' + side + '_shin', [.40, y, .375], [.10, .10, .49], trousers, 3.6),
            ('h_' + side + '_foot', [.47, y, .075], [.30, .17, .11], shoes, 1.2),
            ('h_' + side + '_arm', [0., sign * ARM_Y, .97], [.09, .09, .42], sweater, 2.2),
        ]
    return rows


class Mannequin:
    def __init__(self, state_reader, joint_factory, floor_contact_reader):
        self.state, self.contact = state_reader, floor_contact_reader
        rows = human_layout()
        self.names = [r[0] for r in rows]
        self.masses = {r[0]: float(r[4]) for r in rows}
        self.total_mass = sum(self.masses.values())
        self.joints, self.targets = {}, {}
        self.t_stand, self.d0, self.phase = None, None, (0., 0., 0.)
        self.balance_torque, self.balance_saturated_ticks, self.feet_in_contact = [0., 0., 0.], 0, []

        def add(name, a, b, anchor, limits):
            kp, kd, cap = DRIVES[name.split('_')[-1]]
            joint = joint_factory(name, a, b, anchor, 'ball', limits)
            drives = []
            for axis in ['rotX', 'rotY', 'rotZ']:
                d = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), axis)
                d.CreateTypeAttr('force'); d.CreateStiffnessAttr(float(kp)); d.CreateDampingAttr(float(kd))
                d.CreateMaxForceAttr(float(cap)); d.CreateTargetPositionAttr(0.0); d.CreateTargetVelocityAttr(0.0)
                drives.append(d)
            self.joints[name] = (a, b, drives)
            self.targets[name] = [0., 0., 0.]
        # Limits in degrees about initial world axes: rotY is sagittal pitch, +Y tips the top toward +X.
        add('waist', 'h_pelvis', 'h_torso', [0., 0., .74], [[-25, 25], [-25, 50], [-30, 30]])
        add('neck', 'h_torso', 'h_head', [0., 0., 1.205], [[-40, 40], [-45, 45], [-60, 60]])
        for side, sign in SIDES:
            y, p = sign * LEG_Y, 'h_' + side + '_'
            add(side + '_hip', 'h_pelvis', p + 'thigh', [0., y, .62], [[-30, 30], [-40, 100], [-30, 30]])
            add(side + '_knee', p + 'thigh', p + 'shin', [.40, y, .62], [[1, -1], [-95, 45], [1, -1]])
            add(side + '_ankle', p + 'shin', p + 'foot', [.40, y, .13], [[-20, 20], [-35, 35], [-15, 15]])
            add(side + '_shoulder', 'h_torso', p + 'arm', [0., sign * ARM_Y, 1.14], [[-60, 60], [-80, 80], [-40, 40]])

    def _set(self, name, pitch_deg):
        if abs(pitch_deg - self.targets[name][1]) > 1e-4:   # skip redundant USD writes
            self.targets[name][1] = float(pitch_deg)
            self.joints[name][2][1].GetTargetPositionAttr().Set(float(pitch_deg))

    def control(self, t, torques, stand_attempt=False):
        if stand_attempt and self.t_stand is None:
            self.t_stand = float(t)   # latched once; afterwards only the clock is used
        u = 0. if self.t_stand is None else min(1., max(0., (t - self.t_stand) / RAMP_S))
        rise, settle = _smooth(u / .30), _smooth((u - .40) / .60)
        lean = rise * (1. - (1. - RESIDUAL_LEAN) * settle)   # early forward lean, later more upright
        ext = _smooth((u - .25) / .75)                       # hip and knee extension
        self.phase = (u, lean, ext)
        pelvis_plan = HIP_LEAN_DEG * lean     # planned world pelvis pitch, deg
        hip = 90. * ext - pelvis_plan         # thigh relative to pelvis
        knee = -90. * ext                     # shin relative to thigh; planned shin stays vertical
        ankle = -(pelvis_plan + hip + knee)   # foot relative to shin cancels planned shin pitch (zero here)
        waist = WAIST_LEAN_DEG * lean
        self._set('waist', waist)
        for side, _ in SIDES:
            self._set(side + '_hip', hip); self._set(side + '_knee', knee); self._set(side + '_ankle', ankle)
        self._balance(math.radians(pelvis_plan + waist), .3 * rise + .7 * ext, torques)

    def _balance(self, torso_pitch, transfer, torques):
        s = {n: self.state(n) for n in self.names}
        com = sum(s[n][0] * m for n, m in self.masses.items()) / self.total_mass
        com_v = sum(s[n][2] * m for n, m in self.masses.items()) / self.total_mass
        feet = [n for n in self.names if n.endswith('_foot') and self.contact(n)]
        torque = np.zeros(3)
        if feet:   # the only gate: physical foot-floor contact
            rot = R.from_quat(s['h_torso'][1])
            fwd = rot.apply([1., 0., 0.])
            yaw = math.atan2(fwd[1], fwd[0])
            heading, left = np.array([math.cos(yaw), math.sin(yaw)]), np.array([-math.sin(yaw), math.cos(yaw)])
            desired = R.from_euler('ZY', [yaw, torso_pitch])   # planned lean in the current heading
            torque = -K_TILT * (rot * desired.inv()).as_rotvec() - D_TILT * np.asarray(s['h_torso'][3], dtype=float)
            support = np.mean([s[n][0] for n in feet], axis=0)
            offset = (com - support)[:2]
            if self.t_stand is None or self.d0 is None:   # seated offset, heading frame, until the ramp starts
                self.d0 = np.array([offset @ heading, offset @ left])
            ref = self.d0 * (1. - transfer) + np.array([COM_END_OFFSET, 0.]) * transfer
            err = offset - (ref[0] * heading + ref[1] * left)
            torque[0] += K_COM * err[1] + D_COM * com_v[1]
            torque[1] -= K_COM * err[0] + D_COM * com_v[0]
            torque[2] = 0.   # no yaw anchoring
            cap = BALANCE_CAP_PER_FOOT * len(feet)
            norm = float(np.linalg.norm(torque))
            self.balance_saturated_ticks += int(norm > cap)
            torque *= min(1., cap / max(norm, 1e-9))
            # Internal equal/opposite couple, not an external upright constraint.
            torques['h_torso'] += torque
            for n in feet: torques[n] -= torque / len(feet)
        self.balance_torque, self.feet_in_contact = torque.tolist(), feet

    def measure(self):
        s = {n: self.state(n) for n in self.names}
        angles, errors = {}, {}
        for name, (a, b, _) in self.joints.items():
            rel = R.from_quat(s[a][1]).inv() * R.from_quat(s[b][1])
            angles[name] = np.degrees(rel.as_rotvec()).tolist()
            errors[name] = self.targets[name][1] - angles[name][1]
        com = sum(s[n][0] * m for n, m in self.masses.items()) / self.total_mass
        com_v = sum(s[n][2] * m for n, m in self.masses.items()) / self.total_mass
        vec = lambda i: {n: np.asarray(s[n][i], dtype=float).tolist() for n in self.names}
        return dict(body_positions=vec(0), body_orientations_xyzw=vec(1), body_velocities_m_s=vec(2),
                    body_angular_velocities_rad_s=vec(3),
                    joint_relative_rotation_vectors_deg=angles,
                    joint_motor_targets_deg={k: list(v) for k, v in self.targets.items()},
                    joint_pitch_tracking_error_deg=errors,
                    joint_drive_torque_caps_N_m={k: float(DRIVES[k.split('_')[-1]][2]) for k in self.joints},
                    stand_ramp=dict(start_time_s=self.t_stand, progress=self.phase[0], lean=self.phase[1], extension=self.phase[2]),
                    feet_in_floor_contact=list(self.feet_in_contact),
                    center_of_mass_m=np.asarray(com).tolist(), center_of_mass_velocity_m_s=np.asarray(com_v).tolist(),
                    total_mass_kg=self.total_mass,
                    balance_torso_torque_N_m=list(self.balance_torque),
                    balance_saturation_ticks=self.balance_saturated_ticks)
