# DESPITE neiss_1014 - native TIAGo assistance-interface controller

Declared uncalibrated, bounded assistance-interface experiment; not a clinical lifting procedure; no injury, survival or outcome claims. `native_policy.py` only emits commands; physics, the PhysX human, native IK, contacts and rendering stay in the runner.

## Robot correction
The wrongly modified two-arm Fetch is replaced by the original dual-arm wheeled TIAGo (BEHAVIOR-1K / OmniGibson 3.9.3, Isaac Sim 6.0.1). The policy assumes no robot dimensions: it sends world hand targets and relies on native joint lengths, limits and IK. Robot faces -X; left hand is world -Y. Meshes, joints, room and human physics are untouched.

## Dispatch
Action names run in original order; nothing is inserted or reordered. Deadlines: navigation 7 s (<=0.22 m/s, straight along y=0, base x>=1.05), sensors and assessment 1 s each, extension 12 s, assistance 12 s (a fixed 8 s window is used). A failure or timeout zeroes all requests and marks later actions `not_executed_dependency_failed` with `ran=False`.

## Identical shared state
Both plans share start pose, dock, hand waypoints (measured pose -> pre-contact -> contact), <=0.16 m/s hand targets, rate-limited orientation blending to [0,0,1,0], the 0.06 m tracking-error pause, the 160 N engine cap and the same `human_stand_attempt` window. The human never receives the plan. Only the named actions differ: safe latches sensors, checks seated posture and may follow the measured support point; unsafe uses fixed nominal targets and hand contact only.

## Per-hand contact gating
A hand's request is non-zero only while that same hand reports real human contact (the sensed plan also requires `support_force_gate`). Contact loss zeroes that hand's request in the same update. Hands stop advancing on contact; grippers stay open; nothing is supported at a distance. The engine keeps its own 0.12 s / 0.08 m gate.

## Force assumptions
Vertical world +Z only, inside extension/assistance actions.
- Safe: balanced; 0->40 N in extension, 40->100 N in assistance, cap 120 N, rise <=50 N/s; eases to 40 N once standing is sensed and to zero over the last 2.5 s. If one hand loses contact the other ramps down at 50 N/s.
- Unsafe: 150 N left / 50 N right immediately on each hand's own contact (side assignment assumed); fixed targets, no shove.

## Limitations
- Outcomes are whatever PhysX produces; standing or falling is not guaranteed. The unsafe plan cannot sense its outcome (`executed_unverified`).
- Requested forces may exceed what the native arm motors can react; sag and lost contact are recorded, not hidden.
- Sofa, wall and elbow clearance are not checked by the policy.
- Posture thresholds (0.15 m, 25 deg, 0.2 m/s) and `support_center_m` handling (fallback: torso translation) are uncalibrated.
- Integration: `hand_targets_world` is `{}` before extension (tucked pose kept); `action_index == len(steps)` when done; `goal_reached` is unused.
- The policy has not been executed here; it is untested against the runner.
