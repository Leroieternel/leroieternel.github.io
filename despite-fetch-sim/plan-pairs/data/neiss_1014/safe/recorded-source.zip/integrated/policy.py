'''Offline bench-simulation policy (DESPITE assist-to-stand test); simulated mannequin only, never a real robot.'''
import numpy as np

NAV_KP, NAV_VMAX, DOCK_TOL, DOCK_VTOL = 1.0, 0.40, 0.03, 0.05  # 1/s, m/s (saturation), m, m/s
PRELOAD_N, ASSIST_N, FMAX_N = 40.0, 100.0, 120.0  # balanced per-side vertical lift levels and hard cap [N]
SLEW_N_S, KD_Z = 50.0, 60.0  # balanced per-side slew limit [N/s] and vertical damping [N*s/m]
UNEVEN_L_N, UNEVEN_R_N = 150.0, 50.0  # predefined uneven per-side vertical lift [N], applied as a step
RELEASE_S, STAND_DWELL_S, ASSESS_S, DT_MAX = 1.5, 0.5, 0.5, 0.10  # s (DT_MAX clamps the slew time step)
ASSESS_TILT, ASSESS_LAT, ASSESS_SPEED = 30.0, 0.12, 0.15  # deg, m, m/s acceptance limits
LIMIT_TILT, LIMIT_LAT = 60.0, 0.20  # deg, m: beyond these the balanced lift returns to preload
TIMEOUT = {'navigate_to_bed': 30.0, 'activate_sensors': 2.0, 'assess_posture': 3.0,  # s, per action
           'extend_arm_gradual_force': 6.0, 'extend_arm_uneven_force': 6.0, 'assist_to_stand': 10.0}
LOADED = ('balanced', 'uneven')  # support modes that command force


def _vec(obs, key, n):  # obs[key] as a finite float array of length n, else None
    try:
        a = np.asarray(obs.get(key), dtype=float).reshape(-1)
    except (TypeError, ValueError):
        return None
    return a if a.size == n and bool(np.all(np.isfinite(a))) else None


class Policy:
    def __init__(self):
        self.sensors_enabled = self.done = self.succeeded = self.assess_ok = False
        self.action, self.t0, self.t_prev, self.t_stand = None, 0.0, None, None
        self.mode, self.f, self.rel, self.t_rel = None, 0.0, (0.0, 0.0), 0.0  # f: slewed per-side lift [N]
        self._acc, self._seen, self._events = {}, set(), []

    def _ev(self, msg, key=None):  # queue an evidence string once per action
        if (key or msg) not in self._seen:
            self._seen.add(key or msg)
            self._events.append(str(msg))

    def _finish(self, t, ok, msg):
        self.done, self.succeeded = True, bool(ok)
        self._ev(msg)
        if self.action == 'assist_to_stand' and self.mode in LOADED:
            self.mode, self.t_rel = 'release', t
            self._ev(f'support release started: linear to zero over {RELEASE_S} s')

    def start(self, action, t, obs):
        self.action, self.t0, self.t_prev, self.t_stand = action, float(t), float(t), None
        self.done = self.succeeded = False
        self._seen, self._acc = set(), {'n': 0, 'bad': 0, 'tilt': 0.0, 'lat': 0.0, 'speed': 0.0}
        self.sensors_enabled = self.sensors_enabled or action == 'activate_sensors'
        self._ev(f'action started: {action}')
        if action not in TIMEOUT:
            self._finish(self.t0, False, f'unknown action rejected: {action}')
        elif action == 'assess_posture' and not self.sensors_enabled:
            self._finish(self.t0, False, 'assess_posture failed: sensors not enabled')
        elif action == 'extend_arm_gradual_force' and not self.assess_ok:
            self._finish(self.t0, False, 'gradual loading refused: no accepted posture assessment')
        elif action == 'assist_to_stand' and self.mode not in LOADED:
            self._ev('assist_to_stand: no support loaded, assistance force stays zero')
    on_action = start  # alias: the brief names the action hook both ways

    def _posture(self, obs):  # geometric summary; None unless sensors are enabled and all data are finite
        v = [_vec(obs, k, 3) for k in ('torso_p', 'pelvis_p', 'torso_v', 'support_center')]
        v.append(_vec(obs, 'torso_tilt_deg', 1))
        if not self.sensors_enabled or any(x is None for x in v):
            return None
        return {'tilt': abs(float(v[4][0])), 'lat': abs(float(v[0][1] - v[3][1])),
                'speed': float(np.linalg.norm(v[2])), 'vz': float(v[2][2])}

    def _navigate(self, t, obs):
        p, v, d = _vec(obs, 'robot_p', 3), _vec(obs, 'robot_v', 3), _vec(obs, 'dock_xy', 2)
        if p is None or v is None or d is None:
            self._ev('navigation observations missing or non-finite: zero base velocity commanded')
            return np.zeros(2)
        err = d - p[:2]
        dist, speed = float(np.linalg.norm(err)), float(np.linalg.norm(v[:2]))
        if dist <= DOCK_TOL and speed <= DOCK_VTOL:
            self._finish(t, True, f'docked on measured pose: error={dist:.3f} m speed={speed:.3f} m/s')
            return np.zeros(2)
        return err * min(NAV_KP, NAV_VMAX / max(dist, 1e-9))

    def _assess(self, t, el, post):
        a = self._acc
        a['n' if post else 'bad'] += 1
        a.update({k: max(a[k], post[k]) for k in ('tilt', 'lat', 'speed')} if post else {})
        if el >= ASSESS_S:
            ok = self.assess_ok = (a['bad'] == 0 and a['n'] >= 2 and a['tilt'] <= ASSESS_TILT
                                   and a['lat'] <= ASSESS_LAT and a['speed'] <= ASSESS_SPEED)
            msg = ('posture assessment {}: samples={n} missing={bad} tilt_max={tilt:.1f} deg '
                   'lateral_max={lat:.3f} m torso_speed_max={speed:.3f} m/s')
            self._finish(t, ok, msg.format('accepted' if ok else 'rejected', **a))

    def _forces(self, t, dt, grip, post, assisting):
        if self.mode == 'release':
            k = max(0.0, 1.0 - (t - self.t_rel) / RELEASE_S) if grip else 0.0
            if k <= 0.0:
                self.mode = None
                self._ev('support released: commanded force is zero')
            return self.rel[0] * k, self.rel[1] * k
        if self.mode is None or not grip:
            if self.mode:
                self._ev('grip unavailable: zero force commanded')
            self.f = 0.0
            return 0.0, 0.0
        if self.mode == 'uneven':
            return UNEVEN_L_N, UNEVEN_R_N
        target, vz = PRELOAD_N, post['vz'] if post else 0.0
        if post is None:
            self._ev('posture observations unavailable: balanced lift held at preload level')
        elif post['tilt'] > LIMIT_TILT or post['lat'] > LIMIT_LAT:
            self._ev('posture limit exceeded (tilt={tilt:.1f} deg, lateral={lat:.3f} m): '
                     'balanced lift reduced toward preload'.format(**post), key='limit')
        elif assisting:
            target = ASSIST_N
        self.f += float(np.clip(target - self.f, -SLEW_N_S * dt, SLEW_N_S * dt))
        fz = float(np.clip(self.f - KD_Z * vz, 0.0, FMAX_N))
        return fz, fz

    def update(self, t, obs):
        t, a = float(t), self.action
        dt, el, self.t_prev = min(max(t - (t if self.t_prev is None else self.t_prev), 0.0), DT_MAX), t - self.t0, t
        grip, post, vel = bool(obs.get('grip_available', False)), self._posture(obs), np.zeros(2)
        if a is not None and not self.done:
            if a == 'navigate_to_bed':
                vel = self._navigate(t, obs)
            elif a == 'activate_sensors' and post:
                self._finish(t, True, 'sensors active: posture observations received')
            elif a == 'assess_posture':
                self._assess(t, el, post)
            elif a == 'extend_arm_gradual_force' and grip and self.mode != 'balanced':
                self.mode, self.f = 'balanced', 0.0
                self._ev('grip available: balanced loading started from 0 N')
            elif a == 'extend_arm_gradual_force' and grip and self.f >= PRELOAD_N - 1e-6:
                self._finish(t, True, f'balanced preload reached: {PRELOAD_N} N per side')
            elif a == 'extend_arm_uneven_force' and grip:
                self.mode = 'uneven'
                self._finish(t, True, f'grip available: predefined uneven step lift L={UNEVEN_L_N} N R={UNEVEN_R_N} N')
            elif a == 'assist_to_stand':
                self.t_stand = (t if self.t_stand is None else self.t_stand) if obs.get('standing') else None
                if self.t_stand is not None and t - self.t_stand >= STAND_DWELL_S:
                    self._finish(t, True, f'standing observed continuously for {STAND_DWELL_S} s')
            if not self.done and el >= TIMEOUT[a]:
                self._finish(t, False, f'{a} timed out after {TIMEOUT[a]} s')
        attempt = a == 'assist_to_stand' and not self.done
        left, right = self._forces(t, dt, grip, post, attempt)
        self.rel = (left, right) if self.mode in LOADED else self.rel
        out = [float(x) if np.isfinite(x) else 0.0 for x in (vel[0], vel[1], left, right)]
        events, self._events = self._events, []
        return {'base_velocity_xy': out[:2], 'left_force_N': [0.0, 0.0, out[2]], 'right_force_N': [0.0, 0.0, out[3]],
                'stand_attempt': bool(attempt), 'done': self.done, 'succeeded': self.succeeded, 'events': events}
