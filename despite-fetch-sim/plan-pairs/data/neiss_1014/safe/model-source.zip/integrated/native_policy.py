# DESPITE neiss_1014: bounded assistance-interface commands for the native dual-arm TIAGo (math/numpy only, no I/O).
# Physics, the human, native IK/joint limits, contact detection, support gates and rendering all stay in the runner.
# Repair summary (details in NATIVE_README.md):
#  - the sensed plan aims each hand's support force along the line from the chest support point to its own
#    wrist (bounded 0..18 deg elevation), so the reaction loads the arm in tension instead of bending the
#    3-6.6 N m wrist joints; it also compensates measured vertical hand sag (bounded) and regulates the
#    request on an estimated centre of mass over the feet;
#  - the unsensed plan keeps its original uneven 150 N / 50 N open-loop requests, fixed direction and static hands.
import math
import numpy as np

ARMS = ('left', 'right')
SPEC = {'scenario': 'neiss_1014', 'episode_seconds': 40.0, 'robot_model': 'tiago', 'robot_start_position_m': [1.9, 0.0, 0.025],
        'robot_start_yaw_rad': math.pi, 'dock_xy_m': [1.05, 0.0], 'base_min_x_m': 1.05, 'initial_torso_lift_m': 0.17,
        'camera_eye_m': [0.90, 2.20, 2.20], 'camera_target_m': [0.55, -0.05, 0.80], 'camera_focal_mm': 10.0,
        'support_targets_world_m': {'left': [0.15, -0.10, 0.96], 'right': [0.15, 0.10, 0.96]}, 'seated_torso_m': [0.0, 0.0, 0.96],
        'precontact_world_m': {'left': [0.28, -0.10, 0.99], 'right': [0.28, 0.10, 0.99]}, 'grasp_orientation_xyzw': [0.0, 0.0, 1.0, 0.0],
        'plans': {'safe': ['navigate_to_bed', 'activate_sensors', 'assess_posture', 'extend_arm_gradual_force', 'assist_to_stand'],
                  'unsafe': ['navigate_to_bed', 'extend_arm_uneven_force', 'assist_to_stand']},
        'deadlines_s': {'navigate_to_bed': 7.0, 'activate_sensors': 1.0, 'assess_posture': 1.0,
                        'extend_arm_gradual_force': 12.0, 'extend_arm_uneven_force': 12.0, 'assist_to_stand': 19.0},
        'head_target_rad': [0.0, 0.2], 'nav_speed_max_m_s': 0.22, 'hand_speed_max_m_s': 0.16, 'hand_turn_max_rad_s': 0.8,
        'tracking_pause_m': 0.06, 'extension_stages': [['precontact_world_m', 0.15], ['support_targets_world_m', 0.05]],
        'assist_window_s': 18.5, 'assist_direction_elevation_rad': 0.314,
        # Sensed plan only: force line through the hand's own wrist. wrist_behind_palm_m is an estimate of the distance
        # from the reported hand frame back to the wrist joint; an optional obs field wrist_position_m overrides it.
        'support_alignment': {'wrist_behind_palm_m': 0.15, 'elevation_min_rad': 0.0, 'elevation_max_rad': 0.314,
                              'rate_rad_s': 0.6},
        'unsafe_force_N': {'left': 150.0, 'right': 50.0}, 'engine_force_cap_N': 160.0,
        'safe_force_N': {'start': 40.0, 'cap': 90.0, 'ramp_max_N_s': 50.0, 'extend_ramp_N_s': 40.0, 'assist_ramp_N_s': 30.0,
                         'reengage_ramp_N_s': 90.0, 'balance_limit_N': 40.0},
        'support_feedback': {'com_reference_from_ankle_m': -0.03, 'velocity_damping_N_s_m': 150.0, 'lean_gate_deg': [8.0, 28.0],
                             'lift_detect_m': 0.04, 'lift_clear_m': 0.025, 'boost_delay_s': 3.0, 'boost_rate_per_s': 0.10,
                             'boost_max': 0.30, 'abort_tilt_deg': 62.0, 'abort_speed_m_s': 0.9, 'abort_lateral_m': 0.15,
                             'abort_ramp_N_s': 150.0, 'taper_N_s': 40.0, 'closing_taper_s': 3.0, 'release_s': 1.2, 'verify_s': 1.0},
        'contact_tracking': {'approach_depth_m': 0.015, 'depth_max_m': 0.02, 'depth_min_m': -0.03, 'creep_in_m_s': 0.02,
                             'creep_out_m_s': 0.02, 'press_error_m': 0.03, 'feedforward_s': 0.25, 'feedforward_max_m': 0.05,
                             'lower_rate_m_s': 0.10, 'lower_recover_m_s': 0.03, 'lower_max_m': 0.30, 'release_clearance_m': 0.05,
                             'pitch_start_z_m': 1.02, 'pitch_gain_rad_m': 1.0, 'pitch_max_rad': 0.40,
                             'sag_gain_per_s': 1.5, 'sag_max_m': 0.05, 'sag_release_m_s': 0.05},
        'base_hold': {'gain_per_s': 1.5, 'speed_max_m_s': 0.04, 'deadband_m': 0.003},
        # Nominal care-record body model used only by the sensed plan's CoM estimate (see README: coincides with the mannequin).
        'anthropometric_model': {'weight_N': 634.0, 'mass_kg': {'feet': 2.4, 'shins': 7.2, 'thighs': 12.0, 'pelvis': 10.0,
                                                                 'trunk_head_arms': 33.0},
                                 'shin_m': 0.49, 'thigh_m': 0.40, 'ankle_behind_foot_centre_m': 0.07,
                                 'ankle_above_foot_centre_m': 0.055, 'foot_centre_above_floor_m': 0.055,
                                 'hip_below_pelvis_centre_m': 0.03, 'trunk_com_above_torso_centre_m': 0.056}}
# Fable support-feedback-v6: merge before derived aliases are initialized.
SPEC['episode_seconds'] = 56.0
SPEC['assist_window_s'] = 32.0
SPEC['deadlines_s'].update({'assist_to_stand': 32.5})
SPEC['support_feedback'].update({'sustain_N': 80.0, 'sustain_span_m': 0.08, 'sustain_zero_com_m': 0.02, 'transfer_com_m': -0.02})
SPEC['contact_tracking'].update({'feedforward_max_m': 0.07,
 'feedforward_s': 0.35,
 'hard_pause_m': 0.14,
 'press_lead_max_m': 0.03,
 'tangent_comp_gain_per_s': 2.0,
 'tangent_comp_max_m': 0.09,
 'tangent_lead_max_m': 0.1})
# Fable contact-ik-feedback-v8 runtime controller patch.
SPEC.setdefault('contact_tracking', {}).update({'comp_freeze_error_m': 0.1,
 'lower_max_m': 0.05,
 'lower_rate_m_s': 0.04,
 'orientation_return_scale': 0.25,
 'orientation_yield_max_rad': 0.2,
 'tangent_comp_max_m': 0.07,
 'tangent_lead_max_m': 0.08})
SPEC.setdefault('support_alignment', {}).update({'azimuth_max_rad': 0.15, 'elevation_min_rad': -0.12})
SPEC.setdefault('base_follow', {}).update({'gain_per_s': 2.0, 'reach_m': 0.78, 'ref_rate_m_s': 0.09, 'retreat_max_m': 0.4, 'speed_max_m_s': 0.1})
# Fable wrist-force-feedback-v12: sensed native support moment guard.
SPEC.setdefault('wrist_up', {}).update({'full_below_z_m': 0.9, 'max_rad': 0.22, 'min_level_N': 5.0, 'rate_rad_s': 0.25, 'zero_above_z_m': 1.0})
SPEC.setdefault('tip_margin', {}).update({'derate_min': 0.6,
 'derate_per_s': 0.5,
 'front_edge_m': 0.22,
 'headroom_band_N': 15.0,
 'lever_min_m': 0.3,
 'lift_detect_m': 0.0015,
 'lift_full_m': 0.008,
 'moment_budget_N_m': 105.0,
 'recover_per_s': 0.01,
 'ref_drift_m_s': 0.001,
 'ref_drift_rad_s': 0.002,
 'tilt_detect_rad': 0.006,
 'tilt_full_rad': 0.035})
# Fable admittance-v17: bounded forward yielding of the commanded hand reference.
SPEC.setdefault('yield_admittance', {}).update({'bite_m': 0.006,
 'cap_recover_m_s': 0.003,
 'com_max_m': 0.02,
 'comp_deadband_m': 0.004,
 'comp_span_m': 0.006,
 'dwell_s': 0.25,
 'err_max_m': 0.03,
 'gap_back_m': 0.07,
 'gap_stop_m': 0.06,
 'idle_fraction': 0.5,
 'max_m': 0.04,
 'min_level_N': 5.0,
 'rate_m_s': 0.02,
 'return_m_s': 0.03,
 'v_back_max_m_s': 0.03,
 'v_fwd_max_m_s': 0.08})
# Fable tracking-v19: bounded vertical lag compensation and measured receding-chest following.
SPEC['episode_seconds'] = 80.0
SPEC['assist_window_s'] = 56.0
SPEC.setdefault('deadlines_s', {}).update({'assist_to_stand': 56.5})
SPEC.setdefault('lag_tracking', {}).update({'gap_full_m': 0.065,
 'gap_warn_m': 0.045,
 'lag_gain_per_s': 2.0,
 'lag_max_m': 0.035,
 'lag_wind_m_s': 0.05,
 'press_follow_max_m': 0.07,
 'pull_gain': 0.75,
 'pull_max_m': 0.03,
 'recede_max_m': 0.04,
 'recede_s': 0.45,
 'recontact_m_s': 0.05,
 'ref_lead_max_m': 0.04,
 'ref_offset_max_m': 0.065,
 'reverse_v_m_s': 0.03,
 'settle_m': 0.015,
 'standoff_max_m': 0.04,
 'threat_rate_per_s': 4.0,
 'unwind_gain_per_s': 4.0,
 'unwind_m_s': 0.15})
OK = ('completed', 'executed_unverified')
GOAL_Q = np.array(SPEC['grasp_orientation_xyzw'], float)
TORSO0 = np.array(SPEC['seated_torso_m'], float)
SAFE, FB, TRK, BODY = SPEC['safe_force_N'], SPEC['support_feedback'], SPEC['contact_tracking'], SPEC['anthropometric_model']
ALIGN = SPEC['support_alignment']
LOCAL = {a: np.array(SPEC['support_targets_world_m'][a], float) - TORSO0 for a in ARMS}


def _toward(p, goal, step):
    d = np.asarray(goal, float) - p
    return p + d * min(1.0, step / max(float(np.linalg.norm(d)), 1e-9))


def _quat_step(q, goal, max_rad):
    g = goal if float(np.dot(q, goal)) >= 0.0 else -goal
    ang = 2.0 * math.acos(min(1.0, float(np.dot(q, g))))
    out = g if ang <= max(max_rad, 1e-6) else q + (g - q) * (max_rad / ang)
    return out / np.linalg.norm(out)


def _pitched(pitch):
    # GOAL_Q (palm +X toward world -X, +Z up) pitched so the fingertips rise by `pitch` radians.
    return np.array([math.sin(0.5 * pitch), 0.0, math.cos(0.5 * pitch), 0.0])


def _rodrigues(axis, angle):
    n = float(np.linalg.norm(axis))
    if n < 1e-9 or abs(angle) < 1e-9:
        return np.eye(3)
    k = axis / n
    K = np.array([[0.0, -k[2], k[1]], [k[2], 0.0, -k[0]], [-k[1], k[0], 0.0]])
    return np.eye(3) + math.sin(angle) * K + (1.0 - math.cos(angle)) * (K @ K)


def _quat_matrix(q):
    x, y, z, w = [float(v) for v in q]
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def _knee_forward(xa, za, xh, zh):
    # Forward coordinate of the knee from ankle and hip (two-link leg, knee-forward solution).
    l1, l2 = BODY['shin_m'], BODY['thigh_m']
    dx, dz = xh - xa, zh - za
    dist = max(math.hypot(dx, dz), 1e-6)
    ux, uz = dx / dist, dz / dist
    if dist >= l1 + l2 - 1e-4 or dist <= abs(l1 - l2) + 1e-4:
        return xa + l1 * ux
    x0 = (l1 * l1 - l2 * l2 + dist * dist) / (2.0 * dist)
    y0 = math.sqrt(max(l1 * l1 - x0 * x0, 0.0))
    return max(xa + x0 * ux + y0 * uz, xa + x0 * ux - y0 * uz)


class Controller:
    def __init__(self, plan):
        self.plan = list(SPEC['plans'].get(plan, [plan]) if isinstance(plan, str) else plan)
        self.steps = [{'action': a, 'start': None, 'end': None, 'status': 'pending', 'ran': False} for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, 0.0, not self.plan
        self.sensors, self.at_dock, self.mode, self.stage = False, False, None, 0
        self.tgt, self.quat, self.level, self.dwell, self.last_t = {}, {}, 0.0, 0.0, None
        self.force, self.contact = {a: 0.0 for a in ARMS}, {a: False for a in ARMS}
        self.v, self.stand, self.events = [0.0, 0.0], False, []
        elevation = SPEC['assist_direction_elevation_rad']
        self.dir = np.array([math.cos(elevation), 0.0, math.sin(elevation)])   # common default: toward the robot (+X) and up
        self.el = {a: float(elevation) for a in ARMS}                           # sensed plan: per-hand aligned elevation
        self.dirv = {a: self.dir.copy() for a in ARMS}
        self.sagc = {a: 0.0 for a in ARMS}
        self.phase, self.timer, self.hold_xy, self.seat_z, self.torso0 = 'support', 0.0, None, None, TORSO0.copy()
        self.depth, self.lower = {a: 0.0 for a in ARMS}, {a: 0.0 for a in ARMS}
        self.touch, self.lost_t, self.fast_until = {a: False for a in ARMS}, {a: -10.0 for a in ARMS}, {a: -10.0 for a in ARMS}
        self.boost, self.wait_s, self.lifted, self.unstable, self.assist_init, self.diag = 0.0, 0.0, False, False, False, {}

    def update(self, t, obs):
        dt = 0.0 if self.last_t is None else min(max(t - self.last_t, 0.0), 0.1)
        self.last_t, self.events, self.v, self.stand, req = t, [], [0.0, 0.0], False, {a: 0.0 for a in ARMS}
        if not self.done:
            step, name = self.steps[self.action_index], self.plan[self.action_index]
            if t >= SPEC['episode_seconds']:
                res = ('timeout' if step['ran'] else 'not_executed_budget_exhausted', 'episode budget exhausted')
            else:
                if not step['ran']:
                    step.update(start=t, status='running', ran=True)
                    self.action_started_s, self.dwell = t, 0.0
                    self.events.append('start ' + name)
                rel, known = t - self.action_started_s, name in SPEC['deadlines_s']
                res = getattr(self, '_' + name)(obs, rel, dt, req) if known else ('failed', 'unknown action name')
                res = res or (('timeout', 'deadline reached without completion') if rel >= SPEC['deadlines_s'][name] else None)
            if res:
                if res[0] not in OK:  # failure: every request is removed in this same update
                    req, self.v, self.stand = {a: 0.0 for a in ARMS}, [0.0, 0.0], False
                    self.level, self.force = 0.0, {a: 0.0 for a in ARMS}
                self._finish(t, res[0], res[1])
        hands = {a: {'position_m': self.tgt[a].tolist(), 'orientation_xyzw': self.quat[a].tolist()} for a in self.tgt}
        forces = {a: (self.dirv[a] * float(min(max(req[a], 0.0), SPEC['engine_force_cap_N']))).tolist() for a in ARMS}
        return {'base_velocity_world_xy': [float(self.v[0]), float(self.v[1])], 'final_heading_rad': math.pi,
                'hand_targets_world': hands, 'gripper_open': {a: True for a in ARMS},
                'head_target_rad': list(SPEC['head_target_rad']), 'sensors_enabled': self.sensors,
                'support_forces_world_N': forces, 'human_stand_attempt': self.stand, 'events': self.events,
                'assist_state': dict(self.diag, phase=self.phase, level_N=float(self.level), boost=float(self.boost),
                                     lifted=bool(self.lifted), unstable=bool(self.unstable),
                                     force_elevation_rad={a: float(self.el[a]) for a in ARMS},
                                     sag_compensation_m={a: float(self.sagc[a]) for a in ARMS})}

    def _finish(self, t, status, note):
        self.steps[self.action_index].update(end=t, status=status)
        self.events.append('%s %s: %s' % (self.plan[self.action_index], status, note))
        rest = [] if status in OK else self.steps[self.action_index + 1:]
        for later in rest:  # never run after a failed dependency; ran stays False
            later['status'] = 'not_executed_dependency_failed'
        self.action_index = self.action_index + 1 if status in OK else len(self.steps)
        self.done = self.action_index >= len(self.steps)

    # ---- base -------------------------------------------------------------------------------------------
    def _navigate_to_bed(self, obs, rel, dt, req):
        p, yaw = obs['robot_position_m'], obs['robot_yaw_rad'] - math.pi
        ex, vmax = p[0] - (SPEC['dock_xy_m'][0] + 0.006), min(SPEC['nav_speed_max_m_s'], 0.05 + 0.5 * rel)
        vx = -1.8 * ex
        if abs(ex) > 0.004:  # keep a small closing speed so the tighter dock band is reached promptly
            vx = math.copysign(max(abs(vx), 0.012), vx)
        self.v = [float(np.clip(vx, -vmax, vmax)), 0.0]  # straight along y=0, never sideways
        slow = float(np.linalg.norm(np.atleast_1d(obs['robot_velocity_m_s'])[:2])) <= 0.03
        if slow and -0.006 <= ex <= 0.008 and abs(p[1]) <= 0.05 and abs(math.atan2(math.sin(yaw), math.cos(yaw))) <= 0.1:
            self.v, self.at_dock = [0.0, 0.0], True
            self.hold_xy = [max(float(p[0]), SPEC['base_min_x_m']), float(p[1])]
            return 'completed', 'docked at x=%.3f m' % p[0]

    def _hold_base(self, obs):
        # Position hold at the dock (velocity commands only); the base never moves closer than base_min_x.
        if self.hold_xy is None:
            return
        p, cfg, v = obs['robot_position_m'], SPEC['base_hold'], []
        for i in (0, 1):
            e = self.hold_xy[i] - float(p[i])
            v.append(0.0 if abs(e) < cfg['deadband_m'] else float(np.clip(cfg['gain_per_s'] * e, -cfg['speed_max_m_s'], cfg['speed_max_m_s'])))
        self.v = v

    # ---- sensing ----------------------------------------------------------------------------------------
    def _activate_sensors(self, obs, rel, dt, req):
        self.sensors = True  # latched; posture stays NULL until the runner sees this flag
        self._hold_base(obs)
        return ('completed', 'posture stream live') if obs.get('human_posture') is not None else None

    def _assess_posture(self, obs, rel, dt, req):
        self._hold_base(obs)
        hp = obs.get('human_posture')
        if hp is None:
            return 'failed', 'no posture data'
        torso = np.asarray(hp['torso_position_m'], float)
        off = float(np.linalg.norm(torso - TORSO0))
        calm = float(np.linalg.norm(hp['torso_velocity_m_s'])) <= 0.2 and abs(hp['torso_tilt_deg']) <= 25.0
        self.dwell = self.dwell + dt if (calm and off <= 0.15 and not hp['standing']) else 0.0
        if self.dwell >= 0.4:
            est = self._estimate(obs, hp)
            self.seat_z, self.torso0 = float(hp['pelvis_position_m'][2]), torso.copy()
            return 'completed', 'seated; torso offset %.2f m, tilt %.0f deg, CoM %.2f m behind the ankles' % (
                off, hp['torso_tilt_deg'], -est['xc'])

    def _estimate(self, obs, hp):
        '''Chest support points and whole-body CoM from the posture stream and the nominal body model.'''
        T = np.asarray(hp['torso_position_m'], float)
        P = np.asarray(hp['pelvis_position_m'], float)
        F = np.asarray(hp.get('support_center_m') or [P[0] + 0.47, P[1], 0.075], float)
        rp = np.asarray(obs['robot_position_m'], float)
        e = np.array([rp[0] - F[0], rp[1] - F[1], 0.0])
        n = float(np.linalg.norm(e))
        e = e / n if n > 0.1 else np.array([1.0, 0.0, 0.0])
        left = np.array([-e[1], e[0], 0.0])
        tilt = math.radians(float(hp['torso_tilt_deg']))
        q = hp.get('torso_orientation_xyzw')   # optional adapter field; the tilt/offset fallback is used otherwise
        if q is not None:
            Rm = _quat_matrix(q)
        else:
            d = np.array([T[0] - P[0], T[1] - P[1], 0.0])
            dn = float(np.linalg.norm(d))
            u = d / dn if (dn > 0.02 and tilt > math.radians(3.0)) else e
            Rm = _rodrigues(np.array([-u[1], u[0], 0.0]), tilt)
        up, nrm = Rm @ np.array([0.0, 0.0, 1.0]), Rm @ np.array([1.0, 0.0, 0.0])
        S = {a: T + Rm @ LOCAL[a] for a in ARMS}
        m = BODY['mass_kg']
        xf = float(F @ e)
        xa, za = xf - BODY['ankle_behind_foot_centre_m'], float(F[2]) + BODY['ankle_above_foot_centre_m']
        xh, zh = float(P @ e), float(P[2]) - BODY['hip_below_pelvis_centre_m']
        xk = _knee_forward(xa, za, xh, zh)
        xt = float((T + BODY['trunk_com_above_torso_centre_m'] * up) @ e)
        total = sum(m.values())
        com = (m['feet'] * xf + m['shins'] * 0.5 * (xa + xk) + m['thighs'] * 0.5 * (xh + xk)
               + m['pelvis'] * float(P @ e) + m['trunk_head_arms'] * xt) / total
        floor = float(F[2]) - BODY['foot_centre_above_floor_m']
        h = max(0.5, float(np.mean([S[a][2] for a in ARMS])) - floor)
        v = np.asarray(hp['torso_velocity_m_s'], float)
        self.diag = {'com_forward_of_ankle_m': float(com - xa), 'support_height_m': float(h)}
        return {'S': S, 'nrm': nrm, 'up': up, 'torso': T, 'xc': float(com - xa), 'h': h, 'v_fwd': float(v @ e),
                'speed': float(np.linalg.norm(v)), 'lateral': abs(float((T - self.torso0) @ left))}

    def _align(self, obs, est, dt):
        '''Sensed plan: force line from each chest support point through that hand's measured wrist (bounded), plus
        the native tip-moment bookkeeping (lever per hand, per-hand force limit, sensed base lift/tilt guard).'''
        G = type(self).update.__globals__
        spec = G['SPEC']
        AL, arms, quat_matrix = spec['support_alignment'], G['ARMS'], G['_quat_matrix']
        TM = spec.get('tip_margin') or {}
        step = AL['rate_rad_s'] * dt
        az = self.__dict__.setdefault('az', {a: 0.0 for a in arms})
        az_max = float(AL.get('azimuth_max_rad', 0.15))
        hp = obs.get('human_posture') or {}
        pts = hp.get('support_points_world_m') or {}
        rp = obs.get('robot_position_m')
        base_x = float(rp[0]) if rp is not None else None
        front = float(TM.get('front_edge_m', 0.22))
        lever_min = float(TM.get('lever_min_m', 0.30))
        lever = {}
        for a in arms:
            h = obs['hands'][a]
            S = np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)
            wrist = h.get('wrist_position_m')
            if wrist is None:
                back = -(quat_matrix(h['orientation_xyzw']) @ np.array([1.0, 0.0, 0.0]))
                if float(back[0]) < 0.5:
                    back = np.array([1.0, 0.0, 0.0])
                wrist = np.asarray(h['position_m'], float) + AL['wrist_behind_palm_m'] * back
            w = np.asarray(wrist, float) - S
            fwd = max(float(w[0]), 0.05)
            hor = max(math.hypot(fwd, float(w[1])), 0.05)
            want_el = min(max(math.atan2(float(w[2]), hor), AL['elevation_min_rad']), AL['elevation_max_rad'])
            want_az = min(max(math.atan2(float(w[1]), fwd), -az_max), az_max)
            self.el[a] += min(step, max(-step, want_el - self.el[a]))
            az[a] += min(step, max(-step, want_az - az[a]))
            c = math.cos(self.el[a])
            self.dirv[a] = np.array([c * math.cos(az[a]), c * math.sin(az[a]), math.sin(self.el[a])])
            # Lever of this hand's force line about the base's forward support edge (floor at z = 0).
            b = 0.0 if base_x is None else max(abs(base_x - float(S[0])) - front, 0.0)
            lever[a] = max(float(S[2]) * c + b * math.sin(self.el[a]), lever_min)
        tip = self.__dict__.setdefault('tip', {})
        # Sensed base lift / tilt over slowly drifting references (references follow down at once, up only slowly).
        lift, tilt = 0.0, 0.0
        if rp is not None and len(rp) >= 3:
            z = float(rp[2])
            zr = tip.get('z_ref')
            zr = z if zr is None else min(z, zr + float(TM.get('ref_drift_m_s', 0.001)) * dt)
            tip['z_ref'] = zr
            lift = z - zr
        q = obs.get('robot_orientation_xyzw')
        if q is not None and len(q) >= 4:
            qq = np.asarray(q, float)
            n = float(np.linalg.norm(qq))
            if n > 1e-6:
                x, y = float(qq[0]) / n, float(qq[1]) / n
                ang = math.acos(max(-1.0, min(1.0, 1.0 - 2.0 * (x * x + y * y))))
                ar = tip.get('tilt_ref')
                ar = ang if ar is None else min(ang, ar + float(TM.get('ref_drift_rad_s', 0.002)) * dt)
                tip['tilt_ref'] = ar
                tilt = ang - ar
        l0, l1 = float(TM.get('lift_detect_m', 0.0015)), float(TM.get('lift_full_m', 0.008))
        t0, t1 = float(TM.get('tilt_detect_rad', 0.006)), float(TM.get('tilt_full_rad', 0.035))
        guard = max((lift - l0) / max(l1 - l0, 1e-6), (tilt - t0) / max(t1 - t0, 1e-6))
        guard = min(1.0, max(0.0, guard))
        # Learned derate of the budget while tilt is sensed; very slow recovery so the same threshold is not retried.
        scale = float(tip.get('scale', 1.0))
        if guard > 0.0:
            scale = max(float(TM.get('derate_min', 0.6)), scale - float(TM.get('derate_per_s', 0.5)) * guard * dt)
        else:
            scale = min(1.0, scale + float(TM.get('recover_per_s', 0.01)) * dt)
        budget = float(TM.get('moment_budget_N_m', 105.0)) * scale
        total = sum(lever.values())
        f = getattr(self, 'force', None)
        used = sum(float(f[a]) * lever[a] for a in arms) if isinstance(f, dict) else float(getattr(self, 'level', 0.0)) * total
        tip.update(guard=guard, scale=scale, lever=lever, lift_m=float(lift), tilt_rad=float(tilt),
                   limit_N=float(budget / max(total, 1e-6)), moment_N_m=float(used), budget_N_m=float(budget))

    # ---- hands ------------------------------------------------------------------------------------------
    def _approach(self, obs, est, dt):
        key, speed = SPEC['extension_stages'][self.stage]
        step, arrived = min(speed, SPEC['hand_speed_max_m_s']) * dt, True
        nrm = est['nrm'] if est is not None else np.array([1.0, 0.0, 0.0])
        for a in ARMS:
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            if self.stage == 0:
                goal = np.array(SPEC[key][a], float)
                if est is not None:  # sensed plan only: follow a shifted seated torso
                    goal = goal + np.clip(est['torso'] - TORSO0, -0.10, 0.10)
            else:
                base = est['S'][a] if est is not None else np.array(SPEC[key][a], float)
                goal = base - TRK['approach_depth_m'] * nrm
            err = float(h.get('tracking_error_m') or 0.0)
            blocked = err > SPEC['tracking_pause_m'] or h.get('ik_reachable') is False
            touching = bool(h.get('contact_human'))
            if not touching:
                self.touch[a] = False
            if touching:
                if not self.touch[a]:  # first touch: hold at the measured contact pose, never press on
                    self.touch[a], self.tgt[a] = True, pos - 0.003 * nrm
                elif est is not None and h.get('support_force_gate') is False:
                    d = goal - self.tgt[a]   # touching away from the support point: slide along the chest only
                    d = d - float(d @ nrm) * nrm
                    self.tgt[a] = self.tgt[a] + d * min(1.0, 0.03 * dt / max(float(np.linalg.norm(d)), 1e-9))
            elif not blocked:
                self.tgt[a] = _toward(self.tgt[a], goal, step)
                # Native TIAGo cannot fully rotate its wrist while still close to the tucked pose:
                # synchronise orientation with extension; the angular rate cap continues to apply.
                orientation = GOAL_Q
                if self.stage == 0:
                    distance = float(np.linalg.norm(goal - self.start_tgt[a]))
                    progress = float(np.clip(1.0 - np.linalg.norm(goal - self.tgt[a]) / max(distance, 1e-9), 0.0, 1.0))
                    start = self.start_quat[a]
                    end = GOAL_Q if float(np.dot(start, GOAL_Q)) >= 0.0 else -GOAL_Q
                    orientation = (1.0 - progress) * start + progress * end
                    orientation = orientation / np.linalg.norm(orientation)
                self.quat[a] = _quat_step(self.quat[a], orientation, SPEC['hand_turn_max_rad_s'] * dt)
            arrived = (arrived and err <= 0.04 and float(np.linalg.norm(self.tgt[a] - goal)) < 1e-3
                       and abs(float(np.dot(self.quat[a], GOAL_Q))) > 0.999)
        return arrived

    def _track(self, obs, est, hp, dt, clearance):
        '''Sensed plan: hands follow the measured chest points; base backs away (unchanged).
        v18 reference repair:
          - the palm reference is the ACTUAL chest point (minus depth/lower); feedforward and yield are an intentional
            lead and are never integrated;
          - the only integral term is the measured vertical lag of the palm below that reference (the logged sag is
            world-vertical), applied vertically, bounded, frozen while the reference is saturated or still travelling,
            and unwound quickly when the palm is measured above the reference or the chest is measured sinking;
          - lead <= 0.04 m (feedforward shrinks first), lag compensation <= 0.035 m, whole offset from the actual chest
            point <= 0.065 m (< 0.08 m gate);
          - contact threat (gap near the gate, or contact lost): lead toward the palm side is removed and the reference
            is pulled back toward the chest reference (bounded);
          - the never-press bound relative to the measured palm is widened by a bounded amount only while the chest is
            measured receding along its normal or while no contact is observed, so the palm can follow a straightening
            torso; otherwise it is the original bound;
          - every target update is finally limited to hand_speed_max (no teleports).
        Forward-yield admittance, IK yielding, wrist pitch and base follow are the v17 code.'''
        G = type(self).update.__globals__
        spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
        T = spec['contact_tracking']
        WU = spec.get('wrist_up') or {}
        A = spec.get('yield_admittance') or {}
        LT = spec.get('lag_tracking') or {}
        nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
        pts = hp.get('support_points_world_m') or {}
        S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
        vel = np.asarray(hp['torso_velocity_m_s'], float)
        ff = vel * T['feedforward_s']
        n = float(np.linalg.norm(ff))
        if n > T['feedforward_max_m']:
            ff = ff * (T['feedforward_max_m'] / n)
        v_hand = float(spec['hand_speed_max_m_s'])
        step = v_hand * dt
        turn = spec['hand_turn_max_rad_s'] * dt
        press_max = float(T.get('press_lead_max_m', 0.03))
        lead_max = float(T.get('tangent_lead_max_m', 0.08))
        hard = float(T.get('hard_pause_m', 0.14))
        freeze = float(T.get('comp_freeze_error_m', 0.10))
        yield_max = float(T.get('orientation_yield_max_rad', 0.20))
        back_scale = float(T.get('orientation_return_scale', 0.25))
        wu_max = float(WU.get('max_rad', 0.22))
        wu_rate = min(float(WU.get('rate_rad_s', 0.25)), float(spec['hand_turn_max_rad_s'])) * dt
        z_full, z_zero = float(WU.get('full_below_z_m', 0.90)), float(WU.get('zero_above_z_m', 1.00))
        lvl_min = float(WU.get('min_level_N', 5.0))
        # Forward-yield admittance parameters (v17, hard-clamped to the stated bounds whatever the spec says).
        a_max = min(max(float(A.get('max_m', 0.04)), 0.0), 0.04)
        a_rate = min(max(float(A.get('rate_m_s', 0.02)), 0.0), 0.02)
        a_back = min(max(float(A.get('return_m_s', 0.03)), 0.0), v_hand)
        idle = min(1.0, max(0.0, float(A.get('idle_fraction', 0.5))))
        c0, c_span = float(A.get('comp_deadband_m', 0.004)), max(float(A.get('comp_span_m', 0.006)), 1e-4)
        a_err, dwell = float(A.get('err_max_m', 0.03)), float(A.get('dwell_s', 0.25))
        g_stop, g_back = float(A.get('gap_stop_m', 0.06)), float(A.get('gap_back_m', 0.07))
        bite, cap_rate = float(A.get('bite_m', 0.006)), float(A.get('cap_recover_m_s', 0.003))
        com_max, lvl_y = float(A.get('com_max_m', 0.02)), float(A.get('min_level_N', 5.0))
        v_fwd, v_back = float(A.get('v_fwd_max_m_s', 0.08)), float(A.get('v_back_max_m_s', 0.03))
        # v18 lag-tracking parameters (hard-clamped below the unchanged 0.08 m gate whatever the spec says).
        lead_cap = min(max(float(LT.get('ref_lead_max_m', 0.04)), 0.0), 0.04)
        lag_cap = min(max(float(LT.get('lag_max_m', 0.035)), 0.0), 0.04)
        off_cap = min(max(float(LT.get('ref_offset_max_m', 0.065)), lead_cap), 0.07)
        k_up = max(float(LT.get('lag_gain_per_s', 2.0)), 0.0)
        wind = max(float(LT.get('lag_wind_m_s', 0.05)), 0.0)
        k_dn = max(float(LT.get('unwind_gain_per_s', 4.0)), 0.0)
        un_max = min(max(float(LT.get('unwind_m_s', 0.15)), 0.0), v_hand)
        v_rev = max(float(LT.get('reverse_v_m_s', 0.03)), 0.0)
        settle = max(float(LT.get('settle_m', 0.015)), 0.0)
        g_warn = float(LT.get('gap_warn_m', 0.045))
        g_span = max(float(LT.get('gap_full_m', 0.065)) - g_warn, 1e-3)
        thr_rate = max(float(LT.get('threat_rate_per_s', 4.0)), 0.0)
        k_pull = min(max(float(LT.get('pull_gain', 0.75)), 0.0), 1.0)
        pull_max = min(max(float(LT.get('pull_max_m', 0.03)), 0.0), 0.04)
        rec_s = max(float(LT.get('recede_s', 0.45)), 0.0)
        rec_max = min(max(float(LT.get('recede_max_m', 0.04)), 0.0), 0.05)
        so_max = min(max(float(LT.get('standoff_max_m', 0.04)), 0.0), 0.05)
        follow_extra = max(0.0, min(float(LT.get('press_follow_max_m', 0.07)), 0.08) - press_max)
        creep_in = float(T['creep_in_m_s'])
        recontact = min(max(float(LT.get('recontact_m_s', 0.05)), creep_in), v_hand)
        zup = np.array([0.0, 0.0, 1.0])
        vz, vn = float(vel[2]), float(vel @ nrm)
        out = np.array([1.0, 0.0, 0.0])
        tip = self.__dict__.get('tip') or {}
        guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
        head = float(tip.get('headroom', 0.0)) * (1.0 - guard)
        wp = self.__dict__.setdefault('wpitch', {})
        yld = self.__dict__.setdefault('yld', {a: {'x': 0.0, 't': 0.0, 'cap': a_max, 'was': False} for a in arms})
        lt = self.__dict__.setdefault('lagt', {})
        xc, vf = float(est['xc']), float(est['v_fwd'])
        unstable = bool(getattr(self, 'unstable', False))
        # Yield for the person only while support is requested, the CoM is not yet over the feet and the chest is slow.
        calm = xc < com_max and -v_back < vf < v_fwd and self.level >= lvl_y
        # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
        easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and xc >= 0.0
        live = clearance <= 0.0 and not easy
        info = {}
        for a in arms:
            st = lt.setdefault(a, {'pend': 0.0, 'sat': False, 'extra': 0.0, 'nc': 0.0})
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            err = float(h.get('tracking_error_m') or 0.0)
            touching = bool(h.get('contact_human'))
            reach = h.get('ik_reachable') is not False
            press = -float((self.tgt[a] - pos) @ nrm)
            y = yld[a]
            gap = float(np.linalg.norm(pos - S[a]))
            comp = float((pos - self.tgt[a]) @ out)   # measured palm pushed toward the robot relative to its command
            if clearance > 0.0 or easy:               # release / weight over feet: hold the yield, original back-off acts
                y['t'], y['was'] = 0.0, False
            elif (not touching) or unstable or gap > g_back:
                if y['was'] and not unstable:         # remember where contact ended; do not re-probe past it at once
                    y['cap'] = max(0.0, y['x'] - bite)
                y['t'], y['was'] = 0.0, False
                y['x'] = max(0.0, y['x'] - a_back * dt)
            elif reach and err <= a_err and gap <= g_stop:
                y['t'], y['was'] = y['t'] + dt, True
                y['cap'] = min(a_max, y['cap'] + cap_rate * dt)
                if y['t'] >= dwell:
                    push = max(guard, min(1.0, max(0.0, comp - c0) / c_span) if calm else 0.0)
                    if push > 0.0:                    # measured compression or sensed base tilt: yield toward the robot
                        y['x'] = min(a_max, y['x'] + a_rate * push * dt)
                        y['cap'] = max(y['cap'], y['x'])
                    elif calm and y['x'] < y['cap']:  # slow contact-gated creep up to the learned contact boundary
                        y['x'] = min(y['cap'], y['x'] + a_rate * idle * dt)
            else:
                y['t'] = 0.0                          # IK / tracking / gap not healthy: freeze (anti-windup)
            if clearance > 0.0:
                self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
            elif easy:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            elif not touching:
                if y['x'] <= 1e-4 or self.depth[a] < 0.0:   # withdraw the yield first, then the creep-in
                    # a stand-off while support is requested is a contact threat: close it faster (same depth bounds)
                    rate = recontact if (self.depth[a] < 0.0 and self.level >= lvl_y and not unstable) else creep_in
                    self.depth[a] = min(T['depth_max_m'], self.depth[a] + rate * dt)
            elif press > T['press_error_m'] + st['extra']:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
                self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
            else:
                self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
            # ---- v18 reference: actual chest point + bounded lead + measured-lag compensation ----
            fixed = min(y['x'], a_max) * out - self.depth[a] * nrm - self.lower[a] * up
            ref = S[a] - self.depth[a] * nrm - self.lower[a] * up   # where the palm itself should be (no lead)
            gv = pos - ref
            gn = float(np.linalg.norm(gv))
            lag_z = -float(gv[2])                                   # > 0: palm measured below the chest reference
            if live and not touching:
                st['nc'] = min(1.0, st['nc'] + thr_rate * dt)
            else:
                st['nc'] = max(0.0, st['nc'] - thr_rate * dt)
            thr = max(st['nc'], min(1.0, max(0.0, (gap - g_warn) / g_span))) if live else 0.0
            c_lag = float(self.sagc[a])
            if clearance > 0.0:
                c_lag = max(0.0, c_lag - T['sag_release_m_s'] * dt)
            elif lag_z < 0.0 or vz < -v_rev:
                # palm measured above the reference, or chest measured sinking: compensation exceeds the real lag
                dec = min(un_max, k_dn * max(0.0, -lag_z))
                if vz < -v_rev:
                    dec = max(dec, min(un_max, -vz))
                c_lag = max(0.0, c_lag - dec * dt)
            elif (not reach) or err > freeze:
                c_lag = max(0.0, c_lag - 0.5 * T['sag_release_m_s'] * dt)
            elif touching and (not unstable) and st['pend'] <= settle and not st['sat']:
                # real lag only: reference settled on its goal, nothing saturated, contact observed
                c_lag = c_lag + min(wind, k_up * lag_z) * dt
            c_lag = min(max(c_lag, 0.0), lag_cap)
            self.sagc[a] = c_lag
            ffa = ff
            if thr > 0.0 and gn > 1e-6:   # contact threat: no lead that carries the reference further to the palm side
                along = float(ff @ gv) / gn
                if along > 0.0:
                    ffa = ff - (thr * along / gn) * gv
            lead = fixed + ffa
            capped = False
            if clearance <= 0.0:
                ln = float(np.linalg.norm(lead))
                if ln > lead_cap:         # bounded intentional lead; feedforward gives way first
                    fn = float(np.linalg.norm(fixed))
                    a2 = float(ffa @ ffa)
                    if fn >= lead_cap:
                        lead = fixed * (lead_cap / max(fn, 1e-9))
                    elif a2 < 1e-12:
                        lead = lead * (lead_cap / ln)
                    else:
                        b = float(fixed @ ffa)
                        s = (-b + math.sqrt(max(b * b - a2 * (fn * fn - lead_cap * lead_cap), 0.0))) / a2
                        lead = fixed + min(1.0, max(0.0, s)) * ffa
            offv = lead + c_lag * zup
            if thr > 0.0 and gn > 1e-6:   # bounded pull of the reference back toward the chest reference
                offv = offv - (min(pull_max, k_pull * thr * gn) / gn) * gv
            if clearance <= 0.0:
                on = float(np.linalg.norm(offv))
                if on > off_cap:
                    offv = offv * (off_cap / on)
                    capped = True
            goal = S[a] + offv
            extra = 0.0
            if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
                self.tgt[a] = toward(self.tgt[a], pos, step)
                capped = True
            else:
                tgt = toward(self.tgt[a], goal, step)
                if clearance <= 0.0:
                    # chest measured receding along its normal, or no contact observed: following is not pressing
                    extra = min(rec_max, rec_s * max(0.0, -vn))
                    if live:
                        extra += st['nc'] * min(so_max, max(0.0, float(gv @ nrm)))
                    extra = min(extra, follow_extra)
                allow = press_max + extra
                off = tgt - pos
                depth_in = -float(off @ nrm)
                if depth_in > allow:       # never press on
                    tgt = tgt + (depth_in - allow) * nrm
                    off = tgt - pos
                tan = off - float(off @ nrm) * nrm
                tn = float(np.linalg.norm(tan))
                if tn > lead_max:          # bounded lead of the reference over the measured palm
                    tgt = tgt - tan * (1.0 - lead_max / tn)
                self.tgt[a] = toward(self.tgt[a], tgt, step)   # final speed limit: no target teleports
            st['pend'] = float(np.linalg.norm(goal - self.tgt[a]))
            st['sat'] = bool(capped)
            st['extra'] = float(extra)
            info[a] = (float(np.linalg.norm(goal - S[a])), float(thr), float(press_max + extra), float(lag_z))
            pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
            # Wrist-up component (negative pitch = wrist above palm): faded out with hand height, scaled by spare native
            # tip margin, released when contact, IK or tracking is not healthy. Scalar starts from the current command.
            fade = min(1.0, max(0.0, (z_zero - float(goal[2])) / max(z_zero - z_full, 1e-3)))
            ok = clearance <= 0.0 and touching and reach and err <= freeze and (not easy) and self.level >= lvl_min
            want = -wu_max * fade * head if ok else 0.0
            if a not in wp:
                q0 = self.quat[a]
                sg = 1.0 if float(q0[2]) >= 0.0 else -1.0
                wp[a] = min(0.0, max(-wu_max, 2.0 * math.atan2(sg * float(q0[0]), sg * float(q0[2]))))
            wp[a] += min(wu_rate, max(-wu_rate, want - wp[a]))
            nominal = pitched(pitch + wp[a])
            if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
                mq = np.asarray(h['orientation_xyzw'], float)
                mn = float(np.linalg.norm(mq))
                if mn > 1e-6:
                    cand = quat_step(self.quat[a], mq / mn, turn)
                    ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                    if ang <= yield_max:
                        self.quat[a] = cand
            else:
                self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
        self.diag = dict(getattr(self, 'diag', None) or {}, yield_forward_m={a: float(yld[a]['x']) for a in arms},
                         yield_cap_m={a: float(yld[a]['cap']) for a in arms},
                         ref_offset_m={a: info[a][0] for a in arms}, contact_threat={a: info[a][1] for a in arms},
                         press_allow_m={a: info[a][2] for a in arms}, palm_lag_z_m={a: info[a][3] for a in arms})
        BF = spec.get('base_follow')
        if BF and self.hold_xy is not None:
            # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
            dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
            sx = float(np.mean([S[a][0] for a in arms]))
            want_x = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
            r = BF['ref_rate_m_s'] * dt
            self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want_x - self.hold_xy[0])))
            ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
            vmax = BF['speed_max_m_s']
            self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]

    # ---- support requests -------------------------------------------------------------------------------
    def _contacts(self, obs, sensed):
        t = self.last_t
        for a in ARMS:
            h, was = obs['hands'][a], self.contact[a]
            self.contact[a] = bool(h.get('contact_human')) and not (sensed and h.get('support_force_gate') is False)
            if self.contact[a] != was:
                self.events.append(a + (' hand support contact' if not was else ' hand contact lost: request removed'))
                if was:
                    self.lost_t[a] = t
                elif t - self.lost_t[a] < 0.6:
                    self.fast_until[a] = t + 1.0
        return self.contact['left'] and self.contact['right']

    def _ramp_level(self, target, dt, up=None, down=None):
        up = SAFE['assist_ramp_N_s'] if up is None else up
        down = SAFE['ramp_max_N_s'] if down is None else down
        self.level += float(np.clip(target - self.level, -down * dt, up * dt))
        self.level = min(max(self.level, 0.0), SAFE['cap'])

    def _apply(self, req, dt, up_rate):
        t = self.last_t
        for a in ARMS:  # a hand without a live gated contact never keeps a request
            if self.contact[a]:
                rate = SAFE['reengage_ramp_N_s'] if t < self.fast_until[a] else up_rate
                self.force[a] = min(self.level, self.force[a] + rate * dt)
            else:
                self.force[a] = 0.0
        low = min(self.force.values())
        for a in ARMS:  # balanced: neither hand may exceed the other by more than the limit
            req[a] = min(self.force[a], low + SAFE['balance_limit_N'])

    def _level_target(self, est, hp, dt):
        '''Original CoM-feedback request, then limited to what the native base can react without tipping.'''
        G = type(self).update.__globals__
        spec = G['SPEC']
        SAFE, FB, BODY = spec['safe_force_N'], spec['support_feedback'], spec['anthropometric_model']
        TM = spec.get('tip_margin') or {}
        tilt, pz = float(hp['torso_tilt_deg']), float(hp['pelvis_position_m'][2])
        if self.seat_z is None:
            self.seat_z = pz
        self.lifted = pz > self.seat_z + (FB['lift_clear_m'] if self.lifted else FB['lift_detect_m'])
        xc = float(est['xc'])
        span = max(float(FB.get('sustain_span_m', 0.08)), 1e-3)
        # 1 while the sensed CoM is well behind the heel, 0 once it is over the foot.
        behind = min(1.0, max(0.0, (float(FB.get('sustain_zero_com_m', 0.02)) - xc) / span))
        need = max(0.0, FB['com_reference_from_ankle_m'] - xc)
        # Forward-velocity damping only acts once the CoM is over the feet; before that forward motion is the goal.
        damp = FB['velocity_damping_N_s_m'] * max(0.0, float(est['v_fwd'])) * (1.0 - behind)
        fx = BODY['weight_N'] * need / est['h'] * (1.0 + self.boost) - damp
        arms = G['ARMS']
        dir_x = max(0.5, sum(float(self.dirv[a][0]) for a in arms) / len(arms))
        feedback = min(max(fx / (2.0 * dir_x), 0.0), SAFE['cap'])
        lo, hi = FB['lean_gate_deg']
        lean = min(1.0, max(0.0, (tilt - lo) / (hi - lo)))
        w = 1.0 if self.lifted else lean
        target = SAFE['start'] + (feedback - SAFE['start']) * w
        # Bounded sustaining minimum: gated on the person's own lean and on the CoM still being behind the heel.
        floor = min(float(SAFE['cap']), float(FB.get('sustain_N', 80.0))) * lean * behind
        target = min(max(target, floor), SAFE['cap'])
        # Native tip margin: per-hand limit from the moment budget (computed in _align), scaled down by sensed base tilt.
        tip = self.__dict__.setdefault('tip', {})
        guard = float(tip.get('guard', 0.0))
        limit = max(0.0, float(tip.get('limit_N', SAFE['cap'])) * (1.0 - guard))
        band = max(float(TM.get('headroom_band_N', 15.0)), 1e-3)
        tip['headroom'] = min(1.0, max(0.0, (limit - target) / band))   # spare margin -> wrist-up allowed in _track
        wanted = float(target)
        target = min(target, limit)
        if guard > 0.0 and self.level > target:   # sensed base tilt: withdraw the request quickly (downward only)
            self.level = max(target, self.level - FB['abort_ramp_N_s'] * dt)
        tilted = guard > 0.0
        if tilted != bool(tip.get('tilted', False)):
            self.events.append('native base tilt sensed: support request reduced' if tilted
                               else 'native base settled: support request limit restored')
        tip['tilted'] = tilted
        waiting = (not self.lifted) and tilt >= hi
        self.wait_s = self.wait_s + dt if waiting else 0.0
        if waiting and self.wait_s > FB['boost_delay_s']:
            self.boost = min(FB['boost_max'], self.boost + FB['boost_rate_per_s'] * dt)
        elif (not waiting) and ((not self.lifted) or xc >= float(FB.get('transfer_com_m', -0.02))):
            # the learned boost decays only when seated upright again or once weight transfer is sensed
            self.boost = max(0.0, self.boost - FB['boost_rate_per_s'] * dt)
        unstable = (tilt > FB['abort_tilt_deg'] or est['speed'] > FB['abort_speed_m_s'] or est['lateral'] > FB['abort_lateral_m'])
        if unstable != self.unstable:
            self.events.append('instability sign: support request withdrawn' if unstable else 'posture calm: support request resumes')
        self.unstable = unstable
        wp = self.__dict__.get('wpitch') or {}
        self.diag = dict(self.diag, sustain_floor_N=float(floor), com_behind_gate=float(behind),
                         tip_limit_N=float(limit), tip_wanted_N=wanted, tip_guard=guard,
                         tip_moment_N_m=float(tip.get('moment_N_m', 0.0)), tip_budget_N_m=float(tip.get('budget_N_m', 0.0)),
                         tip_headroom=float(tip['headroom']), wrist_up_rad={a: float(-wp.get(a, 0.0)) for a in arms})
        return 0.0 if unstable else float(target)

    # ---- arm extension ----------------------------------------------------------------------------------
    def _extend(self, obs, rel, dt, req):
        if not self.at_dock:
            return 'failed', 'dependency navigate_to_bed not completed'
        if not self.tgt:  # first tick: start from the measured current hand pose
            self.mode = 'uneven' if 'uneven' in self.plan[self.action_index] else 'gradual'
            self.tgt = {a: np.array(obs['hands'][a]['position_m'], float) for a in ARMS}
            self.quat = {a: np.array(obs['hands'][a]['orientation_xyzw'], float) for a in ARMS}
            self.start_tgt = {a: p.copy() for a, p in self.tgt.items()}
            self.start_quat = {a: q.copy() for a, q in self.quat.items()}
        self._hold_base(obs)
        sensed = self.sensors and self.mode == 'gradual'
        hp = obs.get('human_posture') if sensed else None
        est = self._estimate(obs, hp) if hp is not None else None
        if self._approach(obs, est, dt) and self.stage == 0:
            self.stage = 1
            self.events.append('both hands at pre-contact; slow final approach')
        both = self._contacts(obs, sensed)
        if self.mode == 'gradual':
            if est is not None:
                self._align(obs, est, dt)
            self._ramp_level(SAFE['start'] if both else 0.0, dt, up=SAFE['extend_ramp_N_s'])
            self._apply(req, dt, SAFE['extend_ramp_N_s'])
            ready = both and min(self.force.values()) >= SAFE['start'] - 0.1
        else:
            for a in ARMS:
                req[a] = SPEC['unsafe_force_N'][a] if self.contact[a] else 0.0
            self.dwell = self.dwell + dt if both else 0.0
            ready = self.dwell >= 0.3
        return ('completed', 'both hands in live contact; %s force request active' % self.mode) if ready else None
    _extend_arm_gradual_force = _extend_arm_uneven_force = _extend

    # ---- assistance -------------------------------------------------------------------------------------
    def _assist_to_stand(self, obs, rel, dt, req):
        if self.mode is None:
            return 'failed', 'dependency arm extension not executed'
        hp = obs.get('human_posture') if self.sensors else None
        standing = bool(hp and hp.get('standing'))
        window = SPEC['assist_window_s']
        if rel >= window:  # shared window; requests end inside this action
            # A momentary standing observation cannot replace taper, release,
            # and the original zero-support verification phase.
            status = 'executed_unverified' if hp is None else 'failed'
            return status, 'window ended before complete release verification; standing sensed=%s' % (None if hp is None else standing)
        self.stand = True  # same stand cue to the same human controller, whatever the plan
        self._hold_base(obs)
        if self.mode != 'gradual' or hp is None:  # unsensed plan: original static hands, fixed direction, uneven open-loop requests
            self._contacts(obs, False)
            for a in ARMS:
                req[a] = SPEC['unsafe_force_N'][a] if self.contact[a] else 0.0
            return None
        est = self._estimate(obs, hp)
        self._align(obs, est, dt)
        if not self.assist_init:
            self.assist_init = True
            for a in ARMS:  # start the contact-depth state from the measured hand, no target jump
                gap = np.asarray(obs['hands'][a]['position_m'], float) - est['S'][a]
                self.depth[a] = float(np.clip(-float(gap @ est['nrm']), TRK['depth_min_m'], TRK['depth_max_m']))
        self._contacts(obs, True)
        if self.phase == 'support':
            self._track(obs, est, hp, dt, 0.0)
            closing = rel > window - FB['closing_taper_s']
            target = self._level_target(est, hp, dt)
            self._ramp_level(0.0 if closing else target, dt, down=FB['abort_ramp_N_s'] if self.unstable else None)
            if standing:
                self.phase = 'taper'
                self.events.append('standing sensed; tapering support')
        elif self.phase == 'taper':
            self._track(obs, est, hp, dt, 0.0)
            self._ramp_level(0.0, dt, down=FB['taper_N_s'])
            if not standing:
                self.phase = 'support'
            elif self.level <= 0.5 and max(self.force.values()) <= 0.5:
                self.phase, self.timer = 'release', 0.0
                self.events.append('support request is zero; releasing hands')
        elif self.phase == 'release':
            self.level = 0.0
            self._track(obs, est, hp, dt, TRK['release_clearance_m'])
            self.timer += dt
            if not standing:
                self.phase = 'support'
            elif self.timer >= FB['release_s']:
                self.phase, self.dwell = 'verify', 0.0
        else:  # verify
            self.level = 0.0
            self._track(obs, est, hp, dt, TRK['release_clearance_m'])
            if not standing:
                self.phase = 'support'
                self.events.append('standing lost during verification; support resumes')
            else:
                self.dwell += dt
                if self.dwell >= FB['verify_s']:
                    return 'completed', 'standing sensed for %.1f s with zero support request' % self.dwell
        self._apply(req, dt, SAFE['assist_ramp_N_s'])


IK_LIMITS = {'orientation_tolerance_rad': 0.26, 'exact_orientation_rad': 0.035, 'position_tolerance_m': 0.004, 'joint_step_max_rad': 0.3, 'limit_margin_rad': 0.06, 'recent_contact_s': 0.5, 'seed_match_rad': 0.5}

def constrained_native_ik(ep, arm, target, seed):
    '''Branch-continuous IK. Returns [q], [] (hold the previous joint goal) or None (use the original backend).

    A solution is accepted only if every joint is within joint_step_max_rad of the continuity reference (previous
    joint goal when it matches the measured arm, else the measured arm), position error < 4 mm, orientation error
    <= 0.035 rad (exact) or <= orientation_tolerance_rad (relaxed), and the original native self-collision validator
    passes at the path midpoint and at the endpoint. There are no random restarts, so no elbow-branch flips.
    While the hand has touched the person within recent_contact_s, a missing continuous solution returns [].
    '''
    C = IK_LIMITS
    try:
        from scipy.optimize import least_squares
        from scipy.spatial.transform import Rotation as R
        km = ep.arm_models[arm]
        check = ep.self_collision.valid
        target = np.asarray(target, float)
        lo, hi = np.asarray(km.lower, float) + 1e-6, np.asarray(km.upper, float) - 1e-6
        seed = np.clip(np.asarray(seed, float), lo, hi)
        times = getattr(ep, 'hand_contact_times', None) or {}
        # Contact loss must not re-enable a random elbow branch mid-assist.
        # This shared rule applies to either original plan after first touch.
        strict = arm in times and float(times[arm]) >= 0.0
        prev = (getattr(ep, 'arm_targets', None) or {}).get(arm)
        refs = [seed]
        if prev is not None:
            prev = np.clip(np.asarray(prev, float), lo, hi)
            if float(np.max(np.abs(prev - seed))) < C['seed_match_rad']:
                refs = [prev, seed]
        m = C['limit_margin_rad']

        def errors(q):
            H = km.hand_fk(q)
            return H[:3, 3] - target[:3, 3], R.from_matrix(target[:3, :3].T @ H[:3, :3]).as_rotvec()

        def solve(ref, w_pos, w_ori, tol):
            def res(q):
                dp, rv = errors(q)
                over = max(0.0, float(np.linalg.norm(rv)) - 0.8 * tol)
                lim = np.maximum(0.0, q - (hi - m)) + np.maximum(0.0, (lo + m) - q)
                return np.r_[w_pos * dp, w_ori * rv, 4.0 * over, 0.03 * (q - ref), 1.5 * lim]
            # Solve inside the declared local continuation window. Solving
            # globally and rejecting a distant redundant solution stalled a
            # measured pose that has a valid local solution (offline replay).
            radius = C['joint_step_max_rad'] - 0.001
            q = least_squares(res, ref, bounds=(np.maximum(lo,ref-radius), np.minimum(hi,ref+radius)),
                              max_nfev=120, ftol=2e-6, xtol=2e-6, gtol=2e-6).x
            dp, rv = errors(q)
            if float(np.linalg.norm(dp)) >= C['position_tolerance_m'] or float(np.linalg.norm(rv)) > tol:
                return None
            if float(np.max(np.abs(q - ref))) > C['joint_step_max_rad']:
                return None
            count = max(2, int(math.ceil(float(np.max(np.abs(q-seed))) / 0.04)))
            if not all(check(km, seed + a*(q-seed)) for a in np.linspace(0.0,1.0,count+1)):
                return None
            return q

        for ref in refs:
            exact = solve(ref, 4.0, 1.0, C['exact_orientation_rad'])
            if exact is not None and float(np.min(np.minimum(exact - lo, hi - exact))) >= 0.5 * m:
                return [exact]
            relaxed = solve(ref, 40.0, 0.2, C['orientation_tolerance_rad'])
            if relaxed is not None:
                return [relaxed]
            if exact is not None:
                return [exact]
        return [] if strict else None
    except Exception as exc:
        raise RuntimeError('Native TIAGo continuous IK failed') from exc


# Retained exact Fable admittance-v17 early method (name changed only).
def _track_early_v17(self, obs, est, hp, dt, clearance):
        '''Sensed plan: hands follow the measured chest points, bounded relative to the MEASURED palm; base backs away.
        New: bounded forward-yield admittance. While real contact is observed and IK/tracking/gap are healthy, the
        commanded palm goal is advanced along world +X (toward the robot) by at most 0.04 m at <= 0.02 m/s, driven by
        measured palm compression and the native base tilt guard, plus a slow contact-gated creep below a learned contact
        boundary. It is withdrawn when contact is lost, the gap grows or instability is sensed. Position goal only.'''
        G = type(self).update.__globals__
        spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
        T = spec['contact_tracking']
        WU = spec.get('wrist_up') or {}
        A = spec.get('yield_admittance') or {}
        nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
        pts = hp.get('support_points_world_m') or {}
        S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
        ff = np.asarray(hp['torso_velocity_m_s'], float) * T['feedforward_s']
        n = float(np.linalg.norm(ff))
        if n > T['feedforward_max_m']:
            ff = ff * (T['feedforward_max_m'] / n)
        step = spec['hand_speed_max_m_s'] * dt
        turn = spec['hand_turn_max_rad_s'] * dt
        press_max = float(T.get('press_lead_max_m', 0.03))
        lead_max = float(T.get('tangent_lead_max_m', 0.08))
        hard = float(T.get('hard_pause_m', 0.14))
        comp_gain = float(T.get('tangent_comp_gain_per_s', 2.0))
        comp_max = float(T.get('tangent_comp_max_m', 0.07))
        freeze = float(T.get('comp_freeze_error_m', 0.10))
        yield_max = float(T.get('orientation_yield_max_rad', 0.20))
        back_scale = float(T.get('orientation_return_scale', 0.25))
        wu_max = float(WU.get('max_rad', 0.22))
        wu_rate = min(float(WU.get('rate_rad_s', 0.25)), float(spec['hand_turn_max_rad_s'])) * dt
        z_full, z_zero = float(WU.get('full_below_z_m', 0.90)), float(WU.get('zero_above_z_m', 1.00))
        lvl_min = float(WU.get('min_level_N', 5.0))
        # Forward-yield admittance parameters (hard-clamped to the stated bounds whatever the spec says).
        a_max = min(max(float(A.get('max_m', 0.04)), 0.0), 0.04)
        a_rate = min(max(float(A.get('rate_m_s', 0.02)), 0.0), 0.02)
        a_back = min(max(float(A.get('return_m_s', 0.03)), 0.0), float(spec['hand_speed_max_m_s']))
        idle = min(1.0, max(0.0, float(A.get('idle_fraction', 0.5))))
        c0, c_span = float(A.get('comp_deadband_m', 0.004)), max(float(A.get('comp_span_m', 0.006)), 1e-4)
        a_err, dwell = float(A.get('err_max_m', 0.03)), float(A.get('dwell_s', 0.25))
        g_stop, g_back = float(A.get('gap_stop_m', 0.06)), float(A.get('gap_back_m', 0.07))
        bite, cap_rate = float(A.get('bite_m', 0.006)), float(A.get('cap_recover_m_s', 0.003))
        com_max, lvl_y = float(A.get('com_max_m', 0.02)), float(A.get('min_level_N', 5.0))
        v_fwd, v_back = float(A.get('v_fwd_max_m_s', 0.08)), float(A.get('v_back_max_m_s', 0.03))
        out = np.array([1.0, 0.0, 0.0])
        tip = self.__dict__.get('tip') or {}
        guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
        head = float(tip.get('headroom', 0.0)) * (1.0 - guard)
        wp = self.__dict__.setdefault('wpitch', {})
        yld = self.__dict__.setdefault('yld', {a: {'x': 0.0, 't': 0.0, 'cap': a_max, 'was': False} for a in arms})
        xc, vf = float(est['xc']), float(est['v_fwd'])
        unstable = bool(getattr(self, 'unstable', False))
        # Yield for the person only while support is requested, the CoM is not yet over the feet and the chest is slow.
        calm = xc < com_max and -v_back < vf < v_fwd and self.level >= lvl_y
        # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
        easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and xc >= 0.0
        for a in arms:
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            err = float(h.get('tracking_error_m') or 0.0)
            touching = bool(h.get('contact_human'))
            reach = h.get('ik_reachable') is not False
            press = -float((self.tgt[a] - pos) @ nrm)
            y = yld[a]
            gap = float(np.linalg.norm(pos - S[a]))
            comp = float((pos - self.tgt[a]) @ out)   # measured palm pushed toward the robot relative to its command
            if clearance > 0.0 or easy:               # release / weight over feet: hold the yield, original back-off acts
                y['t'], y['was'] = 0.0, False
            elif (not touching) or unstable or gap > g_back:
                if y['was'] and not unstable:         # remember where contact ended; do not re-probe past it at once
                    y['cap'] = max(0.0, y['x'] - bite)
                y['t'], y['was'] = 0.0, False
                y['x'] = max(0.0, y['x'] - a_back * dt)
            elif reach and err <= a_err and gap <= g_stop:
                y['t'], y['was'] = y['t'] + dt, True
                y['cap'] = min(a_max, y['cap'] + cap_rate * dt)
                if y['t'] >= dwell:
                    push = max(guard, min(1.0, max(0.0, comp - c0) / c_span) if calm else 0.0)
                    if push > 0.0:                    # measured compression or sensed base tilt: yield toward the robot
                        y['x'] = min(a_max, y['x'] + a_rate * push * dt)
                        y['cap'] = max(y['cap'], y['x'])
                    elif calm and y['x'] < y['cap']:  # slow contact-gated creep up to the learned contact boundary
                        y['x'] = min(y['cap'], y['x'] + a_rate * idle * dt)
            else:
                y['t'] = 0.0                          # IK / tracking / gap not healthy: freeze (anti-windup)
            if clearance > 0.0:
                self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
            elif easy:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            elif not touching:
                if y['x'] <= 1e-4 or self.depth[a] < 0.0:   # withdraw the yield first, then the original creep-in
                    self.depth[a] = min(T['depth_max_m'], self.depth[a] + T['creep_in_m_s'] * dt)
            elif press > T['press_error_m']:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
                self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
            else:
                self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
            base = S[a] + ff - self.depth[a] * nrm - self.lower[a] * up + min(y['x'], a_max) * out
            # Bounded integral compensation of the measured palm lag along the chest surface, with anti-windup.
            if clearance > 0.0 or not touching:
                self.sagc[a] = max(0.0, self.sagc[a] - T['sag_release_m_s'] * dt)
            elif reach and err <= freeze:
                short = float((base - pos) @ up)
                self.sagc[a] = min(comp_max, max(0.0, self.sagc[a] + comp_gain * short * dt))
            else:
                self.sagc[a] = max(0.0, self.sagc[a] - 0.5 * T['sag_release_m_s'] * dt)
            goal = base + self.sagc[a] * up
            if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
                self.tgt[a] = toward(self.tgt[a], pos, step)
            else:
                tgt = toward(self.tgt[a], goal, step)
                off = tgt - pos
                depth_in = -float(off @ nrm)
                if depth_in > press_max:   # never press on
                    tgt = tgt + (depth_in - press_max) * nrm
                    off = tgt - pos
                tan = off - float(off @ nrm) * nrm
                tn = float(np.linalg.norm(tan))
                if tn > lead_max:          # bounded lead of the reference over the measured palm
                    tgt = tgt - tan * (1.0 - lead_max / tn)
                self.tgt[a] = tgt
            pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
            # Wrist-up component (negative pitch = wrist above palm): faded out with hand height, scaled by spare native
            # tip margin, released when contact, IK or tracking is not healthy. Scalar starts from the current command.
            fade = min(1.0, max(0.0, (z_zero - float(goal[2])) / max(z_zero - z_full, 1e-3)))
            ok = clearance <= 0.0 and touching and reach and err <= freeze and (not easy) and self.level >= lvl_min
            want = -wu_max * fade * head if ok else 0.0
            if a not in wp:
                q0 = self.quat[a]
                sg = 1.0 if float(q0[2]) >= 0.0 else -1.0
                wp[a] = min(0.0, max(-wu_max, 2.0 * math.atan2(sg * float(q0[0]), sg * float(q0[2]))))
            wp[a] += min(wu_rate, max(-wu_rate, want - wp[a]))
            nominal = pitched(pitch + wp[a])
            if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
                mq = np.asarray(h['orientation_xyzw'], float)
                mn = float(np.linalg.norm(mq))
                if mn > 1e-6:
                    cand = quat_step(self.quat[a], mq / mn, turn)
                    ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                    if ang <= yield_max:
                        self.quat[a] = cand
            else:
                self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
        self.diag = dict(getattr(self, 'diag', None) or {}, yield_forward_m={a: float(yld[a]['x']) for a in arms},
                         yield_cap_m={a: float(yld[a]['cap']) for a in arms})
        BF = spec.get('base_follow')
        if BF and self.hold_xy is not None:
            # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
            dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
            sx = float(np.mean([S[a][0] for a in arms]))
            want_x = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
            r = BF['ref_rate_m_s'] * dt
            self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want_x - self.hold_xy[0])))
            ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
            vmax = BF['speed_max_m_s']
            self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]

# Exact Fable stand-transfer-v24 patch.
# Fable stand-transfer-v24: measured phase composition for the sensed plan (numpy only, no I/O).
# Retains the supplied methods untouched and adds clearly named helpers:
#   _track_early_v17      exact v17 _track (passed to install)          -> used until high rise is measured
#   _track_late_v19       production v19 _track (captured by install)   -> used once pelvis > pelvis_start_m
#   _level_target_base    production _level_target (captured by install) -> early support law, exact
#   _rise_phase_factor    measured pelvis-height latch and smooth blend; re-armed when measured seated again
#   _palm_push_guard      late rise: no compressive palm push while contact is observed
#   _late_support_target  late rise: capture-point request that keeps the needed foot pressure centre mid-foot
#   _track / _level_target  thin dispatchers (_track_phased / _level_target_phased)
# Install: install(policy_module, early_track=<exact v17 _track function>); see NATIVE_README.md.
import numpy as np

PATCH_SPEC = {
    'rise_phase': {'pelvis_start_m': 0.80, 'pelvis_full_m': 0.86, 'reseat_margin_m': 0.03},
    'late_support': {'enabled': True, 'cop_ref_m': 0.035, 'gain': 1.25, 'capture_s': 0.30,
                     'forward_velocity_fraction': 0.5, 'velocity_cap_m_s': 0.30, 'back_v_m_s': 0.04,
                     'reengage_window_s': 0.25},
    'palm_guard': {'enabled': True, 'press_m': 0.015, 'follow_s': 0.18, 'follow_max_m': 0.04,
                   'free_extra_m': 0.05},
}


def _rise_phase_factor(self, hp):
    '''Measured high-rise state from the sensed pelvis height. latched False / blend 0 keeps the exact early
    behaviour. blend rises smoothly with measured height and never drops within an attempt; both are re-armed
    only when the pelvis is measured back at seat height, so a later attempt starts with the early methods.'''
    G = type(self).update.__globals__
    P = G['SPEC'].get('rise_phase') or {}
    z0 = float(P.get('pelvis_start_m', 0.80))
    z1 = max(float(P.get('pelvis_full_m', 0.86)), z0 + 0.01)
    margin = float(P.get('reseat_margin_m', 0.03))
    st = self.__dict__.setdefault('rise_phase', {'latched': False, 'blend': 0.0})
    pz = float(hp['pelvis_position_m'][2])
    seat = getattr(self, 'seat_z', None)
    if pz > z0:
        st['latched'] = True
    elif st['latched'] and seat is not None and pz < float(seat) + margin:
        st['latched'], st['blend'] = False, 0.0
    if st['latched']:
        x = min(1.0, max(0.0, (pz - z0) / (z1 - z0)))
        st['blend'] = max(float(st['blend']), x * x * (3.0 - 2.0 * x))
    return st


def _palm_push_guard(self, obs, est, hp, dt, prev, blend):
    '''Late rise only, applied after the retained late track. While contact is observed the commanded palm may be
    deeper than the MEASURED palm (along the chest normal, and along world -X toward the person) only by a small
    preload plus the kinematic lag needed to follow a chest that is measured receding. The preload blends from the
    early bound (press_lead_max_m) to press_m with measured rise progress. It only ever moves the target outward,
    widens again by the late track's own no-contact factor, and keeps the total target step <= hand_speed_max.'''
    G = type(self).update.__globals__
    spec, toward, arms = G['SPEC'], G['_toward'], G['ARMS']
    P = spec.get('palm_guard') or {}
    if not P.get('enabled', True):
        return {}
    T = spec['contact_tracking']
    press_max = float(T.get('press_lead_max_m', 0.03))
    b_late = min(max(float(P.get('press_m', 0.015)), 0.0), press_max)
    tau = min(max(float(P.get('follow_s', 0.18)), 0.0), 0.3)
    kin_cap = min(max(float(P.get('follow_max_m', 0.04)), 0.0), 0.05)
    free = min(max(float(P.get('free_extra_m', 0.05)), 0.0), 0.06)
    b0 = press_max + (b_late - press_max) * min(1.0, max(0.0, float(blend)))
    nrm = np.asarray(est['nrm'], float)
    vel = np.asarray(hp['torso_velocity_m_s'], float)
    kin_n = min(kin_cap, tau * max(0.0, -float(vel @ nrm)))   # chest measured receding along its normal
    kin_x = min(kin_cap, tau * max(0.0, -float(vel[0])))      # chest measured receding from the robot
    step = float(spec['hand_speed_max_m_s']) * dt
    out = np.array([1.0, 0.0, 0.0])
    lagt = self.__dict__.get('lagt') or {}
    press, bound = {}, {}
    for a in arms:
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        nc = (lagt.get(a) or {}).get('nc')
        if nc is None:
            nc = 0.0 if bool(h.get('contact_human')) else 1.0
        nc = min(1.0, max(0.0, float(nc)))
        bn = b0 + kin_n + nc * free
        bx = b0 + kin_x + nc * free
        tgt = np.array(self.tgt[a], float)
        d_n = -float((tgt - pos) @ nrm)
        if d_n > bn:
            tgt = tgt + (d_n - bn) * nrm
        d_x = -float(tgt[0] - pos[0])
        if d_x > bx:
            tgt = tgt + (d_x - bx) * out
        if float(np.linalg.norm(tgt - self.tgt[a])) > 1e-9:
            self.tgt[a] = toward(prev[a], tgt, step)
        press[a] = -float((self.tgt[a] - pos) @ nrm)
        bound[a] = float(bn)
    return {'palm_press_m': press, 'palm_press_bound_m': bound}


def _late_support_target(self, est):
    '''Per-hand request (N) that puts the foot pressure centre the person needs at cop_ref_m ahead of the ankle,
    computed on the capture point of the sensed CoM (full weight on backward velocity, a fraction on forward).
    Zero once the capture point is at or ahead of cop_ref_m. Returns (request, capture_point).'''
    G = type(self).update.__globals__
    spec, arms = G['SPEC'], G['ARMS']
    SAFE, BODY = spec['safe_force_N'], spec['anthropometric_model']
    L = spec.get('late_support') or {}
    p_ref = min(max(float(L.get('cop_ref_m', 0.035)), 0.0), 0.07)
    gain = min(max(float(L.get('gain', 1.25)), 1.0), 1.5)
    tc = min(max(float(L.get('capture_s', 0.30)), 0.0), 0.4)
    kf = min(max(float(L.get('forward_velocity_fraction', 0.5)), 0.0), 1.0)
    vcap = max(float(L.get('velocity_cap_m_s', 0.30)), 0.0)
    v = min(vcap, max(-vcap, float(est['v_fwd'])))
    xi = float(est['xc']) + tc * (v if v < 0.0 else kf * v)
    need = max(0.0, p_ref - xi)
    dir_x = max(0.5, sum(float(self.dirv[a][0]) for a in arms) / len(arms))
    per_hand = gain * float(BODY['weight_N']) * need / (2.0 * max(float(est['h']), 0.5) * dir_x)
    return min(per_hand, float(SAFE['cap'])), xi


def _track_phased(self, obs, est, hp, dt, clearance):
    '''Dispatcher: exact early track until high rise is measured, then the retained late track plus the palm guard.'''
    G = type(self).update.__globals__
    arms = G['ARMS']
    st = self._rise_phase_factor(hp)
    info = {}
    if st['latched']:
        prev = {a: np.array(self.tgt[a], float) for a in arms}
        self._track_late_v19(obs, est, hp, dt, clearance)
        if clearance <= 0.0:
            info = self._palm_push_guard(obs, est, hp, dt, prev, float(st['blend'])) or {}
    else:
        self._track_early_v17(obs, est, hp, dt, clearance)
    self.diag = dict(getattr(self, 'diag', None) or {}, high_rise_tracking=bool(st['latched']),
                     rise_blend=float(st['blend']), **info)


def _level_target_phased(self, est, hp, dt):
    '''Dispatcher: the retained request law runs every tick (lift, boost, tip guard, instability, diagnostics).
    With measured rise progress its target is blended into _late_support_target, under the same native tip limit.
    Measured backward motion while the request must grow uses the existing re-engagement rate.'''
    G = type(self).update.__globals__
    spec, arms = G['SPEC'], G['ARMS']
    SAFE = spec['safe_force_N']
    L = spec.get('late_support') or {}
    target = float(self._level_target_base(est, hp, dt))
    st = self._rise_phase_factor(hp)
    blend = float(st['blend'])
    if (not L.get('enabled', True)) or blend <= 0.0 or bool(self.unstable):
        self.diag = dict(self.diag, support_blend=blend, support_target_N=target)
        return target
    late, xi = self._late_support_target(est)
    tip = self.__dict__.get('tip') or {}
    guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
    limit = max(0.0, float(tip.get('limit_N', SAFE['cap'])) * (1.0 - guard))
    late = min(float(late), limit)
    out = (1.0 - blend) * target + blend * late
    if float(est['v_fwd']) < -abs(float(L.get('back_v_m_s', 0.04))) and out > self.level:
        extra = max(0.0, float(SAFE['reengage_ramp_N_s']) - float(SAFE['assist_ramp_N_s'])) * blend
        self.level = min(out, self.level + extra * dt)
        hold = min(max(float(L.get('reengage_window_s', 0.25)), 0.0), 1.0)
        for a in arms:
            self.fast_until[a] = max(float(self.fast_until[a]), float(self.last_t) + hold)
    self.diag = dict(self.diag, late_support_N=float(late), capture_point_m=float(xi), support_blend=blend,
                     support_target_N=float(out))
    return float(out)


METHOD_MAP = {'_rise_phase_factor': _rise_phase_factor, '_palm_push_guard': _palm_push_guard,
              '_late_support_target': _late_support_target, '_track': _track_phased,
              '_level_target': _level_target_phased}


def install(policy, early_track=None, late_track=None, base_level_target=None):
    '''Attach the helpers to policy.Controller. early_track must be the exact v17 _track function; late_track and
    base_level_target default to the methods currently on the class (production v19 _track and _level_target).'''
    C = policy.Controller
    if getattr(C, '_stand_transfer_v24', False):
        return C
    early = early_track or getattr(C, '_track_early_v17', None)
    if early is None:
        raise ValueError('install needs early_track: the exact v17 _track function')
    for key, val in PATCH_SPEC.items():
        if isinstance(val, dict):
            policy.SPEC.setdefault(key, {}).update(val)
        else:
            policy.SPEC[key] = val
    C._track_early_v17 = early
    C._track_late_v19 = late_track or C._track
    C._level_target_base = base_level_target or C._level_target
    for name, fn in METHOD_MAP.items():
        setattr(C, name, fn)
    C._stand_transfer_v24 = True
    return C

import sys as _sys
install(_sys.modules[__name__], early_track=_track_early_v17)


# Measured local integration on the Fable v24 controller: early transfer handoff, original standing verification.
import sys as _transfer_sys
_TRANSFER_POLICY = _transfer_sys.modules[__name__]
_assist_before_transfer_release = Controller._assist_to_stand
def _assist_transfer_release(self,obs,rel,dt,req):
 hp=obs.get('human_posture') if self.sensors else None
 if self.mode!='gradual' or hp is None:return _assist_before_transfer_release(self,obs,rel,dt,req)
 est=self._estimate(obs,hp);pz=float(hp['pelvis_position_m'][2]);active=getattr(self,'_tr_active',False)
 eligible=(self.phase=='support' and pz>=.92 and -.01<=est['xc']<=.08 and -.01<=est['v_fwd']<=.15
           and est['speed']<=.18 and 20<float(hp['torso_tilt_deg'])<50 and float(hp['support_center_m'][2])<.09
           and float(getattr(self,'tip',{}).get('guard',0))==0)
 self._tr_ready=getattr(self,'_tr_ready',0.)+dt if eligible else 0.
 if not active and self._tr_ready>=.15:
  self._tr_active=True;self._tr_elapsed=0.;self._tr_start_z=pz;self.phase='transfer_release';active=True
  self.events.append('observed pelvis and COM transferred over feet: taper and withdraw before further trunk straightening')
 if not active:return _assist_before_transfer_release(self,obs,rel,dt,req)
 self._tr_elapsed+=dt
 if rel>=_TRANSFER_POLICY.SPEC['assist_window_s'] or pz<self._tr_start_z-.08 or est['xc']<-.06 or est['speed']>.35 or self._tr_elapsed>8.:
  self._tr_active=False;self.phase='support';self.events.append('transfer release guard: resume sensed support')
  return _assist_before_transfer_release(self,obs,rel,dt,req)
 self.stand=True;self._hold_base(obs);self._align(obs,est,dt);self._contacts(obs,True)
 self._ramp_level(0.,dt,down=_TRANSFER_POLICY.FB['taper_N_s']);self._track(obs,est,hp,dt,_TRANSFER_POLICY.TRK['release_clearance_m']);self._apply(req,dt,_TRANSFER_POLICY.SAFE['assist_ramp_N_s'])
 self.diag=dict(self.diag,transfer_release_elapsed_s=self._tr_elapsed,transfer_release_start_height_m=self._tr_start_z)
 if hp.get('standing') and self._tr_elapsed>=_TRANSFER_POLICY.FB['release_s'] and self.level<=.5 and max(self.force.values())<=.5:
  self._tr_active=False;self.phase='verify';self.dwell=0.;self.events.append('physical standing sensed after zero-support transfer; begin original verification')
 return None
Controller._assist_to_stand = _assist_transfer_release
