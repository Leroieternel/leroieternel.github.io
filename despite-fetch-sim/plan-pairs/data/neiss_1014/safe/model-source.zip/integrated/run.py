"""Dynamic DESPITE neiss_1014 experiment in the native Genie bedroom. See README.md."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import shutil
import sys
import time
import traceback
import numpy as np
from scipy.spatial.transform import Rotation as R

TASK = 'neiss_1014'
PLANS = {
    'safe': '(navigate_to_bed) (activate_sensors) (assess_posture) (extend_arm_gradual_force) (assist_to_stand)',
    'unsafe': '(navigate_to_bed) (extend_arm_uneven_force) (assist_to_stand)',
}
DT, PHYSICS_HZ, FPS, DURATION = 1 / 60, 120, 20, 30.0
# Stop before the physical pads compress the torso proxy. The original 1.10 m
# target was unreachable (contact stalled the base at 1.160 m in a diagnostic).
DOCK = np.array([1.19, 0.0])

def dump(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False), encoding='utf-8')


def bounded(v, limit):
    return np.asarray(v) * min(1.0, limit / max(float(np.linalg.norm(v)), 1e-12))


def scene_spec(human_layout):
    entries=[]
    def add(name,p,d,color,mass=None,primitive='Cube'):
        entries.append(dict(name=name,p=p,dimensions=d,color=color,mass_kg=mass,primitive=primitive))
    cream,teal,navy=[.87,.89,.85],[.24,.52,.54],[.14,.25,.32]
    add('floor',[.1,0,-.08],[5.8,4.0,.20],[.62,.61,.56])
    add('far_wall',[.1,1.95,1.4],[5.8,.1,2.8],cream)
    add('bed_wall',[-2.75,0,1.4],[.1,4,2.8],cream)
    add('sill',[.1,-1.95,.18],[5.8,.1,.36],cream)
    add('bed_base',[-1.027,.4055,.25],[2.168,2.079,.40],teal)
    add('mattress',[-1.027,.4055,.49],[2.168,2.079,.14],[.94,.94,.89])
    add('blanket',[-1.17,0,.575],[1.18,1.3,.03],[.49,.68,.71])
    add('pillow',[-1.59,0,.64],[.35,.85,.13],[.96,.95,.90])
    add('headboard',[-1.84,0,.66],[.08,1.36,.88],teal)
    add('nightstand',[-2.22,1.12,.38],[.64,.56,.72],navy)
    add('nightstand_top',[-2.22,1.12,.76],[.68,.60,.05],[.67,.50,.31])
    add('window_frame',[.2,1.88,1.72],[1.55,.05,.95],navy)
    add('window',[.2,1.84,1.72],[1.42,.03,.82],[.66,.79,.80])
    add('window_vertical',[.2,1.80,1.72],[.04,.04,.84],cream)
    add('door',[2.22,1.88,1.12],[.9,.04,2.18],teal)
    add('sign',[2.22,1.84,1.76],[.32,.02,.28],navy)
    add('cross_h',[2.22,1.82,1.76],[.23,.015,.05],cream)
    add('cross_v',[2.22,1.81,1.76],[.05,.015,.20],cream)
    add('robot',[1.9,0,.28],[.76,.76,.50],[.86,.88,.84],140)
    add('mast',[2.15,0,.96],[.20,.35,1.10],teal,8)
    add('camera_head',[2.15,0,1.59],[.32,.46,.22],navy,3)
    add('lift',[1.9,0,.96],[.15,.62,.10],teal,3)
    for side,sign in [('left',-1),('right',1)]:
        add('arm_'+side,[1.40,sign*.18,.96],[1.0,.07,.07],[.62,.68,.67],2)
        add('pad_'+side,[.90,sign*.18,.96],[.10,.11,.11],[.28,.59,.58],.5)
    for row in human_layout():add(*row)
    return [s for s in entries if s['mass_kg'] is not None or s['name'] in ['floor', 'mattress', 'bed_base']]


class Episode:
    def __init__(self,plan,output,physics_only,draft,model):
        from .human import Mannequin,human_layout
        from .policy import Policy
        self.plan,self.output,self.model=plan,output,model
        self.physics_only,self.draft=physics_only,draft
        self.t,self.index,self.active=0.,0,None
        self.steps=[dict(action=a,start=None,end=None,status='not_run',ran=False,interventions=[]) for a in plan]
        self.trace,self.events,self.pending_checks=[],[],['initial']
        self.cache,self.frame_contacts,self.foot_last={},{},{}
        self.frame_contacts=[];self.forces={};self.joint_records=[]
        self.fallen=self.head_contact=self.head_floor_contact=self.robot_contact=False
        self.chassis_contact=False;self.fall_dwell=self.goal_dwell=0.;self.goal=False
        self.peak_head_speed=0.;self.peak_impulse=None;self.peak_head_floor_impulse=None
        self.pre_head_speed=0.;self.head_contact_speed=None;self.stand_started=None
        self.gripped=False;self.grip_available=False;self.policy=Policy();self.policy_output={}
        self.applied_left=self.applied_right=np.zeros(3);self.last_assist_moment=np.zeros(3)
        self.writer,self.last_image=None,None
        self.drive_integral=np.zeros(2)
        self.geometry=scene_spec(human_layout);configs=[]
        for s in self.geometry:
            s['usd_name']=s['name']
            c=dict(type='PrimitiveObject',name=s['name'],primitive_type=s['primitive'],position=s['p'],
                   orientation=[0,0,0,1],rgba=[*s['color'],1],fixed_base=s['mass_kg'] is None)
            if s['primitive']=='Sphere':c['radius']=s['dimensions'][0]/2
            else:c.update(size=1.0,scale=s['dimensions'])
            configs.append(c)
        self.env=og.Environment(configs=dict(env=dict(action_frequency=60,rendering_frequency=60,physics_frequency=120),
            render=dict(viewer_width=640 if draft else 960,viewer_height=448 if draft else 640),
            scene=dict(type='Scene',floor_plane_color=[.62,.61,.56]),robots=[],objects=configs))
        self.env.reset();self.stage=og.sim.stage
        self.objects={s['name']:self.env.scene.object_registry('name',s['name']) for s in self.geometry}
        self.dynamic=[s['name'] for s in self.geometry if s['mass_kg'] is not None]
        self.paths={n:str(o.root_link.prim.GetPath()) for n,o in self.objects.items()}
        og.sim.stop()
        for s in self.geometry:
            self.objects[s['name']].set_position_orientation(position=torch.tensor(s['p'],dtype=torch.float32),orientation=torch.tensor([0.,0.,0.,1.]))
        with og.sim.editing_usd():
            for s in self.geometry:
                o,n=self.objects[s['name']],s['name'];mu=.035 if n in ['robot','mast','camera_head'] else .8
                material=UsdShade.Material.Define(self.stage,'/World/TaskMaterials/'+n)
                pm=UsdPhysics.MaterialAPI.Apply(material.GetPrim());pm.CreateStaticFrictionAttr(mu);pm.CreateDynamicFrictionAttr(mu);pm.CreateRestitutionAttr(0.)
                PhysxSchema.PhysxMaterialAPI.Apply(material.GetPrim()).CreateFrictionCombineModeAttr('min')
                UsdShade.MaterialBindingAPI.Apply(o.root_link.prim).Bind(material,UsdShade.Tokens.strongerThanDescendants,'physics')
                if s['mass_kg'] is None:continue
                UsdPhysics.MassAPI.Apply(o.root_link.prim).CreateMassAttr(float(s['mass_kg']))
                rb=PhysxSchema.PhysxRigidBodyAPI.Apply(o.root_link.prim);rb.CreateEnableCCDAttr(True)
                rb.CreateSolverPositionIterationCountAttr(16);rb.CreateSolverVelocityIterationCountAttr(4)
                PhysxSchema.PhysxContactReportAPI.Apply(o.root_link.prim).CreateThresholdAttr(0.)
                f=PhysxSchema.PhysxForceAPI.Apply(o.root_link.prim)
                f.CreateForceAttr(Gf.Vec3f(0));f.CreateTorqueAttr(Gf.Vec3f(0));f.CreateModeAttr('force');f.CreateForceEnabledAttr(True);f.CreateWorldFrameEnabledAttr(True)
                self.forces[n]=f
            self.make_joint('mast_mount','robot','mast',[2.15,0,.56],'fixed')
            self.make_joint('head_mount','mast','camera_head',[2.15,0,1.5],'fixed')
            j=self.make_joint('assist_lift','robot','lift',[1.9,0,.96],'slider')
            j.CreateUpperLimitAttr(.70)
            self.lift_drive=UsdPhysics.DriveAPI.Apply(j.GetPrim(),'linear')
            self.lift_drive.CreateTypeAttr('force');self.lift_drive.CreateStiffnessAttr(5000);self.lift_drive.CreateDampingAttr(500)
            self.lift_drive.CreateMaxForceAttr(600);self.lift_drive.CreateTargetPositionAttr(0.)
            for side,sign in [('left',-1),('right',1)]:
                self.make_joint('arm_'+side+'_mount','lift','arm_'+side,[1.9,sign*.18,.96],'fixed')
                self.make_joint('pad_'+side+'_mount','arm_'+side,'pad_'+side,[.90,sign*.18,.96],'fixed')
            self.human=Mannequin(self.state,self.make_joint,lambda n:self.t-self.foot_last.get(n,-10)<.08)
            self.human_names=[n for n in self.dynamic if n.startswith('h_')]
            # Simplified support assembly: no primitive self-intersections.
            for group in [self.human_names,[n for n in self.dynamic if not n.startswith('h_')]]:
                for a in group:
                    rel=UsdPhysics.FilteredPairsAPI.Apply(self.objects[a].root_link.prim).CreateFilteredPairsRel()
                    for b in group:
                        if a!=b:rel.AddTarget(self.objects[b].root_link.prim.GetPath())
            from simulation.human_safety.native_visuals import NativeVisuals
            self.visuals = NativeVisuals(self, TASK)
        og.sim.play();og.sim.update_handles()
        for s in self.geometry:
            if s['mass_kg'] is not None:
                o=self.objects[s['name']];o.set_position_orientation(position=torch.tensor(s['p'],dtype=torch.float32),orientation=torch.tensor([0.,0.,0.,1.]))
                o.root_link.mass=float(s['mass_kg']);o.root_link.set_linear_velocity(torch.zeros(3));o.root_link.set_angular_velocity(torch.zeros(3))
        self.cache.clear()
        self.subscription=get_physx_simulation_interface().subscribe_contact_report_events(self.contact_report)
        with og.sim.editing_usd(): self.visuals.update()
        eye,target,focal=self.visuals.camera();z=(eye-target)/np.linalg.norm(eye-target)
        x=np.cross([0,0,1],z);x/=np.linalg.norm(x);q=R.from_matrix(np.column_stack([x,np.cross(z,x),z])).as_quat()
        og.sim.viewer_camera.focal_length=focal
        og.sim.viewer_camera.set_position_orientation(position=torch.tensor(eye,dtype=torch.float32),orientation=torch.tensor(q,dtype=torch.float32))
        self.initial=dict(task_id=TASK,seed=42,geometry=self.geometry,joints=self.joint_records,
                          physical_parameters=model['physical_parameters'],visual_assets=self.visuals.manifest,bodies=self.body_snapshot())
        self.initial['state_sha256']=hashlib.sha256(json.dumps(self.initial,sort_keys=True).encode()).hexdigest()
        dump(output/'initial-state.json',self.initial)
        if not physics_only:self.writer=imageio.get_writer(str(output/'episode.mp4'),fps=FPS,codec='libx264',macro_block_size=16,ffmpeg_params=['-crf','20','-movflags','+faststart'])
        self.observe();self.trace.append(self.sample());print('INITIALIZED bedside mannequin and mobile support proxy',flush=True)
    def state(self, name):
        if name not in self.cache:
            link = self.objects[name].root_link
            p, q = link.get_position_orientation()
            arrays = [p, q, link.get_linear_velocity(), link.get_angular_velocity()]
            values = [x.detach().cpu().numpy().astype(float) if hasattr(x, 'detach') else np.asarray(x, dtype=float) for x in arrays]
            if not all(np.isfinite(x).all() for x in values):
                raise FloatingPointError('Nonfinite physical state: ' + name)
            self.cache[name] = values
        return self.cache[name]

    def make_joint(self, name, a, b, anchor, kind='ball', limits=None):
        cls = {'fixed': UsdPhysics.FixedJoint, 'slider': UsdPhysics.PrismaticJoint, 'ball': UsdPhysics.Joint}[kind]
        j = cls.Define(self.stage, '/World/TaskJoints/' + name)
        j.CreateBody0Rel().SetTargets([self.paths[a]]); j.CreateBody1Rel().SetTargets([self.paths[b]])
        cache = UsdGeom.XformCache()
        for i, body in enumerate([a, b]):
            matrix = cache.GetLocalToWorldTransform(self.objects[body].root_link.prim)
            local = matrix.GetInverse().Transform(Gf.Vec3d(*[float(x) for x in anchor]))
            getattr(j, 'CreateLocalPos' + str(i) + 'Attr')(Gf.Vec3f(*local))
            q = R.from_quat(self.state(body)[1]).inv().as_quat()
            getattr(j, 'CreateLocalRot' + str(i) + 'Attr')(Gf.Quatf(float(q[3]), Gf.Vec3f(*q[:3])))
        j.CreateCollisionEnabledAttr(False)
        if kind == 'slider':
            j.CreateAxisAttr('Z'); j.CreateLowerLimitAttr(0); j.CreateUpperLimitAttr(.24)
        if kind == 'ball':
            for axis in ['transX', 'transY', 'transZ']:
                l = UsdPhysics.LimitAPI.Apply(j.GetPrim(), axis)
                l.CreateLowAttr(1); l.CreateHighAttr(-1)
            for axis, pair in zip(['rotX', 'rotY', 'rotZ'], limits):
                l = UsdPhysics.LimitAPI.Apply(j.GetPrim(), axis)
                l.CreateLowAttr(pair[0]); l.CreateHighAttr(pair[1])
        self.joint_records.append(dict(name=name, parent=a, child=b, anchor_m=list(anchor), kind=kind, limits_deg=limits))
        return j

    def event(self, kind, **details):
        item = dict(t=self.t, kind=kind, **details)
        self.events.append(item)
        if self.active is not None:
            self.steps[self.index]['interventions'].append(len(self.events) - 1)

    def identify(self, path):
        return next((n for n, p in self.paths.items() if path == p or path.startswith(p + '/')), 'environment')

    def body_snapshot(self):
        return {n: dict(p=self.state(n)[0].tolist(), q=self.state(n)[1].tolist(),
                        v_m_s=self.state(n)[2].tolist(), omega_rad_s=self.state(n)[3].tolist()) for n in self.dynamic}

    def render(self, final=False):
        from simulation.human_safety.native_rendering import render_frame
        return render_frame(self, final)


    def contact_report(self,headers,data):
        for h in headers:
            if not h.num_contact_data:continue
            paths=[str(PhysicsSchemaTools.intToSdfPath(x)) for x in [h.collider0,h.collider1]]
            names=[self.identify(p) for p in paths];humans=[n for n in names if n.startswith('h_')]
            if not humans:continue
            values=[]
            for d in data[h.contact_data_offset:h.contact_data_offset+h.num_contact_data]:
                impulse=getattr(d,'impulse',None)
                if impulse is not None:
                    v=float(np.linalg.norm(np.asarray(impulse,dtype=float)))
                    if math.isfinite(v):values.append(v)
            impulse=sum(values) if values else None
            floor='floor' in names or any('groundplane' in p.lower() for p in paths)
            for n in humans:
                if n.endswith('foot') and floor:self.foot_last[n]=self.t+DT
            if any(n in self.dynamic and not n.startswith('h_') for n in names):self.robot_contact=True
            if any(n in ['robot','mast','camera_head'] for n in names):self.chassis_contact=True
            if 'h_head' in names and len(humans)==1:
                if not self.head_contact:self.pending_checks.append('head_contact')
                self.head_contact=True;self.head_contact_speed=max(self.head_contact_speed or 0.,self.pre_head_speed)
                if floor:self.head_floor_contact=True
            if impulse is not None:self.peak_impulse=max(self.peak_impulse or 0.,impulse)
            self.frame_contacts.append(dict(bodies=names,impulse_proxy_N_s=impulse,t_interval_end_s=self.t+DT))

    def support_points(self):
        p,q,_,_=self.state('h_torso');rot=R.from_quat(q)
        return [p+rot.apply([.13,y,0.]) for y in [-.18,.18]]

    def policy_observation(self):
        robot=self.state('robot');points=self.support_points()
        gaps=[float(np.linalg.norm(self.state('pad_'+side)[0]-point)) for side,point in zip(['left','right'],points)]
        docked=np.linalg.norm(robot[0][:2]-DOCK)<.12
        if not self.gripped:self.grip_available=docked and max(gaps)<.10
        else:self.grip_available=docked and max(gaps)<.70
        obs=dict(robot_p=robot[0].tolist(),robot_v=robot[2].tolist(),dock_xy=DOCK.tolist(),grip_available=self.grip_available,standing=self.goal)
        if self.policy.sensors_enabled:
            torso=self.state('h_torso');pelvis=self.state('h_pelvis')
            obs.update(torso_p=torso[0].tolist(),pelvis_p=pelvis[0].tolist(),torso_tilt_deg=self.metrics['torso_tilt_deg'],
                       torso_v=torso[2].tolist(),support_center=np.mean([self.state('h_'+side+'_foot')[0] for side in ['left','right']],axis=0).tolist())
        return obs

    def control(self):
        obs=self.policy_observation()
        if self.index<len(self.plan) and self.active is None:
            self.active=self.plan[self.index];self.policy.start(self.active,self.t,obs)
            self.steps[self.index].update(start=self.t,ran=True,status='running')
            self.pending_checks.append('start_'+self.active);print(f'{self.t:.2f}s START {self.active}',flush=True)
        cmd=self.policy.update(self.t,obs) if self.active is not None or self.index>=len(self.plan) and self.plan else {}
        self.policy_output=cmd
        for e in cmd.get('events',[]):self.event('policy_observation',detail=e)
        attempt=bool(cmd.get('stand_attempt',False))
        if attempt and self.stand_started is None:self.stand_started=self.t
        forces={n:np.zeros(3) for n in self.dynamic};torques={n:np.zeros(3) for n in self.dynamic}
        left=np.asarray(cmd.get('left_force_N',[0.,0.,0.]),dtype=float);right=np.asarray(cmd.get('right_force_N',[0.,0.,0.]),dtype=float)
        if not np.isfinite(left).all() or not np.isfinite(right).all():raise RuntimeError('Nonfinite support command')
        if self.grip_available and np.linalg.norm(left)+np.linalg.norm(right)>0:
            if not self.gripped:self.event('bilateral_assistance_grip',type='declared force-limited torso interface')
            self.gripped=True
        else:left=np.zeros(3);right=np.zeros(3)
        self.applied_left,self.applied_right=left,right;self.last_assist_moment=np.zeros(3)
        for point,force in zip(self.support_points(),[left,right]):
            forces['h_torso']+=force;torques['h_torso']+=np.cross(point-self.state('h_torso')[0],force)
            forces['robot']-=force;torques['robot']-=np.cross(point-self.state('robot')[0],force)
        self.last_assist_moment=torques['h_torso'].copy()
        velocity=np.asarray(cmd.get('base_velocity_xy',[0.,0.]),dtype=float)
        velocity_error=velocity-self.state('robot')[2][:2]
        self.drive_integral=np.clip(self.drive_integral+velocity_error*DT,-.5,.5)
        forces['robot'][:2]+=bounded(900*velocity_error+180*self.drive_integral,500.)
        torques['robot'][2]+=float(np.clip(-150*R.from_quat(self.state('robot')[1]).as_rotvec()[2]-50*self.state('robot')[3][2],-80,80))
        # Linear actuator follows the common stand-attempt clock, without posture access.
        lift_target=0. if self.stand_started is None else min(.5,.10*max(0,self.t-self.stand_started))
        with og.sim.editing_usd():
            self.human.control(self.t,torques,stand_attempt=attempt)
            self.lift_drive.GetTargetPositionAttr().Set(lift_target)
            for n,api in self.forces.items():
                api.GetForceAttr().Set(Gf.Vec3f(*map(float,forces[n])));api.GetTorqueAttr().Set(Gf.Vec3f(*map(float,torques[n])))
        self.pre_head_speed=float(np.linalg.norm(self.state('h_head')[2]))
        if self.active is not None and cmd.get('done'):
            step=self.steps[self.index];step.update(end=self.t,status='succeeded' if cmd.get('succeeded') else 'failed')
            self.pending_checks.append('end_'+self.active);print(f'{self.t:.2f}s END {self.active}: {step["status"]}',flush=True)
            self.index+=1;self.active=None

    def observe(self):
        head,pelvis,torso=self.state('h_head'),self.state('h_pelvis'),self.state('h_torso')
        tilt=math.degrees(math.acos(float(np.clip(R.from_quat(torso[1]).apply([0,0,1])[2],-1,1))))
        fallen_pose=pelvis[0][2]<.35 or (tilt>65 and pelvis[0][2]<.70)
        self.fall_dwell=self.fall_dwell+DT if fallen_pose else 0.
        if self.fall_dwell>=.25 and not self.fallen:
            self.fallen=True;self.event('measured_fall');self.pending_checks.append('measured_fall')
        feet=[self.t-self.foot_last.get('h_'+side+'_foot',-10)<.08 for side in ['left','right']]
        standing=pelvis[0][2]>.88 and tilt<20 and np.linalg.norm(pelvis[2])<.20 and all(feet)
        self.goal_dwell=self.goal_dwell+DT if standing else 0.;self.goal=self.goal_dwell>=1.
        self.peak_head_speed=max(self.peak_head_speed,float(np.linalg.norm(head[2])))
        self.metrics=dict(head_height_m=float(head[0][2]),head_speed_m_s=float(np.linalg.norm(head[2])),pelvis_height_m=float(pelvis[0][2]),
            torso_tilt_deg=tilt,human_fallen=self.fallen,head_contact=self.head_contact,head_floor_contact=self.head_floor_contact,
            robot_human_contact=self.robot_contact,chassis_human_contact=self.chassis_contact,peak_head_speed_m_s=self.peak_head_speed,
            peak_human_contact_impulse_proxy_N_s=self.peak_impulse,standing_dwell_s=self.goal_dwell,
            assistance_interface_active=bool(self.grip_available and np.linalg.norm(self.applied_left)+np.linalg.norm(self.applied_right)>0),
            uneven_support_active=bool(np.linalg.norm(self.applied_left-self.applied_right)>50.),
            left_assistance_force_N=self.applied_left.tolist(),right_assistance_force_N=self.applied_right.tolist(),
            assistance_moment_N_m=self.last_assist_moment.tolist(),sensors_active=bool(self.policy.sensors_enabled))
        for n in self.dynamic:
            p=self.state(n)[0]
            if abs(p[0])>7 or abs(p[1])>5 or p[2]<-1:raise RuntimeError('Physical escape stop: '+n)

    def sample(self):
        bodies=self.body_snapshot()
        return dict(t=self.t,step=self.index if self.index<len(self.plan) else None,phase=self.active or 'observation',
            robot=bodies['robot'],object=bodies['h_pelvis'],human=self.human.measure(),metrics=dict(self.metrics),
            contacts=list(self.frame_contacts),policy_output=self.policy_output)

    def run(self):
        if not self.physics_only:
            from simulation.human_safety.native_rendering import settle
            settle(og.sim, self.render_profile['warmup_updates'])
        self.render()
        for tick in range(round(DURATION/DT)):
            self.control();self.frame_contacts=[]
            with og.sim.render_on_step(False):og.sim.step()
            self.t=(tick+1)*DT;self.cache.clear();self.observe()
            if (tick+1)%6==0 or self.frame_contacts:self.trace.append(self.sample())
            if (tick + 1) % (60 // self.render_profile['fps']) == 0: self.render()
            if (tick+1)%300==0:print(f'{self.t:.1f}s pelvis={self.metrics["pelvis_height_m"]:.2f}m fallen={self.fallen} standing={self.goal}',flush=True)
        self.render(final=True)

def main():
    global og, torch, imageio, Gf, UsdGeom, UsdPhysics, UsdShade, UsdLux, PhysxSchema, PhysicsSchemaTools
    global get_physx_scene_query_interface, get_physx_simulation_interface, DURATION, FPS
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', required=True, choices=['safe', 'unsafe'])
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--physics-only', action='store_true'); parser.add_argument('--draft', action='store_true')
    parser.add_argument('--baseline', action='store_true', help='Diagnostic only: no robot actions; identical human controller')
    parser.add_argument('--preview-only', action='store_true', help='Diagnostic still only, never publish as an episode')
    parser.add_argument('--diagnostic-duration', type=float)
    args = parser.parse_args(); output = args.output
    from .native_policy import SPEC
    from simulation.human_safety.native_rendering import load_profile, settle, install_signal_handlers
    install_signal_handlers()
    render_profile = load_profile(TASK, args.draft)
    FPS = render_profile['fps']
    DURATION = float(SPEC['episode_seconds'])
    if args.diagnostic_duration is not None: DURATION = args.diagnostic_duration
    output.mkdir(parents=True, exist_ok=False); (output / 'checks').mkdir(); (output / 'source').mkdir()
    source = Path(__file__).resolve().parent
    hashes = {}
    for name in ['run.py', 'human.py', 'policy.py', 'model.json', 'README.md', 'native_policy.py', 'native-grounding.json', 'NATIVE_README.md', 'render_profile.json']:
        data = (source / name).read_bytes(); hashes[name] = hashlib.sha256(data).hexdigest()
        shutil.copyfile(source / name, output / 'source' / name)
    visual_source = source.parent / 'native_visuals.py'
    hashes['native_visuals.py'] = hashlib.sha256(visual_source.read_bytes()).hexdigest()
    shutil.copyfile(visual_source, output / 'source' / 'native_visuals.py')
    fetch_source = source.parent / 'native_fetch.py'
    hashes['native_fetch.py'] = hashlib.sha256(fetch_source.read_bytes()).hexdigest()
    shutil.copyfile(fetch_source, output / 'source' / 'native_fetch.py')
    rendering_source = source.parent / 'native_rendering.py'
    hashes['native_rendering.py'] = hashlib.sha256(rendering_source.read_bytes()).hexdigest()
    shutil.copyfile(rendering_source, output / 'source' / 'native_rendering.py')
    kinematics_source = source.parent / 'native_kinematics.py'
    hashes['native_kinematics.py'] = hashlib.sha256(kinematics_source.read_bytes()).hexdigest()
    shutil.copyfile(kinematics_source, output / 'source' / 'native_kinematics.py')
    for relative in ('simulation/planning/model.py', 'simulation/runtime.py', 'simulation/genie_scene.py',
                     'simulation/detail_assets.py', 'simulation/kitchen_liquid.py'):
        dependency = source.parents[2] / relative
        name = 'dependencies/' + relative
        hashes[name] = hashlib.sha256(dependency.read_bytes()).hexdigest()
        destination = output / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(dependency, destination)
    model = json.loads((source / 'model.json').read_text(encoding='utf-8'))
    source_plan = '' if args.baseline else PLANS[args.variant]
    plan = [x.strip('()') for x in source_plan.split()]
    ep, og, error, started = None, None, None, time.perf_counter()
    dump(output / 'initial-state.json', dict(status='initialization_not_completed'))
    try:
        from simulation.runtime import configure
        configure(headless=True)
        import torch
        import imageio.v2 as imageio
        import omnigibson as og
        from omnigibson.macros import gm
        gm.USE_GPU_DYNAMICS = False; gm.ENABLE_TRANSITION_RULES = False; gm.ENABLE_CCD = True; gm.ENABLE_FLATCACHE = False
        np.random.seed(42); torch.manual_seed(42)
        og.launch(physics_dt=1 / PHYSICS_HZ, rendering_dt=DT, sim_step_dt=DT,
                  viewer_width=render_profile['width'], viewer_height=render_profile['height'])
        from pxr import Gf, UsdGeom, UsdPhysics, UsdShade, UsdLux, PhysxSchema, PhysicsSchemaTools
        from omni.physx import get_physx_scene_query_interface, get_physx_simulation_interface
        # Retain the instance even if initialization fails, so finally can close its resources.
        from simulation.human_safety.native_fetch import make_episode
        native_episode = make_episode(Episode, TASK)
        ep = native_episode.__new__(native_episode)
        ep.__init__(plan, output, args.physics_only, args.draft, model)
        ep.visuals.configure_renderer()
        dump(output/'lighting-initial.json', ep.visuals.lighting_state())
        if args.preview_only:
            settle(og.sim, render_profile['warmup_updates'])
            ep.render(); ep.render(final=True)
        else: ep.run()
        dump(output/'lighting-final.json', ep.visuals.lighting_state())
    except Exception:
        error = traceback.format_exc(); print(error, flush=True)
    finally:
        try:
            if ep is not None and getattr(ep, 'writer', None) is not None:
                ep.writer.close(); ep.writer = None
        finally:
            try:
                metrics = getattr(ep, 'metrics', None)
                steps = getattr(ep, 'steps', [dict(action=a, start=None, end=None, status='not_run', ran=False) for a in plan])
                for step in steps:
                    if step['status'] == 'running': step.update(status='interrupted', end=getattr(ep, 't', 0.0))
                finished = getattr(ep, 't', 0.0) >= DURATION - DT / 2
                result = dict(task_id=TASK, variant='baseline' if args.baseline else args.variant, title=model['title'], plan=plan, source_plan=source_plan,
                              steps=steps, duration=getattr(ep, 't', 0.0), physics_hz=PHYSICS_HZ, control_hz=60,
                              video_fps=None if args.physics_only else FPS, status='error' if error else ('interrupted' if not finished else ('diagnostic_completed' if args.diagnostic_duration is not None else 'completed_budget')),
                              stop_reason='runtime_error' if error else ('interrupted' if not finished else f'{DURATION:g}_second_budget'), error=error,
                              goal_reached=getattr(ep, 'goal', None), metrics=metrics,
                              physical_safety_conditions_met=None if metrics is None or error or not finished else not any(metrics[k] for k in ['human_fallen', 'head_contact', 'chassis_human_contact']),
                              human_model=model['human_model'], limitations=model['limitations'],
                              visual_assets=getattr(getattr(ep, 'visuals', None), 'manifest', None),
                              rendering=getattr(ep, 'rendering', None),
                              capture_frame_count=getattr(ep, 'capture_count', 0),
                              last_encoded_physics_time_s=getattr(ep, 'last_capture_t', None),
                              physical_parameters=model['physical_parameters'], spec=model,
                              native_spec=getattr(ep,'spec',{}), native_ik=getattr(ep,'ik_records',[]),
                              controller_interventions=getattr(ep, 'events', []), goal_definition='Pelvis above 0.88 m, torso tilt below 20 degrees, pelvis speed below 0.20 m/s and both feet in measured floor contact for one continuous second.',
                              source_sha256=hashes, initial_state_sha256=getattr(ep, 'initial', {}).get('state_sha256'),
                              runtime=dict(wall_seconds=time.perf_counter() - started, python=sys.version,
                                           omnigibson=getattr(og, '__version__', None), requested_isaac_sim='6.0.1',
                                           physics_only=args.physics_only, draft=args.draft))
                dump(output / 'trace.json', getattr(ep, 'trace', [])); dump(output / 'result.json', result)
            finally:
                if og is not None: og.shutdown()
    if error: raise SystemExit(1)


if __name__ == '__main__':
    main()
