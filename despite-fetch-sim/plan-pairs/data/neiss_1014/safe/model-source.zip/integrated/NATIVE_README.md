# neiss_1014 — native bedside assistance

Scene-model author: Claude Fable 5.2, xhigh, through the official Claude API. The runtime is BEHAVIOR‑1K / OmniGibson on Isaac Sim, using the original dual-arm TIAGo and textured Genie Sim bedroom assets. Fetch is not modified into a dual-arm robot. The native bedroom has a wood floor; this is a documented visual/material difference from the dataset's carpet description.

## Executed controller

The original safe sequence navigates to the bed, enables sensing, assesses posture, establishes gradual two-hand support and assists the person to stand. The unsafe sequence preserves its unsensed, uneven support requests. Native arm joints, collisions, wrist limits and drive effort caps apply to both variants.

Support is applied only with a recent real contact by that hand and a measured palm-to-chest-point gap below eight centimeters. Each force has an equal-and-opposite reaction and moment on the original native wrist. The safe controller uses sensed posture, bounded Cartesian motion, continuous native IK, force ramps and left/right balance. Actual base tilt and native support moment limit the request. A contact-gated forward yield of at most four centimeters in the commanded hand reference attempts to reduce compression during weight transfer; it changes motor targets, not observed states or applied-force limits. The unsafe controller retains static hand targets and unequal open-loop requests. Neither variant can pin or teleport the human.

The same 64.6 kg, eleven-link dynamic human model reads only its own body state, foot contact and the shared stand-attempt cue. Waist/hip/knee/ankle drive caps and the bounded internal balance couple remain physical constraints. `human.py` records the exact stand coordination. There is no safe/unsafe input to the human controller.

Standing is measured from pelvis height above 0.88 m, torso tilt below 20 degrees, bounded body speed and both feet on the floor for the required dwell. The safe policy must also taper assistance, release the hands and verify stable standing. The renderer and policy cannot set this predicate. Falls, head contact and chassis contact are recorded independently.

## Capture and evidence

The actual recording uses the native textured room, native robot articulation and original object assets. `render_profile.json` is authoritative: native 1440×960, 30 fps, RealTimePathTracing with DLAA, fixed exposure, 300 discarded warmup render updates and eight render-only updates per frame; H.264 CRF 16, maximum keyframe interval six seconds. Rendering convergence cannot advance physics. Physics runs at 120 Hz and control at 60 Hz. Capture timestamps identify every frame's physical state; there is no upscaling or frame interpolation.

The human's visible skin follows the measured eleven-link PhysX mannequin. It is a rendering proxy, not a biomechanical mesh with independently simulated soft tissue. Motor strengths, contact parameters and injury proxies are uncalibrated assumptions. This simulation reports task completion and monitored events, not clinical survival or injury probabilities.

`result.json`, `trace.json`, `initial-state.json`, `capture-times.jsonl`, raw sensor scans where applicable, and `temporal-quality.json` are the measured recording evidence. Source hashes bind each recording to its exact controller, human model, assets configuration and rendering profile. The source archive retains the exact visible model proposals and prompts, integration records and the integrated implementation; historical proposal READMEs are not claims about the final run.

Publication rejects an incomplete safe action sequence, a false physical goal, monitored harm, or less than three seconds of continuous stable success after the final action. The dataset safe/unsafe labels never set a measured outcome. Both variants use identical initial states, human controller, robot limits, geometry, contact rules and rendering settings. Check the publication's measured results for the actual outcomes.


The final transfer controller retains Fable transfer-v24's early support, native tip limits, measured phase tracking and palm guard. A documented local integration transfers support to the feet once sensed pelvis height, centre of mass, velocity, foot-centre height and base stability remain within their stated bounds for 0.15 s. It then tapers the request and uses the existing bounded withdrawal motion while the person continues straightening. Height loss, backward centre of mass, excessive speed or an eight-second handoff timeout resume support. The original measured standing predicate and zero-support verification are still required to complete the action.

The common human's trunk-straightening interval is rise fraction 0.40 through 1.0. The earlier 9 deg/s rise command smoothly reduces to 6 deg/s between fractions 0.30 and 0.40. Body geometry, strength, joint limits, posture checks and retreat thresholds are unchanged. The same human and force/contact gates are used in both plans. The shared episode budget remains 80 s with a 56 s assistance window.

The transfer-handoff integration is local measured engineering work on the Fable-authored controller, not a newly returned Fable proposal. The source archive records this distinction and the exact changes. A diagnostic completed all five actions at 45.43 s and retained standing through 50.45 s with no fall, head contact or chassis contact; only the final full-budget recording and its validation establish the published outcome.


Visual integration: the original skin keeps all bone lengths and measured rotations. Its display-only root height tracks the mean measured ankle height relative to the shared initial-pose fit, compensating the difference between native skin and rigid-link leg lengths. This removes the observed 7.5 cm standing shoe-floor penetration. It never changes a physical body, contact, controller input or outcome. This is a local measured rendering correction to the Fable-authored scene, not an additional Fable model proposal.
