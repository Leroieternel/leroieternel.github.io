# neiss_1014 bedside stand repair (round 3)

Nothing in this revision has been executed. The numbers are hand statics from the layout and your traces; they are predictions to check.

## What your two diagnostics showed

- Seated lean with pelvis 0 and waist 40 deg works: feet stay down and the lean completes.
- The rise then stalls, for two reasons:
  1. With pelvis 0 and torso 40 deg, the weight above the knees needs about 135 N m at the knees with no help. The cap is 120 N m. It only fits with roughly 80 N per hand of real hold.
  2. The robot did not deliver that. Above about 45 N the hands sagged, the palms tilted and the gate cycled. My reading is wrist saturation: the 18 deg force line passes about 6 cm from the wrist, which gives about 3 to 5 N m against wrist caps of 3 and 6.6 N m.

## The repair

**human.py (shared, no plan input, all caps and limits unchanged)**

- Seated lean is waist only: `PELVIS_LEAN_DEG = 0`, `TORSO_LEAN_DEG = 40`.
- The first 8 percent of the rise rocks the pelvis forward 14 deg by hip flexion (`PELVIS_ROCK_DEG`, `TORSO_ROCK_DEG = 50`, waist 36 deg). After that, knees and hips extend as before.
  - Why this should not lift the legs this time: with the trunk already flexed 40 deg, rocking the pelvis over its front seat edge costs about 8 N m. Lifting the legs costs about 63 N m. Upright, the two were 65 against 63, which is why the legs lifted before.
  - The hips are no longer driven into extension at seat-off, so they should not rock the pelvis backward the way your trace showed (pelvis -2 deg).
- Neck pitches back by 0.7 of the trunk lean (max 40 deg, cap 8 N m unchanged) so the head stays about 8 cm further from the robot at 50 deg lean.
- Lean anti-windup now uses the waist's own tracking, so a pelvis offset cannot freeze the lean.
- After a failed attempt the controller re-checks posture in `ready` before trying again.
- Waist trim maximum is 4 deg (was 6), so the trunk stays under 54 deg.

**native_policy.py (safe plan only; unsafe is byte-for-byte the same behaviour)**

- Each hand's force is aimed from the chest support point through that hand's wrist, in the sagittal plane, elevation limited to 0 to 18 deg and rate limited. This removes most of the wrist moment and the downward pull on the arm.
  - The wrist is estimated as 0.15 m behind the reported hand frame (`support_alignment.wrist_behind_palm_m`). If you add `wrist_position_m` to each hand observation, the policy uses that instead.
- Bounded integral compensation of measured vertical hand sag while in contact (max 5 cm).
- `com_reference_from_ankle_m` is -0.03 (was -0.01), which lowers the request by about 10 N per hand.
- `abort_tilt_deg` is 62 (was 58), because the planned trunk lean is now 50 deg.
- Caps, ramps, gates, 40 N balance limit, window and deadlines are unchanged. Unsafe keeps 150 N and 50 N along the fixed 18 deg direction with static hands.

## Predicted budget at seat-off

| Quantity | Round 2 (pelvis 0, torso 40) | Now (pelvis 14, torso 50) | Limit |
|---|---|---|---|
| CoM behind ankle | 0.21 m planned (0.222 measured) | 0.15 to 0.18 m | heel is 0.08 m behind ankle |
| Knee torque, no hold | 135 N m | 113 N m | 120 N m |
| Knee torque, 45 N per hand | about 117 N m | about 98 N m | 120 N m |
| Hold for centre of pressure at heel | 54 N per hand | about 27 to 35 N per hand | 90 N policy cap |
| Hold for the -0.03 m reference | 75 N per hand | about 45 to 55 N per hand | 90 N policy cap |
| Hip torque | 75 N m | about 80 N m | 120 N m |
| Waist torque | 56 N m | about 70 N m | 90 N m |

The planned centre of mass passes the heel at about 30 percent of the rise. From there the body is statically self-supporting and the request falls toward zero.

## Risks to check in the first physics-only safe run

- **Pelvis rock.** `measured_pitch_deg.pelvis` should reach 10 to 14 deg within about 1.5 s of `mode == 'rise'`, with both feet in contact and thigh elevation following to about 5 deg. If the feet lift instead, the controller retreats; lower `PELVIS_ROCK_DEG` to 8.
- **Torso against thighs.** If torso and thigh links collide with each other, the 40 deg waist lean is already at that limit and the rock changes nothing there (waist goes to 36 deg).
- **Fall or tilt thresholds.** Trunk tilt reaches 50 to 54 deg for about 2 s. If the runner flags a fall near that, set `TORSO_ROCK_DEG` to 46.
- **Head clearance.** Head front is predicted near x = 0.66 m at 1.3 m height during the rock. Check `head_contact` stays false.
- **Force alignment.** `assist_state.force_elevation_rad` should settle near 0 to 0.1 rad. Applied force should then follow `level_N` without the 0.7 s dropouts, and palm tilt should stay under about 3 deg. If the hands still sag, tune `wrist_behind_palm_m` between 0.10 and 0.20 or supply `wrist_position_m`.
- **Foot friction.** Seat-off needs a foot friction coefficient of about 0.3.

## Not done

- I did not tuck the feet. The shins sit at the bed edge and I do not know the bed geometry.
- I did not raise any cap or request, pin anything, or change the standing goal.

## Boundaries kept

Original action names and order, native TIAGo and its limits, human masses, geometry, joints, limits and drive caps, shared human controller with no plan or robot-force input, contact and gap gates, equal and opposite reaction, 160 N per hand engine cap, unchanged unsafe requests, unchanged goal.
