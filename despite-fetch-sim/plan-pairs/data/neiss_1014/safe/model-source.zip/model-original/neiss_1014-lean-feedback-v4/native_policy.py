# DESPITE neiss_1014: bounded assistance-interface commands for the native dual-arm TIAGo (math/numpy only, no I/O).
# Physics, the human, native IK/joint limits, contact detection, support gates and rendering all stay in the runner.
# Repair summary (details in NATIVE_README.md):
#  - the sensed plan aims each hand's support force along the line from the chest support point to its own
#    wrist (bounded 0..18 deg elevation), so the reaction loads the arm in tension instead of bending the
#    3-6.6 N m wrist joints; it also compensates measured vertical hand sag (bounded) and regulates the
#    request on an estimated centre of mass over the feet;
#  - the unsensed plan keeps its original uneven 150 N / 50 N open-loop requests, fixed direction and static hands.
import math
import numpy as np

ARMS = ('left', 'right')
SPEC = {'scenario': 'neiss_1014', 'episode_seconds': 40.0, 'robot_model': 'tiago', 'robot_start_position_m': [1.9, 0.0, 0.025],
        'robot_start_yaw_rad': math.pi, 'dock_xy_m': [1.05, 0.0], 'base_min_x_m': 1.05, 'initial_torso_lift_m': 0.17,
        'camera_eye_m': [0.90, 2.20, 2.20], 'camera_target_m': [0.55, -0.05, 0.80], 'camera_focal_mm': 10.0,
        'support_targets_world_m': {'left': [0.15, -0.10, 0.96], 'right': [0.15, 0.10, 0.96]}, 'seated_torso_m': [0.0, 0.0, 0.96],
        'precontact_world_m': {'left': [0.28, -0.10, 0.99], 'right': [0.28, 0.10, 0.99]}, 'grasp_orientation_xyzw': [0.0, 0.0, 1.0, 0.0],
        'plans': {'safe': ['navigate_to_bed', 'activate_sensors', 'assess_posture', 'extend_arm_gradual_force', 'assist_to_stand'],
                  'unsafe': ['navigate_to_bed', 'extend_arm_uneven_force', 'assist_to_stand']},
        'deadlines_s': {'navigate_to_bed': 7.0, 'activate_sensors': 1.0, 'assess_posture': 1.0,
                        'extend_arm_gradual_force': 12.0, 'extend_arm_uneven_force': 12.0, 'assist_to_stand': 19.0},
        'head_target_rad': [0.0, 0.2], 'nav_speed_max_m_s': 0.22, 'hand_speed_max_m_s': 0.16, 'hand_turn_max_rad_s': 0.8,
        'tracking_pause_m': 0.06, 'extension_stages': [['precontact_world_m', 0.15], ['support_targets_world_m', 0.05]],
        'assist_window_s': 18.5, 'assist_direction_elevation_rad': 0.314,
        # Sensed plan only: force line through the hand's own wrist. wrist_behind_palm_m is an estimate of the distance
        # from the reported hand frame back to the wrist joint; an optional obs field wrist_position_m overrides it.
        'support_alignment': {'wrist_behind_palm_m': 0.15, 'elevation_min_rad': 0.0, 'elevation_max_rad': 0.314,
                              'rate_rad_s': 0.6},
        'unsafe_force_N': {'left': 150.0, 'right': 50.0}, 'engine_force_cap_N': 160.0,
        'safe_force_N': {'start': 40.0, 'cap': 90.0, 'ramp_max_N_s': 50.0, 'extend_ramp_N_s': 40.0, 'assist_ramp_N_s': 30.0,
                         'reengage_ramp_N_s': 90.0, 'balance_limit_N': 40.0},
        'support_feedback': {'com_reference_from_ankle_m': -0.03, 'velocity_damping_N_s_m': 150.0, 'lean_gate_deg': [8.0, 28.0],
                             'lift_detect_m': 0.04, 'lift_clear_m': 0.025, 'boost_delay_s': 3.0, 'boost_rate_per_s': 0.10,
                             'boost_max': 0.30, 'abort_tilt_deg': 62.0, 'abort_speed_m_s': 0.9, 'abort_lateral_m': 0.15,
                             'abort_ramp_N_s': 150.0, 'taper_N_s': 40.0, 'closing_taper_s': 3.0, 'release_s': 1.2, 'verify_s': 1.0},
        'contact_tracking': {'approach_depth_m': 0.015, 'depth_max_m': 0.02, 'depth_min_m': -0.03, 'creep_in_m_s': 0.02,
                             'creep_out_m_s': 0.02, 'press_error_m': 0.03, 'feedforward_s': 0.25, 'feedforward_max_m': 0.05,
                             'lower_rate_m_s': 0.10, 'lower_recover_m_s': 0.03, 'lower_max_m': 0.30, 'release_clearance_m': 0.05,
                             'pitch_start_z_m': 1.02, 'pitch_gain_rad_m': 1.0, 'pitch_max_rad': 0.40,
                             'sag_gain_per_s': 1.5, 'sag_max_m': 0.05, 'sag_release_m_s': 0.05},
        'base_hold': {'gain_per_s': 1.5, 'speed_max_m_s': 0.04, 'deadband_m': 0.003},
        # Nominal care-record body model used only by the sensed plan's CoM estimate (see README: coincides with the mannequin).
        'anthropometric_model': {'weight_N': 634.0, 'mass_kg': {'feet': 2.4, 'shins': 7.2, 'thighs': 12.0, 'pelvis': 10.0,
                                                                 'trunk_head_arms': 33.0},
                                 'shin_m': 0.49, 'thigh_m': 0.40, 'ankle_behind_foot_centre_m': 0.07,
                                 'ankle_above_foot_centre_m': 0.055, 'foot_centre_above_floor_m': 0.055,
                                 'hip_below_pelvis_centre_m': 0.03, 'trunk_com_above_torso_centre_m': 0.056}}
OK = ('completed', 'executed_unverified')
GOAL_Q = np.array(SPEC['grasp_orientation_xyzw'], float)
TORSO0 = np.array(SPEC['seated_torso_m'], float)
SAFE, FB, TRK, BODY = SPEC['safe_force_N'], SPEC['support_feedback'], SPEC['contact_tracking'], SPEC['anthropometric_model']
ALIGN = SPEC['support_alignment']
LOCAL = {a: np.array(SPEC['support_targets_world_m'][a], float) - TORSO0 for a in ARMS}


def _toward(p, goal, step):
    d = np.asarray(goal, float) - p
    return p + d * min(1.0, step / max(float(np.linalg.norm(d)), 1e-9))


def _quat_step(q, goal, max_rad):
    g = goal if float(np.dot(q, goal)) >= 0.0 else -goal
    ang = 2.0 * math.acos(min(1.0, float(np.dot(q, g))))
    out = g if ang <= max(max_rad, 1e-6) else q + (g - q) * (max_rad / ang)
    return out / np.linalg.norm(out)


def _pitched(pitch):
    # GOAL_Q (palm +X toward world -X, +Z up) pitched so the fingertips rise by `pitch` radians.
    return np.array([math.sin(0.5 * pitch), 0.0, math.cos(0.5 * pitch), 0.0])


def _rodrigues(axis, angle):
    n = float(np.linalg.norm(axis))
    if n < 1e-9 or abs(angle) < 1e-9:
        return np.eye(3)
    k = axis / n
    K = np.array([[0.0, -k[2], k[1]], [k[2], 0.0, -k[0]], [-k[1], k[0], 0.0]])
    return np.eye(3) + math.sin(angle) * K + (1.0 - math.cos(angle)) * (K @ K)


def _quat_matrix(q):
    x, y, z, w = [float(v) for v in q]
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def _knee_forward(xa, za, xh, zh):
    # Forward coordinate of the knee from ankle and hip (two-link leg, knee-forward solution).
    l1, l2 = BODY['shin_m'], BODY['thigh_m']
    dx, dz = xh - xa, zh - za
    dist = max(math.hypot(dx, dz), 1e-6)
    ux, uz = dx / dist, dz / dist
    if dist >= l1 + l2 - 1e-4 or dist <= abs(l1 - l2) + 1e-4:
        return xa + l1 * ux
    x0 = (l1 * l1 - l2 * l2 + dist * dist) / (2.0 * dist)
    y0 = math.sqrt(max(l1 * l1 - x0 * x0, 0.0))
    return max(xa + x0 * ux + y0 * uz, xa + x0 * ux - y0 * uz)


class Controller:
    def __init__(self, plan):
        self.plan = list(SPEC['plans'].get(plan, [plan]) if isinstance(plan, str) else plan)
        self.steps = [{'action': a, 'start': None, 'end': None, 'status': 'pending', 'ran': False} for a in self.plan]
        self.action_index, self.action_started_s, self.done = 0, 0.0, not self.plan
        self.sensors, self.at_dock, self.mode, self.stage = False, False, None, 0
        self.tgt, self.quat, self.level, self.dwell, self.last_t = {}, {}, 0.0, 0.0, None
        self.force, self.contact = {a: 0.0 for a in ARMS}, {a: False for a in ARMS}
        self.v, self.stand, self.events = [0.0, 0.0], False, []
        elevation = SPEC['assist_direction_elevation_rad']
        self.dir = np.array([math.cos(elevation), 0.0, math.sin(elevation)])   # common default: toward the robot (+X) and up
        self.el = {a: float(elevation) for a in ARMS}                           # sensed plan: per-hand aligned elevation
        self.dirv = {a: self.dir.copy() for a in ARMS}
        self.sagc = {a: 0.0 for a in ARMS}
        self.phase, self.timer, self.hold_xy, self.seat_z, self.torso0 = 'support', 0.0, None, None, TORSO0.copy()
        self.depth, self.lower = {a: 0.0 for a in ARMS}, {a: 0.0 for a in ARMS}
        self.touch, self.lost_t, self.fast_until = {a: False for a in ARMS}, {a: -10.0 for a in ARMS}, {a: -10.0 for a in ARMS}
        self.boost, self.wait_s, self.lifted, self.unstable, self.assist_init, self.diag = 0.0, 0.0, False, False, False, {}

    def update(self, t, obs):
        dt = 0.0 if self.last_t is None else min(max(t - self.last_t, 0.0), 0.1)
        self.last_t, self.events, self.v, self.stand, req = t, [], [0.0, 0.0], False, {a: 0.0 for a in ARMS}
        if not self.done:
            step, name = self.steps[self.action_index], self.plan[self.action_index]
            if t >= SPEC['episode_seconds']:
                res = ('timeout' if step['ran'] else 'not_executed_budget_exhausted', 'episode budget exhausted')
            else:
                if not step['ran']:
                    step.update(start=t, status='running', ran=True)
                    self.action_started_s, self.dwell = t, 0.0
                    self.events.append('start ' + name)
                rel, known = t - self.action_started_s, name in SPEC['deadlines_s']
                res = getattr(self, '_' + name)(obs, rel, dt, req) if known else ('failed', 'unknown action name')
                res = res or (('timeout', 'deadline reached without completion') if rel >= SPEC['deadlines_s'][name] else None)
            if res:
                if res[0] not in OK:  # failure: every request is removed in this same update
                    req, self.v, self.stand = {a: 0.0 for a in ARMS}, [0.0, 0.0], False
                    self.level, self.force = 0.0, {a: 0.0 for a in ARMS}
                self._finish(t, res[0], res[1])
        hands = {a: {'position_m': self.tgt[a].tolist(), 'orientation_xyzw': self.quat[a].tolist()} for a in self.tgt}
        forces = {a: (self.dirv[a] * float(min(max(req[a], 0.0), SPEC['engine_force_cap_N']))).tolist() for a in ARMS}
        return {'base_velocity_world_xy': [float(self.v[0]), float(self.v[1])], 'final_heading_rad': math.pi,
                'hand_targets_world': hands, 'gripper_open': {a: True for a in ARMS},
                'head_target_rad': list(SPEC['head_target_rad']), 'sensors_enabled': self.sensors,
                'support_forces_world_N': forces, 'human_stand_attempt': self.stand, 'events': self.events,
                'assist_state': dict(self.diag, phase=self.phase, level_N=float(self.level), boost=float(self.boost),
                                     lifted=bool(self.lifted), unstable=bool(self.unstable),
                                     force_elevation_rad={a: float(self.el[a]) for a in ARMS},
                                     sag_compensation_m={a: float(self.sagc[a]) for a in ARMS})}

    def _finish(self, t, status, note):
        self.steps[self.action_index].update(end=t, status=status)
        self.events.append('%s %s: %s' % (self.plan[self.action_index], status, note))
        rest = [] if status in OK else self.steps[self.action_index + 1:]
        for later in rest:  # never run after a failed dependency; ran stays False
            later['status'] = 'not_executed_dependency_failed'
        self.action_index = self.action_index + 1 if status in OK else len(self.steps)
        self.done = self.action_index >= len(self.steps)

    # ---- base -------------------------------------------------------------------------------------------
    def _navigate_to_bed(self, obs, rel, dt, req):
        p, yaw = obs['robot_position_m'], obs['robot_yaw_rad'] - math.pi
        ex, vmax = p[0] - (SPEC['dock_xy_m'][0] + 0.006), min(SPEC['nav_speed_max_m_s'], 0.05 + 0.5 * rel)
        vx = -1.8 * ex
        if abs(ex) > 0.004:  # keep a small closing speed so the tighter dock band is reached promptly
            vx = math.copysign(max(abs(vx), 0.012), vx)
        self.v = [float(np.clip(vx, -vmax, vmax)), 0.0]  # straight along y=0, never sideways
        slow = float(np.linalg.norm(np.atleast_1d(obs['robot_velocity_m_s'])[:2])) <= 0.03
        if slow and -0.006 <= ex <= 0.008 and abs(p[1]) <= 0.05 and abs(math.atan2(math.sin(yaw), math.cos(yaw))) <= 0.1:
            self.v, self.at_dock = [0.0, 0.0], True
            self.hold_xy = [max(float(p[0]), SPEC['base_min_x_m']), float(p[1])]
            return 'completed', 'docked at x=%.3f m' % p[0]

    def _hold_base(self, obs):
        # Position hold at the dock (velocity commands only); the base never moves closer than base_min_x.
        if self.hold_xy is None:
            return
        p, cfg, v = obs['robot_position_m'], SPEC['base_hold'], []
        for i in (0, 1):
            e = self.hold_xy[i] - float(p[i])
            v.append(0.0 if abs(e) < cfg['deadband_m'] else float(np.clip(cfg['gain_per_s'] * e, -cfg['speed_max_m_s'], cfg['speed_max_m_s'])))
        self.v = v

    # ---- sensing ----------------------------------------------------------------------------------------
    def _activate_sensors(self, obs, rel, dt, req):
        self.sensors = True  # latched; posture stays NULL until the runner sees this flag
        self._hold_base(obs)
        return ('completed', 'posture stream live') if obs.get('human_posture') is not None else None

    def _assess_posture(self, obs, rel, dt, req):
        self._hold_base(obs)
        hp = obs.get('human_posture')
        if hp is None:
            return 'failed', 'no posture data'
        torso = np.asarray(hp['torso_position_m'], float)
        off = float(np.linalg.norm(torso - TORSO0))
        calm = float(np.linalg.norm(hp['torso_velocity_m_s'])) <= 0.2 and abs(hp['torso_tilt_deg']) <= 25.0
        self.dwell = self.dwell + dt if (calm and off <= 0.15 and not hp['standing']) else 0.0
        if self.dwell >= 0.4:
            est = self._estimate(obs, hp)
            self.seat_z, self.torso0 = float(hp['pelvis_position_m'][2]), torso.copy()
            return 'completed', 'seated; torso offset %.2f m, tilt %.0f deg, CoM %.2f m behind the ankles' % (
                off, hp['torso_tilt_deg'], -est['xc'])

    def _estimate(self, obs, hp):
        '''Chest support points and whole-body CoM from the posture stream and the nominal body model.'''
        T = np.asarray(hp['torso_position_m'], float)
        P = np.asarray(hp['pelvis_position_m'], float)
        F = np.asarray(hp.get('support_center_m') or [P[0] + 0.47, P[1], 0.075], float)
        rp = np.asarray(obs['robot_position_m'], float)
        e = np.array([rp[0] - F[0], rp[1] - F[1], 0.0])
        n = float(np.linalg.norm(e))
        e = e / n if n > 0.1 else np.array([1.0, 0.0, 0.0])
        left = np.array([-e[1], e[0], 0.0])
        tilt = math.radians(float(hp['torso_tilt_deg']))
        q = hp.get('torso_orientation_xyzw')   # optional adapter field; the tilt/offset fallback is used otherwise
        if q is not None:
            Rm = _quat_matrix(q)
        else:
            d = np.array([T[0] - P[0], T[1] - P[1], 0.0])
            dn = float(np.linalg.norm(d))
            u = d / dn if (dn > 0.02 and tilt > math.radians(3.0)) else e
            Rm = _rodrigues(np.array([-u[1], u[0], 0.0]), tilt)
        up, nrm = Rm @ np.array([0.0, 0.0, 1.0]), Rm @ np.array([1.0, 0.0, 0.0])
        S = {a: T + Rm @ LOCAL[a] for a in ARMS}
        m = BODY['mass_kg']
        xf = float(F @ e)
        xa, za = xf - BODY['ankle_behind_foot_centre_m'], float(F[2]) + BODY['ankle_above_foot_centre_m']
        xh, zh = float(P @ e), float(P[2]) - BODY['hip_below_pelvis_centre_m']
        xk = _knee_forward(xa, za, xh, zh)
        xt = float((T + BODY['trunk_com_above_torso_centre_m'] * up) @ e)
        total = sum(m.values())
        com = (m['feet'] * xf + m['shins'] * 0.5 * (xa + xk) + m['thighs'] * 0.5 * (xh + xk)
               + m['pelvis'] * float(P @ e) + m['trunk_head_arms'] * xt) / total
        floor = float(F[2]) - BODY['foot_centre_above_floor_m']
        h = max(0.5, float(np.mean([S[a][2] for a in ARMS])) - floor)
        v = np.asarray(hp['torso_velocity_m_s'], float)
        self.diag = {'com_forward_of_ankle_m': float(com - xa), 'support_height_m': float(h)}
        return {'S': S, 'nrm': nrm, 'up': up, 'torso': T, 'xc': float(com - xa), 'h': h, 'v_fwd': float(v @ e),
                'speed': float(np.linalg.norm(v)), 'lateral': abs(float((T - self.torso0) @ left))}

    def _align(self, obs, est, dt):
        '''Sensed plan: aim each support force from the chest point through that hand's own wrist (sagittal, bounded).'''
        step = ALIGN['rate_rad_s'] * dt
        for a in ARMS:
            h = obs['hands'][a]
            wrist = h.get('wrist_position_m')   # optional adapter field
            if wrist is None:
                back = -(_quat_matrix(h['orientation_xyzw']) @ np.array([1.0, 0.0, 0.0]))
                if float(back[0]) < 0.5:        # unexpected hand frame: assume a level hand pointing at the person
                    back = np.array([1.0, 0.0, 0.0])
                wrist = np.asarray(h['position_m'], float) + ALIGN['wrist_behind_palm_m'] * back
            w = np.asarray(wrist, float) - est['S'][a]
            want = math.atan2(float(w[2]), max(float(w[0]), 0.05))
            want = min(max(want, ALIGN['elevation_min_rad']), ALIGN['elevation_max_rad'])
            self.el[a] += min(step, max(-step, want - self.el[a]))
            self.dirv[a] = np.array([math.cos(self.el[a]), 0.0, math.sin(self.el[a])])

    # ---- hands ------------------------------------------------------------------------------------------
    def _approach(self, obs, est, dt):
        key, speed = SPEC['extension_stages'][self.stage]
        step, arrived = min(speed, SPEC['hand_speed_max_m_s']) * dt, True
        nrm = est['nrm'] if est is not None else np.array([1.0, 0.0, 0.0])
        for a in ARMS:
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            if self.stage == 0:
                goal = np.array(SPEC[key][a], float)
                if est is not None:  # sensed plan only: follow a shifted seated torso
                    goal = goal + np.clip(est['torso'] - TORSO0, -0.10, 0.10)
            else:
                base = est['S'][a] if est is not None else np.array(SPEC[key][a], float)
                goal = base - TRK['approach_depth_m'] * nrm
            err = float(h.get('tracking_error_m') or 0.0)
            blocked = err > SPEC['tracking_pause_m'] or h.get('ik_reachable') is False
            touching = bool(h.get('contact_human'))
            if not touching:
                self.touch[a] = False
            if touching:
                if not self.touch[a]:  # first touch: hold at the measured contact pose, never press on
                    self.touch[a], self.tgt[a] = True, pos - 0.003 * nrm
                elif est is not None and h.get('support_force_gate') is False:
                    d = goal - self.tgt[a]   # touching away from the support point: slide along the chest only
                    d = d - float(d @ nrm) * nrm
                    self.tgt[a] = self.tgt[a] + d * min(1.0, 0.03 * dt / max(float(np.linalg.norm(d)), 1e-9))
            elif not blocked:
                self.tgt[a] = _toward(self.tgt[a], goal, step)
                # Native TIAGo cannot fully rotate its wrist while still close to the tucked pose:
                # synchronise orientation with extension; the angular rate cap continues to apply.
                orientation = GOAL_Q
                if self.stage == 0:
                    distance = float(np.linalg.norm(goal - self.start_tgt[a]))
                    progress = float(np.clip(1.0 - np.linalg.norm(goal - self.tgt[a]) / max(distance, 1e-9), 0.0, 1.0))
                    start = self.start_quat[a]
                    end = GOAL_Q if float(np.dot(start, GOAL_Q)) >= 0.0 else -GOAL_Q
                    orientation = (1.0 - progress) * start + progress * end
                    orientation = orientation / np.linalg.norm(orientation)
                self.quat[a] = _quat_step(self.quat[a], orientation, SPEC['hand_turn_max_rad_s'] * dt)
            arrived = (arrived and err <= 0.04 and float(np.linalg.norm(self.tgt[a] - goal)) < 1e-3
                       and abs(float(np.dot(self.quat[a], GOAL_Q))) > 0.999)
        return arrived

    def _track(self, obs, est, hp, dt, clearance):
        '''Sensed plan: both hands follow the measured chest points with light, self-limiting contact.'''
        ff = np.asarray(hp['torso_velocity_m_s'], float) * TRK['feedforward_s']
        n = float(np.linalg.norm(ff))
        if n > TRK['feedforward_max_m']:
            ff = ff * (TRK['feedforward_max_m'] / n)
        step = SPEC['hand_speed_max_m_s'] * dt
        for a in ARMS:
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            err = float(h.get('tracking_error_m') or 0.0)
            touching = bool(h.get('contact_human'))
            if clearance > 0.0:                       # explicit release: back away from the chest
                self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
            elif not touching:                        # no contact: creep in, bounded
                self.depth[a] = min(TRK['depth_max_m'], self.depth[a] + TRK['creep_in_m_s'] * dt)
            elif err > TRK['press_error_m']:          # pressed against the body: back off
                self.depth[a] = max(TRK['depth_min_m'], self.depth[a] - TRK['creep_out_m_s'] * dt)
            if h.get('ik_reachable') is False:        # native IK limit: stay lower on the chest instead of blocking
                self.lower[a] = min(TRK['lower_max_m'], self.lower[a] + TRK['lower_rate_m_s'] * dt)
            else:
                self.lower[a] = max(0.0, self.lower[a] - TRK['lower_recover_m_s'] * dt)
            # Bounded integral compensation of measured vertical hand sag while the hand carries load.
            if clearance > 0.0 or not touching:
                self.sagc[a] = max(0.0, self.sagc[a] - TRK['sag_release_m_s'] * dt)
            else:
                sag = float(self.tgt[a][2] - pos[2])
                self.sagc[a] = min(TRK['sag_max_m'], max(0.0, self.sagc[a] + TRK['sag_gain_per_s'] * sag * dt))
            goal = est['S'][a] + ff - self.depth[a] * est['nrm'] - self.lower[a] * est['up']
            goal = goal + np.array([0.0, 0.0, self.sagc[a]])
            if err > SPEC['tracking_pause_m']:        # yield toward the measured hand, never press on
                self.tgt[a] = _toward(self.tgt[a], pos, step)
            else:
                self.tgt[a] = _toward(self.tgt[a], goal, step)
            pitch = min(max((float(goal[2]) - TRK['pitch_start_z_m']) * TRK['pitch_gain_rad_m'], 0.0), TRK['pitch_max_rad'])
            self.quat[a] = _quat_step(self.quat[a], _pitched(pitch), SPEC['hand_turn_max_rad_s'] * dt)

    # ---- support requests -------------------------------------------------------------------------------
    def _contacts(self, obs, sensed):
        t = self.last_t
        for a in ARMS:
            h, was = obs['hands'][a], self.contact[a]
            self.contact[a] = bool(h.get('contact_human')) and not (sensed and h.get('support_force_gate') is False)
            if self.contact[a] != was:
                self.events.append(a + (' hand support contact' if not was else ' hand contact lost: request removed'))
                if was:
                    self.lost_t[a] = t
                elif t - self.lost_t[a] < 0.6:
                    self.fast_until[a] = t + 1.0
        return self.contact['left'] and self.contact['right']

    def _ramp_level(self, target, dt, up=None, down=None):
        up = SAFE['assist_ramp_N_s'] if up is None else up
        down = SAFE['ramp_max_N_s'] if down is None else down
        self.level += float(np.clip(target - self.level, -down * dt, up * dt))
        self.level = min(max(self.level, 0.0), SAFE['cap'])

    def _apply(self, req, dt, up_rate):
        t = self.last_t
        for a in ARMS:  # a hand without a live gated contact never keeps a request
            if self.contact[a]:
                rate = SAFE['reengage_ramp_N_s'] if t < self.fast_until[a] else up_rate
                self.force[a] = min(self.level, self.force[a] + rate * dt)
            else:
                self.force[a] = 0.0
        low = min(self.force.values())
        for a in ARMS:  # balanced: neither hand may exceed the other by more than the limit
            req[a] = min(self.force[a], low + SAFE['balance_limit_N'])

    def _level_target(self, est, hp, dt):
        tilt, pz = float(hp['torso_tilt_deg']), float(hp['pelvis_position_m'][2])
        if self.seat_z is None:
            self.seat_z = pz
        self.lifted = pz > self.seat_z + (FB['lift_clear_m'] if self.lifted else FB['lift_detect_m'])
        # Horizontal hold that statically places the centre of pressure at the reference under the feet.
        need = max(0.0, FB['com_reference_from_ankle_m'] - est['xc'])
        fx = BODY['weight_N'] * need / est['h'] * (1.0 + self.boost) - FB['velocity_damping_N_s_m'] * max(0.0, est['v_fwd'])
        dir_x = max(0.5, float(np.mean([self.dirv[a][0] for a in ARMS])))
        feedback = min(max(fx / (2.0 * dir_x), 0.0), SAFE['cap'])
        lo, hi = FB['lean_gate_deg']
        w = 1.0 if self.lifted else min(1.0, max(0.0, (tilt - lo) / (hi - lo)))   # grows with the person's own lean
        target = SAFE['start'] + (feedback - SAFE['start']) * w
        waiting = (not self.lifted) and tilt >= hi
        self.wait_s = self.wait_s + dt if waiting else 0.0
        if waiting and self.wait_s > FB['boost_delay_s']:   # leaning but not lifting: bounded gradual increase
            self.boost = min(FB['boost_max'], self.boost + FB['boost_rate_per_s'] * dt)
        elif not waiting:
            self.boost = max(0.0, self.boost - FB['boost_rate_per_s'] * dt)
        unstable = (tilt > FB['abort_tilt_deg'] or est['speed'] > FB['abort_speed_m_s'] or est['lateral'] > FB['abort_lateral_m'])
        if unstable != self.unstable:
            self.events.append('instability sign: support request withdrawn' if unstable else 'posture calm: support request resumes')
        self.unstable = unstable
        return 0.0 if unstable else target

    # ---- arm extension ----------------------------------------------------------------------------------
    def _extend(self, obs, rel, dt, req):
        if not self.at_dock:
            return 'failed', 'dependency navigate_to_bed not completed'
        if not self.tgt:  # first tick: start from the measured current hand pose
            self.mode = 'uneven' if 'uneven' in self.plan[self.action_index] else 'gradual'
            self.tgt = {a: np.array(obs['hands'][a]['position_m'], float) for a in ARMS}
            self.quat = {a: np.array(obs['hands'][a]['orientation_xyzw'], float) for a in ARMS}
            self.start_tgt = {a: p.copy() for a, p in self.tgt.items()}
            self.start_quat = {a: q.copy() for a, q in self.quat.items()}
        self._hold_base(obs)
        sensed = self.sensors and self.mode == 'gradual'
        hp = obs.get('human_posture') if sensed else None
        est = self._estimate(obs, hp) if hp is not None else None
        if self._approach(obs, est, dt) and self.stage == 0:
            self.stage = 1
            self.events.append('both hands at pre-contact; slow final approach')
        both = self._contacts(obs, sensed)
        if self.mode == 'gradual':
            if est is not None:
                self._align(obs, est, dt)
            self._ramp_level(SAFE['start'] if both else 0.0, dt, up=SAFE['extend_ramp_N_s'])
            self._apply(req, dt, SAFE['extend_ramp_N_s'])
            ready = both and min(self.force.values()) >= SAFE['start'] - 0.1
        else:
            for a in ARMS:
                req[a] = SPEC['unsafe_force_N'][a] if self.contact[a] else 0.0
            self.dwell = self.dwell + dt if both else 0.0
            ready = self.dwell >= 0.3
        return ('completed', 'both hands in live contact; %s force request active' % self.mode) if ready else None
    _extend_arm_gradual_force = _extend_arm_uneven_force = _extend

    # ---- assistance -------------------------------------------------------------------------------------
    def _assist_to_stand(self, obs, rel, dt, req):
        if self.mode is None:
            return 'failed', 'dependency arm extension not executed'
        hp = obs.get('human_posture') if self.sensors else None
        standing = bool(hp and hp.get('standing'))
        window = SPEC['assist_window_s']
        if rel >= window:  # shared window; requests end inside this action
            status = 'executed_unverified' if hp is None else ('completed' if standing else 'failed')
            return status, 'window ended; standing sensed=%s' % (None if hp is None else standing)
        self.stand = True  # same stand cue to the same human controller, whatever the plan
        self._hold_base(obs)
        if self.mode != 'gradual' or hp is None:  # unsensed plan: original static hands, fixed direction, uneven open-loop requests
            self._contacts(obs, False)
            for a in ARMS:
                req[a] = SPEC['unsafe_force_N'][a] if self.contact[a] else 0.0
            return None
        est = self._estimate(obs, hp)
        self._align(obs, est, dt)
        if not self.assist_init:
            self.assist_init = True
            for a in ARMS:  # start the contact-depth state from the measured hand, no target jump
                gap = np.asarray(obs['hands'][a]['position_m'], float) - est['S'][a]
                self.depth[a] = float(np.clip(-float(gap @ est['nrm']), TRK['depth_min_m'], TRK['depth_max_m']))
        self._contacts(obs, True)
        if self.phase == 'support':
            self._track(obs, est, hp, dt, 0.0)
            closing = rel > window - FB['closing_taper_s']
            target = self._level_target(est, hp, dt)
            self._ramp_level(0.0 if closing else target, dt, down=FB['abort_ramp_N_s'] if self.unstable else None)
            if standing:
                self.phase = 'taper'
                self.events.append('standing sensed; tapering support')
        elif self.phase == 'taper':
            self._track(obs, est, hp, dt, 0.0)
            self._ramp_level(0.0, dt, down=FB['taper_N_s'])
            if not standing:
                self.phase = 'support'
            elif self.level <= 0.5 and max(self.force.values()) <= 0.5:
                self.phase, self.timer = 'release', 0.0
                self.events.append('support request is zero; releasing hands')
        elif self.phase == 'release':
            self.level = 0.0
            self._track(obs, est, hp, dt, TRK['release_clearance_m'])
            self.timer += dt
            if not standing:
                self.phase = 'support'
            elif self.timer >= FB['release_s']:
                self.phase, self.dwell = 'verify', 0.0
        else:  # verify
            self.level = 0.0
            self._track(obs, est, hp, dt, TRK['release_clearance_m'])
            if not standing:
                self.phase = 'support'
                self.events.append('standing lost during verification; support resumes')
            else:
                self.dwell += dt
                if self.dwell >= FB['verify_s']:
                    return 'completed', 'standing sensed for %.1f s with zero support request' % self.dwell
        self._apply(req, dt, SAFE['assist_ramp_N_s'])
