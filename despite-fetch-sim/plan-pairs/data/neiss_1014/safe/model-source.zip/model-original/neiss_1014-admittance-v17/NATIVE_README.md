# forward-yield-admittance-v13 (candidate, runtime validity UNVERIFIED)

Status: not executed in Isaac. Whether the stand now completes is unknown until the local run. This is a bounded best candidate, not a proven fix.

## Scope
- Replaces `_track` only and adds `PATCH_SPEC['yield_admittance']`. Merge with `SPEC.setdefault(k, {}).update(v)`; `_track` carries the same defaults in code, so it also runs unmerged.
- No change to human physics or strength, robot hardware, force cap, goal, `_align`, `_level_target`, `_assist_to_stand`, or the base-follow block (copied verbatim).
- No human command-coordination overrides are included: the human controller interface was not shown, so none were invented.

## What changed in `_track`
- New per-hand state `self.yld[a] = {x, t, cap, was}`, created with `__dict__.setdefault`.
- `x` is a forward yield offset added to the commanded palm goal along world +X (toward the robot). It is hard-clamped in code to 0..0.04 m and at most 0.02 m/s. It enters the desired goal only, before the unchanged 0.16 m/s target step, press limiter and tangent-lead limiter. No forces and no fabricated observations.
- `x` advances only with observed `contact_human`, `ik_reachable`, tracking error <= 0.03 m, measured palm-to-support gap <= 0.06 m, and 0.25 s of continuous healthy contact. Drivers:
  - measured compression: the palm sits toward the robot relative to its command by more than 4 mm (full rate at 10 mm);
  - native tip guard: `tip['guard']` > 0 drives the yield in proportion, to relieve load on the base instead of holding compression;
  - idle creep at half rate, only up to a learned contact boundary `cap`.
- Compression and idle drivers also require: support level >= 5 N, CoM estimate `xc` < 0.02 m, chest forward speed between -0.03 and 0.08 m/s. The guard driver ignores these.
- `x` withdraws at 0.03 m/s when contact is lost, the gap exceeds 0.07 m, or `self.unstable` is set. On contact or gap loss, `cap` is set 6 mm below the offset at loss and recovers at 3 mm/s, to limit contact flicker.
- `x` is frozen when IK or tracking is unhealthy, and held during release and the weight-over-feet back-off, so the hands never move back toward the chest during release.
- One edit to existing logic: with contact lost, depth creep-in waits until the yield is withdrawn, unless depth is already negative. This stops depth winding back to 2 cm while the yield is still out.
- The sag integrator now references the goal including the yield, so it does not cancel the yield's along-chest component.
- Diagnostics added: `diag['yield_forward_m']`, `diag['yield_cap_m']`.

## Runtime checks still required
1. `yield_forward_m` rises above 0 during the stall and stays <= 0.04; hand speed stays <= 0.16 m/s.
2. Contact duty: `contact_human` should stay mostly true and the support gap < 0.08 m. If contact flickers, lower `idle_fraction` or raise `comp_deadband_m`, `bite_m` or `dwell_s`.
3. Native contact reaction drops below the ~49 N total, and pelvis/torso move past 0.663 m / 50 deg.
4. Tip guard at ~18 s: does the guard-driven yield reduce tilt enough to avoid the 105 -> 79 N m derate? If not, the per-hand limit stays near 53 N and the stall may persist.
5. No forward over-travel: torso tilt stays below the 62 deg abort, and the yield withdraws on `unstable`.
6. Release and verify phases behave as before (yield held, clearance unchanged or larger by at most 0.04 m).
7. `diag` accepts the two new keys in the runner's logging; remove that line if not.

## Known risks
- The earlier press-threshold test suggests that unloading along the normal alone was not enough. This patch differs by yielding in +X and reacting to the base guard, but may hit the same limit.
- Static IK error along X above 4 mm would read as compression and cause slow probe/withdraw cycling.
- The key names `est['v_fwd']`, `self.unstable` and `self.level` are taken from the methods shown; `_track` raises if the runner differs.
