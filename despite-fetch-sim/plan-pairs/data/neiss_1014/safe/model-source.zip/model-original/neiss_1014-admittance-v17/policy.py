# forward-yield-admittance-v13: replacement _track + PATCH_SPEC only. Merge: SPEC.setdefault(k, {}).update(v).
# _track carries the same defaults in code, so it also runs if PATCH_SPEC is not merged. Runtime validity UNVERIFIED.
import math
import numpy as np

PATCH_SPEC = {'yield_admittance': {
    'max_m': 0.04, 'rate_m_s': 0.02, 'return_m_s': 0.03, 'idle_fraction': 0.5, 'comp_deadband_m': 0.004,
    'comp_span_m': 0.006, 'err_max_m': 0.03, 'dwell_s': 0.25, 'gap_stop_m': 0.06, 'gap_back_m': 0.07,
    'bite_m': 0.006, 'cap_recover_m_s': 0.003, 'com_max_m': 0.02, 'v_fwd_max_m_s': 0.08, 'v_back_max_m_s': 0.03,
    'min_level_N': 5.0}}


def _track(self, obs, est, hp, dt, clearance):
    '''Sensed plan: hands follow the measured chest points, bounded relative to the MEASURED palm; base backs away.
    New: bounded forward-yield admittance. While real contact is observed and IK/tracking/gap are healthy, the
    commanded palm goal is advanced along world +X (toward the robot) by at most 0.04 m at <= 0.02 m/s, driven by
    measured palm compression and the native base tilt guard, plus a slow contact-gated creep below a learned contact
    boundary. It is withdrawn when contact is lost, the gap grows or instability is sensed. Position goal only.'''
    G = type(self).update.__globals__
    spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
    T = spec['contact_tracking']
    WU = spec.get('wrist_up') or {}
    A = spec.get('yield_admittance') or {}
    nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
    pts = hp.get('support_points_world_m') or {}
    S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
    ff = np.asarray(hp['torso_velocity_m_s'], float) * T['feedforward_s']
    n = float(np.linalg.norm(ff))
    if n > T['feedforward_max_m']:
        ff = ff * (T['feedforward_max_m'] / n)
    step = spec['hand_speed_max_m_s'] * dt
    turn = spec['hand_turn_max_rad_s'] * dt
    press_max = float(T.get('press_lead_max_m', 0.03))
    lead_max = float(T.get('tangent_lead_max_m', 0.08))
    hard = float(T.get('hard_pause_m', 0.14))
    comp_gain = float(T.get('tangent_comp_gain_per_s', 2.0))
    comp_max = float(T.get('tangent_comp_max_m', 0.07))
    freeze = float(T.get('comp_freeze_error_m', 0.10))
    yield_max = float(T.get('orientation_yield_max_rad', 0.20))
    back_scale = float(T.get('orientation_return_scale', 0.25))
    wu_max = float(WU.get('max_rad', 0.22))
    wu_rate = min(float(WU.get('rate_rad_s', 0.25)), float(spec['hand_turn_max_rad_s'])) * dt
    z_full, z_zero = float(WU.get('full_below_z_m', 0.90)), float(WU.get('zero_above_z_m', 1.00))
    lvl_min = float(WU.get('min_level_N', 5.0))
    # Forward-yield admittance parameters (hard-clamped to the stated bounds whatever the spec says).
    a_max = min(max(float(A.get('max_m', 0.04)), 0.0), 0.04)
    a_rate = min(max(float(A.get('rate_m_s', 0.02)), 0.0), 0.02)
    a_back = min(max(float(A.get('return_m_s', 0.03)), 0.0), float(spec['hand_speed_max_m_s']))
    idle = min(1.0, max(0.0, float(A.get('idle_fraction', 0.5))))
    c0, c_span = float(A.get('comp_deadband_m', 0.004)), max(float(A.get('comp_span_m', 0.006)), 1e-4)
    a_err, dwell = float(A.get('err_max_m', 0.03)), float(A.get('dwell_s', 0.25))
    g_stop, g_back = float(A.get('gap_stop_m', 0.06)), float(A.get('gap_back_m', 0.07))
    bite, cap_rate = float(A.get('bite_m', 0.006)), float(A.get('cap_recover_m_s', 0.003))
    com_max, lvl_y = float(A.get('com_max_m', 0.02)), float(A.get('min_level_N', 5.0))
    v_fwd, v_back = float(A.get('v_fwd_max_m_s', 0.08)), float(A.get('v_back_max_m_s', 0.03))
    out = np.array([1.0, 0.0, 0.0])
    tip = self.__dict__.get('tip') or {}
    guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
    head = float(tip.get('headroom', 0.0)) * (1.0 - guard)
    wp = self.__dict__.setdefault('wpitch', {})
    yld = self.__dict__.setdefault('yld', {a: {'x': 0.0, 't': 0.0, 'cap': a_max, 'was': False} for a in arms})
    xc, vf = float(est['xc']), float(est['v_fwd'])
    unstable = bool(getattr(self, 'unstable', False))
    # Yield for the person only while support is requested, the CoM is not yet over the feet and the chest is slow.
    calm = xc < com_max and -v_back < vf < v_fwd and self.level >= lvl_y
    # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
    easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and xc >= 0.0
    for a in arms:
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        err = float(h.get('tracking_error_m') or 0.0)
        touching = bool(h.get('contact_human'))
        reach = h.get('ik_reachable') is not False
        press = -float((self.tgt[a] - pos) @ nrm)
        y = yld[a]
        gap = float(np.linalg.norm(pos - S[a]))
        comp = float((pos - self.tgt[a]) @ out)   # measured palm pushed toward the robot relative to its command
        if clearance > 0.0 or easy:               # release / weight over feet: hold the yield, original back-off acts
            y['t'], y['was'] = 0.0, False
        elif (not touching) or unstable or gap > g_back:
            if y['was'] and not unstable:         # remember where contact ended; do not re-probe past it at once
                y['cap'] = max(0.0, y['x'] - bite)
            y['t'], y['was'] = 0.0, False
            y['x'] = max(0.0, y['x'] - a_back * dt)
        elif reach and err <= a_err and gap <= g_stop:
            y['t'], y['was'] = y['t'] + dt, True
            y['cap'] = min(a_max, y['cap'] + cap_rate * dt)
            if y['t'] >= dwell:
                push = max(guard, min(1.0, max(0.0, comp - c0) / c_span) if calm else 0.0)
                if push > 0.0:                    # measured compression or sensed base tilt: yield toward the robot
                    y['x'] = min(a_max, y['x'] + a_rate * push * dt)
                    y['cap'] = max(y['cap'], y['x'])
                elif calm and y['x'] < y['cap']:  # slow contact-gated creep up to the learned contact boundary
                    y['x'] = min(y['cap'], y['x'] + a_rate * idle * dt)
        else:
            y['t'] = 0.0                          # IK / tracking / gap not healthy: freeze (anti-windup)
        if clearance > 0.0:
            self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
        elif easy:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        elif not touching:
            if y['x'] <= 1e-4 or self.depth[a] < 0.0:   # withdraw the yield first, then the original creep-in
                self.depth[a] = min(T['depth_max_m'], self.depth[a] + T['creep_in_m_s'] * dt)
        elif press > T['press_error_m']:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
            self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
        else:
            self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
        base = S[a] + ff - self.depth[a] * nrm - self.lower[a] * up + min(y['x'], a_max) * out
        # Bounded integral compensation of the measured palm lag along the chest surface, with anti-windup.
        if clearance > 0.0 or not touching:
            self.sagc[a] = max(0.0, self.sagc[a] - T['sag_release_m_s'] * dt)
        elif reach and err <= freeze:
            short = float((base - pos) @ up)
            self.sagc[a] = min(comp_max, max(0.0, self.sagc[a] + comp_gain * short * dt))
        else:
            self.sagc[a] = max(0.0, self.sagc[a] - 0.5 * T['sag_release_m_s'] * dt)
        goal = base + self.sagc[a] * up
        if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
            self.tgt[a] = toward(self.tgt[a], pos, step)
        else:
            tgt = toward(self.tgt[a], goal, step)
            off = tgt - pos
            depth_in = -float(off @ nrm)
            if depth_in > press_max:   # never press on
                tgt = tgt + (depth_in - press_max) * nrm
                off = tgt - pos
            tan = off - float(off @ nrm) * nrm
            tn = float(np.linalg.norm(tan))
            if tn > lead_max:          # bounded lead of the reference over the measured palm
                tgt = tgt - tan * (1.0 - lead_max / tn)
            self.tgt[a] = tgt
        pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
        # Wrist-up component (negative pitch = wrist above palm): faded out with hand height, scaled by spare native
        # tip margin, released when contact, IK or tracking is not healthy. Scalar starts from the current command.
        fade = min(1.0, max(0.0, (z_zero - float(goal[2])) / max(z_zero - z_full, 1e-3)))
        ok = clearance <= 0.0 and touching and reach and err <= freeze and (not easy) and self.level >= lvl_min
        want = -wu_max * fade * head if ok else 0.0
        if a not in wp:
            q0 = self.quat[a]
            sg = 1.0 if float(q0[2]) >= 0.0 else -1.0
            wp[a] = min(0.0, max(-wu_max, 2.0 * math.atan2(sg * float(q0[0]), sg * float(q0[2]))))
        wp[a] += min(wu_rate, max(-wu_rate, want - wp[a]))
        nominal = pitched(pitch + wp[a])
        if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
            mq = np.asarray(h['orientation_xyzw'], float)
            mn = float(np.linalg.norm(mq))
            if mn > 1e-6:
                cand = quat_step(self.quat[a], mq / mn, turn)
                ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                if ang <= yield_max:
                    self.quat[a] = cand
        else:
            self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
    self.diag = dict(getattr(self, 'diag', None) or {}, yield_forward_m={a: float(yld[a]['x']) for a in arms},
                     yield_cap_m={a: float(yld[a]['cap']) for a in arms})
    BF = spec.get('base_follow')
    if BF and self.hold_xy is not None:
        # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
        dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
        sx = float(np.mean([S[a][0] for a in arms]))
        want_x = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
        r = BF['ref_rate_m_s'] * dt
        self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want_x - self.hold_xy[0])))
        ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
        vmax = BF['speed_max_m_s']
        self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]
