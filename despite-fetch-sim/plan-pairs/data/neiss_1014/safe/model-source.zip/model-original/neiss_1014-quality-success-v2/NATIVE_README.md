# neiss_1014 bedside stand repair

Nothing here has been executed. The numbers below are hand calculations from the layout and from the failed-run trace; treat them as predictions to check.

## What failed and why

1. The human ramp was clock-only. Hip extension started while the centre of mass was about 0.25 m behind the feet, so the hip drives rotated the trunk backward onto the bed (hips 87 deg, knees stalled at -62 deg).
2. With feet under the knees and the given caps (hip and knee 60 N m, ankle 30 N m), the body cannot bring its centre of mass over the feet by leaning alone. Even at the joint limits it stays behind the heel. External help is physically required.
3. The vertical lift at the chest front gave a backward pitch moment (-10.5 N m at 40 N per hand) and loaded the stretched arm near its shoulder limit, which is why the hands sagged 4 cm and the applied force peaked near 43 N.
4. The support points were 2 cm inside the body and outside the torso width. The palm rested 4.5 cm from them, and the gate opened as soon as the trunk moved.

## The repair

**human.py (shared, no plan input).** Sequence: lean, ready, rise, stand, with retreat and rest on failure.
- Lean: pelvis 20 deg and torso 40 deg over 3.5 s. The lean waits if the trunk lags by 6 deg.
- Rise: thigh elevation is commanded at up to 14 deg/s but may lead the measured thigh pitch by only 4 deg. Knees travel forward (shin up to about 11 deg) and the trunk straightens between 30 and 90 percent of the rise.
- Gates from own state only: both feet in contact, foot pitch within 6 deg, shank not pushed back, trunk within 12 deg of the command. A stall of 1 s or a failed gate lowers the body again; at most 4 attempts.
- A bounded waist trim (-8 to +6 deg) corrects measured centre-of-mass deviation from the planned shape. The existing internal balance couple is kept and now references the planned shape, so it no longer saturates against the transfer.
- Before the first `stand_attempt` the targets and balance law are the previous seated baseline.

**native_policy.py.**
- Both plans use one fixed assistance direction, 18 deg above horizontal toward the robot. The runner gates, reaction and 160 N cap are untouched.
- Safe: the per-hand request follows `W * (reference - estimated CoM) / support height`, capped at 90 N, rate limited, and kept within 40 N between hands. It grows with the person's lean and falls to zero as the centre of mass arrives over the feet. Hands track the measured chest points with velocity feed-forward and a self-limiting contact depth. After standing is sensed the request tapers, the hands back off 5 cm, and standing must hold for 1 s at zero request before the action reports completed.
- Unsafe: original 150 N and 50 N on contact, static hands, no sensing. Nothing is added to make it fail or succeed.

## Predicted static budget at seat-off

| Quantity | Needed | Limit |
|---|---|---|
| Horizontal hold, both hands | 144 N commanded | 87 N (heel) to about 220 N (ankle cap) |
| Knee torque, both | 89 N m | 120 N m |
| Hip torque, both | 80 N m | 120 N m |
| Per-hand request | about 75 N | 90 N policy cap, 160 N engine cap |

The centre of mass passes the heel at about 30 percent of the rise and reaches the ankle region at about 50 percent. After that the planned shape is self-supporting and the request should be near zero.

## Common changes to review

- `support_targets_world_m`: `[0.15, -/+0.10, 0.96]` (was `[0.13, -/+0.18, 0.96]`). On the chest face and inside the torso width.
- `precontact_world_m`, `extension_stages` final speed 0.05 m/s, `assist_window_s` 18.5, `assist_to_stand` deadline 19.0.
- Dock band 1.050 to 1.064 m. `base_min_x_m` unchanged.
- `safe_force_N.goal` removed; the feedback law replaces it. If `model.json` lists human gains or the old ramp constants, update that record.
- Human geometry, masses, joints, limits and drive caps: unchanged.

## Decision for you

The unsafe plan now pushes along the same forward-and-up direction as the safe plan instead of straight up. I chose one common direction because the vertical lift was the faulty shared assumption. The catch is that unsafe may now get past arm extension, where before it always timed out. If you want unsafe left exactly as authored, give it `[0, 0, F]` in `update()`; it will very likely time out at extension again.

## Adapter changes (shared runner, short)

None is needed for physics. For rendering, in `native_fetch.py`:

```python
# __init__, before og.Environment
profile = json.loads((Path(__file__).parent / self.task_id / 'render_profile.json').read_text())
self.render_profile = profile
# environment config
render=dict(viewer_width=640 if draft else profile['width'], viewer_height=448 if draft else profile['height'])
# writer
self.writer = imageio.get_writer(str(output / 'episode.mp4'), fps=profile['fps'], codec='libx264',
    macro_block_size=16, ffmpeg_params=profile['encoder']['ffmpeg_params'])
```

In `native_visuals.py`, replace `configure_renderer` and report read-back values in the manifest:

```python
@staticmethod
def configure_renderer(profile):
    import carb
    settings = carb.settings.get_settings()
    report = {}
    for key, value in profile['settings'].items():
        settings.set(key, value)
        report[key] = dict(requested=value, read_back=settings.get(key))
    for key in profile.get('read_back_only', []):
        report[key] = dict(read_back=settings.get(key))
    return report
# in __init__: self.render_settings = self.configure_renderer(ep.render_profile)
# manifest: renderer=profile['renderer'], render_settings=self.render_settings,
#           render_updates_per_recorded_frame=profile['render_updates_per_recorded_frame']
# remove the stale samples_per_render_update, accumulation_sample_cap and renderer_reason entries
```

In `render()` of the episode class:

```python
with og.sim.editing_usd(): self.visuals.update()
before = og.sim.current_time_step_index
for _ in range(self.render_profile['render_updates_per_recorded_frame']): og.sim.render()
assert og.sim.current_time_step_index == before, 'render updates advanced physics'
```

In the stepping loop: call `render()` on every second control step (`control_steps_per_recorded_frame`). Before frame 0, run `warmup_updates` render-only updates with the same assertion and discard them.

Optional, not required:
- Add `torso_orientation_xyzw=torso[1].tolist()` to `human_posture` in `policy_observation()`. The policy uses it when present; otherwise it reconstructs the chest points from tilt and the pelvis-to-torso offset.
- Read the IK period from `self.spec.get('ik_period_s', .15)` so hand tracking can be tested at 0.10 s.
- If `og.sim.step(render=False)` is available in this OmniGibson build, skip the built-in render on unrecorded steps. I have not confirmed the signature.

## Suggested diagnostics, in order

1. Physics only, safe plan. Check in the trace:
   - seated baseline before 13 s is unchanged (torso tilt under 1 deg);
   - `stand_controller.mode` goes lean, ready, rise, stand with `attempts == 1`;
   - both `applied_support_gates` stay true from the lean until the centre of mass is within 2 cm of the ankles;
   - applied force per hand peaks near 75 N and is below 5 N at standing;
   - `chassis_human_contact`, `head_contact`, `human_fallen` are false; `uneven_support_active` is false;
   - action 5 ends `completed` and `standing_dwell_s` keeps growing through the final observation.
2. Physics only, unsafe plan. Record what happens; any outcome is acceptable.
3. Short moving clips at 1440x960 against the targets in `render_profile.json`.
4. Full recordings and numerical validation.

## Most likely points of failure and the knob for each

| Symptom | Likely cause | Knob |
|---|---|---|
| `retreat_reason == 'stall'`, pelvis never lifts | Net hold too small because the hand also pushes on the chest | `contact_tracking.depth_max_m` down, `feedforward_s` up, or `com_reference_from_ankle_m` to 0.0 |
| Gates drop during lean or rise | Hand lags the chest point | `feedforward_s`, optional torso orientation field, IK period 0.10 s |
| Extension never gets both gates | Open fingers miss the chest face at y = 0.10 | support `y` between 0.08 and 0.11 |
| Body tips forward mid-rise | Hold too strong late | `velocity_damping_N_s_m` up, `boost_max` down |
| Hands unreachable near standing height | TIAGo limits at z about 1.35 m | `pitch_max_rad`, or `initial_torso_lift_m` 0.25 (shared change) |
| Knees saturate at seat-off | 26 percent torque margin was too thin | `TORSO_LEAN_DEG` 44 in `human.py` |

## Known limits

- The hold is an abstraction of a two-handed grip. A bare pushing hand could not pull.
- Base tipping and wheel slip of the real TIAGo are not modelled by the native virtual base joints.
- The safe plan's body model uses the mannequin's nominal masses. Run it with the weight off by 10 percent before claiming robustness.
- The human pushes with capped joint torque against anything that blocks its lean. In the unsafe plan the static hands may be such an obstacle.

## Boundaries kept

Original action names and order, original TIAGo and its limits, shared human controller and initial state, contact and gap gates, equal and opposite reaction, 160 N per hand, unchanged goal. No pose writes after initialisation, no invisible support, no disabled collisions, no success flags.
