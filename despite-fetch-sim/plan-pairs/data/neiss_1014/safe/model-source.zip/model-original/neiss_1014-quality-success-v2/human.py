'''Seated-to-standing PhysX mannequin for neiss_1014 (one controller for every plan).

Eleven dynamic links, bounded PhysX muscle drives and one bounded internal
balance couple: geometry, masses (64.6 kg), joints, limits and drive caps are
unchanged. Only the stand coordination was repaired. The former clock-only 4 s
ramp extended the hips while the centre of mass was still about 0.25 m behind
the feet, which laid the trunk back onto the bed. The stand is now a measured,
feedback-gated sequence that reads only this body's own state and foot-floor
contact:

  seated -> lean -> ready -> rise <-> retreat -> rest -> (rise | abandon) -> stand

No plan label, robot flag, robot force or outcome is read; the one external
input is the same stand_attempt trigger for every plan. All strengths and gains
are uncalibrated assumptions; standing is not guaranteed.
'''
import math
import numpy as np
from scipy.spatial.transform import Rotation as R
from pxr import UsdPhysics

LEG_Y, ARM_Y = .12, .185
K_TILT, D_TILT = 600., 60.   # N m/rad and N m s/rad on torso tilt error
K_COM, D_COM = 300., 40.     # N m/m and N m s/m on horizontal centre-of-mass error
BALANCE_CAP_PER_FOOT = 15.   # N m of internal couple per foot touching the floor
# joint kind: (stiffness, damping, max torque N m) in USD angular-drive units (per degree); unchanged
DRIVES = {'waist': (160, 18, 90), 'neck': (30, 3, 8), 'hip': (140, 14, 60),
          'knee': (140, 14, 60), 'ankle': (80, 8, 30), 'shoulder': (15, 2, 6)}
SIDES = [('left', 1), ('right', -1)]   # facing +X, left is +Y

# Sagittal geometry implied by the layout and joint anchors below.
WAIST_Z, HIP_Z, KNEE_X, ANKLE_Z = .74, .62, .40, .13
SHIN_LEN, THIGH_LEN = HIP_Z - ANKLE_Z, KNEE_X   # 0.49 m, 0.40 m
ANKLE_IN_FOOT = np.array([-.07, 0., .055])      # ankle joint expressed in the foot frame
PELVIS_UP, WAIST_UP = .03, .12                  # pelvis centre and waist joint above the hip joint

# Stand coordination, identical for every plan.
LEAN_S = 3.5                               # s for the forward trunk lean
PELVIS_LEAN_DEG, TORSO_LEAN_DEG = 20., 40.   # absolute forward pitch at full lean
PELVIS_END_DEG, TORSO_END_DEG = 2., 5.       # absolute forward pitch when upright
SHIN_BUMP_DEG, SHIN_END_DEG = 10., 2.        # knees travel forward over the feet mid-rise
UNLEAN_START, UNLEAN_END = .30, .90          # rise fraction over which the trunk straightens
RISE_RATE_DEG_S = 14.                      # peak commanded thigh elevation rate
LEAD_DEG = 4.                              # command may lead the measured thigh pitch by this much
READY_S, STALL_S, BAD_S, RESUME_S, REST_S = .4, 1.0, .25, .4, 1.2
RETREAT_DEG_S = 12.
MAX_ATTEMPTS = 4
LEAN_LAG_HOLD_DEG = 6.                     # lean command waits when the trunk is obstructed
FOOT_PITCH_OK_DEG, SHIN_BACK_OK_DEG, SHIN_FWD_OK_DEG, TORSO_OK_DEG = 6., 6., 10., 12.
TRIM_GAIN_DEG_M, TRIM_DEAD_M = 150., .015  # bounded waist trim on measured CoM deviation
TRIM_MIN_DEG, TRIM_MAX_DEG, TRIM_RATE_DEG_S = -8., 6., 10.


def _smooth(x):
    x = min(1., max(0., x))
    return x * x * (3. - 2. * x)


def _rate_profile(s):
    return max(.3, min(1., .3 + .7 * s / .12, (1. - s) / .10))


def shape(lean, rise):
    '''Commanded absolute sagittal pitches (deg): thigh elevation, shin, pelvis, torso.'''
    s = min(1., max(0., rise))
    k = _smooth((s - UNLEAN_START) / (UNLEAN_END - UNLEAN_START))
    phi = 90. * s
    sigma = SHIN_BUMP_DEG * math.sin(math.pi * s) + SHIN_END_DEG * s
    pelvis = lean * (PELVIS_LEAN_DEG * (1. - k) + PELVIS_END_DEG * k)
    torso = lean * (TORSO_LEAN_DEG * (1. - k) + TORSO_END_DEG * k)
    return phi, sigma, pelvis, torso


def human_layout():
    skin, sweater, trousers, shoes = [.72, .52, .39], [.39, .57, .57], [.22, .28, .36], [.20, .16, .13]
    rows = [
        ('h_pelvis', [0., 0., .65], [.31, .23, .18], trousers, 10),
        ('h_torso', [0., 0., .96], [.30, .25, .46], sweater, 24),
        ('h_head', [0., 0., 1.35], [.26, .26, .26], skin, 4.6, 'Sphere'),
    ]
    for side, sign in SIDES:
        y = sign * LEG_Y
        rows += [
            ('h_' + side + '_thigh', [.20, y, .62], [.40, .105, .11], trousers, 6),
            ('h_' + side + '_shin', [.40, y, .375], [.10, .10, .49], trousers, 3.6),
            ('h_' + side + '_foot', [.47, y, .075], [.30, .17, .11], shoes, 1.2),
            ('h_' + side + '_arm', [0., sign * ARM_Y, .97], [.09, .09, .42], sweater, 2.2),
        ]
    return rows


class Mannequin:
    def __init__(self, state_reader, joint_factory, floor_contact_reader):
        self.state, self.contact = state_reader, floor_contact_reader
        rows = human_layout()
        self.names = [r[0] for r in rows]
        self.masses = {r[0]: float(r[4]) for r in rows}
        self.total_mass = sum(self.masses.values())
        height = {r[0]: float(r[1][2]) for r in rows}
        group = lambda key: sum(m for n, m in self.masses.items() if n.endswith(key))
        hat = [n for n in self.names if n in ('h_torso', 'h_head') or n.endswith('_arm')]
        self.group = dict(foot=group('_foot'), shin=group('_shin'), thigh=group('_thigh'),
                          pelvis=self.masses['h_pelvis'], hat=sum(self.masses[n] for n in hat))
        self.hat_up = sum(self.masses[n] * (height[n] - WAIST_Z) for n in hat) / self.group['hat']
        self.joints, self.targets = {}, {}
        self.t_stand, self.d0, self.phase = None, None, (0., 0., 0.)
        self.balance_torque, self.balance_saturated_ticks, self.feet_in_contact = [0., 0., 0.], 0, []
        self.mode, self.reason, self.last_t = 'seated', None, None
        self.lean_u, self.lean, self.rise, self.trim = 0., 0., 0., 0.
        self.timer, self.bad, self.stall, self.attempts, self.cal = 0., 0., 0., 0, 0.
        self.consistent, self.measured_rise, self.com_error, self.plan_offset = True, 0., 0., None

        def add(name, a, b, anchor, limits):
            kp, kd, cap = DRIVES[name.split('_')[-1]]
            joint = joint_factory(name, a, b, anchor, 'ball', limits)
            drives = []
            for axis in ['rotX', 'rotY', 'rotZ']:
                d = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), axis)
                d.CreateTypeAttr('force'); d.CreateStiffnessAttr(float(kp)); d.CreateDampingAttr(float(kd))
                d.CreateMaxForceAttr(float(cap)); d.CreateTargetPositionAttr(0.0); d.CreateTargetVelocityAttr(0.0)
                drives.append(d)
            self.joints[name] = (a, b, drives)
            self.targets[name] = [0., 0., 0.]
        # Limits in degrees about initial world axes: rotY is sagittal pitch, +Y tips the top toward +X.
        add('waist', 'h_pelvis', 'h_torso', [0., 0., WAIST_Z], [[-25, 25], [-25, 50], [-30, 30]])
        add('neck', 'h_torso', 'h_head', [0., 0., 1.205], [[-40, 40], [-45, 45], [-60, 60]])
        for side, sign in SIDES:
            y, p = sign * LEG_Y, 'h_' + side + '_'
            add(side + '_hip', 'h_pelvis', p + 'thigh', [0., y, HIP_Z], [[-30, 30], [-40, 100], [-30, 30]])
            add(side + '_knee', p + 'thigh', p + 'shin', [KNEE_X, y, HIP_Z], [[1, -1], [-95, 45], [1, -1]])
            add(side + '_ankle', p + 'shin', p + 'foot', [KNEE_X, y, ANKLE_Z], [[-20, 20], [-35, 35], [-15, 15]])
            add(side + '_shoulder', 'h_torso', p + 'arm', [0., sign * ARM_Y, 1.14], [[-60, 60], [-80, 80], [-40, 40]])

    def _set(self, name, pitch_deg):
        if abs(pitch_deg - self.targets[name][1]) > 1e-4:   # skip redundant USD writes
            self.targets[name][1] = float(pitch_deg)
            self.joints[name][2][1].GetTargetPositionAttr().Set(float(pitch_deg))

    def _plan_offset(self, phi, sigma, pelvis, torso):
        '''Whole-body CoM forward of the ankle (m) for a commanded shape with flat feet.'''
        phi, sigma, pelvis, torso = [math.radians(v) for v in (phi, sigma, pelvis, torso)]
        knee = SHIN_LEN * math.sin(sigma)
        hip = knee - THIGH_LEN * math.cos(phi)
        g = self.group
        x = (g['foot'] * -float(ANKLE_IN_FOOT[0]) + g['shin'] * .5 * knee
             + g['thigh'] * (knee - .5 * THIGH_LEN * math.cos(phi))
             + g['pelvis'] * (hip + PELVIS_UP * math.sin(pelvis))
             + g['hat'] * (hip + WAIST_UP * math.sin(pelvis) + self.hat_up * math.sin(torso)))
        return x / self.total_mass

    def _own(self, s):
        '''Proprioceptive summary from this body's own link states and foot contacts.'''
        px = R.from_quat(s['h_pelvis'][1]).apply([1., 0., 0.])
        f = np.array([px[0], px[1], 0.])
        norm = float(np.linalg.norm(f))
        f = f / norm if norm > .2 else np.array([1., 0., 0.])
        left = np.array([-f[1], f[0], 0.])

        def z_pitch(name):   # links whose long axis is local Z
            u = R.from_quat(s[name][1]).apply([0., 0., 1.])
            return math.degrees(math.atan2(float(u @ f), float(u[2])))

        def x_pitch(name):   # links whose long axis is local X
            v = R.from_quat(s[name][1]).apply([1., 0., 0.])
            return math.degrees(math.atan2(-float(v[2]), float(v @ f)))

        sides = [side for side, _ in SIDES]
        phi = float(np.mean([x_pitch('h_' + k + '_thigh') for k in sides]))
        phi_rate = float(np.mean([math.degrees(float(np.asarray(s['h_' + k + '_thigh'][3], dtype=float) @ left)) for k in sides]))
        sigma = float(np.mean([z_pitch('h_' + k + '_shin') for k in sides]))
        foot_pitch = max([x_pitch('h_' + k + '_foot') for k in sides], key=abs)
        ankle = np.mean([np.asarray(s['h_' + k + '_foot'][0], dtype=float)
                         + R.from_quat(s['h_' + k + '_foot'][1]).apply(ANKLE_IN_FOOT) for k in sides], axis=0)
        com = sum(np.asarray(s[n][0], dtype=float) * m for n, m in self.masses.items()) / self.total_mass
        com_v = sum(np.asarray(s[n][2], dtype=float) * m for n, m in self.masses.items()) / self.total_mass
        feet = [n for n in self.names if n.endswith('_foot') and self.contact(n)]
        return dict(phi=phi, phi_rate=phi_rate, sigma=sigma, pelvis=z_pitch('h_pelvis'), torso=z_pitch('h_torso'),
                    foot_pitch=float(foot_pitch), ankle=ankle, com=com, com_v=com_v, feet=feet,
                    com_fwd=float((com - ankle) @ f), com_fwd_v=float(com_v @ f))

    def _begin_rise(self):
        self.attempts += 1
        self.mode, self.reason, self.bad, self.stall, self.timer = 'rise', None, 0., 0., 0.

    def _advance(self, dt, own):
        _, sigma_c, _, torso_c = shape(self.lean, self.rise)
        meas = min(1., max(0., own['phi'] / 90.))
        ok = (len(own['feet']) == 2 and abs(own['foot_pitch']) <= FOOT_PITCH_OK_DEG
              and -SHIN_BACK_OK_DEG <= own['sigma'] - sigma_c <= SHIN_FWD_OK_DEG
              and abs(own['torso'] - (torso_c + self.trim)) <= TORSO_OK_DEG)
        self.consistent, self.measured_rise = ok, meas
        if self.mode == 'lean':
            if torso_c - own['torso'] < LEAN_LAG_HOLD_DEG:   # anti-windup: do not run ahead of an obstructed trunk
                self.lean_u = min(1., self.lean_u + dt / LEAN_S)
            self.lean = _smooth(self.lean_u)
            if self.lean_u >= 1.:
                self.mode, self.timer = 'ready', 0.
        elif self.mode == 'ready':
            self.timer = self.timer + dt if ok else 0.
            if self.timer >= READY_S:
                self._begin_rise()
        elif self.mode == 'rise':
            self.bad = self.bad + dt if not ok else max(0., self.bad - 2. * dt)
            if self.bad > BAD_S:   # feet not flat, shank pushed back or trunk off plan: lower again
                self.mode, self.reason, self.timer = 'retreat', 'posture', 0.
            else:
                if ok:   # extension may only lead the measured thigh elevation by LEAD_DEG
                    step = RISE_RATE_DEG_S * _rate_profile(self.rise) * dt / 90.
                    self.rise = min(1., max(self.rise, min(self.rise + step, meas + LEAD_DEG / 90.)))
                stalled = (self.rise < .85 and self.rise - meas >= (LEAD_DEG - 1.) / 90. and own['phi_rate'] < 1.)
                self.stall = self.stall + dt if stalled else 0.
                if self.stall > STALL_S:   # weight is not on the feet: stop pushing and sit
                    self.mode, self.reason, self.timer = 'retreat', 'stall', 0.
                elif self.rise >= 1. and meas >= .90:
                    self.mode = 'stand'
        elif self.mode == 'retreat':
            self.rise = max(0., self.rise - RETREAT_DEG_S * dt / 90.)
            self.timer = self.timer + dt if ok else 0.
            if self.reason == 'posture' and self.timer >= RESUME_S and self.rise > .15 and meas > .10:
                self.mode, self.bad, self.stall = 'rise', 0., 0.
            elif self.rise <= 0.:
                self.mode, self.timer = 'rest', 0.
        elif self.mode == 'rest':
            self.timer += dt
            if self.timer >= REST_S:
                if self.attempts < MAX_ATTEMPTS:
                    self._begin_rise()
                else:
                    self.mode = 'abandon'
        elif self.mode == 'abandon':
            self.lean_u = max(0., self.lean_u - dt / LEAN_S)
            self.lean = _smooth(self.lean_u)
        elif self.mode == 'stand':
            self.rise = 1.

    def _trim(self, dt, own, plan):
        target, error = 0., own['com_fwd'] - plan
        active = self.mode == 'stand' or (self.mode in ('rise', 'retreat') and self.rise > .05)
        if active and own['feet'] and abs(error) > TRIM_DEAD_M:
            target = -TRIM_GAIN_DEG_M * (error - math.copysign(TRIM_DEAD_M, error))
            target = min(TRIM_MAX_DEG, max(TRIM_MIN_DEG, target))
        step = TRIM_RATE_DEG_S * dt
        self.trim += min(step, max(-step, target - self.trim))
        self.com_error, self.plan_offset = float(error), float(plan)

    def control(self, t, torques, stand_attempt=False):
        t = float(t)
        dt = 0. if self.last_t is None else min(max(t - self.last_t, 0.), .05)
        self.last_t = t
        s = {n: self.state(n) for n in self.names}
        own = self._own(s)
        if stand_attempt and self.t_stand is None:
            self.t_stand, self.mode = t, 'lean'   # latched once; afterwards only own state is used
            if self.d0 is not None:
                self.cal = float(self.d0[0]) - (self._plan_offset(0., 0., 0., 0.) + float(ANKLE_IN_FOOT[0]))
        if self.t_stand is not None:
            self._advance(dt, own)
        phi, sigma, pelvis, torso = shape(self.lean, self.rise)
        plan = self._plan_offset(phi, sigma, pelvis, torso)
        self._trim(dt, own, plan)
        self._set('waist', torso + self.trim - pelvis)
        for side, _ in SIDES:
            self._set(side + '_hip', phi - pelvis)     # thigh relative to pelvis
            self._set(side + '_knee', sigma - phi)     # shin relative to thigh
            self._set(side + '_ankle', -sigma)         # foot stays flat under the tilted shin
        self.phase = (self.rise, self.lean, self.rise)
        self._balance(s, own, math.radians(torso + self.trim), plan, torques)

    def _balance(self, s, own, torso_pitch, plan, torques):
        com, com_v, feet = own['com'], own['com_v'], own['feet']
        torque = np.zeros(3)
        if feet:   # the only gate: physical foot-floor contact
            rot = R.from_quat(s['h_torso'][1])
            fwd = rot.apply([1., 0., 0.])
            yaw = math.atan2(fwd[1], fwd[0])
            heading, left = np.array([math.cos(yaw), math.sin(yaw)]), np.array([-math.sin(yaw), math.cos(yaw)])
            desired = R.from_euler('ZY', [yaw, torso_pitch])   # commanded lean in the current heading
            torque = -K_TILT * (rot * desired.inv()).as_rotvec() - D_TILT * np.asarray(s['h_torso'][3], dtype=float)
            support = np.mean([np.asarray(s[n][0], dtype=float) for n in feet], axis=0)
            offset = (com - support)[:2]
            if self.t_stand is None or self.d0 is None:   # seated offset, heading frame, until the stand starts
                self.d0 = np.array([offset @ heading, offset @ left])
            if self.t_stand is None:
                ref = self.d0
            else:   # follow the commanded shape, so the couple never fights the planned transfer
                keep = 1. - self.rise
                ref = np.array([plan + float(ANKLE_IN_FOOT[0]) + self.cal * keep, float(self.d0[1]) * keep])
            err = offset - (ref[0] * heading + ref[1] * left)
            torque[0] += K_COM * err[1] + D_COM * com_v[1]
            torque[1] -= K_COM * err[0] + D_COM * com_v[0]
            torque[2] = 0.   # no yaw anchoring
            cap = BALANCE_CAP_PER_FOOT * len(feet)
            norm = float(np.linalg.norm(torque))
            self.balance_saturated_ticks += int(norm > cap)
            torque *= min(1., cap / max(norm, 1e-9))
            # Internal equal/opposite couple, not an external upright constraint.
            torques['h_torso'] += torque
            for n in feet: torques[n] -= torque / len(feet)
        self.balance_torque, self.feet_in_contact = torque.tolist(), feet

    def measure(self):
        s = {n: self.state(n) for n in self.names}
        own = self._own(s)
        angles, errors = {}, {}
        for name, (a, b, _) in self.joints.items():
            rel = R.from_quat(s[a][1]).inv() * R.from_quat(s[b][1])
            angles[name] = np.degrees(rel.as_rotvec()).tolist()
            errors[name] = self.targets[name][1] - angles[name][1]
        vec = lambda i: {n: np.asarray(s[n][i], dtype=float).tolist() for n in self.names}
        return dict(body_positions=vec(0), body_orientations_xyzw=vec(1), body_velocities_m_s=vec(2),
                    body_angular_velocities_rad_s=vec(3),
                    joint_relative_rotation_vectors_deg=angles,
                    joint_motor_targets_deg={k: list(v) for k, v in self.targets.items()},
                    joint_pitch_tracking_error_deg=errors,
                    joint_drive_torque_caps_N_m={k: float(DRIVES[k.split('_')[-1]][2]) for k in self.joints},
                    stand_ramp=dict(start_time_s=self.t_stand, progress=self.phase[0], lean=self.phase[1], extension=self.phase[2]),
                    stand_controller=dict(mode=self.mode, attempts=self.attempts, retreat_reason=self.reason,
                                          lean=self.lean, rise=self.rise, measured_rise=self.measured_rise,
                                          posture_consistent=bool(self.consistent), stall_s=self.stall,
                                          lean_trim_deg=self.trim, com_forward_of_ankle_m=own['com_fwd'],
                                          planned_com_forward_of_ankle_m=self.plan_offset,
                                          com_plan_error_m=self.com_error,
                                          measured_pitch_deg=dict(thigh_elevation=own['phi'], shin=own['sigma'],
                                                                  pelvis=own['pelvis'], torso=own['torso'],
                                                                  foot=own['foot_pitch'])),
                    feet_in_floor_contact=list(self.feet_in_contact),
                    center_of_mass_m=np.asarray(own['com']).tolist(),
                    center_of_mass_velocity_m_s=np.asarray(own['com_v']).tolist(),
                    total_mass_kg=self.total_mass,
                    balance_torso_torque_N_m=list(self.balance_torque),
                    balance_saturation_ticks=self.balance_saturated_ticks)
