# neiss_1014 native TIAGo repair: sustained support and chest-tangent hand tracking

This patch has not been run. It is a hypothesis for the next runtime test, built on the tested 80 N wrapper result (pelvis 0.826 m, then the 0.08 m gap gate correctly removed the forces because the hands lagged).

## What the patch contains

- `PATCH_SPEC`: merged into `SPEC`.
- `PATCH_HUMAN = {'RISE_RATE_DEG_S': 9.0}`: one shared motion-command constant.
- `_level_target` and `_track`: Controller method replacements with unchanged signatures. Both read `SPEC` at call time, so they work whether the merge is in place or not.

## Support policy (`_level_target`)

- **Sustaining minimum.** This is the tested wrapper, now built in: `80 N * clip((tilt-8)/20) * clip((0.02-xc)/0.08)` per hand. It is gated on the person's own lean and on the sensed CoM being behind the heel. It fades to zero as the CoM moves over the foot or the trunk straightens, and it stays under the 90 N cap.
- **Boost retention.** The learned boost no longer decays at pelvis +0.04 m. It decays once the sensed CoM passes -0.02 m from the ankle, or when the person is seated upright again.
- **Damping.** Forward-velocity damping is scaled by the same CoM gate, so it no longer cuts support before the body is over its feet.
- **Unchanged.** Instability abort, lean gate, ramps, balance limit, taper, release and zero-support standing verification.

## Hand tracking (`_track`)

The old guard yielded toward the measured hand whenever total tracking error passed 0.06 m. The 5-6 cm wrist deflection alone reached that, so the reference stalled while the chest moved on. The world-vertical sag offset also pointed partly into a 50 degree leaning chest.

- **Pressing is judged along the chest normal only.** The reference may sit at most 0.03 m deeper than the measured palm. Depth back-off uses the same normal component.
- **Lag along the chest surface is followed.** The reference may lead the palm by at most 0.10 m along the surface.
- **Compensation runs along the chest tangent** (`torso_up`). It integrates the measured palm shortfall against the support point at 2 /s, bounded to 0.09 m, and decays on release or loss of contact.
- **Hard yield.** Above 0.14 m tracking error the reference yields fully toward the measured hand, as before.
- **Feedforward.** Horizon 0.35 s, capped at 0.07 m.
- **Unchanged.** The 0.16 m/s hand-reference speed, hand turn rate, IK-limit lowering and all native joint limits.

## Shared timing and human rate

- Rise command rate goes from 14 to 9 deg/s for both plans. This is a command rate only; strengths, gains, caps and geometry are untouched.
- Episode is 56 s, assist window 32 s, assist deadline 32.5 s, shared by both plans. This leaves room for the slower rise, one retry and the unassisted verification.

## Not changed

- Contact gate and 0.08 m gap gate, with no fictitious grasp.
- Equal and opposite reaction, 160 N engine cap, 90 N safe cap.
- Unsafe plan's 150/50 N fixed 18 degree commands and static hands.
- Final standing goal.
- No teleports, pinning or state writes; no human controller phase or force input is read.

## Open risks

- Hands may still lag late in the rise, when the trunk straightens.
- Tangent compensation may saturate at 0.09 m.
- Support may be too low between CoM -0.06 m and +0.02 m, where the minimum fades.
- A retry after a failed first attempt may not fit the window.

## What to log next run

- Gap along the chest normal and along the chest tangent.
- `sag_compensation_m`.
- `sustain_floor_N`.
- Whether either gate drops.
