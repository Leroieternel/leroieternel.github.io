# neiss_1014 patch module (math/numpy only, no I/O). Merge PATCH_SPEC into SPEC, apply PATCH_HUMAN constants to the
# shared human module, and install the top-level functions below as Controller methods (same signatures as before).
# Every function reads SPEC and helpers through the Controller module globals, so it works whether it is spliced
# into native_policy or attached from this module. Force caps, contact/gap gates, reaction and goal are untouched.
import math
import numpy as np

PATCH_SPEC = {
    'episode_seconds': 56.0,                      # shared by both plans
    'assist_window_s': 32.0,                      # shared by both plans
    'deadlines_s': {'assist_to_stand': 32.5},
    'support_feedback': {
        'sustain_N': 80.0,                        # per-hand minimum while the sensed CoM is behind the heel (below the 90 N cap)
        'sustain_zero_com_m': 0.02,               # minimum is zero once the CoM estimate is this far ahead of the ankle
        'sustain_span_m': 0.08,                   # full minimum when the CoM is this much further back
        'transfer_com_m': -0.02},                 # learned boost is kept until the CoM estimate passes this point
    'contact_tracking': {
        'feedforward_s': 0.35, 'feedforward_max_m': 0.07,
        'press_lead_max_m': 0.03,                 # reference may sit at most this deep along the chest normal past the palm
        'tangent_lead_max_m': 0.10,               # reference may lead the palm at most this far along the chest surface
        'hard_pause_m': 0.14,                     # full yield toward the measured hand beyond this tracking error
        'tangent_comp_gain_per_s': 2.0, 'tangent_comp_max_m': 0.09},
}
# Shared human motion-command rate (both plans); no strength, gain, cap or geometry change.
PATCH_HUMAN = {'RISE_RATE_DEG_S': 9.0}


def _level_target(self, est, hp, dt):
    G = type(self).update.__globals__
    spec = G['SPEC']
    SAFE, FB, BODY = spec['safe_force_N'], spec['support_feedback'], spec['anthropometric_model']
    tilt, pz = float(hp['torso_tilt_deg']), float(hp['pelvis_position_m'][2])
    if self.seat_z is None:
        self.seat_z = pz
    self.lifted = pz > self.seat_z + (FB['lift_clear_m'] if self.lifted else FB['lift_detect_m'])
    xc = float(est['xc'])
    span = max(float(FB.get('sustain_span_m', 0.08)), 1e-3)
    # 1 while the sensed CoM is well behind the heel, 0 once it is over the foot.
    behind = min(1.0, max(0.0, (float(FB.get('sustain_zero_com_m', 0.02)) - xc) / span))
    need = max(0.0, FB['com_reference_from_ankle_m'] - xc)
    # Forward-velocity damping only acts once the CoM is over the feet; before that forward motion is the goal.
    damp = FB['velocity_damping_N_s_m'] * max(0.0, float(est['v_fwd'])) * (1.0 - behind)
    fx = BODY['weight_N'] * need / est['h'] * (1.0 + self.boost) - damp
    arms = G['ARMS']
    dir_x = max(0.5, sum(float(self.dirv[a][0]) for a in arms) / len(arms))
    feedback = min(max(fx / (2.0 * dir_x), 0.0), SAFE['cap'])
    lo, hi = FB['lean_gate_deg']
    lean = min(1.0, max(0.0, (tilt - lo) / (hi - lo)))
    w = 1.0 if self.lifted else lean
    target = SAFE['start'] + (feedback - SAFE['start']) * w
    # Bounded sustaining minimum: gated on the person's own lean and on the CoM still being behind the heel.
    floor = min(float(SAFE['cap']), float(FB.get('sustain_N', 80.0))) * lean * behind
    target = min(max(target, floor), SAFE['cap'])
    waiting = (not self.lifted) and tilt >= hi
    self.wait_s = self.wait_s + dt if waiting else 0.0
    if waiting and self.wait_s > FB['boost_delay_s']:
        self.boost = min(FB['boost_max'], self.boost + FB['boost_rate_per_s'] * dt)
    elif (not waiting) and ((not self.lifted) or xc >= float(FB.get('transfer_com_m', -0.02))):
        # the learned boost decays only when seated upright again or once weight transfer is sensed
        self.boost = max(0.0, self.boost - FB['boost_rate_per_s'] * dt)
    unstable = (tilt > FB['abort_tilt_deg'] or est['speed'] > FB['abort_speed_m_s'] or est['lateral'] > FB['abort_lateral_m'])
    if unstable != self.unstable:
        self.events.append('instability sign: support request withdrawn' if unstable else 'posture calm: support request resumes')
    self.unstable = unstable
    self.diag = dict(self.diag, sustain_floor_N=float(floor), com_behind_gate=float(behind))
    return 0.0 if unstable else float(target)


def _track(self, obs, est, hp, dt, clearance):
    '''Sensed plan: hands follow the measured chest points; pressing is judged along the chest normal only.'''
    G = type(self).update.__globals__
    spec, toward, quat_step, pitched = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched']
    TRK = spec['contact_tracking']
    nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
    ff = np.asarray(hp['torso_velocity_m_s'], float) * TRK['feedforward_s']
    n = float(np.linalg.norm(ff))
    if n > TRK['feedforward_max_m']:
        ff = ff * (TRK['feedforward_max_m'] / n)
    step = spec['hand_speed_max_m_s'] * dt            # unchanged bounded hand-reference speed
    press_max = float(TRK.get('press_lead_max_m', 0.03))
    lead_max = float(TRK.get('tangent_lead_max_m', 0.10))
    hard = float(TRK.get('hard_pause_m', 0.14))
    comp_gain = float(TRK.get('tangent_comp_gain_per_s', 2.0))
    comp_max = float(TRK.get('tangent_comp_max_m', 0.09))
    for a in G['ARMS']:
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        err = float(h.get('tracking_error_m') or 0.0)
        touching = bool(h.get('contact_human'))
        off = self.tgt[a] - pos
        press = -float(off @ nrm)                     # > 0: reference deeper into the chest than the measured palm
        if clearance > 0.0:                           # explicit release: back away from the chest
            self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
        elif not touching:                            # no contact: creep in, bounded
            self.depth[a] = min(TRK['depth_max_m'], self.depth[a] + TRK['creep_in_m_s'] * dt)
        elif press > TRK['press_error_m']:            # really pressed along the chest normal: back off
            self.depth[a] = max(TRK['depth_min_m'], self.depth[a] - TRK['creep_out_m_s'] * dt)
        if h.get('ik_reachable') is False:            # native IK limit: stay lower on the chest instead of blocking
            self.lower[a] = min(TRK['lower_max_m'], self.lower[a] + TRK['lower_rate_m_s'] * dt)
        else:
            self.lower[a] = max(0.0, self.lower[a] - TRK['lower_recover_m_s'] * dt)
        base = est['S'][a] + ff - self.depth[a] * nrm - self.lower[a] * up
        # Bounded integral compensation of the measured lag ALONG the chest surface (never along the normal).
        if clearance > 0.0 or not touching:
            self.sagc[a] = max(0.0, self.sagc[a] - TRK['sag_release_m_s'] * dt)
        else:
            short = float((base - pos) @ up)          # > 0: palm is lower on the chest than its support point
            self.sagc[a] = min(comp_max, max(0.0, self.sagc[a] + comp_gain * short * dt))
        goal = base + self.sagc[a] * up
        if err > hard:                                # blocked or far off: yield fully toward the measured hand
            self.tgt[a] = toward(self.tgt[a], pos, step)
        else:
            tgt = toward(self.tgt[a], goal, step)
            off = tgt - pos
            depth_in = -float(off @ nrm)
            if depth_in > press_max:                  # never press on: cap the reference depth along the normal
                tgt = tgt + (depth_in - press_max) * nrm
            tan = off - float(off @ nrm) * nrm
            tn = float(np.linalg.norm(tan))
            if tn > lead_max:                         # bounded lead along the chest surface
                tgt = tgt - tan * (1.0 - lead_max / tn)
            self.tgt[a] = tgt
        pitch = min(max((float(goal[2]) - TRK['pitch_start_z_m']) * TRK['pitch_gain_rad_m'], 0.0), TRK['pitch_max_rad'])
        self.quat[a] = quat_step(self.quat[a], pitched(pitch), spec['hand_turn_max_rad_s'] * dt)
