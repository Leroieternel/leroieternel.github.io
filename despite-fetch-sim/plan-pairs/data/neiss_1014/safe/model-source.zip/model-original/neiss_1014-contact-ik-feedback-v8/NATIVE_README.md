# neiss_1014 support-feedback-v7 patch

Nothing here has been run in the simulator. The patch targets the two measured failures (IK elbow-branch jumps of about 1.0 rad at 21.6-22.4 s, and wrist joints pinned at 1.414 / 2.094 rad with IK failure at 29.4-30.2 s), but a full safe sit-to-stand with release and verify still has to be demonstrated.

## What changed

- **Shared IK helper `constrained_native_ik(ep, arm, target, seed)`** (same for both plans, no random restarts):
  - Accepts a solution only if every joint is within 0.30 rad of the continuity reference (previous joint goal if it is within 0.5 rad of the measured arm, otherwise the measured arm).
  - Position tolerance stays 4 mm. Orientation is exact (0.035 rad) first; if that fails or sits within 0.03 rad of a joint limit, a relaxed solve is used with a declared bound of **0.26 rad**.
  - The original `self_collision.valid` validator is checked at the path midpoint and the endpoint.
  - Returns `[q]`, `[]` (hold the previous joint goal, only while the hand touched the person in the last 0.5 s) or `None` (original backend, e.g. first approach).
- **`_align`**: the force direction is now the full 3D line from the support point to the measured wrist, so the wrist reaction is close to pure tension. Bounds: elevation -0.12..0.314 rad, azimuth +/-0.15 rad, rate 0.6 rad/s.
- **`_track`** (measured palm only, no human internal phase):
  - Tangential lead over the measured palm capped at 0.08 m; sag compensation capped at 0.07 m and frozen/decayed when tracking error exceeds 0.10 m or IK is unreachable.
  - When IK is unreachable the target yields toward the measured palm instead of dropping away: `lower` is now at most 0.05 m at 0.04 m/s, inside the 0.08 m gap gate.
  - When IK is unreachable the commanded palm orientation steps toward the measured one, at most 0.20 rad from nominal. Worst-case total deviation from the nominal palm orientation is therefore 0.46 rad.
  - Once the person is lifted, the request is zero and the CoM is over the ankles, the palms back off within the existing depth bound so they do not push the chest back.
- **Base retreat (sensed plan only)**: velocity-only, at most 0.10 m/s and 0.40 m, never closer than the dock. It keeps horizontal reach to the chest near 0.78 m so the arms stay unfolded as the chest advances. This is a new policy command; the unsafe plan keeps a static base.

## Unchanged

Actions, contact (0.12 s) and gap (<0.08 m) gates, force caps, equal/opposite wrist force and moment, human constants (rise 9 deg/s), geometry, goal, and the unsafe plan's static arms at 150/50 N.

## Runtime checks still needed

1. In `ik_records`, joint-goal steps stay at or below 0.30 rad during contact and no joint sits on a limit.
2. `support_target_gap_m` stays below 0.08 m with continuous contact through the rise.
3. The base retreat does not disturb the hands: tracking error below 0.10 m, no chassis-human contact, peak robot speed within limits.
4. `[]` returns from the IK helper are rare and recover within a few 0.15 s cycles; if they persist, the arms hold while the chest moves and the old failure can recur.
5. Wrist moments and net lateral force stay small with the 3D force line.
6. Standing is reached (pelvis >0.88 m, torso <20 deg, speed <0.2 m/s, both feet for 1 s), then taper, release and verify complete.
7. The unsafe plan's outcome is unchanged with the shared IK helper wired in.
