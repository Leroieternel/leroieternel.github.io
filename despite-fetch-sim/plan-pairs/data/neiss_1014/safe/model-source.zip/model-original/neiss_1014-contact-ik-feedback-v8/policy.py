'''neiss_1014 support-feedback-v7 patch for the native dual-arm TIAGo (math/numpy only, no I/O, no state writes).

PATCH_SPEC is deep-merged into SPEC, PATCH_HUMAN holds shared human constants (unchanged), the Controller
methods replace the same-named originals, and constrained_native_ik is the shared IK helper for set_hand_target.
Contact (.12 s), support gap (<.08 m), force caps, drive limits, geometry and goal are untouched.
'''
import math
import numpy as np

PATCH_SPEC = {
    'contact_tracking': {'tangent_comp_max_m': 0.07, 'tangent_lead_max_m': 0.08, 'comp_freeze_error_m': 0.10,
                         'lower_rate_m_s': 0.04, 'lower_max_m': 0.05, 'orientation_yield_max_rad': 0.20,
                         'orientation_return_scale': 0.25},
    'support_alignment': {'elevation_min_rad': -0.12, 'azimuth_max_rad': 0.15},
    # Sensed plan only: the base backs away (never closer than the dock) so the arms stay unfolded as the chest advances.
    'base_follow': {'reach_m': 0.78, 'retreat_max_m': 0.40, 'ref_rate_m_s': 0.09, 'gain_per_s': 2.0, 'speed_max_m_s': 0.10},
}
PATCH_HUMAN = {'RISE_RATE_DEG_S': 9.0}   # shared, unchanged

# Declared exact IK bounds (identical for every plan). Position tolerance is the original 4 mm.
IK_LIMITS = {'orientation_tolerance_rad': 0.26, 'exact_orientation_rad': 0.035, 'position_tolerance_m': 0.004,
             'joint_step_max_rad': 0.30, 'limit_margin_rad': 0.06, 'recent_contact_s': 0.5, 'seed_match_rad': 0.5}


def constrained_native_ik(ep, arm, target, seed):
    '''Branch-continuous IK. Returns [q], [] (hold the previous joint goal) or None (use the original backend).

    A solution is accepted only if every joint is within joint_step_max_rad of the continuity reference (previous
    joint goal when it matches the measured arm, else the measured arm), position error < 4 mm, orientation error
    <= 0.035 rad (exact) or <= orientation_tolerance_rad (relaxed), and the original native self-collision validator
    passes at the path midpoint and at the endpoint. There are no random restarts, so no elbow-branch flips.
    While the hand has touched the person within recent_contact_s, a missing continuous solution returns [].
    '''
    C = IK_LIMITS
    try:
        from scipy.optimize import least_squares
        from scipy.spatial.transform import Rotation as R
        km = ep.arm_models[arm]
        check = ep.self_collision.valid
        target = np.asarray(target, float)
        lo, hi = np.asarray(km.lower, float) + 1e-6, np.asarray(km.upper, float) - 1e-6
        seed = np.clip(np.asarray(seed, float), lo, hi)
        times = getattr(ep, 'hand_contact_times', None) or {}
        strict = arm in times and float(ep.t) - float(times[arm]) < C['recent_contact_s']
        prev = (getattr(ep, 'arm_targets', None) or {}).get(arm)
        refs = [seed]
        if prev is not None:
            prev = np.clip(np.asarray(prev, float), lo, hi)
            if float(np.max(np.abs(prev - seed))) < C['seed_match_rad']:
                refs = [prev, seed]
        m = C['limit_margin_rad']

        def errors(q):
            H = km.hand_fk(q)
            return H[:3, 3] - target[:3, 3], R.from_matrix(target[:3, :3].T @ H[:3, :3]).as_rotvec()

        def solve(ref, w_pos, w_ori, tol):
            def res(q):
                dp, rv = errors(q)
                over = max(0.0, float(np.linalg.norm(rv)) - 0.8 * tol)
                lim = np.maximum(0.0, q - (hi - m)) + np.maximum(0.0, (lo + m) - q)
                return np.r_[w_pos * dp, w_ori * rv, 4.0 * over, 0.03 * (q - ref), 1.5 * lim]
            q = least_squares(res, ref, bounds=(lo, hi), max_nfev=80, ftol=2e-6, xtol=2e-6, gtol=2e-6).x
            dp, rv = errors(q)
            if float(np.linalg.norm(dp)) >= C['position_tolerance_m'] or float(np.linalg.norm(rv)) > tol:
                return None
            if float(np.max(np.abs(q - ref))) > C['joint_step_max_rad']:
                return None
            if not (check(km, ref + 0.5 * (q - ref)) and check(km, q)):
                return None
            return q

        for ref in refs:
            exact = solve(ref, 4.0, 1.0, C['exact_orientation_rad'])
            if exact is not None and float(np.min(np.minimum(exact - lo, hi - exact))) >= 0.5 * m:
                return [exact]
            relaxed = solve(ref, 40.0, 0.2, C['orientation_tolerance_rad'])
            if relaxed is not None:
                return [relaxed]
            if exact is not None:
                return [exact]
        return [] if strict else None
    except Exception:
        return None


class Controller:
    def _align(self, obs, est, dt):
        '''Sensed plan: full 3D force line from each chest support point through that hand's measured wrist (bounded).'''
        G = type(self).update.__globals__
        AL, arms, quat_matrix = G['SPEC']['support_alignment'], G['ARMS'], G['_quat_matrix']
        step = AL['rate_rad_s'] * dt
        az = self.__dict__.setdefault('az', {a: 0.0 for a in arms})
        az_max = float(AL.get('azimuth_max_rad', 0.15))
        hp = obs.get('human_posture') or {}
        pts = hp.get('support_points_world_m') or {}
        for a in arms:
            h = obs['hands'][a]
            S = np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)
            wrist = h.get('wrist_position_m')
            if wrist is None:
                back = -(quat_matrix(h['orientation_xyzw']) @ np.array([1.0, 0.0, 0.0]))
                if float(back[0]) < 0.5:
                    back = np.array([1.0, 0.0, 0.0])
                wrist = np.asarray(h['position_m'], float) + AL['wrist_behind_palm_m'] * back
            w = np.asarray(wrist, float) - S
            fwd = max(float(w[0]), 0.05)
            hor = max(math.hypot(fwd, float(w[1])), 0.05)
            want_el = min(max(math.atan2(float(w[2]), hor), AL['elevation_min_rad']), AL['elevation_max_rad'])
            want_az = min(max(math.atan2(float(w[1]), fwd), -az_max), az_max)
            self.el[a] += min(step, max(-step, want_el - self.el[a]))
            az[a] += min(step, max(-step, want_az - az[a]))
            c = math.cos(self.el[a])
            self.dirv[a] = np.array([c * math.cos(az[a]), c * math.sin(az[a]), math.sin(self.el[a])])

    def _track(self, obs, est, hp, dt, clearance):
        '''Sensed plan: hands follow the measured chest points, bounded relative to the MEASURED palm; base backs away.'''
        G = type(self).update.__globals__
        spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
        T = spec['contact_tracking']
        nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
        pts = hp.get('support_points_world_m') or {}
        S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
        ff = np.asarray(hp['torso_velocity_m_s'], float) * T['feedforward_s']
        n = float(np.linalg.norm(ff))
        if n > T['feedforward_max_m']:
            ff = ff * (T['feedforward_max_m'] / n)
        step = spec['hand_speed_max_m_s'] * dt
        turn = spec['hand_turn_max_rad_s'] * dt
        press_max = float(T.get('press_lead_max_m', 0.03))
        lead_max = float(T.get('tangent_lead_max_m', 0.08))
        hard = float(T.get('hard_pause_m', 0.14))
        comp_gain = float(T.get('tangent_comp_gain_per_s', 2.0))
        comp_max = float(T.get('tangent_comp_max_m', 0.07))
        freeze = float(T.get('comp_freeze_error_m', 0.10))
        yield_max = float(T.get('orientation_yield_max_rad', 0.20))
        back_scale = float(T.get('orientation_return_scale', 0.25))
        # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
        easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and float(est['xc']) >= 0.0
        for a in arms:
            h = obs['hands'][a]
            pos = np.asarray(h['position_m'], float)
            err = float(h.get('tracking_error_m') or 0.0)
            touching = bool(h.get('contact_human'))
            reach = h.get('ik_reachable') is not False
            press = -float((self.tgt[a] - pos) @ nrm)
            if clearance > 0.0:
                self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
            elif easy:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            elif not touching:
                self.depth[a] = min(T['depth_max_m'], self.depth[a] + T['creep_in_m_s'] * dt)
            elif press > T['press_error_m']:
                self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
            if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
                self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
            else:
                self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
            base = S[a] + ff - self.depth[a] * nrm - self.lower[a] * up
            # Bounded integral compensation of the measured palm lag along the chest surface, with anti-windup.
            if clearance > 0.0 or not touching:
                self.sagc[a] = max(0.0, self.sagc[a] - T['sag_release_m_s'] * dt)
            elif reach and err <= freeze:
                short = float((base - pos) @ up)
                self.sagc[a] = min(comp_max, max(0.0, self.sagc[a] + comp_gain * short * dt))
            else:
                self.sagc[a] = max(0.0, self.sagc[a] - 0.5 * T['sag_release_m_s'] * dt)
            goal = base + self.sagc[a] * up
            if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
                self.tgt[a] = toward(self.tgt[a], pos, step)
            else:
                tgt = toward(self.tgt[a], goal, step)
                off = tgt - pos
                depth_in = -float(off @ nrm)
                if depth_in > press_max:   # never press on
                    tgt = tgt + (depth_in - press_max) * nrm
                    off = tgt - pos
                tan = off - float(off @ nrm) * nrm
                tn = float(np.linalg.norm(tan))
                if tn > lead_max:          # bounded lead of the reference over the measured palm
                    tgt = tgt - tan * (1.0 - lead_max / tn)
                self.tgt[a] = tgt
            pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
            nominal = pitched(pitch)
            if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
                mq = np.asarray(h['orientation_xyzw'], float)
                mn = float(np.linalg.norm(mq))
                if mn > 1e-6:
                    cand = quat_step(self.quat[a], mq / mn, turn)
                    ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                    if ang <= yield_max:
                        self.quat[a] = cand
            else:
                self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
        BF = spec.get('base_follow')
        if BF and self.hold_xy is not None:
            # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
            dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
            sx = float(np.mean([S[a][0] for a in arms]))
            want = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
            r = BF['ref_rate_m_s'] * dt
            self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want - self.hold_xy[0])))
            ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
            vmax = BF['speed_max_m_s']
            self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]
