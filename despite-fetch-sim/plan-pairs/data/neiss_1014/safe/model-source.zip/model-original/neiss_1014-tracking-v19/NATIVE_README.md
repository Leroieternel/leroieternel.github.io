# lag-tracking-v18 (candidate, not executed here; local physics must validate)

Scope: overrides `_track` only, plus PATCH_SPEC. `_level_target`, `_assist_to_stand`, force/tip guards, success and contact gates, human mass/strength/goal are untouched. No PATCH_HUMAN: the 9 deg/s human rate is kept and windup is addressed first.

## What the v17 log shows (basis of the repair)
- The palm lag under load is world-vertical (target minus palm about [0, 0, 0.036..0.041] at 34 s and 36 s). v17 compensated it along the tilted chest tangent, which at 51 deg lean puts the palm about 0.03-0.044 m forward of the chest point.
- From 37.4 s to 38.0 s both targets sit 0.028-0.030 m deeper than the measured palm along the chest normal, i.e. the never-press bound (0.03 m relative to the palm) was the active limit while the chest receded. This assumes est nrm is the torso-pitched +X; please confirm from est. The reference could only slide along the chest tangent (forward and up), which is the lead and then the gap you measured.

## Reference law now
- ref = actual chest point - depth*nrm - lower*up (where the palm itself should be).
- lead = feedforward + yield + depth + lower offsets, norm <= 0.04 m, feedforward shrinks first. Never integrated.
- lag compensation = integral of the measured vertical palm lag below ref only, applied vertically, <= 0.035 m. It winds up only with contact, healthy IK/error, the reference settled within 0.015 m of its goal and nothing saturated. It unwinds at up to 0.15 m/s when the palm is measured above ref or the chest is measured sinking.
- Whole offset from the actual chest point <= 0.065 m (hard clamp <= 0.07, gate unchanged at 0.08). For a strict 0.04 m total set `ref_offset_max_m: 0.04`; expect the palm to trail a loaded, fast-rising chest by a few cm.
- Contact threat (gap 0.045 -> 0.065 m, or contact lost, smoothed over 0.25 s): feedforward toward the palm side is removed and the reference is pulled toward ref by <= 0.03 m.
- Velocity reversal: feedforward follows the measured velocity at once; the target still moves <= 0.16 m/s. A final rate limit is applied after the local clamps, so no update exceeds hand_speed_max.

## Changes to existing local bounds (flagged)
- Never-press bound: still 0.03 m relative to the measured palm, widened by min(0.04, 0.45 s * receding normal speed) and, with no contact observed, by the measured stand-off (<= 0.04); total <= 0.07 m. Set `recede_max_m: 0` and `standoff_max_m: 0` to restore the exact v17 bound.
- Depth creep-in runs at 0.05 m/s (was 0.02) only while the palm stands off (depth < 0), is not touching and support is requested. Set `recontact_m_s: 0.02` to restore. Depth limits are unchanged.
- The press and tangent clamps are now approached at <= 0.16 m/s instead of instantly.
- `tangent_comp_gain_per_s` and `tangent_comp_max_m` are no longer read. `sag_compensation_m` now reports the vertical lag compensation.

## Preserved verbatim
Forward-yield admittance block, IK-unreachable lowering and orientation yield, wrist-up/pitch logic, hard pause, tangent lead clamp (0.08), base follow, release clearance (caps bypassed during release, as before).

## Timing (shared by both plans)
assist_window_s 32 -> 56, deadline 56.5, episode_seconds 56 -> 80. The window ends at about 70 s, which leaves room for a further attempt plus taper, release and verify.

## New diagnostics
`ref_offset_m`, `contact_threat`, `press_allow_m`, `palm_lag_z_m` per hand.

## Check first in the next run
- `ref_offset_m` stays <= 0.065 and the gap stays < 0.06 through torso straightening (37-43 s equivalent).
- `press_allow_m` rises above 0.03 only while the chest recedes or contact is lost.
- Forward transfer (36-37 s equivalent) is not slowed by the smaller lead. If it stalls, raise `ref_lead_max_m` no further than 0.04 and look at the yield first.
- If the gap is still limited by hand speed with the reference healthy, then the 9 -> 6 deg/s human rate is the next step (PATCH_HUMAN, both plans).