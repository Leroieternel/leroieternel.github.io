# Fable lag-tracking-v18: overrides only the sensed plan's _track, plus PATCH_SPEC. math/numpy only, no I/O.
# No PATCH_HUMAN: human rise rate, mass, strength, goal and contact gates are untouched.
import math
import numpy as np

PATCH_SPEC = {
    'episode_seconds': 80.0,
    'assist_window_s': 56.0,
    'deadlines_s': {'assist_to_stand': 56.5},
    'lag_tracking': {
        'ref_lead_max_m': 0.04,       # feedforward + yield + depth + lower, relative to the actual chest point
        'lag_max_m': 0.035,           # vertical compensation of measured palm lag only
        'ref_offset_max_m': 0.065,    # hard cap of the whole reference offset (gate stays 0.08)
        'lag_gain_per_s': 2.0,
        'lag_wind_m_s': 0.05,
        'unwind_gain_per_s': 4.0,
        'unwind_m_s': 0.15,
        'reverse_v_m_s': 0.03,
        'settle_m': 0.015,
        'gap_warn_m': 0.045,
        'gap_full_m': 0.065,
        'threat_rate_per_s': 4.0,
        'pull_gain': 0.75,
        'pull_max_m': 0.03,
        'recede_s': 0.45,
        'recede_max_m': 0.04,
        'standoff_max_m': 0.04,
        'press_follow_max_m': 0.07,
        'recontact_m_s': 0.05,
    },
}


def _track(self, obs, est, hp, dt, clearance):
    '''Sensed plan: hands follow the measured chest points; base backs away (unchanged).
    v18 reference repair:
      - the palm reference is the ACTUAL chest point (minus depth/lower); feedforward and yield are an intentional
        lead and are never integrated;
      - the only integral term is the measured vertical lag of the palm below that reference (the logged sag is
        world-vertical), applied vertically, bounded, frozen while the reference is saturated or still travelling,
        and unwound quickly when the palm is measured above the reference or the chest is measured sinking;
      - lead <= 0.04 m (feedforward shrinks first), lag compensation <= 0.035 m, whole offset from the actual chest
        point <= 0.065 m (< 0.08 m gate);
      - contact threat (gap near the gate, or contact lost): lead toward the palm side is removed and the reference
        is pulled back toward the chest reference (bounded);
      - the never-press bound relative to the measured palm is widened by a bounded amount only while the chest is
        measured receding along its normal or while no contact is observed, so the palm can follow a straightening
        torso; otherwise it is the original bound;
      - every target update is finally limited to hand_speed_max (no teleports).
    Forward-yield admittance, IK yielding, wrist pitch and base follow are the v17 code.'''
    G = type(self).update.__globals__
    spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
    T = spec['contact_tracking']
    WU = spec.get('wrist_up') or {}
    A = spec.get('yield_admittance') or {}
    LT = spec.get('lag_tracking') or {}
    nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
    pts = hp.get('support_points_world_m') or {}
    S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
    vel = np.asarray(hp['torso_velocity_m_s'], float)
    ff = vel * T['feedforward_s']
    n = float(np.linalg.norm(ff))
    if n > T['feedforward_max_m']:
        ff = ff * (T['feedforward_max_m'] / n)
    v_hand = float(spec['hand_speed_max_m_s'])
    step = v_hand * dt
    turn = spec['hand_turn_max_rad_s'] * dt
    press_max = float(T.get('press_lead_max_m', 0.03))
    lead_max = float(T.get('tangent_lead_max_m', 0.08))
    hard = float(T.get('hard_pause_m', 0.14))
    freeze = float(T.get('comp_freeze_error_m', 0.10))
    yield_max = float(T.get('orientation_yield_max_rad', 0.20))
    back_scale = float(T.get('orientation_return_scale', 0.25))
    wu_max = float(WU.get('max_rad', 0.22))
    wu_rate = min(float(WU.get('rate_rad_s', 0.25)), float(spec['hand_turn_max_rad_s'])) * dt
    z_full, z_zero = float(WU.get('full_below_z_m', 0.90)), float(WU.get('zero_above_z_m', 1.00))
    lvl_min = float(WU.get('min_level_N', 5.0))
    # Forward-yield admittance parameters (v17, hard-clamped to the stated bounds whatever the spec says).
    a_max = min(max(float(A.get('max_m', 0.04)), 0.0), 0.04)
    a_rate = min(max(float(A.get('rate_m_s', 0.02)), 0.0), 0.02)
    a_back = min(max(float(A.get('return_m_s', 0.03)), 0.0), v_hand)
    idle = min(1.0, max(0.0, float(A.get('idle_fraction', 0.5))))
    c0, c_span = float(A.get('comp_deadband_m', 0.004)), max(float(A.get('comp_span_m', 0.006)), 1e-4)
    a_err, dwell = float(A.get('err_max_m', 0.03)), float(A.get('dwell_s', 0.25))
    g_stop, g_back = float(A.get('gap_stop_m', 0.06)), float(A.get('gap_back_m', 0.07))
    bite, cap_rate = float(A.get('bite_m', 0.006)), float(A.get('cap_recover_m_s', 0.003))
    com_max, lvl_y = float(A.get('com_max_m', 0.02)), float(A.get('min_level_N', 5.0))
    v_fwd, v_back = float(A.get('v_fwd_max_m_s', 0.08)), float(A.get('v_back_max_m_s', 0.03))
    # v18 lag-tracking parameters (hard-clamped below the unchanged 0.08 m gate whatever the spec says).
    lead_cap = min(max(float(LT.get('ref_lead_max_m', 0.04)), 0.0), 0.04)
    lag_cap = min(max(float(LT.get('lag_max_m', 0.035)), 0.0), 0.04)
    off_cap = min(max(float(LT.get('ref_offset_max_m', 0.065)), lead_cap), 0.07)
    k_up = max(float(LT.get('lag_gain_per_s', 2.0)), 0.0)
    wind = max(float(LT.get('lag_wind_m_s', 0.05)), 0.0)
    k_dn = max(float(LT.get('unwind_gain_per_s', 4.0)), 0.0)
    un_max = min(max(float(LT.get('unwind_m_s', 0.15)), 0.0), v_hand)
    v_rev = max(float(LT.get('reverse_v_m_s', 0.03)), 0.0)
    settle = max(float(LT.get('settle_m', 0.015)), 0.0)
    g_warn = float(LT.get('gap_warn_m', 0.045))
    g_span = max(float(LT.get('gap_full_m', 0.065)) - g_warn, 1e-3)
    thr_rate = max(float(LT.get('threat_rate_per_s', 4.0)), 0.0)
    k_pull = min(max(float(LT.get('pull_gain', 0.75)), 0.0), 1.0)
    pull_max = min(max(float(LT.get('pull_max_m', 0.03)), 0.0), 0.04)
    rec_s = max(float(LT.get('recede_s', 0.45)), 0.0)
    rec_max = min(max(float(LT.get('recede_max_m', 0.04)), 0.0), 0.05)
    so_max = min(max(float(LT.get('standoff_max_m', 0.04)), 0.0), 0.05)
    follow_extra = max(0.0, min(float(LT.get('press_follow_max_m', 0.07)), 0.08) - press_max)
    creep_in = float(T['creep_in_m_s'])
    recontact = min(max(float(LT.get('recontact_m_s', 0.05)), creep_in), v_hand)
    zup = np.array([0.0, 0.0, 1.0])
    vz, vn = float(vel[2]), float(vel @ nrm)
    out = np.array([1.0, 0.0, 0.0])
    tip = self.__dict__.get('tip') or {}
    guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
    head = float(tip.get('headroom', 0.0)) * (1.0 - guard)
    wp = self.__dict__.setdefault('wpitch', {})
    yld = self.__dict__.setdefault('yld', {a: {'x': 0.0, 't': 0.0, 'cap': a_max, 'was': False} for a in arms})
    lt = self.__dict__.setdefault('lagt', {})
    xc, vf = float(est['xc']), float(est['v_fwd'])
    unstable = bool(getattr(self, 'unstable', False))
    # Yield for the person only while support is requested, the CoM is not yet over the feet and the chest is slow.
    calm = xc < com_max and -v_back < vf < v_fwd and self.level >= lvl_y
    # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
    easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and xc >= 0.0
    live = clearance <= 0.0 and not easy
    info = {}
    for a in arms:
        st = lt.setdefault(a, {'pend': 0.0, 'sat': False, 'extra': 0.0, 'nc': 0.0})
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        err = float(h.get('tracking_error_m') or 0.0)
        touching = bool(h.get('contact_human'))
        reach = h.get('ik_reachable') is not False
        press = -float((self.tgt[a] - pos) @ nrm)
        y = yld[a]
        gap = float(np.linalg.norm(pos - S[a]))
        comp = float((pos - self.tgt[a]) @ out)   # measured palm pushed toward the robot relative to its command
        if clearance > 0.0 or easy:               # release / weight over feet: hold the yield, original back-off acts
            y['t'], y['was'] = 0.0, False
        elif (not touching) or unstable or gap > g_back:
            if y['was'] and not unstable:         # remember where contact ended; do not re-probe past it at once
                y['cap'] = max(0.0, y['x'] - bite)
            y['t'], y['was'] = 0.0, False
            y['x'] = max(0.0, y['x'] - a_back * dt)
        elif reach and err <= a_err and gap <= g_stop:
            y['t'], y['was'] = y['t'] + dt, True
            y['cap'] = min(a_max, y['cap'] + cap_rate * dt)
            if y['t'] >= dwell:
                push = max(guard, min(1.0, max(0.0, comp - c0) / c_span) if calm else 0.0)
                if push > 0.0:                    # measured compression or sensed base tilt: yield toward the robot
                    y['x'] = min(a_max, y['x'] + a_rate * push * dt)
                    y['cap'] = max(y['cap'], y['x'])
                elif calm and y['x'] < y['cap']:  # slow contact-gated creep up to the learned contact boundary
                    y['x'] = min(y['cap'], y['x'] + a_rate * idle * dt)
        else:
            y['t'] = 0.0                          # IK / tracking / gap not healthy: freeze (anti-windup)
        if clearance > 0.0:
            self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
        elif easy:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        elif not touching:
            if y['x'] <= 1e-4 or self.depth[a] < 0.0:   # withdraw the yield first, then the creep-in
                # a stand-off while support is requested is a contact threat: close it faster (same depth bounds)
                rate = recontact if (self.depth[a] < 0.0 and self.level >= lvl_y and not unstable) else creep_in
                self.depth[a] = min(T['depth_max_m'], self.depth[a] + rate * dt)
        elif press > T['press_error_m'] + st['extra']:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
            self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
        else:
            self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
        # ---- v18 reference: actual chest point + bounded lead + measured-lag compensation ----
        fixed = min(y['x'], a_max) * out - self.depth[a] * nrm - self.lower[a] * up
        ref = S[a] - self.depth[a] * nrm - self.lower[a] * up   # where the palm itself should be (no lead)
        gv = pos - ref
        gn = float(np.linalg.norm(gv))
        lag_z = -float(gv[2])                                   # > 0: palm measured below the chest reference
        if live and not touching:
            st['nc'] = min(1.0, st['nc'] + thr_rate * dt)
        else:
            st['nc'] = max(0.0, st['nc'] - thr_rate * dt)
        thr = max(st['nc'], min(1.0, max(0.0, (gap - g_warn) / g_span))) if live else 0.0
        c_lag = float(self.sagc[a])
        if clearance > 0.0:
            c_lag = max(0.0, c_lag - T['sag_release_m_s'] * dt)
        elif lag_z < 0.0 or vz < -v_rev:
            # palm measured above the reference, or chest measured sinking: compensation exceeds the real lag
            dec = min(un_max, k_dn * max(0.0, -lag_z))
            if vz < -v_rev:
                dec = max(dec, min(un_max, -vz))
            c_lag = max(0.0, c_lag - dec * dt)
        elif (not reach) or err > freeze:
            c_lag = max(0.0, c_lag - 0.5 * T['sag_release_m_s'] * dt)
        elif touching and (not unstable) and st['pend'] <= settle and not st['sat']:
            # real lag only: reference settled on its goal, nothing saturated, contact observed
            c_lag = c_lag + min(wind, k_up * lag_z) * dt
        c_lag = min(max(c_lag, 0.0), lag_cap)
        self.sagc[a] = c_lag
        ffa = ff
        if thr > 0.0 and gn > 1e-6:   # contact threat: no lead that carries the reference further to the palm side
            along = float(ff @ gv) / gn
            if along > 0.0:
                ffa = ff - (thr * along / gn) * gv
        lead = fixed + ffa
        capped = False
        if clearance <= 0.0:
            ln = float(np.linalg.norm(lead))
            if ln > lead_cap:         # bounded intentional lead; feedforward gives way first
                fn = float(np.linalg.norm(fixed))
                a2 = float(ffa @ ffa)
                if fn >= lead_cap:
                    lead = fixed * (lead_cap / max(fn, 1e-9))
                elif a2 < 1e-12:
                    lead = lead * (lead_cap / ln)
                else:
                    b = float(fixed @ ffa)
                    s = (-b + math.sqrt(max(b * b - a2 * (fn * fn - lead_cap * lead_cap), 0.0))) / a2
                    lead = fixed + min(1.0, max(0.0, s)) * ffa
        offv = lead + c_lag * zup
        if thr > 0.0 and gn > 1e-6:   # bounded pull of the reference back toward the chest reference
            offv = offv - (min(pull_max, k_pull * thr * gn) / gn) * gv
        if clearance <= 0.0:
            on = float(np.linalg.norm(offv))
            if on > off_cap:
                offv = offv * (off_cap / on)
                capped = True
        goal = S[a] + offv
        extra = 0.0
        if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
            self.tgt[a] = toward(self.tgt[a], pos, step)
            capped = True
        else:
            tgt = toward(self.tgt[a], goal, step)
            if clearance <= 0.0:
                # chest measured receding along its normal, or no contact observed: following is not pressing
                extra = min(rec_max, rec_s * max(0.0, -vn))
                if live:
                    extra += st['nc'] * min(so_max, max(0.0, float(gv @ nrm)))
                extra = min(extra, follow_extra)
            allow = press_max + extra
            off = tgt - pos
            depth_in = -float(off @ nrm)
            if depth_in > allow:       # never press on
                tgt = tgt + (depth_in - allow) * nrm
                off = tgt - pos
            tan = off - float(off @ nrm) * nrm
            tn = float(np.linalg.norm(tan))
            if tn > lead_max:          # bounded lead of the reference over the measured palm
                tgt = tgt - tan * (1.0 - lead_max / tn)
            self.tgt[a] = toward(self.tgt[a], tgt, step)   # final speed limit: no target teleports
        st['pend'] = float(np.linalg.norm(goal - self.tgt[a]))
        st['sat'] = bool(capped)
        st['extra'] = float(extra)
        info[a] = (float(np.linalg.norm(goal - S[a])), float(thr), float(press_max + extra), float(lag_z))
        pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
        # Wrist-up component (negative pitch = wrist above palm): faded out with hand height, scaled by spare native
        # tip margin, released when contact, IK or tracking is not healthy. Scalar starts from the current command.
        fade = min(1.0, max(0.0, (z_zero - float(goal[2])) / max(z_zero - z_full, 1e-3)))
        ok = clearance <= 0.0 and touching and reach and err <= freeze and (not easy) and self.level >= lvl_min
        want = -wu_max * fade * head if ok else 0.0
        if a not in wp:
            q0 = self.quat[a]
            sg = 1.0 if float(q0[2]) >= 0.0 else -1.0
            wp[a] = min(0.0, max(-wu_max, 2.0 * math.atan2(sg * float(q0[0]), sg * float(q0[2]))))
        wp[a] += min(wu_rate, max(-wu_rate, want - wp[a]))
        nominal = pitched(pitch + wp[a])
        if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
            mq = np.asarray(h['orientation_xyzw'], float)
            mn = float(np.linalg.norm(mq))
            if mn > 1e-6:
                cand = quat_step(self.quat[a], mq / mn, turn)
                ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                if ang <= yield_max:
                    self.quat[a] = cand
        else:
            self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
    self.diag = dict(getattr(self, 'diag', None) or {}, yield_forward_m={a: float(yld[a]['x']) for a in arms},
                     yield_cap_m={a: float(yld[a]['cap']) for a in arms},
                     ref_offset_m={a: info[a][0] for a in arms}, contact_threat={a: info[a][1] for a in arms},
                     press_allow_m={a: info[a][2] for a in arms}, palm_lag_z_m={a: info[a][3] for a in arms})
    BF = spec.get('base_follow')
    if BF and self.hold_xy is not None:
        # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
        dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
        sx = float(np.mean([S[a][0] for a in arms]))
        want_x = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
        r = BF['ref_rate_m_s'] * dt
        self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want_x - self.hold_xy[0])))
        ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
        vmax = BF['speed_max_m_s']
        self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]
