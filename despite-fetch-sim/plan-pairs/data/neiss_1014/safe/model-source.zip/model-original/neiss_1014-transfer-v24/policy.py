# Fable stand-transfer-v24: measured phase composition for the sensed plan (numpy only, no I/O).
# Retains the supplied methods untouched and adds clearly named helpers:
#   _track_early_v17      exact v17 _track (passed to install)          -> used until high rise is measured
#   _track_late_v19       production v19 _track (captured by install)   -> used once pelvis > pelvis_start_m
#   _level_target_base    production _level_target (captured by install) -> early support law, exact
#   _rise_phase_factor    measured pelvis-height latch and smooth blend; re-armed when measured seated again
#   _palm_push_guard      late rise: no compressive palm push while contact is observed
#   _late_support_target  late rise: capture-point request that keeps the needed foot pressure centre mid-foot
#   _track / _level_target  thin dispatchers (_track_phased / _level_target_phased)
# Install: install(policy_module, early_track=<exact v17 _track function>); see NATIVE_README.md.
import numpy as np

PATCH_SPEC = {
    'rise_phase': {'pelvis_start_m': 0.80, 'pelvis_full_m': 0.86, 'reseat_margin_m': 0.03},
    'late_support': {'enabled': True, 'cop_ref_m': 0.035, 'gain': 1.25, 'capture_s': 0.30,
                     'forward_velocity_fraction': 0.5, 'velocity_cap_m_s': 0.30, 'back_v_m_s': 0.04,
                     'reengage_window_s': 0.25},
    'palm_guard': {'enabled': True, 'press_m': 0.015, 'follow_s': 0.18, 'follow_max_m': 0.04,
                   'free_extra_m': 0.05},
}


def _rise_phase_factor(self, hp):
    '''Measured high-rise state from the sensed pelvis height. latched False / blend 0 keeps the exact early
    behaviour. blend rises smoothly with measured height and never drops within an attempt; both are re-armed
    only when the pelvis is measured back at seat height, so a later attempt starts with the early methods.'''
    G = type(self).update.__globals__
    P = G['SPEC'].get('rise_phase') or {}
    z0 = float(P.get('pelvis_start_m', 0.80))
    z1 = max(float(P.get('pelvis_full_m', 0.86)), z0 + 0.01)
    margin = float(P.get('reseat_margin_m', 0.03))
    st = self.__dict__.setdefault('rise_phase', {'latched': False, 'blend': 0.0})
    pz = float(hp['pelvis_position_m'][2])
    seat = getattr(self, 'seat_z', None)
    if pz > z0:
        st['latched'] = True
    elif st['latched'] and seat is not None and pz < float(seat) + margin:
        st['latched'], st['blend'] = False, 0.0
    if st['latched']:
        x = min(1.0, max(0.0, (pz - z0) / (z1 - z0)))
        st['blend'] = max(float(st['blend']), x * x * (3.0 - 2.0 * x))
    return st


def _palm_push_guard(self, obs, est, hp, dt, prev, blend):
    '''Late rise only, applied after the retained late track. While contact is observed the commanded palm may be
    deeper than the MEASURED palm (along the chest normal, and along world -X toward the person) only by a small
    preload plus the kinematic lag needed to follow a chest that is measured receding. The preload blends from the
    early bound (press_lead_max_m) to press_m with measured rise progress. It only ever moves the target outward,
    widens again by the late track's own no-contact factor, and keeps the total target step <= hand_speed_max.'''
    G = type(self).update.__globals__
    spec, toward, arms = G['SPEC'], G['_toward'], G['ARMS']
    P = spec.get('palm_guard') or {}
    if not P.get('enabled', True):
        return {}
    T = spec['contact_tracking']
    press_max = float(T.get('press_lead_max_m', 0.03))
    b_late = min(max(float(P.get('press_m', 0.015)), 0.0), press_max)
    tau = min(max(float(P.get('follow_s', 0.18)), 0.0), 0.3)
    kin_cap = min(max(float(P.get('follow_max_m', 0.04)), 0.0), 0.05)
    free = min(max(float(P.get('free_extra_m', 0.05)), 0.0), 0.06)
    b0 = press_max + (b_late - press_max) * min(1.0, max(0.0, float(blend)))
    nrm = np.asarray(est['nrm'], float)
    vel = np.asarray(hp['torso_velocity_m_s'], float)
    kin_n = min(kin_cap, tau * max(0.0, -float(vel @ nrm)))   # chest measured receding along its normal
    kin_x = min(kin_cap, tau * max(0.0, -float(vel[0])))      # chest measured receding from the robot
    step = float(spec['hand_speed_max_m_s']) * dt
    out = np.array([1.0, 0.0, 0.0])
    lagt = self.__dict__.get('lagt') or {}
    press, bound = {}, {}
    for a in arms:
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        nc = (lagt.get(a) or {}).get('nc')
        if nc is None:
            nc = 0.0 if bool(h.get('contact_human')) else 1.0
        nc = min(1.0, max(0.0, float(nc)))
        bn = b0 + kin_n + nc * free
        bx = b0 + kin_x + nc * free
        tgt = np.array(self.tgt[a], float)
        d_n = -float((tgt - pos) @ nrm)
        if d_n > bn:
            tgt = tgt + (d_n - bn) * nrm
        d_x = -float(tgt[0] - pos[0])
        if d_x > bx:
            tgt = tgt + (d_x - bx) * out
        if float(np.linalg.norm(tgt - self.tgt[a])) > 1e-9:
            self.tgt[a] = toward(prev[a], tgt, step)
        press[a] = -float((self.tgt[a] - pos) @ nrm)
        bound[a] = float(bn)
    return {'palm_press_m': press, 'palm_press_bound_m': bound}


def _late_support_target(self, est):
    '''Per-hand request (N) that puts the foot pressure centre the person needs at cop_ref_m ahead of the ankle,
    computed on the capture point of the sensed CoM (full weight on backward velocity, a fraction on forward).
    Zero once the capture point is at or ahead of cop_ref_m. Returns (request, capture_point).'''
    G = type(self).update.__globals__
    spec, arms = G['SPEC'], G['ARMS']
    SAFE, BODY = spec['safe_force_N'], spec['anthropometric_model']
    L = spec.get('late_support') or {}
    p_ref = min(max(float(L.get('cop_ref_m', 0.035)), 0.0), 0.07)
    gain = min(max(float(L.get('gain', 1.25)), 1.0), 1.5)
    tc = min(max(float(L.get('capture_s', 0.30)), 0.0), 0.4)
    kf = min(max(float(L.get('forward_velocity_fraction', 0.5)), 0.0), 1.0)
    vcap = max(float(L.get('velocity_cap_m_s', 0.30)), 0.0)
    v = min(vcap, max(-vcap, float(est['v_fwd'])))
    xi = float(est['xc']) + tc * (v if v < 0.0 else kf * v)
    need = max(0.0, p_ref - xi)
    dir_x = max(0.5, sum(float(self.dirv[a][0]) for a in arms) / len(arms))
    per_hand = gain * float(BODY['weight_N']) * need / (2.0 * max(float(est['h']), 0.5) * dir_x)
    return min(per_hand, float(SAFE['cap'])), xi


def _track_phased(self, obs, est, hp, dt, clearance):
    '''Dispatcher: exact early track until high rise is measured, then the retained late track plus the palm guard.'''
    G = type(self).update.__globals__
    arms = G['ARMS']
    st = self._rise_phase_factor(hp)
    info = {}
    if st['latched']:
        prev = {a: np.array(self.tgt[a], float) for a in arms}
        self._track_late_v19(obs, est, hp, dt, clearance)
        if clearance <= 0.0:
            info = self._palm_push_guard(obs, est, hp, dt, prev, float(st['blend'])) or {}
    else:
        self._track_early_v17(obs, est, hp, dt, clearance)
    self.diag = dict(getattr(self, 'diag', None) or {}, high_rise_tracking=bool(st['latched']),
                     rise_blend=float(st['blend']), **info)


def _level_target_phased(self, est, hp, dt):
    '''Dispatcher: the retained request law runs every tick (lift, boost, tip guard, instability, diagnostics).
    With measured rise progress its target is blended into _late_support_target, under the same native tip limit.
    Measured backward motion while the request must grow uses the existing re-engagement rate.'''
    G = type(self).update.__globals__
    spec, arms = G['SPEC'], G['ARMS']
    SAFE = spec['safe_force_N']
    L = spec.get('late_support') or {}
    target = float(self._level_target_base(est, hp, dt))
    st = self._rise_phase_factor(hp)
    blend = float(st['blend'])
    if (not L.get('enabled', True)) or blend <= 0.0 or bool(self.unstable):
        self.diag = dict(self.diag, support_blend=blend, support_target_N=target)
        return target
    late, xi = self._late_support_target(est)
    tip = self.__dict__.get('tip') or {}
    guard = min(1.0, max(0.0, float(tip.get('guard', 0.0))))
    limit = max(0.0, float(tip.get('limit_N', SAFE['cap'])) * (1.0 - guard))
    late = min(float(late), limit)
    out = (1.0 - blend) * target + blend * late
    if float(est['v_fwd']) < -abs(float(L.get('back_v_m_s', 0.04))) and out > self.level:
        extra = max(0.0, float(SAFE['reengage_ramp_N_s']) - float(SAFE['assist_ramp_N_s'])) * blend
        self.level = min(out, self.level + extra * dt)
        hold = min(max(float(L.get('reengage_window_s', 0.25)), 0.0), 1.0)
        for a in arms:
            self.fast_until[a] = max(float(self.fast_until[a]), float(self.last_t) + hold)
    self.diag = dict(self.diag, late_support_N=float(late), capture_point_m=float(xi), support_blend=blend,
                     support_target_N=float(out))
    return float(out)


METHOD_MAP = {'_rise_phase_factor': _rise_phase_factor, '_palm_push_guard': _palm_push_guard,
              '_late_support_target': _late_support_target, '_track': _track_phased,
              '_level_target': _level_target_phased}


def install(policy, early_track=None, late_track=None, base_level_target=None):
    '''Attach the helpers to policy.Controller. early_track must be the exact v17 _track function; late_track and
    base_level_target default to the methods currently on the class (production v19 _track and _level_target).'''
    C = policy.Controller
    if getattr(C, '_stand_transfer_v24', False):
        return C
    early = early_track or getattr(C, '_track_early_v17', None)
    if early is None:
        raise ValueError('install needs early_track: the exact v17 _track function')
    for key, val in PATCH_SPEC.items():
        if isinstance(val, dict):
            policy.SPEC.setdefault(key, {}).update(val)
        else:
            policy.SPEC[key] = val
    C._track_early_v17 = early
    C._track_late_v19 = late_track or C._track
    C._level_target_base = base_level_target or C._level_target
    for name, fn in METHOD_MAP.items():
        setattr(C, name, fn)
    C._stand_transfer_v24 = True
    return C
