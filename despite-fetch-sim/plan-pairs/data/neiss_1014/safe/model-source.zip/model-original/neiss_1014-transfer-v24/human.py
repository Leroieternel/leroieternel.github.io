'''Optional common stand-coordination override, identical for every plan.

Reads only the human's own commanded rise fraction (which is itself bounded by the measured thigh elevation).
Mid/late rise and unlean are commanded at 6 deg/s instead of 9 deg/s. At or below MID_RATE_START the retained
original profile is returned exactly, so the lean, pelvis rock and early rise are unchanged. Shape, joint limits,
drive gains and caps, masses, consistency checks, stall/retreat logic and thresholds are untouched.

Install: install(human_module), where human_module defines Mannequin, RISE_RATE_DEG_S and _rate_profile.
'''

EARLY_RISE_RATE_DEG_S = 9.0               # must equal human.RISE_RATE_DEG_S (checked by install)
MID_RISE_RATE_DEG_S = 6.0                 # commanded rate once the own rise fraction is past MID_RATE_END
MID_RATE_START, MID_RATE_END = .30, .40   # own rise fraction over which the rate blends smoothly


def _smooth(x):
    x = min(1., max(0., x))
    return x * x * (3. - 2. * x)


def mid_rise_rate_factor(s):
    '''1.0 at or below MID_RATE_START, MID/EARLY at or above MID_RATE_END, smooth in between.'''
    k = _smooth((s - MID_RATE_START) / (MID_RATE_END - MID_RATE_START))
    return 1. - k * (1. - MID_RISE_RATE_DEG_S / EARLY_RISE_RATE_DEG_S)


def install(human):
    if getattr(human, '_mid_rise_rate_v24', False):
        return human
    if abs(float(human.RISE_RATE_DEG_S) - EARLY_RISE_RATE_DEG_S) > 1e-9:
        raise ValueError('human.RISE_RATE_DEG_S is not the expected 9.0 deg/s')
    base = human._rate_profile

    def _rate_profile_mid_late(s):
        return base(s) * mid_rise_rate_factor(s)

    human._rate_profile_base = base            # retained original
    human._rate_profile = _rate_profile_mid_late   # looked up by Mannequin._advance at call time
    human._mid_rise_rate_v24 = True
    return human
