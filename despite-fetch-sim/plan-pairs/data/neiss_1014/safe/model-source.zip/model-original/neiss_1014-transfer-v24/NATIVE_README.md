# stand-transfer-v24 (candidate, not executed here; local native physics must validate)

## What the v23 log shows
- **Arms in compression from 38.0 s.** Contact is held, but the commanded palms sit 4-6 cm behind the measured palms in X (left target/palm x: 0.437/0.480 at 38.0, 0.366/0.423 at 38.5, 0.289/0.328 at 39.0). Free-motion lag is about 0.19 s (0.031 m error at 0.16 m/s, t=40.0), so most of that error is the arm pressing on the chest, not following lag. This starts as the torso reverses.
- **Likely cause, unconfirmed.** The v19 allowance for a receding chest (up to 0.07 m into the chest while touching) lets the palms push the person backward. Arm stiffness is unknown, so the size of the push is not measured.
- **Request overshoots the human's own plan, then drops.** The request stays tip-limited (53 N per hand) until the CoM is 3 cm ahead of the human's planned CoM (-0.012 vs -0.046 at 37.5). The whole body is rotated about 4 deg forward about the ankle, so the human pushes back. The request then falls to 14 N at the CoM crossing and can only return at 30 N/s.
- **The human's plan is rearward.** Its planned CoM stays 1-3.5 cm behind the ankle until about 87 % rise, so a request that vanishes at +0.02 m is never satisfied by the plan itself.

## Changes (robot)
All are gated by measured pelvis height: latch above 0.80 m (the v23 switch point) and a smooth blend to full at 0.86 m. Blend 0 is exactly v17 `_track` plus the production `_level_target`. The latch re-arms only when the pelvis is measured back at seat height; v23 latched permanently, so a later attempt ran v19 from the seat.
- `_track_phased`: v17 early, v19 late (as v23), then `_palm_push_guard`.
- `_palm_push_guard`: while contact is observed, the target may be deeper than the measured palm (chest normal and world -X) only by a preload plus 0.18 s x the measured receding chest speed (<= 0.04 m). The preload blends 0.03 -> 0.015 m. It only moves the target outward, widens by v19's own no-contact factor so the chase after contact loss stays, and keeps the total target step <= 0.16 m/s.
- `_late_support_target` via `_level_target_phased`: per-hand request = 1.25 x W x (0.035 - capture point) / (2 h). Capture point = sensed CoM + 0.30 s x velocity (full weight backward, half forward).
  - At the human's planned posture this is about 25 -> 8 N per hand through mid/late rise and 0 at the upright plan, so release is gradual and comes from measurement.
  - A transient CoM crossing no longer unloads, and backward motion reloads at once.
  - It stays under the same tip limit, tip guard and instability withdrawal; the retained law still runs every tick for those.
  - With measured backward motion the request may grow at the existing `reengage_ramp_N_s` (90 N/s) instead of 30 N/s. This is a change to request slew, inside existing constants.
- Not changed: standing gate, taper, release, verify, window-end failure, contact/gap gates, hand speed, IK, tip budget, episode 80 s / assist 56 s.

## Optional human.py (common to both plans)
- Commanded rise rate 9 -> 6 deg/s only above the human's own rise fraction 0.30 (smooth to 0.40). Below that the retained profile is returned exactly.
- Reason: with palms no longer wedged against the chest, the hand has less speed margin. Torso speed was 0.14-0.16 m/s at 9 deg/s against the 0.16 m/s hand limit.
- Cost: about 4 s more from 35 % rise to upright. An attempt that leaves the bed by about 37 s still finishes near 53 s, inside the window.
- Suggested order: policy.py + human.py first; policy.py alone as the ablation.

## Install (in the v23 wrapper, replacing the `phased` definition and assignment)
```
import policy_v24 as stand_patch            # this policy.py
stand_patch.install(policy, early_track=early)   # early = exact v17 _track, as already extracted
# optional, before the episode starts:
import human_v24; human_v24.install(human_module)   # module defining Mannequin
```
`install` merges PATCH_SPEC, captures the current `Controller._track` as `_track_late_v19` and `_level_target` as `_level_target_base`, and is idempotent.

To publish in the class instead: rename those two methods to the retained names, add v17 as `_track_early_v17`, and add the five functions in `METHOD_MAP` as methods.

## Switches
- `palm_guard.enabled: False` gives v23 tracking.
- `late_support.enabled: False` gives the v23 request law.
- `rise_phase.pelvis_full_m` sets the blend length.

## Check first
- `palm_press_m` stays near `palm_press_bound_m`, and target minus palm X is not negative beyond about 2 cm while touching.
- Gap stays < 0.06 m and contact is held through 37-40 s equivalent. If contact flickers, raise `palm_guard.press_m` toward 0.02 before anything else.
- `support_target_N` declines smoothly (roughly 50 -> 25 N over pelvis 0.80-0.86 m) and never drops below `late_support_N`.
- Human shin and pelvis stay within about 1 deg of command, i.e. no forward drag. If the CoM stalls behind plan, raise `late_support.gain` (max 1.5) or `cop_ref_m` (max 0.07).
- Success is still only: standing flag (upright, feet, speed dwell) -> taper -> release -> verify with zero request.