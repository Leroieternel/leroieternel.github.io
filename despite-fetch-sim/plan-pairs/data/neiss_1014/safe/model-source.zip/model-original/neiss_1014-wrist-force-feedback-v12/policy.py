# DESPITE neiss_1014 native TIAGo patch v9: tip-margin-gated wrist-up palm trajectory (math/numpy only, no I/O).
# Overrides (sensed plan only): _align, _track, _level_target. Unsensed plan, actions, gates and caps are unchanged.
# No module-level helper is modified: _pitched keeps its convention (positive = fingertips up).
#
# Sign check. R(_pitched(p)) = [[-cos p, 0, sin p], [0, -1, 0], [sin p, 0, cos p]], so
#   hand +X (wrist -> fingertips) = (-cos p, 0, sin p) and wrist = palm + d*(cos p, 0, -sin p), d = 0.2665 m measured.
#   p > 0: wrist below palm.  p < 0: wrist above palm by d*sin|p|; _align then gives el > 0, i.e. +F*sin(el) upward
#   on the person with an unbent wrist while el is unclipped.  CONFIRMED.
# NOT confirmed: 'downward wrist reaction stabilises the base'. The wrist (x 0.58) is ~0.26 m in FRONT of the forward
#   support edge (base x 1.064, edge <= 0.27 m ahead), so the tip moment about that edge is
#   M = sum_a F_a * (z_S*cos(el) + b*sin(el)), b = edge-to-support-point distance ~0.5 m > 0: it GROWS with el.
#   Samples: ~121 N m settled at 20 s, ~126 N m with pitch-rate onset at 22 s. Wrist-up therefore only spends the
#   tip moment left over by the force request, and the request itself is limited to the same budget.
import math
import numpy as np

PATCH_SPEC = {
    # Bounded wrist-up (negative _pitched) schedule; rate is below the existing hand_turn_max_rad_s = 0.8.
    'wrist_up': {'max_rad': 0.22, 'rate_rad_s': 0.25, 'full_below_z_m': 0.90, 'zero_above_z_m': 1.00, 'min_level_N': 5.0},
    # Native tip margin: static moment budget about the forward support edge plus a sensed base lift/tilt guard.
    'tip_margin': {'moment_budget_N_m': 105.0, 'front_edge_m': 0.22, 'lever_min_m': 0.30, 'headroom_band_N': 15.0,
                   'lift_detect_m': 0.0015, 'lift_full_m': 0.008, 'tilt_detect_rad': 0.006, 'tilt_full_rad': 0.035,
                   'ref_drift_m_s': 0.001, 'ref_drift_rad_s': 0.002, 'derate_per_s': 0.5, 'derate_min': 0.6,
                   'recover_per_s': 0.01},
}


def _align(self, obs, est, dt):
    '''Sensed plan: force line from each chest support point through that hand's measured wrist (bounded), plus
    the native tip-moment bookkeeping (lever per hand, per-hand force limit, sensed base lift/tilt guard).'''
    G = type(self).update.__globals__
    spec = G['SPEC']
    AL, arms, quat_matrix = spec['support_alignment'], G['ARMS'], G['_quat_matrix']
    TM = spec.get('tip_margin') or {}
    step = AL['rate_rad_s'] * dt
    az = self.__dict__.setdefault('az', {a: 0.0 for a in arms})
    az_max = float(AL.get('azimuth_max_rad', 0.15))
    hp = obs.get('human_posture') or {}
    pts = hp.get('support_points_world_m') or {}
    rp = obs.get('robot_position_m')
    base_x = float(rp[0]) if rp is not None else None
    front = float(TM.get('front_edge_m', 0.22))
    lever_min = float(TM.get('lever_min_m', 0.30))
    lever = {}
    for a in arms:
        h = obs['hands'][a]
        S = np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)
        wrist = h.get('wrist_position_m')
        if wrist is None:
            back = -(quat_matrix(h['orientation_xyzw']) @ np.array([1.0, 0.0, 0.0]))
            if float(back[0]) < 0.5:
                back = np.array([1.0, 0.0, 0.0])
            wrist = np.asarray(h['position_m'], float) + AL['wrist_behind_palm_m'] * back
        w = np.asarray(wrist, float) - S
        fwd = max(float(w[0]), 0.05)
        hor = max(math.hypot(fwd, float(w[1])), 0.05)
        want_el = min(max(math.atan2(float(w[2]), hor), AL['elevation_min_rad']), AL['elevation_max_rad'])
        want_az = min(max(math.atan2(float(w[1]), fwd), -az_max), az_max)
        self.el[a] += min(step, max(-step, want_el - self.el[a]))
        az[a] += min(step, max(-step, want_az - az[a]))
        c = math.cos(self.el[a])
        self.dirv[a] = np.array([c * math.cos(az[a]), c * math.sin(az[a]), math.sin(self.el[a])])
        # Lever of this hand's force line about the base's forward support edge (floor at z = 0).
        b = 0.0 if base_x is None else max(abs(base_x - float(S[0])) - front, 0.0)
        lever[a] = max(float(S[2]) * c + b * math.sin(self.el[a]), lever_min)
    tip = self.__dict__.setdefault('tip', {})
    # Sensed base lift / tilt over slowly drifting references (references follow down at once, up only slowly).
    lift, tilt = 0.0, 0.0
    if rp is not None and len(rp) >= 3:
        z = float(rp[2])
        zr = tip.get('z_ref')
        zr = z if zr is None else min(z, zr + float(TM.get('ref_drift_m_s', 0.001)) * dt)
        tip['z_ref'] = zr
        lift = z - zr
    q = obs.get('robot_orientation_xyzw')
    if q is not None and len(q) >= 4:
        qq = np.asarray(q, float)
        n = float(np.linalg.norm(qq))
        if n > 1e-6:
            x, y = float(qq[0]) / n, float(qq[1]) / n
            ang = math.acos(max(-1.0, min(1.0, 1.0 - 2.0 * (x * x + y * y))))
            ar = tip.get('tilt_ref')
            ar = ang if ar is None else min(ang, ar + float(TM.get('ref_drift_rad_s', 0.002)) * dt)
            tip['tilt_ref'] = ar
            tilt = ang - ar
    l0, l1 = float(TM.get('lift_detect_m', 0.0015)), float(TM.get('lift_full_m', 0.008))
    t0, t1 = float(TM.get('tilt_detect_rad', 0.006)), float(TM.get('tilt_full_rad', 0.035))
    guard = max((lift - l0) / max(l1 - l0, 1e-6), (tilt - t0) / max(t1 - t0, 1e-6))
    guard = min(1.0, max(0.0, guard))
    # Learned derate of the budget while tilt is sensed; very slow recovery so the same threshold is not retried.
    scale = float(tip.get('scale', 1.0))
    if guard > 0.0:
        scale = max(float(TM.get('derate_min', 0.6)), scale - float(TM.get('derate_per_s', 0.5)) * guard * dt)
    else:
        scale = min(1.0, scale + float(TM.get('recover_per_s', 0.01)) * dt)
    budget = float(TM.get('moment_budget_N_m', 105.0)) * scale
    total = sum(lever.values())
    f = getattr(self, 'force', None)
    used = sum(float(f[a]) * lever[a] for a in arms) if isinstance(f, dict) else float(getattr(self, 'level', 0.0)) * total
    tip.update(guard=guard, scale=scale, lever=lever, lift_m=float(lift), tilt_rad=float(tilt),
               limit_N=float(budget / max(total, 1e-6)), moment_N_m=float(used), budget_N_m=float(budget))


def _track(self, obs, est, hp, dt, clearance):
    '''Sensed plan: hands follow the measured chest points, bounded relative to the MEASURED palm; base backs away.
    Palm orientation: original fingertips-up schedule above pitch_start_z_m, plus a bounded, rate-limited wrist-up
    (negative pitch) component at low hand heights that is only allowed while native tip margin is spare.'''
    G = type(self).update.__globals__
    spec, toward, quat_step, pitched, arms = G['SPEC'], G['_toward'], G['_quat_step'], G['_pitched'], G['ARMS']
    T = spec['contact_tracking']
    WU = spec.get('wrist_up') or {}
    nrm, up = np.asarray(est['nrm'], float), np.asarray(est['up'], float)
    pts = hp.get('support_points_world_m') or {}
    S = {a: (np.asarray(pts[a], float) if a in pts else np.asarray(est['S'][a], float)) for a in arms}
    ff = np.asarray(hp['torso_velocity_m_s'], float) * T['feedforward_s']
    n = float(np.linalg.norm(ff))
    if n > T['feedforward_max_m']:
        ff = ff * (T['feedforward_max_m'] / n)
    step = spec['hand_speed_max_m_s'] * dt
    turn = spec['hand_turn_max_rad_s'] * dt
    press_max = float(T.get('press_lead_max_m', 0.03))
    lead_max = float(T.get('tangent_lead_max_m', 0.08))
    hard = float(T.get('hard_pause_m', 0.14))
    comp_gain = float(T.get('tangent_comp_gain_per_s', 2.0))
    comp_max = float(T.get('tangent_comp_max_m', 0.07))
    freeze = float(T.get('comp_freeze_error_m', 0.10))
    yield_max = float(T.get('orientation_yield_max_rad', 0.20))
    back_scale = float(T.get('orientation_return_scale', 0.25))
    wu_max = float(WU.get('max_rad', 0.22))
    wu_rate = min(float(WU.get('rate_rad_s', 0.25)), float(spec['hand_turn_max_rad_s'])) * dt
    z_full, z_zero = float(WU.get('full_below_z_m', 0.90)), float(WU.get('zero_above_z_m', 1.00))
    lvl_min = float(WU.get('min_level_N', 5.0))
    tip = self.__dict__.get('tip') or {}
    head = float(tip.get('headroom', 0.0)) * (1.0 - float(tip.get('guard', 0.0)))
    wp = self.__dict__.setdefault('wpitch', {})
    # Weight is over the feet and the request is already zero: stop leaning the palms on the chest (bounded back-off).
    easy = clearance <= 0.0 and bool(self.lifted) and self.level <= 1.0 and float(est['xc']) >= 0.0
    for a in arms:
        h = obs['hands'][a]
        pos = np.asarray(h['position_m'], float)
        err = float(h.get('tracking_error_m') or 0.0)
        touching = bool(h.get('contact_human'))
        reach = h.get('ik_reachable') is not False
        press = -float((self.tgt[a] - pos) @ nrm)
        if clearance > 0.0:
            self.depth[a] = max(-clearance, self.depth[a] - 0.05 * dt)
        elif easy:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        elif not touching:
            self.depth[a] = min(T['depth_max_m'], self.depth[a] + T['creep_in_m_s'] * dt)
        elif press > T['press_error_m']:
            self.depth[a] = max(T['depth_min_m'], self.depth[a] - T['creep_out_m_s'] * dt)
        if not reach:   # no branch-continuous IK: stay slightly lower (bounded well inside the 0.08 m gap gate)
            self.lower[a] = min(T['lower_max_m'], self.lower[a] + T['lower_rate_m_s'] * dt)
        else:
            self.lower[a] = max(0.0, self.lower[a] - T['lower_recover_m_s'] * dt)
        base = S[a] + ff - self.depth[a] * nrm - self.lower[a] * up
        # Bounded integral compensation of the measured palm lag along the chest surface, with anti-windup.
        if clearance > 0.0 or not touching:
            self.sagc[a] = max(0.0, self.sagc[a] - T['sag_release_m_s'] * dt)
        elif reach and err <= freeze:
            short = float((base - pos) @ up)
            self.sagc[a] = min(comp_max, max(0.0, self.sagc[a] + comp_gain * short * dt))
        else:
            self.sagc[a] = max(0.0, self.sagc[a] - 0.5 * T['sag_release_m_s'] * dt)
        goal = base + self.sagc[a] * up
        if err > hard or not reach:   # blocked, far off or no continuous IK: yield toward the measured palm
            self.tgt[a] = toward(self.tgt[a], pos, step)
        else:
            tgt = toward(self.tgt[a], goal, step)
            off = tgt - pos
            depth_in = -float(off @ nrm)
            if depth_in > press_max:   # never press on
                tgt = tgt + (depth_in - press_max) * nrm
                off = tgt - pos
            tan = off - float(off @ nrm) * nrm
            tn = float(np.linalg.norm(tan))
            if tn > lead_max:          # bounded lead of the reference over the measured palm
                tgt = tgt - tan * (1.0 - lead_max / tn)
            self.tgt[a] = tgt
        pitch = min(max((float(goal[2]) - T['pitch_start_z_m']) * T['pitch_gain_rad_m'], 0.0), T['pitch_max_rad'])
        # Wrist-up component (negative pitch = wrist above palm): faded out with hand height, scaled by spare native
        # tip margin, released when contact, IK or tracking is not healthy. Scalar starts from the current command.
        fade = min(1.0, max(0.0, (z_zero - float(goal[2])) / max(z_zero - z_full, 1e-3)))
        ok = clearance <= 0.0 and touching and reach and err <= freeze and (not easy) and self.level >= lvl_min
        want = -wu_max * fade * head if ok else 0.0
        if a not in wp:
            q0 = self.quat[a]
            sg = 1.0 if float(q0[2]) >= 0.0 else -1.0
            wp[a] = min(0.0, max(-wu_max, 2.0 * math.atan2(sg * float(q0[0]), sg * float(q0[2]))))
        wp[a] += min(wu_rate, max(-wu_rate, want - wp[a]))
        nominal = pitched(pitch + wp[a])
        if not reach:   # choose a feasible palm orientation: step toward the measured one, bounded from nominal
            mq = np.asarray(h['orientation_xyzw'], float)
            mn = float(np.linalg.norm(mq))
            if mn > 1e-6:
                cand = quat_step(self.quat[a], mq / mn, turn)
                ang = 2.0 * math.acos(min(1.0, abs(float(np.dot(cand, nominal)))))
                if ang <= yield_max:
                    self.quat[a] = cand
        else:
            self.quat[a] = quat_step(self.quat[a], nominal, turn * back_scale)
    BF = spec.get('base_follow')
    if BF and self.hold_xy is not None:
        # Velocity-only base retreat: keep the horizontal reach to the chest near reach_m; never closer than the dock.
        dock = self.__dict__.setdefault('dock_x', float(self.hold_xy[0]))
        sx = float(np.mean([S[a][0] for a in arms]))
        want_x = min(max(sx + BF['reach_m'], dock), dock + BF['retreat_max_m'])
        r = BF['ref_rate_m_s'] * dt
        self.hold_xy[0] = float(self.hold_xy[0] + min(r, max(-r, want_x - self.hold_xy[0])))
        ex = self.hold_xy[0] - float(obs['robot_position_m'][0])
        vmax = BF['speed_max_m_s']
        self.v = [float(min(vmax, max(-vmax, BF['gain_per_s'] * ex))), float(self.v[1])]


def _level_target(self, est, hp, dt):
    '''Original CoM-feedback request, then limited to what the native base can react without tipping.'''
    G = type(self).update.__globals__
    spec = G['SPEC']
    SAFE, FB, BODY = spec['safe_force_N'], spec['support_feedback'], spec['anthropometric_model']
    TM = spec.get('tip_margin') or {}
    tilt, pz = float(hp['torso_tilt_deg']), float(hp['pelvis_position_m'][2])
    if self.seat_z is None:
        self.seat_z = pz
    self.lifted = pz > self.seat_z + (FB['lift_clear_m'] if self.lifted else FB['lift_detect_m'])
    xc = float(est['xc'])
    span = max(float(FB.get('sustain_span_m', 0.08)), 1e-3)
    # 1 while the sensed CoM is well behind the heel, 0 once it is over the foot.
    behind = min(1.0, max(0.0, (float(FB.get('sustain_zero_com_m', 0.02)) - xc) / span))
    need = max(0.0, FB['com_reference_from_ankle_m'] - xc)
    # Forward-velocity damping only acts once the CoM is over the feet; before that forward motion is the goal.
    damp = FB['velocity_damping_N_s_m'] * max(0.0, float(est['v_fwd'])) * (1.0 - behind)
    fx = BODY['weight_N'] * need / est['h'] * (1.0 + self.boost) - damp
    arms = G['ARMS']
    dir_x = max(0.5, sum(float(self.dirv[a][0]) for a in arms) / len(arms))
    feedback = min(max(fx / (2.0 * dir_x), 0.0), SAFE['cap'])
    lo, hi = FB['lean_gate_deg']
    lean = min(1.0, max(0.0, (tilt - lo) / (hi - lo)))
    w = 1.0 if self.lifted else lean
    target = SAFE['start'] + (feedback - SAFE['start']) * w
    # Bounded sustaining minimum: gated on the person's own lean and on the CoM still being behind the heel.
    floor = min(float(SAFE['cap']), float(FB.get('sustain_N', 80.0))) * lean * behind
    target = min(max(target, floor), SAFE['cap'])
    # Native tip margin: per-hand limit from the moment budget (computed in _align), scaled down by sensed base tilt.
    tip = self.__dict__.setdefault('tip', {})
    guard = float(tip.get('guard', 0.0))
    limit = max(0.0, float(tip.get('limit_N', SAFE['cap'])) * (1.0 - guard))
    band = max(float(TM.get('headroom_band_N', 15.0)), 1e-3)
    tip['headroom'] = min(1.0, max(0.0, (limit - target) / band))   # spare margin -> wrist-up allowed in _track
    wanted = float(target)
    target = min(target, limit)
    if guard > 0.0 and self.level > target:   # sensed base tilt: withdraw the request quickly (downward only)
        self.level = max(target, self.level - FB['abort_ramp_N_s'] * dt)
    tilted = guard > 0.0
    if tilted != bool(tip.get('tilted', False)):
        self.events.append('native base tilt sensed: support request reduced' if tilted
                           else 'native base settled: support request limit restored')
    tip['tilted'] = tilted
    waiting = (not self.lifted) and tilt >= hi
    self.wait_s = self.wait_s + dt if waiting else 0.0
    if waiting and self.wait_s > FB['boost_delay_s']:
        self.boost = min(FB['boost_max'], self.boost + FB['boost_rate_per_s'] * dt)
    elif (not waiting) and ((not self.lifted) or xc >= float(FB.get('transfer_com_m', -0.02))):
        # the learned boost decays only when seated upright again or once weight transfer is sensed
        self.boost = max(0.0, self.boost - FB['boost_rate_per_s'] * dt)
    unstable = (tilt > FB['abort_tilt_deg'] or est['speed'] > FB['abort_speed_m_s'] or est['lateral'] > FB['abort_lateral_m'])
    if unstable != self.unstable:
        self.events.append('instability sign: support request withdrawn' if unstable else 'posture calm: support request resumes')
    self.unstable = unstable
    wp = self.__dict__.get('wpitch') or {}
    self.diag = dict(self.diag, sustain_floor_N=float(floor), com_behind_gate=float(behind),
                     tip_limit_N=float(limit), tip_wanted_N=wanted, tip_guard=guard,
                     tip_moment_N_m=float(tip.get('moment_N_m', 0.0)), tip_budget_N_m=float(tip.get('budget_N_m', 0.0)),
                     tip_headroom=float(tip['headroom']), wrist_up_rad={a: float(-wp.get(a, 0.0)) for a in arms})
    return 0.0 if unstable else float(target)


METHOD_OVERRIDES = {'_align': _align, '_track': _track, '_level_target': _level_target}


def install(policy_module, cls=None):
    '''Optional helper: nested-merge PATCH_SPEC into policy_module.SPEC and bind the overrides on the policy class.'''
    spec = policy_module.SPEC
    for key, val in PATCH_SPEC.items():
        spec.setdefault(key, {}).update(val)
    if cls is None:
        found = [c for c in vars(policy_module).values() if isinstance(c, type) and hasattr(c, '_assist_to_stand')]
        cls = found[0] if found else None
    if cls is not None:
        for name, fn in METHOD_OVERRIDES.items():
            setattr(cls, name, fn)
    return cls
