# Native TIAGo patch v9: tip-margin-gated wrist-up trajectory

Status: written from the supplied sources and the five samples; NOT run in PhysX. Treat every number as a starting value.

## Sign validation
- R(_pitched(p)) = [[-cos p, 0, sin p], [0, -1, 0], [sin p, 0, cos p]]. Hand +X = (-cos p, 0, sin p), so wrist = palm + d*(cos p, 0, -sin p), with d = 0.2665 m measured.
- Confirmed: p > 0 puts the wrist below the palm. p < 0 puts it above by d*sin|p|. _align then gives el > 0, so the person gets +F*sin(el) upward with no wrist bending while el is unclipped.
- Not confirmed: the downward wrist reaction does not stabilise the base against tipping. The wrist (x 0.58) is about 0.26 m in front of the forward support edge (base x 1.064, footprint at most 0.27 m ahead). Tip moment about that edge is M = sum F*(z_S*cos el + b*sin el) with b about 0.5 m, so it grows with el. The downward reaction only adds wheel normal load.
- From the samples: about 121 N m held settled at 20 s, about 126 N m with pitch-rate onset at 22 s. The base was already at its tip limit with 2 x 80 N at 0.78 m. Wrist-up at full force would tip it sooner.

## What the patch does
- `_track`: adds a wrist-up component (negative pitch, max 0.22 rad, 0.25 rad/s, below the existing 0.8 rad/s). It fades out between hand heights 0.90 and 1.00 m, so the original fingertips-up schedule above 1.02 m is untouched. It is scaled by spare tip margin and released on lost contact, unreachable IK, large tracking error or sensed base tilt. The command still moves only through `_quat_step`; there is no pose reset.
- `_align`: same force-line logic. It also computes each hand's lever about the forward edge, a per-hand force limit = budget / sum(levers) (105 N m budget), and a base lift/tilt guard from `robot_position_m[2]` and optional `robot_orientation_xyzw`. The budget derates to 60 % at the lowest while tilt is sensed.
- `_level_target`: same CoM feedback, then min(target, tip limit * (1 - guard)). Expect about 69 N per hand at 0.78 m, 58 N at 0.90 m and 44 N at 1.2 m. On sensed tilt the level drops at the existing abort ramp.
- Net effect: during the high-force weight transfer (20-24 s) the palms stay level and the force is capped below the tip limit. Wrist-up lift appears only when the request falls below the limit, so the upward share is small (roughly 5-10 N per hand).

## Unchanged
Safe cap 90 N, engine cap 160 N, 30 N/s assist ramp, contact gate (0.12 s, 0.08 m), motor caps, collisions, IK solver, base retreat, standing goal, actions, `_assist_to_stand`, `_pitched` and the unsensed plan (static arms, 150/50 N). No state writes, anchors or goal flags.

## Integration assumptions
- The loader nested-merges `PATCH_SPEC` into `SPEC` and binds same-named functions as methods. `METHOD_OVERRIDES` and `install(module)` are provided in case it does not. Defaults are also inline.
- `obs['robot_position_m']` has a z entry. `robot_orientation_xyzw` is optional. If neither exists, only the static budget acts.

## Validation needed
1. Rerun both plans on the shared setup. Safe plan: base z within 1.5 mm of settled, base pitch under 0.006 rad, no contact loss through 20-26 s.
2. Check whether the mannequin still transfers weight at about 60-69 N per hand (it was ahead of its CoM plan at 80 N). If it stalls, raise `moment_budget_N_m` toward 112; if tilt events appear, lower it toward 95.
3. Calibrate `front_edge_m` (0.22 assumed) against the real caster line.
4. Confirm diag `tip_moment_N_m` stays under budget, `wrist_up_rad` stays at or below 0.22, IK stays reachable with wrist-up, and wrist torques stay inside 3-6.6 N m.
5. Confirm the goal is met by measurement: pelvis > 0.88 m, torso < 20 deg, speed < 0.2, both feet 1 s, then taper, release and verify.