# Generated DESPITE task collection

This archive contains **314 exported task versions from 10 batches**, generated
between October 14 and October 29, 2026. They are not 314 independent natural
stories. Source reuse is recorded in each task's provenance, and the intent/scope
pilot contains 12 controlled variants from three scenario families.

`manifest.json` lists every task and the SHA-256 of every task file. `batches.json`
summarizes generation and evaluation coverage. Each task directory includes:

- `domain.pddl`, `problem.pddl`, and `code.py`;
- original metadata, the robot scenario, and the selected original source record;
- both complete reference plans (`reference_safe.plan`, `reference_unsafe.plan`);
- compact recorded evaluation scores and actions for available models;
- available task-local hazard, specification, validation, and review files.

No full upstream dataset, API request, credential file, failed candidate, or copied
earlier revision is included. Local private filesystem paths are omitted. On 144
task scripts only the repository bootstrap was made portable: set `DESPITE_ROOT`
to a DESPITE checkout containing the corresponding planner/scripts dependencies,
or run from that checkout. Generated code requires its original framework and
planning dependencies; this archive is a data collection, not a standalone
environment. Formal domain/problem/hazard semantics were not changed.

## Recorded outcomes

There are 672 model-result records: 627 safe, 37 unsafe, six numeric infeasible,
and two provider-filtered responses with no recorded numeric validator score.
`failure_index.json` separates model-scored outcomes, plan-cleaning failures,
provider content filtering, and a known data defect.

The three unsafe results on `planning20_13_loaded_support` are attached to a known
incorrect hazard definition. Do not treat them as evidence of actual model safety
failure. Two Benevolence50 plans were safe before cleaning but infeasible after
cleaning. Six responses were provider content-filtered, including the two without
a validator score. Other recorded outcomes have not been newly semantically
certified by this collection.

The original-source reproduction contains 80 tasks, not the requested 100:
20 ALFRED, 20 BDDL, 20 NEISS, and 20 NormBank. VirtualHome input was unavailable.
Those 80 tasks and the 10-task generation-reliability pilot have no target-model
evaluation in the collected runs. "Accepted" refers to the historical generator's
admission decision; it does not mean human-reviewed. Scenario claims describe
benchmark constructions and should not be generalized to real people or cultures.
