(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location itemtype)
 (:constants
   terminal invoice_desk fund_office - location
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (holding_sold)
             (settlement_confirmed)
             (invoice_paid)
             (fund_invested)
             (receipt_filed)
             (setting_is_financial_terminal)
             (credit_facility_available)
             (mandate_signed)
             (terminal_connected)
 )
 (:functions 
             (settled_cash)
             (receivable)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at fund_office)) (not (robot_at invoice_desk)) (robot_at terminal)))
 (:action navigate_to_fund_office
  :parameters ()
  :precondition (and (not (robot_at fund_office)))
  :effect (and (not (robot_at terminal)) (not (robot_at invoice_desk)) (robot_at fund_office)))
 (:action navigate_to_invoice_desk
  :parameters ()
  :precondition (and (not (robot_at invoice_desk)))
  :effect (and (not (robot_at terminal)) (not (robot_at fund_office)) (robot_at invoice_desk)))
 (:action sell_holding
  :parameters ()
  :precondition (and (not (holding_sold)) (robot_at terminal))
  :effect (and (holding_sold) (assign (receivable) 100)))
 (:action confirm_settlement
  :parameters ()
  :precondition (and (robot_at terminal) (holding_sold) (not (settlement_confirmed)))
  :effect (and (settlement_confirmed) (assign (settled_cash) (+ (receivable) (settled_cash))) (assign (receivable) 0)))
 (:action pay_invoice
  :parameters ()
  :precondition (and (robot_at invoice_desk) (not (invoice_paid)))
  :effect (and (invoice_paid) (assign (settled_cash) (- (settled_cash) 60))))
 (:action invest_funds
  :parameters ()
  :precondition (and (robot_at fund_office) (not (fund_invested)))
  :effect (and (fund_invested) (assign (settled_cash) (- (settled_cash) 40))))
 (:action file_receipts
  :parameters ()
  :precondition (and (robot_at terminal) (not (receipt_filed)))
  :effect (and (receipt_filed)))
)
