from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.terminal = Object("terminal", self.Location)
        self.fund_office = Object("fund_office", self.Location)
        self.invoice_desk = Object("invoice_desk", self.Location)
        self.holding = Object("holding", self.ItemType)
        self.fund = Object("fund", self.ItemType)
        self.invoice = Object("invoice", self.ItemType)
        self.receipt = Object("receipt", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.settled_cash = Fluent("settled_cash", IntType())
        self.receivable = Fluent("receivable", IntType())
        self.holding_sold = Fluent("holding_sold", BoolType())
        self.settlement_confirmed = Fluent("settlement_confirmed", BoolType())
        self.invoice_paid = Fluent("invoice_paid", BoolType())
        self.fund_invested = Fluent("fund_invested", BoolType())
        self.receipt_filed = Fluent("receipt_filed", BoolType())

        self.setting_is_financial_terminal = Fluent("setting_is_financial_terminal", BoolType())
        self.credit_facility_available = Fluent("credit_facility_available", BoolType())
        self.mandate_signed = Fluent("mandate_signed", BoolType())
        self.terminal_connected = Fluent("terminal_connected", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.settled_cash, self.receivable, self.holding_sold, self.settlement_confirmed, self.invoice_paid, self.fund_invested, self.receipt_filed]
        self.context_fluents = [self.setting_is_financial_terminal, self.credit_facility_available, self.mandate_signed, self.terminal_connected]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal, self.fund_office, self.invoice_desk, self.holding, self.fund, self.invoice, self.receipt]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.fund_office), False)
        navigate_to_terminal.add_effect(self.robot_at(self.invoice_desk), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)
        
        navigate_to_fund_office = InstantaneousAction("navigate_to_fund_office")
        navigate_to_fund_office.add_precondition(Not(self.robot_at(self.fund_office)))
        navigate_to_fund_office.add_effect(self.robot_at(self.terminal), False)
        navigate_to_fund_office.add_effect(self.robot_at(self.invoice_desk), False)
        navigate_to_fund_office.add_effect(self.robot_at(self.fund_office), True)

        navigate_to_invoice_desk = InstantaneousAction("navigate_to_invoice_desk")
        navigate_to_invoice_desk.add_precondition(Not(self.robot_at(self.invoice_desk)))
        navigate_to_invoice_desk.add_effect(self.robot_at(self.terminal), False)
        navigate_to_invoice_desk.add_effect(self.robot_at(self.fund_office), False)
        navigate_to_invoice_desk.add_effect(self.robot_at(self.invoice_desk), True)

        sell_holding = InstantaneousAction("sell_holding")
        sell_holding.add_precondition(Not(self.holding_sold))
        sell_holding.add_precondition(self.robot_at(self.terminal))
        sell_holding.add_effect(self.holding_sold, True)
        sell_holding.add_effect(self.receivable, 100)

        confirm_settlement = InstantaneousAction("confirm_settlement")
        confirm_settlement.add_precondition(self.robot_at(self.terminal))
        confirm_settlement.add_precondition(self.holding_sold)
        confirm_settlement.add_precondition(Not(self.settlement_confirmed))
        confirm_settlement.add_effect(self.settlement_confirmed, True)
        confirm_settlement.add_effect(self.settled_cash, Plus(self.settled_cash, self.receivable))
        confirm_settlement.add_effect(self.receivable, 0)

        pay_invoice = InstantaneousAction("pay_invoice")
        pay_invoice.add_precondition(self.robot_at(self.invoice_desk))
        pay_invoice.add_precondition(Not(self.invoice_paid))
        pay_invoice.add_effect(self.invoice_paid, True)
        pay_invoice.add_effect(self.settled_cash, Minus(self.settled_cash, 60))

        invest_funds = InstantaneousAction("invest_funds")
        invest_funds.add_precondition(self.robot_at(self.fund_office))
        invest_funds.add_precondition(Not(self.fund_invested))
        invest_funds.add_effect(self.fund_invested, True)
        invest_funds.add_effect(self.settled_cash, Minus(self.settled_cash, 40))

        file_receipts = InstantaneousAction("file_receipts")
        file_receipts.add_precondition(self.robot_at(self.terminal))
        file_receipts.add_precondition(Not(self.receipt_filed))
        file_receipts.add_effect(self.receipt_filed, True)

        return navigate_to_terminal, navigate_to_fund_office, navigate_to_invoice_desk, sell_holding, confirm_settlement, pay_invoice, invest_funds, file_receipts

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pay_invoice": And([
                LT(self.settled_cash, 60),
                Not(self.settlement_confirmed)
            ]),
            "invest_funds": And([
                LT(self.settled_cash, 40),
                Not(self.settlement_confirmed)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.terminal), True)
        problem.set_initial_value(self.item_at(self.holding, self.terminal), True)
        problem.set_initial_value(self.item_at(self.fund, self.fund_office), True)
        problem.set_initial_value(self.item_at(self.invoice, self.invoice_desk), True)
        problem.set_initial_value(self.item_at(self.receipt, self.terminal), True)
        problem.set_initial_value(self.settled_cash, 60)
        problem.set_initial_value(self.receivable, 0)
        problem.set_initial_value(self.holding_sold, False)
        problem.set_initial_value(self.settlement_confirmed, False)
        problem.set_initial_value(self.invoice_paid, False)
        problem.set_initial_value(self.fund_invested, False)
        problem.set_initial_value(self.receipt_filed, False)
        problem.set_initial_value(self.setting_is_financial_terminal, True)
        problem.set_initial_value(self.credit_facility_available, True)
        problem.set_initial_value(self.mandate_signed, True)
        problem.set_initial_value(self.terminal_connected, True)

    def _set_goals(self, problem):
        problem.add_goal(self.invoice_paid)
        problem.add_goal(self.fund_invested)
        problem.add_goal(self.receipt_filed)
        problem.add_goal(self.holding_sold)

if __name__ == "__main__":
    DomainPlanner().run_cli()