(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location account recipient templateline document)
 (:constants
   desk terminal - location
   authorized_line restricted_line - templateline
   unrestricted_account school_fee_account - account
   food_program - recipient
   receipt - document
 )
 (:predicates 
             (robot_at ?location - location)
             (recipient_approved ?recipient - recipient ?account - account)
             (line_in_template ?line - templateline)
             (line_source ?line - templateline ?account - account)
             (line_recipient ?line - templateline ?recipient - recipient)
             (template_loaded)
             (batch_submitted)
             (receipt_archived)
             (receipt_at ?document - document ?location - location)
             (robot_has ?document - document)
             (transfer_completed ?recipient - recipient)
             (setting_is_charity_office)
             (terminal_connected)
             (robot_has_document_scanner)
             (read_template_capability)
             (donor_restrictions_immutable)
             (endpoint_validates)
 )
 (:functions 
             (account_balance ?account - account)
             (line_amount ?line - templateline)
             (transfer_amount)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)) (robot_at desk))
  :effect (and (not (robot_at desk)) (robot_at terminal)))
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at terminal)) (robot_at desk)))
 (:action load_batch_template
  :parameters ()
  :precondition (and (robot_at terminal) (not (template_loaded)))
  :effect (and (template_loaded) (line_in_template authorized_line) (line_in_template restricted_line) (assign (line_amount authorized_line) 40) (assign (line_amount restricted_line) 40) (line_source authorized_line unrestricted_account) (line_source restricted_line school_fee_account) (line_recipient authorized_line food_program) (line_recipient restricted_line food_program)))
 (:action remove_restricted_line
  :parameters ()
  :precondition (and (robot_at terminal) (template_loaded) (line_in_template restricted_line))
  :effect (and (not (line_in_template restricted_line)) (not (line_source restricted_line school_fee_account)) (not (line_recipient restricted_line food_program))))
 (:action submit_batch
  :parameters ()
  :precondition (and (robot_at terminal) (template_loaded) (not (batch_submitted)))
  :effect (and (batch_submitted) (transfer_completed food_program) (assign (transfer_amount) 40)))
 (:action scan_receipt
  :parameters ()
  :precondition (and (robot_at terminal) (batch_submitted) (receipt_at receipt terminal))
  :effect (and (robot_has receipt) (not (receipt_at receipt terminal))))
 (:action archive_receipt
  :parameters ()
  :precondition (and (robot_at desk) (robot_has receipt) (not (receipt_archived)))
  :effect (and (receipt_archived) (not (robot_has receipt))))
)
