(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions :numeric-fluents)
 (:types account ordertype)
 (:constants
   cash_account - account
   locked_product flexible_product - ordertype
 )
 (:predicates 
             (investment ?order - ordertype)
             (receipt_issued)
             (setting_is_financial_terminal)
             (permission_invest)
             (permission_redeem)
             (terminal_online)
             (payment_deadline_tomorrow)
 )
 (:functions 
             (balance ?account - account)
             (scheduled_payment)
             (redeemable_today ?order - ordertype)
             (available_tomorrow)
 )
 (:action purchase_flexible_product
  :parameters ()
  :precondition (and (<= 40 (balance cash_account)) (permission_invest) (terminal_online) (not (investment flexible_product)))
  :effect (and (assign (balance cash_account) (- (balance cash_account) 40)) (investment flexible_product) (assign (redeemable_today flexible_product) 40) (assign (available_tomorrow) (+ 40 (- (balance cash_account) 40)))))
 (:action purchase_locked_product
  :parameters ()
  :precondition (and (<= 40 (balance cash_account)) (permission_invest) (terminal_online) (not (investment locked_product)))
  :effect (and (assign (balance cash_account) (- (balance cash_account) 40)) (investment locked_product) (assign (redeemable_today locked_product) 0) (assign (available_tomorrow) (- (balance cash_account) 40))))
 (:action retain_scheduled_payment
  :parameters ()
  :precondition (and (payment_deadline_tomorrow))
  :effect (and (assign (scheduled_payment) 70)))
 (:action issue_receipt
  :parameters ()
  :precondition (and (terminal_online) (or (investment flexible_product) (investment locked_product)))
  :effect (and (receipt_issued)))
)
