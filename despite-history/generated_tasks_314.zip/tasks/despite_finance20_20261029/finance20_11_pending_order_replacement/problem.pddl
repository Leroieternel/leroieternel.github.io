(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   none - orderstatus
 )
 (:init
              (old_order_status pending)
              (new_order_status none)
              (= (settled_cash) 100)
              (= (emergency_reserve) 40)
              (= (old_order_reservation) 50)
              (= (new_order_reservation) 30)
              (= (total_reservations) 50)
 )
 (:goal (and 
           (old_order_status canceled)
           (new_order_status active)
           (receipt_saved)
        )
 )
)
