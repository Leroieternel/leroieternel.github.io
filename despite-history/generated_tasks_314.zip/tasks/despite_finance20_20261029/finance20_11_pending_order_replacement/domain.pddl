(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types orderstatus)
 (:constants
   pending active canceled cancel_requested - orderstatus
 )
 (:predicates 
             (old_order_status ?status - orderstatus)
             (new_order_status ?status - orderstatus)
             (receipt_saved)
             (cancel_acknowledged)
             (cancel_request_sent)
 )
 (:functions 
             (settled_cash)
             (emergency_reserve)
             (old_order_reservation)
             (new_order_reservation)
             (total_reservations)
 )
 (:action send_cancel_request
  :parameters ()
  :precondition (and (old_order_status pending) (not (cancel_request_sent)))
  :effect (and (cancel_request_sent) (not (old_order_status pending)) (old_order_status cancel_requested)))
 (:action process_cancel_ack
  :parameters ()
  :precondition (and (old_order_status cancel_requested) (not (cancel_acknowledged)))
  :effect (and (cancel_acknowledged) (not (old_order_status cancel_requested)) (old_order_status canceled) (assign (total_reservations) (- (total_reservations) (old_order_reservation)))))
 (:action place_new_order
  :parameters ()
  :precondition (and (not (new_order_status active)) (not (new_order_status pending)))
  :effect (and (new_order_status active) (assign (total_reservations) (+ (new_order_reservation) (total_reservations)))))
 (:action save_receipt
  :parameters ()
  :precondition (and (new_order_status active) (not (receipt_saved)))
  :effect (and (receipt_saved)))
)
