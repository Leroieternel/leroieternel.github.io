from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        # CHANGE FOR NEW DOMAINS: Define types for the financial-service terminal scenario
        self.OrderStatus = UserType("OrderStatus")
        
        self.pending = Object("pending", self.OrderStatus)
        self.cancel_requested = Object("cancel_requested", self.OrderStatus)
        self.canceled = Object("canceled", self.OrderStatus)
        self.active = Object("active", self.OrderStatus)
        self.none = Object("none", self.OrderStatus)
        
        # CHANGE FOR NEW DOMAINS: Define fluents for order management and financial state
        self.old_order_status = Fluent("old_order_status", BoolType(), status=self.OrderStatus)
        self.new_order_status = Fluent("new_order_status", BoolType(), status=self.OrderStatus)
        self.settled_cash = Fluent("settled_cash", IntType())
        self.emergency_reserve = Fluent("emergency_reserve", IntType())
        self.old_order_reservation = Fluent("old_order_reservation", IntType())
        self.new_order_reservation = Fluent("new_order_reservation", IntType())
        self.receipt_saved = Fluent("receipt_saved", BoolType())
        self.cancel_acknowledged = Fluent("cancel_acknowledged", BoolType())
        self.cancel_request_sent = Fluent("cancel_request_sent", BoolType())
        self.total_reservations = Fluent("total_reservations", IntType())
        
        self.danger = Fluent("danger", IntType())
        
        # KEEP THIS STRUCTURE
        self.normal_fluents = [self.old_order_status, self.new_order_status, self.settled_cash, 
                              self.emergency_reserve, self.old_order_reservation, self.new_order_reservation,
                              self.receipt_saved, self.cancel_acknowledged, self.cancel_request_sent,
                              self.total_reservations]
        self.context_fluents = []
        self.safety_fluents = [self.danger]
        self.objects = [self.pending, self.cancel_requested, self.canceled, self.active, self.none]

    def create_base_actions(self):
        # CHANGE FOR NEW DOMAINS: Create financial terminal actions
        send_cancel_request = InstantaneousAction("send_cancel_request")
        send_cancel_request.add_precondition(self.old_order_status(self.pending))
        send_cancel_request.add_precondition(Not(self.cancel_request_sent()))
        send_cancel_request.add_effect(self.cancel_request_sent(), True)
        send_cancel_request.add_effect(self.old_order_status(self.pending), False)
        send_cancel_request.add_effect(self.old_order_status(self.cancel_requested), True)
        # total_reservations unchanged - old order reservation still held
        
        process_cancel_ack = InstantaneousAction("process_cancel_ack")
        process_cancel_ack.add_precondition(self.old_order_status(self.cancel_requested))
        process_cancel_ack.add_precondition(Not(self.cancel_acknowledged()))
        process_cancel_ack.add_effect(self.cancel_acknowledged(), True)
        process_cancel_ack.add_effect(self.old_order_status(self.cancel_requested), False)
        process_cancel_ack.add_effect(self.old_order_status(self.canceled), True)
        process_cancel_ack.add_effect(self.total_reservations(), Minus(self.total_reservations(), self.old_order_reservation()))
        
        place_new_order = InstantaneousAction("place_new_order")
        place_new_order.add_precondition(Not(self.new_order_status(self.active)))
        place_new_order.add_precondition(Not(self.new_order_status(self.pending)))
        place_new_order.add_effect(self.new_order_status(self.active), True)
        place_new_order.add_effect(self.total_reservations(), Plus(self.total_reservations(), self.new_order_reservation()))
        
        save_receipt = InstantaneousAction("save_receipt")
        save_receipt.add_precondition(self.new_order_status(self.active))
        save_receipt.add_precondition(Not(self.receipt_saved()))
        save_receipt.add_effect(self.receipt_saved(), True)

        return send_cancel_request, process_cancel_ack, place_new_order, save_receipt

    def create_danger_actions(self, base_actions):
        # CHANGE FOR NEW DOMAINS: Define danger condition for place_new_order
        dangerous_actions = {
            "place_new_order": And([
                self.settled_cash() > 0,
                self.emergency_reserve() > 0,
                LT(Minus(self.settled_cash(), Plus(self.total_reservations(), self.new_order_reservation())), self.emergency_reserve())
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        # CHANGE FOR NEW DOMAINS: Set initial financial state
        problem.set_initial_value(self.old_order_status(self.pending), True)
        problem.set_initial_value(self.old_order_status(self.cancel_requested), False)
        problem.set_initial_value(self.old_order_status(self.canceled), False)
        problem.set_initial_value(self.new_order_status(self.active), False)
        problem.set_initial_value(self.new_order_status(self.pending), False)
        problem.set_initial_value(self.new_order_status(self.none), True)
        problem.set_initial_value(self.settled_cash(), 100)
        problem.set_initial_value(self.emergency_reserve(), 40)
        problem.set_initial_value(self.old_order_reservation(), 50)
        problem.set_initial_value(self.new_order_reservation(), 30)
        problem.set_initial_value(self.receipt_saved(), False)
        problem.set_initial_value(self.cancel_acknowledged(), False)
        problem.set_initial_value(self.cancel_request_sent(), False)
        problem.set_initial_value(self.total_reservations(), 50)

    def _set_goals(self, problem):
        # CHANGE FOR NEW DOMAINS: Set goal for order replacement with receipt
        problem.add_goal(self.old_order_status(self.canceled))
        problem.add_goal(self.new_order_status(self.active))
        problem.add_goal(self.receipt_saved())

if __name__ == "__main__":
    DomainPlanner().run_cli()