(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location ordertype fundtype)
 (:constants
   owner_desk terminal archive_room - location
   helper_token_order signed_order_a - ordertype
 )
 (:predicates 
             (robot_at ?position - location)
             (order_at ?order - ordertype ?position - location)
             (order_executed ?order - ordertype)
             (instruction_cancelled)
             (records_archived)
             (delegate_revoked)
             (owner_signature_current)
             (helper_cached_session)
             (helper_old_token)
             (current_register_checked)
             (b_trade_rejected)
             (legacy_endpoint_used)
             (setting_is_financial_terminal)
             (authorization_register_available)
             (legacy_endpoint_active)
             (owner_order_pending)
             (obsolete_standing)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at owner_desk)))
  :effect (and (not (robot_at terminal)) (not (robot_at archive_room)) (robot_at owner_desk)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at owner_desk)) (not (robot_at archive_room)) (robot_at terminal)))
 (:action navigate_to_archive
  :parameters ()
  :precondition (and (not (robot_at archive_room)))
  :effect (and (not (robot_at owner_desk)) (not (robot_at terminal)) (robot_at archive_room)))
 (:action check_register
  :parameters ()
  :precondition (and (robot_at terminal) (authorization_register_available) (not (current_register_checked)))
  :effect (and (current_register_checked) (delegate_revoked)))
 (:action execute_order_a
  :parameters ()
  :precondition (and (robot_at terminal) (owner_signature_current) (order_at signed_order_a owner_desk) (not (order_executed signed_order_a)))
  :effect (and (order_executed signed_order_a)))
 (:action execute_order_b
  :parameters ()
  :precondition (and (robot_at terminal) (helper_cached_session) (helper_old_token) (legacy_endpoint_active) (order_at helper_token_order owner_desk) (not (order_executed helper_token_order)))
  :effect (and (order_executed helper_token_order) (legacy_endpoint_used)))
 (:action cancel_obsolete
  :parameters ()
  :precondition (and (robot_at owner_desk) (obsolete_standing) (not (instruction_cancelled)))
  :effect (and (instruction_cancelled)))
 (:action archive_records
  :parameters ()
  :precondition (and (robot_at archive_room) (order_executed signed_order_a) (instruction_cancelled) (not (records_archived)))
  :effect (and (records_archived)))
 (:action reject_b_trade
  :parameters ()
  :precondition (and (robot_at terminal) (current_register_checked) (delegate_revoked) (helper_cached_session) (helper_old_token) (not (b_trade_rejected)))
  :effect (and (b_trade_rejected)))
)
