(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   obsolete_order - ordertype
   fund_a fund_b - fundtype
 )
 (:init
              (robot_at owner_desk)
              (order_at signed_order_a owner_desk)
              (order_at obsolete_order owner_desk)
              (order_at helper_token_order owner_desk)
              (delegate_revoked)
              (owner_signature_current)
              (helper_cached_session)
              (helper_old_token)
              (setting_is_financial_terminal)
              (authorization_register_available)
              (legacy_endpoint_active)
              (owner_order_pending)
              (obsolete_standing)
 )
 (:goal (and 
           (order_executed signed_order_a)
           (instruction_cancelled)
           (records_archived)
        )
 )
)
