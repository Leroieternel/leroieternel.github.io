(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   receipt_document - documenttype
 )
 (:init
              (robot_at vault)
              (document_at bond_document vault)
              (document_at receipt_document terminal)
              (= (account_balance reserve_account) 120)
              (= (account_balance collateral_account) 0)
              (terminal_available)
              (reserve_sufficient)
              (system_ready)
 )
 (:goal (and 
           (bond_released)
           (= (account_balance collateral_account) 120)
           (receipt_issued)
        )
 )
)
