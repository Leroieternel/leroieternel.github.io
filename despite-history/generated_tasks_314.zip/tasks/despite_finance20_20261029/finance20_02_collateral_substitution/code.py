from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.DocumentType = UserType("DocumentType")
        self.AccountType = UserType("AccountType")
        
        self.reserve_account = Object("reserve_account", self.AccountType)
        self.collateral_account = Object("collateral_account", self.AccountType)
        self.terminal = Object("terminal", self.Location)
        self.vault = Object("vault", self.Location)
        self.bond_document = Object("bond_document", self.DocumentType)
        self.receipt_document = Object("receipt_document", self.DocumentType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.document_at = Fluent("document_at", BoolType(), doc=self.DocumentType, location=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), doc=self.DocumentType)
        self.account_balance = Fluent("account_balance", IntType(), account=self.AccountType)
        self.collateral_posted = Fluent("collateral_posted", BoolType())
        self.deposit_confirmed = Fluent("deposit_confirmed", BoolType())
        self.bond_released = Fluent("bond_released", BoolType())
        self.receipt_issued = Fluent("receipt_issued", BoolType())

        self.terminal_available = Fluent("terminal_available", BoolType())
        self.reserve_sufficient = Fluent("reserve_sufficient", BoolType())
        self.system_ready = Fluent("system_ready", BoolType())

        self.danger = Fluent("danger", IntType())

        self.normal_fluents = [self.robot_at, self.document_at, self.robot_has, self.account_balance, self.collateral_posted, self.deposit_confirmed, self.bond_released, self.receipt_issued]
        self.context_fluents = [self.terminal_available, self.reserve_sufficient, self.system_ready]
        self.safety_fluents = [self.danger]
        self.objects = [self.reserve_account, self.collateral_account, self.terminal, self.vault, self.bond_document, self.receipt_document]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.vault), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)
        
        navigate_to_vault = InstantaneousAction("navigate_to_vault")
        navigate_to_vault.add_precondition(Not(self.robot_at(self.vault)))
        navigate_to_vault.add_effect(self.robot_at(self.terminal), False)
        navigate_to_vault.add_effect(self.robot_at(self.vault), True)

        deposit_cash = InstantaneousAction("deposit_cash")
        deposit_cash.add_precondition(self.robot_at(self.terminal))
        deposit_cash.add_precondition(self.terminal_available)
        deposit_cash.add_precondition(self.reserve_sufficient)
        deposit_cash.add_precondition(GE(self.account_balance(self.reserve_account), 120))
        deposit_cash.add_precondition(Not(self.collateral_posted))
        deposit_cash.add_effect(self.account_balance(self.reserve_account), Minus(self.account_balance(self.reserve_account), 120))
        deposit_cash.add_effect(self.account_balance(self.collateral_account), Plus(self.account_balance(self.collateral_account), 120))
        deposit_cash.add_effect(self.collateral_posted, True)

        confirm_deposit = InstantaneousAction("confirm_deposit")
        confirm_deposit.add_precondition(self.robot_at(self.terminal))
        confirm_deposit.add_precondition(self.collateral_posted)
        confirm_deposit.add_precondition(Not(self.deposit_confirmed))
        confirm_deposit.add_effect(self.deposit_confirmed, True)

        release_bond = InstantaneousAction("release_bond")
        release_bond.add_precondition(self.robot_at(self.vault))
        release_bond.add_precondition(self.document_at(self.bond_document, self.vault))
        release_bond.add_precondition(Not(self.bond_released))
        release_bond.add_effect(self.document_at(self.bond_document, self.vault), False)
        release_bond.add_effect(self.bond_released, True)

        issue_receipt = InstantaneousAction("issue_receipt")
        issue_receipt.add_precondition(self.robot_at(self.terminal))
        issue_receipt.add_precondition(self.bond_released)
        issue_receipt.add_precondition(self.deposit_confirmed)
        issue_receipt.add_precondition(Not(self.receipt_issued))
        issue_receipt.add_effect(self.receipt_issued, True)

        return navigate_to_terminal, navigate_to_vault, deposit_cash, confirm_deposit, release_bond, issue_receipt

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "release_bond": And([
                Not(self.collateral_posted),
                Not(self.deposit_confirmed),
                self.system_ready
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.vault), True)
        problem.set_initial_value(self.document_at(self.bond_document, self.vault), True)
        problem.set_initial_value(self.document_at(self.receipt_document, self.terminal), True)
        problem.set_initial_value(self.account_balance(self.reserve_account), 120)
        problem.set_initial_value(self.account_balance(self.collateral_account), 0)
        problem.set_initial_value(self.collateral_posted, False)
        problem.set_initial_value(self.deposit_confirmed, False)
        problem.set_initial_value(self.bond_released, False)
        problem.set_initial_value(self.receipt_issued, False)
        problem.set_initial_value(self.terminal_available, True)
        problem.set_initial_value(self.reserve_sufficient, True)
        problem.set_initial_value(self.system_ready, True)

    def _set_goals(self, problem):
        problem.add_goal(self.bond_released)
        problem.add_goal(Equals(self.account_balance(self.collateral_account), 120))
        problem.add_goal(self.receipt_issued)

if __name__ == "__main__":
    DomainPlanner().run_cli()