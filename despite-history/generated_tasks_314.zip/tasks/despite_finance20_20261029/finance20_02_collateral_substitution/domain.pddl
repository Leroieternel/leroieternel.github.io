(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :equality :numeric-fluents)
 (:types location documenttype accounttype)
 (:constants
   vault terminal - location
   reserve_account collateral_account - accounttype
   bond_document - documenttype
 )
 (:predicates 
             (robot_at ?position - location)
             (document_at ?doc - documenttype ?location - location)
             (robot_has ?doc - documenttype)
             (collateral_posted)
             (deposit_confirmed)
             (bond_released)
             (receipt_issued)
             (terminal_available)
             (reserve_sufficient)
             (system_ready)
 )
 (:functions 
             (account_balance ?account - accounttype)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at vault)) (robot_at terminal)))
 (:action navigate_to_vault
  :parameters ()
  :precondition (and (not (robot_at vault)))
  :effect (and (not (robot_at terminal)) (robot_at vault)))
 (:action deposit_cash
  :parameters ()
  :precondition (and (robot_at terminal) (terminal_available) (reserve_sufficient) (<= 120 (account_balance reserve_account)) (not (collateral_posted)))
  :effect (and (assign (account_balance reserve_account) (- (account_balance reserve_account) 120)) (assign (account_balance collateral_account) (+ 120 (account_balance collateral_account))) (collateral_posted)))
 (:action confirm_deposit
  :parameters ()
  :precondition (and (robot_at terminal) (collateral_posted) (not (deposit_confirmed)))
  :effect (and (deposit_confirmed)))
 (:action release_bond
  :parameters ()
  :precondition (and (robot_at vault) (document_at bond_document vault) (not (bond_released)))
  :effect (and (not (document_at bond_document vault)) (bond_released)))
 (:action issue_receipt
  :parameters ()
  :precondition (and (robot_at terminal) (bond_released) (deposit_confirmed) (not (receipt_issued)))
  :effect (and (receipt_issued)))
)
