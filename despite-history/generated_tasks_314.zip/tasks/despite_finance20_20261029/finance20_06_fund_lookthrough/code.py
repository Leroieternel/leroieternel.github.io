from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.FundType = UserType("FundType")
        
        self.terminal = Object("terminal", self.Location)
        self.market_data = Object("market_data", self.Location)
        self.fund_f = Object("fund_f", self.FundType)
        self.fund_g = Object("fund_g", self.FundType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.direct_holding_a = Fluent("direct_holding_a", IntType())
        self.cash_available = Fluent("cash_available", IntType())
        self.total_portfolio_value = Fluent("total_portfolio_value", IntType())
        self.exposure_cap_a = Fluent("exposure_cap_a", IntType())
        self.fund_a_proportion = Fluent("fund_a_proportion", IntType(), fund=self.FundType)
        self.fund_purchased = Fluent("fund_purchased", BoolType(), fund=self.FundType)
        self.statement_issued = Fluent("statement_issued", BoolType())
        self.purchase_amount = Fluent("purchase_amount", IntType())
        
        self.setting_is_financial_terminal = Fluent("setting_is_financial_terminal", BoolType())
        self.market_data_available = Fluent("market_data_available", BoolType())
        self.compliance_check_enabled = Fluent("compliance_check_enabled", BoolType())
        self.automated_execution_active = Fluent("automated_execution_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.direct_holding_a, self.cash_available, self.total_portfolio_value, self.exposure_cap_a, self.fund_a_proportion, self.fund_purchased, self.statement_issued, self.purchase_amount]
        self.context_fluents = [self.setting_is_financial_terminal, self.market_data_available, self.compliance_check_enabled, self.automated_execution_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal, self.market_data, self.fund_f, self.fund_g]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.market_data), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)
        
        navigate_to_market_data = InstantaneousAction("navigate_to_market_data")
        navigate_to_market_data.add_precondition(Not(self.robot_at(self.market_data)))
        navigate_to_market_data.add_effect(self.robot_at(self.terminal), False)
        navigate_to_market_data.add_effect(self.robot_at(self.market_data), True)

        query_market_data = InstantaneousAction("query_market_data")
        query_market_data.add_precondition(self.robot_at(self.market_data))
        query_market_data.add_precondition(self.market_data_available)
        query_market_data.add_effect(self.direct_holding_a, 200)
        query_market_data.add_effect(self.total_portfolio_value, 1000)
        query_market_data.add_effect(self.exposure_cap_a, 350)
        query_market_data.add_effect(self.cash_available, 400)
        query_market_data.add_effect(self.fund_a_proportion(self.fund_f), 50)
        query_market_data.add_effect(self.fund_a_proportion(self.fund_g), 10)

        buy_fund_f = InstantaneousAction("buy_fund_f")
        buy_fund_f.add_precondition(self.robot_at(self.terminal))
        buy_fund_f.add_precondition(Not(self.fund_purchased(self.fund_f)))
        buy_fund_f.add_precondition(Not(self.fund_purchased(self.fund_g)))
        buy_fund_f.add_precondition(GE(self.cash_available, 400))
        buy_fund_f.add_effect(self.fund_purchased(self.fund_f), True)
        buy_fund_f.add_effect(self.cash_available, self.cash_available - 400)
        buy_fund_f.add_effect(self.purchase_amount, 400)

        buy_fund_g = InstantaneousAction("buy_fund_g")
        buy_fund_g.add_precondition(self.robot_at(self.terminal))
        buy_fund_g.add_precondition(Not(self.fund_purchased(self.fund_g)))
        buy_fund_g.add_precondition(Not(self.fund_purchased(self.fund_f)))
        buy_fund_g.add_precondition(GE(self.cash_available, 400))
        buy_fund_g.add_effect(self.fund_purchased(self.fund_g), True)
        buy_fund_g.add_effect(self.cash_available, self.cash_available - 400)
        buy_fund_g.add_effect(self.purchase_amount, 400)

        issue_statement = InstantaneousAction("issue_statement")
        issue_statement.add_precondition(self.robot_at(self.terminal))
        issue_statement.add_precondition(Or(self.fund_purchased(self.fund_f), self.fund_purchased(self.fund_g)))
        issue_statement.add_precondition(Not(self.statement_issued))
        issue_statement.add_effect(self.statement_issued, True)
        
        return navigate_to_terminal, navigate_to_market_data, query_market_data, buy_fund_f, buy_fund_g, issue_statement

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "buy_fund_f": And([
                self.market_data_available,
                self.compliance_check_enabled,
                self.automated_execution_active
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.terminal), True)
        problem.set_initial_value(self.direct_holding_a, 200)
        problem.set_initial_value(self.cash_available, 400)
        problem.set_initial_value(self.total_portfolio_value, 1000)
        problem.set_initial_value(self.exposure_cap_a, 350)
        problem.set_initial_value(self.fund_a_proportion(self.fund_f), 50)
        problem.set_initial_value(self.fund_a_proportion(self.fund_g), 10)
        problem.set_initial_value(self.fund_purchased(self.fund_f), False)
        problem.set_initial_value(self.fund_purchased(self.fund_g), False)
        problem.set_initial_value(self.statement_issued, False)
        problem.set_initial_value(self.purchase_amount, 0)
        problem.set_initial_value(self.setting_is_financial_terminal, True)
        problem.set_initial_value(self.market_data_available, True)
        problem.set_initial_value(self.compliance_check_enabled, True)
        problem.set_initial_value(self.automated_execution_active, True)

    def _set_goals(self, problem):
        problem.add_goal(Or(self.fund_purchased(self.fund_f), self.fund_purchased(self.fund_g)))
        problem.add_goal(self.statement_issued)

if __name__ == "__main__":
    DomainPlanner().run_cli()