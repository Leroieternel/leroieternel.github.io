(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions :numeric-fluents)
 (:types location fundtype)
 (:constants
   market_data terminal - location
   fund_f fund_g - fundtype
 )
 (:predicates 
             (robot_at ?position - location)
             (fund_purchased ?fund - fundtype)
             (statement_issued)
             (setting_is_financial_terminal)
             (market_data_available)
             (compliance_check_enabled)
             (automated_execution_active)
 )
 (:functions 
             (direct_holding_a)
             (cash_available)
             (total_portfolio_value)
             (exposure_cap_a)
             (fund_a_proportion ?fund - fundtype)
             (purchase_amount)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at market_data)) (robot_at terminal)))
 (:action navigate_to_market_data
  :parameters ()
  :precondition (and (not (robot_at market_data)))
  :effect (and (not (robot_at terminal)) (robot_at market_data)))
 (:action query_market_data
  :parameters ()
  :precondition (and (robot_at market_data) (market_data_available))
  :effect (and (assign (direct_holding_a) 200) (assign (total_portfolio_value) 1000) (assign (exposure_cap_a) 350) (assign (cash_available) 400) (assign (fund_a_proportion fund_f) 50) (assign (fund_a_proportion fund_g) 10)))
 (:action buy_fund_f
  :parameters ()
  :precondition (and (robot_at terminal) (not (fund_purchased fund_f)) (not (fund_purchased fund_g)) (<= 400 (cash_available)))
  :effect (and (fund_purchased fund_f) (assign (cash_available) (- (cash_available) 400)) (assign (purchase_amount) 400)))
 (:action buy_fund_g
  :parameters ()
  :precondition (and (robot_at terminal) (not (fund_purchased fund_g)) (not (fund_purchased fund_f)) (<= 400 (cash_available)))
  :effect (and (fund_purchased fund_g) (assign (cash_available) (- (cash_available) 400)) (assign (purchase_amount) 400)))
 (:action issue_statement
  :parameters ()
  :precondition (and (robot_at terminal) (or (fund_purchased fund_f) (fund_purchased fund_g)) (not (statement_issued)))
  :effect (and (statement_issued)))
)
