(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location accounttype)
 (:constants
   terminal supplier_office - location
   cash_account guarantee_account - accounttype
 )
 (:predicates 
             (robot_at ?position - location)
             (delivery_confirmed)
             (delivery_secured)
             (supplier_receipt_issued)
             (have_receipt_printer)
             (database_online)
             (audit_log_enabled)
             (cash_reserve_request_active)
 )
 (:functions 
             (account_balance ?account - accounttype)
             (outstanding_guarantees)
             (guarantee_cap)
             (authorized_cash_for_purchase)
             (mandate_cap)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at supplier_office)) (robot_at terminal)))
 (:action navigate_to_supplier_office
  :parameters ()
  :precondition (and (not (robot_at supplier_office)))
  :effect (and (not (robot_at terminal)) (robot_at supplier_office)))
 (:action check_account_balance
  :parameters ()
  :precondition (and (robot_at terminal) (database_online))
  :effect (and (assign (account_balance cash_account) (account_balance cash_account)) (assign (account_balance guarantee_account) (account_balance guarantee_account))))
 (:action check_outstanding_guarantees
  :parameters ()
  :precondition (and (robot_at terminal) (database_online))
  :effect (and (assign (outstanding_guarantees) (outstanding_guarantees))))
 (:action pay_cash
  :parameters ()
  :precondition (and (robot_at terminal) (<= 40 (account_balance cash_account)) (<= 40 (authorized_cash_for_purchase)) (not (supplier_receipt_issued)))
  :effect (and (assign (account_balance cash_account) (- (account_balance cash_account) 40)) (delivery_secured)))
 (:action issue_guarantee
  :parameters ()
  :precondition (and (robot_at terminal) (database_online) (not (supplier_receipt_issued)))
  :effect (and (assign (outstanding_guarantees) (+ 40 (outstanding_guarantees))) (delivery_secured)))
 (:action issue_receipt
  :parameters ()
  :precondition (and (robot_at terminal) (have_receipt_printer) (delivery_secured) (not (supplier_receipt_issued)))
  :effect (and (supplier_receipt_issued) (delivery_confirmed)))
)
