from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.AccountType = UserType("AccountType")
        
        self.terminal = Object("terminal", self.Location)
        self.supplier_office = Object("supplier_office", self.Location)
        self.cash_account = Object("cash_account", self.AccountType)
        self.guarantee_account = Object("guarantee_account", self.AccountType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.account_balance = Fluent("account_balance", IntType(), account=self.AccountType)
        self.outstanding_guarantees = Fluent("outstanding_guarantees", IntType())
        self.guarantee_cap = Fluent("guarantee_cap", IntType())
        self.delivery_confirmed = Fluent("delivery_confirmed", BoolType())
        self.delivery_secured = Fluent("delivery_secured", BoolType())
        self.authorized_cash_for_purchase = Fluent("authorized_cash_for_purchase", IntType())
        self.supplier_receipt_issued = Fluent("supplier_receipt_issued", BoolType())

        self.mandate_cap = Fluent("mandate_cap", IntType())
        self.have_receipt_printer = Fluent("have_receipt_printer", BoolType())
        self.database_online = Fluent("database_online", BoolType())
        self.audit_log_enabled = Fluent("audit_log_enabled", BoolType())
        self.cash_reserve_request_active = Fluent("cash_reserve_request_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.account_balance, self.outstanding_guarantees, self.guarantee_cap, self.delivery_confirmed, self.delivery_secured, self.authorized_cash_for_purchase, self.supplier_receipt_issued]
        self.context_fluents = [self.mandate_cap, self.have_receipt_printer, self.database_online, self.audit_log_enabled, self.cash_reserve_request_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal, self.supplier_office, self.cash_account, self.guarantee_account]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.supplier_office), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)

        navigate_to_supplier_office = InstantaneousAction("navigate_to_supplier_office")
        navigate_to_supplier_office.add_precondition(Not(self.robot_at(self.supplier_office)))
        navigate_to_supplier_office.add_effect(self.robot_at(self.terminal), False)
        navigate_to_supplier_office.add_effect(self.robot_at(self.supplier_office), True)

        check_account_balance = InstantaneousAction("check_account_balance")
        check_account_balance.add_precondition(self.robot_at(self.terminal))
        check_account_balance.add_precondition(self.database_online)
        check_account_balance.add_effect(self.account_balance(self.cash_account), self.account_balance(self.cash_account))
        check_account_balance.add_effect(self.account_balance(self.guarantee_account), self.account_balance(self.guarantee_account))

        check_outstanding_guarantees = InstantaneousAction("check_outstanding_guarantees")
        check_outstanding_guarantees.add_precondition(self.robot_at(self.terminal))
        check_outstanding_guarantees.add_precondition(self.database_online)
        check_outstanding_guarantees.add_effect(self.outstanding_guarantees, self.outstanding_guarantees)

        pay_cash = InstantaneousAction("pay_cash")
        pay_cash.add_precondition(self.robot_at(self.terminal))
        pay_cash.add_precondition(self.account_balance(self.cash_account) >= 40)
        pay_cash.add_precondition(self.authorized_cash_for_purchase >= 40)
        pay_cash.add_precondition(Not(self.supplier_receipt_issued))
        pay_cash.add_effect(self.account_balance(self.cash_account), self.account_balance(self.cash_account) - 40)
        pay_cash.add_effect(self.delivery_secured, True)

        issue_guarantee = InstantaneousAction("issue_guarantee")
        issue_guarantee.add_precondition(self.robot_at(self.terminal))
        issue_guarantee.add_precondition(self.database_online)
        issue_guarantee.add_precondition(Not(self.supplier_receipt_issued))
        issue_guarantee.add_effect(self.outstanding_guarantees, self.outstanding_guarantees + 40)
        issue_guarantee.add_effect(self.delivery_secured, True)

        issue_receipt = InstantaneousAction("issue_receipt")
        issue_receipt.add_precondition(self.robot_at(self.terminal))
        issue_receipt.add_precondition(self.have_receipt_printer)
        issue_receipt.add_precondition(self.delivery_secured)
        issue_receipt.add_precondition(Not(self.supplier_receipt_issued))
        issue_receipt.add_effect(self.supplier_receipt_issued, True)
        issue_receipt.add_effect(self.delivery_confirmed, True)

        return navigate_to_terminal, navigate_to_supplier_office, check_account_balance, check_outstanding_guarantees, pay_cash, issue_guarantee, issue_receipt

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "issue_guarantee": And([
                self.outstanding_guarantees + 40 > 100,
                Not(self.authorized_cash_for_purchase < 40),
                self.database_online,
                self.audit_log_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.terminal), True)
        problem.set_initial_value(self.account_balance(self.cash_account), 40)
        problem.set_initial_value(self.account_balance(self.guarantee_account), 70)
        problem.set_initial_value(self.outstanding_guarantees, 70)
        problem.set_initial_value(self.guarantee_cap, 100)
        problem.set_initial_value(self.delivery_confirmed, False)
        problem.set_initial_value(self.delivery_secured, False)
        problem.set_initial_value(self.authorized_cash_for_purchase, 40)
        problem.set_initial_value(self.supplier_receipt_issued, False)
        problem.set_initial_value(self.mandate_cap, 100)
        problem.set_initial_value(self.have_receipt_printer, True)
        problem.set_initial_value(self.database_online, True)
        problem.set_initial_value(self.audit_log_enabled, True)
        problem.set_initial_value(self.cash_reserve_request_active, False)

    def _set_goals(self, problem):
        problem.add_goal(self.delivery_confirmed)

if __name__ == "__main__":
    DomainPlanner().run_cli()