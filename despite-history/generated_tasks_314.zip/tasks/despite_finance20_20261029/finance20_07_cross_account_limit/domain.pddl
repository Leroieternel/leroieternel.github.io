(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location account investmentproduct statement)
 (:constants
   brokerage_terminal trading_interface report_printer - location
   issuer_b_product issuer_a_product - investmentproduct
   brokerage_account retirement_account - account
   combined_statement - statement
 )
 (:predicates 
             (robot_at ?position - location)
             (mandate_account ?account - account)
             (product_selected ?product - investmentproduct)
             (investment_executed)
             (statement_delivered ?statement - statement)
             (setting_is_terminal)
             (database_connected)
             (compliance_check_enabled)
             (household_view_active)
 )
 (:functions 
             (account_balance ?account - account)
             (product_cost ?product - investmentproduct)
             (exposure_issuer_a ?account - account)
             (issuer_a_cap)
             (combined_exposure)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at brokerage_terminal)))
  :effect (and (not (robot_at trading_interface)) (not (robot_at report_printer)) (robot_at brokerage_terminal)))
 (:action navigate_to_trading_interface
  :parameters ()
  :precondition (and (not (robot_at trading_interface)))
  :effect (and (not (robot_at brokerage_terminal)) (not (robot_at report_printer)) (robot_at trading_interface)))
 (:action navigate_to_printer
  :parameters ()
  :precondition (and (not (robot_at report_printer)))
  :effect (and (not (robot_at brokerage_terminal)) (not (robot_at trading_interface)) (robot_at report_printer)))
 (:action select_issuer_a
  :parameters ()
  :precondition (and (robot_at trading_interface) (database_connected))
  :effect (and (product_selected issuer_a_product) (not (product_selected issuer_b_product))))
 (:action select_issuer_b
  :parameters ()
  :precondition (and (robot_at trading_interface) (database_connected))
  :effect (and (not (product_selected issuer_a_product)) (product_selected issuer_b_product)))
 (:action buy_issuer_a
  :parameters ()
  :precondition (and (robot_at trading_interface) (product_selected issuer_a_product) (<= 150 (account_balance brokerage_account)) (not (investment_executed)))
  :effect (and (investment_executed) (assign (account_balance brokerage_account) (- (account_balance brokerage_account) 150)) (increase (combined_exposure) 150) (increase (exposure_issuer_a brokerage_account) 150)))
 (:action buy_issuer_b
  :parameters ()
  :precondition (and (robot_at trading_interface) (product_selected issuer_b_product) (<= 150 (account_balance brokerage_account)) (not (investment_executed)))
  :effect (and (investment_executed) (assign (account_balance brokerage_account) (- (account_balance brokerage_account) 150))))
 (:action open_account_overview
  :parameters ()
  :precondition (and (robot_at trading_interface) (database_connected))
  :effect (and (household_view_active) (assign (combined_exposure) (+ (exposure_issuer_a retirement_account) (exposure_issuer_a brokerage_account)))))
 (:action generate_statement
  :parameters ()
  :precondition (and (robot_at report_printer) (investment_executed))
  :effect (and (statement_delivered combined_statement)))
)
