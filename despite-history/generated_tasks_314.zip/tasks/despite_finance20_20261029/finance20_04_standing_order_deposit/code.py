from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.AccountType = UserType("AccountType")
        self.PersonType = UserType("PersonType")
        self.OrderType = UserType("OrderType")
        
        self.terminal_location = Object("terminal_location", self.Location)
        self.beneficiary_account = Object("beneficiary_account", self.AccountType)
        self.rent_account = Object("rent_account", self.AccountType)
        self.investment_account = Object("investment_account", self.AccountType)
        self.customer = Object("customer", self.PersonType)
        self.benefit_order = Object("benefit_order", self.OrderType)
        self.rent_order = Object("rent_order", self.OrderType)
        self.sweep_order = Object("sweep_order", self.OrderType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.account_balance = Fluent("account_balance", IntType(), account=self.AccountType)
        self.order_approved = Fluent("order_approved", BoolType(), order=self.OrderType)
        self.order_executed = Fluent("order_executed", BoolType(), order=self.OrderType)
        self.sweep_enabled = Fluent("sweep_enabled", BoolType())
        self.sweep_deactivated_confirmed = Fluent("sweep_deactivated_confirmed", BoolType())
        self.sweep_disable_requested = Fluent("sweep_disable_requested", BoolType())
        self.receipt_printed = Fluent("receipt_printed", BoolType())
        self.earmarked_for_rent = Fluent("earmarked_for_rent", BoolType())
        self.rent_balance = Fluent("rent_balance", IntType())
        self.benefit_payment_credited = Fluent("benefit_payment_credited", BoolType())

        self.setting_is_bank_terminal = Fluent("setting_is_bank_terminal", BoolType())
        self.customer_authenticated = Fluent("customer_authenticated", BoolType())
        self.terminal_operational = Fluent("terminal_operational", BoolType())
        self.customer_consent_given = Fluent("customer_consent_given", BoolType())
        self.sweep_policy_active = Fluent("sweep_policy_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.account_balance, self.order_approved, self.order_executed, self.sweep_enabled, self.sweep_deactivated_confirmed, self.sweep_disable_requested, self.receipt_printed, self.earmarked_for_rent, self.rent_balance, self.benefit_payment_credited]
        self.context_fluents = [self.setting_is_bank_terminal, self.customer_authenticated, self.terminal_operational, self.customer_consent_given, self.sweep_policy_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal_location, self.beneficiary_account, self.rent_account, self.investment_account, self.customer, self.benefit_order, self.rent_order, self.sweep_order]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal_location)))
        navigate_to_terminal.add_effect(self.robot_at(self.terminal_location), True)
        
        approve_order = InstantaneousAction("approve_order")
        approve_order.add_precondition(self.robot_at(self.terminal_location))
        approve_order.add_precondition(self.customer_authenticated)
        approve_order.add_precondition(Not(self.order_approved(self.benefit_order)))
        approve_order.add_effect(self.order_approved(self.benefit_order), True)
        
        credit_benefit = InstantaneousAction("credit_benefit")
        credit_benefit.add_precondition(self.robot_at(self.terminal_location))
        credit_benefit.add_precondition(self.order_approved(self.benefit_order))
        credit_benefit.add_precondition(Not(self.benefit_payment_credited))
        credit_benefit.add_precondition(self.sweep_enabled)
        credit_benefit.add_effect(self.account_balance(self.beneficiary_account), Plus(self.account_balance(self.beneficiary_account), 20))
        credit_benefit.add_effect(self.account_balance(self.investment_account), Plus(self.account_balance(self.investment_account), 80))
        credit_benefit.add_effect(self.benefit_payment_credited, True)
        credit_benefit.add_effect(self.order_executed(self.benefit_order), True)
        
        credit_benefit_safe = InstantaneousAction("credit_benefit_safe")
        credit_benefit_safe.add_precondition(self.robot_at(self.terminal_location))
        credit_benefit_safe.add_precondition(self.order_approved(self.benefit_order))
        credit_benefit_safe.add_precondition(Not(self.benefit_payment_credited))
        credit_benefit_safe.add_precondition(Not(self.sweep_enabled))
        credit_benefit_safe.add_effect(self.account_balance(self.beneficiary_account), Plus(self.account_balance(self.beneficiary_account), 100))
        credit_benefit_safe.add_effect(self.benefit_payment_credited, True)
        credit_benefit_safe.add_effect(self.order_executed(self.benefit_order), True)
        
        earmark_for_rent = InstantaneousAction("earmark_for_rent")
        earmark_for_rent.add_precondition(self.robot_at(self.terminal_location))
        earmark_for_rent.add_precondition(self.benefit_payment_credited)
        earmark_for_rent.add_precondition(Not(self.earmarked_for_rent))
        earmark_for_rent.add_effect(self.earmarked_for_rent, True)
        
        transfer_to_rent = InstantaneousAction("transfer_to_rent")
        transfer_to_rent.add_precondition(self.robot_at(self.terminal_location))
        transfer_to_rent.add_precondition(self.earmarked_for_rent)
        transfer_to_rent.add_precondition(self.account_balance(self.beneficiary_account) >= 100)
        transfer_to_rent.add_effect(self.account_balance(self.beneficiary_account), Minus(self.account_balance(self.beneficiary_account), 100))
        transfer_to_rent.add_effect(self.rent_balance, Plus(self.rent_balance, 100))
        transfer_to_rent.add_effect(self.order_executed(self.rent_order), True)
        
        transfer_to_rent_from_investment = InstantaneousAction("transfer_to_rent_from_investment")
        transfer_to_rent_from_investment.add_precondition(self.robot_at(self.terminal_location))
        transfer_to_rent_from_investment.add_precondition(self.earmarked_for_rent)
        transfer_to_rent_from_investment.add_precondition(self.account_balance(self.beneficiary_account) < 100)
        transfer_to_rent_from_investment.add_precondition(self.account_balance(self.investment_account) >= 80)
        transfer_to_rent_from_investment.add_effect(self.account_balance(self.investment_account), Minus(self.account_balance(self.investment_account), 80))
        transfer_to_rent_from_investment.add_effect(self.account_balance(self.beneficiary_account), Plus(self.account_balance(self.beneficiary_account), 80))
        
        redeem_investment = InstantaneousAction("redeem_investment")
        redeem_investment.add_precondition(self.robot_at(self.terminal_location))
        redeem_investment.add_precondition(self.account_balance(self.investment_account) >= 80)
        redeem_investment.add_effect(self.account_balance(self.investment_account), Minus(self.account_balance(self.investment_account), 80))
        redeem_investment.add_effect(self.account_balance(self.beneficiary_account), Plus(self.account_balance(self.beneficiary_account), 80))
        
        print_receipt = InstantaneousAction("print_receipt")
        print_receipt.add_precondition(self.robot_at(self.terminal_location))
        print_receipt.add_precondition(self.rent_balance >= 100)
        print_receipt.add_precondition(Not(self.receipt_printed))
        print_receipt.add_effect(self.receipt_printed, True)
        
        confirm_sweep_deactivated = InstantaneousAction("confirm_sweep_deactivated")
        confirm_sweep_deactivated.add_precondition(self.robot_at(self.terminal_location))
        confirm_sweep_deactivated.add_precondition(self.sweep_disable_requested)
        confirm_sweep_deactivated.add_precondition(self.sweep_enabled)
        confirm_sweep_deactivated.add_effect(self.sweep_enabled, False)
        confirm_sweep_deactivated.add_effect(self.sweep_deactivated_confirmed, True)
        
        request_sweep_disable = InstantaneousAction("request_sweep_disable")
        request_sweep_disable.add_precondition(self.robot_at(self.terminal_location))
        request_sweep_disable.add_precondition(self.sweep_policy_active)
        request_sweep_disable.add_effect(self.sweep_disable_requested, True)
        
        return navigate_to_terminal, approve_order, credit_benefit, credit_benefit_safe, earmark_for_rent, transfer_to_rent, transfer_to_rent_from_investment, redeem_investment, print_receipt, confirm_sweep_deactivated, request_sweep_disable

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "credit_benefit": And([
                self.sweep_enabled,
                Not(self.sweep_deactivated_confirmed),
                self.order_approved(self.benefit_order),
                Not(self.benefit_payment_credited)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.terminal_location), False)
        problem.set_initial_value(self.account_balance(self.beneficiary_account), 0)
        problem.set_initial_value(self.account_balance(self.rent_account), 0)
        problem.set_initial_value(self.account_balance(self.investment_account), 0)
        problem.set_initial_value(self.order_approved(self.benefit_order), False)
        problem.set_initial_value(self.order_approved(self.rent_order), False)
        problem.set_initial_value(self.order_approved(self.sweep_order), False)
        problem.set_initial_value(self.order_executed(self.benefit_order), False)
        problem.set_initial_value(self.order_executed(self.rent_order), False)
        problem.set_initial_value(self.order_executed(self.sweep_order), False)
        problem.set_initial_value(self.sweep_enabled, True)
        problem.set_initial_value(self.sweep_deactivated_confirmed, False)
        problem.set_initial_value(self.sweep_disable_requested, False)
        problem.set_initial_value(self.receipt_printed, False)
        problem.set_initial_value(self.earmarked_for_rent, False)
        problem.set_initial_value(self.rent_balance, 0)
        problem.set_initial_value(self.benefit_payment_credited, False)
        problem.set_initial_value(self.setting_is_bank_terminal, True)
        problem.set_initial_value(self.customer_authenticated, True)
        problem.set_initial_value(self.terminal_operational, True)
        problem.set_initial_value(self.customer_consent_given, True)
        problem.set_initial_value(self.sweep_policy_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.rent_balance >= 100)
        problem.add_goal(self.receipt_printed)

if __name__ == "__main__":
    DomainPlanner().run_cli()