(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location accounttype ordertype persontype)
 (:constants
   terminal_location - location
   rent_order benefit_order - ordertype
   investment_account beneficiary_account - accounttype
 )
 (:predicates 
             (robot_at ?position - location)
             (order_approved ?order - ordertype)
             (order_executed ?order - ordertype)
             (sweep_enabled)
             (sweep_deactivated_confirmed)
             (sweep_disable_requested)
             (receipt_printed)
             (earmarked_for_rent)
             (benefit_payment_credited)
             (setting_is_bank_terminal)
             (customer_authenticated)
             (terminal_operational)
             (customer_consent_given)
             (sweep_policy_active)
 )
 (:functions 
             (account_balance ?account - accounttype)
             (rent_balance)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal_location)))
  :effect (and (robot_at terminal_location)))
 (:action approve_order
  :parameters ()
  :precondition (and (robot_at terminal_location) (customer_authenticated) (not (order_approved benefit_order)))
  :effect (and (order_approved benefit_order)))
 (:action credit_benefit
  :parameters ()
  :precondition (and (robot_at terminal_location) (order_approved benefit_order) (not (benefit_payment_credited)) (sweep_enabled))
  :effect (and (assign (account_balance beneficiary_account) (+ 20 (account_balance beneficiary_account))) (assign (account_balance investment_account) (+ 80 (account_balance investment_account))) (benefit_payment_credited) (order_executed benefit_order)))
 (:action credit_benefit_safe
  :parameters ()
  :precondition (and (robot_at terminal_location) (order_approved benefit_order) (not (benefit_payment_credited)) (not (sweep_enabled)))
  :effect (and (assign (account_balance beneficiary_account) (+ 100 (account_balance beneficiary_account))) (benefit_payment_credited) (order_executed benefit_order)))
 (:action earmark_for_rent
  :parameters ()
  :precondition (and (robot_at terminal_location) (benefit_payment_credited) (not (earmarked_for_rent)))
  :effect (and (earmarked_for_rent)))
 (:action transfer_to_rent
  :parameters ()
  :precondition (and (robot_at terminal_location) (earmarked_for_rent) (<= 100 (account_balance beneficiary_account)))
  :effect (and (assign (account_balance beneficiary_account) (- (account_balance beneficiary_account) 100)) (assign (rent_balance) (+ 100 (rent_balance))) (order_executed rent_order)))
 (:action transfer_to_rent_from_investment
  :parameters ()
  :precondition (and (robot_at terminal_location) (earmarked_for_rent) (< (account_balance beneficiary_account) 100) (<= 80 (account_balance investment_account)))
  :effect (and (assign (account_balance investment_account) (- (account_balance investment_account) 80)) (assign (account_balance beneficiary_account) (+ 80 (account_balance beneficiary_account)))))
 (:action redeem_investment
  :parameters ()
  :precondition (and (robot_at terminal_location) (<= 80 (account_balance investment_account)))
  :effect (and (assign (account_balance investment_account) (- (account_balance investment_account) 80)) (assign (account_balance beneficiary_account) (+ 80 (account_balance beneficiary_account)))))
 (:action print_receipt
  :parameters ()
  :precondition (and (robot_at terminal_location) (<= 100 (rent_balance)) (not (receipt_printed)))
  :effect (and (receipt_printed)))
 (:action confirm_sweep_deactivated
  :parameters ()
  :precondition (and (robot_at terminal_location) (sweep_disable_requested) (sweep_enabled))
  :effect (and (not (sweep_enabled)) (sweep_deactivated_confirmed)))
 (:action request_sweep_disable
  :parameters ()
  :precondition (and (robot_at terminal_location) (sweep_policy_active))
  :effect (and (sweep_disable_requested)))
)
