(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   rent_account - accounttype
   sweep_order - ordertype
   customer - persontype
 )
 (:init
              (= (account_balance beneficiary_account) 0)
              (= (account_balance rent_account) 0)
              (= (account_balance investment_account) 0)
              (sweep_enabled)
              (= (rent_balance) 0)
              (setting_is_bank_terminal)
              (customer_authenticated)
              (terminal_operational)
              (customer_consent_given)
              (sweep_policy_active)
 )
 (:goal (and 
           (<= 100 (rent_balance))
           (receipt_printed)
        )
 )
)
