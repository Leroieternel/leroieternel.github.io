(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   long_account hedge_asset statement_doc portfolio_viewer order_entry - itemtype
 )
 (:init
              (robot_at terminal)
              (= (long_position) 100)
              (= (hedge_position) 60)
              (= (net_exposure) 40)
              (setting_is_brokerage)
              (= (mandate_cap) 50)
              (trade_authorized)
              (compliance_enabled)
              (terminal_operational)
 )
 (:goal (and 
           (= (long_position) 80)
           (= (hedge_position) 40)
           (statement_filed)
        )
 )
)
