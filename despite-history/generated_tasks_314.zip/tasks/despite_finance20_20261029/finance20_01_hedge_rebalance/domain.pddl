(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :equality :numeric-fluents)
 (:types location itemtype)
 (:constants
   terminal - location
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (statement_filed)
             (logged_in)
             (inspected)
             (setting_is_brokerage)
             (trade_authorized)
             (compliance_enabled)
             (terminal_operational)
 )
 (:functions 
             (long_position)
             (hedge_position)
             (net_exposure)
             (mandate_cap)
 )
 (:action login
  :parameters ()
  :precondition (and (not (logged_in)) (robot_at terminal))
  :effect (and (logged_in)))
 (:action inspect_positions
  :parameters ()
  :precondition (and (logged_in) (robot_at terminal) (not (inspected)))
  :effect (and (inspected)))
 (:action sell_long
  :parameters ()
  :precondition (and (logged_in) (robot_at terminal) (<= 20 (long_position)))
  :effect (and (assign (long_position) (- (long_position) 20)) (assign (net_exposure) (+ (- 0 (hedge_position)) (- (long_position) 20)))))
 (:action close_hedge
  :parameters ()
  :precondition (and (logged_in) (robot_at terminal) (<= 20 (hedge_position)))
  :effect (and (assign (hedge_position) (- (hedge_position) 20)) (assign (net_exposure) (- (long_position) (- (hedge_position) 20)))))
 (:action file_statement
  :parameters ()
  :precondition (and (logged_in) (robot_at terminal) (not (statement_filed)))
  :effect (and (statement_filed)))
)
