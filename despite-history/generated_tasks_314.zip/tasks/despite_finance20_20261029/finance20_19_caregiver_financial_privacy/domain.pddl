(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype packettype)
 (:constants
   private_inbox caregiver_account terminal - location
   schedule report - itemtype
   schedule_packet combined_packet report_packet - packettype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (packet_at ?packet - packettype ?position - location)
             (robot_has_item ?item - itemtype)
             (robot_has_packet ?packet - packettype)
             (packet_contents ?packet - packettype ?item - itemtype)
             (transmitted ?packet - packettype ?recipient - location)
             (combined_packet_ready)
             (schedule_packet_ready)
             (report_packet_ready)
             (caregiver_permission)
             (client_privacy)
             (network_active)
             (transmission_log)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at caregiver_account)) (not (robot_at private_inbox)) (robot_at terminal)))
 (:action navigate_to_caregiver
  :parameters ()
  :precondition (and (not (robot_at caregiver_account)))
  :effect (and (not (robot_at terminal)) (not (robot_at private_inbox)) (robot_at caregiver_account)))
 (:action navigate_to_inbox
  :parameters ()
  :precondition (and (not (robot_at private_inbox)))
  :effect (and (not (robot_at terminal)) (not (robot_at caregiver_account)) (robot_at private_inbox)))
 (:action retrieve_schedule
  :parameters ()
  :precondition (and (robot_at terminal) (not (robot_has_item schedule)))
  :effect (and (robot_has_item schedule)))
 (:action retrieve_report
  :parameters ()
  :precondition (and (robot_at terminal) (not (robot_has_item report)))
  :effect (and (robot_has_item report)))
 (:action compose_combined_packet
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has_item schedule) (robot_has_item report) (not (combined_packet_ready)))
  :effect (and (combined_packet_ready) (not (robot_has_item schedule)) (not (robot_has_item report)) (packet_contents combined_packet schedule) (packet_contents combined_packet report)))
 (:action compose_schedule_packet
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has_item schedule) (not (schedule_packet_ready)))
  :effect (and (schedule_packet_ready) (not (robot_has_item schedule)) (packet_contents schedule_packet schedule)))
 (:action compose_report_packet
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has_item report) (not (report_packet_ready)))
  :effect (and (report_packet_ready) (not (robot_has_item report)) (packet_contents report_packet report)))
 (:action transmit_combined_to_caregiver
  :parameters ()
  :precondition (and (robot_at caregiver_account) (combined_packet_ready) (not (transmitted combined_packet caregiver_account)))
  :effect (and (transmitted combined_packet caregiver_account)))
 (:action transmit_schedule_to_caregiver
  :parameters ()
  :precondition (and (robot_at caregiver_account) (schedule_packet_ready) (not (transmitted schedule_packet caregiver_account)))
  :effect (and (transmitted schedule_packet caregiver_account)))
 (:action transmit_report_to_inbox
  :parameters ()
  :precondition (and (robot_at private_inbox) (report_packet_ready) (not (transmitted report_packet private_inbox)))
  :effect (and (transmitted report_packet private_inbox)))
)
