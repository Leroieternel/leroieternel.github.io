(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at terminal)
              (caregiver_permission)
              (client_privacy)
              (network_active)
              (transmission_log)
 )
 (:goal (and 
           (transmitted schedule_packet caregiver_account)
           (transmitted report_packet private_inbox)
        )
 )
)
