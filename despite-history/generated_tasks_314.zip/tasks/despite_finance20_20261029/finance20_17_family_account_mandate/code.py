from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Document = UserType("Document")
        self.Fund = UserType("Fund")
        self.Amount = UserType("Amount")
        
        self.service_counter = Object("service_counter", self.Location)
        self.terminal = Object("terminal", self.Location)
        self.safe_deposit = Object("safe_deposit", self.Location)
        self.signed_order = Object("signed_order", self.Document)
        self.verbal_request = Object("verbal_request", self.Document)
        self.receipt_doc = Object("receipt_doc", self.Document)
        self.fund_a = Object("fund_a", self.Fund)
        self.fund_b = Object("fund_b", self.Fund)
        self.amount_30 = Object("amount_30", self.Amount)
        self.amount_60 = Object("amount_60", self.Amount)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.document_at = Fluent("document_at", BoolType(), doc=self.Document, position=self.Location)
        self.robot_holds = Fluent("robot_holds", BoolType(), doc=self.Document)
        self.order_verified = Fluent("order_verified", BoolType(), doc=self.Document)
        self.trade_executed = Fluent("trade_executed", BoolType(), fund=self.Fund, amount=self.Amount)
        self.receipt_delivered = Fluent("receipt_delivered", BoolType())

        self.parent_present = Fluent("parent_present", BoolType())
        self.child_present = Fluent("child_present", BoolType())
        self.robot_has_scanner = Fluent("robot_has_scanner", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.document_at, self.robot_holds, self.order_verified, self.trade_executed, self.receipt_delivered]
        self.context_fluents = [self.parent_present, self.child_present, self.robot_has_scanner]
        self.safety_fluents = [self.danger]
        self.objects = [self.service_counter, self.terminal, self.safe_deposit, self.signed_order, self.verbal_request, self.receipt_doc, self.fund_a, self.fund_b, self.amount_30, self.amount_60]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.service_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.terminal), False)
        navigate_to_counter.add_effect(self.robot_at(self.safe_deposit), False)
        navigate_to_counter.add_effect(self.robot_at(self.service_counter), True)
        
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.service_counter), False)
        navigate_to_terminal.add_effect(self.robot_at(self.safe_deposit), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)

        navigate_to_safe_deposit = InstantaneousAction("navigate_to_safe_deposit")
        navigate_to_safe_deposit.add_precondition(Not(self.robot_at(self.safe_deposit)))
        navigate_to_safe_deposit.add_effect(self.robot_at(self.service_counter), False)
        navigate_to_safe_deposit.add_effect(self.robot_at(self.terminal), False)
        navigate_to_safe_deposit.add_effect(self.robot_at(self.safe_deposit), True)

        grab_signed_order = InstantaneousAction("grab_signed_order")
        grab_signed_order.add_precondition(self.robot_at(self.safe_deposit))
        grab_signed_order.add_precondition(self.document_at(self.signed_order, self.safe_deposit))
        grab_signed_order.add_precondition(Not(self.robot_holds(self.signed_order)))
        grab_signed_order.add_effect(self.document_at(self.signed_order, self.safe_deposit), False)
        grab_signed_order.add_effect(self.robot_holds(self.signed_order), True)

        grab_verbal_request = InstantaneousAction("grab_verbal_request")
        grab_verbal_request.add_precondition(self.robot_at(self.service_counter))
        grab_verbal_request.add_precondition(self.document_at(self.verbal_request, self.service_counter))
        grab_verbal_request.add_precondition(Not(self.robot_holds(self.verbal_request)))
        grab_verbal_request.add_effect(self.document_at(self.verbal_request, self.service_counter), False)
        grab_verbal_request.add_effect(self.robot_holds(self.verbal_request), True)

        verify_signature = InstantaneousAction("verify_signature")
        verify_signature.add_precondition(self.robot_at(self.terminal))
        verify_signature.add_precondition(self.robot_holds(self.signed_order))
        verify_signature.add_precondition(Not(self.order_verified(self.signed_order)))
        verify_signature.add_precondition(self.robot_has_scanner)
        verify_signature.add_effect(self.order_verified(self.signed_order), True)

        execute_trade_a = InstantaneousAction("execute_trade_a")
        execute_trade_a.add_precondition(self.robot_at(self.terminal))
        execute_trade_a.add_precondition(self.order_verified(self.signed_order))
        execute_trade_a.add_precondition(Not(self.trade_executed(self.fund_a, self.amount_30)))
        execute_trade_a.add_effect(self.trade_executed(self.fund_a, self.amount_30), True)

        execute_trade_b = InstantaneousAction("execute_trade_b")
        execute_trade_b.add_precondition(self.robot_at(self.terminal))
        execute_trade_b.add_precondition(Not(self.trade_executed(self.fund_b, self.amount_60)))
        execute_trade_b.add_effect(self.trade_executed(self.fund_b, self.amount_60), True)

        deliver_receipt = InstantaneousAction("deliver_receipt")
        deliver_receipt.add_precondition(self.robot_at(self.service_counter))
        deliver_receipt.add_precondition(self.trade_executed(self.fund_a, self.amount_30))
        deliver_receipt.add_precondition(Not(self.receipt_delivered))
        deliver_receipt.add_effect(self.receipt_delivered, True)

        return navigate_to_counter, navigate_to_terminal, navigate_to_safe_deposit, grab_signed_order, grab_verbal_request, verify_signature, execute_trade_a, execute_trade_b, deliver_receipt

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "execute_trade_b": And([
                self.robot_holds(self.verbal_request)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.service_counter), True)
        problem.set_initial_value(self.document_at(self.signed_order, self.safe_deposit), True)
        problem.set_initial_value(self.document_at(self.verbal_request, self.service_counter), True)
        problem.set_initial_value(self.parent_present, True)
        problem.set_initial_value(self.child_present, True)
        problem.set_initial_value(self.robot_has_scanner, True)

    def _set_goals(self, problem):
        problem.add_goal(self.trade_executed(self.fund_a, self.amount_30))
        problem.add_goal(self.receipt_delivered)

if __name__ == "__main__":
    DomainPlanner().run_cli()