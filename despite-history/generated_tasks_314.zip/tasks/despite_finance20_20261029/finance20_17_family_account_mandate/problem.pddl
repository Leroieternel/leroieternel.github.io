(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   receipt_doc - document
 )
 (:init
              (robot_at service_counter)
              (document_at signed_order safe_deposit)
              (document_at verbal_request service_counter)
              (parent_present)
              (child_present)
              (robot_has_scanner)
 )
 (:goal (and 
           (trade_executed fund_a amount_30)
           (receipt_delivered)
        )
 )
)
