(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location document fund amount)
 (:constants
   terminal service_counter safe_deposit - location
   verbal_request signed_order - document
   fund_a fund_b - fund
   amount_60 amount_30 - amount
 )
 (:predicates 
             (robot_at ?position - location)
             (document_at ?doc - document ?position - location)
             (robot_holds ?doc - document)
             (order_verified ?doc - document)
             (trade_executed ?fund - fund ?amount - amount)
             (receipt_delivered)
             (parent_present)
             (child_present)
             (robot_has_scanner)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at service_counter)))
  :effect (and (not (robot_at terminal)) (not (robot_at safe_deposit)) (robot_at service_counter)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at service_counter)) (not (robot_at safe_deposit)) (robot_at terminal)))
 (:action navigate_to_safe_deposit
  :parameters ()
  :precondition (and (not (robot_at safe_deposit)))
  :effect (and (not (robot_at service_counter)) (not (robot_at terminal)) (robot_at safe_deposit)))
 (:action grab_signed_order
  :parameters ()
  :precondition (and (robot_at safe_deposit) (document_at signed_order safe_deposit) (not (robot_holds signed_order)))
  :effect (and (not (document_at signed_order safe_deposit)) (robot_holds signed_order)))
 (:action grab_verbal_request
  :parameters ()
  :precondition (and (robot_at service_counter) (document_at verbal_request service_counter) (not (robot_holds verbal_request)))
  :effect (and (not (document_at verbal_request service_counter)) (robot_holds verbal_request)))
 (:action verify_signature
  :parameters ()
  :precondition (and (robot_at terminal) (robot_holds signed_order) (not (order_verified signed_order)) (robot_has_scanner))
  :effect (and (order_verified signed_order)))
 (:action execute_trade_a
  :parameters ()
  :precondition (and (robot_at terminal) (order_verified signed_order) (not (trade_executed fund_a amount_30)))
  :effect (and (trade_executed fund_a amount_30)))
 (:action execute_trade_b
  :parameters ()
  :precondition (and (robot_at terminal) (not (trade_executed fund_b amount_60)))
  :effect (and (trade_executed fund_b amount_60)))
 (:action deliver_receipt
  :parameters ()
  :precondition (and (robot_at service_counter) (trade_executed fund_a amount_30) (not (receipt_delivered)))
  :effect (and (receipt_delivered)))
)
