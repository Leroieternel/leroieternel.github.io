(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location doctype)
 (:constants
   terminal signature_storage draft_storage - location
   sig_b invoice_a - doctype
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_at ?item - doctype ?position - location)
             (robot_holds ?item - doctype)
             (draft_edited)
             (b_signature_validated)
             (payment_executed)
             (receipt_archived)
             (setting_terminal_online)
             (receipt_printer_ready)
             (draft_recipient_is_b)
             (draft_amount_is_30)
 )
 (:action navigate_draft_storage
  :parameters ()
  :precondition (and (not (robot_at draft_storage)))
  :effect (and (not (robot_at signature_storage)) (not (robot_at terminal)) (robot_at draft_storage)))
 (:action navigate_signature_storage
  :parameters ()
  :precondition (and (not (robot_at signature_storage)))
  :effect (and (not (robot_at draft_storage)) (not (robot_at terminal)) (robot_at signature_storage)))
 (:action navigate_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at draft_storage)) (not (robot_at signature_storage)) (robot_at terminal)))
 (:action grab_draft
  :parameters ()
  :precondition (and (robot_at draft_storage) (doc_at invoice_a draft_storage) (not (robot_holds invoice_a)))
  :effect (and (not (doc_at invoice_a draft_storage)) (robot_holds invoice_a)))
 (:action edit_draft_to_b
  :parameters ()
  :precondition (and (robot_at terminal) (robot_holds invoice_a) (not (draft_edited)))
  :effect (and (draft_recipient_is_b) (draft_edited)))
 (:action grab_sig_b
  :parameters ()
  :precondition (and (robot_at signature_storage) (doc_at sig_b signature_storage) (not (robot_holds sig_b)))
  :effect (and (not (doc_at sig_b signature_storage)) (robot_holds sig_b)))
 (:action validate_b_signature
  :parameters ()
  :precondition (and (robot_at terminal) (robot_holds sig_b) (not (b_signature_validated)))
  :effect (and (b_signature_validated)))
 (:action execute_payment
  :parameters ()
  :precondition (and (robot_at terminal) (draft_recipient_is_b) (draft_amount_is_30) (not (payment_executed)))
  :effect (and (payment_executed)))
 (:action archive_receipt
  :parameters ()
  :precondition (and (robot_at terminal) (payment_executed) (not (receipt_archived)))
  :effect (and (receipt_archived)))
)
