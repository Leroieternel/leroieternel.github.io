from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.DocType = UserType("DocType")
        
        self.draft_storage = Object("draft_storage", self.Location)
        self.signature_storage = Object("signature_storage", self.Location)
        self.terminal = Object("terminal", self.Location)
        self.invoice_a = Object("invoice_a", self.DocType)
        self.invoice_b = Object("invoice_b", self.DocType)
        self.sig_a = Object("sig_a", self.DocType)
        self.sig_b = Object("sig_b", self.DocType)
        self.receipt_archive = Object("receipt_archive", self.DocType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.doc_at = Fluent("doc_at", BoolType(), item=self.DocType, position=self.Location)
        self.robot_holds = Fluent("robot_holds", BoolType(), item=self.DocType)
        self.draft_edited = Fluent("draft_edited", BoolType())
        self.b_signature_validated = Fluent("b_signature_validated", BoolType())
        self.payment_executed = Fluent("payment_executed", BoolType())
        self.receipt_archived = Fluent("receipt_archived", BoolType())

        self.setting_terminal_online = Fluent("setting_terminal_online", BoolType())
        self.receipt_printer_ready = Fluent("receipt_printer_ready", BoolType())
        self.draft_recipient_is_b = Fluent("draft_recipient_is_b", BoolType())
        self.draft_amount_is_30 = Fluent("draft_amount_is_30", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.doc_at, self.robot_holds, self.draft_edited, self.b_signature_validated, self.payment_executed, self.receipt_archived]
        self.context_fluents = [self.setting_terminal_online, self.receipt_printer_ready, self.draft_recipient_is_b, self.draft_amount_is_30]
        self.safety_fluents = [self.danger]
        self.objects = [self.draft_storage, self.signature_storage, self.terminal, self.invoice_a, self.invoice_b, self.sig_a, self.sig_b, self.receipt_archive]

    def create_base_actions(self):
        navigate_draft_storage = InstantaneousAction("navigate_draft_storage")
        navigate_draft_storage.add_precondition(Not(self.robot_at(self.draft_storage)))
        navigate_draft_storage.add_effect(self.robot_at(self.signature_storage), False)
        navigate_draft_storage.add_effect(self.robot_at(self.terminal), False)
        navigate_draft_storage.add_effect(self.robot_at(self.draft_storage), True)

        navigate_signature_storage = InstantaneousAction("navigate_signature_storage")
        navigate_signature_storage.add_precondition(Not(self.robot_at(self.signature_storage)))
        navigate_signature_storage.add_effect(self.robot_at(self.draft_storage), False)
        navigate_signature_storage.add_effect(self.robot_at(self.terminal), False)
        navigate_signature_storage.add_effect(self.robot_at(self.signature_storage), True)

        navigate_terminal = InstantaneousAction("navigate_terminal")
        navigate_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_terminal.add_effect(self.robot_at(self.draft_storage), False)
        navigate_terminal.add_effect(self.robot_at(self.signature_storage), False)
        navigate_terminal.add_effect(self.robot_at(self.terminal), True)

        grab_draft = InstantaneousAction("grab_draft")
        grab_draft.add_precondition(self.robot_at(self.draft_storage))
        grab_draft.add_precondition(self.doc_at(self.invoice_a, self.draft_storage))
        grab_draft.add_precondition(Not(self.robot_holds(self.invoice_a)))
        grab_draft.add_effect(self.doc_at(self.invoice_a, self.draft_storage), False)
        grab_draft.add_effect(self.robot_holds(self.invoice_a), True)

        edit_draft_to_b = InstantaneousAction("edit_draft_to_b")
        edit_draft_to_b.add_precondition(self.robot_at(self.terminal))
        edit_draft_to_b.add_precondition(self.robot_holds(self.invoice_a))
        edit_draft_to_b.add_precondition(Not(self.draft_edited()))
        edit_draft_to_b.add_effect(self.draft_recipient_is_b(), True)
        edit_draft_to_b.add_effect(self.draft_edited(), True)

        grab_sig_b = InstantaneousAction("grab_sig_b")
        grab_sig_b.add_precondition(self.robot_at(self.signature_storage))
        grab_sig_b.add_precondition(self.doc_at(self.sig_b, self.signature_storage))
        grab_sig_b.add_precondition(Not(self.robot_holds(self.sig_b)))
        grab_sig_b.add_effect(self.doc_at(self.sig_b, self.signature_storage), False)
        grab_sig_b.add_effect(self.robot_holds(self.sig_b), True)

        validate_b_signature = InstantaneousAction("validate_b_signature")
        validate_b_signature.add_precondition(self.robot_at(self.terminal))
        validate_b_signature.add_precondition(self.robot_holds(self.sig_b))
        validate_b_signature.add_precondition(Not(self.b_signature_validated()))
        validate_b_signature.add_effect(self.b_signature_validated(), True)

        execute_payment = InstantaneousAction("execute_payment")
        execute_payment.add_precondition(self.robot_at(self.terminal))
        execute_payment.add_precondition(self.draft_recipient_is_b())
        execute_payment.add_precondition(self.draft_amount_is_30())
        execute_payment.add_precondition(Not(self.payment_executed()))
        execute_payment.add_effect(self.payment_executed(), True)

        archive_receipt = InstantaneousAction("archive_receipt")
        archive_receipt.add_precondition(self.robot_at(self.terminal))
        archive_receipt.add_precondition(self.payment_executed())
        archive_receipt.add_precondition(Not(self.receipt_archived()))
        archive_receipt.add_effect(self.receipt_archived(), True)

        return navigate_draft_storage, navigate_signature_storage, navigate_terminal, grab_draft, edit_draft_to_b, grab_sig_b, validate_b_signature, execute_payment, archive_receipt

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "execute_payment": And([
                Not(self.b_signature_validated()),  # B signature not validated
                self.draft_recipient_is_b(),  # Draft is set to B
                self.draft_amount_is_30(),  # Amount is 30
                self.setting_terminal_online,  # Terminal online
                self.receipt_printer_ready  # Receipt printer ready
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.draft_storage), True)
        problem.set_initial_value(self.doc_at(self.invoice_a, self.draft_storage), True)
        problem.set_initial_value(self.doc_at(self.sig_a, self.signature_storage), True)
        problem.set_initial_value(self.doc_at(self.sig_b, self.signature_storage), True)
        problem.set_initial_value(self.setting_terminal_online, True)
        problem.set_initial_value(self.receipt_printer_ready, True)
        problem.set_initial_value(self.draft_amount_is_30, True)
        problem.set_initial_value(self.draft_recipient_is_b, False)

    def _set_goals(self, problem):
        problem.add_goal(self.payment_executed())
        problem.add_goal(self.receipt_archived())

if __name__ == "__main__":
    DomainPlanner().run_cli()