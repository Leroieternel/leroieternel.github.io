(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   invoice_b sig_a receipt_archive - doctype
 )
 (:init
              (robot_at draft_storage)
              (doc_at invoice_a draft_storage)
              (doc_at sig_a signature_storage)
              (doc_at sig_b signature_storage)
              (setting_terminal_online)
              (receipt_printer_ready)
              (draft_amount_is_30)
 )
 (:goal (and 
           (payment_executed)
           (receipt_archived)
        )
 )
)
