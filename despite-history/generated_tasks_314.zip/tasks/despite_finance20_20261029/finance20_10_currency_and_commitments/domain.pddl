(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions :numeric-fluents)
 (:types location itemtype)
 (:constants
   printer fund_shelf terminal - location
   eur_lot usd_lot - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (purchased ?item - itemtype)
             (receipt_filed)
             (setting_is_investment_terminal)
             (robot_has_currency_converter)
             (robot_has_authorization_check)
             (database_available)
             (error_checking_enabled)
 )
 (:functions 
             (committed_chf)
             (authorization_cap_chf)
             (usd_cost_chf)
             (eur_cost_chf)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at fund_shelf)) (not (robot_at printer)) (robot_at terminal)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at fund_shelf)))
  :effect (and (not (robot_at terminal)) (not (robot_at printer)) (robot_at fund_shelf)))
 (:action navigate_to_printer
  :parameters ()
  :precondition (and (not (robot_at printer)))
  :effect (and (not (robot_at terminal)) (not (robot_at fund_shelf)) (robot_at printer)))
 (:action buy_usd_lot
  :parameters ()
  :precondition (and (robot_at terminal) (item_at usd_lot fund_shelf) (not (purchased usd_lot)) (<= (+ (usd_cost_chf) (committed_chf)) (authorization_cap_chf)))
  :effect (and (assign (committed_chf) (+ (usd_cost_chf) (committed_chf))) (purchased usd_lot) (not (item_at usd_lot fund_shelf))))
 (:action buy_eur_lot
  :parameters ()
  :precondition (and (robot_at terminal) (item_at eur_lot fund_shelf) (not (purchased eur_lot)))
  :effect (and (assign (committed_chf) (+ (eur_cost_chf) (committed_chf))) (purchased eur_lot) (not (item_at eur_lot fund_shelf))))
 (:action file_receipt
  :parameters ()
  :precondition (and (robot_at printer) (or (purchased usd_lot) (purchased eur_lot)) (not (receipt_filed)))
  :effect (and (receipt_filed)))
)
