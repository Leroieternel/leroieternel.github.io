from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.AccountType = UserType("AccountType")
        self.OrderType = UserType("OrderType")
        
        self.terminal_location = Object("terminal_location", self.Location)
        self.receipt_printer = Object("receipt_printer", self.Location)
        self.client_area = Object("client_area", self.Location)
        
        self.investment_account = Object("investment_account", self.AccountType)
        self.reserve_account = Object("reserve_account", self.AccountType)
        
        self.order_20 = Object("order_20", self.OrderType)
        self.order_80 = Object("order_80", self.OrderType)
        
        self.robot_at = Fluent("robot_at", BoolType(), location=self.Location)
        self.account_balance = Fluent("account_balance", IntType(), account=self.AccountType)
        self.order_selected = Fluent("order_selected", BoolType(), order=self.OrderType)
        self.receipt_printed = Fluent("receipt_printed", BoolType())
        self.lot_acquired = Fluent("lot_acquired", BoolType())
        self.transfer_complete = Fluent("transfer_complete", BoolType(), source=self.AccountType, target=self.AccountType)
        self.mandate_signed_20 = Fluent("mandate_signed_20", BoolType())
        self.mandate_signed_80 = Fluent("mandate_signed_80", BoolType())
        self.client_seen = Fluent("client_seen", BoolType())
        self.receipt_delivered = Fluent("receipt_delivered", BoolType())
        
        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.account_balance, self.order_selected, self.receipt_printed, self.lot_acquired, self.transfer_complete, self.mandate_signed_20, self.mandate_signed_80, self.client_seen, self.receipt_delivered]
        self.context_fluents = []
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal_location, self.receipt_printer, self.client_area, self.investment_account, self.reserve_account, self.order_20, self.order_80]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal_location)))
        navigate_to_terminal.add_effect(self.robot_at(self.receipt_printer), False)
        navigate_to_terminal.add_effect(self.robot_at(self.client_area), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal_location), True)

        navigate_to_printer = InstantaneousAction("navigate_to_printer")
        navigate_to_printer.add_precondition(Not(self.robot_at(self.receipt_printer)))
        navigate_to_printer.add_effect(self.robot_at(self.terminal_location), False)
        navigate_to_printer.add_effect(self.robot_at(self.client_area), False)
        navigate_to_printer.add_effect(self.robot_at(self.receipt_printer), True)

        navigate_to_client = InstantaneousAction("navigate_to_client")
        navigate_to_client.add_precondition(Not(self.robot_at(self.client_area)))
        navigate_to_client.add_effect(self.robot_at(self.terminal_location), False)
        navigate_to_client.add_effect(self.robot_at(self.receipt_printer), False)
        navigate_to_client.add_effect(self.robot_at(self.client_area), True)

        select_order_20 = InstantaneousAction("select_order_20")
        select_order_20.add_precondition(self.robot_at(self.terminal_location))
        select_order_20.add_precondition(Not(self.order_selected(self.order_20)))
        select_order_20.add_effect(self.order_selected(self.order_20), True)

        select_order_80 = InstantaneousAction("select_order_80")
        select_order_80.add_precondition(self.robot_at(self.terminal_location))
        select_order_80.add_precondition(Not(self.order_selected(self.order_80)))
        select_order_80.add_effect(self.order_selected(self.order_80), True)

        transfer_from_reserve_to_investment = InstantaneousAction("transfer_from_reserve_to_investment")
        transfer_from_reserve_to_investment.add_precondition(self.robot_at(self.terminal_location))
        transfer_from_reserve_to_investment.add_precondition(GE(self.account_balance(self.reserve_account), 40))
        transfer_from_reserve_to_investment.add_precondition(Not(self.transfer_complete(self.reserve_account, self.investment_account)))
        transfer_from_reserve_to_investment.add_effect(self.transfer_complete(self.reserve_account, self.investment_account), True)
        transfer_from_reserve_to_investment.add_effect(self.account_balance(self.reserve_account), Minus(self.account_balance(self.reserve_account), 40))
        transfer_from_reserve_to_investment.add_effect(self.account_balance(self.investment_account), Plus(self.account_balance(self.investment_account), 40))

        execute_order_20 = InstantaneousAction("execute_order_20")
        execute_order_20.add_precondition(self.robot_at(self.terminal_location))
        execute_order_20.add_precondition(self.order_selected(self.order_20))
        execute_order_20.add_precondition(GE(self.account_balance(self.investment_account), 20))
        execute_order_20.add_precondition(Not(self.lot_acquired))
        execute_order_20.add_effect(self.lot_acquired, True)
        execute_order_20.add_effect(self.account_balance(self.investment_account), Minus(self.account_balance(self.investment_account), 20))

        execute_order_80 = InstantaneousAction("execute_order_80")
        execute_order_80.add_precondition(self.robot_at(self.terminal_location))
        execute_order_80.add_precondition(self.order_selected(self.order_80))
        execute_order_80.add_precondition(GE(self.account_balance(self.investment_account), 80))
        execute_order_80.add_precondition(Not(self.lot_acquired))
        execute_order_80.add_effect(self.lot_acquired, True)
        execute_order_80.add_effect(self.account_balance(self.investment_account), Minus(self.account_balance(self.investment_account), 80))

        print_receipt = InstantaneousAction("print_receipt")
        print_receipt.add_precondition(self.robot_at(self.receipt_printer))
        print_receipt.add_precondition(self.lot_acquired)
        print_receipt.add_precondition(Not(self.receipt_printed))
        print_receipt.add_effect(self.receipt_printed, True)

        deliver_receipt = InstantaneousAction("deliver_receipt")
        deliver_receipt.add_precondition(self.robot_at(self.client_area))
        deliver_receipt.add_precondition(self.receipt_printed)
        deliver_receipt.add_precondition(Not(self.receipt_delivered))
        deliver_receipt.add_effect(self.receipt_delivered, True)

        return navigate_to_terminal, navigate_to_printer, navigate_to_client, select_order_20, select_order_80, transfer_from_reserve_to_investment, execute_order_20, execute_order_80, print_receipt, deliver_receipt

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "execute_order_80": And([
                self.transfer_complete(self.reserve_account, self.investment_account),
                GE(self.account_balance(self.investment_account), 80),
                Not(self.mandate_signed_80),
                self.client_seen
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.client_area), True)
        problem.set_initial_value(self.account_balance(self.investment_account), 40)
        problem.set_initial_value(self.account_balance(self.reserve_account), 60)
        problem.set_initial_value(self.mandate_signed_20, True)
        problem.set_initial_value(self.mandate_signed_80, False)
        problem.set_initial_value(self.client_seen, True)

    def _set_goals(self, problem):
        problem.add_goal(self.lot_acquired)
        problem.add_goal(self.receipt_delivered)

if __name__ == "__main__":
    DomainPlanner().run_cli()