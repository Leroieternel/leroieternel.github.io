(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location accounttype ordertype)
 (:constants
   terminal_location client_area receipt_printer - location
   order_20 order_80 - ordertype
   investment_account reserve_account - accounttype
 )
 (:predicates 
             (robot_at ?location - location)
             (order_selected ?order - ordertype)
             (receipt_printed)
             (lot_acquired)
             (transfer_complete ?source - accounttype ?target - accounttype)
             (mandate_signed_20)
             (mandate_signed_80)
             (client_seen)
             (receipt_delivered)
 )
 (:functions 
             (account_balance ?account - accounttype)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal_location)))
  :effect (and (not (robot_at receipt_printer)) (not (robot_at client_area)) (robot_at terminal_location)))
 (:action navigate_to_printer
  :parameters ()
  :precondition (and (not (robot_at receipt_printer)))
  :effect (and (not (robot_at terminal_location)) (not (robot_at client_area)) (robot_at receipt_printer)))
 (:action navigate_to_client
  :parameters ()
  :precondition (and (not (robot_at client_area)))
  :effect (and (not (robot_at terminal_location)) (not (robot_at receipt_printer)) (robot_at client_area)))
 (:action select_order_20
  :parameters ()
  :precondition (and (robot_at terminal_location) (not (order_selected order_20)))
  :effect (and (order_selected order_20)))
 (:action select_order_80
  :parameters ()
  :precondition (and (robot_at terminal_location) (not (order_selected order_80)))
  :effect (and (order_selected order_80)))
 (:action transfer_from_reserve_to_investment
  :parameters ()
  :precondition (and (robot_at terminal_location) (<= 40 (account_balance reserve_account)) (not (transfer_complete reserve_account investment_account)))
  :effect (and (transfer_complete reserve_account investment_account) (assign (account_balance reserve_account) (- (account_balance reserve_account) 40)) (assign (account_balance investment_account) (+ 40 (account_balance investment_account)))))
 (:action execute_order_20
  :parameters ()
  :precondition (and (robot_at terminal_location) (order_selected order_20) (<= 20 (account_balance investment_account)) (not (lot_acquired)))
  :effect (and (lot_acquired) (assign (account_balance investment_account) (- (account_balance investment_account) 20))))
 (:action execute_order_80
  :parameters ()
  :precondition (and (robot_at terminal_location) (order_selected order_80) (<= 80 (account_balance investment_account)) (not (lot_acquired)))
  :effect (and (lot_acquired) (assign (account_balance investment_account) (- (account_balance investment_account) 80))))
 (:action print_receipt
  :parameters ()
  :precondition (and (robot_at receipt_printer) (lot_acquired) (not (receipt_printed)))
  :effect (and (receipt_printed)))
 (:action deliver_receipt
  :parameters ()
  :precondition (and (robot_at client_area) (receipt_printed) (not (receipt_delivered)))
  :effect (and (receipt_delivered)))
)
