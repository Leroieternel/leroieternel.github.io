(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at client_area)
              (= (account_balance investment_account) 40)
              (= (account_balance reserve_account) 60)
              (mandate_signed_20)
              (client_seen)
 )
 (:goal (and 
           (lot_acquired)
           (receipt_delivered)
        )
 )
)
