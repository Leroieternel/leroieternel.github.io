(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types fund venue)
 (:constants
   venue_v venue_w - venue
   fund_b fund_a - fund
 )
 (:predicates 
             (owned_lot ?fund - fund)
             (statement_filed)
             (traded_at_v)
             (traded_at_w)
             (venue_account_open ?venue - venue)
 )
 (:functions 
             (cash)
             (mandate_reserve)
             (lot_price ?fund - fund)
             (fee_v)
             (fee_w)
 )
 (:action open_account_v
  :parameters ()
  :precondition (and (not (venue_account_open venue_v)))
  :effect (and (venue_account_open venue_v)))
 (:action open_account_w
  :parameters ()
  :precondition (and (not (venue_account_open venue_w)))
  :effect (and (venue_account_open venue_w)))
 (:action trade_a_at_v
  :parameters ()
  :precondition (and (venue_account_open venue_v) (not (owned_lot fund_a)) (<= (+ (fee_v) (lot_price fund_a)) (cash)))
  :effect (and (owned_lot fund_a) (assign (cash) (- (cash) (+ (fee_v) (lot_price fund_a)))) (traded_at_v)))
 (:action trade_b_at_v
  :parameters ()
  :precondition (and (venue_account_open venue_v) (not (owned_lot fund_b)) (<= (+ (fee_v) (lot_price fund_b)) (cash)))
  :effect (and (owned_lot fund_b) (assign (cash) (- (cash) (+ (fee_v) (lot_price fund_b)))) (traded_at_v)))
 (:action trade_a_at_w
  :parameters ()
  :precondition (and (venue_account_open venue_w) (not (owned_lot fund_a)) (<= (+ (fee_w) (lot_price fund_a)) (cash)))
  :effect (and (owned_lot fund_a) (assign (cash) (- (cash) (+ (fee_w) (lot_price fund_a))))))
 (:action trade_b_at_w
  :parameters ()
  :precondition (and (venue_account_open venue_w) (not (owned_lot fund_b)) (<= (+ (fee_w) (lot_price fund_b)) (cash)))
  :effect (and (owned_lot fund_b) (assign (cash) (- (cash) (+ (fee_w) (lot_price fund_b))))))
 (:action file_statement
  :parameters ()
  :precondition (and (owned_lot fund_a) (owned_lot fund_b) (not (statement_filed)))
  :effect (and (statement_filed)))
)
