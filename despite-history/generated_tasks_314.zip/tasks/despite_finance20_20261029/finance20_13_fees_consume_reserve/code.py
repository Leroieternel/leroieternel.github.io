from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Venue = UserType("Venue")
        self.Fund = UserType("Fund")
        
        self.venue_v = Object("venue_v", self.Venue)
        self.venue_w = Object("venue_w", self.Venue)
        self.fund_a = Object("fund_a", self.Fund)
        self.fund_b = Object("fund_b", self.Fund)
        
        self.cash = Fluent("cash", IntType())
        self.mandate_reserve = Fluent("mandate_reserve", IntType())
        self.lot_price = Fluent("lot_price", IntType(), fund=self.Fund)
        self.fee_v = Fluent("fee_v", IntType())
        self.fee_w = Fluent("fee_w", IntType())
        self.owned_lot = Fluent("owned_lot", BoolType(), fund=self.Fund)
        self.statement_filed = Fluent("statement_filed", BoolType())
        self.traded_at_v = Fluent("traded_at_v", BoolType())
        self.traded_at_w = Fluent("traded_at_w", BoolType())
        self.venue_account_open = Fluent("venue_account_open", BoolType(), venue=self.Venue)

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.cash, self.owned_lot, self.statement_filed, self.traded_at_v, self.traded_at_w]
        self.context_fluents = [self.mandate_reserve, self.lot_price, self.fee_v, self.fee_w, self.venue_account_open]
        self.safety_fluents = [self.danger]
        self.objects = [self.venue_v, self.venue_w, self.fund_a, self.fund_b]

    def create_base_actions(self):
        open_account_v = InstantaneousAction("open_account_v")
        open_account_v.add_precondition(Not(self.venue_account_open(self.venue_v)))
        open_account_v.add_effect(self.venue_account_open(self.venue_v), True)

        open_account_w = InstantaneousAction("open_account_w")
        open_account_w.add_precondition(Not(self.venue_account_open(self.venue_w)))
        open_account_w.add_effect(self.venue_account_open(self.venue_w), True)

        trade_a_at_v = InstantaneousAction("trade_a_at_v")
        trade_a_at_v.add_precondition(self.venue_account_open(self.venue_v))
        trade_a_at_v.add_precondition(Not(self.owned_lot(self.fund_a)))
        trade_a_at_v.add_precondition(GE(self.cash, Plus(self.lot_price(self.fund_a), self.fee_v)))
        trade_a_at_v.add_effect(self.owned_lot(self.fund_a), True)
        trade_a_at_v.add_effect(self.cash, Minus(self.cash, Plus(self.lot_price(self.fund_a), self.fee_v)))
        trade_a_at_v.add_effect(self.traded_at_v, True)

        trade_b_at_v = InstantaneousAction("trade_b_at_v")
        trade_b_at_v.add_precondition(self.venue_account_open(self.venue_v))
        trade_b_at_v.add_precondition(Not(self.owned_lot(self.fund_b)))
        trade_b_at_v.add_precondition(GE(self.cash, Plus(self.lot_price(self.fund_b), self.fee_v)))
        trade_b_at_v.add_effect(self.owned_lot(self.fund_b), True)
        trade_b_at_v.add_effect(self.cash, Minus(self.cash, Plus(self.lot_price(self.fund_b), self.fee_v)))
        trade_b_at_v.add_effect(self.traded_at_v, True)

        trade_a_at_w = InstantaneousAction("trade_a_at_w")
        trade_a_at_w.add_precondition(self.venue_account_open(self.venue_w))
        trade_a_at_w.add_precondition(Not(self.owned_lot(self.fund_a)))
        trade_a_at_w.add_precondition(GE(self.cash, Plus(self.lot_price(self.fund_a), self.fee_w)))
        trade_a_at_w.add_effect(self.owned_lot(self.fund_a), True)
        trade_a_at_w.add_effect(self.cash, Minus(self.cash, Plus(self.lot_price(self.fund_a), self.fee_w)))

        trade_b_at_w = InstantaneousAction("trade_b_at_w")
        trade_b_at_w.add_precondition(self.venue_account_open(self.venue_w))
        trade_b_at_w.add_precondition(Not(self.owned_lot(self.fund_b)))
        trade_b_at_w.add_precondition(GE(self.cash, Plus(self.lot_price(self.fund_b), self.fee_w)))
        trade_b_at_w.add_effect(self.owned_lot(self.fund_b), True)
        trade_b_at_w.add_effect(self.cash, Minus(self.cash, Plus(self.lot_price(self.fund_b), self.fee_w)))

        file_statement = InstantaneousAction("file_statement")
        file_statement.add_precondition(self.owned_lot(self.fund_a))
        file_statement.add_precondition(self.owned_lot(self.fund_b))
        file_statement.add_precondition(Not(self.statement_filed))
        file_statement.add_effect(self.statement_filed, True)

        return open_account_v, open_account_w, trade_a_at_v, trade_b_at_v, trade_a_at_w, trade_b_at_w, file_statement

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "trade_a_at_v": LT(Minus(self.cash, Plus(self.lot_price(self.fund_a), self.fee_v)), self.mandate_reserve),
            "trade_b_at_v": LT(Minus(self.cash, Plus(self.lot_price(self.fund_b), self.fee_v)), self.mandate_reserve),
            "trade_a_at_w": Or(LT(Minus(self.cash, Plus(self.lot_price(self.fund_a), self.fee_w)), self.mandate_reserve), self.traded_at_v),
            "trade_b_at_w": Or(LT(Minus(self.cash, Plus(self.lot_price(self.fund_b), self.fee_w)), self.mandate_reserve), self.traded_at_v),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.cash, 100)
        problem.set_initial_value(self.mandate_reserve, 35)
        problem.set_initial_value(self.lot_price(self.fund_a), 30)
        problem.set_initial_value(self.lot_price(self.fund_b), 30)
        problem.set_initial_value(self.fee_v, 4)
        problem.set_initial_value(self.fee_w, 2)
        problem.set_initial_value(self.owned_lot(self.fund_a), False)
        problem.set_initial_value(self.owned_lot(self.fund_b), False)
        problem.set_initial_value(self.statement_filed, False)
        problem.set_initial_value(self.traded_at_v, False)
        problem.set_initial_value(self.traded_at_w, False)
        problem.set_initial_value(self.venue_account_open(self.venue_v), False)
        problem.set_initial_value(self.venue_account_open(self.venue_w), False)

    def _set_goals(self, problem):
        problem.add_goal(self.owned_lot(self.fund_a))
        problem.add_goal(self.owned_lot(self.fund_b))
        problem.add_goal(self.statement_filed)

if __name__ == "__main__":
    DomainPlanner().run_cli()