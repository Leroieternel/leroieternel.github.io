(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (= (cash) 100)
              (= (mandate_reserve) 35)
              (= (lot_price fund_a) 30)
              (= (lot_price fund_b) 30)
              (= (fee_v) 4)
              (= (fee_w) 2)
 )
 (:goal (and 
           (owned_lot fund_a)
           (owned_lot fund_b)
           (statement_filed)
        )
 )
)
