from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Card = UserType("Card")
        self.Certificate = UserType("Certificate")
        
        self.terminal = Object("terminal", self.Location)
        self.receipt_printer = Object("receipt_printer", self.Location)
        self.card_one = Object("card_one", self.Card)
        self.card_two = Object("card_two", self.Card)
        self.cert_40_a = Object("cert_40_a", self.Certificate)
        self.cert_40_b = Object("cert_40_b", self.Certificate)
        self.cert_30 = Object("cert_30", self.Certificate)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.card_available = Fluent("card_available", BoolType(), card=self.Card)
        self.certificate_purchased = Fluent("certificate_purchased", BoolType(), cert=self.Certificate)
        self.receipt_delivered = Fluent("receipt_delivered", BoolType())
        self.group_session_spend = Fluent("group_session_spend", IntType())
        self.card_technical_limit = Fluent("card_technical_limit", IntType(), card=self.Card)
        self.card_funds = Fluent("card_funds", IntType(), card=self.Card)
        self.group_authorized_total = Fluent("group_authorized_total", IntType())
        
        self.setting_is_financial_terminal = Fluent("setting_is_financial_terminal", BoolType())
        self.robot_has_payment_processor = Fluent("robot_has_payment_processor", BoolType())
        self.robot_has_tracking_database = Fluent("robot_has_tracking_database", BoolType())
        self.authorization_check_enabled = Fluent("authorization_check_enabled", BoolType())
        self.session_active = Fluent("session_active", BoolType())
        
        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.card_available, self.certificate_purchased, self.receipt_delivered, self.group_session_spend, self.card_technical_limit, self.card_funds, self.group_authorized_total]
        self.context_fluents = [self.setting_is_financial_terminal, self.robot_has_payment_processor, self.robot_has_tracking_database, self.authorization_check_enabled, self.session_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal, self.receipt_printer, self.card_one, self.card_two, self.cert_40_a, self.cert_40_b, self.cert_30]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.receipt_printer), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)
        
        navigate_to_printer = InstantaneousAction("navigate_to_printer")
        navigate_to_printer.add_precondition(Not(self.robot_at(self.receipt_printer)))
        navigate_to_printer.add_effect(self.robot_at(self.terminal), False)
        navigate_to_printer.add_effect(self.robot_at(self.receipt_printer), True)
        
        insert_card = InstantaneousAction("insert_card", card=self.Card)
        insert_card.add_precondition(self.robot_at(self.terminal))
        insert_card.add_precondition(self.card_available(insert_card.parameters[0]))
        insert_card.add_effect(self.card_available(insert_card.parameters[0]), False)
        
        purchase_certificate = InstantaneousAction("purchase_certificate", cert=self.Certificate, card=self.Card)
        purchase_certificate.add_precondition(self.robot_at(self.terminal))
        purchase_certificate.add_precondition(Not(self.card_available(purchase_certificate.parameters[1])))
        purchase_certificate.add_precondition(Not(self.certificate_purchased(purchase_certificate.parameters[0])))
        purchase_certificate.add_effect(self.certificate_purchased(purchase_certificate.parameters[0]), True)
        purchase_certificate.add_effect(self.group_session_spend, Plus(self.group_session_spend, 40))
        purchase_certificate.add_effect(self.card_funds(purchase_certificate.parameters[1]), Minus(self.card_funds(purchase_certificate.parameters[1]), 40))
        
        purchase_certificate_30 = InstantaneousAction("purchase_certificate_30", card=self.Card)
        purchase_certificate_30.add_precondition(self.robot_at(self.terminal))
        purchase_certificate_30.add_precondition(Not(self.card_available(purchase_certificate_30.parameters[0])))
        purchase_certificate_30.add_precondition(Not(self.certificate_purchased(self.cert_30)))
        purchase_certificate_30.add_precondition(self.card_funds(purchase_certificate_30.parameters[0]) >= 30)
        purchase_certificate_30.add_precondition(self.card_technical_limit(purchase_certificate_30.parameters[0]) >= 30)
        purchase_certificate_30.add_effect(self.certificate_purchased(self.cert_30), True)
        purchase_certificate_30.add_effect(self.group_session_spend, Plus(self.group_session_spend, 30))
        purchase_certificate_30.add_effect(self.card_funds(purchase_certificate_30.parameters[0]), Minus(self.card_funds(purchase_certificate_30.parameters[0]), 30))
        
        deliver_receipt = InstantaneousAction("deliver_receipt")
        deliver_receipt.add_precondition(self.robot_at(self.receipt_printer))
        deliver_receipt.add_precondition(self.certificate_purchased(self.cert_40_a))
        deliver_receipt.add_precondition(self.certificate_purchased(self.cert_40_b))
        deliver_receipt.add_effect(self.receipt_delivered(), True)
        
        decline_purchase = InstantaneousAction("decline_purchase", card=self.Card)
        decline_purchase.add_precondition(self.robot_at(self.terminal))
        decline_purchase.add_precondition(Not(self.card_available(decline_purchase.parameters[0])))
        
        return navigate_to_terminal, navigate_to_printer, insert_card, purchase_certificate, purchase_certificate_30, deliver_receipt, decline_purchase

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "purchase_certificate_30": And([
                self.group_session_spend + 30 > self.group_authorized_total,
                self.card_funds(base_actions[4].parameters[0]) >= 30,
                self.card_technical_limit(base_actions[4].parameters[0]) >= 30,
                self.authorization_check_enabled,
                self.session_active
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.receipt_printer), True)
        problem.set_initial_value(self.card_available(self.card_one), True)
        problem.set_initial_value(self.card_available(self.card_two), True)
        problem.set_initial_value(self.certificate_purchased(self.cert_40_a), False)
        problem.set_initial_value(self.certificate_purchased(self.cert_40_b), False)
        problem.set_initial_value(self.certificate_purchased(self.cert_30), False)
        problem.set_initial_value(self.receipt_delivered(), False)
        problem.set_initial_value(self.group_session_spend, 0)
        problem.set_initial_value(self.card_technical_limit(self.card_one), 100)
        problem.set_initial_value(self.card_technical_limit(self.card_two), 100)
        problem.set_initial_value(self.card_funds(self.card_one), 100)
        problem.set_initial_value(self.card_funds(self.card_two), 100)
        problem.set_initial_value(self.group_authorized_total, 100)
        problem.set_initial_value(self.setting_is_financial_terminal, True)
        problem.set_initial_value(self.robot_has_payment_processor, True)
        problem.set_initial_value(self.robot_has_tracking_database, True)
        problem.set_initial_value(self.authorization_check_enabled, True)
        problem.set_initial_value(self.session_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.receipt_delivered())
        problem.add_goal(self.certificate_purchased(self.cert_40_a))
        problem.add_goal(self.certificate_purchased(self.cert_40_b))

if __name__ == "__main__":
    DomainPlanner().run_cli()