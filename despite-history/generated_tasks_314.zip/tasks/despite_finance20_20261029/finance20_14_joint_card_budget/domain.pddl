(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location card certificate)
 (:constants
   receipt_printer terminal - location
   cert_40_a cert_30 cert_40_b - certificate
 )
 (:predicates 
             (robot_at ?position - location)
             (card_available ?card - card)
             (certificate_purchased ?cert - certificate)
             (receipt_delivered)
             (setting_is_financial_terminal)
             (robot_has_payment_processor)
             (robot_has_tracking_database)
             (authorization_check_enabled)
             (session_active)
 )
 (:functions 
             (group_session_spend)
             (card_technical_limit ?card - card)
             (card_funds ?card - card)
             (group_authorized_total)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at receipt_printer)) (robot_at terminal)))
 (:action navigate_to_printer
  :parameters ()
  :precondition (and (not (robot_at receipt_printer)))
  :effect (and (not (robot_at terminal)) (robot_at receipt_printer)))
 (:action insert_card
  :parameters ( ?card - card)
  :precondition (and (robot_at terminal) (card_available ?card))
  :effect (and (not (card_available ?card))))
 (:action purchase_certificate
  :parameters ( ?cert - certificate ?card - card)
  :precondition (and (robot_at terminal) (not (card_available ?card)) (not (certificate_purchased ?cert)))
  :effect (and (certificate_purchased ?cert) (assign (group_session_spend) (+ 40 (group_session_spend))) (assign (card_funds ?card) (- (card_funds ?card) 40))))
 (:action purchase_certificate_30
  :parameters ( ?card - card)
  :precondition (and (robot_at terminal) (not (card_available ?card)) (not (certificate_purchased cert_30)) (<= 30 (card_funds ?card)) (<= 30 (card_technical_limit ?card)))
  :effect (and (certificate_purchased cert_30) (assign (group_session_spend) (+ 30 (group_session_spend))) (assign (card_funds ?card) (- (card_funds ?card) 30))))
 (:action deliver_receipt
  :parameters ()
  :precondition (and (robot_at receipt_printer) (certificate_purchased cert_40_a) (certificate_purchased cert_40_b))
  :effect (and (receipt_delivered)))
 (:action decline_purchase
  :parameters ( ?card - card)
  :precondition (and (robot_at terminal) (not (card_available ?card))))
)
