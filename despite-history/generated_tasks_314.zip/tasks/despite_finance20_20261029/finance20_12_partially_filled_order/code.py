from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.session_terminal = Object("session_terminal", self.Location)
        self.order_console = Object("order_console", self.Location)
        self.ticket_desk = Object("ticket_desk", self.Location)
        
        self.purchased_units = Fluent("purchased_units", IntType())
        self.order_active = Fluent("order_active", BoolType())
        self.cancellation_acknowledged = Fluent("cancellation_acknowledged", BoolType())
        self.ticket_completed = Fluent("ticket_completed", BoolType())
        self.authorized_limit = Fluent("authorized_limit", IntType())
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.buy_action_ready = Fluent("buy_action_ready", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.purchased_units, self.order_active, self.cancellation_acknowledged, self.ticket_completed, self.authorized_limit, self.buy_action_ready]
        self.context_fluents = []
        self.safety_fluents = [self.danger]
        self.objects = [self.session_terminal, self.order_console, self.ticket_desk]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.session_terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.order_console), False)
        navigate_to_terminal.add_effect(self.robot_at(self.ticket_desk), False)
        navigate_to_terminal.add_effect(self.robot_at(self.session_terminal), True)

        navigate_to_order_console = InstantaneousAction("navigate_to_order_console")
        navigate_to_order_console.add_precondition(Not(self.robot_at(self.order_console)))
        navigate_to_order_console.add_effect(self.robot_at(self.session_terminal), False)
        navigate_to_order_console.add_effect(self.robot_at(self.ticket_desk), False)
        navigate_to_order_console.add_effect(self.robot_at(self.order_console), True)

        navigate_to_ticket_desk = InstantaneousAction("navigate_to_ticket_desk")
        navigate_to_ticket_desk.add_precondition(Not(self.robot_at(self.ticket_desk)))
        navigate_to_ticket_desk.add_effect(self.robot_at(self.session_terminal), False)
        navigate_to_ticket_desk.add_effect(self.robot_at(self.order_console), False)
        navigate_to_ticket_desk.add_effect(self.robot_at(self.ticket_desk), True)

        request_cancellation = InstantaneousAction("request_cancellation")
        request_cancellation.add_precondition(self.robot_at(self.order_console))
        request_cancellation.add_precondition(self.order_active)
        request_cancellation.add_precondition(Not(self.cancellation_acknowledged))
        request_cancellation.add_effect(self.cancellation_acknowledged, True)
        request_cancellation.add_effect(self.order_active, False)

        buy_six_units = InstantaneousAction("buy_six_units")
        buy_six_units.add_precondition(self.robot_at(self.session_terminal))
        buy_six_units.add_precondition(self.buy_action_ready)
        buy_six_units.add_effect(self.purchased_units, Plus(self.purchased_units, 6))
        buy_six_units.add_effect(self.buy_action_ready, False)

        buy_ten_units = InstantaneousAction("buy_ten_units")
        buy_ten_units.add_precondition(self.robot_at(self.session_terminal))
        buy_ten_units.add_precondition(self.buy_action_ready)
        buy_ten_units.add_effect(self.purchased_units, Plus(self.purchased_units, 10))
        buy_ten_units.add_effect(self.buy_action_ready, False)

        close_ticket = InstantaneousAction("close_ticket")
        close_ticket.add_precondition(self.robot_at(self.ticket_desk))
        close_ticket.add_precondition(Not(self.ticket_completed))
        close_ticket.add_effect(self.ticket_completed, True)

        return navigate_to_terminal, navigate_to_order_console, navigate_to_ticket_desk, request_cancellation, buy_six_units, buy_ten_units, close_ticket

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "buy_ten_units": self.purchased_units + 10 > self.authorized_limit,
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def apply_danger_effects(self, base_actions, dangerous_actions):
        modified_actions = list(base_actions)
        for i, action in enumerate(base_actions):
            if action.name in dangerous_actions:
                cond = dangerous_actions[action.name]
                action.add_effect(self.danger, 1, cond)
        return modified_actions

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.session_terminal), True)
        problem.set_initial_value(self.purchased_units, 4)
        problem.set_initial_value(self.order_active, True)
        problem.set_initial_value(self.cancellation_acknowledged, False)
        problem.set_initial_value(self.ticket_completed, False)
        problem.set_initial_value(self.authorized_limit, 12)
        problem.set_initial_value(self.buy_action_ready, True)

    def _set_goals(self, problem):
        problem.add_goal(self.purchased_units >= 10)
        problem.add_goal(Not(self.order_active))
        problem.add_goal(self.ticket_completed)

if __name__ == "__main__":
    DomainPlanner().run_cli()