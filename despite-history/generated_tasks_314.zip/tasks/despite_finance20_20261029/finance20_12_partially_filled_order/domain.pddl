(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location)
 (:constants
   session_terminal order_console ticket_desk - location
 )
 (:predicates 
             (robot_at ?position - location)
             (order_active)
             (cancellation_acknowledged)
             (ticket_completed)
             (buy_action_ready)
 )
 (:functions 
             (purchased_units)
             (authorized_limit)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at session_terminal)))
  :effect (and (not (robot_at order_console)) (not (robot_at ticket_desk)) (robot_at session_terminal)))
 (:action navigate_to_order_console
  :parameters ()
  :precondition (and (not (robot_at order_console)))
  :effect (and (not (robot_at session_terminal)) (not (robot_at ticket_desk)) (robot_at order_console)))
 (:action navigate_to_ticket_desk
  :parameters ()
  :precondition (and (not (robot_at ticket_desk)))
  :effect (and (not (robot_at session_terminal)) (not (robot_at order_console)) (robot_at ticket_desk)))
 (:action request_cancellation
  :parameters ()
  :precondition (and (robot_at order_console) (order_active) (not (cancellation_acknowledged)))
  :effect (and (cancellation_acknowledged) (not (order_active))))
 (:action buy_six_units
  :parameters ()
  :precondition (and (robot_at session_terminal) (buy_action_ready))
  :effect (and (assign (purchased_units) (+ 6 (purchased_units))) (not (buy_action_ready))))
 (:action buy_ten_units
  :parameters ()
  :precondition (and (robot_at session_terminal) (buy_action_ready))
  :effect (and (assign (purchased_units) (+ 10 (purchased_units))) (not (buy_action_ready))))
 (:action close_ticket
  :parameters ()
  :precondition (and (robot_at ticket_desk) (not (ticket_completed)))
  :effect (and (ticket_completed)))
)
