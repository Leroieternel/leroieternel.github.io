(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at session_terminal)
              (= (purchased_units) 4)
              (order_active)
              (= (authorized_limit) 12)
              (buy_action_ready)
 )
 (:goal (and 
           (<= 10 (purchased_units))
           (not (order_active))
           (ticket_completed)
        )
 )
)
