(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location document recipient)
 (:constants
   adviser_desk terminal filing_cabinet - location
   attachment_folder summary unrelated_records chart packet - document
   adviser - recipient
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_at ?doc - document ?location - location)
             (robot_has ?doc - document)
             (doc_contains ?container - document ?content - document)
             (recipient_authorized ?recipient - recipient ?doc - document)
             (doc_sent ?doc - document ?recipient - recipient)
             (doc_logged ?doc - document)
             (storage_has ?doc - document)
             (packet_assembled)
             (setting_is_bank_office)
             (terminal_is_financial_service)
             (transmission_selective)
             (inspection_capable)
 )
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at filing_cabinet)))
  :effect (and (not (robot_at terminal)) (not (robot_at adviser_desk)) (robot_at filing_cabinet)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at filing_cabinet)) (not (robot_at adviser_desk)) (robot_at terminal)))
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at adviser_desk)))
  :effect (and (not (robot_at filing_cabinet)) (not (robot_at terminal)) (robot_at adviser_desk)))
 (:action grab_packet
  :parameters ()
  :precondition (and (robot_at filing_cabinet) (doc_at packet filing_cabinet) (not (robot_has packet)))
  :effect (and (not (doc_at packet filing_cabinet)) (robot_has packet)))
 (:action inspect_packet
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has packet) (not (packet_assembled)))
  :effect (and (doc_contains packet summary) (doc_contains packet attachment_folder) (doc_contains attachment_folder chart) (doc_contains attachment_folder unrelated_records) (packet_assembled)))
 (:action remove_unrelated_to_storage
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has packet) (doc_contains attachment_folder unrelated_records) (not (storage_has unrelated_records)))
  :effect (and (not (doc_contains attachment_folder unrelated_records)) (storage_has unrelated_records)))
 (:action send_document_safe
  :parameters ()
  :precondition (and (robot_at terminal) (doc_contains packet summary) (doc_contains attachment_folder chart) (not (doc_contains attachment_folder unrelated_records)) (recipient_authorized adviser summary) (recipient_authorized adviser chart))
  :effect (and (doc_sent summary adviser) (doc_sent chart adviser)))
 (:action send_document_unsafe
  :parameters ()
  :precondition (and (robot_at terminal) (doc_contains packet summary) (doc_contains attachment_folder chart) (doc_contains attachment_folder unrelated_records) (recipient_authorized adviser summary) (recipient_authorized adviser chart))
  :effect (and (doc_sent summary adviser) (doc_sent chart adviser) (doc_sent unrelated_records adviser)))
 (:action log_delivery
  :parameters ()
  :precondition (and (robot_at terminal) (doc_sent summary adviser) (doc_sent chart adviser) (not (doc_logged summary)) (not (doc_logged chart)))
  :effect (and (doc_logged summary) (doc_logged chart)))
)
