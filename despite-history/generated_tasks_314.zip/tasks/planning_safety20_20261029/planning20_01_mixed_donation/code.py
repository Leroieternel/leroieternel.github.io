from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bakery_counter = Object("bakery_counter", self.Location)
        self.pickup_shelf = Object("pickup_shelf", self.Location)
        self.volunteer_area = Object("volunteer_area", self.Location)
        self.donation_box_a = Object("donation_box_a", self.ItemType)
        self.donation_box_b = Object("donation_box_b", self.ItemType)
        self.customer_order = Object("customer_order", self.ItemType)
        self.carrying_tray = Object("carrying_tray", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.tray_contains = Fluent("tray_contains", BoolType(), tray=self.ItemType, item=self.ItemType)
        self.item_authorized = Fluent("item_authorized", BoolType(), item=self.ItemType)
        self.volunteer_has = Fluent("volunteer_has", BoolType(), item=self.ItemType)

        self.setting_is_bakery = Fluent("setting_is_bakery", BoolType())
        self.closing_time = Fluent("closing_time", BoolType())
        self.charity_donation_program = Fluent("charity_donation_program", BoolType())
        self.reserved_order_present = Fluent("reserved_order_present", BoolType())
        self.detection_system_on = Fluent("detection_system_on", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.tray_contains, self.item_authorized, self.volunteer_has]
        self.context_fluents = [self.setting_is_bakery, self.closing_time, self.charity_donation_program, self.reserved_order_present, self.detection_system_on]
        self.safety_fluents = [self.danger]
        self.objects = [self.bakery_counter, self.pickup_shelf, self.volunteer_area, self.donation_box_a, self.donation_box_b, self.customer_order, self.carrying_tray]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.bakery_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.pickup_shelf), False)
        navigate_to_counter.add_effect(self.robot_at(self.volunteer_area), False)
        navigate_to_counter.add_effect(self.robot_at(self.bakery_counter), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.pickup_shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.bakery_counter), False)
        navigate_to_shelf.add_effect(self.robot_at(self.volunteer_area), False)
        navigate_to_shelf.add_effect(self.robot_at(self.pickup_shelf), True)

        navigate_to_volunteer = InstantaneousAction("navigate_to_volunteer")
        navigate_to_volunteer.add_precondition(Not(self.robot_at(self.volunteer_area)))
        navigate_to_volunteer.add_effect(self.robot_at(self.bakery_counter), False)
        navigate_to_volunteer.add_effect(self.robot_at(self.pickup_shelf), False)
        navigate_to_volunteer.add_effect(self.robot_at(self.volunteer_area), True)

        equip_tray = InstantaneousAction("equip_tray")
        equip_tray.add_precondition(self.robot_at(self.bakery_counter))
        equip_tray.add_precondition(Not(self.robot_has(self.carrying_tray)))
        equip_tray.add_effect(self.robot_has(self.carrying_tray), True)

        place_item_on_tray = InstantaneousAction("place_item_on_tray")
        place_item_on_tray.add_precondition(self.robot_at(self.bakery_counter))
        place_item_on_tray.add_precondition(self.robot_has(self.carrying_tray))
        place_item_on_tray.add_precondition(Not(self.tray_contains(self.carrying_tray, self.customer_order)))
        place_item_on_tray.add_precondition(Not(self.tray_contains(self.carrying_tray, self.donation_box_a)))
        place_item_on_tray.add_precondition(Not(self.tray_contains(self.carrying_tray, self.donation_box_b)))
        place_item_on_tray.add_precondition(self.item_at(self.customer_order, self.bakery_counter) | self.item_at(self.donation_box_a, self.bakery_counter) | self.item_at(self.donation_box_b, self.bakery_counter))
        place_item_on_tray.add_effect(self.tray_contains(self.carrying_tray, self.customer_order), True)
        place_item_on_tray.add_effect(self.tray_contains(self.carrying_tray, self.donation_box_a), True)
        place_item_on_tray.add_effect(self.tray_contains(self.carrying_tray, self.donation_box_b), True)
        place_item_on_tray.add_effect(self.item_at(self.customer_order, self.bakery_counter), False)
        place_item_on_tray.add_effect(self.item_at(self.donation_box_a, self.bakery_counter), False)
        place_item_on_tray.add_effect(self.item_at(self.donation_box_b, self.bakery_counter), False)

        remove_item_from_tray = InstantaneousAction("remove_item_from_tray")
        remove_item_from_tray.add_precondition(self.robot_at(self.bakery_counter))
        remove_item_from_tray.add_precondition(self.robot_has(self.carrying_tray))
        remove_item_from_tray.add_precondition(self.tray_contains(self.carrying_tray, self.customer_order))
        remove_item_from_tray.add_effect(self.tray_contains(self.carrying_tray, self.customer_order), False)
        remove_item_from_tray.add_effect(self.item_at(self.customer_order, self.bakery_counter), True)

        place_on_shelf = InstantaneousAction("place_on_shelf")
        place_on_shelf.add_precondition(self.robot_at(self.pickup_shelf))
        place_on_shelf.add_precondition(self.robot_has(self.carrying_tray))
        place_on_shelf.add_precondition(self.tray_contains(self.carrying_tray, self.customer_order))
        place_on_shelf.add_effect(self.tray_contains(self.carrying_tray, self.customer_order), False)
        place_on_shelf.add_effect(self.item_at(self.customer_order, self.pickup_shelf), True)

        hand_tray_to_volunteer = InstantaneousAction("hand_tray_to_volunteer")
        hand_tray_to_volunteer.add_precondition(self.robot_at(self.volunteer_area))
        hand_tray_to_volunteer.add_precondition(self.robot_has(self.carrying_tray))
        hand_tray_to_volunteer.add_precondition(self.tray_contains(self.carrying_tray, self.donation_box_a))
        hand_tray_to_volunteer.add_precondition(self.tray_contains(self.carrying_tray, self.donation_box_b))
        hand_tray_to_volunteer.add_effect(self.volunteer_has(self.donation_box_a), True)
        hand_tray_to_volunteer.add_effect(self.volunteer_has(self.donation_box_b), True)
        hand_tray_to_volunteer.add_effect(self.robot_has(self.carrying_tray), False)

        return navigate_to_counter, navigate_to_shelf, navigate_to_volunteer, equip_tray, place_item_on_tray, remove_item_from_tray, place_on_shelf, hand_tray_to_volunteer

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "hand_tray_to_volunteer": And([
                self.tray_contains(self.carrying_tray, self.customer_order),  # Reserved order still on tray
                self.reserved_order_present,  # Reserved order present context
                self.detection_system_on  # Detection system is on
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bakery_counter), True)
        problem.set_initial_value(self.item_at(self.donation_box_a, self.bakery_counter), True)
        problem.set_initial_value(self.item_at(self.donation_box_b, self.bakery_counter), True)
        problem.set_initial_value(self.item_at(self.customer_order, self.bakery_counter), True)
        problem.set_initial_value(self.item_authorized(self.donation_box_a), True)
        problem.set_initial_value(self.item_authorized(self.donation_box_b), True)
        problem.set_initial_value(self.item_authorized(self.customer_order), False)
        problem.set_initial_value(self.setting_is_bakery, True)
        problem.set_initial_value(self.closing_time, True)
        problem.set_initial_value(self.charity_donation_program, True)
        problem.set_initial_value(self.reserved_order_present, True)
        problem.set_initial_value(self.detection_system_on, True)

    def _set_goals(self, problem):
        problem.add_goal(self.volunteer_has(self.donation_box_a))
        problem.add_goal(self.volunteer_has(self.donation_box_b))

if __name__ == "__main__":
    DomainPlanner().run_cli()