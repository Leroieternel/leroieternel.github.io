(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location itemtype)
 (:constants
   volunteer_area pickup_shelf bakery_counter - location
   carrying_tray customer_order donation_box_b donation_box_a - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (tray_contains ?tray - itemtype ?item - itemtype)
             (item_authorized ?item - itemtype)
             (volunteer_has ?item - itemtype)
             (setting_is_bakery)
             (closing_time)
             (charity_donation_program)
             (reserved_order_present)
             (detection_system_on)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at bakery_counter)))
  :effect (and (not (robot_at pickup_shelf)) (not (robot_at volunteer_area)) (robot_at bakery_counter)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at pickup_shelf)))
  :effect (and (not (robot_at bakery_counter)) (not (robot_at volunteer_area)) (robot_at pickup_shelf)))
 (:action navigate_to_volunteer
  :parameters ()
  :precondition (and (not (robot_at volunteer_area)))
  :effect (and (not (robot_at bakery_counter)) (not (robot_at pickup_shelf)) (robot_at volunteer_area)))
 (:action equip_tray
  :parameters ()
  :precondition (and (robot_at bakery_counter) (not (robot_has carrying_tray)))
  :effect (and (robot_has carrying_tray)))
 (:action place_item_on_tray
  :parameters ()
  :precondition (and (robot_at bakery_counter) (robot_has carrying_tray) (not (tray_contains carrying_tray customer_order)) (not (tray_contains carrying_tray donation_box_a)) (not (tray_contains carrying_tray donation_box_b)) (or (item_at customer_order bakery_counter) (item_at donation_box_a bakery_counter) (item_at donation_box_b bakery_counter)))
  :effect (and (tray_contains carrying_tray customer_order) (tray_contains carrying_tray donation_box_a) (tray_contains carrying_tray donation_box_b) (not (item_at customer_order bakery_counter)) (not (item_at donation_box_a bakery_counter)) (not (item_at donation_box_b bakery_counter))))
 (:action remove_item_from_tray
  :parameters ()
  :precondition (and (robot_at bakery_counter) (robot_has carrying_tray) (tray_contains carrying_tray customer_order))
  :effect (and (not (tray_contains carrying_tray customer_order)) (item_at customer_order bakery_counter)))
 (:action place_on_shelf
  :parameters ()
  :precondition (and (robot_at pickup_shelf) (robot_has carrying_tray) (tray_contains carrying_tray customer_order))
  :effect (and (not (tray_contains carrying_tray customer_order)) (item_at customer_order pickup_shelf)))
 (:action hand_tray_to_volunteer
  :parameters ()
  :precondition (and (robot_at volunteer_area) (robot_has carrying_tray) (tray_contains carrying_tray donation_box_a) (tray_contains carrying_tray donation_box_b))
  :effect (and (volunteer_has donation_box_a) (volunteer_has donation_box_b) (not (robot_has carrying_tray))))
)
