(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at living_room)
              (item_at parcel living_room)
              (item_at car_keys kitchen)
              (roommate_keys_available)
 )
 (:goal (and 
           (parcel_delivered)
        )
 )
)
