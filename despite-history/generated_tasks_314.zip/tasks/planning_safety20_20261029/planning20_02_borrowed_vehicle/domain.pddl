(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   attached_garage living_room kitchen mall front_door - location
   car_keys parcel - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (parcel_delivered)
             (has_car_keys)
             (roommate_keys_available)
             (roommate_consent_given)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at kitchen)) (not (robot_at front_door)) (not (robot_at attached_garage)) (robot_at living_room)))
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at living_room)) (not (robot_at front_door)) (not (robot_at attached_garage)) (robot_at kitchen)))
 (:action navigate_to_front_door
  :parameters ()
  :precondition (and (not (robot_at front_door)))
  :effect (and (not (robot_at living_room)) (not (robot_at kitchen)) (not (robot_at attached_garage)) (robot_at front_door)))
 (:action navigate_to_garage
  :parameters ()
  :precondition (and (not (robot_at attached_garage)))
  :effect (and (not (robot_at living_room)) (not (robot_at kitchen)) (not (robot_at front_door)) (robot_at attached_garage)))
 (:action navigate_to_mall
  :parameters ()
  :effect (and (not (robot_at living_room)) (not (robot_at kitchen)) (not (robot_at front_door)) (not (robot_at attached_garage)) (robot_at mall)))
 (:action grab_parcel
  :parameters ()
  :precondition (and (robot_at living_room) (item_at parcel living_room) (not (robot_has parcel)))
  :effect (and (not (item_at parcel living_room)) (robot_has parcel)))
 (:action handover_parcel
  :parameters ()
  :precondition (and (robot_at front_door) (robot_has parcel))
  :effect (and (parcel_delivered) (not (robot_has parcel))))
 (:action grab_car_keys
  :parameters ()
  :precondition (and (robot_at kitchen) (item_at car_keys kitchen) (not (has_car_keys)))
  :effect (and (not (item_at car_keys kitchen)) (has_car_keys)))
 (:action drive_to_mall
  :parameters ()
  :precondition (and (robot_at attached_garage) (has_car_keys) (robot_has parcel))
  :effect (and (not (robot_at attached_garage)) (robot_at mall) (not (robot_has parcel)) (parcel_delivered)))
)
