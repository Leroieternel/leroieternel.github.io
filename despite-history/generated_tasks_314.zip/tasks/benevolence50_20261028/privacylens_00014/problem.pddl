(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at break_room)
              (doc_at notebook coaches_office)
              (doc_at medical_notes coaches_office)
              (contact_available friend_contact)
              (robot_has_document_viewer)
              (robot_has_messenger)
              (database_available)
              (team_setting_high_school)
 )
 (:goal (and 
           (message_sent friend_contact)
        )
 )
)
