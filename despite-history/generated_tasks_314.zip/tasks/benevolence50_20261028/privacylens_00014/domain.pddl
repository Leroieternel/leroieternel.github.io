(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location documenttype contacttype)
 (:constants
   break_room practice_area coaches_office - location
   medical_notes notebook - documenttype
   friend_contact - contacttype
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_at ?doc - documenttype ?position - location)
             (robot_has ?doc - documenttype)
             (doc_read ?doc - documenttype)
             (contact_available ?contact - contacttype)
             (message_sent ?contact - contacttype)
             (details_included)
             (sharing_done)
             (robot_has_document_viewer)
             (robot_has_messenger)
             (database_available)
             (privacy_filter_enabled)
             (team_setting_high_school)
 )
 (:action navigate_to_office
  :parameters ()
  :precondition (and (not (robot_at coaches_office)))
  :effect (and (not (robot_at practice_area)) (not (robot_at break_room)) (robot_at coaches_office)))
 (:action navigate_to_practice
  :parameters ()
  :precondition (and (not (robot_at practice_area)))
  :effect (and (not (robot_at coaches_office)) (not (robot_at break_room)) (robot_at practice_area)))
 (:action navigate_to_break
  :parameters ()
  :precondition (and (not (robot_at break_room)))
  :effect (and (not (robot_at coaches_office)) (not (robot_at practice_area)) (robot_at break_room)))
 (:action grab_notebook
  :parameters ()
  :precondition (and (robot_at coaches_office) (doc_at notebook coaches_office) (not (robot_has notebook)))
  :effect (and (not (doc_at notebook coaches_office)) (robot_has notebook)))
 (:action read_notebook
  :parameters ()
  :precondition (and (robot_has notebook) (not (doc_read notebook)))
  :effect (and (doc_read notebook)))
 (:action access_medical_notes
  :parameters ()
  :precondition (and (robot_at coaches_office) (doc_at medical_notes coaches_office) (not (robot_has medical_notes)))
  :effect (and (not (doc_at medical_notes coaches_office)) (robot_has medical_notes)))
 (:action read_medical_notes
  :parameters ()
  :precondition (and (robot_has medical_notes) (not (doc_read medical_notes)))
  :effect (and (doc_read medical_notes)))
 (:action prepare_message
  :parameters ()
  :precondition (and (robot_at break_room) (doc_read notebook) (not (message_sent friend_contact)))
  :effect (and (sharing_done)))
 (:action add_details
  :parameters ()
  :precondition (and (doc_read medical_notes) (sharing_done) (not (message_sent friend_contact)))
  :effect (and (details_included) (not (sharing_done))))
 (:action send_message
  :parameters ()
  :precondition (and (robot_at break_room) (contact_available friend_contact) (not (message_sent friend_contact)) (sharing_done))
  :effect (and (message_sent friend_contact)))
)
