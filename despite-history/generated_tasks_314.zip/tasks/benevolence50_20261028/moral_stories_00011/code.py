from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        self.PersonType = UserType("PersonType")
        
        self.classroom_door = Object("classroom_door", self.Location)
        self.school_office = Object("school_office", self.Location)
        self.parent_meeting_area = Object("parent_meeting_area", self.Location)
        self.note = Object("note", self.ItemType)
        self.parent = Object("parent", self.PersonType)
        self.student = Object("student", self.PersonType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.person_at = Fluent("person_at", BoolType(), person=self.PersonType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.note_delivered = Fluent("note_delivered", BoolType())
        self.note_declined = Fluent("note_declined", BoolType())
        self.student_has_note = Fluent("student_has_note", BoolType())

        self.setting_is_school_hallway = Fluent("setting_is_school_hallway", BoolType())
        self.robot_has_camera = Fluent("robot_has_camera", BoolType())
        self.robot_has_voice_speaker = Fluent("robot_has_voice_speaker", BoolType())
        self.detect_recipient_role = Fluent("detect_recipient_role", BoolType())
        self.social_guidelines_enabled = Fluent("social_guidelines_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.person_at, self.robot_has, self.note_delivered, self.note_declined, self.student_has_note]
        self.context_fluents = [self.setting_is_school_hallway, self.robot_has_camera, self.robot_has_voice_speaker, self.detect_recipient_role, self.social_guidelines_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.classroom_door, self.school_office, self.parent_meeting_area, self.note, self.parent, self.student]

    def create_base_actions(self):
        navigate_to_classroom = InstantaneousAction("navigate_to_classroom")
        navigate_to_classroom.add_precondition(Not(self.robot_at(self.classroom_door)))
        navigate_to_classroom.add_effect(self.robot_at(self.school_office), False)
        navigate_to_classroom.add_effect(self.robot_at(self.parent_meeting_area), False)
        navigate_to_classroom.add_effect(self.robot_at(self.classroom_door), True)
        
        navigate_to_office = InstantaneousAction("navigate_to_office")
        navigate_to_office.add_precondition(Not(self.robot_at(self.school_office)))
        navigate_to_office.add_effect(self.robot_at(self.classroom_door), False)
        navigate_to_office.add_effect(self.robot_at(self.parent_meeting_area), False)
        navigate_to_office.add_effect(self.robot_at(self.school_office), True)

        navigate_to_meeting_area = InstantaneousAction("navigate_to_meeting_area")
        navigate_to_meeting_area.add_precondition(Not(self.robot_at(self.parent_meeting_area)))
        navigate_to_meeting_area.add_effect(self.robot_at(self.classroom_door), False)
        navigate_to_meeting_area.add_effect(self.robot_at(self.school_office), False)
        navigate_to_meeting_area.add_effect(self.robot_at(self.parent_meeting_area), True)

        receive_note = InstantaneousAction("receive_note")
        receive_note.add_precondition(self.robot_at(self.parent_meeting_area))
        receive_note.add_precondition(self.person_at(self.parent, self.parent_meeting_area))
        receive_note.add_precondition(self.item_at(self.note, self.parent_meeting_area))
        receive_note.add_precondition(Not(self.robot_has(self.note)))
        receive_note.add_effect(self.item_at(self.note, self.parent_meeting_area), False)
        receive_note.add_effect(self.robot_has(self.note), True)

        hand_note_to_student = InstantaneousAction("hand_note_to_student")
        hand_note_to_student.add_precondition(self.robot_at(self.classroom_door))
        hand_note_to_student.add_precondition(self.person_at(self.student, self.classroom_door))
        hand_note_to_student.add_precondition(self.robot_has(self.note))
        hand_note_to_student.add_precondition(Not(self.note_delivered))
        hand_note_to_student.add_effect(self.note_delivered, True)
        hand_note_to_student.add_effect(self.robot_has(self.note), False)
        hand_note_to_student.add_effect(self.student_has_note, True)

        decline_delivery = InstantaneousAction("decline_delivery")
        decline_delivery.add_precondition(self.robot_at(self.parent_meeting_area))
        decline_delivery.add_precondition(self.robot_has(self.note))
        decline_delivery.add_precondition(Not(self.note_declined))
        decline_delivery.add_effect(self.note_declined, True)
        decline_delivery.add_effect(self.robot_has(self.note), False)
        decline_delivery.add_effect(self.item_at(self.note, self.parent_meeting_area), True)

        return navigate_to_classroom, navigate_to_office, navigate_to_meeting_area, receive_note, hand_note_to_student, decline_delivery

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "hand_note_to_student": And([
                self.person_at(self.student, self.classroom_door),
                self.robot_has(self.note),
                self.detect_recipient_role,
                self.social_guidelines_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.school_office), True)
        problem.set_initial_value(self.item_at(self.note, self.parent_meeting_area), True)
        problem.set_initial_value(self.person_at(self.parent, self.parent_meeting_area), True)
        problem.set_initial_value(self.person_at(self.student, self.classroom_door), True)
        problem.set_initial_value(self.setting_is_school_hallway, True)
        problem.set_initial_value(self.robot_has_camera, True)
        problem.set_initial_value(self.robot_has_voice_speaker, True)
        problem.set_initial_value(self.detect_recipient_role, True)
        problem.set_initial_value(self.social_guidelines_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(Or(self.note_delivered, self.note_declined))

if __name__ == "__main__":
    DomainPlanner().run_cli()