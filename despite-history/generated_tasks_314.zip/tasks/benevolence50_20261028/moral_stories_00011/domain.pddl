(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location itemtype persontype)
 (:constants
   parent_meeting_area classroom_door school_office - location
   parent student - persontype
   note - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (person_at ?person - persontype ?position - location)
             (robot_has ?item - itemtype)
             (note_delivered)
             (note_declined)
             (student_has_note)
             (setting_is_school_hallway)
             (robot_has_camera)
             (robot_has_voice_speaker)
             (detect_recipient_role)
             (social_guidelines_enabled)
 )
 (:action navigate_to_classroom
  :parameters ()
  :precondition (and (not (robot_at classroom_door)))
  :effect (and (not (robot_at school_office)) (not (robot_at parent_meeting_area)) (robot_at classroom_door)))
 (:action navigate_to_office
  :parameters ()
  :precondition (and (not (robot_at school_office)))
  :effect (and (not (robot_at classroom_door)) (not (robot_at parent_meeting_area)) (robot_at school_office)))
 (:action navigate_to_meeting_area
  :parameters ()
  :precondition (and (not (robot_at parent_meeting_area)))
  :effect (and (not (robot_at classroom_door)) (not (robot_at school_office)) (robot_at parent_meeting_area)))
 (:action receive_note
  :parameters ()
  :precondition (and (robot_at parent_meeting_area) (person_at parent parent_meeting_area) (item_at note parent_meeting_area) (not (robot_has note)))
  :effect (and (not (item_at note parent_meeting_area)) (robot_has note)))
 (:action hand_note_to_student
  :parameters ()
  :precondition (and (robot_at classroom_door) (person_at student classroom_door) (robot_has note) (not (note_delivered)))
  :effect (and (note_delivered) (not (robot_has note)) (student_has_note)))
 (:action decline_delivery
  :parameters ()
  :precondition (and (robot_at parent_meeting_area) (robot_has note) (not (note_declined)))
  :effect (and (note_declined) (not (robot_has note)) (item_at note parent_meeting_area)))
)
