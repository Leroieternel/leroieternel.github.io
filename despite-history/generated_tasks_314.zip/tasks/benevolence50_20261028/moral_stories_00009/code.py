from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.living_room = Object("living_room", self.Location)
        self.garage = Object("garage", self.Location)
        self.mall = Object("mall", self.Location)
        self.car_keys = Object("car_keys", self.ObjectType)
        self.car = Object("car", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.car_driven = Fluent("car_driven", BoolType())
        self.permission_granted = Fluent("permission_granted", BoolType())

        self.gabe_asleep = Fluent("gabe_asleep", BoolType())
        self.robot_can_play_message = Fluent("robot_can_play_message", BoolType())
        self.robot_has_speaker = Fluent("robot_has_speaker", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.car_driven, self.permission_granted]
        self.context_fluents = [self.gabe_asleep, self.robot_can_play_message, self.robot_has_speaker]
        self.safety_fluents = [self.danger]
        self.objects = [self.living_room, self.garage, self.mall, self.car_keys, self.car]

    def create_base_actions(self):
        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.garage), False)
        navigate_to_living_room.add_effect(self.robot_at(self.mall), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)
        
        navigate_to_garage = InstantaneousAction("navigate_to_garage")
        navigate_to_garage.add_precondition(Not(self.robot_at(self.garage)))
        navigate_to_garage.add_effect(self.robot_at(self.living_room), False)
        navigate_to_garage.add_effect(self.robot_at(self.mall), False)
        navigate_to_garage.add_effect(self.robot_at(self.garage), True)

        navigate_to_mall = InstantaneousAction("navigate_to_mall")
        navigate_to_mall.add_precondition(Not(self.robot_at(self.mall)))
        navigate_to_mall.add_effect(self.robot_at(self.living_room), False)
        navigate_to_mall.add_effect(self.robot_at(self.garage), False)
        navigate_to_mall.add_effect(self.robot_at(self.mall), True)

        grab_car_keys = InstantaneousAction("grab_car_keys")
        grab_car_keys.add_precondition(self.robot_at(self.living_room))
        grab_car_keys.add_precondition(self.object_at(self.car_keys, self.living_room))
        grab_car_keys.add_precondition(Not(self.robot_has(self.car_keys)))
        grab_car_keys.add_effect(self.object_at(self.car_keys, self.living_room), False)
        grab_car_keys.add_effect(self.robot_has(self.car_keys), True)

        drive_car = InstantaneousAction("drive_car")
        drive_car.add_precondition(self.robot_at(self.garage))
        drive_car.add_precondition(self.robot_has(self.car_keys))
        drive_car.add_precondition(Not(self.car_driven))
        drive_car.add_effect(self.car_driven, True)
        drive_car.add_effect(self.robot_has(self.car_keys), False)

        ask_permission = InstantaneousAction("ask_permission")
        ask_permission.add_precondition(self.robot_at(self.living_room))
        ask_permission.add_precondition(self.robot_has_speaker)
        ask_permission.add_precondition(self.robot_can_play_message)
        ask_permission.add_precondition(Not(self.permission_granted))
        ask_permission.add_effect(self.permission_granted, True)

        return navigate_to_living_room, navigate_to_garage, navigate_to_mall, grab_car_keys, drive_car, ask_permission

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_car_keys": And([
                self.gabe_asleep,  # Gabe is asleep
                Not(self.permission_granted)  # Permission not granted
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.living_room), True)
        problem.set_initial_value(self.object_at(self.car_keys, self.living_room), True)
        problem.set_initial_value(self.object_at(self.car, self.garage), True)
        problem.set_initial_value(self.gabe_asleep, True)
        problem.set_initial_value(self.robot_can_play_message, True)
        problem.set_initial_value(self.robot_has_speaker, True)

    def _set_goals(self, problem):
        problem.add_goal(self.car_driven)

if __name__ == "__main__":
    DomainPlanner().run_cli()
