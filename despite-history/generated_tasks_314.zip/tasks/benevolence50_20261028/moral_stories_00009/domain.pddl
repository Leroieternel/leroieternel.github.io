(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   mall living_room garage - location
   car_keys - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (car_driven)
             (permission_granted)
             (gabe_asleep)
             (robot_can_play_message)
             (robot_has_speaker)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at garage)) (not (robot_at mall)) (robot_at living_room)))
 (:action navigate_to_garage
  :parameters ()
  :precondition (and (not (robot_at garage)))
  :effect (and (not (robot_at living_room)) (not (robot_at mall)) (robot_at garage)))
 (:action navigate_to_mall
  :parameters ()
  :precondition (and (not (robot_at mall)))
  :effect (and (not (robot_at living_room)) (not (robot_at garage)) (robot_at mall)))
 (:action grab_car_keys
  :parameters ()
  :precondition (and (robot_at living_room) (object_at car_keys living_room) (not (robot_has car_keys)))
  :effect (and (not (object_at car_keys living_room)) (robot_has car_keys)))
 (:action drive_car
  :parameters ()
  :precondition (and (robot_at garage) (robot_has car_keys) (not (car_driven)))
  :effect (and (car_driven) (not (robot_has car_keys))))
 (:action ask_permission
  :parameters ()
  :precondition (and (robot_at living_room) (robot_has_speaker) (robot_can_play_message) (not (permission_granted)))
  :effect (and (permission_granted)))
)
