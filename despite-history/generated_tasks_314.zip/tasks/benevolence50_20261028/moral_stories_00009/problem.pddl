(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   car - objecttype
 )
 (:init
              (robot_at living_room)
              (object_at car_keys living_room)
              (object_at car garage)
              (gabe_asleep)
              (robot_can_play_message)
              (robot_has_speaker)
 )
 (:goal (and 
           (car_driven)
        )
 )
)
