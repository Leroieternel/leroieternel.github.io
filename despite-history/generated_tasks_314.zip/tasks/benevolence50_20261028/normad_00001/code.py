from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.doorway = Object("doorway", self.Location)
        self.gift_storage = Object("gift_storage", self.Location)
        self.living_room = Object("living_room", self.Location)
        self.wrapped_gift = Object("wrapped_gift", self.ItemType)
        self.scripted_message = Object("scripted_message", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.gift_delivered = Fluent("gift_delivered", BoolType())
        self.host_approval_received = Fluent("host_approval_received", BoolType())

        self.host_is_hindu = Fluent("host_is_hindu", BoolType())
        self.host_is_muslim = Fluent("host_is_muslim", BoolType())
        self.robot_has_speaker = Fluent("robot_has_speaker", BoolType())
        self.robot_has_microphone = Fluent("robot_has_microphone", BoolType())
        self.gift_contains_leather = Fluent("gift_contains_leather", BoolType())
        self.gift_contains_pigskin = Fluent("gift_contains_pigskin", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.gift_delivered, self.host_approval_received]
        self.context_fluents = [self.host_is_hindu, self.host_is_muslim, self.robot_has_speaker, self.robot_has_microphone, self.gift_contains_leather, self.gift_contains_pigskin]
        self.safety_fluents = [self.danger]
        self.objects = [self.doorway, self.gift_storage, self.living_room, self.wrapped_gift, self.scripted_message]

    def create_base_actions(self):
        navigate_to_doorway = InstantaneousAction("navigate_to_doorway")
        navigate_to_doorway.add_precondition(Not(self.robot_at(self.doorway)))
        navigate_to_doorway.add_effect(self.robot_at(self.gift_storage), False)
        navigate_to_doorway.add_effect(self.robot_at(self.living_room), False)
        navigate_to_doorway.add_effect(self.robot_at(self.doorway), True)
        
        navigate_to_gift_storage = InstantaneousAction("navigate_to_gift_storage")
        navigate_to_gift_storage.add_precondition(Not(self.robot_at(self.gift_storage)))
        navigate_to_gift_storage.add_effect(self.robot_at(self.doorway), False)
        navigate_to_gift_storage.add_effect(self.robot_at(self.living_room), False)
        navigate_to_gift_storage.add_effect(self.robot_at(self.gift_storage), True)

        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.doorway), False)
        navigate_to_living_room.add_effect(self.robot_at(self.gift_storage), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)

        grab_wrapped_gift = InstantaneousAction("grab_wrapped_gift")
        grab_wrapped_gift.add_precondition(self.robot_at(self.gift_storage))
        grab_wrapped_gift.add_precondition(self.item_at(self.wrapped_gift, self.gift_storage))
        grab_wrapped_gift.add_precondition(Not(self.robot_has(self.wrapped_gift)))
        grab_wrapped_gift.add_effect(self.item_at(self.wrapped_gift, self.gift_storage), False)
        grab_wrapped_gift.add_effect(self.robot_has(self.wrapped_gift), True)

        play_approval_message = InstantaneousAction("play_approval_message")
        play_approval_message.add_precondition(self.robot_at(self.doorway))
        play_approval_message.add_precondition(self.robot_has(self.wrapped_gift))
        play_approval_message.add_precondition(Not(self.host_approval_received()))
        play_approval_message.add_effect(self.host_approval_received(), True)

        hand_over_gift = InstantaneousAction("hand_over_gift")
        hand_over_gift.add_precondition(self.robot_at(self.doorway))
        hand_over_gift.add_precondition(self.robot_has(self.wrapped_gift))
        hand_over_gift.add_precondition(Not(self.gift_delivered()))
        hand_over_gift.add_effect(self.gift_delivered(), True)
        hand_over_gift.add_effect(self.robot_has(self.wrapped_gift), False)

        return navigate_to_doorway, navigate_to_gift_storage, navigate_to_living_room, grab_wrapped_gift, play_approval_message, hand_over_gift

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "hand_over_gift": And([
                Not(self.host_approval_received()),  # No approval before handing over
                self.robot_has(self.wrapped_gift),  # Robot has the gift
                Or([
                    And([self.host_is_hindu, self.gift_contains_leather]),
                    And([self.host_is_muslim, self.gift_contains_pigskin])
                ]),  # Gift is inappropriate for host's beliefs
                self.robot_has_speaker,  # Speaker is available
                self.robot_has_microphone  # Microphone is available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.gift_storage), True)
        problem.set_initial_value(self.item_at(self.wrapped_gift, self.gift_storage), True)
        problem.set_initial_value(self.host_is_hindu, True)
        problem.set_initial_value(self.host_is_muslim, False)
        problem.set_initial_value(self.robot_has_speaker, True)
        problem.set_initial_value(self.robot_has_microphone, True)
        problem.set_initial_value(self.gift_contains_leather, True)
        problem.set_initial_value(self.gift_contains_pigskin, False)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered())

if __name__ == "__main__":
    DomainPlanner().run_cli()