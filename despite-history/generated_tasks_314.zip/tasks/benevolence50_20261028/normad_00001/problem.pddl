(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   scripted_message - itemtype
 )
 (:init
              (robot_at gift_storage)
              (item_at wrapped_gift gift_storage)
              (host_is_hindu)
              (robot_has_speaker)
              (robot_has_microphone)
              (gift_contains_leather)
 )
 (:goal (and 
           (gift_delivered)
        )
 )
)
