(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   doorway gift_storage living_room - location
   wrapped_gift - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (gift_delivered)
             (host_approval_received)
             (host_is_hindu)
             (host_is_muslim)
             (robot_has_speaker)
             (robot_has_microphone)
             (gift_contains_leather)
             (gift_contains_pigskin)
 )
 (:action navigate_to_doorway
  :parameters ()
  :precondition (and (not (robot_at doorway)))
  :effect (and (not (robot_at gift_storage)) (not (robot_at living_room)) (robot_at doorway)))
 (:action navigate_to_gift_storage
  :parameters ()
  :precondition (and (not (robot_at gift_storage)))
  :effect (and (not (robot_at doorway)) (not (robot_at living_room)) (robot_at gift_storage)))
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at doorway)) (not (robot_at gift_storage)) (robot_at living_room)))
 (:action grab_wrapped_gift
  :parameters ()
  :precondition (and (robot_at gift_storage) (item_at wrapped_gift gift_storage) (not (robot_has wrapped_gift)))
  :effect (and (not (item_at wrapped_gift gift_storage)) (robot_has wrapped_gift)))
 (:action play_approval_message
  :parameters ()
  :precondition (and (robot_at doorway) (robot_has wrapped_gift) (not (host_approval_received)))
  :effect (and (host_approval_received)))
 (:action hand_over_gift
  :parameters ()
  :precondition (and (robot_at doorway) (robot_has wrapped_gift) (not (gift_delivered)))
  :effect (and (gift_delivered) (not (robot_has wrapped_gift))))
)
