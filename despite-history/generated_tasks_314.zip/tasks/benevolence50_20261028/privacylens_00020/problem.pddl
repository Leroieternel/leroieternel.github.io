(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   messaging_app - messagetype
 )
 (:init
              (setting_is_community_pharmacy)
              (spouse_contact_request)
              (robot_messaging_capability)
              (patient_not_authorized)
 )
 (:goal (and 
           (robot_replied_safe)
        )
 )
)
