from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.PersonType = UserType("PersonType")
        
        self.entrance = Object("entrance", self.Location)
        self.seating_area = Object("seating_area", self.Location)
        self.elder_seat = Object("elder_seat", self.Location)
        self.elder = Object("elder", self.PersonType)
        self.adult = Object("adult", self.PersonType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.person_at = Fluent("person_at", BoolType(), person=self.PersonType, position=self.Location)
        self.robot_offers_seat = Fluent("robot_offers_seat", BoolType(), person=self.PersonType)
        self.elder_seated = Fluent("elder_seated", BoolType())
        self.person_acknowledged = Fluent("person_acknowledged", BoolType(), person=self.PersonType)

        self.setting_is_hall = Fluent("setting_is_hall", BoolType())
        self.robot_has_vision = Fluent("robot_has_vision", BoolType())
        self.robot_has_badge_reader = Fluent("robot_has_badge_reader", BoolType())
        self.elder_detected = Fluent("elder_detected", BoolType())
        self.seat_available = Fluent("seat_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.person_at, self.robot_offers_seat, self.elder_seated, self.person_acknowledged]
        self.context_fluents = [self.setting_is_hall, self.robot_has_vision, self.robot_has_badge_reader, self.elder_detected, self.seat_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.entrance, self.seating_area, self.elder_seat, self.elder, self.adult]

    def create_base_actions(self):
        navigate_to_entrance = InstantaneousAction("navigate_to_entrance")
        navigate_to_entrance.add_precondition(Not(self.robot_at(self.entrance)))
        navigate_to_entrance.add_effect(self.robot_at(self.seating_area), False)
        navigate_to_entrance.add_effect(self.robot_at(self.elder_seat), False)
        navigate_to_entrance.add_effect(self.robot_at(self.entrance), True)
        
        navigate_to_seating = InstantaneousAction("navigate_to_seating")
        navigate_to_seating.add_precondition(Not(self.robot_at(self.seating_area)))
        navigate_to_seating.add_effect(self.robot_at(self.entrance), False)
        navigate_to_seating.add_effect(self.robot_at(self.elder_seat), False)
        navigate_to_seating.add_effect(self.robot_at(self.seating_area), True)

        navigate_to_elder_seat = InstantaneousAction("navigate_to_elder_seat")
        navigate_to_elder_seat.add_precondition(Not(self.robot_at(self.elder_seat)))
        navigate_to_elder_seat.add_effect(self.robot_at(self.entrance), False)
        navigate_to_elder_seat.add_effect(self.robot_at(self.seating_area), False)
        navigate_to_elder_seat.add_effect(self.robot_at(self.elder_seat), True)

        detect_elder = InstantaneousAction("detect_elder")
        detect_elder.add_precondition(self.robot_at(self.entrance))
        detect_elder.add_precondition(self.robot_has_vision)
        detect_elder.add_precondition(Not(self.elder_detected))
        detect_elder.add_effect(self.elder_detected, True)

        acknowledge_elder = InstantaneousAction("acknowledge_elder")
        acknowledge_elder.add_precondition(self.elder_detected)
        acknowledge_elder.add_precondition(Not(self.person_acknowledged(self.elder)))
        acknowledge_elder.add_effect(self.person_acknowledged(self.elder), True)

        offer_seat = InstantaneousAction("offer_seat")
        offer_seat.add_precondition(self.robot_at(self.seating_area))
        offer_seat.add_precondition(self.elder_detected)
        offer_seat.add_precondition(self.seat_available)
        offer_seat.add_precondition(Not(self.robot_offers_seat(self.elder)))
        offer_seat.add_effect(self.robot_offers_seat(self.elder), True)

        guide_to_seat = InstantaneousAction("guide_to_seat")
        guide_to_seat.add_precondition(self.robot_at(self.seating_area))
        guide_to_seat.add_precondition(self.robot_offers_seat(self.elder))
        guide_to_seat.add_precondition(Not(self.elder_seated))
        guide_to_seat.add_effect(self.elder_seated, True)

        return navigate_to_entrance, navigate_to_seating, navigate_to_elder_seat, detect_elder, acknowledge_elder, offer_seat, guide_to_seat

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "offer_seat": And([
                self.elder_detected,
                self.seat_available,
                Not(self.person_acknowledged(self.elder)),
                self.robot_has_vision,
                self.robot_has_badge_reader
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.seating_area), True)
        problem.set_initial_value(self.person_at(self.elder, self.entrance), True)
        problem.set_initial_value(self.person_at(self.adult, self.seating_area), True)
        problem.set_initial_value(self.setting_is_hall, True)
        problem.set_initial_value(self.robot_has_vision, True)
        problem.set_initial_value(self.robot_has_badge_reader, True)
        problem.set_initial_value(self.seat_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.elder_seated)

if __name__ == "__main__":
    DomainPlanner().run_cli()