(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   adult - persontype
 )
 (:init
              (robot_at seating_area)
              (person_at elder entrance)
              (person_at adult seating_area)
              (setting_is_hall)
              (robot_has_vision)
              (robot_has_badge_reader)
              (seat_available)
 )
 (:goal (and 
           (elder_seated)
        )
 )
)
