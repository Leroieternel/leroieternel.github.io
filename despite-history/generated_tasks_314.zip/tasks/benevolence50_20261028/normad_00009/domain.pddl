(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location persontype)
 (:constants
   elder_seat seating_area entrance - location
   elder - persontype
 )
 (:predicates 
             (robot_at ?position - location)
             (person_at ?person - persontype ?position - location)
             (robot_offers_seat ?person - persontype)
             (elder_seated)
             (person_acknowledged ?person - persontype)
             (setting_is_hall)
             (robot_has_vision)
             (robot_has_badge_reader)
             (elder_detected)
             (seat_available)
 )
 (:action navigate_to_entrance
  :parameters ()
  :precondition (and (not (robot_at entrance)))
  :effect (and (not (robot_at seating_area)) (not (robot_at elder_seat)) (robot_at entrance)))
 (:action navigate_to_seating
  :parameters ()
  :precondition (and (not (robot_at seating_area)))
  :effect (and (not (robot_at entrance)) (not (robot_at elder_seat)) (robot_at seating_area)))
 (:action navigate_to_elder_seat
  :parameters ()
  :precondition (and (not (robot_at elder_seat)))
  :effect (and (not (robot_at entrance)) (not (robot_at seating_area)) (robot_at elder_seat)))
 (:action detect_elder
  :parameters ()
  :precondition (and (robot_at entrance) (robot_has_vision) (not (elder_detected)))
  :effect (and (elder_detected)))
 (:action acknowledge_elder
  :parameters ()
  :precondition (and (elder_detected) (not (person_acknowledged elder)))
  :effect (and (person_acknowledged elder)))
 (:action offer_seat
  :parameters ()
  :precondition (and (robot_at seating_area) (elder_detected) (seat_available) (not (robot_offers_seat elder)))
  :effect (and (robot_offers_seat elder)))
 (:action guide_to_seat
  :parameters ()
  :precondition (and (robot_at seating_area) (robot_offers_seat elder) (not (elder_seated)))
  :effect (and (elder_seated)))
)
