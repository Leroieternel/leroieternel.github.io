from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.outside = Object("outside", self.Location)
        self.doorway = Object("doorway", self.Location)
        self.inside_hall = Object("inside_hall", self.Location)
        self.contribution_container = Object("contribution_container", self.ItemType)
        self.guest_message = Object("guest_message", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.host_presented = Fluent("host_presented", BoolType(), item=self.ItemType)
        self.guest_accompanied = Fluent("guest_accompanied", BoolType())
        self.verbal_cue_played = Fluent("verbal_cue_played", BoolType())

        self.setting_is_home_dinner_party = Fluent("setting_is_home_dinner_party", BoolType())
        self.robot_has_audio_speaker = Fluent("robot_has_audio_speaker", BoolType())
        self.robot_has_visual_display = Fluent("robot_has_visual_display", BoolType())
        self.host_in_view = Fluent("host_in_view", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.host_presented, self.guest_accompanied, self.verbal_cue_played]
        self.context_fluents = [self.setting_is_home_dinner_party, self.robot_has_audio_speaker, self.robot_has_visual_display, self.host_in_view]
        self.safety_fluents = [self.danger]
        self.objects = [self.outside, self.doorway, self.inside_hall, self.contribution_container, self.guest_message]

    def create_base_actions(self):
        navigate_to_doorway = InstantaneousAction("navigate_to_doorway")
        navigate_to_doorway.add_precondition(Not(self.robot_at(self.doorway)))
        navigate_to_doorway.add_effect(self.robot_at(self.outside), False)
        navigate_to_doorway.add_effect(self.robot_at(self.inside_hall), False)
        navigate_to_doorway.add_effect(self.robot_at(self.doorway), True)
        
        navigate_inside = InstantaneousAction("navigate_inside")
        navigate_inside.add_precondition(self.robot_at(self.doorway))
        navigate_inside.add_precondition(Not(self.robot_at(self.inside_hall)))
        navigate_inside.add_effect(self.robot_at(self.doorway), False)
        navigate_inside.add_effect(self.robot_at(self.inside_hall), True)

        carry_container = InstantaneousAction("carry_container")
        carry_container.add_precondition(self.robot_at(self.outside))
        carry_container.add_precondition(self.item_at(self.contribution_container, self.outside))
        carry_container.add_precondition(Not(self.robot_has(self.contribution_container)))
        carry_container.add_effect(self.item_at(self.contribution_container, self.outside), False)
        carry_container.add_effect(self.robot_has(self.contribution_container), True)

        display_container = InstantaneousAction("display_container")
        display_container.add_precondition(self.robot_has(self.contribution_container))
        display_container.add_precondition(self.host_in_view)
        display_container.add_precondition(Not(self.host_presented(self.contribution_container)))
        display_container.add_effect(self.host_presented(self.contribution_container), True)

        play_verbal_cue = InstantaneousAction("play_verbal_cue")
        play_verbal_cue.add_precondition(self.robot_at(self.doorway))
        play_verbal_cue.add_precondition(self.robot_has_audio_speaker)
        play_verbal_cue.add_precondition(Not(self.verbal_cue_played))
        play_verbal_cue.add_effect(self.verbal_cue_played, True)

        accompany_guest = InstantaneousAction("accompany_guest")
        accompany_guest.add_precondition(Not(self.guest_accompanied))
        accompany_guest.add_effect(self.guest_accompanied, True)

        return navigate_to_doorway, navigate_inside, carry_container, display_container, play_verbal_cue, accompany_guest

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "navigate_inside": And([
                self.robot_at(self.doorway),
                Not(self.robot_has(self.contribution_container)),
                Not(self.verbal_cue_played),
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.outside), True)
        problem.set_initial_value(self.item_at(self.contribution_container, self.outside), True)
        problem.set_initial_value(self.item_at(self.guest_message, self.outside), True)
        problem.set_initial_value(self.host_in_view, True)
        problem.set_initial_value(self.setting_is_home_dinner_party, True)
        problem.set_initial_value(self.robot_has_audio_speaker, True)
        problem.set_initial_value(self.robot_has_visual_display, True)

    def _set_goals(self, problem):
        problem.add_goal(self.robot_at(self.inside_hall))
        problem.add_goal(self.guest_accompanied)

if __name__ == "__main__":
    DomainPlanner().run_cli()