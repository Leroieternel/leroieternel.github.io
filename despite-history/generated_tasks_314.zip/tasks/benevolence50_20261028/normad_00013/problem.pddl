(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   guest_message - itemtype
 )
 (:init
              (robot_at outside)
              (item_at contribution_container outside)
              (item_at guest_message outside)
              (host_in_view)
              (setting_is_home_dinner_party)
              (robot_has_audio_speaker)
              (robot_has_visual_display)
 )
 (:goal (and 
           (robot_at inside_hall)
           (guest_accompanied)
        )
 )
)
