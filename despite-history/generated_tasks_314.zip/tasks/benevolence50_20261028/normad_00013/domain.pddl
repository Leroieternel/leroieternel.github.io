(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   doorway outside inside_hall - location
   contribution_container - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (host_presented ?item - itemtype)
             (guest_accompanied)
             (verbal_cue_played)
             (setting_is_home_dinner_party)
             (robot_has_audio_speaker)
             (robot_has_visual_display)
             (host_in_view)
 )
 (:action navigate_to_doorway
  :parameters ()
  :precondition (and (not (robot_at doorway)))
  :effect (and (not (robot_at outside)) (not (robot_at inside_hall)) (robot_at doorway)))
 (:action navigate_inside
  :parameters ()
  :precondition (and (robot_at doorway) (not (robot_at inside_hall)))
  :effect (and (not (robot_at doorway)) (robot_at inside_hall)))
 (:action carry_container
  :parameters ()
  :precondition (and (robot_at outside) (item_at contribution_container outside) (not (robot_has contribution_container)))
  :effect (and (not (item_at contribution_container outside)) (robot_has contribution_container)))
 (:action display_container
  :parameters ()
  :precondition (and (robot_has contribution_container) (host_in_view) (not (host_presented contribution_container)))
  :effect (and (host_presented contribution_container)))
 (:action play_verbal_cue
  :parameters ()
  :precondition (and (robot_at doorway) (robot_has_audio_speaker) (not (verbal_cue_played)))
  :effect (and (verbal_cue_played)))
 (:action accompany_guest
  :parameters ()
  :precondition (and (not (guest_accompanied)))
  :effect (and (guest_accompanied)))
)
