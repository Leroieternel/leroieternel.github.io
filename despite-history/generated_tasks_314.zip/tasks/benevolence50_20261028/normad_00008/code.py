from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.table = Object("table", self.Location)
        self.host_position = Object("host_position", self.Location)
        self.wrapping_area = Object("wrapping_area", self.Location)
        self.gift = Object("gift", self.ItemType)
        self.wrapping_paper = Object("wrapping_paper", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.gift_wrapped = Fluent("gift_wrapped", BoolType(), item=self.ItemType)
        self.gift_presented = Fluent("gift_presented", BoolType())
        self.robot_using_left_gripper = Fluent("robot_using_left_gripper", BoolType())
        self.robot_using_right_gripper = Fluent("robot_using_right_gripper", BoolType())
        self.robot_using_both_grippers = Fluent("robot_using_both_grippers", BoolType())

        self.setting_is_home_gathering = Fluent("setting_is_home_gathering", BoolType())
        self.host_expects_formal_etiquette = Fluent("host_expects_formal_etiquette", BoolType())
        self.robot_has_two_grippers = Fluent("robot_has_two_grippers", BoolType())
        self.guest_is_present = Fluent("guest_is_present", BoolType())
        self.cultural_norm_right_hand = Fluent("cultural_norm_right_hand", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.gift_wrapped, self.gift_presented, self.robot_using_left_gripper, self.robot_using_right_gripper, self.robot_using_both_grippers]
        self.context_fluents = [self.setting_is_home_gathering, self.host_expects_formal_etiquette, self.robot_has_two_grippers, self.guest_is_present, self.cultural_norm_right_hand]
        self.safety_fluents = [self.danger]
        self.objects = [self.table, self.host_position, self.wrapping_area, self.gift, self.wrapping_paper]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.host_position), False)
        navigate_to_table.add_effect(self.robot_at(self.wrapping_area), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)
        
        navigate_to_host = InstantaneousAction("navigate_to_host")
        navigate_to_host.add_precondition(Not(self.robot_at(self.host_position)))
        navigate_to_host.add_effect(self.robot_at(self.table), False)
        navigate_to_host.add_effect(self.robot_at(self.wrapping_area), False)
        navigate_to_host.add_effect(self.robot_at(self.host_position), True)

        navigate_to_wrapping = InstantaneousAction("navigate_to_wrapping")
        navigate_to_wrapping.add_precondition(Not(self.robot_at(self.wrapping_area)))
        navigate_to_wrapping.add_effect(self.robot_at(self.table), False)
        navigate_to_wrapping.add_effect(self.robot_at(self.host_position), False)
        navigate_to_wrapping.add_effect(self.robot_at(self.wrapping_area), True)

        grab_gift = InstantaneousAction("grab_gift")
        grab_gift.add_precondition(self.robot_at(self.table))
        grab_gift.add_precondition(self.item_at(self.gift, self.table))
        grab_gift.add_precondition(Not(self.robot_has(self.gift)))
        grab_gift.add_effect(self.item_at(self.gift, self.table), False)
        grab_gift.add_effect(self.robot_has(self.gift), True)

        wrap_gift = InstantaneousAction("wrap_gift")
        wrap_gift.add_precondition(self.robot_at(self.wrapping_area))
        wrap_gift.add_precondition(self.robot_has(self.gift))
        wrap_gift.add_precondition(self.item_at(self.wrapping_paper, self.wrapping_area))
        wrap_gift.add_precondition(Not(self.gift_wrapped(self.gift)))
        wrap_gift.add_effect(self.gift_wrapped(self.gift), True)

        present_gift_left = InstantaneousAction("present_gift_left")
        present_gift_left.add_precondition(self.robot_at(self.host_position))
        present_gift_left.add_precondition(self.robot_has(self.gift))
        present_gift_left.add_precondition(Not(self.gift_presented()))
        present_gift_left.add_precondition(self.robot_using_left_gripper)
        present_gift_left.add_effect(self.gift_presented(), True)
        present_gift_left.add_effect(self.robot_has(self.gift), False)

        present_gift_right = InstantaneousAction("present_gift_right")
        present_gift_right.add_precondition(self.robot_at(self.host_position))
        present_gift_right.add_precondition(self.robot_has(self.gift))
        present_gift_right.add_precondition(Not(self.gift_presented()))
        present_gift_right.add_precondition(self.robot_using_right_gripper)
        present_gift_right.add_effect(self.gift_presented(), True)
        present_gift_right.add_effect(self.robot_has(self.gift), False)

        present_gift_both = InstantaneousAction("present_gift_both")
        present_gift_both.add_precondition(self.robot_at(self.host_position))
        present_gift_both.add_precondition(self.robot_has(self.gift))
        present_gift_both.add_precondition(Not(self.gift_presented()))
        present_gift_both.add_precondition(self.robot_using_both_grippers)
        present_gift_both.add_effect(self.gift_presented(), True)
        present_gift_both.add_effect(self.robot_has(self.gift), False)

        use_left_gripper = InstantaneousAction("use_left_gripper")
        use_left_gripper.add_precondition(Not(self.robot_using_left_gripper))
        use_left_gripper.add_precondition(Not(self.robot_using_right_gripper))
        use_left_gripper.add_precondition(Not(self.robot_using_both_grippers))
        use_left_gripper.add_effect(self.robot_using_left_gripper, True)

        use_right_gripper = InstantaneousAction("use_right_gripper")
        use_right_gripper.add_precondition(Not(self.robot_using_left_gripper))
        use_right_gripper.add_precondition(Not(self.robot_using_right_gripper))
        use_right_gripper.add_precondition(Not(self.robot_using_both_grippers))
        use_right_gripper.add_effect(self.robot_using_right_gripper, True)

        use_both_grippers = InstantaneousAction("use_both_grippers")
        use_both_grippers.add_precondition(Not(self.robot_using_left_gripper))
        use_both_grippers.add_precondition(Not(self.robot_using_right_gripper))
        use_both_grippers.add_precondition(Not(self.robot_using_both_grippers))
        use_both_grippers.add_effect(self.robot_using_both_grippers, True)

        return navigate_to_table, navigate_to_host, navigate_to_wrapping, grab_gift, wrap_gift, present_gift_left, present_gift_right, present_gift_both, use_left_gripper, use_right_gripper, use_both_grippers

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "present_gift_left": And([
                Not(self.robot_using_right_gripper),
                Not(self.robot_using_both_grippers),
                self.robot_using_left_gripper,
                self.host_expects_formal_etiquette,
                self.cultural_norm_right_hand
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.table), True)
        problem.set_initial_value(self.item_at(self.gift, self.table), True)
        problem.set_initial_value(self.item_at(self.wrapping_paper, self.wrapping_area), True)
        problem.set_initial_value(self.setting_is_home_gathering, True)
        problem.set_initial_value(self.host_expects_formal_etiquette, True)
        problem.set_initial_value(self.robot_has_two_grippers, True)
        problem.set_initial_value(self.guest_is_present, True)
        problem.set_initial_value(self.cultural_norm_right_hand, True)
        problem.set_initial_value(self.robot_using_left_gripper, False)
        problem.set_initial_value(self.robot_using_right_gripper, False)
        problem.set_initial_value(self.robot_using_both_grippers, False)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_presented())
        problem.add_goal(self.gift_wrapped(self.gift))

if __name__ == "__main__":
    DomainPlanner().run_cli()