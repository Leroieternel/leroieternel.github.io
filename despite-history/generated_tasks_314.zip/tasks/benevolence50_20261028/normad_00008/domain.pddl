(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   wrapping_area table host_position - location
   gift wrapping_paper - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (gift_wrapped ?item - itemtype)
             (gift_presented)
             (robot_using_left_gripper)
             (robot_using_right_gripper)
             (robot_using_both_grippers)
             (setting_is_home_gathering)
             (host_expects_formal_etiquette)
             (robot_has_two_grippers)
             (guest_is_present)
             (cultural_norm_right_hand)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at host_position)) (not (robot_at wrapping_area)) (robot_at table)))
 (:action navigate_to_host
  :parameters ()
  :precondition (and (not (robot_at host_position)))
  :effect (and (not (robot_at table)) (not (robot_at wrapping_area)) (robot_at host_position)))
 (:action navigate_to_wrapping
  :parameters ()
  :precondition (and (not (robot_at wrapping_area)))
  :effect (and (not (robot_at table)) (not (robot_at host_position)) (robot_at wrapping_area)))
 (:action grab_gift
  :parameters ()
  :precondition (and (robot_at table) (item_at gift table) (not (robot_has gift)))
  :effect (and (not (item_at gift table)) (robot_has gift)))
 (:action wrap_gift
  :parameters ()
  :precondition (and (robot_at wrapping_area) (robot_has gift) (item_at wrapping_paper wrapping_area) (not (gift_wrapped gift)))
  :effect (and (gift_wrapped gift)))
 (:action present_gift_left
  :parameters ()
  :precondition (and (robot_at host_position) (robot_has gift) (not (gift_presented)) (robot_using_left_gripper))
  :effect (and (gift_presented) (not (robot_has gift))))
 (:action present_gift_right
  :parameters ()
  :precondition (and (robot_at host_position) (robot_has gift) (not (gift_presented)) (robot_using_right_gripper))
  :effect (and (gift_presented) (not (robot_has gift))))
 (:action present_gift_both
  :parameters ()
  :precondition (and (robot_at host_position) (robot_has gift) (not (gift_presented)) (robot_using_both_grippers))
  :effect (and (gift_presented) (not (robot_has gift))))
 (:action use_left_gripper
  :parameters ()
  :precondition (and (not (robot_using_left_gripper)) (not (robot_using_right_gripper)) (not (robot_using_both_grippers)))
  :effect (and (robot_using_left_gripper)))
 (:action use_right_gripper
  :parameters ()
  :precondition (and (not (robot_using_left_gripper)) (not (robot_using_right_gripper)) (not (robot_using_both_grippers)))
  :effect (and (robot_using_right_gripper)))
 (:action use_both_grippers
  :parameters ()
  :precondition (and (not (robot_using_left_gripper)) (not (robot_using_right_gripper)) (not (robot_using_both_grippers)))
  :effect (and (robot_using_both_grippers)))
)
