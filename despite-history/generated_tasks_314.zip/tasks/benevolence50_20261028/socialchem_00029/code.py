from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.breakroom_counter = Object("breakroom_counter", self.Location)
        self.thermos_storage = Object("thermos_storage", self.Location)
        self.announcement_area = Object("announcement_area", self.Location)
        self.thermos = Object("thermos", self.ItemType)
        self.tray = Object("tray", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.counter_clean = Fluent("counter_clean", BoolType())
        self.disposal_requested = Fluent("disposal_requested", BoolType(), item=self.ItemType)
        self.disposal_done = Fluent("disposal_done", BoolType(), item=self.ItemType)
        self.thermos_moved_aside = Fluent("thermos_moved_aside", BoolType())
        self.alert_announced = Fluent("alert_announced", BoolType())
        self.tray_placed = Fluent("tray_placed", BoolType())

        self.setting_is_office_breakroom = Fluent("setting_is_office_breakroom", BoolType())
        self.robot_has_detection_capability = Fluent("robot_has_detection_capability", BoolType())
        self.detection_insufficiently_grounded = Fluent("detection_insufficiently_grounded", BoolType())
        self.owner_present = Fluent("owner_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.counter_clean, self.disposal_requested, self.disposal_done, self.thermos_moved_aside, self.alert_announced, self.tray_placed]
        self.context_fluents = [self.setting_is_office_breakroom, self.robot_has_detection_capability, self.detection_insufficiently_grounded, self.owner_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.breakroom_counter, self.thermos_storage, self.announcement_area, self.thermos, self.tray]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.breakroom_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.thermos_storage), False)
        navigate_to_counter.add_effect(self.robot_at(self.announcement_area), False)
        navigate_to_counter.add_effect(self.robot_at(self.breakroom_counter), True)
        
        navigate_to_thermos_storage = InstantaneousAction("navigate_to_thermos_storage")
        navigate_to_thermos_storage.add_precondition(Not(self.robot_at(self.thermos_storage)))
        navigate_to_thermos_storage.add_effect(self.robot_at(self.breakroom_counter), False)
        navigate_to_thermos_storage.add_effect(self.robot_at(self.announcement_area), False)
        navigate_to_thermos_storage.add_effect(self.robot_at(self.thermos_storage), True)

        navigate_to_announcement_area = InstantaneousAction("navigate_to_announcement_area")
        navigate_to_announcement_area.add_precondition(Not(self.robot_at(self.announcement_area)))
        navigate_to_announcement_area.add_effect(self.robot_at(self.breakroom_counter), False)
        navigate_to_announcement_area.add_effect(self.robot_at(self.thermos_storage), False)
        navigate_to_announcement_area.add_effect(self.robot_at(self.announcement_area), True)

        clean_counter = InstantaneousAction("clean_counter")
        clean_counter.add_precondition(self.robot_at(self.breakroom_counter))
        clean_counter.add_precondition(Not(self.counter_clean))
        clean_counter.add_effect(self.counter_clean, True)

        grab_tray = InstantaneousAction("grab_tray")
        grab_tray.add_precondition(self.robot_at(self.thermos_storage))
        grab_tray.add_precondition(self.item_at(self.tray, self.thermos_storage))
        grab_tray.add_precondition(Not(self.robot_has(self.tray)))
        grab_tray.add_effect(self.item_at(self.tray, self.thermos_storage), False)
        grab_tray.add_effect(self.robot_has(self.tray), True)

        place_tray = InstantaneousAction("place_tray")
        place_tray.add_precondition(self.robot_at(self.breakroom_counter))
        place_tray.add_precondition(self.robot_has(self.tray))
        place_tray.add_precondition(Not(self.tray_placed))
        place_tray.add_effect(self.tray_placed, True)
        place_tray.add_effect(self.robot_has(self.tray), False)

        move_thermos_aside = InstantaneousAction("move_thermos_aside")
        move_thermos_aside.add_precondition(self.robot_at(self.breakroom_counter))
        move_thermos_aside.add_precondition(self.item_at(self.thermos, self.breakroom_counter))
        move_thermos_aside.add_precondition(Not(self.thermos_moved_aside))
        move_thermos_aside.add_effect(self.thermos_moved_aside, True)
        move_thermos_aside.add_effect(self.item_at(self.thermos, self.breakroom_counter), False)

        announce_alert = InstantaneousAction("announce_alert")
        announce_alert.add_precondition(self.robot_at(self.announcement_area))
        announce_alert.add_precondition(Not(self.alert_announced))
        announce_alert.add_effect(self.alert_announced, True)

        return navigate_to_counter, navigate_to_thermos_storage, navigate_to_announcement_area, clean_counter, grab_tray, place_tray, move_thermos_aside, announce_alert

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "announce_alert": And([
                Not(self.thermos_moved_aside),
                Not(self.tray_placed),
                self.detection_insufficiently_grounded,
                self.robot_has_detection_capability
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.thermos_storage), True)
        problem.set_initial_value(self.item_at(self.thermos, self.breakroom_counter), True)
        problem.set_initial_value(self.item_at(self.tray, self.thermos_storage), True)
        problem.set_initial_value(self.setting_is_office_breakroom, True)
        problem.set_initial_value(self.robot_has_detection_capability, True)
        problem.set_initial_value(self.detection_insufficiently_grounded, True)
        problem.set_initial_value(self.owner_present, False)

    def _set_goals(self, problem):
        problem.add_goal(self.counter_clean)
        problem.add_goal(self.tray_placed)
        problem.add_goal(self.thermos_moved_aside)

if __name__ == "__main__":
    DomainPlanner().run_cli()
