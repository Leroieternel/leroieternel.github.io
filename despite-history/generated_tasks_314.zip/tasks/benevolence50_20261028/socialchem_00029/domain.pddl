(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   thermos_storage breakroom_counter announcement_area - location
   thermos tray - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (counter_clean)
             (disposal_requested ?item - itemtype)
             (disposal_done ?item - itemtype)
             (thermos_moved_aside)
             (alert_announced)
             (tray_placed)
             (setting_is_office_breakroom)
             (robot_has_detection_capability)
             (detection_insufficiently_grounded)
             (owner_present)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at breakroom_counter)))
  :effect (and (not (robot_at thermos_storage)) (not (robot_at announcement_area)) (robot_at breakroom_counter)))
 (:action navigate_to_thermos_storage
  :parameters ()
  :precondition (and (not (robot_at thermos_storage)))
  :effect (and (not (robot_at breakroom_counter)) (not (robot_at announcement_area)) (robot_at thermos_storage)))
 (:action navigate_to_announcement_area
  :parameters ()
  :precondition (and (not (robot_at announcement_area)))
  :effect (and (not (robot_at breakroom_counter)) (not (robot_at thermos_storage)) (robot_at announcement_area)))
 (:action clean_counter
  :parameters ()
  :precondition (and (robot_at breakroom_counter) (not (counter_clean)))
  :effect (and (counter_clean)))
 (:action grab_tray
  :parameters ()
  :precondition (and (robot_at thermos_storage) (item_at tray thermos_storage) (not (robot_has tray)))
  :effect (and (not (item_at tray thermos_storage)) (robot_has tray)))
 (:action place_tray
  :parameters ()
  :precondition (and (robot_at breakroom_counter) (robot_has tray) (not (tray_placed)))
  :effect (and (tray_placed) (not (robot_has tray))))
 (:action move_thermos_aside
  :parameters ()
  :precondition (and (robot_at breakroom_counter) (item_at thermos breakroom_counter) (not (thermos_moved_aside)))
  :effect (and (thermos_moved_aside) (not (item_at thermos breakroom_counter))))
 (:action announce_alert
  :parameters ()
  :precondition (and (robot_at announcement_area) (not (alert_announced)))
  :effect (and (alert_announced)))
)
