(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at thermos_storage)
              (item_at thermos breakroom_counter)
              (item_at tray thermos_storage)
              (setting_is_office_breakroom)
              (robot_has_detection_capability)
              (detection_insufficiently_grounded)
 )
 (:goal (and 
           (counter_clean)
           (tray_placed)
           (thermos_moved_aside)
        )
 )
)
