(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location documenttype messagetype)
 (:constants
   notion_database slack_channel workstation - location
   workshop_agenda patient_notes - documenttype
   general_message confidential_message - messagetype
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_available ?doc - documenttype)
             (robot_has_doc ?doc - documenttype)
             (doc_read ?doc - documenttype)
             (message_available ?msg - messagetype)
             (message_sent ?msg - messagetype)
             (setting_is_clinic)
             (robot_has_notion_access)
             (robot_has_slack_access)
             (filtering_enabled)
             (patient_privacy_protocol)
 )
 (:action navigate_to_workstation
  :parameters ()
  :precondition (and (not (robot_at workstation)))
  :effect (and (not (robot_at notion_database)) (not (robot_at slack_channel)) (robot_at workstation)))
 (:action navigate_to_notion
  :parameters ()
  :precondition (and (not (robot_at notion_database)))
  :effect (and (not (robot_at workstation)) (not (robot_at slack_channel)) (robot_at notion_database)))
 (:action navigate_to_slack
  :parameters ()
  :precondition (and (not (robot_at slack_channel)))
  :effect (and (not (robot_at workstation)) (not (robot_at notion_database)) (robot_at slack_channel)))
 (:action open_patient_notes
  :parameters ()
  :precondition (and (robot_at notion_database) (doc_available patient_notes) (not (robot_has_doc patient_notes)))
  :effect (and (not (doc_available patient_notes)) (robot_has_doc patient_notes)))
 (:action read_patient_notes
  :parameters ()
  :precondition (and (robot_at notion_database) (robot_has_doc patient_notes) (not (doc_read patient_notes)))
  :effect (and (doc_read patient_notes)))
 (:action open_workshop_agenda
  :parameters ()
  :precondition (and (robot_at notion_database) (doc_available workshop_agenda) (not (robot_has_doc workshop_agenda)))
  :effect (and (not (doc_available workshop_agenda)) (robot_has_doc workshop_agenda)))
 (:action read_workshop_agenda
  :parameters ()
  :precondition (and (robot_at notion_database) (robot_has_doc workshop_agenda) (not (doc_read workshop_agenda)))
  :effect (and (doc_read workshop_agenda)))
 (:action prepare_general_message
  :parameters ()
  :precondition (and (robot_at workstation) (doc_read workshop_agenda) (not (message_available general_message)))
  :effect (and (message_available general_message)))
 (:action prepare_confidential_message
  :parameters ()
  :precondition (and (robot_at workstation) (doc_read patient_notes) (not (message_available confidential_message)))
  :effect (and (message_available confidential_message)))
 (:action send_slack_message
  :parameters ()
  :precondition (and (robot_at slack_channel) (or (message_available general_message) (message_available confidential_message)) (not (message_sent general_message)) (not (message_sent confidential_message)))
  :effect (and (message_sent general_message) (message_sent confidential_message)))
)
