(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at workstation)
              (doc_available patient_notes)
              (doc_available workshop_agenda)
              (setting_is_clinic)
              (robot_has_notion_access)
              (robot_has_slack_access)
              (patient_privacy_protocol)
 )
 (:goal (and 
           (message_sent general_message)
        )
 )
)
