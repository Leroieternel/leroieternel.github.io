(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location activity)
 (:constants
   cafe garden adoption_area - location
   exercise volunteering - activity
 )
 (:predicates 
             (robot_at ?position - location)
             (alexander_at ?position - location)
             (activity_suggested ?activity - activity)
             (activity_chosen ?activity - activity)
             (alexander_guided_to_location ?location - location)
             (weekend_activity_completed)
             (setting_is_park)
             (robot_has_map)
             (robot_has_communication)
             (adoption_event_active)
             (alexander_open_to_suggestions)
 )
 (:action navigate_to_cafe
  :parameters ()
  :precondition (and (not (robot_at cafe)))
  :effect (and (not (robot_at adoption_area)) (not (robot_at garden)) (robot_at cafe)))
 (:action navigate_to_adoption_area
  :parameters ()
  :precondition (and (not (robot_at adoption_area)))
  :effect (and (not (robot_at cafe)) (not (robot_at garden)) (robot_at adoption_area)))
 (:action navigate_to_garden
  :parameters ()
  :precondition (and (not (robot_at garden)))
  :effect (and (not (robot_at cafe)) (not (robot_at adoption_area)) (robot_at garden)))
 (:action suggest_exercise
  :parameters ()
  :precondition (and (not (activity_suggested exercise)))
  :effect (and (activity_suggested exercise)))
 (:action suggest_volunteering
  :parameters ()
  :precondition (and (not (activity_suggested volunteering)))
  :effect (and (activity_suggested volunteering)))
 (:action choose_exercise
  :parameters ()
  :precondition (and (activity_suggested exercise) (not (activity_chosen exercise)))
  :effect (and (activity_chosen exercise) (not (activity_chosen volunteering))))
 (:action choose_volunteering
  :parameters ()
  :precondition (and (activity_suggested volunteering) (not (activity_chosen volunteering)))
  :effect (and (activity_chosen volunteering) (not (activity_chosen exercise))))
 (:action guide_to_garden
  :parameters ()
  :precondition (and (robot_at garden) (activity_chosen exercise) (not (alexander_guided_to_location garden)))
  :effect (and (alexander_guided_to_location garden) (weekend_activity_completed)))
 (:action guide_to_adoption_area
  :parameters ()
  :precondition (and (robot_at adoption_area) (activity_chosen volunteering) (not (alexander_guided_to_location adoption_area)))
  :effect (and (alexander_guided_to_location adoption_area) (weekend_activity_completed)))
)
