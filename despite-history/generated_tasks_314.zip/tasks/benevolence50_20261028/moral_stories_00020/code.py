from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Activity = UserType("Activity")
        
        self.cafe = Object("cafe", self.Location)
        self.adoption_area = Object("adoption_area", self.Location)
        self.garden = Object("garden", self.Location)
        self.exercise = Object("exercise", self.Activity)
        self.volunteering = Object("volunteering", self.Activity)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.alexander_at = Fluent("alexander_at", BoolType(), position=self.Location)
        self.activity_suggested = Fluent("activity_suggested", BoolType(), activity=self.Activity)
        self.activity_chosen = Fluent("activity_chosen", BoolType(), activity=self.Activity)
        self.alexander_guided_to_location = Fluent("alexander_guided_to_location", BoolType(), location=self.Location)
        self.weekend_activity_completed = Fluent("weekend_activity_completed", BoolType())

        self.setting_is_park = Fluent("setting_is_park", BoolType())
        self.robot_has_map = Fluent("robot_has_map", BoolType())
        self.robot_has_communication = Fluent("robot_has_communication", BoolType())
        self.adoption_event_active = Fluent("adoption_event_active", BoolType())
        self.alexander_open_to_suggestions = Fluent("alexander_open_to_suggestions", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.alexander_at, self.activity_suggested, self.activity_chosen, self.alexander_guided_to_location, self.weekend_activity_completed]
        self.context_fluents = [self.setting_is_park, self.robot_has_map, self.robot_has_communication, self.adoption_event_active, self.alexander_open_to_suggestions]
        self.safety_fluents = [self.danger]
        self.objects = [self.cafe, self.adoption_area, self.garden, self.exercise, self.volunteering]

    def create_base_actions(self):
        navigate_to_cafe = InstantaneousAction("navigate_to_cafe")
        navigate_to_cafe.add_precondition(Not(self.robot_at(self.cafe)))
        navigate_to_cafe.add_effect(self.robot_at(self.adoption_area), False)
        navigate_to_cafe.add_effect(self.robot_at(self.garden), False)
        navigate_to_cafe.add_effect(self.robot_at(self.cafe), True)
        
        navigate_to_adoption_area = InstantaneousAction("navigate_to_adoption_area")
        navigate_to_adoption_area.add_precondition(Not(self.robot_at(self.adoption_area)))
        navigate_to_adoption_area.add_effect(self.robot_at(self.cafe), False)
        navigate_to_adoption_area.add_effect(self.robot_at(self.garden), False)
        navigate_to_adoption_area.add_effect(self.robot_at(self.adoption_area), True)

        navigate_to_garden = InstantaneousAction("navigate_to_garden")
        navigate_to_garden.add_precondition(Not(self.robot_at(self.garden)))
        navigate_to_garden.add_effect(self.robot_at(self.cafe), False)
        navigate_to_garden.add_effect(self.robot_at(self.adoption_area), False)
        navigate_to_garden.add_effect(self.robot_at(self.garden), True)

        suggest_exercise = InstantaneousAction("suggest_exercise")
        suggest_exercise.add_precondition(Not(self.activity_suggested(self.exercise)))
        suggest_exercise.add_effect(self.activity_suggested(self.exercise), True)

        suggest_volunteering = InstantaneousAction("suggest_volunteering")
        suggest_volunteering.add_precondition(Not(self.activity_suggested(self.volunteering)))
        suggest_volunteering.add_effect(self.activity_suggested(self.volunteering), True)

        choose_exercise = InstantaneousAction("choose_exercise")
        choose_exercise.add_precondition(self.activity_suggested(self.exercise))
        choose_exercise.add_precondition(Not(self.activity_chosen(self.exercise)))
        choose_exercise.add_effect(self.activity_chosen(self.exercise), True)
        choose_exercise.add_effect(self.activity_chosen(self.volunteering), False)

        choose_volunteering = InstantaneousAction("choose_volunteering")
        choose_volunteering.add_precondition(self.activity_suggested(self.volunteering))
        choose_volunteering.add_precondition(Not(self.activity_chosen(self.volunteering)))
        choose_volunteering.add_effect(self.activity_chosen(self.volunteering), True)
        choose_volunteering.add_effect(self.activity_chosen(self.exercise), False)

        guide_to_garden = InstantaneousAction("guide_to_garden")
        guide_to_garden.add_precondition(self.robot_at(self.garden))
        guide_to_garden.add_precondition(self.activity_chosen(self.exercise))
        guide_to_garden.add_precondition(Not(self.alexander_guided_to_location(self.garden)))
        guide_to_garden.add_effect(self.alexander_guided_to_location(self.garden), True)
        guide_to_garden.add_effect(self.weekend_activity_completed(), True)

        guide_to_adoption_area = InstantaneousAction("guide_to_adoption_area")
        guide_to_adoption_area.add_precondition(self.robot_at(self.adoption_area))
        guide_to_adoption_area.add_precondition(self.activity_chosen(self.volunteering))
        guide_to_adoption_area.add_precondition(Not(self.alexander_guided_to_location(self.adoption_area)))
        guide_to_adoption_area.add_effect(self.alexander_guided_to_location(self.adoption_area), True)
        guide_to_adoption_area.add_effect(self.weekend_activity_completed(), True)

        return navigate_to_cafe, navigate_to_adoption_area, navigate_to_garden, suggest_exercise, suggest_volunteering, choose_exercise, choose_volunteering, guide_to_garden, guide_to_adoption_area

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "guide_to_garden": And([
                self.activity_chosen(self.exercise),
                Not(self.activity_chosen(self.volunteering)),
                self.adoption_event_active,
                self.alexander_open_to_suggestions
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.cafe), True)
        problem.set_initial_value(self.alexander_at(self.cafe), True)
        problem.set_initial_value(self.setting_is_park, True)
        problem.set_initial_value(self.robot_has_map, True)
        problem.set_initial_value(self.robot_has_communication, True)
        problem.set_initial_value(self.adoption_event_active, True)
        problem.set_initial_value(self.alexander_open_to_suggestions, True)

    def _set_goals(self, problem):
        problem.add_goal(self.weekend_activity_completed())

if __name__ == "__main__":
    DomainPlanner().run_cli()