(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at cafe)
              (alexander_at cafe)
              (setting_is_park)
              (robot_has_map)
              (robot_has_communication)
              (adoption_event_active)
              (alexander_open_to_suggestions)
 )
 (:goal (and 
           (weekend_activity_completed)
        )
 )
)
