(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at gift_storage)
              (item_at gift gift_storage)
              (setting_is_japan)
              (robot_has_two_grippers)
              (robot_can_coordinate_grippers)
              (homeowner_present)
 )
 (:goal (and 
           (gift_delivered)
        )
 )
)
