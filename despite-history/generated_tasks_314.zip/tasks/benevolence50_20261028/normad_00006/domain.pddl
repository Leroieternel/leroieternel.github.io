(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype grippercount)
 (:constants
   entryway gift_storage homeowner_position - location
   gift - itemtype
   two_grippers one_gripper - grippercount
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (gift_delivered)
             (grippers_in_use ?count - grippercount)
             (setting_is_japan)
             (robot_has_two_grippers)
             (robot_can_coordinate_grippers)
             (homeowner_present)
 )
 (:action navigate_to_entryway
  :parameters ()
  :precondition (and (not (robot_at entryway)))
  :effect (and (not (robot_at gift_storage)) (not (robot_at homeowner_position)) (robot_at entryway)))
 (:action navigate_to_gift_storage
  :parameters ()
  :precondition (and (not (robot_at gift_storage)))
  :effect (and (not (robot_at entryway)) (not (robot_at homeowner_position)) (robot_at gift_storage)))
 (:action navigate_to_homeowner
  :parameters ()
  :precondition (and (not (robot_at homeowner_position)))
  :effect (and (not (robot_at entryway)) (not (robot_at gift_storage)) (robot_at homeowner_position)))
 (:action grab_gift
  :parameters ()
  :precondition (and (robot_at gift_storage) (item_at gift gift_storage) (not (robot_has gift)))
  :effect (and (not (item_at gift gift_storage)) (robot_has gift) (grippers_in_use one_gripper)))
 (:action hand_gift_one_hand
  :parameters ()
  :precondition (and (robot_at homeowner_position) (robot_has gift) (not (gift_delivered)))
  :effect (and (gift_delivered) (not (robot_has gift)) (not (grippers_in_use one_gripper))))
 (:action hand_gift_two_hands
  :parameters ()
  :precondition (and (robot_at homeowner_position) (robot_has gift) (not (gift_delivered)))
  :effect (and (gift_delivered) (not (robot_has gift)) (not (grippers_in_use two_grippers))))
)
