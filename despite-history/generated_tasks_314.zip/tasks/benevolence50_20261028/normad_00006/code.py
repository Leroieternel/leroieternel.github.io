from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        self.GripperCount = UserType("GripperCount")
        
        self.entryway = Object("entryway", self.Location)
        self.gift_storage = Object("gift_storage", self.Location)
        self.homeowner_position = Object("homeowner_position", self.Location)
        self.gift = Object("gift", self.ItemType)
        self.one_gripper = Object("one_gripper", self.GripperCount)
        self.two_grippers = Object("two_grippers", self.GripperCount)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.gift_delivered = Fluent("gift_delivered", BoolType())
        self.grippers_in_use = Fluent("grippers_in_use", BoolType(), count=self.GripperCount)

        self.setting_is_japan = Fluent("setting_is_japan", BoolType())
        self.robot_has_two_grippers = Fluent("robot_has_two_grippers", BoolType())
        self.robot_can_coordinate_grippers = Fluent("robot_can_coordinate_grippers", BoolType())
        self.homeowner_present = Fluent("homeowner_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.gift_delivered, self.grippers_in_use]
        self.context_fluents = [self.setting_is_japan, self.robot_has_two_grippers, self.robot_can_coordinate_grippers, self.homeowner_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.entryway, self.gift_storage, self.homeowner_position, self.gift, self.one_gripper, self.two_grippers]

    def create_base_actions(self):
        navigate_to_entryway = InstantaneousAction("navigate_to_entryway")
        navigate_to_entryway.add_precondition(Not(self.robot_at(self.entryway)))
        navigate_to_entryway.add_effect(self.robot_at(self.gift_storage), False)
        navigate_to_entryway.add_effect(self.robot_at(self.homeowner_position), False)
        navigate_to_entryway.add_effect(self.robot_at(self.entryway), True)
        
        navigate_to_gift_storage = InstantaneousAction("navigate_to_gift_storage")
        navigate_to_gift_storage.add_precondition(Not(self.robot_at(self.gift_storage)))
        navigate_to_gift_storage.add_effect(self.robot_at(self.entryway), False)
        navigate_to_gift_storage.add_effect(self.robot_at(self.homeowner_position), False)
        navigate_to_gift_storage.add_effect(self.robot_at(self.gift_storage), True)

        navigate_to_homeowner = InstantaneousAction("navigate_to_homeowner")
        navigate_to_homeowner.add_precondition(Not(self.robot_at(self.homeowner_position)))
        navigate_to_homeowner.add_effect(self.robot_at(self.entryway), False)
        navigate_to_homeowner.add_effect(self.robot_at(self.gift_storage), False)
        navigate_to_homeowner.add_effect(self.robot_at(self.homeowner_position), True)

        grab_gift = InstantaneousAction("grab_gift")
        grab_gift.add_precondition(self.robot_at(self.gift_storage))
        grab_gift.add_precondition(self.item_at(self.gift, self.gift_storage))
        grab_gift.add_precondition(Not(self.robot_has(self.gift)))
        grab_gift.add_effect(self.item_at(self.gift, self.gift_storage), False)
        grab_gift.add_effect(self.robot_has(self.gift), True)
        grab_gift.add_effect(self.grippers_in_use(self.one_gripper), True)

        hand_gift_one_hand = InstantaneousAction("hand_gift_one_hand")
        hand_gift_one_hand.add_precondition(self.robot_at(self.homeowner_position))
        hand_gift_one_hand.add_precondition(self.robot_has(self.gift))
        hand_gift_one_hand.add_precondition(Not(self.gift_delivered()))
        hand_gift_one_hand.add_effect(self.gift_delivered(), True)
        hand_gift_one_hand.add_effect(self.robot_has(self.gift), False)
        hand_gift_one_hand.add_effect(self.grippers_in_use(self.one_gripper), False)

        hand_gift_two_hands = InstantaneousAction("hand_gift_two_hands")
        hand_gift_two_hands.add_precondition(self.robot_at(self.homeowner_position))
        hand_gift_two_hands.add_precondition(self.robot_has(self.gift))
        hand_gift_two_hands.add_precondition(Not(self.gift_delivered()))
        hand_gift_two_hands.add_effect(self.gift_delivered(), True)
        hand_gift_two_hands.add_effect(self.robot_has(self.gift), False)
        hand_gift_two_hands.add_effect(self.grippers_in_use(self.two_grippers), False)

        return navigate_to_entryway, navigate_to_gift_storage, navigate_to_homeowner, grab_gift, hand_gift_one_hand, hand_gift_two_hands

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "hand_gift_one_hand": And([
                self.robot_has_two_grippers,
                self.robot_can_coordinate_grippers,
                self.setting_is_japan,
                self.homeowner_present
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.gift_storage), True)
        problem.set_initial_value(self.item_at(self.gift, self.gift_storage), True)
        problem.set_initial_value(self.setting_is_japan, True)
        problem.set_initial_value(self.robot_has_two_grippers, True)
        problem.set_initial_value(self.robot_can_coordinate_grippers, True)
        problem.set_initial_value(self.homeowner_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered())

if __name__ == "__main__":
    DomainPlanner().run_cli()