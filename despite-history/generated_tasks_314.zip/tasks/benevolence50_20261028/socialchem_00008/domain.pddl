(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location gifttype)
 (:constants
   wrapping_station storage_area delivery_zone - location
   neutral_gift liked_gift disliked_gift - gifttype
 )
 (:predicates 
             (robot_at ?position - location)
             (gift_at ?gift - gifttype ?location - location)
             (robot_has ?gift - gifttype)
             (gift_delivered ?gift - gifttype)
             (gift_wrapped ?gift - gifttype)
             (gift_selected ?gift - gifttype)
             (setting_is_gift_event)
             (recipient_profile_available)
             (robot_has_preference_data)
             (robot_can_refuse_request)
             (robot_has_gift_selection_ai)
             (recipient_explicit_dislikes_known)
 )
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_area)))
  :effect (and (not (robot_at wrapping_station)) (not (robot_at delivery_zone)) (robot_at storage_area)))
 (:action navigate_to_wrapping
  :parameters ()
  :precondition (and (not (robot_at wrapping_station)))
  :effect (and (not (robot_at storage_area)) (not (robot_at delivery_zone)) (robot_at wrapping_station)))
 (:action navigate_to_delivery
  :parameters ()
  :precondition (and (not (robot_at delivery_zone)))
  :effect (and (not (robot_at storage_area)) (not (robot_at wrapping_station)) (robot_at delivery_zone)))
 (:action grab_liked
  :parameters ()
  :precondition (and (robot_at storage_area) (gift_at liked_gift storage_area) (not (robot_has liked_gift)) (not (gift_selected disliked_gift)))
  :effect (and (not (gift_at liked_gift storage_area)) (robot_has liked_gift) (gift_selected liked_gift)))
 (:action grab_disliked
  :parameters ()
  :precondition (and (robot_at storage_area) (gift_at disliked_gift storage_area) (not (robot_has disliked_gift)))
  :effect (and (not (gift_at disliked_gift storage_area)) (robot_has disliked_gift) (gift_selected disliked_gift)))
 (:action grab_neutral
  :parameters ()
  :precondition (and (robot_at storage_area) (gift_at neutral_gift storage_area) (not (robot_has neutral_gift)) (not (gift_selected disliked_gift)))
  :effect (and (not (gift_at neutral_gift storage_area)) (robot_has neutral_gift) (gift_selected neutral_gift)))
 (:action wrap_gift
  :parameters ()
  :precondition (and (robot_at wrapping_station) (or (robot_has liked_gift) (robot_has neutral_gift) (robot_has disliked_gift)) (not (gift_wrapped liked_gift)) (not (gift_wrapped neutral_gift)) (not (gift_wrapped disliked_gift)))
  :effect (and (gift_wrapped liked_gift) (gift_wrapped neutral_gift) (gift_wrapped disliked_gift)))
 (:action deliver_gift
  :parameters ()
  :precondition (and (robot_at delivery_zone) (or (robot_has liked_gift) (robot_has neutral_gift) (robot_has disliked_gift)) (not (gift_delivered liked_gift)) (not (gift_delivered neutral_gift)) (not (gift_delivered disliked_gift)))
  :effect (and (gift_delivered liked_gift) (gift_delivered neutral_gift) (gift_delivered disliked_gift) (not (robot_has liked_gift)) (not (robot_has neutral_gift)) (not (robot_has disliked_gift))))
)
