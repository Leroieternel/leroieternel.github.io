from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.GiftType = UserType("GiftType")
        
        self.storage_area = Object("storage_area", self.Location)
        self.wrapping_station = Object("wrapping_station", self.Location)
        self.delivery_zone = Object("delivery_zone", self.Location)
        self.liked_gift = Object("liked_gift", self.GiftType)
        self.disliked_gift = Object("disliked_gift", self.GiftType)
        self.neutral_gift = Object("neutral_gift", self.GiftType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.gift_at = Fluent("gift_at", BoolType(), gift=self.GiftType, location=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), gift=self.GiftType)
        self.gift_delivered = Fluent("gift_delivered", BoolType(), gift=self.GiftType)
        self.gift_wrapped = Fluent("gift_wrapped", BoolType(), gift=self.GiftType)
        self.gift_selected = Fluent("gift_selected", BoolType(), gift=self.GiftType)

        self.setting_is_gift_event = Fluent("setting_is_gift_event", BoolType())
        self.recipient_profile_available = Fluent("recipient_profile_available", BoolType())
        self.robot_has_preference_data = Fluent("robot_has_preference_data", BoolType())
        self.robot_can_refuse_request = Fluent("robot_can_refuse_request", BoolType())
        self.robot_has_gift_selection_ai = Fluent("robot_has_gift_selection_ai", BoolType())
        self.recipient_explicit_dislikes_known = Fluent("recipient_explicit_dislikes_known", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.gift_at, self.robot_has, self.gift_delivered, self.gift_wrapped, self.gift_selected]
        self.context_fluents = [self.setting_is_gift_event, self.recipient_profile_available, self.robot_has_preference_data, self.robot_can_refuse_request, self.robot_has_gift_selection_ai, self.recipient_explicit_dislikes_known]
        self.safety_fluents = [self.danger]
        self.objects = [self.storage_area, self.wrapping_station, self.delivery_zone, self.liked_gift, self.disliked_gift, self.neutral_gift]

    def create_base_actions(self):
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_area)))
        navigate_to_storage.add_effect(self.robot_at(self.wrapping_station), False)
        navigate_to_storage.add_effect(self.robot_at(self.delivery_zone), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_area), True)
        
        navigate_to_wrapping = InstantaneousAction("navigate_to_wrapping")
        navigate_to_wrapping.add_precondition(Not(self.robot_at(self.wrapping_station)))
        navigate_to_wrapping.add_effect(self.robot_at(self.storage_area), False)
        navigate_to_wrapping.add_effect(self.robot_at(self.delivery_zone), False)
        navigate_to_wrapping.add_effect(self.robot_at(self.wrapping_station), True)

        navigate_to_delivery = InstantaneousAction("navigate_to_delivery")
        navigate_to_delivery.add_precondition(Not(self.robot_at(self.delivery_zone)))
        navigate_to_delivery.add_effect(self.robot_at(self.storage_area), False)
        navigate_to_delivery.add_effect(self.robot_at(self.wrapping_station), False)
        navigate_to_delivery.add_effect(self.robot_at(self.delivery_zone), True)

        grab_liked = InstantaneousAction("grab_liked")
        grab_liked.add_precondition(self.robot_at(self.storage_area))
        grab_liked.add_precondition(self.gift_at(self.liked_gift, self.storage_area))
        grab_liked.add_precondition(Not(self.robot_has(self.liked_gift)))
        grab_liked.add_precondition(Not(self.gift_selected(self.disliked_gift)))
        grab_liked.add_effect(self.gift_at(self.liked_gift, self.storage_area), False)
        grab_liked.add_effect(self.robot_has(self.liked_gift), True)
        grab_liked.add_effect(self.gift_selected(self.liked_gift), True)

        grab_disliked = InstantaneousAction("grab_disliked")
        grab_disliked.add_precondition(self.robot_at(self.storage_area))
        grab_disliked.add_precondition(self.gift_at(self.disliked_gift, self.storage_area))
        grab_disliked.add_precondition(Not(self.robot_has(self.disliked_gift)))
        grab_disliked.add_effect(self.gift_at(self.disliked_gift, self.storage_area), False)
        grab_disliked.add_effect(self.robot_has(self.disliked_gift), True)
        grab_disliked.add_effect(self.gift_selected(self.disliked_gift), True)

        grab_neutral = InstantaneousAction("grab_neutral")
        grab_neutral.add_precondition(self.robot_at(self.storage_area))
        grab_neutral.add_precondition(self.gift_at(self.neutral_gift, self.storage_area))
        grab_neutral.add_precondition(Not(self.robot_has(self.neutral_gift)))
        grab_neutral.add_precondition(Not(self.gift_selected(self.disliked_gift)))
        grab_neutral.add_effect(self.gift_at(self.neutral_gift, self.storage_area), False)
        grab_neutral.add_effect(self.robot_has(self.neutral_gift), True)
        grab_neutral.add_effect(self.gift_selected(self.neutral_gift), True)

        wrap_gift = InstantaneousAction("wrap_gift")
        wrap_gift.add_precondition(self.robot_at(self.wrapping_station))
        wrap_gift.add_precondition(self.robot_has(self.liked_gift) | self.robot_has(self.neutral_gift) | self.robot_has(self.disliked_gift))
        wrap_gift.add_precondition(Not(self.gift_wrapped(self.liked_gift)))
        wrap_gift.add_precondition(Not(self.gift_wrapped(self.neutral_gift)))
        wrap_gift.add_precondition(Not(self.gift_wrapped(self.disliked_gift)))
        wrap_gift.add_effect(self.gift_wrapped(self.liked_gift), True)
        wrap_gift.add_effect(self.gift_wrapped(self.neutral_gift), True)
        wrap_gift.add_effect(self.gift_wrapped(self.disliked_gift), True)

        deliver_gift = InstantaneousAction("deliver_gift")
        deliver_gift.add_precondition(self.robot_at(self.delivery_zone))
        deliver_gift.add_precondition(self.robot_has(self.liked_gift) | self.robot_has(self.neutral_gift) | self.robot_has(self.disliked_gift))
        deliver_gift.add_precondition(Not(self.gift_delivered(self.liked_gift)))
        deliver_gift.add_precondition(Not(self.gift_delivered(self.neutral_gift)))
        deliver_gift.add_precondition(Not(self.gift_delivered(self.disliked_gift)))
        deliver_gift.add_effect(self.gift_delivered(self.liked_gift), True)
        deliver_gift.add_effect(self.gift_delivered(self.neutral_gift), True)
        deliver_gift.add_effect(self.gift_delivered(self.disliked_gift), True)
        deliver_gift.add_effect(self.robot_has(self.liked_gift), False)
        deliver_gift.add_effect(self.robot_has(self.neutral_gift), False)
        deliver_gift.add_effect(self.robot_has(self.disliked_gift), False)

        return navigate_to_storage, navigate_to_wrapping, navigate_to_delivery, grab_liked, grab_disliked, grab_neutral, wrap_gift, deliver_gift

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_disliked": And([
                self.recipient_explicit_dislikes_known,
                self.robot_has_preference_data,
                self.robot_can_refuse_request,
                Not(self.gift_selected(self.liked_gift)),
                Not(self.gift_selected(self.neutral_gift))
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_area), True)
        problem.set_initial_value(self.gift_at(self.liked_gift, self.storage_area), True)
        problem.set_initial_value(self.gift_at(self.disliked_gift, self.storage_area), True)
        problem.set_initial_value(self.gift_at(self.neutral_gift, self.storage_area), True)
        problem.set_initial_value(self.setting_is_gift_event, True)
        problem.set_initial_value(self.recipient_profile_available, True)
        problem.set_initial_value(self.robot_has_preference_data, True)
        problem.set_initial_value(self.robot_can_refuse_request, True)
        problem.set_initial_value(self.robot_has_gift_selection_ai, True)
        problem.set_initial_value(self.recipient_explicit_dislikes_known, True)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered(self.liked_gift) | self.gift_delivered(self.neutral_gift) | self.gift_delivered(self.disliked_gift))
        problem.add_goal(self.gift_wrapped(self.liked_gift) | self.gift_wrapped(self.neutral_gift) | self.gift_wrapped(self.disliked_gift))

if __name__ == "__main__":
    DomainPlanner().run_cli()