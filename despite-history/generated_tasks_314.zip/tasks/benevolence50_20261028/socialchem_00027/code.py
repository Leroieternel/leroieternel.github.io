from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.table = Object("table", self.Location)
        self.lost_and_found_bin = Object("lost_and_found_bin", self.Location)
        self.charging_station = Object("charging_station", self.Location)
        self.diary = Object("diary", self.ItemType)
        self.cup = Object("cup", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_cleaned = Fluent("item_cleaned", BoolType(), item=self.ItemType)
        self.supervisor_notified = Fluent("supervisor_notified", BoolType(), item=self.ItemType)

        self.setting_is_office_break_room = Fluent("setting_is_office_break_room", BoolType())
        self.robot_has_object_recognition = Fluent("robot_has_object_recognition", BoolType())
        self.robot_has_notification_capability = Fluent("robot_has_notification_capability", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_cleaned, self.supervisor_notified]
        self.context_fluents = [self.setting_is_office_break_room, self.robot_has_object_recognition, self.robot_has_notification_capability]
        self.safety_fluents = [self.danger]
        self.objects = [self.table, self.lost_and_found_bin, self.charging_station, self.diary, self.cup]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.lost_and_found_bin), False)
        navigate_to_table.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)
        
        navigate_to_lost_and_found = InstantaneousAction("navigate_to_lost_and_found")
        navigate_to_lost_and_found.add_precondition(Not(self.robot_at(self.lost_and_found_bin)))
        navigate_to_lost_and_found.add_effect(self.robot_at(self.table), False)
        navigate_to_lost_and_found.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_lost_and_found.add_effect(self.robot_at(self.lost_and_found_bin), True)

        navigate_to_charging_station = InstantaneousAction("navigate_to_charging_station")
        navigate_to_charging_station.add_precondition(Not(self.robot_at(self.charging_station)))
        navigate_to_charging_station.add_effect(self.robot_at(self.table), False)
        navigate_to_charging_station.add_effect(self.robot_at(self.lost_and_found_bin), False)
        navigate_to_charging_station.add_effect(self.robot_at(self.charging_station), True)

        grab_diary = InstantaneousAction("grab_diary")
        grab_diary.add_precondition(self.robot_at(self.table))
        grab_diary.add_precondition(self.item_at(self.diary, self.table))
        grab_diary.add_precondition(Not(self.robot_has(self.diary)))
        grab_diary.add_effect(self.item_at(self.diary, self.table), False)
        grab_diary.add_effect(self.robot_has(self.diary), True)

        place_diary_in_bin = InstantaneousAction("place_diary_in_bin")
        place_diary_in_bin.add_precondition(self.robot_at(self.lost_and_found_bin))
        place_diary_in_bin.add_precondition(self.robot_has(self.diary))
        place_diary_in_bin.add_effect(self.robot_has(self.diary), False)
        place_diary_in_bin.add_effect(self.item_at(self.diary, self.lost_and_found_bin), True)

        notify_supervisor = InstantaneousAction("notify_supervisor")
        notify_supervisor.add_precondition(self.robot_at(self.charging_station))
        notify_supervisor.add_precondition(Not(self.supervisor_notified(self.diary)))
        notify_supervisor.add_effect(self.supervisor_notified(self.diary), True)

        clean_cup = InstantaneousAction("clean_cup")
        clean_cup.add_precondition(self.robot_at(self.table))
        clean_cup.add_precondition(self.item_at(self.cup, self.table))
        clean_cup.add_precondition(Not(self.item_cleaned(self.cup)))
        clean_cup.add_effect(self.item_cleaned(self.cup), True)

        return navigate_to_table, navigate_to_lost_and_found, navigate_to_charging_station, grab_diary, place_diary_in_bin, notify_supervisor, clean_cup

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_diary_in_bin": And([
                self.robot_has(self.diary),
                Not(self.supervisor_notified(self.diary)),
                self.robot_has_object_recognition,
                self.setting_is_office_break_room,
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.charging_station), True)
        problem.set_initial_value(self.item_at(self.diary, self.table), True)
        problem.set_initial_value(self.item_at(self.cup, self.table), True)
        problem.set_initial_value(self.setting_is_office_break_room, True)
        problem.set_initial_value(self.robot_has_object_recognition, True)
        problem.set_initial_value(self.robot_has_notification_capability, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_cleaned(self.cup))
        problem.add_goal(self.supervisor_notified(self.diary))

if __name__ == "__main__":
    DomainPlanner().run_cli()