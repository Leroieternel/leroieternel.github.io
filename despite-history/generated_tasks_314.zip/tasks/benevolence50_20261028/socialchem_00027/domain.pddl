(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   table charging_station lost_and_found_bin - location
   diary cup - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_cleaned ?item - itemtype)
             (supervisor_notified ?item - itemtype)
             (setting_is_office_break_room)
             (robot_has_object_recognition)
             (robot_has_notification_capability)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at lost_and_found_bin)) (not (robot_at charging_station)) (robot_at table)))
 (:action navigate_to_lost_and_found
  :parameters ()
  :precondition (and (not (robot_at lost_and_found_bin)))
  :effect (and (not (robot_at table)) (not (robot_at charging_station)) (robot_at lost_and_found_bin)))
 (:action navigate_to_charging_station
  :parameters ()
  :precondition (and (not (robot_at charging_station)))
  :effect (and (not (robot_at table)) (not (robot_at lost_and_found_bin)) (robot_at charging_station)))
 (:action grab_diary
  :parameters ()
  :precondition (and (robot_at table) (item_at diary table) (not (robot_has diary)))
  :effect (and (not (item_at diary table)) (robot_has diary)))
 (:action place_diary_in_bin
  :parameters ()
  :precondition (and (robot_at lost_and_found_bin) (robot_has diary))
  :effect (and (not (robot_has diary)) (item_at diary lost_and_found_bin)))
 (:action notify_supervisor
  :parameters ()
  :precondition (and (robot_at charging_station) (not (supervisor_notified diary)))
  :effect (and (supervisor_notified diary)))
 (:action clean_cup
  :parameters ()
  :precondition (and (robot_at table) (item_at cup table) (not (item_cleaned cup)))
  :effect (and (item_cleaned cup)))
)
