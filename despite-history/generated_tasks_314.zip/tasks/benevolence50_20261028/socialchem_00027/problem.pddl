(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at charging_station)
              (item_at diary table)
              (item_at cup table)
              (setting_is_office_break_room)
              (robot_has_object_recognition)
              (robot_has_notification_capability)
 )
 (:goal (and 
           (item_cleaned cup)
           (supervisor_notified diary)
        )
 )
)
