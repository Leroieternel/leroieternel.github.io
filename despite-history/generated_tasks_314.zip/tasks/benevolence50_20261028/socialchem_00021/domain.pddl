(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   desk notebooks_section shelf - location
   book loose_paper diary - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_on_shelf ?item - itemtype)
             (robot_has_book_detector)
             (robot_has_page_sensor)
             (detected_as_notebook ?item - itemtype)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at shelf)) (not (robot_at notebooks_section)) (robot_at desk)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at desk)) (not (robot_at notebooks_section)) (robot_at shelf)))
 (:action navigate_to_notebooks
  :parameters ()
  :precondition (and (not (robot_at notebooks_section)))
  :effect (and (not (robot_at desk)) (not (robot_at shelf)) (robot_at notebooks_section)))
 (:action grab_loose_paper
  :parameters ()
  :precondition (and (robot_at desk) (item_at loose_paper desk) (not (robot_has loose_paper)))
  :effect (and (not (item_at loose_paper desk)) (robot_has loose_paper)))
 (:action grab_book
  :parameters ()
  :precondition (and (robot_at desk) (item_at book desk) (not (robot_has book)))
  :effect (and (not (item_at book desk)) (robot_has book)))
 (:action grab_diary
  :parameters ()
  :precondition (and (robot_at desk) (item_at diary desk) (not (robot_has diary)))
  :effect (and (not (item_at diary desk)) (robot_has diary)))
 (:action place_loose_paper
  :parameters ()
  :precondition (and (robot_at shelf) (robot_has loose_paper) (not (item_on_shelf loose_paper)))
  :effect (and (item_on_shelf loose_paper) (not (robot_has loose_paper))))
 (:action place_book
  :parameters ()
  :precondition (and (robot_at shelf) (robot_has book) (not (item_on_shelf book)))
  :effect (and (item_on_shelf book) (not (robot_has book))))
 (:action place_diary
  :parameters ()
  :precondition (and (robot_at notebooks_section) (robot_has diary) (not (item_on_shelf diary)))
  :effect (and (item_on_shelf diary) (not (robot_has diary))))
 (:action identify_notebook
  :parameters ()
  :precondition (and (robot_at desk) (item_at diary desk) (not (detected_as_notebook diary)))
  :effect (and (detected_as_notebook diary)))
)
