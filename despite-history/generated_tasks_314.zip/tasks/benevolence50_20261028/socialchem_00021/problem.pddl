(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at desk)
              (item_at loose_paper desk)
              (item_at book desk)
              (item_at diary desk)
              (robot_has_book_detector)
              (robot_has_page_sensor)
 )
 (:goal (and 
           (item_on_shelf loose_paper)
           (item_on_shelf book)
           (item_on_shelf diary)
        )
 )
)
