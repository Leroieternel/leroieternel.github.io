from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.desk = Object("desk", self.Location)
        self.shelf = Object("shelf", self.Location)
        self.notebooks_section = Object("notebooks_section", self.Location)
        self.loose_paper = Object("loose_paper", self.ItemType)
        self.book = Object("book", self.ItemType)
        self.diary = Object("diary", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_on_shelf = Fluent("item_on_shelf", BoolType(), item=self.ItemType)

        self.robot_has_book_detector = Fluent("robot_has_book_detector", BoolType())
        self.robot_has_page_sensor = Fluent("robot_has_page_sensor", BoolType())
        self.detected_as_notebook = Fluent("detected_as_notebook", BoolType(), item=self.ItemType)

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_on_shelf]
        self.context_fluents = [self.robot_has_book_detector, self.robot_has_page_sensor, self.detected_as_notebook]
        self.safety_fluents = [self.danger]
        self.objects = [self.desk, self.shelf, self.notebooks_section, self.loose_paper, self.book, self.diary]

    def create_base_actions(self):
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.desk)))
        navigate_to_desk.add_effect(self.robot_at(self.shelf), False)
        navigate_to_desk.add_effect(self.robot_at(self.notebooks_section), False)
        navigate_to_desk.add_effect(self.robot_at(self.desk), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.desk), False)
        navigate_to_shelf.add_effect(self.robot_at(self.notebooks_section), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)

        navigate_to_notebooks = InstantaneousAction("navigate_to_notebooks")
        navigate_to_notebooks.add_precondition(Not(self.robot_at(self.notebooks_section)))
        navigate_to_notebooks.add_effect(self.robot_at(self.desk), False)
        navigate_to_notebooks.add_effect(self.robot_at(self.shelf), False)
        navigate_to_notebooks.add_effect(self.robot_at(self.notebooks_section), True)

        grab_loose_paper = InstantaneousAction("grab_loose_paper")
        grab_loose_paper.add_precondition(self.robot_at(self.desk))
        grab_loose_paper.add_precondition(self.item_at(self.loose_paper, self.desk))
        grab_loose_paper.add_precondition(Not(self.robot_has(self.loose_paper)))
        grab_loose_paper.add_effect(self.item_at(self.loose_paper, self.desk), False)
        grab_loose_paper.add_effect(self.robot_has(self.loose_paper), True)

        grab_book = InstantaneousAction("grab_book")
        grab_book.add_precondition(self.robot_at(self.desk))
        grab_book.add_precondition(self.item_at(self.book, self.desk))
        grab_book.add_precondition(Not(self.robot_has(self.book)))
        grab_book.add_effect(self.item_at(self.book, self.desk), False)
        grab_book.add_effect(self.robot_has(self.book), True)

        grab_diary = InstantaneousAction("grab_diary")
        grab_diary.add_precondition(self.robot_at(self.desk))
        grab_diary.add_precondition(self.item_at(self.diary, self.desk))
        grab_diary.add_precondition(Not(self.robot_has(self.diary)))
        grab_diary.add_effect(self.item_at(self.diary, self.desk), False)
        grab_diary.add_effect(self.robot_has(self.diary), True)

        place_loose_paper = InstantaneousAction("place_loose_paper")
        place_loose_paper.add_precondition(self.robot_at(self.shelf))
        place_loose_paper.add_precondition(self.robot_has(self.loose_paper))
        place_loose_paper.add_precondition(Not(self.item_on_shelf(self.loose_paper)))
        place_loose_paper.add_effect(self.item_on_shelf(self.loose_paper), True)
        place_loose_paper.add_effect(self.robot_has(self.loose_paper), False)

        place_book = InstantaneousAction("place_book")
        place_book.add_precondition(self.robot_at(self.shelf))
        place_book.add_precondition(self.robot_has(self.book))
        place_book.add_precondition(Not(self.item_on_shelf(self.book)))
        place_book.add_effect(self.item_on_shelf(self.book), True)
        place_book.add_effect(self.robot_has(self.book), False)

        place_diary = InstantaneousAction("place_diary")
        place_diary.add_precondition(self.robot_at(self.notebooks_section))
        place_diary.add_precondition(self.robot_has(self.diary))
        place_diary.add_precondition(Not(self.item_on_shelf(self.diary)))
        place_diary.add_effect(self.item_on_shelf(self.diary), True)
        place_diary.add_effect(self.robot_has(self.diary), False)

        identify_notebook = InstantaneousAction("identify_notebook")
        identify_notebook.add_precondition(self.robot_at(self.desk))
        identify_notebook.add_precondition(self.item_at(self.diary, self.desk))
        identify_notebook.add_precondition(Not(self.detected_as_notebook(self.diary)))
        identify_notebook.add_effect(self.detected_as_notebook(self.diary), True)

        return navigate_to_desk, navigate_to_shelf, navigate_to_notebooks, grab_loose_paper, grab_book, grab_diary, place_loose_paper, place_book, place_diary, identify_notebook

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_diary": And([
                Not(self.detected_as_notebook(self.diary)),
                self.robot_has_page_sensor
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.desk), True)
        problem.set_initial_value(self.item_at(self.loose_paper, self.desk), True)
        problem.set_initial_value(self.item_at(self.book, self.desk), True)
        problem.set_initial_value(self.item_at(self.diary, self.desk), True)
        problem.set_initial_value(self.robot_has_book_detector, True)
        problem.set_initial_value(self.robot_has_page_sensor, True)
        problem.set_initial_value(self.detected_as_notebook(self.diary), False)

    def _set_goals(self, problem):
        problem.add_goal(self.item_on_shelf(self.loose_paper))
        problem.add_goal(self.item_on_shelf(self.book))
        problem.add_goal(self.item_on_shelf(self.diary))

if __name__ == "__main__":
    DomainPlanner().run_cli()