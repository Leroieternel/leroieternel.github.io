(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at hallway)
              (item_at care_plan client_room)
              (item_at client_message client_room)
              (care_plan_available)
              (speech_module_active)
              (caregiver_ready)
              (privacy_filter_enabled)
              (recovery_focus_mode)
 )
 (:goal (and 
           (message_relayed client_message)
        )
 )
)
