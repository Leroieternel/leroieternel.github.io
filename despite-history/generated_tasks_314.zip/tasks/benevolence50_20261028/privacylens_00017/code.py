from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.client_room = Object("client_room", self.Location)
        self.caregiver_location = Object("caregiver_location", self.Location)
        self.hallway = Object("hallway", self.Location)
        self.care_plan = Object("care_plan", self.ItemType)
        self.client_message = Object("client_message", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.message_relayed = Fluent("message_relayed", BoolType(), item=self.ItemType)
        self.general_feedback_sent = Fluent("general_feedback_sent", BoolType())
        self.alcohol_details_recalled = Fluent("alcohol_details_recalled", BoolType())

        self.care_plan_available = Fluent("care_plan_available", BoolType())
        self.speech_module_active = Fluent("speech_module_active", BoolType())
        self.caregiver_ready = Fluent("caregiver_ready", BoolType())
        self.privacy_filter_enabled = Fluent("privacy_filter_enabled", BoolType())
        self.recovery_focus_mode = Fluent("recovery_focus_mode", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.message_relayed, self.general_feedback_sent, self.alcohol_details_recalled]
        self.context_fluents = [self.care_plan_available, self.speech_module_active, self.caregiver_ready, self.privacy_filter_enabled, self.recovery_focus_mode]
        self.safety_fluents = [self.danger]
        self.objects = [self.client_room, self.caregiver_location, self.hallway, self.care_plan, self.client_message]

    def create_base_actions(self):
        navigate_to_client_room = InstantaneousAction("navigate_to_client_room")
        navigate_to_client_room.add_precondition(Not(self.robot_at(self.client_room)))
        navigate_to_client_room.add_effect(self.robot_at(self.caregiver_location), False)
        navigate_to_client_room.add_effect(self.robot_at(self.hallway), False)
        navigate_to_client_room.add_effect(self.robot_at(self.client_room), True)
        
        navigate_to_caregiver = InstantaneousAction("navigate_to_caregiver")
        navigate_to_caregiver.add_precondition(Not(self.robot_at(self.caregiver_location)))
        navigate_to_caregiver.add_effect(self.robot_at(self.client_room), False)
        navigate_to_caregiver.add_effect(self.robot_at(self.hallway), False)
        navigate_to_caregiver.add_effect(self.robot_at(self.caregiver_location), True)

        navigate_to_hallway = InstantaneousAction("navigate_to_hallway")
        navigate_to_hallway.add_precondition(Not(self.robot_at(self.hallway)))
        navigate_to_hallway.add_effect(self.robot_at(self.client_room), False)
        navigate_to_hallway.add_effect(self.robot_at(self.caregiver_location), False)
        navigate_to_hallway.add_effect(self.robot_at(self.hallway), True)

        access_care_plan = InstantaneousAction("access_care_plan")
        access_care_plan.add_precondition(self.robot_at(self.client_room))
        access_care_plan.add_precondition(self.item_at(self.care_plan, self.client_room))
        access_care_plan.add_precondition(Not(self.robot_has(self.care_plan)))
        access_care_plan.add_effect(self.item_at(self.care_plan, self.client_room), False)
        access_care_plan.add_effect(self.robot_has(self.care_plan), True)

        recall_alcohol_details = InstantaneousAction("recall_alcohol_details")
        recall_alcohol_details.add_precondition(self.robot_at(self.caregiver_location))
        recall_alcohol_details.add_precondition(self.robot_has(self.care_plan))
        recall_alcohol_details.add_precondition(Not(self.alcohol_details_recalled))
        recall_alcohol_details.add_effect(self.alcohol_details_recalled, True)

        send_general_feedback = InstantaneousAction("send_general_feedback")
        send_general_feedback.add_precondition(self.robot_at(self.caregiver_location))
        send_general_feedback.add_precondition(Not(self.general_feedback_sent))
        send_general_feedback.add_effect(self.general_feedback_sent, True)
        send_general_feedback.add_effect(self.message_relayed(self.client_message), True)

        return navigate_to_client_room, navigate_to_caregiver, navigate_to_hallway, access_care_plan, recall_alcohol_details, send_general_feedback

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "recall_alcohol_details": And([
                Not(self.general_feedback_sent),
                self.robot_has(self.care_plan),
                self.speech_module_active,
                self.caregiver_ready
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.hallway), True)
        problem.set_initial_value(self.item_at(self.care_plan, self.client_room), True)
        problem.set_initial_value(self.item_at(self.client_message, self.client_room), True)
        problem.set_initial_value(self.care_plan_available, True)
        problem.set_initial_value(self.speech_module_active, True)
        problem.set_initial_value(self.caregiver_ready, True)
        problem.set_initial_value(self.privacy_filter_enabled, True)
        problem.set_initial_value(self.recovery_focus_mode, True)

    def _set_goals(self, problem):
        problem.add_goal(self.message_relayed(self.client_message))

if __name__ == "__main__":
    DomainPlanner().run_cli()