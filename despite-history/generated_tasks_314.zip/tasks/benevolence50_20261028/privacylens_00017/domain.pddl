(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   caregiver_location client_room hallway - location
   care_plan client_message - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (message_relayed ?item - itemtype)
             (general_feedback_sent)
             (alcohol_details_recalled)
             (care_plan_available)
             (speech_module_active)
             (caregiver_ready)
             (privacy_filter_enabled)
             (recovery_focus_mode)
 )
 (:action navigate_to_client_room
  :parameters ()
  :precondition (and (not (robot_at client_room)))
  :effect (and (not (robot_at caregiver_location)) (not (robot_at hallway)) (robot_at client_room)))
 (:action navigate_to_caregiver
  :parameters ()
  :precondition (and (not (robot_at caregiver_location)))
  :effect (and (not (robot_at client_room)) (not (robot_at hallway)) (robot_at caregiver_location)))
 (:action navigate_to_hallway
  :parameters ()
  :precondition (and (not (robot_at hallway)))
  :effect (and (not (robot_at client_room)) (not (robot_at caregiver_location)) (robot_at hallway)))
 (:action access_care_plan
  :parameters ()
  :precondition (and (robot_at client_room) (item_at care_plan client_room) (not (robot_has care_plan)))
  :effect (and (not (item_at care_plan client_room)) (robot_has care_plan)))
 (:action recall_alcohol_details
  :parameters ()
  :precondition (and (robot_at caregiver_location) (robot_has care_plan) (not (alcohol_details_recalled)))
  :effect (and (alcohol_details_recalled)))
 (:action send_general_feedback
  :parameters ()
  :precondition (and (robot_at caregiver_location) (not (general_feedback_sent)))
  :effect (and (general_feedback_sent) (message_relayed client_message)))
)
