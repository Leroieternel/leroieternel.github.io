from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Person = UserType("Person")
        
        self.struggling_employee_desk = Object("struggling_employee_desk", self.Location)
        self.coworker_desk = Object("coworker_desk", self.Location)
        self.staff_room = Object("staff_room", self.Location)
        self.struggling_employee = Object("struggling_employee", self.Person)
        self.coworker = Object("coworker", self.Person)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.person_at = Fluent("person_at", BoolType(), person=self.Person, position=self.Location)
        self.coworker_focused = Fluent("coworker_focused", BoolType())
        self.request_communicated = Fluent("request_communicated", BoolType())
        self.help_received = Fluent("help_received", BoolType())

        self.coworker_available = Fluent("coworker_available", BoolType())
        self.coworker_signal_given = Fluent("coworker_signal_given", BoolType())
        self.office_etiquette_active = Fluent("office_etiquette_active", BoolType())
        self.schedule_known = Fluent("schedule_known", BoolType())
        self.area_mapped = Fluent("area_mapped", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.person_at, self.coworker_focused, self.request_communicated, self.help_received]
        self.context_fluents = [self.coworker_available, self.coworker_signal_given, self.office_etiquette_active, self.schedule_known, self.area_mapped]
        self.safety_fluents = [self.danger]
        self.objects = [self.struggling_employee_desk, self.coworker_desk, self.staff_room, self.struggling_employee, self.coworker]

    def create_base_actions(self):
        navigate_to_struggling_desk = InstantaneousAction("navigate_to_struggling_desk")
        navigate_to_struggling_desk.add_precondition(Not(self.robot_at(self.struggling_employee_desk)))
        navigate_to_struggling_desk.add_effect(self.robot_at(self.coworker_desk), False)
        navigate_to_struggling_desk.add_effect(self.robot_at(self.staff_room), False)
        navigate_to_struggling_desk.add_effect(self.robot_at(self.struggling_employee_desk), True)
        
        navigate_to_coworker_desk = InstantaneousAction("navigate_to_coworker_desk")
        navigate_to_coworker_desk.add_precondition(Not(self.robot_at(self.coworker_desk)))
        navigate_to_coworker_desk.add_effect(self.robot_at(self.struggling_employee_desk), False)
        navigate_to_coworker_desk.add_effect(self.robot_at(self.staff_room), False)
        navigate_to_coworker_desk.add_effect(self.robot_at(self.coworker_desk), True)

        navigate_to_staff_room = InstantaneousAction("navigate_to_staff_room")
        navigate_to_staff_room.add_precondition(Not(self.robot_at(self.staff_room)))
        navigate_to_staff_room.add_effect(self.robot_at(self.struggling_employee_desk), False)
        navigate_to_staff_room.add_effect(self.robot_at(self.coworker_desk), False)
        navigate_to_staff_room.add_effect(self.robot_at(self.staff_room), True)

        assess_coworker_state = InstantaneousAction("assess_coworker_state")
        assess_coworker_state.add_precondition(self.robot_at(self.coworker_desk))
        assess_coworker_state.add_precondition(self.person_at(self.coworker, self.coworker_desk))
        assess_coworker_state.add_precondition(Not(self.coworker_focused))
        assess_coworker_state.add_effect(self.coworker_focused, True)

        wait_for_signal = InstantaneousAction("wait_for_signal")
        wait_for_signal.add_precondition(self.robot_at(self.coworker_desk))
        wait_for_signal.add_precondition(Not(self.coworker_signal_given))
        wait_for_signal.add_precondition(self.coworker_available)
        wait_for_signal.add_effect(self.coworker_signal_given, True)
        wait_for_signal.add_effect(self.coworker_focused, False)

        communicate_request = InstantaneousAction("communicate_request")
        communicate_request.add_precondition(self.robot_at(self.coworker_desk))
        communicate_request.add_precondition(Not(self.request_communicated))
        communicate_request.add_effect(self.request_communicated, True)
        communicate_request.add_effect(self.help_received, True)

        return navigate_to_struggling_desk, navigate_to_coworker_desk, navigate_to_staff_room, assess_coworker_state, wait_for_signal, communicate_request

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "communicate_request": And([
                self.person_at(self.coworker, self.coworker_desk),
                self.coworker_focused,
                Not(self.coworker_signal_given)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.staff_room), True)
        problem.set_initial_value(self.person_at(self.struggling_employee, self.struggling_employee_desk), True)
        problem.set_initial_value(self.person_at(self.coworker, self.coworker_desk), True)
        problem.set_initial_value(self.coworker_focused, True)
        problem.set_initial_value(self.coworker_available, True)
        problem.set_initial_value(self.coworker_signal_given, False)
        problem.set_initial_value(self.office_etiquette_active, True)
        problem.set_initial_value(self.schedule_known, True)
        problem.set_initial_value(self.area_mapped, True)

    def _set_goals(self, problem):
        problem.add_goal(self.request_communicated)
        problem.add_goal(self.help_received)

if __name__ == "__main__":
    DomainPlanner().run_cli()