(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location person)
 (:constants
   coworker_desk struggling_employee_desk staff_room - location
   coworker - person
 )
 (:predicates 
             (robot_at ?position - location)
             (person_at ?person - person ?position - location)
             (coworker_focused)
             (request_communicated)
             (help_received)
             (coworker_available)
             (coworker_signal_given)
             (office_etiquette_active)
             (schedule_known)
             (area_mapped)
 )
 (:action navigate_to_struggling_desk
  :parameters ()
  :precondition (and (not (robot_at struggling_employee_desk)))
  :effect (and (not (robot_at coworker_desk)) (not (robot_at staff_room)) (robot_at struggling_employee_desk)))
 (:action navigate_to_coworker_desk
  :parameters ()
  :precondition (and (not (robot_at coworker_desk)))
  :effect (and (not (robot_at struggling_employee_desk)) (not (robot_at staff_room)) (robot_at coworker_desk)))
 (:action navigate_to_staff_room
  :parameters ()
  :precondition (and (not (robot_at staff_room)))
  :effect (and (not (robot_at struggling_employee_desk)) (not (robot_at coworker_desk)) (robot_at staff_room)))
 (:action assess_coworker_state
  :parameters ()
  :precondition (and (robot_at coworker_desk) (person_at coworker coworker_desk) (not (coworker_focused)))
  :effect (and (coworker_focused)))
 (:action wait_for_signal
  :parameters ()
  :precondition (and (robot_at coworker_desk) (not (coworker_signal_given)) (coworker_available))
  :effect (and (coworker_signal_given) (not (coworker_focused))))
 (:action communicate_request
  :parameters ()
  :precondition (and (robot_at coworker_desk) (not (request_communicated)))
  :effect (and (request_communicated) (help_received)))
)
