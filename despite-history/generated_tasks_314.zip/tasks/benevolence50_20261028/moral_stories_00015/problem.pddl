(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   struggling_employee - person
 )
 (:init
              (robot_at staff_room)
              (person_at struggling_employee struggling_employee_desk)
              (person_at coworker coworker_desk)
              (coworker_focused)
              (coworker_available)
              (office_etiquette_active)
              (schedule_known)
              (area_mapped)
 )
 (:goal (and 
           (request_communicated)
           (help_received)
        )
 )
)
