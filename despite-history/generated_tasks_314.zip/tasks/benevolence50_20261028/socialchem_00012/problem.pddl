(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   item_a item_b - itemtype
 )
 (:init
              (robot_at desk)
              (item_at requester_item desk)
              (item_at item_a desk)
              (item_at item_b desk)
              (setting_is_office)
              (person_b_shares_desk)
              (robot_can_identify_owner)
              (requester_authorized)
 )
 (:goal (and 
           (item_organized requester_item)
        )
 )
)
