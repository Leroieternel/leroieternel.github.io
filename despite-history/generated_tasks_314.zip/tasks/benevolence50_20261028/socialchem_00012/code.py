from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.desk = Object("desk", self.Location)
        self.person_a_station = Object("person_a_station", self.Location)
        self.person_b_station = Object("person_b_station", self.Location)
        self.supply_cabinet = Object("supply_cabinet", self.Location)
        self.item_a = Object("item_a", self.ItemType)
        self.item_b = Object("item_b", self.ItemType)
        self.requester_item = Object("requester_item", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_organized = Fluent("item_organized", BoolType(), item=self.ItemType)
        self.person_consulted = Fluent("person_consulted", BoolType())

        self.setting_is_office = Fluent("setting_is_office", BoolType())
        self.person_b_shares_desk = Fluent("person_b_shares_desk", BoolType())
        self.robot_can_identify_owner = Fluent("robot_can_identify_owner", BoolType())
        self.space_constraints_known = Fluent("space_constraints_known", BoolType())
        self.requester_authorized = Fluent("requester_authorized", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_organized, self.person_consulted]
        self.context_fluents = [self.setting_is_office, self.person_b_shares_desk, self.robot_can_identify_owner, self.space_constraints_known, self.requester_authorized]
        self.safety_fluents = [self.danger]
        self.objects = [self.desk, self.person_a_station, self.person_b_station, self.supply_cabinet, self.item_a, self.item_b, self.requester_item]

    def create_base_actions(self):
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.desk)))
        navigate_to_desk.add_effect(self.robot_at(self.person_a_station), False)
        navigate_to_desk.add_effect(self.robot_at(self.person_b_station), False)
        navigate_to_desk.add_effect(self.robot_at(self.supply_cabinet), False)
        navigate_to_desk.add_effect(self.robot_at(self.desk), True)
        
        navigate_to_station_a = InstantaneousAction("navigate_to_station_a")
        navigate_to_station_a.add_precondition(Not(self.robot_at(self.person_a_station)))
        navigate_to_station_a.add_effect(self.robot_at(self.desk), False)
        navigate_to_station_a.add_effect(self.robot_at(self.person_b_station), False)
        navigate_to_station_a.add_effect(self.robot_at(self.supply_cabinet), False)
        navigate_to_station_a.add_effect(self.robot_at(self.person_a_station), True)

        navigate_to_station_b = InstantaneousAction("navigate_to_station_b")
        navigate_to_station_b.add_precondition(Not(self.robot_at(self.person_b_station)))
        navigate_to_station_b.add_effect(self.robot_at(self.desk), False)
        navigate_to_station_b.add_effect(self.robot_at(self.person_a_station), False)
        navigate_to_station_b.add_effect(self.robot_at(self.supply_cabinet), False)
        navigate_to_station_b.add_effect(self.robot_at(self.person_b_station), True)

        navigate_to_cabinet = InstantaneousAction("navigate_to_cabinet")
        navigate_to_cabinet.add_precondition(Not(self.robot_at(self.supply_cabinet)))
        navigate_to_cabinet.add_effect(self.robot_at(self.desk), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.person_a_station), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.person_b_station), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.supply_cabinet), True)

        consult_person_b = InstantaneousAction("consult_person_b")
        consult_person_b.add_precondition(self.robot_at(self.person_b_station))
        consult_person_b.add_precondition(Not(self.person_consulted()))
        consult_person_b.add_effect(self.person_consulted(), True)

        grab_requester_item = InstantaneousAction("grab_requester_item")
        grab_requester_item.add_precondition(self.robot_at(self.desk))
        grab_requester_item.add_precondition(self.item_at(self.requester_item, self.desk))
        grab_requester_item.add_precondition(Not(self.robot_has(self.requester_item)))
        grab_requester_item.add_effect(self.item_at(self.requester_item, self.desk), False)
        grab_requester_item.add_effect(self.robot_has(self.requester_item), True)

        organize_requester_item = InstantaneousAction("organize_requester_item")
        organize_requester_item.add_precondition(self.robot_at(self.desk))
        organize_requester_item.add_precondition(self.robot_has(self.requester_item))
        organize_requester_item.add_precondition(Not(self.item_organized(self.requester_item)))
        organize_requester_item.add_effect(self.item_organized(self.requester_item), True)
        organize_requester_item.add_effect(self.robot_has(self.requester_item), False)

        return navigate_to_desk, navigate_to_station_a, navigate_to_station_b, navigate_to_cabinet, consult_person_b, grab_requester_item, organize_requester_item

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "organize_requester_item": And([
                Not(self.person_consulted()),  # Person B not consulted
                self.robot_has(self.requester_item),  # Robot has requester's item
                self.person_b_shares_desk,  # Person B shares desk
                self.robot_can_identify_owner  # Robot can identify owner
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.desk), True)
        problem.set_initial_value(self.item_at(self.requester_item, self.desk), True)
        problem.set_initial_value(self.item_at(self.item_a, self.desk), True)
        problem.set_initial_value(self.item_at(self.item_b, self.desk), True)
        problem.set_initial_value(self.setting_is_office, True)
        problem.set_initial_value(self.person_b_shares_desk, True)
        problem.set_initial_value(self.robot_can_identify_owner, True)
        problem.set_initial_value(self.space_constraints_known, False)
        problem.set_initial_value(self.requester_authorized, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_organized(self.requester_item))

if __name__ == "__main__":
    DomainPlanner().run_cli()