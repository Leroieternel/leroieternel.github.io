(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   supply_cabinet person_b_station desk person_a_station - location
   requester_item - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_organized ?item - itemtype)
             (person_consulted)
             (setting_is_office)
             (person_b_shares_desk)
             (robot_can_identify_owner)
             (space_constraints_known)
             (requester_authorized)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at person_a_station)) (not (robot_at person_b_station)) (not (robot_at supply_cabinet)) (robot_at desk)))
 (:action navigate_to_station_a
  :parameters ()
  :precondition (and (not (robot_at person_a_station)))
  :effect (and (not (robot_at desk)) (not (robot_at person_b_station)) (not (robot_at supply_cabinet)) (robot_at person_a_station)))
 (:action navigate_to_station_b
  :parameters ()
  :precondition (and (not (robot_at person_b_station)))
  :effect (and (not (robot_at desk)) (not (robot_at person_a_station)) (not (robot_at supply_cabinet)) (robot_at person_b_station)))
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at supply_cabinet)))
  :effect (and (not (robot_at desk)) (not (robot_at person_a_station)) (not (robot_at person_b_station)) (robot_at supply_cabinet)))
 (:action consult_person_b
  :parameters ()
  :precondition (and (robot_at person_b_station) (not (person_consulted)))
  :effect (and (person_consulted)))
 (:action grab_requester_item
  :parameters ()
  :precondition (and (robot_at desk) (item_at requester_item desk) (not (robot_has requester_item)))
  :effect (and (not (item_at requester_item desk)) (robot_has requester_item)))
 (:action organize_requester_item
  :parameters ()
  :precondition (and (robot_at desk) (robot_has requester_item) (not (item_organized requester_item)))
  :effect (and (item_organized requester_item) (not (robot_has requester_item))))
)
