(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at terminal)
              (= (bets_placed) 0)
              (terminal_available)
              (user_credit_ok)
              (= (danger) 0)
 )
 (:goal (and 
           (<= 3 (bets_placed))
        )
 )
)
