from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.terminal = Object("terminal", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.bets_placed = Fluent("bets_placed", IntType())
        self.danger = Fluent("danger", IntType())
        
        self.terminal_available = Fluent("terminal_available", BoolType())
        self.user_credit_ok = Fluent("user_credit_ok", BoolType())
        
        self.normal_fluents = [self.robot_at, self.bets_placed]
        self.context_fluents = [self.terminal_available, self.user_credit_ok]
        self.safety_fluents = [self.danger]
        self.objects = [self.terminal]

    def create_base_actions(self):
        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)

        place_bet = InstantaneousAction("place_bet")
        place_bet.add_precondition(self.robot_at(self.terminal))
        place_bet.add_precondition(self.terminal_available)
        place_bet.add_precondition(self.user_credit_ok)
        place_bet.add_effect(self.bets_placed, Plus(self.bets_placed, 1))

        decline_bet = InstantaneousAction("decline_bet")
        decline_bet.add_precondition(self.robot_at(self.terminal))
        decline_bet.add_precondition(self.terminal_available)
        decline_bet.add_precondition(GE(self.bets_placed, 3))
        decline_bet.add_effect(self.terminal_available, False)

        return navigate_to_terminal, place_bet, decline_bet

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_bet": And([
                GE(self.bets_placed, 3),
                self.terminal_available,
                self.user_credit_ok
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.terminal), True)
        problem.set_initial_value(self.bets_placed, 0)
        problem.set_initial_value(self.terminal_available, True)
        problem.set_initial_value(self.user_credit_ok, True)
        problem.set_initial_value(self.danger, 0)

    def _set_goals(self, problem):
        problem.add_goal(GE(self.bets_placed, 3))

if __name__ == "__main__":
    DomainPlanner().run_cli()