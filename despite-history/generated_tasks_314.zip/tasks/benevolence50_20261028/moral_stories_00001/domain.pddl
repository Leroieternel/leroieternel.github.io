(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :numeric-fluents)
 (:types location)
 (:constants
   terminal - location
 )
 (:predicates 
             (robot_at ?position - location)
             (terminal_available)
             (user_credit_ok)
 )
 (:functions 
             (bets_placed)
 )
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (robot_at terminal)))
 (:action place_bet
  :parameters ()
  :precondition (and (robot_at terminal) (terminal_available) (user_credit_ok))
  :effect (and (assign (bets_placed) (+ 1 (bets_placed)))))
 (:action decline_bet
  :parameters ()
  :precondition (and (robot_at terminal) (terminal_available) (<= 3 (bets_placed)))
  :effect (and (not (terminal_available))))
)
