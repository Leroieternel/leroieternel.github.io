(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   editor_desk staff_office hallway - location
   envelope manuscript - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_sealed ?item - itemtype)
             (item_delivered ?item - itemtype)
             (hallway_has_unauthorized_personnel)
             (robot_has_badge_scanner)
             (envelope_available)
             (secure_delivery_protocol_active)
             (document_visible ?item - itemtype)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at editor_desk)))
  :effect (and (not (robot_at staff_office)) (not (robot_at hallway)) (robot_at editor_desk)))
 (:action navigate_to_hallway
  :parameters ()
  :precondition (and (not (robot_at hallway)))
  :effect (and (not (robot_at editor_desk)) (not (robot_at staff_office)) (robot_at hallway)))
 (:action navigate_to_office
  :parameters ()
  :precondition (and (not (robot_at staff_office)))
  :effect (and (not (robot_at editor_desk)) (not (robot_at hallway)) (robot_at staff_office)))
 (:action grab_manuscript
  :parameters ()
  :precondition (and (robot_at editor_desk) (item_at manuscript editor_desk) (not (robot_has manuscript)))
  :effect (and (not (item_at manuscript editor_desk)) (robot_has manuscript) (document_visible manuscript)))
 (:action seal_in_envelope
  :parameters ()
  :precondition (and (robot_has manuscript) (item_at envelope editor_desk) (not (item_sealed manuscript)))
  :effect (and (item_sealed manuscript) (not (document_visible manuscript)) (not (item_at envelope editor_desk)) (robot_has envelope)))
 (:action deliver_to_staff
  :parameters ()
  :precondition (and (robot_at staff_office) (robot_has manuscript) (not (item_delivered manuscript)))
  :effect (and (item_delivered manuscript) (not (robot_has manuscript))))
)
