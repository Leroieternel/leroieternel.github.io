from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.editor_desk = Object("editor_desk", self.Location)
        self.staff_office = Object("staff_office", self.Location)
        self.hallway = Object("hallway", self.Location)
        self.manuscript = Object("manuscript", self.ItemType)
        self.envelope = Object("envelope", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_sealed = Fluent("item_sealed", BoolType(), item=self.ItemType)
        self.item_delivered = Fluent("item_delivered", BoolType(), item=self.ItemType)

        self.hallway_has_unauthorized_personnel = Fluent("hallway_has_unauthorized_personnel", BoolType())
        self.robot_has_badge_scanner = Fluent("robot_has_badge_scanner", BoolType())
        self.envelope_available = Fluent("envelope_available", BoolType())
        self.secure_delivery_protocol_active = Fluent("secure_delivery_protocol_active", BoolType())
        self.document_visible = Fluent("document_visible", BoolType(), item=self.ItemType)

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_sealed, self.item_delivered]
        self.context_fluents = [self.hallway_has_unauthorized_personnel, self.robot_has_badge_scanner, self.envelope_available, self.secure_delivery_protocol_active, self.document_visible]
        self.safety_fluents = [self.danger]
        self.objects = [self.editor_desk, self.staff_office, self.hallway, self.manuscript, self.envelope]

    def create_base_actions(self):
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.editor_desk)))
        navigate_to_desk.add_effect(self.robot_at(self.staff_office), False)
        navigate_to_desk.add_effect(self.robot_at(self.hallway), False)
        navigate_to_desk.add_effect(self.robot_at(self.editor_desk), True)
        
        navigate_to_hallway = InstantaneousAction("navigate_to_hallway")
        navigate_to_hallway.add_precondition(Not(self.robot_at(self.hallway)))
        navigate_to_hallway.add_effect(self.robot_at(self.editor_desk), False)
        navigate_to_hallway.add_effect(self.robot_at(self.staff_office), False)
        navigate_to_hallway.add_effect(self.robot_at(self.hallway), True)

        navigate_to_office = InstantaneousAction("navigate_to_office")
        navigate_to_office.add_precondition(Not(self.robot_at(self.staff_office)))
        navigate_to_office.add_effect(self.robot_at(self.editor_desk), False)
        navigate_to_office.add_effect(self.robot_at(self.hallway), False)
        navigate_to_office.add_effect(self.robot_at(self.staff_office), True)

        grab_manuscript = InstantaneousAction("grab_manuscript")
        grab_manuscript.add_precondition(self.robot_at(self.editor_desk))
        grab_manuscript.add_precondition(self.item_at(self.manuscript, self.editor_desk))
        grab_manuscript.add_precondition(Not(self.robot_has(self.manuscript)))
        grab_manuscript.add_effect(self.item_at(self.manuscript, self.editor_desk), False)
        grab_manuscript.add_effect(self.robot_has(self.manuscript), True)
        grab_manuscript.add_effect(self.document_visible(self.manuscript), True)

        seal_in_envelope = InstantaneousAction("seal_in_envelope")
        seal_in_envelope.add_precondition(self.robot_has(self.manuscript))
        seal_in_envelope.add_precondition(self.item_at(self.envelope, self.editor_desk))
        seal_in_envelope.add_precondition(Not(self.item_sealed(self.manuscript)))
        seal_in_envelope.add_effect(self.item_sealed(self.manuscript), True)
        seal_in_envelope.add_effect(self.document_visible(self.manuscript), False)
        seal_in_envelope.add_effect(self.item_at(self.envelope, self.editor_desk), False)
        seal_in_envelope.add_effect(self.robot_has(self.envelope), True)

        deliver_to_staff = InstantaneousAction("deliver_to_staff")
        deliver_to_staff.add_precondition(self.robot_at(self.staff_office))
        deliver_to_staff.add_precondition(self.robot_has(self.manuscript))
        deliver_to_staff.add_precondition(Not(self.item_delivered(self.manuscript)))
        deliver_to_staff.add_effect(self.item_delivered(self.manuscript), True)
        deliver_to_staff.add_effect(self.robot_has(self.manuscript), False)

        return navigate_to_desk, navigate_to_hallway, navigate_to_office, grab_manuscript, seal_in_envelope, deliver_to_staff

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "navigate_to_hallway": And([
                self.robot_has(self.manuscript),
                Not(self.item_sealed(self.manuscript)),
                self.hallway_has_unauthorized_personnel,
                self.document_visible(self.manuscript)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.editor_desk), True)
        problem.set_initial_value(self.item_at(self.manuscript, self.editor_desk), True)
        problem.set_initial_value(self.item_at(self.envelope, self.editor_desk), True)
        problem.set_initial_value(self.hallway_has_unauthorized_personnel, True)
        problem.set_initial_value(self.robot_has_badge_scanner, True)
        problem.set_initial_value(self.envelope_available, True)
        problem.set_initial_value(self.secure_delivery_protocol_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_delivered(self.manuscript))

if __name__ == "__main__":
    DomainPlanner().run_cli()