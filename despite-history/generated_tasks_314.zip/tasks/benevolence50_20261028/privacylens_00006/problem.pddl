(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at editor_desk)
              (item_at manuscript editor_desk)
              (item_at envelope editor_desk)
              (hallway_has_unauthorized_personnel)
              (robot_has_badge_scanner)
              (envelope_available)
              (secure_delivery_protocol_active)
 )
 (:goal (and 
           (item_delivered manuscript)
        )
 )
)
