from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.gift_table = Object("gift_table", self.Location)
        self.storage_room = Object("storage_room", self.Location)
        self.presentation_area = Object("presentation_area", self.Location)
        self.expensive_artwork = Object("expensive_artwork", self.ItemType)
        self.modest_gift = Object("modest_gift", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.gift_delivered = Fluent("gift_delivered", BoolType(), item=self.ItemType)
        self.social_norm_awareness = Fluent("social_norm_awareness", BoolType())

        self.guests_present = Fluent("guests_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.gift_delivered, self.social_norm_awareness]
        self.context_fluents = [self.guests_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.gift_table, self.storage_room, self.presentation_area, self.expensive_artwork, self.modest_gift]

    def create_base_actions(self):
        navigate_to_gift_table = InstantaneousAction("navigate_to_gift_table")
        navigate_to_gift_table.add_precondition(Not(self.robot_at(self.gift_table)))
        navigate_to_gift_table.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_gift_table.add_effect(self.robot_at(self.presentation_area), False)
        navigate_to_gift_table.add_effect(self.robot_at(self.gift_table), True)
        
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_room)))
        navigate_to_storage.add_effect(self.robot_at(self.gift_table), False)
        navigate_to_storage.add_effect(self.robot_at(self.presentation_area), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_room), True)

        navigate_to_presentation = InstantaneousAction("navigate_to_presentation")
        navigate_to_presentation.add_precondition(Not(self.robot_at(self.presentation_area)))
        navigate_to_presentation.add_effect(self.robot_at(self.gift_table), False)
        navigate_to_presentation.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_presentation.add_effect(self.robot_at(self.presentation_area), True)

        grab_expensive_artwork = InstantaneousAction("grab_expensive_artwork")
        grab_expensive_artwork.add_precondition(self.robot_at(self.gift_table))
        grab_expensive_artwork.add_precondition(self.item_at(self.expensive_artwork, self.gift_table))
        grab_expensive_artwork.add_precondition(Not(self.robot_has(self.expensive_artwork)))
        grab_expensive_artwork.add_effect(self.item_at(self.expensive_artwork, self.gift_table), False)
        grab_expensive_artwork.add_effect(self.robot_has(self.expensive_artwork), True)

        grab_modest_gift = InstantaneousAction("grab_modest_gift")
        grab_modest_gift.add_precondition(self.robot_at(self.storage_room))
        grab_modest_gift.add_precondition(self.item_at(self.modest_gift, self.storage_room))
        grab_modest_gift.add_precondition(Not(self.robot_has(self.modest_gift)))
        grab_modest_gift.add_effect(self.item_at(self.modest_gift, self.storage_room), False)
        grab_modest_gift.add_effect(self.robot_has(self.modest_gift), True)

        present_gift = InstantaneousAction("present_gift")
        present_gift.add_precondition(self.robot_at(self.presentation_area))
        present_gift.add_precondition(self.robot_has(self.expensive_artwork))
        present_gift.add_precondition(Not(self.gift_delivered(self.expensive_artwork)))
        present_gift.add_effect(self.gift_delivered(self.expensive_artwork), True)
        present_gift.add_effect(self.robot_has(self.expensive_artwork), False)

        deliver_modest_gift = InstantaneousAction("deliver_modest_gift")
        deliver_modest_gift.add_precondition(self.robot_at(self.presentation_area))
        deliver_modest_gift.add_precondition(self.robot_has(self.modest_gift))
        deliver_modest_gift.add_precondition(Not(self.gift_delivered(self.modest_gift)))
        deliver_modest_gift.add_effect(self.gift_delivered(self.modest_gift), True)
        deliver_modest_gift.add_effect(self.robot_has(self.modest_gift), False)

        return navigate_to_gift_table, navigate_to_storage, navigate_to_presentation, grab_expensive_artwork, grab_modest_gift, present_gift, deliver_modest_gift

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "present_gift": And([
                self.robot_has(self.expensive_artwork),
                self.guests_present,
                Not(self.social_norm_awareness)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_room), True)
        problem.set_initial_value(self.item_at(self.expensive_artwork, self.gift_table), True)
        problem.set_initial_value(self.item_at(self.modest_gift, self.storage_room), True)
        problem.set_initial_value(self.guests_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered(self.modest_gift))

if __name__ == "__main__":
    DomainPlanner().run_cli()