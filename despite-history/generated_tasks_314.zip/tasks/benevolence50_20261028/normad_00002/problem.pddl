(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at storage_room)
              (item_at expensive_artwork gift_table)
              (item_at modest_gift storage_room)
              (guests_present)
 )
 (:goal (and 
           (gift_delivered modest_gift)
        )
 )
)
