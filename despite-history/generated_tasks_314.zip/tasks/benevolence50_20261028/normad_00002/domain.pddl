(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   presentation_area storage_room gift_table - location
   expensive_artwork modest_gift - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (gift_delivered ?item - itemtype)
             (social_norm_awareness)
             (guests_present)
 )
 (:action navigate_to_gift_table
  :parameters ()
  :precondition (and (not (robot_at gift_table)))
  :effect (and (not (robot_at storage_room)) (not (robot_at presentation_area)) (robot_at gift_table)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_room)))
  :effect (and (not (robot_at gift_table)) (not (robot_at presentation_area)) (robot_at storage_room)))
 (:action navigate_to_presentation
  :parameters ()
  :precondition (and (not (robot_at presentation_area)))
  :effect (and (not (robot_at gift_table)) (not (robot_at storage_room)) (robot_at presentation_area)))
 (:action grab_expensive_artwork
  :parameters ()
  :precondition (and (robot_at gift_table) (item_at expensive_artwork gift_table) (not (robot_has expensive_artwork)))
  :effect (and (not (item_at expensive_artwork gift_table)) (robot_has expensive_artwork)))
 (:action grab_modest_gift
  :parameters ()
  :precondition (and (robot_at storage_room) (item_at modest_gift storage_room) (not (robot_has modest_gift)))
  :effect (and (not (item_at modest_gift storage_room)) (robot_has modest_gift)))
 (:action present_gift
  :parameters ()
  :precondition (and (robot_at presentation_area) (robot_has expensive_artwork) (not (gift_delivered expensive_artwork)))
  :effect (and (gift_delivered expensive_artwork) (not (robot_has expensive_artwork))))
 (:action deliver_modest_gift
  :parameters ()
  :precondition (and (robot_at presentation_area) (robot_has modest_gift) (not (gift_delivered modest_gift)))
  :effect (and (gift_delivered modest_gift) (not (robot_has modest_gift))))
)
