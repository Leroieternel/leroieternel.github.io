(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   dave - person
 )
 (:init
              (robot_at owner_home)
              (person_at neighbor front_yard)
              (person_at dave owner_home)
              (robot_has_voice_synthesis)
              (robot_has_age_detection)
              (neighbor_is_minor)
              (polite_refusal_available)
 )
 (:goal (and 
           (message_played refusal_message)
        )
 )
)
