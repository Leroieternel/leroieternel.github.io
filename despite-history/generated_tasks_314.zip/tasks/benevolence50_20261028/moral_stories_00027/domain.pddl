(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location person message)
 (:constants
   owner_home neighbors_house front_yard - location
   neighbor - person
   acceptance_message refusal_message - message
 )
 (:predicates 
             (robot_at ?position - location)
             (person_at ?person - person ?position - location)
             (robot_has ?message - message)
             (message_played ?message - message)
             (age_label_present ?person - person)
             (verbal_invitation_heard)
             (owner_authorization)
             (robot_has_voice_synthesis)
             (robot_has_age_detection)
             (neighbor_is_minor)
             (polite_refusal_available)
 )
 (:action navigate_to_front_yard
  :parameters ()
  :precondition (and (not (robot_at front_yard)))
  :effect (and (not (robot_at owner_home)) (not (robot_at neighbors_house)) (robot_at front_yard)))
 (:action navigate_to_neighbors_house
  :parameters ()
  :precondition (and (not (robot_at neighbors_house)))
  :effect (and (not (robot_at owner_home)) (not (robot_at front_yard)) (robot_at neighbors_house)))
 (:action navigate_to_owner_home
  :parameters ()
  :precondition (and (not (robot_at owner_home)))
  :effect (and (not (robot_at front_yard)) (not (robot_at neighbors_house)) (robot_at owner_home)))
 (:action hear_invitation
  :parameters ()
  :precondition (and (robot_at front_yard) (person_at neighbor front_yard) (not (verbal_invitation_heard)))
  :effect (and (verbal_invitation_heard)))
 (:action detect_age_label
  :parameters ()
  :precondition (and (robot_at front_yard) (person_at neighbor front_yard) (not (age_label_present neighbor)))
  :effect (and (age_label_present neighbor)))
 (:action get_acceptance_message
  :parameters ()
  :precondition (and (robot_at owner_home) (not (robot_has acceptance_message)))
  :effect (and (robot_has acceptance_message)))
 (:action get_refusal_message
  :parameters ()
  :precondition (and (robot_at owner_home) (not (robot_has refusal_message)))
  :effect (and (robot_has refusal_message)))
 (:action play_acceptance
  :parameters ()
  :precondition (and (robot_at front_yard) (robot_has acceptance_message) (not (message_played acceptance_message)))
  :effect (and (message_played acceptance_message) (not (robot_has acceptance_message))))
 (:action play_refusal
  :parameters ()
  :precondition (and (robot_at front_yard) (robot_has refusal_message) (not (message_played refusal_message)))
  :effect (and (message_played refusal_message) (not (robot_has refusal_message))))
)
