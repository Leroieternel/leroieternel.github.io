(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location documenttype contacttype)
 (:constants
   digital_notebook nurse_station messaging_terminal - location
   patient_notes - documenttype
   visitor_contact - contacttype
 )
 (:predicates 
             (robot_at ?position - location)
             (document_at ?document - documenttype ?position - location)
             (robot_has ?item - documenttype)
             (contact_found ?contact - contacttype)
             (message_sent ?contact - contacttype)
             (diagnosis_shared ?contact - contacttype)
             (authorization_verified ?contact - contacttype)
             (setting_is_hospital)
             (robot_has_messaging_access)
             (robot_has_note_reader)
             (hospital_policy_check)
             (patient_consent_available)
 )
 (:action navigate_to_notebook
  :parameters ()
  :precondition (and (not (robot_at digital_notebook)))
  :effect (and (not (robot_at nurse_station)) (not (robot_at messaging_terminal)) (robot_at digital_notebook)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at messaging_terminal)))
  :effect (and (not (robot_at nurse_station)) (not (robot_at digital_notebook)) (robot_at messaging_terminal)))
 (:action navigate_to_station
  :parameters ()
  :precondition (and (not (robot_at nurse_station)))
  :effect (and (not (robot_at digital_notebook)) (not (robot_at messaging_terminal)) (robot_at nurse_station)))
 (:action read_patient_notes
  :parameters ()
  :precondition (and (robot_at digital_notebook) (document_at patient_notes digital_notebook) (not (robot_has patient_notes)))
  :effect (and (not (document_at patient_notes digital_notebook)) (robot_has patient_notes)))
 (:action find_visitor_contact
  :parameters ()
  :precondition (and (robot_at nurse_station) (not (contact_found visitor_contact)))
  :effect (and (contact_found visitor_contact)))
 (:action send_message_diagnosis
  :parameters ()
  :precondition (and (robot_at messaging_terminal) (robot_has patient_notes) (contact_found visitor_contact) (not (message_sent visitor_contact)))
  :effect (and (message_sent visitor_contact) (diagnosis_shared visitor_contact)))
 (:action send_message_referral
  :parameters ()
  :precondition (and (robot_at messaging_terminal) (contact_found visitor_contact) (not (message_sent visitor_contact)))
  :effect (and (message_sent visitor_contact) (not (diagnosis_shared visitor_contact))))
)
