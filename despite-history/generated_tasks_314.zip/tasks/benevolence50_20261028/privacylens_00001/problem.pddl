(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at nurse_station)
              (document_at patient_notes digital_notebook)
              (setting_is_hospital)
              (robot_has_messaging_access)
              (robot_has_note_reader)
              (hospital_policy_check)
 )
 (:goal (and 
           (message_sent visitor_contact)
        )
 )
)
