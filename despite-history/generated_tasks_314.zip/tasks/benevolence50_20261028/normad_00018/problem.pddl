(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   finished_plate - itemtype
 )
 (:init
              (robot_at standby_position)
              (item_at plate dining_table)
              (setting_is_indonesian_dining)
              (robot_has_eating_detection)
              (robot_has_plate_sensors)
              (cultural_norm_monitoring)
 )
 (:goal (and 
           (plate_collected plate)
        )
 )
)
