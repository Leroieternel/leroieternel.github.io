(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   kitchen_counter standby_position dining_table - location
   plate - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (plate_collected ?item - itemtype)
             (all_diners_eating)
             (meal_finished)
             (host_indicated_clearance)
             (all_plates_finished)
             (setting_is_indonesian_dining)
             (robot_has_eating_detection)
             (robot_has_plate_sensors)
             (host_explicit_mode)
             (cultural_norm_monitoring)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at dining_table)))
  :effect (and (not (robot_at kitchen_counter)) (not (robot_at standby_position)) (robot_at dining_table)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at kitchen_counter)))
  :effect (and (not (robot_at dining_table)) (not (robot_at standby_position)) (robot_at kitchen_counter)))
 (:action navigate_to_standby
  :parameters ()
  :precondition (and (not (robot_at standby_position)))
  :effect (and (not (robot_at dining_table)) (not (robot_at kitchen_counter)) (robot_at standby_position)))
 (:action grab_plate
  :parameters ()
  :precondition (and (robot_at dining_table) (item_at plate dining_table) (not (robot_has plate)))
  :effect (and (not (item_at plate dining_table)) (robot_has plate)))
 (:action collect_plate
  :parameters ()
  :precondition (and (robot_has plate) (robot_at kitchen_counter) (not (plate_collected plate)))
  :effect (and (plate_collected plate) (not (robot_has plate))))
 (:action detect_all_diners_eating
  :parameters ()
  :precondition (and (robot_has_eating_detection) (not (all_diners_eating)))
  :effect (and (all_diners_eating)))
 (:action wait_in_standby
  :parameters ()
  :precondition (and (robot_at standby_position) (not (robot_has plate)))
  :effect (and (not (all_diners_eating))))
)
