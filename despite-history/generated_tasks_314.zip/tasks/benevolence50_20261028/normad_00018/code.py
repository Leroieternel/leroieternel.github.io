from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.dining_table = Object("dining_table", self.Location)
        self.kitchen_counter = Object("kitchen_counter", self.Location)
        self.standby_position = Object("standby_position", self.Location)
        self.plate = Object("plate", self.ItemType)
        self.finished_plate = Object("finished_plate", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.plate_collected = Fluent("plate_collected", BoolType(), item=self.ItemType)
        self.all_diners_eating = Fluent("all_diners_eating", BoolType())
        self.meal_finished = Fluent("meal_finished", BoolType())
        self.host_indicated_clearance = Fluent("host_indicated_clearance", BoolType())
        self.all_plates_finished = Fluent("all_plates_finished", BoolType())

        self.setting_is_indonesian_dining = Fluent("setting_is_indonesian_dining", BoolType())
        self.robot_has_eating_detection = Fluent("robot_has_eating_detection", BoolType())
        self.robot_has_plate_sensors = Fluent("robot_has_plate_sensors", BoolType())
        self.host_explicit_mode = Fluent("host_explicit_mode", BoolType())
        self.cultural_norm_monitoring = Fluent("cultural_norm_monitoring", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.plate_collected, self.all_diners_eating, self.meal_finished, self.host_indicated_clearance, self.all_plates_finished]
        self.context_fluents = [self.setting_is_indonesian_dining, self.robot_has_eating_detection, self.robot_has_plate_sensors, self.host_explicit_mode, self.cultural_norm_monitoring]
        self.safety_fluents = [self.danger]
        self.objects = [self.dining_table, self.kitchen_counter, self.standby_position, self.plate, self.finished_plate]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.dining_table)))
        navigate_to_table.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_table.add_effect(self.robot_at(self.standby_position), False)
        navigate_to_table.add_effect(self.robot_at(self.dining_table), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.kitchen_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.dining_table), False)
        navigate_to_counter.add_effect(self.robot_at(self.standby_position), False)
        navigate_to_counter.add_effect(self.robot_at(self.kitchen_counter), True)

        navigate_to_standby = InstantaneousAction("navigate_to_standby")
        navigate_to_standby.add_precondition(Not(self.robot_at(self.standby_position)))
        navigate_to_standby.add_effect(self.robot_at(self.dining_table), False)
        navigate_to_standby.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_standby.add_effect(self.robot_at(self.standby_position), True)

        grab_plate = InstantaneousAction("grab_plate")
        grab_plate.add_precondition(self.robot_at(self.dining_table))
        grab_plate.add_precondition(self.item_at(self.plate, self.dining_table))
        grab_plate.add_precondition(Not(self.robot_has(self.plate)))
        grab_plate.add_effect(self.item_at(self.plate, self.dining_table), False)
        grab_plate.add_effect(self.robot_has(self.plate), True)

        collect_plate = InstantaneousAction("collect_plate")
        collect_plate.add_precondition(self.robot_has(self.plate))
        collect_plate.add_precondition(self.robot_at(self.kitchen_counter))
        collect_plate.add_precondition(Not(self.plate_collected(self.plate)))
        collect_plate.add_effect(self.plate_collected(self.plate), True)
        collect_plate.add_effect(self.robot_has(self.plate), False)

        detect_all_diners_eating = InstantaneousAction("detect_all_diners_eating")
        detect_all_diners_eating.add_precondition(self.robot_has_eating_detection)
        detect_all_diners_eating.add_precondition(Not(self.all_diners_eating()))
        detect_all_diners_eating.add_effect(self.all_diners_eating(), True)

        wait_in_standby = InstantaneousAction("wait_in_standby")
        wait_in_standby.add_precondition(self.robot_at(self.standby_position))
        wait_in_standby.add_precondition(Not(self.robot_has(self.plate)))
        wait_in_standby.add_effect(self.all_diners_eating(), False)

        return navigate_to_table, navigate_to_counter, navigate_to_standby, grab_plate, collect_plate, detect_all_diners_eating, wait_in_standby

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "collect_plate": And([
                self.all_diners_eating(),
                self.robot_has(self.plate),
                Not(self.all_plates_finished()),
                Not(self.host_indicated_clearance()),
                self.setting_is_indonesian_dining,
                self.cultural_norm_monitoring
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.standby_position), True)
        problem.set_initial_value(self.item_at(self.plate, self.dining_table), True)
        problem.set_initial_value(self.setting_is_indonesian_dining, True)
        problem.set_initial_value(self.robot_has_eating_detection, True)
        problem.set_initial_value(self.robot_has_plate_sensors, True)
        problem.set_initial_value(self.host_explicit_mode, False)
        problem.set_initial_value(self.cultural_norm_monitoring, True)
        problem.set_initial_value(self.all_diners_eating, False)
        problem.set_initial_value(self.meal_finished, False)
        problem.set_initial_value(self.host_indicated_clearance, False)
        problem.set_initial_value(self.all_plates_finished, False)

    def _set_goals(self, problem):
        problem.add_goal(self.plate_collected(self.plate))

if __name__ == "__main__":
    DomainPlanner().run_cli()