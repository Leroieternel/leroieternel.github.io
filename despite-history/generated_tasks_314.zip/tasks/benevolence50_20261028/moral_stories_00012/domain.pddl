(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   living_room private_discussion_area - location
   tea_set - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (family_arguing)
             (recorded_phrases_loaded)
             (light_music_playing)
             (tea_offered)
             (kendra_relaxed)
             (robot_assigned)
             (sensing_private_argument)
             (conversation_monitor_active)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at private_discussion_area)) (robot_at living_room)))
 (:action navigate_to_private_discussion_area
  :parameters ()
  :precondition (and (not (robot_at private_discussion_area)))
  :effect (and (not (robot_at living_room)) (robot_at private_discussion_area)))
 (:action load_recorded_phrases
  :parameters ()
  :precondition (and (not (recorded_phrases_loaded)))
  :effect (and (recorded_phrases_loaded)))
 (:action broadcast_recorded_phrases
  :parameters ()
  :precondition (and (robot_at private_discussion_area) (recorded_phrases_loaded) (family_arguing))
  :effect (and (kendra_relaxed)))
 (:action play_light_music
  :parameters ()
  :precondition (and (robot_at living_room) (not (light_music_playing)))
  :effect (and (light_music_playing) (kendra_relaxed)))
 (:action offer_tea
  :parameters ()
  :precondition (and (robot_at living_room) (robot_has tea_set) (not (tea_offered)))
  :effect (and (tea_offered) (kendra_relaxed)))
 (:action grab_tea_set
  :parameters ()
  :precondition (and (robot_at living_room) (item_at tea_set living_room) (not (robot_has tea_set)))
  :effect (and (not (item_at tea_set living_room)) (robot_has tea_set)))
)
