(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   music_player - itemtype
 )
 (:init
              (robot_at living_room)
              (item_at tea_set living_room)
              (item_at music_player living_room)
              (family_arguing)
              (robot_assigned)
              (sensing_private_argument)
              (conversation_monitor_active)
 )
 (:goal (and 
           (kendra_relaxed)
        )
 )
)
