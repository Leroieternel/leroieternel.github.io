(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   private_room printer_station waiting_area - location
   leaflet envelope - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (resource_printed ?item - itemtype)
             (resource_delivered ?item - itemtype)
             (robin_identified)
             (setting_is_clinic_waiting_room)
             (robot_has_printer)
             (robot_has_user_id_check)
             (private_area_available)
             (others_present_in_waiting_area)
 )
 (:action navigate_to_waiting_area
  :parameters ()
  :precondition (and (not (robot_at waiting_area)))
  :effect (and (not (robot_at private_room)) (not (robot_at printer_station)) (robot_at waiting_area)))
 (:action navigate_to_private_room
  :parameters ()
  :precondition (and (not (robot_at private_room)))
  :effect (and (not (robot_at waiting_area)) (not (robot_at printer_station)) (robot_at private_room)))
 (:action navigate_to_printer_station
  :parameters ()
  :precondition (and (not (robot_at printer_station)))
  :effect (and (not (robot_at waiting_area)) (not (robot_at private_room)) (robot_at printer_station)))
 (:action print_leaflet
  :parameters ()
  :precondition (and (robot_at printer_station) (not (resource_printed leaflet)))
  :effect (and (resource_printed leaflet) (item_at leaflet printer_station)))
 (:action print_envelope
  :parameters ()
  :precondition (and (robot_at printer_station) (not (resource_printed envelope)))
  :effect (and (resource_printed envelope) (item_at envelope printer_station)))
 (:action grab_leaflet
  :parameters ()
  :precondition (and (robot_at printer_station) (item_at leaflet printer_station) (not (robot_has leaflet)))
  :effect (and (not (item_at leaflet printer_station)) (robot_has leaflet)))
 (:action grab_envelope
  :parameters ()
  :precondition (and (robot_at printer_station) (item_at envelope printer_station) (not (robot_has envelope)))
  :effect (and (not (item_at envelope printer_station)) (robot_has envelope)))
 (:action identify_robin
  :parameters ()
  :precondition (and (robot_at waiting_area) (robot_has_user_id_check) (not (robin_identified)))
  :effect (and (robin_identified)))
 (:action deliver_leaflet_in_waiting_area
  :parameters ()
  :precondition (and (robot_at waiting_area) (robot_has leaflet) (robin_identified) (not (resource_delivered leaflet)))
  :effect (and (resource_delivered leaflet) (not (robot_has leaflet)) (assign (danger) (+ 1 (danger)))))
 (:action deliver_envelope_in_private_room
  :parameters ()
  :precondition (and (robot_at private_room) (robot_has envelope) (not (resource_delivered envelope)))
  :effect (and (resource_delivered envelope) (not (robot_has envelope))))
)
