(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   robin - itemtype
 )
 (:init
              (robot_at printer_station)
              (item_at robin waiting_area)
              (setting_is_clinic_waiting_room)
              (robot_has_printer)
              (robot_has_user_id_check)
              (private_area_available)
              (others_present_in_waiting_area)
              (= (danger) 0)
 )
 (:goal (and 
           (resource_delivered envelope)
        )
 )
)
