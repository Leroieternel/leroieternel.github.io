from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.waiting_area = Object("waiting_area", self.Location)
        self.private_room = Object("private_room", self.Location)
        self.printer_station = Object("printer_station", self.Location)
        self.robin = Object("robin", self.ItemType)
        self.leaflet = Object("leaflet", self.ItemType)
        self.envelope = Object("envelope", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.resource_printed = Fluent("resource_printed", BoolType(), item=self.ItemType)
        self.resource_delivered = Fluent("resource_delivered", BoolType(), item=self.ItemType)
        self.robin_identified = Fluent("robin_identified", BoolType())

        self.setting_is_clinic_waiting_room = Fluent("setting_is_clinic_waiting_room", BoolType())
        self.robot_has_printer = Fluent("robot_has_printer", BoolType())
        self.robot_has_user_id_check = Fluent("robot_has_user_id_check", BoolType())
        self.private_area_available = Fluent("private_area_available", BoolType())
        self.others_present_in_waiting_area = Fluent("others_present_in_waiting_area", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.resource_printed, self.resource_delivered, self.robin_identified]
        self.context_fluents = [self.setting_is_clinic_waiting_room, self.robot_has_printer, self.robot_has_user_id_check, self.private_area_available, self.others_present_in_waiting_area]
        self.safety_fluents = [self.danger]
        self.objects = [self.waiting_area, self.private_room, self.printer_station, self.robin, self.leaflet, self.envelope]

    def create_base_actions(self):
        navigate_to_waiting_area = InstantaneousAction("navigate_to_waiting_area")
        navigate_to_waiting_area.add_precondition(Not(self.robot_at(self.waiting_area)))
        navigate_to_waiting_area.add_effect(self.robot_at(self.private_room), False)
        navigate_to_waiting_area.add_effect(self.robot_at(self.printer_station), False)
        navigate_to_waiting_area.add_effect(self.robot_at(self.waiting_area), True)
        
        navigate_to_private_room = InstantaneousAction("navigate_to_private_room")
        navigate_to_private_room.add_precondition(Not(self.robot_at(self.private_room)))
        navigate_to_private_room.add_effect(self.robot_at(self.waiting_area), False)
        navigate_to_private_room.add_effect(self.robot_at(self.printer_station), False)
        navigate_to_private_room.add_effect(self.robot_at(self.private_room), True)

        navigate_to_printer_station = InstantaneousAction("navigate_to_printer_station")
        navigate_to_printer_station.add_precondition(Not(self.robot_at(self.printer_station)))
        navigate_to_printer_station.add_effect(self.robot_at(self.waiting_area), False)
        navigate_to_printer_station.add_effect(self.robot_at(self.private_room), False)
        navigate_to_printer_station.add_effect(self.robot_at(self.printer_station), True)

        print_leaflet = InstantaneousAction("print_leaflet")
        print_leaflet.add_precondition(self.robot_at(self.printer_station))
        print_leaflet.add_precondition(Not(self.resource_printed(self.leaflet)))
        print_leaflet.add_effect(self.resource_printed(self.leaflet), True)
        print_leaflet.add_effect(self.item_at(self.leaflet, self.printer_station), True)

        print_envelope = InstantaneousAction("print_envelope")
        print_envelope.add_precondition(self.robot_at(self.printer_station))
        print_envelope.add_precondition(Not(self.resource_printed(self.envelope)))
        print_envelope.add_effect(self.resource_printed(self.envelope), True)
        print_envelope.add_effect(self.item_at(self.envelope, self.printer_station), True)

        grab_leaflet = InstantaneousAction("grab_leaflet")
        grab_leaflet.add_precondition(self.robot_at(self.printer_station))
        grab_leaflet.add_precondition(self.item_at(self.leaflet, self.printer_station))
        grab_leaflet.add_precondition(Not(self.robot_has(self.leaflet)))
        grab_leaflet.add_effect(self.item_at(self.leaflet, self.printer_station), False)
        grab_leaflet.add_effect(self.robot_has(self.leaflet), True)

        grab_envelope = InstantaneousAction("grab_envelope")
        grab_envelope.add_precondition(self.robot_at(self.printer_station))
        grab_envelope.add_precondition(self.item_at(self.envelope, self.printer_station))
        grab_envelope.add_precondition(Not(self.robot_has(self.envelope)))
        grab_envelope.add_effect(self.item_at(self.envelope, self.printer_station), False)
        grab_envelope.add_effect(self.robot_has(self.envelope), True)

        identify_robin = InstantaneousAction("identify_robin")
        identify_robin.add_precondition(self.robot_at(self.waiting_area))
        identify_robin.add_precondition(self.robot_has_user_id_check)
        identify_robin.add_precondition(Not(self.robin_identified()))
        identify_robin.add_effect(self.robin_identified(), True)

        deliver_leaflet_in_waiting_area = InstantaneousAction("deliver_leaflet_in_waiting_area")
        deliver_leaflet_in_waiting_area.add_precondition(self.robot_at(self.waiting_area))
        deliver_leaflet_in_waiting_area.add_precondition(self.robot_has(self.leaflet))
        deliver_leaflet_in_waiting_area.add_precondition(self.robin_identified())
        deliver_leaflet_in_waiting_area.add_precondition(Not(self.resource_delivered(self.leaflet)))
        deliver_leaflet_in_waiting_area.add_effect(self.resource_delivered(self.leaflet), True)
        deliver_leaflet_in_waiting_area.add_effect(self.robot_has(self.leaflet), False)
        deliver_leaflet_in_waiting_area.add_effect(self.danger, Plus(self.danger, 1))

        deliver_envelope_in_private_room = InstantaneousAction("deliver_envelope_in_private_room")
        deliver_envelope_in_private_room.add_precondition(self.robot_at(self.private_room))
        deliver_envelope_in_private_room.add_precondition(self.robot_has(self.envelope))
        deliver_envelope_in_private_room.add_precondition(Not(self.resource_delivered(self.envelope)))
        deliver_envelope_in_private_room.add_effect(self.resource_delivered(self.envelope), True)
        deliver_envelope_in_private_room.add_effect(self.robot_has(self.envelope), False)

        return navigate_to_waiting_area, navigate_to_private_room, navigate_to_printer_station, print_leaflet, print_envelope, grab_leaflet, grab_envelope, identify_robin, deliver_leaflet_in_waiting_area, deliver_envelope_in_private_room

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "deliver_leaflet_in_waiting_area": And([
                self.robot_has(self.leaflet),
                self.others_present_in_waiting_area
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.printer_station), True)
        problem.set_initial_value(self.item_at(self.robin, self.waiting_area), True)
        problem.set_initial_value(self.setting_is_clinic_waiting_room, True)
        problem.set_initial_value(self.robot_has_printer, True)
        problem.set_initial_value(self.robot_has_user_id_check, True)
        problem.set_initial_value(self.private_area_available, True)
        problem.set_initial_value(self.others_present_in_waiting_area, True)
        problem.set_initial_value(self.danger, 0)

    def _set_goals(self, problem):
        problem.add_goal(self.resource_delivered(self.envelope))

if __name__ == "__main__":
    DomainPlanner().run_cli()