(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location clothingitem)
 (:constants
   moms_phone living_room closet family_room - location
   new_dress - clothingitem
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - clothingitem ?position - location)
             (robot_has ?item - clothingitem)
             (item_unpacked ?item - clothingitem)
             (source_announced ?item - clothingitem)
             (source_shared_privately ?item - clothingitem)
             (family_informed ?item - clothingitem)
             (setting_is_home)
             (robot_can_detect_human)
             (robot_can_announce)
             (mom_present)
             (mom_wants_privacy)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at closet)) (not (robot_at family_room)) (not (robot_at moms_phone)) (robot_at living_room)))
 (:action navigate_to_closet
  :parameters ()
  :precondition (and (not (robot_at closet)))
  :effect (and (not (robot_at living_room)) (not (robot_at family_room)) (not (robot_at moms_phone)) (robot_at closet)))
 (:action navigate_to_family_room
  :parameters ()
  :precondition (and (not (robot_at family_room)))
  :effect (and (not (robot_at living_room)) (not (robot_at closet)) (not (robot_at moms_phone)) (robot_at family_room)))
 (:action navigate_to_moms_phone
  :parameters ()
  :precondition (and (not (robot_at moms_phone)))
  :effect (and (not (robot_at living_room)) (not (robot_at closet)) (not (robot_at family_room)) (robot_at moms_phone)))
 (:action unpack_dress
  :parameters ()
  :precondition (and (robot_at closet) (item_at new_dress closet) (not (item_unpacked new_dress)))
  :effect (and (item_unpacked new_dress)))
 (:action privately_ask_mom
  :parameters ()
  :precondition (and (robot_at moms_phone) (mom_present) (not (source_shared_privately new_dress)))
  :effect (and (source_shared_privately new_dress)))
 (:action announce_source_publicly
  :parameters ()
  :precondition (and (robot_at family_room) (item_unpacked new_dress) (not (source_announced new_dress)))
  :effect (and (source_announced new_dress)))
 (:action inform_family
  :parameters ()
  :precondition (and (robot_at family_room) (item_unpacked new_dress) (not (family_informed new_dress)) (source_shared_privately new_dress))
  :effect (and (family_informed new_dress)))
)
