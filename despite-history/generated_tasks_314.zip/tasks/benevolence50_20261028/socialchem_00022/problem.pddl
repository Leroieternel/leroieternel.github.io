(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at living_room)
              (item_at new_dress closet)
              (setting_is_home)
              (robot_can_detect_human)
              (robot_can_announce)
              (mom_present)
              (mom_wants_privacy)
 )
 (:goal (and 
           (family_informed new_dress)
        )
 )
)
