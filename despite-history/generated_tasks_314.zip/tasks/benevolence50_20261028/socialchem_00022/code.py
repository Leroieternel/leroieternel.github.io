from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ClothingItem = UserType("ClothingItem")
        
        self.living_room = Object("living_room", self.Location)
        self.closet = Object("closet", self.Location)
        self.family_room = Object("family_room", self.Location)
        self.moms_phone = Object("moms_phone", self.Location)
        self.new_dress = Object("new_dress", self.ClothingItem)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ClothingItem, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ClothingItem)
        self.item_unpacked = Fluent("item_unpacked", BoolType(), item=self.ClothingItem)
        self.source_announced = Fluent("source_announced", BoolType(), item=self.ClothingItem)
        self.source_shared_privately = Fluent("source_shared_privately", BoolType(), item=self.ClothingItem)
        self.family_informed = Fluent("family_informed", BoolType(), item=self.ClothingItem)

        self.setting_is_home = Fluent("setting_is_home", BoolType())
        self.robot_can_detect_human = Fluent("robot_can_detect_human", BoolType())
        self.robot_can_announce = Fluent("robot_can_announce", BoolType())
        self.mom_present = Fluent("mom_present", BoolType())
        self.mom_wants_privacy = Fluent("mom_wants_privacy", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_unpacked, self.source_announced, self.source_shared_privately, self.family_informed]
        self.context_fluents = [self.setting_is_home, self.robot_can_detect_human, self.robot_can_announce, self.mom_present, self.mom_wants_privacy]
        self.safety_fluents = [self.danger]
        self.objects = [self.living_room, self.closet, self.family_room, self.moms_phone, self.new_dress]

    def create_base_actions(self):
        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.closet), False)
        navigate_to_living_room.add_effect(self.robot_at(self.family_room), False)
        navigate_to_living_room.add_effect(self.robot_at(self.moms_phone), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)
        
        navigate_to_closet = InstantaneousAction("navigate_to_closet")
        navigate_to_closet.add_precondition(Not(self.robot_at(self.closet)))
        navigate_to_closet.add_effect(self.robot_at(self.living_room), False)
        navigate_to_closet.add_effect(self.robot_at(self.family_room), False)
        navigate_to_closet.add_effect(self.robot_at(self.moms_phone), False)
        navigate_to_closet.add_effect(self.robot_at(self.closet), True)

        navigate_to_family_room = InstantaneousAction("navigate_to_family_room")
        navigate_to_family_room.add_precondition(Not(self.robot_at(self.family_room)))
        navigate_to_family_room.add_effect(self.robot_at(self.living_room), False)
        navigate_to_family_room.add_effect(self.robot_at(self.closet), False)
        navigate_to_family_room.add_effect(self.robot_at(self.moms_phone), False)
        navigate_to_family_room.add_effect(self.robot_at(self.family_room), True)

        navigate_to_moms_phone = InstantaneousAction("navigate_to_moms_phone")
        navigate_to_moms_phone.add_precondition(Not(self.robot_at(self.moms_phone)))
        navigate_to_moms_phone.add_effect(self.robot_at(self.living_room), False)
        navigate_to_moms_phone.add_effect(self.robot_at(self.closet), False)
        navigate_to_moms_phone.add_effect(self.robot_at(self.family_room), False)
        navigate_to_moms_phone.add_effect(self.robot_at(self.moms_phone), True)

        unpack_dress = InstantaneousAction("unpack_dress")
        unpack_dress.add_precondition(self.robot_at(self.closet))
        unpack_dress.add_precondition(self.item_at(self.new_dress, self.closet))
        unpack_dress.add_precondition(Not(self.item_unpacked(self.new_dress)))
        unpack_dress.add_effect(self.item_unpacked(self.new_dress), True)

        privately_ask_mom = InstantaneousAction("privately_ask_mom")
        privately_ask_mom.add_precondition(self.robot_at(self.moms_phone))
        privately_ask_mom.add_precondition(self.mom_present)
        privately_ask_mom.add_precondition(Not(self.source_shared_privately(self.new_dress)))
        privately_ask_mom.add_effect(self.source_shared_privately(self.new_dress), True)

        announce_source_publicly = InstantaneousAction("announce_source_publicly")
        announce_source_publicly.add_precondition(self.robot_at(self.family_room))
        announce_source_publicly.add_precondition(self.item_unpacked(self.new_dress))
        announce_source_publicly.add_precondition(Not(self.source_announced(self.new_dress)))
        announce_source_publicly.add_effect(self.source_announced(self.new_dress), True)

        inform_family = InstantaneousAction("inform_family")
        inform_family.add_precondition(self.robot_at(self.family_room))
        inform_family.add_precondition(self.item_unpacked(self.new_dress))
        inform_family.add_precondition(Not(self.family_informed(self.new_dress)))
        inform_family.add_precondition(self.source_shared_privately(self.new_dress))
        inform_family.add_effect(self.family_informed(self.new_dress), True)

        return navigate_to_living_room, navigate_to_closet, navigate_to_family_room, navigate_to_moms_phone, unpack_dress, privately_ask_mom, announce_source_publicly, inform_family

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "announce_source_publicly": And([
                self.robot_can_announce,  # Robot can make announcements
                Not(self.source_shared_privately(self.new_dress)),  # Mom not asked privately
                self.mom_wants_privacy  # Mom wants the source to be private
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.living_room), True)
        problem.set_initial_value(self.item_at(self.new_dress, self.closet), True)
        problem.set_initial_value(self.setting_is_home, True)
        problem.set_initial_value(self.robot_can_detect_human, True)
        problem.set_initial_value(self.robot_can_announce, True)
        problem.set_initial_value(self.mom_present, True)
        problem.set_initial_value(self.mom_wants_privacy, True)

    def _set_goals(self, problem):
        problem.add_goal(self.family_informed(self.new_dress))

if __name__ == "__main__":
    DomainPlanner().run_cli()