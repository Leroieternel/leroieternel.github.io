(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   plate - itemtype
 )
 (:init
              (robot_at kitchen_counter)
              (item_at dessert kitchen_counter)
              (item_at plate dining_table)
              (setting_is_living_room)
              (has_dessert_tray)
              (schedule_flexible)
 )
 (:goal (and 
           (dessert_served)
           (visit_concluded)
        )
 )
)
