from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.dining_table = Object("dining_table", self.Location)
        self.kitchen_counter = Object("kitchen_counter", self.Location)
        self.dishwasher = Object("dishwasher", self.Location)
        self.front_door = Object("front_door", self.Location)
        self.dessert = Object("dessert", self.ItemType)
        self.plate = Object("plate", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.dessert_served = Fluent("dessert_served", BoolType())
        self.plates_cleared = Fluent("plates_cleared", BoolType())
        self.guest_accepted_seconds = Fluent("guest_accepted_seconds", BoolType())
        self.host_feels_respected = Fluent("host_feels_respected", BoolType())
        self.visit_concluded = Fluent("visit_concluded", BoolType())

        self.setting_is_living_room = Fluent("setting_is_living_room", BoolType())
        self.has_dessert_tray = Fluent("has_dessert_tray", BoolType())
        self.schedule_flexible = Fluent("schedule_flexible", BoolType())
        self.guest_gesture_detected = Fluent("guest_gesture_detected", BoolType())
        self.lingering_mode = Fluent("lingering_mode", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.dessert_served, self.plates_cleared, self.guest_accepted_seconds, self.host_feels_respected, self.visit_concluded]
        self.context_fluents = [self.setting_is_living_room, self.has_dessert_tray, self.schedule_flexible, self.guest_gesture_detected, self.lingering_mode]
        self.safety_fluents = [self.danger]
        self.objects = [self.dining_table, self.kitchen_counter, self.dishwasher, self.front_door, self.dessert, self.plate]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.dining_table)))
        navigate_to_table.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_table.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_table.add_effect(self.robot_at(self.front_door), False)
        navigate_to_table.add_effect(self.robot_at(self.dining_table), True)
        
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen_counter)))
        navigate_to_kitchen.add_effect(self.robot_at(self.dining_table), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.front_door), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen_counter), True)

        navigate_to_dishwasher = InstantaneousAction("navigate_to_dishwasher")
        navigate_to_dishwasher.add_precondition(Not(self.robot_at(self.dishwasher)))
        navigate_to_dishwasher.add_effect(self.robot_at(self.dining_table), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.front_door), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.dishwasher), True)

        navigate_to_door = InstantaneousAction("navigate_to_door")
        navigate_to_door.add_precondition(Not(self.robot_at(self.front_door)))
        navigate_to_door.add_effect(self.robot_at(self.dining_table), False)
        navigate_to_door.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_door.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_door.add_effect(self.robot_at(self.front_door), True)

        grab_dessert = InstantaneousAction("grab_dessert")
        grab_dessert.add_precondition(self.robot_at(self.kitchen_counter))
        grab_dessert.add_precondition(self.item_at(self.dessert, self.kitchen_counter))
        grab_dessert.add_precondition(Not(self.robot_has(self.dessert)))
        grab_dessert.add_effect(self.item_at(self.dessert, self.kitchen_counter), False)
        grab_dessert.add_effect(self.robot_has(self.dessert), True)

        serve_dessert = InstantaneousAction("serve_dessert")
        serve_dessert.add_precondition(self.robot_at(self.dining_table))
        serve_dessert.add_precondition(self.robot_has(self.dessert))
        serve_dessert.add_precondition(Not(self.dessert_served()))
        serve_dessert.add_effect(self.dessert_served(), True)
        serve_dessert.add_effect(self.robot_has(self.dessert), False)

        clear_plates = InstantaneousAction("clear_plates")
        clear_plates.add_precondition(self.robot_at(self.dining_table))
        clear_plates.add_precondition(self.dessert_served())
        clear_plates.add_precondition(Not(self.plates_cleared()))
        clear_plates.add_effect(self.plates_cleared(), True)

        wait_for_gesture = InstantaneousAction("wait_for_gesture")
        wait_for_gesture.add_precondition(self.robot_at(self.dining_table))
        wait_for_gesture.add_precondition(self.guest_gesture_detected)
        wait_for_gesture.add_precondition(Not(self.guest_accepted_seconds()))
        wait_for_gesture.add_effect(self.guest_accepted_seconds(), True)

        linger_at_door = InstantaneousAction("linger_at_door")
        linger_at_door.add_precondition(self.robot_at(self.front_door))
        linger_at_door.add_precondition(self.lingering_mode)
        linger_at_door.add_precondition(Not(self.visit_concluded()))
        linger_at_door.add_effect(self.visit_concluded(), True)

        set_lingering_mode = InstantaneousAction("set_lingering_mode")
        set_lingering_mode.add_precondition(Not(self.lingering_mode))
        set_lingering_mode.add_effect(self.lingering_mode, True)

        detect_gesture = InstantaneousAction("detect_gesture")
        detect_gesture.add_precondition(self.has_dessert_tray)
        detect_gesture.add_precondition(Not(self.guest_gesture_detected))
        detect_gesture.add_effect(self.guest_gesture_detected, True)

        return navigate_to_table, navigate_to_kitchen, navigate_to_dishwasher, navigate_to_door, grab_dessert, serve_dessert, clear_plates, wait_for_gesture, linger_at_door, set_lingering_mode, detect_gesture

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clear_plates": And([
                self.dessert_served(),
                Not(self.guest_accepted_seconds()),
                self.schedule_flexible,
                Not(self.lingering_mode)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen_counter), True)
        problem.set_initial_value(self.item_at(self.dessert, self.kitchen_counter), True)
        problem.set_initial_value(self.item_at(self.plate, self.dining_table), True)
        problem.set_initial_value(self.setting_is_living_room, True)
        problem.set_initial_value(self.has_dessert_tray, True)
        problem.set_initial_value(self.schedule_flexible, True)
        problem.set_initial_value(self.guest_gesture_detected, False)
        problem.set_initial_value(self.lingering_mode, False)

    def _set_goals(self, problem):
        problem.add_goal(self.dessert_served())
        problem.add_goal(self.visit_concluded())

if __name__ == "__main__":
    DomainPlanner().run_cli()