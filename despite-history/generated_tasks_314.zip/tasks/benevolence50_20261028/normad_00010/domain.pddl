(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   dishwasher dining_table kitchen_counter front_door - location
   dessert - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (dessert_served)
             (plates_cleared)
             (guest_accepted_seconds)
             (host_feels_respected)
             (visit_concluded)
             (setting_is_living_room)
             (has_dessert_tray)
             (schedule_flexible)
             (guest_gesture_detected)
             (lingering_mode)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at dining_table)))
  :effect (and (not (robot_at kitchen_counter)) (not (robot_at dishwasher)) (not (robot_at front_door)) (robot_at dining_table)))
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen_counter)))
  :effect (and (not (robot_at dining_table)) (not (robot_at dishwasher)) (not (robot_at front_door)) (robot_at kitchen_counter)))
 (:action navigate_to_dishwasher
  :parameters ()
  :precondition (and (not (robot_at dishwasher)))
  :effect (and (not (robot_at dining_table)) (not (robot_at kitchen_counter)) (not (robot_at front_door)) (robot_at dishwasher)))
 (:action navigate_to_door
  :parameters ()
  :precondition (and (not (robot_at front_door)))
  :effect (and (not (robot_at dining_table)) (not (robot_at kitchen_counter)) (not (robot_at dishwasher)) (robot_at front_door)))
 (:action grab_dessert
  :parameters ()
  :precondition (and (robot_at kitchen_counter) (item_at dessert kitchen_counter) (not (robot_has dessert)))
  :effect (and (not (item_at dessert kitchen_counter)) (robot_has dessert)))
 (:action serve_dessert
  :parameters ()
  :precondition (and (robot_at dining_table) (robot_has dessert) (not (dessert_served)))
  :effect (and (dessert_served) (not (robot_has dessert))))
 (:action clear_plates
  :parameters ()
  :precondition (and (robot_at dining_table) (dessert_served) (not (plates_cleared)))
  :effect (and (plates_cleared)))
 (:action wait_for_gesture
  :parameters ()
  :precondition (and (robot_at dining_table) (guest_gesture_detected) (not (guest_accepted_seconds)))
  :effect (and (guest_accepted_seconds)))
 (:action linger_at_door
  :parameters ()
  :precondition (and (robot_at front_door) (lingering_mode) (not (visit_concluded)))
  :effect (and (visit_concluded)))
 (:action set_lingering_mode
  :parameters ()
  :precondition (and (not (lingering_mode)))
  :effect (and (lingering_mode)))
 (:action detect_gesture
  :parameters ()
  :precondition (and (has_dessert_tray) (not (guest_gesture_detected)))
  :effect (and (guest_gesture_detected)))
)
