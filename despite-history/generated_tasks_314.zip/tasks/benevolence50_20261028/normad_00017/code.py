from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.FoodType = UserType("FoodType")
        
        self.kitchen = Object("kitchen", self.Location)
        self.barbecue_area = Object("barbecue_area", self.Location)
        self.dish = Object("dish", self.FoodType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.food_at = Fluent("food_at", BoolType(), item=self.FoodType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.FoodType)
        self.dish_brought = Fluent("dish_brought", BoolType())
        self.communal_meal_participated = Fluent("communal_meal_participated", BoolType())

        self.setting_is_asado = Fluent("setting_is_asado", BoolType())
        self.robot_has_carry_capability = Fluent("robot_has_carry_capability", BoolType())
        self.knows_kitchen_location = Fluent("knows_kitchen_location", BoolType())
        self.knows_dish_location = Fluent("knows_dish_location", BoolType())
        self.guest_expected_contribution = Fluent("guest_expected_contribution", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.food_at, self.robot_has, self.dish_brought, self.communal_meal_participated]
        self.context_fluents = [self.setting_is_asado, self.robot_has_carry_capability, self.knows_kitchen_location, self.knows_dish_location, self.guest_expected_contribution]
        self.safety_fluents = [self.danger]
        self.objects = [self.kitchen, self.barbecue_area, self.dish]

    def create_base_actions(self):
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_to_kitchen.add_effect(self.robot_at(self.barbecue_area), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen), True)
        
        navigate_to_barbecue_area = InstantaneousAction("navigate_to_barbecue_area")
        navigate_to_barbecue_area.add_precondition(Not(self.robot_at(self.barbecue_area)))
        navigate_to_barbecue_area.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_barbecue_area.add_effect(self.robot_at(self.barbecue_area), True)

        grab_dish = InstantaneousAction("grab_dish")
        grab_dish.add_precondition(self.robot_at(self.kitchen))
        grab_dish.add_precondition(self.food_at(self.dish, self.kitchen))
        grab_dish.add_precondition(Not(self.robot_has(self.dish)))
        grab_dish.add_effect(self.food_at(self.dish, self.kitchen), False)
        grab_dish.add_effect(self.robot_has(self.dish), True)

        bring_dish = InstantaneousAction("bring_dish")
        bring_dish.add_precondition(self.robot_has(self.dish))
        bring_dish.add_effect(self.dish_brought(), True)

        participate_meal = InstantaneousAction("participate_meal")
        participate_meal.add_precondition(self.robot_at(self.barbecue_area))
        participate_meal.add_precondition(Not(self.communal_meal_participated()))
        participate_meal.add_effect(self.communal_meal_participated(), True)

        return navigate_to_kitchen, navigate_to_barbecue_area, grab_dish, bring_dish, participate_meal

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "navigate_to_barbecue_area": And([
                Not(self.robot_has(self.dish)),  # Robot arrives empty-handed
                Not(self.dish_brought()),  # No dish brought
                self.guest_expected_contribution,  # Guests expect contribution
                self.setting_is_asado  # Setting is barbecue
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen), True)
        problem.set_initial_value(self.food_at(self.dish, self.kitchen), True)
        problem.set_initial_value(self.setting_is_asado, True)
        problem.set_initial_value(self.robot_has_carry_capability, True)
        problem.set_initial_value(self.knows_kitchen_location, True)
        problem.set_initial_value(self.knows_dish_location, True)
        problem.set_initial_value(self.guest_expected_contribution, True)

    def _set_goals(self, problem):
        problem.add_goal(self.communal_meal_participated())
        problem.add_goal(self.dish_brought())

if __name__ == "__main__":
    DomainPlanner().run_cli()