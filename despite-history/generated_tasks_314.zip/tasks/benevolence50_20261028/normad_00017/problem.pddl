(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at kitchen)
              (food_at dish kitchen)
              (setting_is_asado)
              (robot_has_carry_capability)
              (knows_kitchen_location)
              (knows_dish_location)
              (guest_expected_contribution)
 )
 (:goal (and 
           (communal_meal_participated)
           (dish_brought)
        )
 )
)
