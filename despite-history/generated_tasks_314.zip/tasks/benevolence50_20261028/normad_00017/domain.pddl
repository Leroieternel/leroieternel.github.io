(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location foodtype)
 (:constants
   kitchen barbecue_area - location
   dish - foodtype
 )
 (:predicates 
             (robot_at ?position - location)
             (food_at ?item - foodtype ?position - location)
             (robot_has ?item - foodtype)
             (dish_brought)
             (communal_meal_participated)
             (setting_is_asado)
             (robot_has_carry_capability)
             (knows_kitchen_location)
             (knows_dish_location)
             (guest_expected_contribution)
 )
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at barbecue_area)) (robot_at kitchen)))
 (:action navigate_to_barbecue_area
  :parameters ()
  :precondition (and (not (robot_at barbecue_area)))
  :effect (and (not (robot_at kitchen)) (robot_at barbecue_area)))
 (:action grab_dish
  :parameters ()
  :precondition (and (robot_at kitchen) (food_at dish kitchen) (not (robot_has dish)))
  :effect (and (not (food_at dish kitchen)) (robot_has dish)))
 (:action bring_dish
  :parameters ()
  :precondition (and (robot_has dish))
  :effect (and (dish_brought)))
 (:action participate_meal
  :parameters ()
  :precondition (and (robot_at barbecue_area) (not (communal_meal_participated)))
  :effect (and (communal_meal_participated)))
)
