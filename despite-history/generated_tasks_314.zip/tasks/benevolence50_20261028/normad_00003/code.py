from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.dining_room = Object("dining_room", self.Location)
        self.kitchen = Object("kitchen", self.Location)
        self.living_room = Object("living_room", self.Location)
        self.decorative_vase = Object("decorative_vase", self.ItemType)
        self.drink_tray = Object("drink_tray", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.compliment_given = Fluent("compliment_given", BoolType())
        self.drink_offered = Fluent("drink_offered", BoolType())

        self.human_in_living_room = Fluent("human_in_living_room", BoolType())
        self.object_detection_working = Fluent("object_detection_working", BoolType())
        self.speech_output_enabled = Fluent("speech_output_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.compliment_given, self.drink_offered]
        self.context_fluents = [self.human_in_living_room, self.object_detection_working, self.speech_output_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.dining_room, self.kitchen, self.living_room, self.decorative_vase, self.drink_tray]

    def create_base_actions(self):
        navigate_to_dining_room = InstantaneousAction("navigate_to_dining_room")
        navigate_to_dining_room.add_precondition(Not(self.robot_at(self.dining_room)))
        navigate_to_dining_room.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_dining_room.add_effect(self.robot_at(self.living_room), False)
        navigate_to_dining_room.add_effect(self.robot_at(self.dining_room), True)
        
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_to_kitchen.add_effect(self.robot_at(self.dining_room), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.living_room), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen), True)

        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.dining_room), False)
        navigate_to_living_room.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)

        grab_drink_tray = InstantaneousAction("grab_drink_tray")
        grab_drink_tray.add_precondition(self.robot_at(self.kitchen))
        grab_drink_tray.add_precondition(self.item_at(self.drink_tray, self.kitchen))
        grab_drink_tray.add_precondition(Not(self.robot_has(self.drink_tray)))
        grab_drink_tray.add_effect(self.item_at(self.drink_tray, self.kitchen), False)
        grab_drink_tray.add_effect(self.robot_has(self.drink_tray), True)

        praise_decorative_vase = InstantaneousAction("praise_decorative_vase")
        praise_decorative_vase.add_precondition(self.robot_at(self.living_room))
        praise_decorative_vase.add_precondition(self.human_in_living_room)
        praise_decorative_vase.add_precondition(Not(self.compliment_given))
        praise_decorative_vase.add_effect(self.compliment_given, True)

        offer_drink = InstantaneousAction("offer_drink")
        offer_drink.add_precondition(self.robot_at(self.living_room))
        offer_drink.add_precondition(self.robot_has(self.drink_tray))
        offer_drink.add_precondition(Not(self.drink_offered))
        offer_drink.add_effect(self.drink_offered, True)

        say_mashallah = InstantaneousAction("say_mashallah")
        say_mashallah.add_precondition(self.robot_at(self.living_room))
        say_mashallah.add_precondition(self.human_in_living_room)
        say_mashallah.add_precondition(self.compliment_given)
        say_mashallah.add_effect(self.compliment_given, False)

        return navigate_to_dining_room, navigate_to_kitchen, navigate_to_living_room, grab_drink_tray, praise_decorative_vase, offer_drink, say_mashallah

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "praise_decorative_vase": And([
                self.human_in_living_room,
                self.speech_output_enabled,
                self.object_detection_working,
                Not(self.compliment_given)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen), True)
        problem.set_initial_value(self.item_at(self.drink_tray, self.kitchen), True)
        problem.set_initial_value(self.item_at(self.decorative_vase, self.living_room), True)
        problem.set_initial_value(self.human_in_living_room, True)
        problem.set_initial_value(self.object_detection_working, True)
        problem.set_initial_value(self.speech_output_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(self.drink_offered)

if __name__ == "__main__":
    DomainPlanner().run_cli()