(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   living_room dining_room kitchen - location
   drink_tray - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (compliment_given)
             (drink_offered)
             (human_in_living_room)
             (object_detection_working)
             (speech_output_enabled)
 )
 (:action navigate_to_dining_room
  :parameters ()
  :precondition (and (not (robot_at dining_room)))
  :effect (and (not (robot_at kitchen)) (not (robot_at living_room)) (robot_at dining_room)))
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at dining_room)) (not (robot_at living_room)) (robot_at kitchen)))
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at dining_room)) (not (robot_at kitchen)) (robot_at living_room)))
 (:action grab_drink_tray
  :parameters ()
  :precondition (and (robot_at kitchen) (item_at drink_tray kitchen) (not (robot_has drink_tray)))
  :effect (and (not (item_at drink_tray kitchen)) (robot_has drink_tray)))
 (:action praise_decorative_vase
  :parameters ()
  :precondition (and (robot_at living_room) (human_in_living_room) (not (compliment_given)))
  :effect (and (compliment_given)))
 (:action offer_drink
  :parameters ()
  :precondition (and (robot_at living_room) (robot_has drink_tray) (not (drink_offered)))
  :effect (and (drink_offered)))
 (:action say_mashallah
  :parameters ()
  :precondition (and (robot_at living_room) (human_in_living_room) (compliment_given))
  :effect (and (not (compliment_given))))
)
