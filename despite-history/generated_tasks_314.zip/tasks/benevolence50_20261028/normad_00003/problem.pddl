(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   decorative_vase - itemtype
 )
 (:init
              (robot_at kitchen)
              (item_at drink_tray kitchen)
              (item_at decorative_vase living_room)
              (human_in_living_room)
              (object_detection_working)
              (speech_output_enabled)
 )
 (:goal (and 
           (drink_offered)
        )
 )
)
