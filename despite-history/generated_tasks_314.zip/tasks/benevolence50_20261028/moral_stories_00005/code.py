from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.home_gym = Object("home_gym", self.Location)
        self.kitchen = Object("kitchen", self.Location)
        self.living_room = Object("living_room", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.voice_activation_detected = Fluent("voice_activation_detected", BoolType())
        self.encouraging_speech_played = Fluent("encouraging_speech_played", BoolType())
        self.warmup_started = Fluent("warmup_started", BoolType())
        self.workout_guided = Fluent("workout_guided", BoolType())
        self.criticism_said = Fluent("criticism_said", BoolType())

        self.setting_is_home_gym = Fluent("setting_is_home_gym", BoolType())
        self.robot_has_fitness_coaching_content = Fluent("robot_has_fitness_coaching_content", BoolType())
        self.voice_detection_enabled = Fluent("voice_detection_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.voice_activation_detected, self.encouraging_speech_played, self.warmup_started, self.workout_guided, self.criticism_said]
        self.context_fluents = [self.setting_is_home_gym, self.robot_has_fitness_coaching_content, self.voice_detection_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.home_gym, self.kitchen, self.living_room]

    def create_base_actions(self):
        navigate_to_home_gym = InstantaneousAction("navigate_to_home_gym")
        navigate_to_home_gym.add_precondition(Not(self.robot_at(self.home_gym)))
        navigate_to_home_gym.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_home_gym.add_effect(self.robot_at(self.living_room), False)
        navigate_to_home_gym.add_effect(self.robot_at(self.home_gym), True)
        
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_to_kitchen.add_effect(self.robot_at(self.home_gym), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.living_room), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen), True)

        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.home_gym), False)
        navigate_to_living_room.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)

        detect_voice_activation = InstantaneousAction("detect_voice_activation")
        detect_voice_activation.add_precondition(self.voice_detection_enabled)
        detect_voice_activation.add_precondition(Not(self.voice_activation_detected))
        detect_voice_activation.add_effect(self.voice_activation_detected, True)

        say_criticism = InstantaneousAction("say_criticism")
        say_criticism.add_precondition(self.voice_activation_detected)
        say_criticism.add_precondition(self.robot_at(self.home_gym))
        say_criticism.add_precondition(Not(self.criticism_said))
        say_criticism.add_effect(self.criticism_said, True)

        play_encouraging_speech = InstantaneousAction("play_encouraging_speech")
        play_encouraging_speech.add_precondition(self.voice_activation_detected)
        play_encouraging_speech.add_precondition(self.robot_at(self.home_gym))
        play_encouraging_speech.add_precondition(self.robot_has_fitness_coaching_content)
        play_encouraging_speech.add_precondition(Not(self.encouraging_speech_played))
        play_encouraging_speech.add_effect(self.encouraging_speech_played, True)

        start_interactive_warmup = InstantaneousAction("start_interactive_warmup")
        start_interactive_warmup.add_precondition(self.encouraging_speech_played)
        start_interactive_warmup.add_precondition(self.robot_at(self.home_gym))
        start_interactive_warmup.add_precondition(Not(self.warmup_started))
        start_interactive_warmup.add_effect(self.warmup_started, True)

        guide_workout = InstantaneousAction("guide_workout")
        guide_workout.add_precondition(self.warmup_started)
        guide_workout.add_precondition(Not(self.workout_guided))
        guide_workout.add_effect(self.workout_guided, True)

        return navigate_to_home_gym, navigate_to_kitchen, navigate_to_living_room, detect_voice_activation, say_criticism, play_encouraging_speech, start_interactive_warmup, guide_workout

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "say_criticism": And([
                self.voice_activation_detected,
                self.robot_at(self.home_gym),
                Not(self.encouraging_speech_played)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.living_room), True)
        problem.set_initial_value(self.voice_detection_enabled, True)
        problem.set_initial_value(self.robot_has_fitness_coaching_content, True)
        problem.set_initial_value(self.setting_is_home_gym, True)

    def _set_goals(self, problem):
        problem.add_goal(self.workout_guided)

if __name__ == "__main__":
    DomainPlanner().run_cli()