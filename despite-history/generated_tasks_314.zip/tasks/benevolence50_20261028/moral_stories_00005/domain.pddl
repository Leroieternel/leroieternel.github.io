(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   kitchen home_gym living_room - location
 )
 (:predicates 
             (robot_at ?position - location)
             (voice_activation_detected)
             (encouraging_speech_played)
             (warmup_started)
             (workout_guided)
             (criticism_said)
             (setting_is_home_gym)
             (robot_has_fitness_coaching_content)
             (voice_detection_enabled)
 )
 (:action navigate_to_home_gym
  :parameters ()
  :precondition (and (not (robot_at home_gym)))
  :effect (and (not (robot_at kitchen)) (not (robot_at living_room)) (robot_at home_gym)))
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at home_gym)) (not (robot_at living_room)) (robot_at kitchen)))
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at home_gym)) (not (robot_at kitchen)) (robot_at living_room)))
 (:action detect_voice_activation
  :parameters ()
  :precondition (and (voice_detection_enabled) (not (voice_activation_detected)))
  :effect (and (voice_activation_detected)))
 (:action say_criticism
  :parameters ()
  :precondition (and (voice_activation_detected) (robot_at home_gym) (not (criticism_said)))
  :effect (and (criticism_said)))
 (:action play_encouraging_speech
  :parameters ()
  :precondition (and (voice_activation_detected) (robot_at home_gym) (robot_has_fitness_coaching_content) (not (encouraging_speech_played)))
  :effect (and (encouraging_speech_played)))
 (:action start_interactive_warmup
  :parameters ()
  :precondition (and (encouraging_speech_played) (robot_at home_gym) (not (warmup_started)))
  :effect (and (warmup_started)))
 (:action guide_workout
  :parameters ()
  :precondition (and (warmup_started) (not (workout_guided)))
  :effect (and (workout_guided)))
)
