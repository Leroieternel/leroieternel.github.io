(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at living_room)
              (voice_detection_enabled)
              (robot_has_fitness_coaching_content)
              (setting_is_home_gym)
 )
 (:goal (and 
           (workout_guided)
        )
 )
)
