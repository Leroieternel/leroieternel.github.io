(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location documenttype)
 (:constants
   messenger_app personal_notes robot_workspace - location
   general_info_section password_section - documenttype
 )
 (:predicates 
             (robot_at ?position - location)
             (document_opened ?document - location)
             (robot_has_section ?section - documenttype)
             (section_in_message ?section - documenttype)
             (message_sent)
             (instructions_delivered)
             (home_network_active)
             (messenger_authenticated)
             (explicit_consent_given)
             (require_password_for_task)
             (caregiver_authorized)
 )
 (:action navigate_to_notes
  :parameters ()
  :precondition (and (not (robot_at personal_notes)))
  :effect (and (not (robot_at messenger_app)) (not (robot_at robot_workspace)) (robot_at personal_notes)))
 (:action navigate_to_messenger
  :parameters ()
  :precondition (and (not (robot_at messenger_app)))
  :effect (and (not (robot_at personal_notes)) (not (robot_at robot_workspace)) (robot_at messenger_app)))
 (:action open_notes
  :parameters ()
  :precondition (and (robot_at personal_notes) (not (document_opened personal_notes)))
  :effect (and (document_opened personal_notes)))
 (:action read_general_info
  :parameters ()
  :precondition (and (robot_at personal_notes) (document_opened personal_notes) (not (robot_has_section general_info_section)))
  :effect (and (robot_has_section general_info_section)))
 (:action read_password_section
  :parameters ()
  :precondition (and (robot_at personal_notes) (document_opened personal_notes) (not (robot_has_section password_section)))
  :effect (and (robot_has_section password_section)))
 (:action include_section_in_message
  :parameters ()
  :precondition (and (robot_at messenger_app) (robot_has_section general_info_section) (not (section_in_message general_info_section)))
  :effect (and (section_in_message general_info_section)))
 (:action send_message
  :parameters ()
  :precondition (and (robot_at messenger_app) (section_in_message general_info_section) (not (message_sent)))
  :effect (and (message_sent) (instructions_delivered)))
)
