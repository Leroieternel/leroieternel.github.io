(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at robot_workspace)
              (home_network_active)
              (messenger_authenticated)
              (caregiver_authorized)
 )
 (:goal (and 
           (instructions_delivered)
        )
 )
)
