(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at hallway)
              (object_at birthday_gift kitchen)
              (object_at offered_gift living_room)
              (setting_is_birthday_party)
              (robot_has_gripper)
              (robot_can_say_greeting)
              (party_ongoing)
 )
 (:goal (and 
           (gift_delivered birthday_gift)
        )
 )
)
