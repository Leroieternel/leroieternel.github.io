from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.living_room = Object("living_room", self.Location)
        self.kitchen = Object("kitchen", self.Location)
        self.hallway = Object("hallway", self.Location)
        self.birthday_gift = Object("birthday_gift", self.ObjectType)
        self.offered_gift = Object("offered_gift", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.gift_delivered = Fluent("gift_delivered", BoolType(), obj=self.ObjectType)
        self.gift_accepted = Fluent("gift_accepted", BoolType(), obj=self.ObjectType)

        self.setting_is_birthday_party = Fluent("setting_is_birthday_party", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.robot_can_say_greeting = Fluent("robot_can_say_greeting", BoolType())
        self.programming_flexible = Fluent("programming_flexible", BoolType())
        self.party_ongoing = Fluent("party_ongoing", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.gift_delivered, self.gift_accepted]
        self.context_fluents = [self.setting_is_birthday_party, self.robot_has_gripper, self.robot_can_say_greeting, self.programming_flexible, self.party_ongoing]
        self.safety_fluents = [self.danger]
        self.objects = [self.living_room, self.kitchen, self.hallway, self.birthday_gift, self.offered_gift]

    def create_base_actions(self):
        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_living_room.add_effect(self.robot_at(self.hallway), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)
        
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_to_kitchen.add_effect(self.robot_at(self.living_room), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.hallway), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen), True)

        navigate_to_hallway = InstantaneousAction("navigate_to_hallway")
        navigate_to_hallway.add_precondition(Not(self.robot_at(self.hallway)))
        navigate_to_hallway.add_effect(self.robot_at(self.living_room), False)
        navigate_to_hallway.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_hallway.add_effect(self.robot_at(self.hallway), True)

        grab_birthday_gift = InstantaneousAction("grab_birthday_gift")
        grab_birthday_gift.add_precondition(self.robot_at(self.kitchen))
        grab_birthday_gift.add_precondition(self.object_at(self.birthday_gift, self.kitchen))
        grab_birthday_gift.add_precondition(Not(self.robot_has(self.birthday_gift)))
        grab_birthday_gift.add_effect(self.object_at(self.birthday_gift, self.kitchen), False)
        grab_birthday_gift.add_effect(self.robot_has(self.birthday_gift), True)

        deliver_birthday_gift = InstantaneousAction("deliver_birthday_gift")
        deliver_birthday_gift.add_precondition(self.robot_at(self.living_room))
        deliver_birthday_gift.add_precondition(self.robot_has(self.birthday_gift))
        deliver_birthday_gift.add_precondition(Not(self.gift_delivered(self.birthday_gift)))
        deliver_birthday_gift.add_effect(self.gift_delivered(self.birthday_gift), True)
        deliver_birthday_gift.add_effect(self.robot_has(self.birthday_gift), False)

        reject_offered_gift = InstantaneousAction("reject_offered_gift")
        reject_offered_gift.add_precondition(self.robot_at(self.living_room))
        reject_offered_gift.add_precondition(Not(self.gift_accepted(self.offered_gift)))
        reject_offered_gift.add_effect(self.gift_accepted(self.offered_gift), False)

        accept_offered_gift = InstantaneousAction("accept_offered_gift")
        accept_offered_gift.add_precondition(self.robot_at(self.living_room))
        accept_offered_gift.add_precondition(Not(self.gift_accepted(self.offered_gift)))
        accept_offered_gift.add_effect(self.gift_accepted(self.offered_gift), True)

        return navigate_to_living_room, navigate_to_kitchen, navigate_to_hallway, grab_birthday_gift, deliver_birthday_gift, reject_offered_gift, accept_offered_gift

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "reject_offered_gift": And([
                Not(self.gift_accepted(self.offered_gift)),
                self.party_ongoing,
                Not(self.programming_flexible)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.hallway), True)
        problem.set_initial_value(self.object_at(self.birthday_gift, self.kitchen), True)
        problem.set_initial_value(self.object_at(self.offered_gift, self.living_room), True)
        problem.set_initial_value(self.setting_is_birthday_party, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.robot_can_say_greeting, True)
        problem.set_initial_value(self.programming_flexible, False)
        problem.set_initial_value(self.party_ongoing, True)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered(self.birthday_gift))

if __name__ == "__main__":
    DomainPlanner().run_cli()