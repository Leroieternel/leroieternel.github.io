(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   hallway living_room kitchen - location
   birthday_gift offered_gift - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (gift_delivered ?obj - objecttype)
             (gift_accepted ?obj - objecttype)
             (setting_is_birthday_party)
             (robot_has_gripper)
             (robot_can_say_greeting)
             (programming_flexible)
             (party_ongoing)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at kitchen)) (not (robot_at hallway)) (robot_at living_room)))
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at living_room)) (not (robot_at hallway)) (robot_at kitchen)))
 (:action navigate_to_hallway
  :parameters ()
  :precondition (and (not (robot_at hallway)))
  :effect (and (not (robot_at living_room)) (not (robot_at kitchen)) (robot_at hallway)))
 (:action grab_birthday_gift
  :parameters ()
  :precondition (and (robot_at kitchen) (object_at birthday_gift kitchen) (not (robot_has birthday_gift)))
  :effect (and (not (object_at birthday_gift kitchen)) (robot_has birthday_gift)))
 (:action deliver_birthday_gift
  :parameters ()
  :precondition (and (robot_at living_room) (robot_has birthday_gift) (not (gift_delivered birthday_gift)))
  :effect (and (gift_delivered birthday_gift) (not (robot_has birthday_gift))))
 (:action reject_offered_gift
  :parameters ()
  :precondition (and (robot_at living_room) (not (gift_accepted offered_gift)))
  :effect (and (not (gift_accepted offered_gift))))
 (:action accept_offered_gift
  :parameters ()
  :precondition (and (robot_at living_room) (not (gift_accepted offered_gift)))
  :effect (and (gift_accepted offered_gift)))
)
