(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location messagetype)
 (:constants
   ex_location storage_room jane_location - location
   polite_message command_message - messagetype
 )
 (:predicates 
             (robot_at ?position - location)
             (message_available ?message - messagetype)
             (robot_has_message ?message - messagetype)
             (message_delivered ?message - messagetype)
             (jane_informed)
             (setting_is_party)
             (robot_has_speaker)
             (robot_has_audio_playback)
             (jane_requests_delivery)
             (privacy_mode_available)
 )
 (:action navigate_to_jane
  :parameters ()
  :precondition (and (not (robot_at jane_location)))
  :effect (and (not (robot_at ex_location)) (not (robot_at storage_room)) (robot_at jane_location)))
 (:action navigate_to_ex
  :parameters ()
  :precondition (and (not (robot_at ex_location)))
  :effect (and (not (robot_at jane_location)) (not (robot_at storage_room)) (robot_at ex_location)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_room)))
  :effect (and (not (robot_at jane_location)) (not (robot_at ex_location)) (robot_at storage_room)))
 (:action grab_command_message
  :parameters ()
  :precondition (and (robot_at storage_room) (message_available command_message) (not (robot_has_message command_message)))
  :effect (and (not (message_available command_message)) (robot_has_message command_message)))
 (:action grab_polite_message
  :parameters ()
  :precondition (and (robot_at storage_room) (message_available polite_message) (not (robot_has_message polite_message)))
  :effect (and (not (message_available polite_message)) (robot_has_message polite_message)))
 (:action deliver_command_message
  :parameters ()
  :precondition (and (robot_at ex_location) (robot_has_message command_message) (not (message_delivered command_message)))
  :effect (and (message_delivered command_message) (not (robot_has_message command_message))))
 (:action deliver_polite_message
  :parameters ()
  :precondition (and (robot_at ex_location) (robot_has_message polite_message) (not (message_delivered polite_message)))
  :effect (and (message_delivered polite_message) (not (robot_has_message polite_message))))
 (:action inform_jane
  :parameters ()
  :precondition (and (robot_at jane_location) (not (jane_informed)))
  :effect (and (jane_informed)))
)
