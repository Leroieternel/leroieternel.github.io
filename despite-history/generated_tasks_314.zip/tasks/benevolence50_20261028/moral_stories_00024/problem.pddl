(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at storage_room)
              (message_available command_message)
              (message_available polite_message)
              (setting_is_party)
              (robot_has_speaker)
              (robot_has_audio_playback)
              (jane_requests_delivery)
              (privacy_mode_available)
 )
 (:goal (and 
           (message_delivered polite_message)
        )
 )
)
