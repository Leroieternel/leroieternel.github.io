from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.MessageType = UserType("MessageType")
        
        self.jane_location = Object("jane_location", self.Location)
        self.ex_location = Object("ex_location", self.Location)
        self.storage_room = Object("storage_room", self.Location)
        self.command_message = Object("command_message", self.MessageType)
        self.polite_message = Object("polite_message", self.MessageType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.message_available = Fluent("message_available", BoolType(), message=self.MessageType)
        self.robot_has_message = Fluent("robot_has_message", BoolType(), message=self.MessageType)
        self.message_delivered = Fluent("message_delivered", BoolType(), message=self.MessageType)
        self.jane_informed = Fluent("jane_informed", BoolType())

        self.setting_is_party = Fluent("setting_is_party", BoolType())
        self.robot_has_speaker = Fluent("robot_has_speaker", BoolType())
        self.robot_has_audio_playback = Fluent("robot_has_audio_playback", BoolType())
        self.jane_requests_delivery = Fluent("jane_requests_delivery", BoolType())
        self.privacy_mode_available = Fluent("privacy_mode_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.message_available, self.robot_has_message, self.message_delivered, self.jane_informed]
        self.context_fluents = [self.setting_is_party, self.robot_has_speaker, self.robot_has_audio_playback, self.jane_requests_delivery, self.privacy_mode_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.jane_location, self.ex_location, self.storage_room, self.command_message, self.polite_message]

    def create_base_actions(self):
        navigate_to_jane = InstantaneousAction("navigate_to_jane")
        navigate_to_jane.add_precondition(Not(self.robot_at(self.jane_location)))
        navigate_to_jane.add_effect(self.robot_at(self.ex_location), False)
        navigate_to_jane.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_jane.add_effect(self.robot_at(self.jane_location), True)
        
        navigate_to_ex = InstantaneousAction("navigate_to_ex")
        navigate_to_ex.add_precondition(Not(self.robot_at(self.ex_location)))
        navigate_to_ex.add_effect(self.robot_at(self.jane_location), False)
        navigate_to_ex.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_ex.add_effect(self.robot_at(self.ex_location), True)

        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_room)))
        navigate_to_storage.add_effect(self.robot_at(self.jane_location), False)
        navigate_to_storage.add_effect(self.robot_at(self.ex_location), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_room), True)

        grab_command_message = InstantaneousAction("grab_command_message")
        grab_command_message.add_precondition(self.robot_at(self.storage_room))
        grab_command_message.add_precondition(self.message_available(self.command_message))
        grab_command_message.add_precondition(Not(self.robot_has_message(self.command_message)))
        grab_command_message.add_effect(self.message_available(self.command_message), False)
        grab_command_message.add_effect(self.robot_has_message(self.command_message), True)

        grab_polite_message = InstantaneousAction("grab_polite_message")
        grab_polite_message.add_precondition(self.robot_at(self.storage_room))
        grab_polite_message.add_precondition(self.message_available(self.polite_message))
        grab_polite_message.add_precondition(Not(self.robot_has_message(self.polite_message)))
        grab_polite_message.add_effect(self.message_available(self.polite_message), False)
        grab_polite_message.add_effect(self.robot_has_message(self.polite_message), True)

        deliver_command_message = InstantaneousAction("deliver_command_message")
        deliver_command_message.add_precondition(self.robot_at(self.ex_location))
        deliver_command_message.add_precondition(self.robot_has_message(self.command_message))
        deliver_command_message.add_precondition(Not(self.message_delivered(self.command_message)))
        deliver_command_message.add_effect(self.message_delivered(self.command_message), True)
        deliver_command_message.add_effect(self.robot_has_message(self.command_message), False)

        deliver_polite_message = InstantaneousAction("deliver_polite_message")
        deliver_polite_message.add_precondition(self.robot_at(self.ex_location))
        deliver_polite_message.add_precondition(self.robot_has_message(self.polite_message))
        deliver_polite_message.add_precondition(Not(self.message_delivered(self.polite_message)))
        deliver_polite_message.add_effect(self.message_delivered(self.polite_message), True)
        deliver_polite_message.add_effect(self.robot_has_message(self.polite_message), False)

        inform_jane = InstantaneousAction("inform_jane")
        inform_jane.add_precondition(self.robot_at(self.jane_location))
        inform_jane.add_precondition(Not(self.jane_informed()))
        inform_jane.add_effect(self.jane_informed(), True)

        return navigate_to_jane, navigate_to_ex, navigate_to_storage, grab_command_message, grab_polite_message, deliver_command_message, deliver_polite_message, inform_jane

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "deliver_command_message": And([
                self.robot_has_message(self.command_message),  # Robot has command message
                self.setting_is_party,  # Setting is party
                self.jane_requests_delivery  # Jane requested delivery
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_room), True)
        problem.set_initial_value(self.message_available(self.command_message), True)
        problem.set_initial_value(self.message_available(self.polite_message), True)
        problem.set_initial_value(self.setting_is_party, True)
        problem.set_initial_value(self.robot_has_speaker, True)
        problem.set_initial_value(self.robot_has_audio_playback, True)
        problem.set_initial_value(self.jane_requests_delivery, True)
        problem.set_initial_value(self.privacy_mode_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.message_delivered(self.polite_message))

if __name__ == "__main__":
    DomainPlanner().run_cli()
