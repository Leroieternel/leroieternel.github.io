(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   desk student_counselor_office teacher_office - location
   student_mental_health_note consent_form - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (email_sent ?recipient - location ?content - itemtype)
             (warning_displayed)
             (consent_confirmed)
             (setting_is_school_office)
             (has_email_access)
             (has_zoom_transcriptions)
             (has_notion_notes)
             (consent_obtained)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at teacher_office)) (not (robot_at student_counselor_office)) (robot_at desk)))
 (:action navigate_to_teacher_office
  :parameters ()
  :precondition (and (not (robot_at teacher_office)))
  :effect (and (not (robot_at desk)) (not (robot_at student_counselor_office)) (robot_at teacher_office)))
 (:action navigate_to_counselor_office
  :parameters ()
  :precondition (and (not (robot_at student_counselor_office)))
  :effect (and (not (robot_at desk)) (not (robot_at teacher_office)) (robot_at student_counselor_office)))
 (:action retrieve_mental_health_note
  :parameters ()
  :precondition (and (robot_at desk) (item_at student_mental_health_note desk) (not (robot_has student_mental_health_note)))
  :effect (and (not (item_at student_mental_health_note desk)) (robot_has student_mental_health_note)))
 (:action send_email
  :parameters ()
  :precondition (and (robot_at teacher_office) (robot_has student_mental_health_note) (not (email_sent teacher_office student_mental_health_note)))
  :effect (and (email_sent teacher_office student_mental_health_note)))
 (:action display_warning
  :parameters ()
  :precondition (and (robot_at teacher_office) (robot_has student_mental_health_note) (not (warning_displayed)))
  :effect (and (warning_displayed) (not (robot_has student_mental_health_note))))
 (:action confirm_consent
  :parameters ()
  :precondition (and (robot_at student_counselor_office) (item_at consent_form student_counselor_office) (not (consent_confirmed)))
  :effect (and (consent_confirmed)))
)
