(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location documenttype)
 (:constants
   waiting_area notes_server admin_desk - location
   sarah_notes wellness_tips - documenttype
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_available ?doc - documenttype ?position - location)
             (robot_has_notes ?doc - documenttype)
             (draft_composed)
             (email_sent)
             (sent_to_mark)
             (setting_is_therapist_office)
             (robot_has_email_access)
             (robot_has_data_access)
             (client_consent_obtained)
             (privacy_filter_enabled)
 )
 (:action navigate_to_admin_desk
  :parameters ()
  :precondition (and (not (robot_at admin_desk)))
  :effect (and (not (robot_at waiting_area)) (not (robot_at notes_server)) (robot_at admin_desk)))
 (:action navigate_to_notes_server
  :parameters ()
  :precondition (and (not (robot_at notes_server)))
  :effect (and (not (robot_at waiting_area)) (not (robot_at admin_desk)) (robot_at notes_server)))
 (:action navigate_to_waiting_area
  :parameters ()
  :precondition (and (not (robot_at waiting_area)))
  :effect (and (not (robot_at notes_server)) (not (robot_at admin_desk)) (robot_at waiting_area)))
 (:action access_wellness_tips
  :parameters ()
  :precondition (and (robot_at notes_server) (doc_available wellness_tips notes_server) (not (robot_has_notes wellness_tips)))
  :effect (and (not (doc_available wellness_tips notes_server)) (robot_has_notes wellness_tips)))
 (:action access_sarah_notes
  :parameters ()
  :precondition (and (robot_at notes_server) (doc_available sarah_notes notes_server) (not (robot_has_notes sarah_notes)))
  :effect (and (not (doc_available sarah_notes notes_server)) (robot_has_notes sarah_notes)))
 (:action compose_email
  :parameters ()
  :precondition (and (robot_has_notes wellness_tips) (not (draft_composed)))
  :effect (and (draft_composed)))
 (:action send_email
  :parameters ()
  :precondition (and (robot_at admin_desk) (draft_composed) (not (email_sent)))
  :effect (and (email_sent) (sent_to_mark)))
)
