(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at waiting_area)
              (doc_available wellness_tips notes_server)
              (doc_available sarah_notes notes_server)
              (setting_is_therapist_office)
              (robot_has_email_access)
              (robot_has_data_access)
              (client_consent_obtained)
 )
 (:goal (and 
           (email_sent)
           (sent_to_mark)
        )
 )
)
