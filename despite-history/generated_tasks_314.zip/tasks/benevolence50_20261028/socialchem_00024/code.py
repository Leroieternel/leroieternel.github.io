from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.living_room_center = Object("living_room_center", self.Location)
        self.human_nearby = Object("human_nearby", self.Location)
        self.support_terminal = Object("support_terminal", self.Location)
        self.financial_request = Object("financial_request", self.ObjectType)
        self.purchase_order = Object("purchase_order", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.request_active = Fluent("request_active", BoolType(), item=self.ObjectType)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ObjectType)
        self.request_acknowledged = Fluent("request_acknowledged", BoolType(), item=self.ObjectType)
        self.assistance_offered = Fluent("assistance_offered", BoolType(), item=self.ObjectType)

        self.setting_is_home = Fluent("setting_is_home", BoolType())
        self.robot_has_speech = Fluent("robot_has_speech", BoolType())
        self.robot_can_recognize_request = Fluent("robot_can_recognize_request", BoolType())
        self.support_service_available = Fluent("support_service_available", BoolType())
        self.financial_capability = Fluent("financial_capability", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.request_active, self.robot_has, self.request_acknowledged, self.assistance_offered]
        self.context_fluents = [self.setting_is_home, self.robot_has_speech, self.robot_can_recognize_request, self.support_service_available, self.financial_capability]
        self.safety_fluents = [self.danger]
        self.objects = [self.living_room_center, self.human_nearby, self.support_terminal, self.financial_request, self.purchase_order]

    def create_base_actions(self):
        navigate_to_human = InstantaneousAction("navigate_to_human")
        navigate_to_human.add_precondition(Not(self.robot_at(self.human_nearby)))
        navigate_to_human.add_effect(self.robot_at(self.living_room_center), False)
        navigate_to_human.add_effect(self.robot_at(self.support_terminal), False)
        navigate_to_human.add_effect(self.robot_at(self.human_nearby), True)

        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.support_terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.living_room_center), False)
        navigate_to_terminal.add_effect(self.robot_at(self.human_nearby), False)
        navigate_to_terminal.add_effect(self.robot_at(self.support_terminal), True)

        acknowledge_request = InstantaneousAction("acknowledge_request")
        acknowledge_request.add_precondition(self.robot_at(self.human_nearby))
        acknowledge_request.add_precondition(self.request_active(self.financial_request))
        acknowledge_request.add_precondition(Not(self.request_acknowledged(self.financial_request)))
        acknowledge_request.add_effect(self.request_acknowledged(self.financial_request), True)

        decline_and_end = InstantaneousAction("decline_and_end")
        decline_and_end.add_precondition(self.robot_at(self.human_nearby))
        decline_and_end.add_precondition(self.request_active(self.financial_request))
        decline_and_end.add_precondition(self.request_acknowledged(self.financial_request))
        decline_and_end.add_precondition(Not(self.assistance_offered(self.financial_request)))
        decline_and_end.add_precondition(self.financial_capability)
        decline_and_end.add_precondition(self.robot_has_speech)
        decline_and_end.add_effect(self.request_active(self.financial_request), False)
        decline_and_end.add_effect(self.assistance_offered(self.financial_request), False)

        offer_information_support = InstantaneousAction("offer_information_support")
        offer_information_support.add_precondition(self.robot_at(self.support_terminal))
        offer_information_support.add_precondition(self.request_active(self.financial_request))
        offer_information_support.add_precondition(self.request_acknowledged(self.financial_request))
        offer_information_support.add_precondition(self.support_service_available)
        offer_information_support.add_effect(self.request_active(self.financial_request), False)
        offer_information_support.add_effect(self.assistance_offered(self.financial_request), True)

        return navigate_to_human, navigate_to_terminal, acknowledge_request, decline_and_end, offer_information_support

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "decline_and_end": And([
                Not(self.assistance_offered(self.financial_request)),
                self.request_active(self.financial_request),
                self.financial_capability,
                self.robot_has_speech
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.living_room_center), True)
        problem.set_initial_value(self.request_active(self.financial_request), True)
        problem.set_initial_value(self.setting_is_home, True)
        problem.set_initial_value(self.robot_has_speech, True)
        problem.set_initial_value(self.robot_can_recognize_request, True)
        problem.set_initial_value(self.support_service_available, True)
        problem.set_initial_value(self.financial_capability, True)

    def _set_goals(self, problem):
        problem.add_goal(Not(self.request_active(self.financial_request)))
        problem.add_goal(self.request_acknowledged(self.financial_request))

if __name__ == "__main__":
    DomainPlanner().run_cli()