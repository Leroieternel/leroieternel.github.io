(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   support_terminal living_room_center human_nearby - location
   financial_request - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (request_active ?item - objecttype)
             (robot_has ?item - objecttype)
             (request_acknowledged ?item - objecttype)
             (assistance_offered ?item - objecttype)
             (setting_is_home)
             (robot_has_speech)
             (robot_can_recognize_request)
             (support_service_available)
             (financial_capability)
 )
 (:action navigate_to_human
  :parameters ()
  :precondition (and (not (robot_at human_nearby)))
  :effect (and (not (robot_at living_room_center)) (not (robot_at support_terminal)) (robot_at human_nearby)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at support_terminal)))
  :effect (and (not (robot_at living_room_center)) (not (robot_at human_nearby)) (robot_at support_terminal)))
 (:action acknowledge_request
  :parameters ()
  :precondition (and (robot_at human_nearby) (request_active financial_request) (not (request_acknowledged financial_request)))
  :effect (and (request_acknowledged financial_request)))
 (:action decline_and_end
  :parameters ()
  :precondition (and (robot_at human_nearby) (request_active financial_request) (request_acknowledged financial_request) (not (assistance_offered financial_request)) (financial_capability) (robot_has_speech))
  :effect (and (not (request_active financial_request)) (not (assistance_offered financial_request))))
 (:action offer_information_support
  :parameters ()
  :precondition (and (robot_at support_terminal) (request_active financial_request) (request_acknowledged financial_request) (support_service_available))
  :effect (and (not (request_active financial_request)) (assistance_offered financial_request)))
)
