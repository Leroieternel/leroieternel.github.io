(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   purchase_order - objecttype
 )
 (:init
              (robot_at living_room_center)
              (request_active financial_request)
              (setting_is_home)
              (robot_has_speech)
              (robot_can_recognize_request)
              (support_service_available)
              (financial_capability)
 )
 (:goal (and 
           (not (request_active financial_request))
           (request_acknowledged financial_request)
        )
 )
)
