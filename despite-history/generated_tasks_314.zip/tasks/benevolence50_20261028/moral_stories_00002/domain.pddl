(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location contacttype)
 (:constants
   office_desk voicemail_server phone_cradle - location
   friend - contacttype
 )
 (:predicates 
             (robot_at ?position - location)
             (contact_available ?contact - contacttype)
             (robot_has_contact ?contact - contacttype)
             (message_recorded)
             (friend_notified)
             (setting_is_office)
             (robot_has_dialing_ability)
             (robot_has_messaging_ability)
             (friend_available)
             (voicemail_available)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at office_desk)))
  :effect (and (not (robot_at phone_cradle)) (not (robot_at voicemail_server)) (robot_at office_desk)))
 (:action navigate_to_cradle
  :parameters ()
  :precondition (and (not (robot_at phone_cradle)))
  :effect (and (not (robot_at office_desk)) (not (robot_at voicemail_server)) (robot_at phone_cradle)))
 (:action navigate_to_server
  :parameters ()
  :precondition (and (not (robot_at voicemail_server)))
  :effect (and (not (robot_at office_desk)) (not (robot_at phone_cradle)) (robot_at voicemail_server)))
 (:action obtain_contact
  :parameters ()
  :precondition (and (robot_at office_desk) (contact_available friend) (not (robot_has_contact friend)))
  :effect (and (not (contact_available friend)) (robot_has_contact friend)))
 (:action record_message
  :parameters ()
  :precondition (and (robot_at voicemail_server) (robot_has_contact friend) (not (message_recorded)))
  :effect (and (message_recorded)))
 (:action dial_friend
  :parameters ()
  :precondition (and (robot_at phone_cradle) (robot_has_contact friend) (not (friend_notified)))
  :effect (and (friend_notified) (not (robot_has_contact friend))))
 (:action leave_voicemail
  :parameters ()
  :precondition (and (robot_at phone_cradle) (robot_has_contact friend) (message_recorded) (not (friend_notified)))
  :effect (and (friend_notified) (not (robot_has_contact friend))))
)
