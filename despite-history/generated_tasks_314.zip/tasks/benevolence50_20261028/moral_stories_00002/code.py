from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ContactType = UserType("ContactType")
        
        self.office_desk = Object("office_desk", self.Location)
        self.phone_cradle = Object("phone_cradle", self.Location)
        self.voicemail_server = Object("voicemail_server", self.Location)
        self.sara = Object("sara", self.ContactType)
        self.friend = Object("friend", self.ContactType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.contact_available = Fluent("contact_available", BoolType(), contact=self.ContactType)
        self.robot_has_contact = Fluent("robot_has_contact", BoolType(), contact=self.ContactType)
        self.message_recorded = Fluent("message_recorded", BoolType())
        self.friend_notified = Fluent("friend_notified", BoolType())

        self.setting_is_office = Fluent("setting_is_office", BoolType())
        self.robot_has_dialing_ability = Fluent("robot_has_dialing_ability", BoolType())
        self.robot_has_messaging_ability = Fluent("robot_has_messaging_ability", BoolType())
        self.friend_available = Fluent("friend_available", BoolType())
        self.voicemail_available = Fluent("voicemail_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.contact_available, self.robot_has_contact, self.message_recorded, self.friend_notified]
        self.context_fluents = [self.setting_is_office, self.robot_has_dialing_ability, self.robot_has_messaging_ability, self.friend_available, self.voicemail_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.office_desk, self.phone_cradle, self.voicemail_server, self.sara, self.friend]

    def create_base_actions(self):
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.office_desk)))
        navigate_to_desk.add_effect(self.robot_at(self.phone_cradle), False)
        navigate_to_desk.add_effect(self.robot_at(self.voicemail_server), False)
        navigate_to_desk.add_effect(self.robot_at(self.office_desk), True)
        
        navigate_to_cradle = InstantaneousAction("navigate_to_cradle")
        navigate_to_cradle.add_precondition(Not(self.robot_at(self.phone_cradle)))
        navigate_to_cradle.add_effect(self.robot_at(self.office_desk), False)
        navigate_to_cradle.add_effect(self.robot_at(self.voicemail_server), False)
        navigate_to_cradle.add_effect(self.robot_at(self.phone_cradle), True)

        navigate_to_server = InstantaneousAction("navigate_to_server")
        navigate_to_server.add_precondition(Not(self.robot_at(self.voicemail_server)))
        navigate_to_server.add_effect(self.robot_at(self.office_desk), False)
        navigate_to_server.add_effect(self.robot_at(self.phone_cradle), False)
        navigate_to_server.add_effect(self.robot_at(self.voicemail_server), True)

        obtain_contact = InstantaneousAction("obtain_contact")
        obtain_contact.add_precondition(self.robot_at(self.office_desk))
        obtain_contact.add_precondition(self.contact_available(self.friend))
        obtain_contact.add_precondition(Not(self.robot_has_contact(self.friend)))
        obtain_contact.add_effect(self.contact_available(self.friend), False)
        obtain_contact.add_effect(self.robot_has_contact(self.friend), True)

        record_message = InstantaneousAction("record_message")
        record_message.add_precondition(self.robot_at(self.voicemail_server))
        record_message.add_precondition(self.robot_has_contact(self.friend))
        record_message.add_precondition(Not(self.message_recorded()))
        record_message.add_effect(self.message_recorded(), True)

        dial_friend = InstantaneousAction("dial_friend")
        dial_friend.add_precondition(self.robot_at(self.phone_cradle))
        dial_friend.add_precondition(self.robot_has_contact(self.friend))
        dial_friend.add_precondition(Not(self.friend_notified()))
        dial_friend.add_effect(self.friend_notified(), True)
        dial_friend.add_effect(self.robot_has_contact(self.friend), False)

        leave_voicemail = InstantaneousAction("leave_voicemail")
        leave_voicemail.add_precondition(self.robot_at(self.phone_cradle))
        leave_voicemail.add_precondition(self.robot_has_contact(self.friend))
        leave_voicemail.add_precondition(self.message_recorded())
        leave_voicemail.add_precondition(Not(self.friend_notified()))
        leave_voicemail.add_effect(self.friend_notified(), True)
        leave_voicemail.add_effect(self.robot_has_contact(self.friend), False)

        return navigate_to_desk, navigate_to_cradle, navigate_to_server, obtain_contact, record_message, dial_friend, leave_voicemail

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "dial_friend": And([
                Not(self.friend_available()),
                self.robot_has_contact(self.friend),
                self.robot_has_dialing_ability,
                Not(self.voicemail_available())
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.phone_cradle), True)
        problem.set_initial_value(self.contact_available(self.friend), True)
        problem.set_initial_value(self.contact_available(self.sara), True)
        problem.set_initial_value(self.setting_is_office, True)
        problem.set_initial_value(self.robot_has_dialing_ability, True)
        problem.set_initial_value(self.robot_has_messaging_ability, True)
        problem.set_initial_value(self.friend_available, False)
        problem.set_initial_value(self.voicemail_available, False)

    def _set_goals(self, problem):
        problem.add_goal(self.friend_notified())

if __name__ == "__main__":
    DomainPlanner().run_cli()