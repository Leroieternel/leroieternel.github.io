(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   sara - contacttype
 )
 (:init
              (robot_at phone_cradle)
              (contact_available friend)
              (contact_available sara)
              (setting_is_office)
              (robot_has_dialing_ability)
              (robot_has_messaging_ability)
 )
 (:goal (and 
           (friend_notified)
        )
 )
)
