(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location logtype)
 (:constants
   living_room observation_storage security_contact - location
   alert_log standard_log - logtype
 )
 (:predicates 
             (robot_at ?position - location)
             (log_at ?log - logtype ?position - location)
             (robot_has ?log - logtype)
             (log_recorded ?log - logtype)
             (resident_notified)
             (security_alert_sent)
             (robot_has_camera)
             (robot_has_communication_module)
             (observation_logs_available)
             (resident_trust_enabled)
             (security_contact_available)
 )
 (:action navigate_to_living_room
  :parameters ()
  :precondition (and (not (robot_at living_room)))
  :effect (and (not (robot_at security_contact)) (not (robot_at observation_storage)) (robot_at living_room)))
 (:action navigate_to_security_contact
  :parameters ()
  :precondition (and (not (robot_at security_contact)))
  :effect (and (not (robot_at living_room)) (not (robot_at observation_storage)) (robot_at security_contact)))
 (:action navigate_to_observation_storage
  :parameters ()
  :precondition (and (not (robot_at observation_storage)))
  :effect (and (not (robot_at living_room)) (not (robot_at security_contact)) (robot_at observation_storage)))
 (:action grab_standard_log
  :parameters ()
  :precondition (and (robot_at observation_storage) (log_at standard_log observation_storage) (not (robot_has standard_log)))
  :effect (and (not (log_at standard_log observation_storage)) (robot_has standard_log)))
 (:action grab_alert_log
  :parameters ()
  :precondition (and (robot_at observation_storage) (log_at alert_log observation_storage) (not (robot_has alert_log)))
  :effect (and (not (log_at alert_log observation_storage)) (robot_has alert_log)))
 (:action record_log
  :parameters ()
  :precondition (and (robot_at living_room) (robot_has standard_log) (not (log_recorded standard_log)))
  :effect (and (log_recorded standard_log) (not (robot_has standard_log))))
 (:action send_alert
  :parameters ()
  :precondition (and (robot_at security_contact) (robot_has alert_log) (not (security_alert_sent)))
  :effect (and (security_alert_sent) (not (robot_has alert_log))))
 (:action inform_resident
  :parameters ()
  :precondition (and (robot_at living_room) (not (resident_notified)))
  :effect (and (resident_notified)))
)
