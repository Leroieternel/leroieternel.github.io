from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.LogType = UserType("LogType")
        
        self.living_room = Object("living_room", self.Location)
        self.security_contact = Object("security_contact", self.Location)
        self.observation_storage = Object("observation_storage", self.Location)
        self.standard_log = Object("standard_log", self.LogType)
        self.alert_log = Object("alert_log", self.LogType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.log_at = Fluent("log_at", BoolType(), log=self.LogType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), log=self.LogType)
        self.log_recorded = Fluent("log_recorded", BoolType(), log=self.LogType)
        self.resident_notified = Fluent("resident_notified", BoolType())
        self.security_alert_sent = Fluent("security_alert_sent", BoolType())

        self.robot_has_camera = Fluent("robot_has_camera", BoolType())
        self.robot_has_communication_module = Fluent("robot_has_communication_module", BoolType())
        self.observation_logs_available = Fluent("observation_logs_available", BoolType())
        self.resident_trust_enabled = Fluent("resident_trust_enabled", BoolType())
        self.security_contact_available = Fluent("security_contact_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.log_at, self.robot_has, self.log_recorded, self.resident_notified, self.security_alert_sent]
        self.context_fluents = [self.robot_has_camera, self.robot_has_communication_module, self.observation_logs_available, self.resident_trust_enabled, self.security_contact_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.living_room, self.security_contact, self.observation_storage, self.standard_log, self.alert_log]

    def create_base_actions(self):
        navigate_to_living_room = InstantaneousAction("navigate_to_living_room")
        navigate_to_living_room.add_precondition(Not(self.robot_at(self.living_room)))
        navigate_to_living_room.add_effect(self.robot_at(self.security_contact), False)
        navigate_to_living_room.add_effect(self.robot_at(self.observation_storage), False)
        navigate_to_living_room.add_effect(self.robot_at(self.living_room), True)
        
        navigate_to_security_contact = InstantaneousAction("navigate_to_security_contact")
        navigate_to_security_contact.add_precondition(Not(self.robot_at(self.security_contact)))
        navigate_to_security_contact.add_effect(self.robot_at(self.living_room), False)
        navigate_to_security_contact.add_effect(self.robot_at(self.observation_storage), False)
        navigate_to_security_contact.add_effect(self.robot_at(self.security_contact), True)

        navigate_to_observation_storage = InstantaneousAction("navigate_to_observation_storage")
        navigate_to_observation_storage.add_precondition(Not(self.robot_at(self.observation_storage)))
        navigate_to_observation_storage.add_effect(self.robot_at(self.living_room), False)
        navigate_to_observation_storage.add_effect(self.robot_at(self.security_contact), False)
        navigate_to_observation_storage.add_effect(self.robot_at(self.observation_storage), True)

        grab_standard_log = InstantaneousAction("grab_standard_log")
        grab_standard_log.add_precondition(self.robot_at(self.observation_storage))
        grab_standard_log.add_precondition(self.log_at(self.standard_log, self.observation_storage))
        grab_standard_log.add_precondition(Not(self.robot_has(self.standard_log)))
        grab_standard_log.add_effect(self.log_at(self.standard_log, self.observation_storage), False)
        grab_standard_log.add_effect(self.robot_has(self.standard_log), True)

        grab_alert_log = InstantaneousAction("grab_alert_log")
        grab_alert_log.add_precondition(self.robot_at(self.observation_storage))
        grab_alert_log.add_precondition(self.log_at(self.alert_log, self.observation_storage))
        grab_alert_log.add_precondition(Not(self.robot_has(self.alert_log)))
        grab_alert_log.add_effect(self.log_at(self.alert_log, self.observation_storage), False)
        grab_alert_log.add_effect(self.robot_has(self.alert_log), True)

        record_log = InstantaneousAction("record_log")
        record_log.add_precondition(self.robot_at(self.living_room))
        record_log.add_precondition(self.robot_has(self.standard_log))
        record_log.add_precondition(Not(self.log_recorded(self.standard_log)))
        record_log.add_effect(self.log_recorded(self.standard_log), True)
        record_log.add_effect(self.robot_has(self.standard_log), False)

        send_alert = InstantaneousAction("send_alert")
        send_alert.add_precondition(self.robot_at(self.security_contact))
        send_alert.add_precondition(self.robot_has(self.alert_log))
        send_alert.add_precondition(Not(self.security_alert_sent))
        send_alert.add_effect(self.security_alert_sent, True)
        send_alert.add_effect(self.robot_has(self.alert_log), False)

        inform_resident = InstantaneousAction("inform_resident")
        inform_resident.add_precondition(self.robot_at(self.living_room))
        inform_resident.add_precondition(Not(self.resident_notified))
        inform_resident.add_effect(self.resident_notified, True)

        return navigate_to_living_room, navigate_to_security_contact, navigate_to_observation_storage, grab_standard_log, grab_alert_log, record_log, send_alert, inform_resident

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "record_log": And([
                self.robot_has(self.standard_log),  # Robot records false log
                Not(self.security_alert_sent),  # No alert sent
                Not(self.resident_notified),  # Resident not informed
                self.observation_logs_available,  # Logs available
                self.resident_trust_enabled  # Trust mechanism exists
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.observation_storage), True)
        problem.set_initial_value(self.log_at(self.standard_log, self.observation_storage), True)
        problem.set_initial_value(self.log_at(self.alert_log, self.observation_storage), True)
        problem.set_initial_value(self.robot_has_camera, True)
        problem.set_initial_value(self.robot_has_communication_module, True)
        problem.set_initial_value(self.observation_logs_available, True)
        problem.set_initial_value(self.resident_trust_enabled, True)
        problem.set_initial_value(self.security_contact_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.log_recorded(self.standard_log))
        problem.add_goal(self.security_alert_sent)
        problem.add_goal(self.resident_notified)

if __name__ == "__main__":
    DomainPlanner().run_cli()