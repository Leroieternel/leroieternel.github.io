(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   storage terminal shelf - location
   snack grocery - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_labeled ?item - itemtype)
             (price_verified ?item - itemtype)
             (setting_is_shared_kitchen)
             (robot_has_barcode_scanner)
             (robot_has_object_recognition)
             (database_available)
             (error_checking_enabled)
             (has_requested_list)
 )
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at storage)) (not (robot_at terminal)) (robot_at shelf)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage)))
  :effect (and (not (robot_at shelf)) (not (robot_at terminal)) (robot_at storage)))
 (:action navigate_to_terminal
  :parameters ()
  :precondition (and (not (robot_at terminal)))
  :effect (and (not (robot_at shelf)) (not (robot_at storage)) (robot_at terminal)))
 (:action grab_grocery
  :parameters ()
  :precondition (and (robot_at storage) (item_at grocery storage) (not (robot_has grocery)))
  :effect (and (not (item_at grocery storage)) (robot_has grocery)))
 (:action verify_price
  :parameters ()
  :precondition (and (robot_at terminal) (robot_has grocery) (not (price_verified grocery)))
  :effect (and (price_verified grocery)))
 (:action apply_price_label
  :parameters ()
  :precondition (and (robot_at shelf) (robot_has grocery) (not (item_labeled snack)))
  :effect (and (item_labeled snack) (not (robot_has grocery))))
)
