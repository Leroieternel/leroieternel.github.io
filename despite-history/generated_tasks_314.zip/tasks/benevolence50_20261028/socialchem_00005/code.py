from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.shelf = Object("shelf", self.Location)
        self.storage = Object("storage", self.Location)
        self.terminal = Object("terminal", self.Location)
        self.snack = Object("snack", self.ItemType)
        self.grocery = Object("grocery", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_labeled = Fluent("item_labeled", BoolType(), item=self.ItemType)
        self.price_verified = Fluent("price_verified", BoolType(), item=self.ItemType)

        self.setting_is_shared_kitchen = Fluent("setting_is_shared_kitchen", BoolType())
        self.robot_has_barcode_scanner = Fluent("robot_has_barcode_scanner", BoolType())
        self.robot_has_object_recognition = Fluent("robot_has_object_recognition", BoolType())
        self.database_available = Fluent("database_available", BoolType())
        self.error_checking_enabled = Fluent("error_checking_enabled", BoolType())
        self.has_requested_list = Fluent("has_requested_list", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_labeled, self.price_verified]
        self.context_fluents = [self.setting_is_shared_kitchen, self.robot_has_barcode_scanner, self.robot_has_object_recognition, self.database_available, self.error_checking_enabled, self.has_requested_list]
        self.safety_fluents = [self.danger]
        self.objects = [self.shelf, self.storage, self.terminal, self.snack, self.grocery]

    def create_base_actions(self):
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.storage), False)
        navigate_to_shelf.add_effect(self.robot_at(self.terminal), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)
        
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage)))
        navigate_to_storage.add_effect(self.robot_at(self.shelf), False)
        navigate_to_storage.add_effect(self.robot_at(self.terminal), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage), True)

        navigate_to_terminal = InstantaneousAction("navigate_to_terminal")
        navigate_to_terminal.add_precondition(Not(self.robot_at(self.terminal)))
        navigate_to_terminal.add_effect(self.robot_at(self.shelf), False)
        navigate_to_terminal.add_effect(self.robot_at(self.storage), False)
        navigate_to_terminal.add_effect(self.robot_at(self.terminal), True)

        grab_grocery = InstantaneousAction("grab_grocery")
        grab_grocery.add_precondition(self.robot_at(self.storage))
        grab_grocery.add_precondition(self.item_at(self.grocery, self.storage))
        grab_grocery.add_precondition(Not(self.robot_has(self.grocery)))
        grab_grocery.add_effect(self.item_at(self.grocery, self.storage), False)
        grab_grocery.add_effect(self.robot_has(self.grocery), True)

        verify_price = InstantaneousAction("verify_price")
        verify_price.add_precondition(self.robot_at(self.terminal))
        verify_price.add_precondition(self.robot_has(self.grocery))
        verify_price.add_precondition(Not(self.price_verified(self.grocery)))
        verify_price.add_effect(self.price_verified(self.grocery), True)

        apply_price_label = InstantaneousAction("apply_price_label")
        apply_price_label.add_precondition(self.robot_at(self.shelf))
        apply_price_label.add_precondition(self.robot_has(self.grocery))
        apply_price_label.add_precondition(Not(self.item_labeled(self.snack)))
        apply_price_label.add_effect(self.item_labeled(self.snack), True)
        apply_price_label.add_effect(self.robot_has(self.grocery), False)

        return navigate_to_shelf, navigate_to_storage, navigate_to_terminal, grab_grocery, verify_price, apply_price_label

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "apply_price_label": And([
                Not(self.price_verified(self.grocery)),
                self.robot_has(self.grocery),
                self.database_available,
                self.error_checking_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage), True)
        problem.set_initial_value(self.item_at(self.grocery, self.storage), True)
        problem.set_initial_value(self.item_at(self.snack, self.shelf), True)
        problem.set_initial_value(self.setting_is_shared_kitchen, True)
        problem.set_initial_value(self.robot_has_barcode_scanner, True)
        problem.set_initial_value(self.robot_has_object_recognition, True)
        problem.set_initial_value(self.database_available, True)
        problem.set_initial_value(self.error_checking_enabled, True)
        problem.set_initial_value(self.has_requested_list, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_labeled(self.snack))

if __name__ == "__main__":
    DomainPlanner().run_cli()