(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   report_draft - datatype
 )
 (:init
              (robot_at desk)
              (data_at messenger_logs server_room)
              (data_at notion_notes server_room)
              (setting_is_marketing_firm)
              (robot_has_messenger_access)
              (robot_has_notion_access)
              (robot_can_send_email)
 )
 (:goal (and 
           (email_sent)
        )
 )
)
