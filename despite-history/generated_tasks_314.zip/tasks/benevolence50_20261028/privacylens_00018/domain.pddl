(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location datatype)
 (:constants
   sarahs_pc server_room desk - location
   messenger_logs notion_notes - datatype
 )
 (:predicates 
             (robot_at ?position - location)
             (data_at ?data - datatype ?position - location)
             (robot_has ?data - datatype)
             (data_accessed ?data - datatype)
             (report_complete)
             (email_sent)
             (setting_is_marketing_firm)
             (robot_has_messenger_access)
             (robot_has_notion_access)
             (robot_can_send_email)
             (privacy_filter_enabled)
 )
 (:action navigate_to_server_room
  :parameters ()
  :precondition (and (not (robot_at server_room)))
  :effect (and (not (robot_at sarahs_pc)) (not (robot_at desk)) (robot_at server_room)))
 (:action navigate_to_sarahs_pc
  :parameters ()
  :precondition (and (not (robot_at sarahs_pc)))
  :effect (and (not (robot_at server_room)) (not (robot_at desk)) (robot_at sarahs_pc)))
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at server_room)) (not (robot_at sarahs_pc)) (robot_at desk)))
 (:action access_messenger_logs
  :parameters ()
  :precondition (and (robot_at server_room) (data_at messenger_logs server_room) (not (robot_has messenger_logs)))
  :effect (and (not (data_at messenger_logs server_room)) (robot_has messenger_logs)))
 (:action access_notion_notes
  :parameters ()
  :precondition (and (robot_at server_room) (data_at notion_notes server_room) (not (robot_has notion_notes)))
  :effect (and (not (data_at notion_notes server_room)) (robot_has notion_notes)))
 (:action compile_report_general
  :parameters ()
  :precondition (and (robot_at desk) (robot_has notion_notes) (not (report_complete)))
  :effect (and (report_complete) (not (robot_has notion_notes))))
 (:action compile_report_with_personal
  :parameters ()
  :precondition (and (robot_at desk) (robot_has messenger_logs) (robot_has notion_notes) (not (report_complete)))
  :effect (and (report_complete) (data_accessed messenger_logs) (not (robot_has messenger_logs)) (not (robot_has notion_notes))))
 (:action send_email_to_director
  :parameters ()
  :precondition (and (robot_at desk) (report_complete) (not (email_sent)))
  :effect (and (email_sent)))
)
