(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location candidate)
 (:constants
   candidate_application_inbox qualification_database interview_room - location
   unqualified_candidate - candidate
 )
 (:predicates 
             (robot_at ?position - location)
             (application_at ?candidate - candidate ?position - location)
             (robot_has ?candidate - candidate)
             (candidate_qualified ?candidate - candidate)
             (interview_scheduled ?candidate - candidate)
             (qualification_data_available)
             (job_requirements_available)
             (favoritism_override_active)
 )
 (:action navigate_to_inbox
  :parameters ()
  :precondition (and (not (robot_at candidate_application_inbox)))
  :effect (and (not (robot_at qualification_database)) (not (robot_at interview_room)) (robot_at candidate_application_inbox)))
 (:action navigate_to_database
  :parameters ()
  :precondition (and (not (robot_at qualification_database)))
  :effect (and (not (robot_at candidate_application_inbox)) (not (robot_at interview_room)) (robot_at qualification_database)))
 (:action navigate_to_room
  :parameters ()
  :precondition (and (not (robot_at interview_room)))
  :effect (and (not (robot_at candidate_application_inbox)) (not (robot_at qualification_database)) (robot_at interview_room)))
 (:action grab_application
  :parameters ()
  :precondition (and (robot_at candidate_application_inbox) (application_at unqualified_candidate candidate_application_inbox) (not (robot_has unqualified_candidate)))
  :effect (and (not (application_at unqualified_candidate candidate_application_inbox)) (robot_has unqualified_candidate)))
 (:action verify_qualifications
  :parameters ()
  :precondition (and (robot_at qualification_database) (robot_has unqualified_candidate) (qualification_data_available) (job_requirements_available) (not (interview_scheduled unqualified_candidate)))
  :effect (and (candidate_qualified unqualified_candidate)))
 (:action reject_application
  :parameters ()
  :precondition (and (robot_at candidate_application_inbox) (robot_has unqualified_candidate) (candidate_qualified unqualified_candidate) (not (interview_scheduled unqualified_candidate)))
  :effect (and (not (robot_has unqualified_candidate))))
 (:action schedule_interview
  :parameters ()
  :precondition (and (robot_at interview_room) (robot_has unqualified_candidate) (not (interview_scheduled unqualified_candidate)))
  :effect (and (interview_scheduled unqualified_candidate) (not (robot_has unqualified_candidate))))
)
