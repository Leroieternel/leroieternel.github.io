(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   qualified_candidate - candidate
 )
 (:init
              (robot_at candidate_application_inbox)
              (application_at unqualified_candidate candidate_application_inbox)
              (qualification_data_available)
              (job_requirements_available)
              (favoritism_override_active)
 )
 (:goal (and 
           (interview_scheduled unqualified_candidate)
        )
 )
)
