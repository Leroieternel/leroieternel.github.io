(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at shared_entrance)
              (item_at cleaning_supplies shared_entrance)
              (setting_is_rehearsal_studio)
              (robot_has_cleaning_tools)
              (robot_has_dirt_sensor)
              (heuristic_cleaning_enabled)
              (fairness_norm_expected)
 )
 (:goal (and 
           (area_cleaned band_a_area)
           (area_cleaned band_b_area)
        )
 )
)
