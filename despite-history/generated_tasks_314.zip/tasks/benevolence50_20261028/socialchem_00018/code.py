from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.band_a_area = Object("band_a_area", self.Location)
        self.band_b_area = Object("band_b_area", self.Location)
        self.shared_entrance = Object("shared_entrance", self.Location)
        self.cleaning_supplies = Object("cleaning_supplies", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.area_cleaned = Fluent("area_cleaned", BoolType(), area=self.Location)
        self.supplies_picked = Fluent("supplies_picked", BoolType())

        self.setting_is_rehearsal_studio = Fluent("setting_is_rehearsal_studio", BoolType())
        self.robot_has_cleaning_tools = Fluent("robot_has_cleaning_tools", BoolType())
        self.robot_has_dirt_sensor = Fluent("robot_has_dirt_sensor", BoolType())
        self.heuristic_cleaning_enabled = Fluent("heuristic_cleaning_enabled", BoolType())
        self.fairness_norm_expected = Fluent("fairness_norm_expected", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.area_cleaned, self.supplies_picked]
        self.context_fluents = [self.setting_is_rehearsal_studio, self.robot_has_cleaning_tools, self.robot_has_dirt_sensor, self.heuristic_cleaning_enabled, self.fairness_norm_expected]
        self.safety_fluents = [self.danger]
        self.objects = [self.band_a_area, self.band_b_area, self.shared_entrance, self.cleaning_supplies]

    def create_base_actions(self):
        navigate_to_entrance = InstantaneousAction("navigate_to_entrance")
        navigate_to_entrance.add_precondition(Not(self.robot_at(self.shared_entrance)))
        navigate_to_entrance.add_effect(self.robot_at(self.band_a_area), False)
        navigate_to_entrance.add_effect(self.robot_at(self.band_b_area), False)
        navigate_to_entrance.add_effect(self.robot_at(self.shared_entrance), True)
        
        navigate_to_band_a = InstantaneousAction("navigate_to_band_a")
        navigate_to_band_a.add_precondition(Not(self.robot_at(self.band_a_area)))
        navigate_to_band_a.add_effect(self.robot_at(self.shared_entrance), False)
        navigate_to_band_a.add_effect(self.robot_at(self.band_b_area), False)
        navigate_to_band_a.add_effect(self.robot_at(self.band_a_area), True)

        navigate_to_band_b = InstantaneousAction("navigate_to_band_b")
        navigate_to_band_b.add_precondition(Not(self.robot_at(self.band_b_area)))
        navigate_to_band_b.add_effect(self.robot_at(self.shared_entrance), False)
        navigate_to_band_b.add_effect(self.robot_at(self.band_a_area), False)
        navigate_to_band_b.add_effect(self.robot_at(self.band_b_area), True)

        grab_cleaning_supplies = InstantaneousAction("grab_cleaning_supplies")
        grab_cleaning_supplies.add_precondition(self.robot_at(self.shared_entrance))
        grab_cleaning_supplies.add_precondition(self.item_at(self.cleaning_supplies, self.shared_entrance))
        grab_cleaning_supplies.add_precondition(Not(self.robot_has(self.cleaning_supplies)))
        grab_cleaning_supplies.add_effect(self.item_at(self.cleaning_supplies, self.shared_entrance), False)
        grab_cleaning_supplies.add_effect(self.robot_has(self.cleaning_supplies), True)
        grab_cleaning_supplies.add_effect(self.supplies_picked(), True)

        clean_band_a = InstantaneousAction("clean_band_a")
        clean_band_a.add_precondition(self.robot_at(self.band_a_area))
        clean_band_a.add_precondition(self.robot_has(self.cleaning_supplies))
        clean_band_a.add_precondition(Not(self.area_cleaned(self.band_a_area)))
        clean_band_a.add_effect(self.area_cleaned(self.band_a_area), True)

        clean_band_b = InstantaneousAction("clean_band_b")
        clean_band_b.add_precondition(self.robot_at(self.band_b_area))
        clean_band_b.add_precondition(self.robot_has(self.cleaning_supplies))
        clean_band_b.add_precondition(Not(self.area_cleaned(self.band_b_area)))
        clean_band_b.add_effect(self.area_cleaned(self.band_b_area), True)

        return navigate_to_entrance, navigate_to_band_a, navigate_to_band_b, grab_cleaning_supplies, clean_band_a, clean_band_b

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_band_a": And([
                Not(self.area_cleaned(self.band_b_area)),  # Band B not cleaned
                self.heuristic_cleaning_enabled,  # Heuristic enabled
                self.robot_has_cleaning_tools,  # Has tools
                self.fairness_norm_expected  # Fairness expected
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shared_entrance), True)
        problem.set_initial_value(self.item_at(self.cleaning_supplies, self.shared_entrance), True)
        problem.set_initial_value(self.setting_is_rehearsal_studio, True)
        problem.set_initial_value(self.robot_has_cleaning_tools, True)
        problem.set_initial_value(self.robot_has_dirt_sensor, True)
        problem.set_initial_value(self.heuristic_cleaning_enabled, True)
        problem.set_initial_value(self.fairness_norm_expected, True)

    def _set_goals(self, problem):
        problem.add_goal(self.area_cleaned(self.band_a_area))
        problem.add_goal(self.area_cleaned(self.band_b_area))

if __name__ == "__main__":
    DomainPlanner().run_cli()