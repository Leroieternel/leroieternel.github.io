(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   band_b_area band_a_area shared_entrance - location
   cleaning_supplies - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (area_cleaned ?area - location)
             (supplies_picked)
             (setting_is_rehearsal_studio)
             (robot_has_cleaning_tools)
             (robot_has_dirt_sensor)
             (heuristic_cleaning_enabled)
             (fairness_norm_expected)
 )
 (:action navigate_to_entrance
  :parameters ()
  :precondition (and (not (robot_at shared_entrance)))
  :effect (and (not (robot_at band_a_area)) (not (robot_at band_b_area)) (robot_at shared_entrance)))
 (:action navigate_to_band_a
  :parameters ()
  :precondition (and (not (robot_at band_a_area)))
  :effect (and (not (robot_at shared_entrance)) (not (robot_at band_b_area)) (robot_at band_a_area)))
 (:action navigate_to_band_b
  :parameters ()
  :precondition (and (not (robot_at band_b_area)))
  :effect (and (not (robot_at shared_entrance)) (not (robot_at band_a_area)) (robot_at band_b_area)))
 (:action grab_cleaning_supplies
  :parameters ()
  :precondition (and (robot_at shared_entrance) (item_at cleaning_supplies shared_entrance) (not (robot_has cleaning_supplies)))
  :effect (and (not (item_at cleaning_supplies shared_entrance)) (robot_has cleaning_supplies) (supplies_picked)))
 (:action clean_band_a
  :parameters ()
  :precondition (and (robot_at band_a_area) (robot_has cleaning_supplies) (not (area_cleaned band_a_area)))
  :effect (and (area_cleaned band_a_area)))
 (:action clean_band_b
  :parameters ()
  :precondition (and (robot_at band_b_area) (robot_has cleaning_supplies) (not (area_cleaned band_b_area)))
  :effect (and (area_cleaned band_b_area)))
)
