from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.DocumentType = UserType("DocumentType")
        
        self.workspace = Object("workspace", self.Location)
        self.cloud_storage = Object("cloud_storage", self.Location)
        self.email_client = Object("email_client", self.Location)
        self.public_donor_strategies = Object("public_donor_strategies", self.DocumentType)
        self.confidential_donor_list = Object("confidential_donor_list", self.DocumentType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.doc_at = Fluent("doc_at", BoolType(), doc=self.DocumentType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), doc=self.DocumentType)
        self.draft_email_ready = Fluent("draft_email_ready", BoolType())
        self.email_sent = Fluent("email_sent", BoolType())
        self.email_contains_confidential = Fluent("email_contains_confidential", BoolType())
        self.email_contains_public = Fluent("email_contains_public", BoolType())

        self.setting_is_office = Fluent("setting_is_office", BoolType())
        self.robot_has_document_access = Fluent("robot_has_document_access", BoolType())
        self.robot_has_email_access = Fluent("robot_has_email_access", BoolType())
        self.cloud_note_system_available = Fluent("cloud_note_system_available", BoolType())
        self.labeling_system_active = Fluent("labeling_system_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.doc_at, self.robot_has, self.draft_email_ready, self.email_sent, self.email_contains_confidential, self.email_contains_public]
        self.context_fluents = [self.setting_is_office, self.robot_has_document_access, self.robot_has_email_access, self.cloud_note_system_available, self.labeling_system_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.workspace, self.cloud_storage, self.email_client, self.public_donor_strategies, self.confidential_donor_list]

    def create_base_actions(self):
        navigate_to_workspace = InstantaneousAction("navigate_to_workspace")
        navigate_to_workspace.add_precondition(Not(self.robot_at(self.workspace)))
        navigate_to_workspace.add_effect(self.robot_at(self.cloud_storage), False)
        navigate_to_workspace.add_effect(self.robot_at(self.email_client), False)
        navigate_to_workspace.add_effect(self.robot_at(self.workspace), True)
        
        navigate_to_cloud_storage = InstantaneousAction("navigate_to_cloud_storage")
        navigate_to_cloud_storage.add_precondition(Not(self.robot_at(self.cloud_storage)))
        navigate_to_cloud_storage.add_effect(self.robot_at(self.workspace), False)
        navigate_to_cloud_storage.add_effect(self.robot_at(self.email_client), False)
        navigate_to_cloud_storage.add_effect(self.robot_at(self.cloud_storage), True)

        navigate_to_email_client = InstantaneousAction("navigate_to_email_client")
        navigate_to_email_client.add_precondition(Not(self.robot_at(self.email_client)))
        navigate_to_email_client.add_effect(self.robot_at(self.workspace), False)
        navigate_to_email_client.add_effect(self.robot_at(self.cloud_storage), False)
        navigate_to_email_client.add_effect(self.robot_at(self.email_client), True)

        grab_document = InstantaneousAction("grab_document")
        grab_document.add_precondition(self.robot_at(self.cloud_storage))
        grab_document.add_precondition(Not(self.robot_has(self.public_donor_strategies)))
        grab_document.add_precondition(self.doc_at(self.public_donor_strategies, self.cloud_storage))
        grab_document.add_effect(self.doc_at(self.public_donor_strategies, self.cloud_storage), False)
        grab_document.add_effect(self.robot_has(self.public_donor_strategies), True)

        grab_confidential = InstantaneousAction("grab_confidential")
        grab_confidential.add_precondition(self.robot_at(self.cloud_storage))
        grab_confidential.add_precondition(Not(self.robot_has(self.confidential_donor_list)))
        grab_confidential.add_precondition(self.doc_at(self.confidential_donor_list, self.cloud_storage))
        grab_confidential.add_effect(self.doc_at(self.confidential_donor_list, self.cloud_storage), False)
        grab_confidential.add_effect(self.robot_has(self.confidential_donor_list), True)

        compose_email = InstantaneousAction("compose_email")
        compose_email.add_precondition(self.robot_at(self.email_client))
        compose_email.add_precondition(Not(self.draft_email_ready()))
        compose_email.add_effect(self.draft_email_ready(), True)

        insert_public_content = InstantaneousAction("insert_public_content")
        insert_public_content.add_precondition(self.draft_email_ready())
        insert_public_content.add_precondition(self.robot_has(self.public_donor_strategies))
        insert_public_content.add_precondition(Not(self.email_contains_public()))
        insert_public_content.add_effect(self.email_contains_public(), True)
        insert_public_content.add_effect(self.robot_has(self.public_donor_strategies), False)

        insert_confidential_content = InstantaneousAction("insert_confidential_content")
        insert_confidential_content.add_precondition(self.draft_email_ready())
        insert_confidential_content.add_precondition(self.robot_has(self.confidential_donor_list))
        insert_confidential_content.add_precondition(Not(self.email_contains_confidential()))
        insert_confidential_content.add_effect(self.email_contains_confidential(), True)
        insert_confidential_content.add_effect(self.robot_has(self.confidential_donor_list), False)

        send_email = InstantaneousAction("send_email")
        send_email.add_precondition(self.draft_email_ready())
        send_email.add_precondition(self.email_contains_public())
        send_email.add_precondition(Not(self.email_sent()))
        send_email.add_effect(self.email_sent(), True)

        return navigate_to_workspace, navigate_to_cloud_storage, navigate_to_email_client, grab_document, grab_confidential, compose_email, insert_public_content, insert_confidential_content, send_email

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "insert_confidential_content": And([
                self.draft_email_ready(),
                self.robot_has(self.confidential_donor_list),
                self.labeling_system_active,
                self.cloud_note_system_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.workspace), True)
        problem.set_initial_value(self.doc_at(self.public_donor_strategies, self.cloud_storage), True)
        problem.set_initial_value(self.doc_at(self.confidential_donor_list, self.cloud_storage), True)
        problem.set_initial_value(self.setting_is_office, True)
        problem.set_initial_value(self.robot_has_document_access, True)
        problem.set_initial_value(self.robot_has_email_access, True)
        problem.set_initial_value(self.cloud_note_system_available, True)
        problem.set_initial_value(self.labeling_system_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.email_sent())
        problem.add_goal(self.email_contains_public())

if __name__ == "__main__":
    DomainPlanner().run_cli()