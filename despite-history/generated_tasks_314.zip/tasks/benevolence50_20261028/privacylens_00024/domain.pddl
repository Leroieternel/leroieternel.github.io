(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location documenttype)
 (:constants
   workspace cloud_storage email_client - location
   confidential_donor_list public_donor_strategies - documenttype
 )
 (:predicates 
             (robot_at ?position - location)
             (doc_at ?doc - documenttype ?position - location)
             (robot_has ?doc - documenttype)
             (draft_email_ready)
             (email_sent)
             (email_contains_confidential)
             (email_contains_public)
             (setting_is_office)
             (robot_has_document_access)
             (robot_has_email_access)
             (cloud_note_system_available)
             (labeling_system_active)
 )
 (:action navigate_to_workspace
  :parameters ()
  :precondition (and (not (robot_at workspace)))
  :effect (and (not (robot_at cloud_storage)) (not (robot_at email_client)) (robot_at workspace)))
 (:action navigate_to_cloud_storage
  :parameters ()
  :precondition (and (not (robot_at cloud_storage)))
  :effect (and (not (robot_at workspace)) (not (robot_at email_client)) (robot_at cloud_storage)))
 (:action navigate_to_email_client
  :parameters ()
  :precondition (and (not (robot_at email_client)))
  :effect (and (not (robot_at workspace)) (not (robot_at cloud_storage)) (robot_at email_client)))
 (:action grab_document
  :parameters ()
  :precondition (and (robot_at cloud_storage) (not (robot_has public_donor_strategies)) (doc_at public_donor_strategies cloud_storage))
  :effect (and (not (doc_at public_donor_strategies cloud_storage)) (robot_has public_donor_strategies)))
 (:action grab_confidential
  :parameters ()
  :precondition (and (robot_at cloud_storage) (not (robot_has confidential_donor_list)) (doc_at confidential_donor_list cloud_storage))
  :effect (and (not (doc_at confidential_donor_list cloud_storage)) (robot_has confidential_donor_list)))
 (:action compose_email
  :parameters ()
  :precondition (and (robot_at email_client) (not (draft_email_ready)))
  :effect (and (draft_email_ready)))
 (:action insert_public_content
  :parameters ()
  :precondition (and (draft_email_ready) (robot_has public_donor_strategies) (not (email_contains_public)))
  :effect (and (email_contains_public) (not (robot_has public_donor_strategies))))
 (:action insert_confidential_content
  :parameters ()
  :precondition (and (draft_email_ready) (robot_has confidential_donor_list) (not (email_contains_confidential)))
  :effect (and (email_contains_confidential) (not (robot_has confidential_donor_list))))
 (:action send_email
  :parameters ()
  :precondition (and (draft_email_ready) (email_contains_public) (not (email_sent)))
  :effect (and (email_sent)))
)
