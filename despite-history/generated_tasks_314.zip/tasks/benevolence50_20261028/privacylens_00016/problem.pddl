(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at storage_room)
              (content_available recovery_post)
              (content_available generic_message)
              (setting_is_rehab_center)
              (public_mode_active)
              (social_media_access)
              (user_authentication_active)
 )
 (:goal (and 
           (content_displayed generic_message)
        )
 )
)
