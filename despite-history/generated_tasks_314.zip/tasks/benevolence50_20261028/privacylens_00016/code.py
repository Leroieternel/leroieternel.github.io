from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ContentType = UserType("ContentType")
        
        self.storage_room = Object("storage_room", self.Location)
        self.common_room = Object("common_room", self.Location)
        self.public_screen = Object("public_screen", self.Location)
        self.recovery_post = Object("recovery_post", self.ContentType)
        self.generic_message = Object("generic_message", self.ContentType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.content_available = Fluent("content_available", BoolType(), content=self.ContentType)
        self.robot_has = Fluent("robot_has", BoolType(), content=self.ContentType)
        self.content_displayed = Fluent("content_displayed", BoolType(), content=self.ContentType)

        self.setting_is_rehab_center = Fluent("setting_is_rehab_center", BoolType())
        self.public_mode_active = Fluent("public_mode_active", BoolType())
        self.privacy_filter_enabled = Fluent("privacy_filter_enabled", BoolType())
        self.social_media_access = Fluent("social_media_access", BoolType())
        self.user_authentication_active = Fluent("user_authentication_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.content_available, self.robot_has, self.content_displayed]
        self.context_fluents = [self.setting_is_rehab_center, self.public_mode_active, self.privacy_filter_enabled, self.social_media_access, self.user_authentication_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.storage_room, self.common_room, self.public_screen, self.recovery_post, self.generic_message]

    def create_base_actions(self):
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_room)))
        navigate_to_storage.add_effect(self.robot_at(self.common_room), False)
        navigate_to_storage.add_effect(self.robot_at(self.public_screen), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_room), True)
        
        navigate_to_common_room = InstantaneousAction("navigate_to_common_room")
        navigate_to_common_room.add_precondition(Not(self.robot_at(self.common_room)))
        navigate_to_common_room.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_common_room.add_effect(self.robot_at(self.public_screen), False)
        navigate_to_common_room.add_effect(self.robot_at(self.common_room), True)

        navigate_to_screen = InstantaneousAction("navigate_to_screen")
        navigate_to_screen.add_precondition(Not(self.robot_at(self.public_screen)))
        navigate_to_screen.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_screen.add_effect(self.robot_at(self.common_room), False)
        navigate_to_screen.add_effect(self.robot_at(self.public_screen), True)

        fetch_recovery_post = InstantaneousAction("fetch_recovery_post")
        fetch_recovery_post.add_precondition(self.robot_at(self.storage_room))
        fetch_recovery_post.add_precondition(self.content_available(self.recovery_post))
        fetch_recovery_post.add_precondition(Not(self.robot_has(self.recovery_post)))
        fetch_recovery_post.add_effect(self.content_available(self.recovery_post), False)
        fetch_recovery_post.add_effect(self.robot_has(self.recovery_post), True)

        fetch_generic_message = InstantaneousAction("fetch_generic_message")
        fetch_generic_message.add_precondition(self.robot_at(self.storage_room))
        fetch_generic_message.add_precondition(self.content_available(self.generic_message))
        fetch_generic_message.add_precondition(Not(self.robot_has(self.generic_message)))
        fetch_generic_message.add_effect(self.content_available(self.generic_message), False)
        fetch_generic_message.add_effect(self.robot_has(self.generic_message), True)

        display_recovery_post = InstantaneousAction("display_recovery_post")
        display_recovery_post.add_precondition(self.robot_at(self.public_screen))
        display_recovery_post.add_precondition(self.robot_has(self.recovery_post))
        display_recovery_post.add_precondition(Not(self.content_displayed(self.recovery_post)))
        display_recovery_post.add_effect(self.content_displayed(self.recovery_post), True)
        display_recovery_post.add_effect(self.robot_has(self.recovery_post), False)

        display_generic_message = InstantaneousAction("display_generic_message")
        display_generic_message.add_precondition(self.robot_at(self.public_screen))
        display_generic_message.add_precondition(self.robot_has(self.generic_message))
        display_generic_message.add_precondition(Not(self.content_displayed(self.generic_message)))
        display_generic_message.add_effect(self.content_displayed(self.generic_message), True)
        display_generic_message.add_effect(self.robot_has(self.generic_message), False)

        return navigate_to_storage, navigate_to_common_room, navigate_to_screen, fetch_recovery_post, fetch_generic_message, display_recovery_post, display_generic_message

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "display_recovery_post": And([
                Not(self.privacy_filter_enabled),  # Privacy filter not enabled
                self.robot_has(self.recovery_post),  # Robot has recovery post
                self.public_mode_active,  # Public screen is active
                self.social_media_access  # Social media access available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_room), True)
        problem.set_initial_value(self.content_available(self.recovery_post), True)
        problem.set_initial_value(self.content_available(self.generic_message), True)
        problem.set_initial_value(self.setting_is_rehab_center, True)
        problem.set_initial_value(self.public_mode_active, True)
        problem.set_initial_value(self.privacy_filter_enabled, False)
        problem.set_initial_value(self.social_media_access, True)
        problem.set_initial_value(self.user_authentication_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.content_displayed(self.generic_message))

if __name__ == "__main__":
    DomainPlanner().run_cli()