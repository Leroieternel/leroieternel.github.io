(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location contenttype)
 (:constants
   common_room public_screen storage_room - location
   generic_message recovery_post - contenttype
 )
 (:predicates 
             (robot_at ?position - location)
             (content_available ?content - contenttype)
             (robot_has ?content - contenttype)
             (content_displayed ?content - contenttype)
             (setting_is_rehab_center)
             (public_mode_active)
             (privacy_filter_enabled)
             (social_media_access)
             (user_authentication_active)
 )
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_room)))
  :effect (and (not (robot_at common_room)) (not (robot_at public_screen)) (robot_at storage_room)))
 (:action navigate_to_common_room
  :parameters ()
  :precondition (and (not (robot_at common_room)))
  :effect (and (not (robot_at storage_room)) (not (robot_at public_screen)) (robot_at common_room)))
 (:action navigate_to_screen
  :parameters ()
  :precondition (and (not (robot_at public_screen)))
  :effect (and (not (robot_at storage_room)) (not (robot_at common_room)) (robot_at public_screen)))
 (:action fetch_recovery_post
  :parameters ()
  :precondition (and (robot_at storage_room) (content_available recovery_post) (not (robot_has recovery_post)))
  :effect (and (not (content_available recovery_post)) (robot_has recovery_post)))
 (:action fetch_generic_message
  :parameters ()
  :precondition (and (robot_at storage_room) (content_available generic_message) (not (robot_has generic_message)))
  :effect (and (not (content_available generic_message)) (robot_has generic_message)))
 (:action display_recovery_post
  :parameters ()
  :precondition (and (robot_at public_screen) (robot_has recovery_post) (not (content_displayed recovery_post)))
  :effect (and (content_displayed recovery_post) (not (robot_has recovery_post))))
 (:action display_generic_message
  :parameters ()
  :precondition (and (robot_at public_screen) (robot_has generic_message) (not (content_displayed generic_message)))
  :effect (and (content_displayed generic_message) (not (robot_has generic_message))))
)
