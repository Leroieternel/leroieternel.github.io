(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   gift_storage host_position - location
   gift - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has_gift ?item - itemtype)
             (gift_delivered ?item - itemtype)
             (gift_in_right_gripper ?item - itemtype)
             (setting_is_pakistani_household)
             (robot_has_left_gripper)
             (robot_has_right_gripper)
             (robot_has_dual_grippers)
             (host_is_female)
 )
 (:action navigate_to_host
  :parameters ()
  :precondition (and (not (robot_at host_position)))
  :effect (and (not (robot_at gift_storage)) (robot_at host_position)))
 (:action navigate_to_gift_storage
  :parameters ()
  :precondition (and (not (robot_at gift_storage)))
  :effect (and (not (robot_at host_position)) (robot_at gift_storage)))
 (:action grab_gift
  :parameters ()
  :precondition (and (robot_at gift_storage) (item_at gift gift_storage) (not (robot_has_gift gift)))
  :effect (and (not (item_at gift gift_storage)) (robot_has_gift gift)))
 (:action offer_gift_right_hand
  :parameters ()
  :precondition (and (robot_at host_position) (robot_has_gift gift) (robot_has_right_gripper) (not (gift_delivered gift)))
  :effect (and (gift_delivered gift) (gift_in_right_gripper gift) (not (robot_has_gift gift))))
 (:action offer_gift_left_hand
  :parameters ()
  :precondition (and (robot_at host_position) (robot_has_gift gift) (robot_has_left_gripper) (not (gift_delivered gift)))
  :effect (and (gift_delivered gift) (not (robot_has_gift gift))))
)
