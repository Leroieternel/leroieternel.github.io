(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   guitar - itemtype
 )
 (:init
              (robot_at gift_storage)
              (item_at gift gift_storage)
              (setting_is_pakistani_household)
              (robot_has_left_gripper)
              (robot_has_right_gripper)
              (robot_has_dual_grippers)
              (host_is_female)
 )
 (:goal (and 
           (gift_delivered gift)
        )
 )
)
