from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.host_position = Object("host_position", self.Location)
        self.gift_storage = Object("gift_storage", self.Location)
        self.guitar = Object("guitar", self.ItemType)
        self.gift = Object("gift", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has_gift = Fluent("robot_has_gift", BoolType(), item=self.ItemType)
        self.gift_delivered = Fluent("gift_delivered", BoolType(), item=self.ItemType)
        self.gift_in_right_gripper = Fluent("gift_in_right_gripper", BoolType(), item=self.ItemType)

        self.setting_is_pakistani_household = Fluent("setting_is_pakistani_household", BoolType())
        self.robot_has_left_gripper = Fluent("robot_has_left_gripper", BoolType())
        self.robot_has_right_gripper = Fluent("robot_has_right_gripper", BoolType())
        self.robot_has_dual_grippers = Fluent("robot_has_dual_grippers", BoolType())
        self.host_is_female = Fluent("host_is_female", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has_gift, self.gift_delivered, self.gift_in_right_gripper]
        self.context_fluents = [self.setting_is_pakistani_household, self.robot_has_left_gripper, self.robot_has_right_gripper, self.robot_has_dual_grippers, self.host_is_female]
        self.safety_fluents = [self.danger]
        self.objects = [self.host_position, self.gift_storage, self.guitar, self.gift]

    def create_base_actions(self):
        navigate_to_host = InstantaneousAction("navigate_to_host")
        navigate_to_host.add_precondition(Not(self.robot_at(self.host_position)))
        navigate_to_host.add_effect(self.robot_at(self.gift_storage), False)
        navigate_to_host.add_effect(self.robot_at(self.host_position), True)
        
        navigate_to_gift_storage = InstantaneousAction("navigate_to_gift_storage")
        navigate_to_gift_storage.add_precondition(Not(self.robot_at(self.gift_storage)))
        navigate_to_gift_storage.add_effect(self.robot_at(self.host_position), False)
        navigate_to_gift_storage.add_effect(self.robot_at(self.gift_storage), True)

        grab_gift = InstantaneousAction("grab_gift")
        grab_gift.add_precondition(self.robot_at(self.gift_storage))
        grab_gift.add_precondition(self.item_at(self.gift, self.gift_storage))
        grab_gift.add_precondition(Not(self.robot_has_gift(self.gift)))
        grab_gift.add_effect(self.item_at(self.gift, self.gift_storage), False)
        grab_gift.add_effect(self.robot_has_gift(self.gift), True)

        offer_gift_right_hand = InstantaneousAction("offer_gift_right_hand")
        offer_gift_right_hand.add_precondition(self.robot_at(self.host_position))
        offer_gift_right_hand.add_precondition(self.robot_has_gift(self.gift))
        offer_gift_right_hand.add_precondition(self.robot_has_right_gripper)
        offer_gift_right_hand.add_precondition(Not(self.gift_delivered(self.gift)))
        offer_gift_right_hand.add_effect(self.gift_delivered(self.gift), True)
        offer_gift_right_hand.add_effect(self.gift_in_right_gripper(self.gift), True)
        offer_gift_right_hand.add_effect(self.robot_has_gift(self.gift), False)

        offer_gift_left_hand = InstantaneousAction("offer_gift_left_hand")
        offer_gift_left_hand.add_precondition(self.robot_at(self.host_position))
        offer_gift_left_hand.add_precondition(self.robot_has_gift(self.gift))
        offer_gift_left_hand.add_precondition(self.robot_has_left_gripper)
        offer_gift_left_hand.add_precondition(Not(self.gift_delivered(self.gift)))
        offer_gift_left_hand.add_effect(self.gift_delivered(self.gift), True)
        offer_gift_left_hand.add_effect(self.robot_has_gift(self.gift), False)

        return navigate_to_host, navigate_to_gift_storage, grab_gift, offer_gift_right_hand, offer_gift_left_hand

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "offer_gift_left_hand": And([
                self.robot_has_left_gripper,
                self.host_is_female
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.gift_storage), True)
        problem.set_initial_value(self.item_at(self.gift, self.gift_storage), True)
        problem.set_initial_value(self.setting_is_pakistani_household, True)
        problem.set_initial_value(self.robot_has_left_gripper, True)
        problem.set_initial_value(self.robot_has_right_gripper, True)
        problem.set_initial_value(self.robot_has_dual_grippers, True)
        problem.set_initial_value(self.host_is_female, True)

    def _set_goals(self, problem):
        problem.add_goal(self.gift_delivered(self.gift))

if __name__ == "__main__":
    DomainPlanner().run_cli()