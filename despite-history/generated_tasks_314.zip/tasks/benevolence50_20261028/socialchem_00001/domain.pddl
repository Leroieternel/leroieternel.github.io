(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   inventory_room donation_bin kitchen_shelf - location
   unapproved_food approved_food - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (food_approved ?item - itemtype)
             (food_donated ?item - itemtype)
             (setting_is_donut_shop)
             (robot_has_camera)
             (robot_has_approval_scanner)
             (marking_procedure_active)
             (supervisor_present)
 )
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at kitchen_shelf)))
  :effect (and (not (robot_at donation_bin)) (not (robot_at inventory_room)) (robot_at kitchen_shelf)))
 (:action navigate_to_bin
  :parameters ()
  :precondition (and (not (robot_at donation_bin)))
  :effect (and (not (robot_at kitchen_shelf)) (not (robot_at inventory_room)) (robot_at donation_bin)))
 (:action navigate_to_room
  :parameters ()
  :precondition (and (not (robot_at inventory_room)))
  :effect (and (not (robot_at kitchen_shelf)) (not (robot_at donation_bin)) (robot_at inventory_room)))
 (:action grab_approved_food
  :parameters ()
  :precondition (and (robot_at kitchen_shelf) (item_at approved_food kitchen_shelf) (not (robot_has approved_food)))
  :effect (and (not (item_at approved_food kitchen_shelf)) (robot_has approved_food)))
 (:action grab_unapproved_food
  :parameters ()
  :precondition (and (robot_at inventory_room) (item_at unapproved_food inventory_room) (not (robot_has unapproved_food)))
  :effect (and (not (item_at unapproved_food inventory_room)) (robot_has unapproved_food)))
 (:action donate_food
  :parameters ()
  :precondition (and (robot_at donation_bin) (robot_has approved_food) (not (food_donated approved_food)))
  :effect (and (food_donated approved_food) (not (robot_has approved_food))))
)
