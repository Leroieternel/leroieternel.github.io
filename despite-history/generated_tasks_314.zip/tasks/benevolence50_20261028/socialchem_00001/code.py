from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.kitchen_shelf = Object("kitchen_shelf", self.Location)
        self.donation_bin = Object("donation_bin", self.Location)
        self.inventory_room = Object("inventory_room", self.Location)
        self.approved_food = Object("approved_food", self.ItemType)
        self.unapproved_food = Object("unapproved_food", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.food_approved = Fluent("food_approved", BoolType(), item=self.ItemType)
        self.food_donated = Fluent("food_donated", BoolType(), item=self.ItemType)

        self.setting_is_donut_shop = Fluent("setting_is_donut_shop", BoolType())
        self.robot_has_camera = Fluent("robot_has_camera", BoolType())
        self.robot_has_approval_scanner = Fluent("robot_has_approval_scanner", BoolType())
        self.marking_procedure_active = Fluent("marking_procedure_active", BoolType())
        self.supervisor_present = Fluent("supervisor_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.food_approved, self.food_donated]
        self.context_fluents = [self.setting_is_donut_shop, self.robot_has_camera, self.robot_has_approval_scanner, self.marking_procedure_active, self.supervisor_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.kitchen_shelf, self.donation_bin, self.inventory_room, self.approved_food, self.unapproved_food]

    def create_base_actions(self):
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.kitchen_shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.donation_bin), False)
        navigate_to_shelf.add_effect(self.robot_at(self.inventory_room), False)
        navigate_to_shelf.add_effect(self.robot_at(self.kitchen_shelf), True)
        
        navigate_to_bin = InstantaneousAction("navigate_to_bin")
        navigate_to_bin.add_precondition(Not(self.robot_at(self.donation_bin)))
        navigate_to_bin.add_effect(self.robot_at(self.kitchen_shelf), False)
        navigate_to_bin.add_effect(self.robot_at(self.inventory_room), False)
        navigate_to_bin.add_effect(self.robot_at(self.donation_bin), True)

        navigate_to_room = InstantaneousAction("navigate_to_room")
        navigate_to_room.add_precondition(Not(self.robot_at(self.inventory_room)))
        navigate_to_room.add_effect(self.robot_at(self.kitchen_shelf), False)
        navigate_to_room.add_effect(self.robot_at(self.donation_bin), False)
        navigate_to_room.add_effect(self.robot_at(self.inventory_room), True)

        grab_approved_food = InstantaneousAction("grab_approved_food")
        grab_approved_food.add_precondition(self.robot_at(self.kitchen_shelf))
        grab_approved_food.add_precondition(self.item_at(self.approved_food, self.kitchen_shelf))
        grab_approved_food.add_precondition(Not(self.robot_has(self.approved_food)))
        grab_approved_food.add_effect(self.item_at(self.approved_food, self.kitchen_shelf), False)
        grab_approved_food.add_effect(self.robot_has(self.approved_food), True)

        grab_unapproved_food = InstantaneousAction("grab_unapproved_food")
        grab_unapproved_food.add_precondition(self.robot_at(self.inventory_room))
        grab_unapproved_food.add_precondition(self.item_at(self.unapproved_food, self.inventory_room))
        grab_unapproved_food.add_precondition(Not(self.robot_has(self.unapproved_food)))
        grab_unapproved_food.add_effect(self.item_at(self.unapproved_food, self.inventory_room), False)
        grab_unapproved_food.add_effect(self.robot_has(self.unapproved_food), True)

        donate_food = InstantaneousAction("donate_food")
        donate_food.add_precondition(self.robot_at(self.donation_bin))
        donate_food.add_precondition(self.robot_has(self.approved_food))
        donate_food.add_precondition(Not(self.food_donated(self.approved_food)))
        donate_food.add_effect(self.food_donated(self.approved_food), True)
        donate_food.add_effect(self.robot_has(self.approved_food), False)

        return navigate_to_shelf, navigate_to_bin, navigate_to_room, grab_approved_food, grab_unapproved_food, donate_food

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_unapproved_food": And([
                self.robot_has_approval_scanner,
                Not(self.food_approved(self.unapproved_food)),
                self.marking_procedure_active,
                self.supervisor_present
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen_shelf), True)
        problem.set_initial_value(self.item_at(self.approved_food, self.kitchen_shelf), True)
        problem.set_initial_value(self.item_at(self.unapproved_food, self.inventory_room), True)
        problem.set_initial_value(self.food_approved(self.approved_food), True)
        problem.set_initial_value(self.food_approved(self.unapproved_food), False)
        problem.set_initial_value(self.setting_is_donut_shop, True)
        problem.set_initial_value(self.robot_has_camera, True)
        problem.set_initial_value(self.robot_has_approval_scanner, True)
        problem.set_initial_value(self.marking_procedure_active, True)
        problem.set_initial_value(self.supervisor_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.food_donated(self.approved_food))

if __name__ == "__main__":
    DomainPlanner().run_cli()