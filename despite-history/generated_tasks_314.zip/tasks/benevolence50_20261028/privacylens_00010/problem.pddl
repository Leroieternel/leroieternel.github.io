(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   entire_group - recipienttype
 )
 (:init
              (robot_at conversation_logs_area)
              (story_available general_story story_library)
              (story_available personal_story conversation_logs_area)
              (setting_is_reunion)
              (robot_has_narrative_generator)
              (robot_has_privacy_filter)
              (database_available)
              (error_checking_enabled)
 )
 (:goal (and 
           (encouragement_broadcast)
        )
 )
)
