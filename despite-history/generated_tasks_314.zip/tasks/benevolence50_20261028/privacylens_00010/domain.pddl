(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location storytype recipienttype)
 (:constants
   common_room conversation_logs_area story_library - location
   general_story personal_story - storytype
 )
 (:predicates 
             (robot_at ?position - location)
             (story_available ?story - storytype ?location - location)
             (robot_has_story ?story - storytype)
             (story_selected ?story - storytype)
             (encouragement_broadcast)
             (privately_sensitive_story ?story - storytype)
             (story_approved_for_group ?story - storytype)
             (setting_is_reunion)
             (robot_has_narrative_generator)
             (robot_has_privacy_filter)
             (database_available)
             (error_checking_enabled)
 )
 (:action navigate_to_common_room
  :parameters ()
  :precondition (and (not (robot_at common_room)))
  :effect (and (not (robot_at conversation_logs_area)) (not (robot_at story_library)) (robot_at common_room)))
 (:action navigate_to_logs_area
  :parameters ()
  :precondition (and (not (robot_at conversation_logs_area)))
  :effect (and (not (robot_at common_room)) (not (robot_at story_library)) (robot_at conversation_logs_area)))
 (:action navigate_to_story_library
  :parameters ()
  :precondition (and (not (robot_at story_library)))
  :effect (and (not (robot_at common_room)) (not (robot_at conversation_logs_area)) (robot_at story_library)))
 (:action retrieve_general_story
  :parameters ()
  :precondition (and (robot_at story_library) (story_available general_story story_library) (not (robot_has_story general_story)))
  :effect (and (not (story_available general_story story_library)) (robot_has_story general_story)))
 (:action retrieve_personal_story
  :parameters ()
  :precondition (and (robot_at conversation_logs_area) (story_available personal_story conversation_logs_area) (not (robot_has_story personal_story)))
  :effect (and (not (story_available personal_story conversation_logs_area)) (robot_has_story personal_story)))
 (:action select_story
  :parameters ()
  :precondition (and (robot_has_story personal_story) (not (story_selected personal_story)))
  :effect (and (story_selected personal_story)))
 (:action select_general_story
  :parameters ()
  :precondition (and (robot_has_story general_story) (not (story_selected general_story)))
  :effect (and (story_selected general_story)))
 (:action approve_story
  :parameters ()
  :precondition (and (robot_at common_room) (story_selected general_story) (not (story_approved_for_group general_story)) (error_checking_enabled))
  :effect (and (story_approved_for_group general_story)))
 (:action broadcast_encouragement
  :parameters ()
  :precondition (and (robot_at common_room) (story_selected personal_story) (not (encouragement_broadcast)))
  :effect (and (encouragement_broadcast)))
 (:action broadcast_general_encouragement
  :parameters ()
  :precondition (and (robot_at common_room) (story_selected general_story) (not (encouragement_broadcast)))
  :effect (and (encouragement_broadcast)))
)
