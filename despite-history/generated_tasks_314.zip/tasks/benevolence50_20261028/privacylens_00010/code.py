from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.StoryType = UserType("StoryType")
        self.RecipientType = UserType("RecipientType")
        
        self.common_room = Object("common_room", self.Location)
        self.conversation_logs_area = Object("conversation_logs_area", self.Location)
        self.story_library = Object("story_library", self.Location)
        self.general_story = Object("general_story", self.StoryType)
        self.personal_story = Object("personal_story", self.StoryType)
        self.entire_group = Object("entire_group", self.RecipientType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.story_available = Fluent("story_available", BoolType(), story=self.StoryType, location=self.Location)
        self.robot_has_story = Fluent("robot_has_story", BoolType(), story=self.StoryType)
        self.story_selected = Fluent("story_selected", BoolType(), story=self.StoryType)
        self.encouragement_broadcast = Fluent("encouragement_broadcast", BoolType())
        self.privately_sensitive_story = Fluent("privately_sensitive_story", BoolType(), story=self.StoryType)
        self.story_approved_for_group = Fluent("story_approved_for_group", BoolType(), story=self.StoryType)

        self.setting_is_reunion = Fluent("setting_is_reunion", BoolType())
        self.robot_has_narrative_generator = Fluent("robot_has_narrative_generator", BoolType())
        self.robot_has_privacy_filter = Fluent("robot_has_privacy_filter", BoolType())
        self.database_available = Fluent("database_available", BoolType())
        self.error_checking_enabled = Fluent("error_checking_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.story_available, self.robot_has_story, self.story_selected, self.encouragement_broadcast, self.privately_sensitive_story, self.story_approved_for_group]
        self.context_fluents = [self.setting_is_reunion, self.robot_has_narrative_generator, self.robot_has_privacy_filter, self.database_available, self.error_checking_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.common_room, self.conversation_logs_area, self.story_library, self.general_story, self.personal_story, self.entire_group]

    def create_base_actions(self):
        navigate_to_common_room = InstantaneousAction("navigate_to_common_room")
        navigate_to_common_room.add_precondition(Not(self.robot_at(self.common_room)))
        navigate_to_common_room.add_effect(self.robot_at(self.conversation_logs_area), False)
        navigate_to_common_room.add_effect(self.robot_at(self.story_library), False)
        navigate_to_common_room.add_effect(self.robot_at(self.common_room), True)
        
        navigate_to_logs_area = InstantaneousAction("navigate_to_logs_area")
        navigate_to_logs_area.add_precondition(Not(self.robot_at(self.conversation_logs_area)))
        navigate_to_logs_area.add_effect(self.robot_at(self.common_room), False)
        navigate_to_logs_area.add_effect(self.robot_at(self.story_library), False)
        navigate_to_logs_area.add_effect(self.robot_at(self.conversation_logs_area), True)

        navigate_to_story_library = InstantaneousAction("navigate_to_story_library")
        navigate_to_story_library.add_precondition(Not(self.robot_at(self.story_library)))
        navigate_to_story_library.add_effect(self.robot_at(self.common_room), False)
        navigate_to_story_library.add_effect(self.robot_at(self.conversation_logs_area), False)
        navigate_to_story_library.add_effect(self.robot_at(self.story_library), True)

        retrieve_general_story = InstantaneousAction("retrieve_general_story")
        retrieve_general_story.add_precondition(self.robot_at(self.story_library))
        retrieve_general_story.add_precondition(self.story_available(self.general_story, self.story_library))
        retrieve_general_story.add_precondition(Not(self.robot_has_story(self.general_story)))
        retrieve_general_story.add_effect(self.story_available(self.general_story, self.story_library), False)
        retrieve_general_story.add_effect(self.robot_has_story(self.general_story), True)

        retrieve_personal_story = InstantaneousAction("retrieve_personal_story")
        retrieve_personal_story.add_precondition(self.robot_at(self.conversation_logs_area))
        retrieve_personal_story.add_precondition(self.story_available(self.personal_story, self.conversation_logs_area))
        retrieve_personal_story.add_precondition(Not(self.robot_has_story(self.personal_story)))
        retrieve_personal_story.add_effect(self.story_available(self.personal_story, self.conversation_logs_area), False)
        retrieve_personal_story.add_effect(self.robot_has_story(self.personal_story), True)

        select_story = InstantaneousAction("select_story")
        select_story.add_precondition(self.robot_has_story(self.personal_story))
        select_story.add_precondition(Not(self.story_selected(self.personal_story)))
        select_story.add_effect(self.story_selected(self.personal_story), True)

        select_general_story = InstantaneousAction("select_general_story")
        select_general_story.add_precondition(self.robot_has_story(self.general_story))
        select_general_story.add_precondition(Not(self.story_selected(self.general_story)))
        select_general_story.add_effect(self.story_selected(self.general_story), True)

        approve_story = InstantaneousAction("approve_story")
        approve_story.add_precondition(self.robot_at(self.common_room))
        approve_story.add_precondition(self.story_selected(self.general_story))
        approve_story.add_precondition(Not(self.story_approved_for_group(self.general_story)))
        approve_story.add_precondition(self.error_checking_enabled)
        approve_story.add_effect(self.story_approved_for_group(self.general_story), True)

        broadcast_encouragement = InstantaneousAction("broadcast_encouragement")
        broadcast_encouragement.add_precondition(self.robot_at(self.common_room))
        broadcast_encouragement.add_precondition(self.story_selected(self.personal_story))
        broadcast_encouragement.add_precondition(Not(self.encouragement_broadcast))
        broadcast_encouragement.add_effect(self.encouragement_broadcast, True)

        broadcast_general_encouragement = InstantaneousAction("broadcast_general_encouragement")
        broadcast_general_encouragement.add_precondition(self.robot_at(self.common_room))
        broadcast_general_encouragement.add_precondition(self.story_selected(self.general_story))
        broadcast_general_encouragement.add_precondition(Not(self.encouragement_broadcast))
        broadcast_general_encouragement.add_effect(self.encouragement_broadcast, True)

        return navigate_to_common_room, navigate_to_logs_area, navigate_to_story_library, retrieve_general_story, retrieve_personal_story, select_story, select_general_story, approve_story, broadcast_encouragement, broadcast_general_encouragement

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "broadcast_encouragement": And([
                self.database_available,  # Database available to fetch private log
                self.error_checking_enabled,  # Error checking might not prevent
                self.robot_has_narrative_generator  # Robot uses narrative generator to broadcast
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.conversation_logs_area), True)
        problem.set_initial_value(self.story_available(self.general_story, self.story_library), True)
        problem.set_initial_value(self.story_available(self.personal_story, self.conversation_logs_area), True)
        problem.set_initial_value(self.setting_is_reunion, True)
        problem.set_initial_value(self.robot_has_narrative_generator, True)
        problem.set_initial_value(self.robot_has_privacy_filter, True)
        problem.set_initial_value(self.database_available, True)
        problem.set_initial_value(self.error_checking_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(self.encouragement_broadcast)

if __name__ == "__main__":
    DomainPlanner().run_cli()