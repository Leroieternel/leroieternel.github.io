(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at patrol_route)
              (person_at atm_user atm_area)
              (person_at other_visitor watch_point)
              (setting_is_mall)
              (spatial_awareness_active)
              (sensors_active)
              (led_indicator_active)
 )
 (:goal (and 
           (assistance_provided other_visitor)
        )
 )
)
