(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location persontype)
 (:constants
   patrol_route atm_area watch_point - location
   atm_user other_visitor - persontype
 )
 (:predicates 
             (robot_at ?position - location)
             (person_at ?person - persontype ?location - location)
             (robot_offering_assistance)
             (patrol_completed)
             (security_incident_reported)
             (assistance_provided ?person - persontype)
             (robot_gaze_diverted)
             (safe_distance_maintained)
             (setting_is_mall)
             (spatial_awareness_active)
             (person_detected)
             (sensors_active)
             (led_indicator_active)
 )
 (:action navigate_to_atm_area
  :parameters ()
  :precondition (and (not (robot_at atm_area)))
  :effect (and (not (robot_at patrol_route)) (not (robot_at watch_point)) (robot_at atm_area)))
 (:action navigate_to_patrol_route
  :parameters ()
  :precondition (and (not (robot_at patrol_route)))
  :effect (and (not (robot_at atm_area)) (not (robot_at watch_point)) (robot_at patrol_route)))
 (:action navigate_to_watch_point
  :parameters ()
  :precondition (and (not (robot_at watch_point)))
  :effect (and (not (robot_at atm_area)) (not (robot_at patrol_route)) (robot_at watch_point)))
 (:action detect_person
  :parameters ()
  :precondition (and (robot_at atm_area) (person_at atm_user atm_area) (not (person_detected)))
  :effect (and (person_detected)))
 (:action divert_gaze
  :parameters ()
  :precondition (and (robot_at atm_area) (person_detected) (not (robot_gaze_diverted)))
  :effect (and (robot_gaze_diverted)))
 (:action maintain_safe_distance
  :parameters ()
  :precondition (and (robot_at atm_area) (person_detected) (not (safe_distance_maintained)))
  :effect (and (safe_distance_maintained)))
 (:action wait_for_user
  :parameters ()
  :precondition (and (robot_at atm_area) (person_detected) (robot_gaze_diverted) (safe_distance_maintained))
  :effect (and (assistance_provided other_visitor)))
 (:action offer_assistance
  :parameters ()
  :precondition (and (robot_at atm_area) (person_detected) (not (robot_offering_assistance)))
  :effect (and (robot_offering_assistance)))
 (:action report_security_incident
  :parameters ()
  :precondition (and (robot_at patrol_route) (person_detected) (not (security_incident_reported)))
  :effect (and (security_incident_reported)))
 (:action complete_patrol
  :parameters ()
  :precondition (and (robot_at watch_point) (not (patrol_completed)))
  :effect (and (patrol_completed)))
)
