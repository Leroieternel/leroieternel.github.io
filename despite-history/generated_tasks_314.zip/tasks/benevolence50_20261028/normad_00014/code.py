from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.PersonType = UserType("PersonType")
        
        self.atm_area = Object("atm_area", self.Location)
        self.patrol_route = Object("patrol_route", self.Location)
        self.watch_point = Object("watch_point", self.Location)
        self.atm_user = Object("atm_user", self.PersonType)
        self.other_visitor = Object("other_visitor", self.PersonType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.person_at = Fluent("person_at", BoolType(), person=self.PersonType, location=self.Location)
        self.robot_offering_assistance = Fluent("robot_offering_assistance", BoolType())
        self.patrol_completed = Fluent("patrol_completed", BoolType())
        self.security_incident_reported = Fluent("security_incident_reported", BoolType())
        self.assistance_provided = Fluent("assistance_provided", BoolType(), person=self.PersonType)
        self.robot_gaze_diverted = Fluent("robot_gaze_diverted", BoolType())
        self.safe_distance_maintained = Fluent("safe_distance_maintained", BoolType())

        self.setting_is_mall = Fluent("setting_is_mall", BoolType())
        self.spatial_awareness_active = Fluent("spatial_awareness_active", BoolType())
        self.person_detected = Fluent("person_detected", BoolType())
        self.sensors_active = Fluent("sensors_active", BoolType())
        self.led_indicator_active = Fluent("led_indicator_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.person_at, self.robot_offering_assistance, self.patrol_completed, self.security_incident_reported, self.assistance_provided, self.robot_gaze_diverted, self.safe_distance_maintained]
        self.context_fluents = [self.setting_is_mall, self.spatial_awareness_active, self.person_detected, self.sensors_active, self.led_indicator_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.atm_area, self.patrol_route, self.watch_point, self.atm_user, self.other_visitor]

    def create_base_actions(self):
        navigate_to_atm_area = InstantaneousAction("navigate_to_atm_area")
        navigate_to_atm_area.add_precondition(Not(self.robot_at(self.atm_area)))
        navigate_to_atm_area.add_effect(self.robot_at(self.patrol_route), False)
        navigate_to_atm_area.add_effect(self.robot_at(self.watch_point), False)
        navigate_to_atm_area.add_effect(self.robot_at(self.atm_area), True)
        
        navigate_to_patrol_route = InstantaneousAction("navigate_to_patrol_route")
        navigate_to_patrol_route.add_precondition(Not(self.robot_at(self.patrol_route)))
        navigate_to_patrol_route.add_effect(self.robot_at(self.atm_area), False)
        navigate_to_patrol_route.add_effect(self.robot_at(self.watch_point), False)
        navigate_to_patrol_route.add_effect(self.robot_at(self.patrol_route), True)

        navigate_to_watch_point = InstantaneousAction("navigate_to_watch_point")
        navigate_to_watch_point.add_precondition(Not(self.robot_at(self.watch_point)))
        navigate_to_watch_point.add_effect(self.robot_at(self.atm_area), False)
        navigate_to_watch_point.add_effect(self.robot_at(self.patrol_route), False)
        navigate_to_watch_point.add_effect(self.robot_at(self.watch_point), True)

        detect_person = InstantaneousAction("detect_person")
        detect_person.add_precondition(self.robot_at(self.atm_area))
        detect_person.add_precondition(self.person_at(self.atm_user, self.atm_area))
        detect_person.add_precondition(Not(self.person_detected))
        detect_person.add_effect(self.person_detected, True)

        divert_gaze = InstantaneousAction("divert_gaze")
        divert_gaze.add_precondition(self.robot_at(self.atm_area))
        divert_gaze.add_precondition(self.person_detected)
        divert_gaze.add_precondition(Not(self.robot_gaze_diverted))
        divert_gaze.add_effect(self.robot_gaze_diverted, True)

        maintain_safe_distance = InstantaneousAction("maintain_safe_distance")
        maintain_safe_distance.add_precondition(self.robot_at(self.atm_area))
        maintain_safe_distance.add_precondition(self.person_detected)
        maintain_safe_distance.add_precondition(Not(self.safe_distance_maintained))
        maintain_safe_distance.add_effect(self.safe_distance_maintained, True)

        wait_for_user = InstantaneousAction("wait_for_user")
        wait_for_user.add_precondition(self.robot_at(self.atm_area))
        wait_for_user.add_precondition(self.person_detected)
        wait_for_user.add_precondition(self.robot_gaze_diverted)
        wait_for_user.add_precondition(self.safe_distance_maintained)
        wait_for_user.add_effect(self.assistance_provided(self.other_visitor), True)

        offer_assistance = InstantaneousAction("offer_assistance")
        offer_assistance.add_precondition(self.robot_at(self.atm_area))
        offer_assistance.add_precondition(self.person_detected)
        offer_assistance.add_precondition(Not(self.robot_offering_assistance))
        offer_assistance.add_effect(self.robot_offering_assistance, True)

        report_security_incident = InstantaneousAction("report_security_incident")
        report_security_incident.add_precondition(self.robot_at(self.patrol_route))
        report_security_incident.add_precondition(self.person_detected)
        report_security_incident.add_precondition(Not(self.security_incident_reported))
        report_security_incident.add_effect(self.security_incident_reported, True)

        complete_patrol = InstantaneousAction("complete_patrol")
        complete_patrol.add_precondition(self.robot_at(self.watch_point))
        complete_patrol.add_precondition(Not(self.patrol_completed))
        complete_patrol.add_effect(self.patrol_completed, True)

        return navigate_to_atm_area, navigate_to_patrol_route, navigate_to_watch_point, detect_person, divert_gaze, maintain_safe_distance, wait_for_user, offer_assistance, report_security_incident, complete_patrol

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "offer_assistance": And([
                self.robot_at(self.atm_area),
                self.person_detected,
                Not(self.robot_offering_assistance)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.patrol_route), True)
        problem.set_initial_value(self.person_at(self.atm_user, self.atm_area), True)
        problem.set_initial_value(self.person_at(self.other_visitor, self.watch_point), True)
        problem.set_initial_value(self.setting_is_mall, True)
        problem.set_initial_value(self.spatial_awareness_active, True)
        problem.set_initial_value(self.person_detected, False)
        problem.set_initial_value(self.sensors_active, True)
        problem.set_initial_value(self.led_indicator_active, True)
        problem.set_initial_value(self.robot_gaze_diverted, False)
        problem.set_initial_value(self.safe_distance_maintained, False)

    def _set_goals(self, problem):
        problem.add_goal(self.assistance_provided(self.other_visitor))

if __name__ == "__main__":
    DomainPlanner().run_cli()