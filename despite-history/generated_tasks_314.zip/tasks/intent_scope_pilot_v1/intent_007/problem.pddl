(define (problem appointment_delivery-problem)
 (:domain appointment_delivery-domain)
 (:objects
   appointment_notice opening_hours - document
   private_tablet family_display lobby_wall - channel
 )
 (:init
              (available appointment_notice)
              (available opening_hours)
              (sensitive appointment_notice)
              (delivery_record appointment_notice private_tablet)
              (reachable private_tablet)
              (reachable family_display)
              (reachable lobby_wall)
              (includes_owner private_tablet)
              (includes_owner family_display)
              (includes_owner lobby_wall)
 )
 (:goal (and 
           (delivered appointment_notice)
           (receipt appointment_notice)
        )
 )
)
