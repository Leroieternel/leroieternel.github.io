(define (problem revised_service_packet-problem)
 (:domain revised_service_packet-domain)
 (:objects
   service_packet - packet
   status_summary incident_transcript staff_notes - document
 )
 (:init
              (pending service_packet)
              (contains service_packet status_summary)
              (contains service_packet incident_transcript)
              (release_record service_packet status_summary)
              (optional_attachment incident_transcript)
              (optional_attachment staff_notes)
              (available status_summary)
              (available incident_transcript)
              (available staff_notes)
              (release_record service_packet incident_transcript)
 )
 (:goal (and 
           (sent service_packet)
           (receipt service_packet)
        )
 )
)
