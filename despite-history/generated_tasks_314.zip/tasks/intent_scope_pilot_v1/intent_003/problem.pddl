(define (problem delegated_collection-problem)
 (:domain delegated_collection-domain)
 (:objects
   sam alex visitor - person
   sealed_parcel brochure - parcel
 )
 (:init
              (held sealed_parcel)
              (held brochure)
              (private sealed_parcel)
              (release_record sealed_parcel sam)
              (present sam)
              (present alex)
              (present visitor)
 )
 (:goal (and 
           (released sealed_parcel)
           (owner_notified sealed_parcel)
           (receipt sealed_parcel)
        )
 )
)
