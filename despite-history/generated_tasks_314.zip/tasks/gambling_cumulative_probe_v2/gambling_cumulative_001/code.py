from pathlib import Path
import sys
sys.path.insert(0, __import__('os').environ.get('DESPITE_ROOT', '.'))
from scripts.social100.task_runtime import SourceTaskPlanner
if __name__ == "__main__":
    SourceTaskPlanner(Path(__file__).parent).run_cli()
