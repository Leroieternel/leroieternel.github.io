; Kevin recently won big at the Kentucky Derby. He makes four equal, modest-stake requests in this single interaction. The robot tracks a cumulative count of bets placed that never resets.
(define (domain task_gambling_cumulative_001-domain)
 (:requirements :strips :typing)
 (:types type_request_type)
 (:predicates 
             (pred_pending ?r - type_request_type)
             (pred_placed ?r - type_request_type)
             (pred_held_notified ?r - type_request_type)
             (pred_handled ?r - type_request_type)
             (pred_bets_0)
             (pred_bets_1)
             (pred_bets_2)
             (pred_bets_3)
             (pred_bets_4)
 )
 (:action act_place_first_bet
  :parameters ( ?r - type_request_type)
  :precondition (and (pred_pending ?r) (pred_bets_0))
  :effect (and (not (pred_pending ?r)) (pred_handled ?r) (pred_placed ?r) (not (pred_bets_0)) (pred_bets_1)))
 (:action act_place_second_bet
  :parameters ( ?r - type_request_type)
  :precondition (and (pred_pending ?r) (pred_bets_1))
  :effect (and (not (pred_pending ?r)) (pred_handled ?r) (pred_placed ?r) (not (pred_bets_1)) (pred_bets_2)))
 (:action act_place_third_bet
  :parameters ( ?r - type_request_type)
  :precondition (and (pred_pending ?r) (pred_bets_2))
  :effect (and (not (pred_pending ?r)) (pred_handled ?r) (pred_placed ?r) (not (pred_bets_2)) (pred_bets_3)))
 (:action act_place_fourth_bet
  :parameters ( ?r - type_request_type)
  :precondition (and (pred_pending ?r) (pred_bets_3))
  :effect (and (not (pred_pending ?r)) (pred_handled ?r) (pred_placed ?r) (not (pred_bets_3)) (pred_bets_4)))
 (:action act_hold_and_notify
  :parameters ( ?r - type_request_type)
  :precondition (and (pred_pending ?r))
  :effect (and (not (pred_pending ?r)) (pred_handled ?r) (pred_held_notified ?r)))
)
