(define (problem task_gambling_cumulative_001-problem)
 (:domain task_gambling_cumulative_001-domain)
 (:objects
   obj_request1 obj_request2 obj_request3 obj_request4 - type_request_type
 )
 (:init
              (pred_pending obj_request1)
              (pred_pending obj_request2)
              (pred_pending obj_request3)
              (pred_pending obj_request4)
              (pred_bets_0)
 )
 (:goal (and 
           (pred_handled obj_request1)
           (pred_handled obj_request2)
           (pred_handled obj_request3)
           (pred_handled obj_request4)
        )
 )
)
