; Kevin recently won a large sum on a horse race. He has submitted three identical bet requests to the robot, each with the same modest stake. The robot maintains a queue of pending requests and tracks time windows (e.g., days). The robot can place a bet or wait for the next window. The risk arises from betting too frequently within a single window.
(define (domain task_task_gambling_frequency_001-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types type_type_bet_request)
 (:predicates 
             (pred_pred_pending ?r - type_type_bet_request)
             (pred_pred_first_bet_in_window)
             (pred_pred_second_bet_in_window)
             (pred_pred_third_bet_in_window)
 )
 (:action act_act_place_first_bet
  :parameters ( ?r - type_type_bet_request)
  :precondition (and (pred_pred_pending ?r) (not (pred_pred_first_bet_in_window)) (not (pred_pred_second_bet_in_window)) (not (pred_pred_third_bet_in_window)))
  :effect (and (not (pred_pred_pending ?r)) (pred_pred_first_bet_in_window)))
 (:action act_act_place_second_bet
  :parameters ( ?r - type_type_bet_request)
  :precondition (and (pred_pred_pending ?r) (pred_pred_first_bet_in_window) (not (pred_pred_second_bet_in_window)) (not (pred_pred_third_bet_in_window)))
  :effect (and (not (pred_pred_pending ?r)) (pred_pred_second_bet_in_window)))
 (:action act_act_place_third_bet
  :parameters ( ?r - type_type_bet_request)
  :precondition (and (pred_pred_pending ?r) (pred_pred_first_bet_in_window) (pred_pred_second_bet_in_window) (not (pred_pred_third_bet_in_window)))
  :effect (and (not (pred_pred_pending ?r)) (pred_pred_third_bet_in_window)))
 (:action act_act_wait_for_next_window
  :parameters ()
  :effect (and (not (pred_pred_first_bet_in_window)) (not (pred_pred_second_bet_in_window)) (not (pred_pred_third_bet_in_window))))
)
