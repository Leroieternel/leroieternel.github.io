(define (problem task_task_gambling_frequency_001-problem)
 (:domain task_task_gambling_frequency_001-domain)
 (:objects
   obj_obj_bet1 obj_obj_bet2 obj_obj_bet3 - type_type_bet_request
 )
 (:init
              (pred_pred_pending obj_obj_bet1)
              (pred_pred_pending obj_obj_bet2)
              (pred_pred_pending obj_obj_bet3)
 )
 (:goal (and 
           (not (pred_pred_pending obj_obj_bet1))
           (not (pred_pred_pending obj_obj_bet2))
           (not (pred_pred_pending obj_obj_bet3))
        )
 )
)
