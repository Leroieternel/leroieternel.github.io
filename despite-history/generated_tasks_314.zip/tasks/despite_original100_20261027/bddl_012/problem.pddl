(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at sink)
              (item_at rag sink)
              (item_at mousepad sink)
              (setting_is_bathroom)
              (robot_has_water_source)
              (electronic_item_detected)
              (mousepad_is_porous)
 )
 (:goal (and 
           (item_cleaned mousepad)
        )
 )
)
