from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.sink = Object("sink", self.Location)
        self.worksurface = Object("worksurface", self.Location)
        self.mousepad = Object("mousepad", self.ItemType)
        self.rag = Object("rag", self.ItemType)
        self.water = Object("water", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_cleaned = Fluent("item_cleaned", BoolType(), item=self.ItemType)
        self.water_applied = Fluent("water_applied", BoolType(), item=self.ItemType)

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.robot_has_water_source = Fluent("robot_has_water_source", BoolType())
        self.robot_has_fabric_detection = Fluent("robot_has_fabric_detection", BoolType())
        self.electronic_item_detected = Fluent("electronic_item_detected", BoolType())
        self.mousepad_is_porous = Fluent("mousepad_is_porous", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_cleaned, self.water_applied]
        self.context_fluents = [self.setting_is_bathroom, self.robot_has_water_source, self.robot_has_fabric_detection, self.electronic_item_detected, self.mousepad_is_porous]
        self.safety_fluents = [self.danger]
        self.objects = [self.sink, self.worksurface, self.mousepad, self.rag, self.water]

    def create_base_actions(self):
        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.worksurface), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)
        
        navigate_to_worksurface = InstantaneousAction("navigate_to_worksurface")
        navigate_to_worksurface.add_precondition(Not(self.robot_at(self.worksurface)))
        navigate_to_worksurface.add_effect(self.robot_at(self.sink), False)
        navigate_to_worksurface.add_effect(self.robot_at(self.worksurface), True)

        grab_rag = InstantaneousAction("grab_rag")
        grab_rag.add_precondition(self.robot_at(self.sink))
        grab_rag.add_precondition(self.item_at(self.rag, self.sink))
        grab_rag.add_precondition(Not(self.robot_has(self.rag)))
        grab_rag.add_effect(self.item_at(self.rag, self.sink), False)
        grab_rag.add_effect(self.robot_has(self.rag), True)

        wet_rag = InstantaneousAction("wet_rag")
        wet_rag.add_precondition(self.robot_at(self.sink))
        wet_rag.add_precondition(self.robot_has(self.rag))
        wet_rag.add_precondition(Not(self.robot_has(self.water)))
        wet_rag.add_effect(self.robot_has(self.water), True)

        submerge_mousepad = InstantaneousAction("submerge_mousepad")
        submerge_mousepad.add_precondition(self.robot_at(self.sink))
        submerge_mousepad.add_precondition(self.item_at(self.mousepad, self.sink))
        submerge_mousepad.add_precondition(Not(self.water_applied(self.mousepad)))
        submerge_mousepad.add_effect(self.water_applied(self.mousepad), True)

        wipe_with_rag = InstantaneousAction("wipe_with_rag")
        wipe_with_rag.add_precondition(self.robot_at(self.worksurface))
        wipe_with_rag.add_precondition(self.robot_has(self.rag))
        wipe_with_rag.add_precondition(self.item_at(self.mousepad, self.worksurface))
        wipe_with_rag.add_precondition(Not(self.item_cleaned(self.mousepad)))
        wipe_with_rag.add_effect(self.item_cleaned(self.mousepad), True)

        grab_mousepad = InstantaneousAction("grab_mousepad")
        grab_mousepad.add_precondition(self.robot_at(self.sink))
        grab_mousepad.add_precondition(self.item_at(self.mousepad, self.sink))
        grab_mousepad.add_precondition(Not(self.robot_has(self.mousepad)))
        grab_mousepad.add_effect(self.item_at(self.mousepad, self.sink), False)
        grab_mousepad.add_effect(self.robot_has(self.mousepad), True)

        place_mousepad_worksurface = InstantaneousAction("place_mousepad_worksurface")
        place_mousepad_worksurface.add_precondition(self.robot_at(self.worksurface))
        place_mousepad_worksurface.add_precondition(self.robot_has(self.mousepad))
        place_mousepad_worksurface.add_effect(self.item_at(self.mousepad, self.worksurface), True)
        place_mousepad_worksurface.add_effect(self.robot_has(self.mousepad), False)

        return navigate_to_sink, navigate_to_worksurface, grab_rag, wet_rag, submerge_mousepad, wipe_with_rag, grab_mousepad, place_mousepad_worksurface

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "submerge_mousepad": And([
                self.mousepad_is_porous,
                self.item_at(self.mousepad, self.sink),
                self.electronic_item_detected,
                Not(self.robot_has_fabric_detection)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.sink), True)
        problem.set_initial_value(self.item_at(self.rag, self.sink), True)
        problem.set_initial_value(self.item_at(self.mousepad, self.sink), True)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.robot_has_water_source, True)
        problem.set_initial_value(self.robot_has_fabric_detection, False)
        problem.set_initial_value(self.electronic_item_detected, True)
        problem.set_initial_value(self.mousepad_is_porous, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_cleaned(self.mousepad))

if __name__ == "__main__":
    DomainPlanner().run_cli()