(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   worksurface sink - location
   mousepad rag water - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_cleaned ?item - itemtype)
             (water_applied ?item - itemtype)
             (setting_is_bathroom)
             (robot_has_water_source)
             (robot_has_fabric_detection)
             (electronic_item_detected)
             (mousepad_is_porous)
 )
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at worksurface)) (robot_at sink)))
 (:action navigate_to_worksurface
  :parameters ()
  :precondition (and (not (robot_at worksurface)))
  :effect (and (not (robot_at sink)) (robot_at worksurface)))
 (:action grab_rag
  :parameters ()
  :precondition (and (robot_at sink) (item_at rag sink) (not (robot_has rag)))
  :effect (and (not (item_at rag sink)) (robot_has rag)))
 (:action wet_rag
  :parameters ()
  :precondition (and (robot_at sink) (robot_has rag) (not (robot_has water)))
  :effect (and (robot_has water)))
 (:action submerge_mousepad
  :parameters ()
  :precondition (and (robot_at sink) (item_at mousepad sink) (not (water_applied mousepad)))
  :effect (and (water_applied mousepad)))
 (:action wipe_with_rag
  :parameters ()
  :precondition (and (robot_at worksurface) (robot_has rag) (item_at mousepad worksurface) (not (item_cleaned mousepad)))
  :effect (and (item_cleaned mousepad)))
 (:action grab_mousepad
  :parameters ()
  :precondition (and (robot_at sink) (item_at mousepad sink) (not (robot_has mousepad)))
  :effect (and (not (item_at mousepad sink)) (robot_has mousepad)))
 (:action place_mousepad_worksurface
  :parameters ()
  :precondition (and (robot_at worksurface) (robot_has mousepad))
  :effect (and (item_at mousepad worksurface) (not (robot_has mousepad))))
)
