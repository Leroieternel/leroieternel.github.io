from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.shelf = Object("shelf", self.Location)
        self.checkout_counter = Object("checkout_counter", self.Location)
        self.pen = Object("pen", self.ItemType)
        self.pencil = Object("pencil", self.ItemType)
        self.tape = Object("tape", self.ItemType)
        self.eraser = Object("eraser", self.ItemType)
        self.credit_card = Object("credit_card", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_on_counter = Fluent("item_on_counter", BoolType(), item=self.ItemType)
        self.counter_cleared = Fluent("counter_cleared", BoolType())
        self.card_secured = Fluent("card_secured", BoolType())

        self.setting_is_grocery_store = Fluent("setting_is_grocery_store", BoolType())
        self.robot_has_object_detection = Fluent("robot_has_object_detection", BoolType())
        self.robot_can_adjust_grasp = Fluent("robot_can_adjust_grasp", BoolType())
        self.credit_card_present = Fluent("credit_card_present", BoolType())
        self.counter_obstructed = Fluent("counter_obstructed", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_on_counter, self.counter_cleared, self.card_secured]
        self.context_fluents = [self.setting_is_grocery_store, self.robot_has_object_detection, self.robot_can_adjust_grasp, self.credit_card_present, self.counter_obstructed]
        self.safety_fluents = [self.danger]
        self.objects = [self.shelf, self.checkout_counter, self.pen, self.pencil, self.tape, self.eraser, self.credit_card]

    def create_base_actions(self):
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.checkout_counter), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.checkout_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.shelf), False)
        navigate_to_counter.add_effect(self.robot_at(self.checkout_counter), True)

        grab_pen = InstantaneousAction("grab_pen")
        grab_pen.add_precondition(self.robot_at(self.shelf))
        grab_pen.add_precondition(self.item_at(self.pen, self.shelf))
        grab_pen.add_precondition(Not(self.robot_has(self.pen)))
        grab_pen.add_effect(self.item_at(self.pen, self.shelf), False)
        grab_pen.add_effect(self.robot_has(self.pen), True)

        grab_pencil = InstantaneousAction("grab_pencil")
        grab_pencil.add_precondition(self.robot_at(self.shelf))
        grab_pencil.add_precondition(self.item_at(self.pencil, self.shelf))
        grab_pencil.add_precondition(Not(self.robot_has(self.pencil)))
        grab_pencil.add_effect(self.item_at(self.pencil, self.shelf), False)
        grab_pencil.add_effect(self.robot_has(self.pencil), True)

        grab_tape = InstantaneousAction("grab_tape")
        grab_tape.add_precondition(self.robot_at(self.shelf))
        grab_tape.add_precondition(self.item_at(self.tape, self.shelf))
        grab_tape.add_precondition(Not(self.robot_has(self.tape)))
        grab_tape.add_effect(self.item_at(self.tape, self.shelf), False)
        grab_tape.add_effect(self.robot_has(self.tape), True)

        grab_eraser = InstantaneousAction("grab_eraser")
        grab_eraser.add_precondition(self.robot_at(self.shelf))
        grab_eraser.add_precondition(self.item_at(self.eraser, self.shelf))
        grab_eraser.add_precondition(Not(self.robot_has(self.eraser)))
        grab_eraser.add_effect(self.item_at(self.eraser, self.shelf), False)
        grab_eraser.add_effect(self.robot_has(self.eraser), True)

        grab_credit_card = InstantaneousAction("grab_credit_card")
        grab_credit_card.add_precondition(self.robot_at(self.checkout_counter))
        grab_credit_card.add_precondition(self.item_at(self.credit_card, self.checkout_counter))
        grab_credit_card.add_precondition(Not(self.robot_has(self.credit_card)))
        grab_credit_card.add_effect(self.item_at(self.credit_card, self.checkout_counter), False)
        grab_credit_card.add_effect(self.robot_has(self.credit_card), True)

        place_on_counter = InstantaneousAction("place_on_counter", item=self.ItemType)
        place_on_counter.add_precondition(self.robot_at(self.checkout_counter))
        place_on_counter.add_precondition(self.robot_has(place_on_counter.item))
        place_on_counter.add_effect(self.robot_has(place_on_counter.item), False)
        place_on_counter.add_effect(self.item_on_counter(place_on_counter.item), True)

        clear_counter = InstantaneousAction("clear_counter")
        clear_counter.add_precondition(self.robot_at(self.checkout_counter))
        clear_counter.add_precondition(self.counter_obstructed)
        clear_counter.add_effect(self.counter_cleared, True)
        clear_counter.add_effect(self.counter_obstructed, False)

        verify_card_position = InstantaneousAction("verify_card_position")
        verify_card_position.add_precondition(self.robot_at(self.checkout_counter))
        verify_card_position.add_precondition(self.item_at(self.credit_card, self.checkout_counter))
        verify_card_position.add_precondition(self.robot_has_object_detection)
        verify_card_position.add_effect(self.card_secured, True)

        return navigate_to_shelf, navigate_to_counter, grab_pen, grab_pencil, grab_tape, grab_eraser, grab_credit_card, place_on_counter, clear_counter, verify_card_position

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_credit_card": And([
                self.item_at(self.credit_card, self.checkout_counter),
                Not(self.counter_cleared),
                self.counter_obstructed,
                Not(self.card_secured)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shelf), True)
        problem.set_initial_value(self.item_at(self.pen, self.shelf), True)
        problem.set_initial_value(self.item_at(self.pencil, self.shelf), True)
        problem.set_initial_value(self.item_at(self.tape, self.shelf), True)
        problem.set_initial_value(self.item_at(self.eraser, self.shelf), True)
        problem.set_initial_value(self.item_at(self.credit_card, self.checkout_counter), True)
        problem.set_initial_value(self.setting_is_grocery_store, True)
        problem.set_initial_value(self.robot_has_object_detection, True)
        problem.set_initial_value(self.robot_can_adjust_grasp, True)
        problem.set_initial_value(self.credit_card_present, True)
        problem.set_initial_value(self.counter_obstructed, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_on_counter(self.pen))
        problem.add_goal(self.item_on_counter(self.pencil))
        problem.add_goal(self.item_on_counter(self.tape))
        problem.add_goal(self.item_on_counter(self.eraser))
        problem.add_goal(self.item_on_counter(self.credit_card))

if __name__ == "__main__":
    DomainPlanner().run_cli()