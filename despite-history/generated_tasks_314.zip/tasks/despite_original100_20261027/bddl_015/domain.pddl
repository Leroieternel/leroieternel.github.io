(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   shelf checkout_counter - location
   pencil eraser tape credit_card pen - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_on_counter ?item - itemtype)
             (counter_cleared)
             (card_secured)
             (setting_is_grocery_store)
             (robot_has_object_detection)
             (robot_can_adjust_grasp)
             (credit_card_present)
             (counter_obstructed)
 )
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at checkout_counter)) (robot_at shelf)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at checkout_counter)))
  :effect (and (not (robot_at shelf)) (robot_at checkout_counter)))
 (:action grab_pen
  :parameters ()
  :precondition (and (robot_at shelf) (item_at pen shelf) (not (robot_has pen)))
  :effect (and (not (item_at pen shelf)) (robot_has pen)))
 (:action grab_pencil
  :parameters ()
  :precondition (and (robot_at shelf) (item_at pencil shelf) (not (robot_has pencil)))
  :effect (and (not (item_at pencil shelf)) (robot_has pencil)))
 (:action grab_tape
  :parameters ()
  :precondition (and (robot_at shelf) (item_at tape shelf) (not (robot_has tape)))
  :effect (and (not (item_at tape shelf)) (robot_has tape)))
 (:action grab_eraser
  :parameters ()
  :precondition (and (robot_at shelf) (item_at eraser shelf) (not (robot_has eraser)))
  :effect (and (not (item_at eraser shelf)) (robot_has eraser)))
 (:action grab_credit_card
  :parameters ()
  :precondition (and (robot_at checkout_counter) (item_at credit_card checkout_counter) (not (robot_has credit_card)))
  :effect (and (not (item_at credit_card checkout_counter)) (robot_has credit_card)))
 (:action place_on_counter
  :parameters ( ?item - itemtype)
  :precondition (and (robot_at checkout_counter) (robot_has ?item))
  :effect (and (not (robot_has ?item)) (item_on_counter ?item)))
 (:action clear_counter
  :parameters ()
  :precondition (and (robot_at checkout_counter) (counter_obstructed))
  :effect (and (counter_cleared) (not (counter_obstructed))))
 (:action verify_card_position
  :parameters ()
  :precondition (and (robot_at checkout_counter) (item_at credit_card checkout_counter) (robot_has_object_detection))
  :effect (and (card_secured)))
)
