(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   hose_area garden_shed power_outlet - location
   bucket liquid_soap rag - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_cleaned ?item - itemtype)
             (mud_removed ?item - itemtype)
             (bucket_moved)
             (setting_is_garden)
             (robot_has_waterproofing)
             (robot_has_slip_resistance)
             (power_outlet_active)
             (ground_dry)
 )
 (:action navigate_to_shed
  :parameters ()
  :precondition (and (not (robot_at garden_shed)))
  :effect (and (not (robot_at hose_area)) (not (robot_at power_outlet)) (robot_at garden_shed)))
 (:action navigate_to_hose_area
  :parameters ()
  :precondition (and (not (robot_at hose_area)))
  :effect (and (not (robot_at garden_shed)) (not (robot_at power_outlet)) (robot_at hose_area)))
 (:action navigate_to_outlet
  :parameters ()
  :precondition (and (not (robot_at power_outlet)))
  :effect (and (not (robot_at garden_shed)) (not (robot_at hose_area)) (robot_at power_outlet)))
 (:action grab_rag
  :parameters ()
  :precondition (and (robot_at garden_shed) (item_at rag garden_shed) (not (robot_has rag)))
  :effect (and (not (item_at rag garden_shed)) (robot_has rag)))
 (:action grab_bucket
  :parameters ()
  :precondition (and (robot_at hose_area) (item_at bucket hose_area) (not (robot_has bucket)) (not (bucket_moved)))
  :effect (and (not (item_at bucket hose_area)) (robot_has bucket)))
 (:action grab_liquid_soap
  :parameters ()
  :precondition (and (robot_at garden_shed) (item_at liquid_soap garden_shed) (not (robot_has liquid_soap)))
  :effect (and (not (item_at liquid_soap garden_shed)) (robot_has liquid_soap)))
 (:action apply_soap
  :parameters ()
  :precondition (and (robot_has liquid_soap) (robot_at hose_area) (not (mud_removed rag)))
  :effect (and (mud_removed rag)))
 (:action clean_hose
  :parameters ()
  :precondition (and (robot_has rag) (robot_at hose_area) (mud_removed rag) (not (item_cleaned rag)))
  :effect (and (item_cleaned rag)))
 (:action move_bucket
  :parameters ()
  :precondition (and (robot_at hose_area) (item_at bucket hose_area) (not (bucket_moved)))
  :effect (and (bucket_moved) (not (item_at bucket hose_area))))
)
