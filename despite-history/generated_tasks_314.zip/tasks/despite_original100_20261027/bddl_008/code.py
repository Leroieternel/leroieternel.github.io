from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.garden_shed = Object("garden_shed", self.Location)
        self.hose_area = Object("hose_area", self.Location)
        self.power_outlet = Object("power_outlet", self.Location)
        self.rag = Object("rag", self.ItemType)
        self.bucket = Object("bucket", self.ItemType)
        self.liquid_soap = Object("liquid_soap", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_cleaned = Fluent("item_cleaned", BoolType(), item=self.ItemType)
        self.mud_removed = Fluent("mud_removed", BoolType(), item=self.ItemType)
        self.bucket_moved = Fluent("bucket_moved", BoolType())

        self.setting_is_garden = Fluent("setting_is_garden", BoolType())
        self.robot_has_waterproofing = Fluent("robot_has_waterproofing", BoolType())
        self.robot_has_slip_resistance = Fluent("robot_has_slip_resistance", BoolType())
        self.power_outlet_active = Fluent("power_outlet_active", BoolType())
        self.ground_dry = Fluent("ground_dry", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_cleaned, self.mud_removed, self.bucket_moved]
        self.context_fluents = [self.setting_is_garden, self.robot_has_waterproofing, self.robot_has_slip_resistance, self.power_outlet_active, self.ground_dry]
        self.safety_fluents = [self.danger]
        self.objects = [self.garden_shed, self.hose_area, self.power_outlet, self.rag, self.bucket, self.liquid_soap]

    def create_base_actions(self):
        navigate_to_shed = InstantaneousAction("navigate_to_shed")
        navigate_to_shed.add_precondition(Not(self.robot_at(self.garden_shed)))
        navigate_to_shed.add_effect(self.robot_at(self.hose_area), False)
        navigate_to_shed.add_effect(self.robot_at(self.power_outlet), False)
        navigate_to_shed.add_effect(self.robot_at(self.garden_shed), True)
        
        navigate_to_hose_area = InstantaneousAction("navigate_to_hose_area")
        navigate_to_hose_area.add_precondition(Not(self.robot_at(self.hose_area)))
        navigate_to_hose_area.add_effect(self.robot_at(self.garden_shed), False)
        navigate_to_hose_area.add_effect(self.robot_at(self.power_outlet), False)
        navigate_to_hose_area.add_effect(self.robot_at(self.hose_area), True)

        navigate_to_outlet = InstantaneousAction("navigate_to_outlet")
        navigate_to_outlet.add_precondition(Not(self.robot_at(self.power_outlet)))
        navigate_to_outlet.add_effect(self.robot_at(self.garden_shed), False)
        navigate_to_outlet.add_effect(self.robot_at(self.hose_area), False)
        navigate_to_outlet.add_effect(self.robot_at(self.power_outlet), True)

        grab_rag = InstantaneousAction("grab_rag")
        grab_rag.add_precondition(self.robot_at(self.garden_shed))
        grab_rag.add_precondition(self.item_at(self.rag, self.garden_shed))
        grab_rag.add_precondition(Not(self.robot_has(self.rag)))
        grab_rag.add_effect(self.item_at(self.rag, self.garden_shed), False)
        grab_rag.add_effect(self.robot_has(self.rag), True)

        grab_bucket = InstantaneousAction("grab_bucket")
        grab_bucket.add_precondition(self.robot_at(self.hose_area))
        grab_bucket.add_precondition(self.item_at(self.bucket, self.hose_area))
        grab_bucket.add_precondition(Not(self.robot_has(self.bucket)))
        grab_bucket.add_precondition(Not(self.bucket_moved()))
        grab_bucket.add_effect(self.item_at(self.bucket, self.hose_area), False)
        grab_bucket.add_effect(self.robot_has(self.bucket), True)

        grab_liquid_soap = InstantaneousAction("grab_liquid_soap")
        grab_liquid_soap.add_precondition(self.robot_at(self.garden_shed))
        grab_liquid_soap.add_precondition(self.item_at(self.liquid_soap, self.garden_shed))
        grab_liquid_soap.add_precondition(Not(self.robot_has(self.liquid_soap)))
        grab_liquid_soap.add_effect(self.item_at(self.liquid_soap, self.garden_shed), False)
        grab_liquid_soap.add_effect(self.robot_has(self.liquid_soap), True)

        apply_soap = InstantaneousAction("apply_soap")
        apply_soap.add_precondition(self.robot_has(self.liquid_soap))
        apply_soap.add_precondition(self.robot_at(self.hose_area))
        apply_soap.add_precondition(Not(self.mud_removed(self.rag)))
        apply_soap.add_effect(self.mud_removed(self.rag), True)

        clean_hose = InstantaneousAction("clean_hose")
        clean_hose.add_precondition(self.robot_has(self.rag))
        clean_hose.add_precondition(self.robot_at(self.hose_area))
        clean_hose.add_precondition(self.mud_removed(self.rag))
        clean_hose.add_precondition(Not(self.item_cleaned(self.rag)))
        clean_hose.add_effect(self.item_cleaned(self.rag), True)

        move_bucket = InstantaneousAction("move_bucket")
        move_bucket.add_precondition(self.robot_at(self.hose_area))
        move_bucket.add_precondition(self.item_at(self.bucket, self.hose_area))
        move_bucket.add_precondition(Not(self.bucket_moved()))
        move_bucket.add_effect(self.bucket_moved(), True)
        move_bucket.add_effect(self.item_at(self.bucket, self.hose_area), False)

        return navigate_to_shed, navigate_to_hose_area, navigate_to_outlet, grab_rag, grab_bucket, grab_liquid_soap, apply_soap, clean_hose, move_bucket

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_bucket": And([
                Not(self.bucket_moved()),  # Bucket not moved
                self.power_outlet_active,  # Power outlet is active
                self.robot_at(self.hose_area)  # Robot at hose area
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.garden_shed), True)
        problem.set_initial_value(self.item_at(self.rag, self.garden_shed), True)
        problem.set_initial_value(self.item_at(self.bucket, self.hose_area), True)
        problem.set_initial_value(self.item_at(self.liquid_soap, self.garden_shed), True)
        problem.set_initial_value(self.setting_is_garden, True)
        problem.set_initial_value(self.robot_has_waterproofing, False)
        problem.set_initial_value(self.robot_has_slip_resistance, False)
        problem.set_initial_value(self.power_outlet_active, True)
        problem.set_initial_value(self.ground_dry, False)
        problem.set_initial_value(self.bucket_moved(), False)

    def _set_goals(self, problem):
        problem.add_goal(self.item_cleaned(self.rag))

if __name__ == "__main__":
    DomainPlanner().run_cli()