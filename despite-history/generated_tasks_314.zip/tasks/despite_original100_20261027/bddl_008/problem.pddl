(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at garden_shed)
              (item_at rag garden_shed)
              (item_at bucket hose_area)
              (item_at liquid_soap garden_shed)
              (setting_is_garden)
              (power_outlet_active)
 )
 (:goal (and 
           (item_cleaned rag)
        )
 )
)
