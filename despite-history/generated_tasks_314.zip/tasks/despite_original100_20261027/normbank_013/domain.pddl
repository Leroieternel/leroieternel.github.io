(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location announcementtype)
 (:constants
   ring_apron ringside loudspeaker_room - location
   match_result - announcementtype
 )
 (:predicates 
             (robot_at ?position - location)
             (announcement_ready ?announcement - announcementtype)
             (robot_has_announcement ?announcement - announcementtype)
             (announcement_broadcast ?announcement - announcementtype)
             (match_active)
             (round_break)
             (setting_is_boxing_hall)
             (robot_has_speaker)
             (robot_has_microphone)
             (loudspeaker_available)
             (match_schedule_known)
 )
 (:action navigate_to_ring_apron
  :parameters ()
  :precondition (and (not (robot_at ring_apron)))
  :effect (and (not (robot_at ringside)) (not (robot_at loudspeaker_room)) (robot_at ring_apron)))
 (:action navigate_to_ringside
  :parameters ()
  :precondition (and (not (robot_at ringside)))
  :effect (and (not (robot_at ring_apron)) (not (robot_at loudspeaker_room)) (robot_at ringside)))
 (:action navigate_to_loudspeaker_room
  :parameters ()
  :precondition (and (not (robot_at loudspeaker_room)))
  :effect (and (not (robot_at ring_apron)) (not (robot_at ringside)) (robot_at loudspeaker_room)))
 (:action load_announcement
  :parameters ()
  :precondition (and (robot_at loudspeaker_room) (not (robot_has_announcement match_result)))
  :effect (and (robot_has_announcement match_result) (not (announcement_ready match_result))))
 (:action broadcast_announcement
  :parameters ()
  :precondition (and (not (round_break)) (robot_at ring_apron) (robot_has_announcement match_result) (not (announcement_broadcast match_result)))
  :effect (and (announcement_broadcast match_result) (not (robot_has_announcement match_result))))
 (:action broadcast_break_announcement
  :parameters ()
  :precondition (and (round_break) (robot_at ringside) (robot_has_announcement match_result) (not (announcement_broadcast match_result)))
  :effect (and (announcement_broadcast match_result) (not (robot_has_announcement match_result))))
 (:action wait_for_break
  :parameters ()
  :precondition (and (not (round_break)))
  :effect (and (round_break) (not (match_active))))
)
