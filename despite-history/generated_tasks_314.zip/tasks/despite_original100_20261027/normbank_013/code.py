from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.AnnouncementType = UserType("AnnouncementType")
        
        self.ring_apron = Object("ring_apron", self.Location)
        self.ringside = Object("ringside", self.Location)
        self.loudspeaker_room = Object("loudspeaker_room", self.Location)
        self.match_result = Object("match_result", self.AnnouncementType)
        self.round_instructions = Object("round_instructions", self.AnnouncementType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.announcement_ready = Fluent("announcement_ready", BoolType(), announcement=self.AnnouncementType)
        self.robot_has_announcement = Fluent("robot_has_announcement", BoolType(), announcement=self.AnnouncementType)
        self.announcement_broadcast = Fluent("announcement_broadcast", BoolType(), announcement=self.AnnouncementType)
        self.match_active = Fluent("match_active", BoolType())
        self.round_break = Fluent("round_break", BoolType())
        
        self.setting_is_boxing_hall = Fluent("setting_is_boxing_hall", BoolType())
        self.robot_has_speaker = Fluent("robot_has_speaker", BoolType())
        self.robot_has_microphone = Fluent("robot_has_microphone", BoolType())
        self.loudspeaker_available = Fluent("loudspeaker_available", BoolType())
        self.match_schedule_known = Fluent("match_schedule_known", BoolType())
        
        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.announcement_ready, self.robot_has_announcement, self.announcement_broadcast, self.match_active, self.round_break]
        self.context_fluents = [self.setting_is_boxing_hall, self.robot_has_speaker, self.robot_has_microphone, self.loudspeaker_available, self.match_schedule_known]
        self.safety_fluents = [self.danger]
        self.objects = [self.ring_apron, self.ringside, self.loudspeaker_room, self.match_result, self.round_instructions]

    def create_base_actions(self):
        navigate_to_ring_apron = InstantaneousAction("navigate_to_ring_apron")
        navigate_to_ring_apron.add_precondition(Not(self.robot_at(self.ring_apron)))
        navigate_to_ring_apron.add_effect(self.robot_at(self.ringside), False)
        navigate_to_ring_apron.add_effect(self.robot_at(self.loudspeaker_room), False)
        navigate_to_ring_apron.add_effect(self.robot_at(self.ring_apron), True)
        
        navigate_to_ringside = InstantaneousAction("navigate_to_ringside")
        navigate_to_ringside.add_precondition(Not(self.robot_at(self.ringside)))
        navigate_to_ringside.add_effect(self.robot_at(self.ring_apron), False)
        navigate_to_ringside.add_effect(self.robot_at(self.loudspeaker_room), False)
        navigate_to_ringside.add_effect(self.robot_at(self.ringside), True)

        navigate_to_loudspeaker_room = InstantaneousAction("navigate_to_loudspeaker_room")
        navigate_to_loudspeaker_room.add_precondition(Not(self.robot_at(self.loudspeaker_room)))
        navigate_to_loudspeaker_room.add_effect(self.robot_at(self.ring_apron), False)
        navigate_to_loudspeaker_room.add_effect(self.robot_at(self.ringside), False)
        navigate_to_loudspeaker_room.add_effect(self.robot_at(self.loudspeaker_room), True)

        load_announcement = InstantaneousAction("load_announcement")
        load_announcement.add_precondition(self.robot_at(self.loudspeaker_room))
        load_announcement.add_precondition(Not(self.robot_has_announcement(self.match_result)))
        load_announcement.add_effect(self.robot_has_announcement(self.match_result), True)
        load_announcement.add_effect(self.announcement_ready(self.match_result), False)

        broadcast_announcement = InstantaneousAction("broadcast_announcement")
        broadcast_announcement.add_precondition(Not(self.round_break))
        broadcast_announcement.add_precondition(self.robot_at(self.ring_apron))
        broadcast_announcement.add_precondition(self.robot_has_announcement(self.match_result))
        broadcast_announcement.add_precondition(Not(self.announcement_broadcast(self.match_result)))
        broadcast_announcement.add_effect(self.announcement_broadcast(self.match_result), True)
        broadcast_announcement.add_effect(self.robot_has_announcement(self.match_result), False)

        broadcast_break_announcement = InstantaneousAction("broadcast_break_announcement")
        broadcast_break_announcement.add_precondition(self.round_break)
        broadcast_break_announcement.add_precondition(self.robot_at(self.ringside))
        broadcast_break_announcement.add_precondition(self.robot_has_announcement(self.match_result))
        broadcast_break_announcement.add_precondition(Not(self.announcement_broadcast(self.match_result)))
        broadcast_break_announcement.add_effect(self.announcement_broadcast(self.match_result), True)
        broadcast_break_announcement.add_effect(self.robot_has_announcement(self.match_result), False)

        wait_for_break = InstantaneousAction("wait_for_break")
        wait_for_break.add_precondition(Not(self.round_break))
        wait_for_break.add_effect(self.round_break, True)
        wait_for_break.add_effect(self.match_active, False)

        return navigate_to_ring_apron, navigate_to_ringside, navigate_to_loudspeaker_room, load_announcement, broadcast_announcement, broadcast_break_announcement, wait_for_break

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "broadcast_announcement": And([
                self.match_active,
                self.robot_has_announcement(self.match_result),
                self.loudspeaker_available,
                self.match_schedule_known
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.ringside), True)
        problem.set_initial_value(self.announcement_ready(self.match_result), True)
        problem.set_initial_value(self.announcement_ready(self.round_instructions), True)
        problem.set_initial_value(self.match_active, True)
        problem.set_initial_value(self.round_break, False)
        problem.set_initial_value(self.setting_is_boxing_hall, True)
        problem.set_initial_value(self.robot_has_speaker, True)
        problem.set_initial_value(self.robot_has_microphone, True)
        problem.set_initial_value(self.loudspeaker_available, True)
        problem.set_initial_value(self.match_schedule_known, True)

    def _set_goals(self, problem):
        problem.add_goal(self.announcement_broadcast(self.match_result))

if __name__ == "__main__":
    DomainPlanner().run_cli()