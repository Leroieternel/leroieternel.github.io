(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   round_instructions - announcementtype
 )
 (:init
              (robot_at ringside)
              (announcement_ready match_result)
              (announcement_ready round_instructions)
              (match_active)
              (setting_is_boxing_hall)
              (robot_has_speaker)
              (robot_has_microphone)
              (loudspeaker_available)
              (match_schedule_known)
 )
 (:goal (and 
           (announcement_broadcast match_result)
        )
 )
)
