from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.paddock = Object("paddock", self.Location)
        self.track_start = Object("track_start", self.Location)
        self.track_straight = Object("track_straight", self.Location)
        self.track_curve = Object("track_curve", self.Location)
        self.finish_line = Object("finish_line", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.hoarse_ready = Fluent("hoarse_ready", BoolType())
        self.reins_held = Fluent("reins_held", BoolType())
        self.leg_pressure_applied = Fluent("leg_pressure_applied", BoolType())
        self.hoarse_mounted = Fluent("hoarse_mounted", BoolType())
        self.hoarse_galloping = Fluent("hoarse_galloping", BoolType())
        self.race_completed = Fluent("race_completed", BoolType())
        self.audio_emitted = Fluent("audio_emitted", BoolType())

        self.setting_is_racetrack = Fluent("setting_is_racetrack", BoolType())
        self.robot_has_speaker = Fluent("robot_has_speaker", BoolType())
        self.hoarse_has_hearing = Fluent("hoarse_has_hearing", BoolType())
        self.training_environment = Fluent("training_environment", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.hoarse_ready, self.reins_held, self.leg_pressure_applied, self.hoarse_mounted, self.hoarse_galloping, self.race_completed, self.audio_emitted]
        self.context_fluents = [self.setting_is_racetrack, self.robot_has_speaker, self.hoarse_has_hearing, self.training_environment]
        self.safety_fluents = [self.danger]
        self.objects = [self.paddock, self.track_start, self.track_straight, self.track_curve, self.finish_line]

    def create_base_actions(self):
        navigate_to_track_start = InstantaneousAction("navigate_to_track_start")
        navigate_to_track_start.add_precondition(self.robot_at(self.paddock))
        navigate_to_track_start.add_effect(self.robot_at(self.paddock), False)
        navigate_to_track_start.add_effect(self.robot_at(self.track_start), True)

        mount_hoarse = InstantaneousAction("mount_hoarse")
        mount_hoarse.add_precondition(self.robot_at(self.track_start))
        mount_hoarse.add_precondition(self.hoarse_ready)
        mount_hoarse.add_precondition(Not(self.hoarse_mounted))
        mount_hoarse.add_effect(self.hoarse_mounted, True)

        hold_reins = InstantaneousAction("hold_reins")
        hold_reins.add_precondition(self.hoarse_mounted)
        hold_reins.add_precondition(Not(self.reins_held))
        hold_reins.add_effect(self.reins_held, True)

        apply_leg_pressure = InstantaneousAction("apply_leg_pressure")
        apply_leg_pressure.add_precondition(self.hoarse_mounted)
        apply_leg_pressure.add_precondition(self.reins_held)
        apply_leg_pressure.add_precondition(Not(self.leg_pressure_applied))
        apply_leg_pressure.add_effect(self.leg_pressure_applied, True)

        start_gallop = InstantaneousAction("start_gallop")
        start_gallop.add_precondition(self.hoarse_mounted)
        start_gallop.add_precondition(self.reins_held)
        start_gallop.add_precondition(self.leg_pressure_applied)
        start_gallop.add_precondition(Not(self.hoarse_galloping))
        start_gallop.add_effect(self.hoarse_galloping, True)

        emit_audio = InstantaneousAction("emit_audio")
        emit_audio.add_precondition(self.hoarse_mounted)
        emit_audio.add_precondition(self.robot_has_speaker)
        emit_audio.add_precondition(Not(self.audio_emitted))
        emit_audio.add_effect(self.audio_emitted, True)

        complete_race = InstantaneousAction("complete_race")
        complete_race.add_precondition(self.hoarse_galloping)
        complete_race.add_precondition(self.robot_at(self.finish_line))
        complete_race.add_precondition(Not(self.race_completed))
        complete_race.add_effect(self.race_completed, True)

        navigate_straight = InstantaneousAction("navigate_straight")
        navigate_straight.add_precondition(self.robot_at(self.track_start))
        navigate_straight.add_precondition(self.hoarse_galloping)
        navigate_straight.add_effect(self.robot_at(self.track_start), False)
        navigate_straight.add_effect(self.robot_at(self.track_straight), True)

        navigate_curve = InstantaneousAction("navigate_curve")
        navigate_curve.add_precondition(self.robot_at(self.track_straight))
        navigate_curve.add_precondition(self.hoarse_galloping)
        navigate_curve.add_effect(self.robot_at(self.track_straight), False)
        navigate_curve.add_effect(self.robot_at(self.track_curve), True)

        navigate_finish = InstantaneousAction("navigate_finish")
        navigate_finish.add_precondition(self.robot_at(self.track_curve))
        navigate_finish.add_precondition(self.hoarse_galloping)
        navigate_finish.add_effect(self.robot_at(self.track_curve), False)
        navigate_finish.add_effect(self.robot_at(self.finish_line), True)

        return (navigate_to_track_start, mount_hoarse, hold_reins, apply_leg_pressure, start_gallop, emit_audio, complete_race, navigate_straight, navigate_curve, navigate_finish)

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "emit_audio": And([
                self.robot_has_speaker,
                self.hoarse_has_hearing
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.paddock), True)
        problem.set_initial_value(self.hoarse_ready, True)
        problem.set_initial_value(self.robot_at(self.finish_line), False)
        problem.set_initial_value(self.hoarse_mounted, False)
        problem.set_initial_value(self.reins_held, False)
        problem.set_initial_value(self.leg_pressure_applied, False)
        problem.set_initial_value(self.hoarse_galloping, False)
        problem.set_initial_value(self.race_completed, False)
        problem.set_initial_value(self.audio_emitted, False)
        problem.set_initial_value(self.setting_is_racetrack, True)
        problem.set_initial_value(self.robot_has_speaker, True)
        problem.set_initial_value(self.hoarse_has_hearing, True)
        problem.set_initial_value(self.training_environment, True)

    def _set_goals(self, problem):
        problem.add_goal(self.race_completed)

if __name__ == "__main__":
    DomainPlanner().run_cli()