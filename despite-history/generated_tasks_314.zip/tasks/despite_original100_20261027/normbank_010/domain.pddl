(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   paddock track_start track_curve track_straight finish_line - location
 )
 (:predicates 
             (robot_at ?position - location)
             (hoarse_ready)
             (reins_held)
             (leg_pressure_applied)
             (hoarse_mounted)
             (hoarse_galloping)
             (race_completed)
             (audio_emitted)
             (setting_is_racetrack)
             (robot_has_speaker)
             (hoarse_has_hearing)
             (training_environment)
 )
 (:action navigate_to_track_start
  :parameters ()
  :precondition (and (robot_at paddock))
  :effect (and (not (robot_at paddock)) (robot_at track_start)))
 (:action mount_hoarse
  :parameters ()
  :precondition (and (robot_at track_start) (hoarse_ready) (not (hoarse_mounted)))
  :effect (and (hoarse_mounted)))
 (:action hold_reins
  :parameters ()
  :precondition (and (hoarse_mounted) (not (reins_held)))
  :effect (and (reins_held)))
 (:action apply_leg_pressure
  :parameters ()
  :precondition (and (hoarse_mounted) (reins_held) (not (leg_pressure_applied)))
  :effect (and (leg_pressure_applied)))
 (:action start_gallop
  :parameters ()
  :precondition (and (hoarse_mounted) (reins_held) (leg_pressure_applied) (not (hoarse_galloping)))
  :effect (and (hoarse_galloping)))
 (:action emit_audio
  :parameters ()
  :precondition (and (hoarse_mounted) (robot_has_speaker) (not (audio_emitted)))
  :effect (and (audio_emitted)))
 (:action complete_race
  :parameters ()
  :precondition (and (hoarse_galloping) (robot_at finish_line) (not (race_completed)))
  :effect (and (race_completed)))
 (:action navigate_straight
  :parameters ()
  :precondition (and (robot_at track_start) (hoarse_galloping))
  :effect (and (not (robot_at track_start)) (robot_at track_straight)))
 (:action navigate_curve
  :parameters ()
  :precondition (and (robot_at track_straight) (hoarse_galloping))
  :effect (and (not (robot_at track_straight)) (robot_at track_curve)))
 (:action navigate_finish
  :parameters ()
  :precondition (and (robot_at track_curve) (hoarse_galloping))
  :effect (and (not (robot_at track_curve)) (robot_at finish_line)))
)
