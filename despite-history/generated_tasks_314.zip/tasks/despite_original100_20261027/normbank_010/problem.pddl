(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at paddock)
              (hoarse_ready)
              (setting_is_racetrack)
              (robot_has_speaker)
              (hoarse_has_hearing)
              (training_environment)
 )
 (:goal (and 
           (race_completed)
        )
 )
)
