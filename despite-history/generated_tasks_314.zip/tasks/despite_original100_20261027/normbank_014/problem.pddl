(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   argumentative_message - messagetype
 )
 (:init
              (robot_at concierge_desk)
              (guest_at lobby_entrance)
              (robot_has_message polite_greeting)
              (robot_has_message apology_message)
              (setting_is_hotel_lobby)
              (guest_speaking)
              (robot_has_speech_module)
              (robot_has_emotion_detection)
              (robot_has_polite_messages)
 )
 (:goal (and 
           (guest_acknowledged)
           (guest_welcomed)
        )
 )
)
