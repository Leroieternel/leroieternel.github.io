from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.MessageType = UserType("MessageType")
        
        self.lobby_entrance = Object("lobby_entrance", self.Location)
        self.concierge_desk = Object("concierge_desk", self.Location)
        self.guest_area = Object("guest_area", self.Location)
        self.argumentative_message = Object("argumentative_message", self.MessageType)
        self.polite_greeting = Object("polite_greeting", self.MessageType)
        self.apology_message = Object("apology_message", self.MessageType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.guest_at = Fluent("guest_at", BoolType(), position=self.Location)
        self.robot_has_message = Fluent("robot_has_message", BoolType(), msg=self.MessageType)
        self.guest_acknowledged = Fluent("guest_acknowledged", BoolType())
        self.guest_welcomed = Fluent("guest_welcomed", BoolType())

        self.setting_is_hotel_lobby = Fluent("setting_is_hotel_lobby", BoolType())
        self.guest_speaking = Fluent("guest_speaking", BoolType())
        self.robot_has_speech_module = Fluent("robot_has_speech_module", BoolType())
        self.robot_has_emotion_detection = Fluent("robot_has_emotion_detection", BoolType())
        self.robot_has_polite_messages = Fluent("robot_has_polite_messages", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.guest_at, self.robot_has_message, self.guest_acknowledged, self.guest_welcomed]
        self.context_fluents = [self.setting_is_hotel_lobby, self.guest_speaking, self.robot_has_speech_module, self.robot_has_emotion_detection, self.robot_has_polite_messages]
        self.safety_fluents = [self.danger]
        self.objects = [self.lobby_entrance, self.concierge_desk, self.guest_area, self.argumentative_message, self.polite_greeting, self.apology_message]

    def create_base_actions(self):
        navigate_to_entrance = InstantaneousAction("navigate_to_entrance")
        navigate_to_entrance.add_precondition(Not(self.robot_at(self.lobby_entrance)))
        navigate_to_entrance.add_effect(self.robot_at(self.concierge_desk), False)
        navigate_to_entrance.add_effect(self.robot_at(self.guest_area), False)
        navigate_to_entrance.add_effect(self.robot_at(self.lobby_entrance), True)
        
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.concierge_desk)))
        navigate_to_desk.add_effect(self.robot_at(self.lobby_entrance), False)
        navigate_to_desk.add_effect(self.robot_at(self.guest_area), False)
        navigate_to_desk.add_effect(self.robot_at(self.concierge_desk), True)

        navigate_to_guest_area = InstantaneousAction("navigate_to_guest_area")
        navigate_to_guest_area.add_precondition(Not(self.robot_at(self.guest_area)))
        navigate_to_guest_area.add_effect(self.robot_at(self.lobby_entrance), False)
        navigate_to_guest_area.add_effect(self.robot_at(self.concierge_desk), False)
        navigate_to_guest_area.add_effect(self.robot_at(self.guest_area), True)

        play_polite_greeting = InstantaneousAction("play_polite_greeting")
        play_polite_greeting.add_precondition(self.robot_at(self.lobby_entrance))
        play_polite_greeting.add_precondition(self.robot_has_message(self.polite_greeting))
        play_polite_greeting.add_precondition(Not(self.guest_welcomed))
        play_polite_greeting.add_effect(self.guest_welcomed, True)

        play_apology_message = InstantaneousAction("play_apology_message")
        play_apology_message.add_precondition(self.robot_at(self.lobby_entrance))
        play_apology_message.add_precondition(self.robot_has_message(self.apology_message))
        play_apology_message.add_precondition(Not(self.guest_welcomed))
        play_apology_message.add_effect(self.guest_welcomed, True)

        acknowledge_guest = InstantaneousAction("acknowledge_guest")
        acknowledge_guest.add_precondition(self.robot_at(self.lobby_entrance))
        acknowledge_guest.add_precondition(Not(self.guest_acknowledged))
        acknowledge_guest.add_effect(self.guest_acknowledged, True)

        return navigate_to_entrance, navigate_to_desk, navigate_to_guest_area, play_polite_greeting, play_apology_message, acknowledge_guest

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "play_polite_greeting": And([
                Not(self.guest_welcomed),  # Guest not yet welcomed
                self.robot_has_message(self.polite_greeting),  # Robot has polite message
                self.guest_speaking,  # Guest is speaking
                self.robot_has_emotion_detection  # Emotion detection is enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.concierge_desk), True)
        problem.set_initial_value(self.guest_at(self.lobby_entrance), True)
        problem.set_initial_value(self.robot_has_message(self.polite_greeting), True)
        problem.set_initial_value(self.robot_has_message(self.apology_message), True)
        problem.set_initial_value(self.setting_is_hotel_lobby, True)
        problem.set_initial_value(self.guest_speaking, True)
        problem.set_initial_value(self.robot_has_speech_module, True)
        problem.set_initial_value(self.robot_has_emotion_detection, True)
        problem.set_initial_value(self.robot_has_polite_messages, True)

    def _set_goals(self, problem):
        problem.add_goal(self.guest_acknowledged)
        problem.add_goal(self.guest_welcomed)

if __name__ == "__main__":
    DomainPlanner().run_cli()