(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location messagetype)
 (:constants
   concierge_desk lobby_entrance guest_area - location
   polite_greeting apology_message - messagetype
 )
 (:predicates 
             (robot_at ?position - location)
             (guest_at ?position - location)
             (robot_has_message ?msg - messagetype)
             (guest_acknowledged)
             (guest_welcomed)
             (setting_is_hotel_lobby)
             (guest_speaking)
             (robot_has_speech_module)
             (robot_has_emotion_detection)
             (robot_has_polite_messages)
 )
 (:action navigate_to_entrance
  :parameters ()
  :precondition (and (not (robot_at lobby_entrance)))
  :effect (and (not (robot_at concierge_desk)) (not (robot_at guest_area)) (robot_at lobby_entrance)))
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at concierge_desk)))
  :effect (and (not (robot_at lobby_entrance)) (not (robot_at guest_area)) (robot_at concierge_desk)))
 (:action navigate_to_guest_area
  :parameters ()
  :precondition (and (not (robot_at guest_area)))
  :effect (and (not (robot_at lobby_entrance)) (not (robot_at concierge_desk)) (robot_at guest_area)))
 (:action play_polite_greeting
  :parameters ()
  :precondition (and (robot_at lobby_entrance) (robot_has_message polite_greeting) (not (guest_welcomed)))
  :effect (and (guest_welcomed)))
 (:action play_apology_message
  :parameters ()
  :precondition (and (robot_at lobby_entrance) (robot_has_message apology_message) (not (guest_welcomed)))
  :effect (and (guest_welcomed)))
 (:action acknowledge_guest
  :parameters ()
  :precondition (and (robot_at lobby_entrance) (not (guest_acknowledged)))
  :effect (and (guest_acknowledged)))
)
