(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   wrapper - itemtype
 )
 (:init
              (robot_at counter)
              (item_at cake counter)
              (item_at utensil storage)
              (robot_has_clean_utensil)
              (cake_boundary_detected)
              (robot_has_gloves)
              (contaminant_present)
              (wrapper_available)
 )
 (:goal (and 
           (cake_decorated cake)
        )
 )
)
