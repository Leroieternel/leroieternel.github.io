from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.counter = Object("counter", self.Location)
        self.storage = Object("storage", self.Location)
        self.display = Object("display", self.Location)
        self.cake = Object("cake", self.ItemType)
        self.utensil = Object("utensil", self.ItemType)
        self.wrapper = Object("wrapper", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.cake_decorated = Fluent("cake_decorated", BoolType(), item=self.ItemType)
        self.cake_clean = Fluent("cake_clean", BoolType(), item=self.ItemType)

        self.robot_has_clean_utensil = Fluent("robot_has_clean_utensil", BoolType())
        self.cake_boundary_detected = Fluent("cake_boundary_detected", BoolType())
        self.robot_has_gloves = Fluent("robot_has_gloves", BoolType())
        self.contaminant_present = Fluent("contaminant_present", BoolType())
        self.wrapper_available = Fluent("wrapper_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.cake_decorated, self.cake_clean]
        self.context_fluents = [self.robot_has_clean_utensil, self.cake_boundary_detected, self.robot_has_gloves, self.contaminant_present, self.wrapper_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.counter, self.storage, self.display, self.cake, self.utensil, self.wrapper]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.storage), False)
        navigate_to_counter.add_effect(self.robot_at(self.display), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)
        
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage)))
        navigate_to_storage.add_effect(self.robot_at(self.counter), False)
        navigate_to_storage.add_effect(self.robot_at(self.display), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage), True)

        navigate_to_display = InstantaneousAction("navigate_to_display")
        navigate_to_display.add_precondition(Not(self.robot_at(self.display)))
        navigate_to_display.add_effect(self.robot_at(self.counter), False)
        navigate_to_display.add_effect(self.robot_at(self.storage), False)
        navigate_to_display.add_effect(self.robot_at(self.display), True)

        grab_cake = InstantaneousAction("grab_cake")
        grab_cake.add_precondition(self.robot_at(self.counter))
        grab_cake.add_precondition(self.item_at(self.cake, self.counter))
        grab_cake.add_precondition(Not(self.robot_has(self.cake)))
        grab_cake.add_effect(self.item_at(self.cake, self.counter), False)
        grab_cake.add_effect(self.robot_has(self.cake), True)

        grab_utensil = InstantaneousAction("grab_utensil")
        grab_utensil.add_precondition(self.robot_at(self.storage))
        grab_utensil.add_precondition(self.item_at(self.utensil, self.storage))
        grab_utensil.add_precondition(Not(self.robot_has(self.utensil)))
        grab_utensil.add_effect(self.item_at(self.utensil, self.storage), False)
        grab_utensil.add_effect(self.robot_has(self.utensil), True)

        place_cake_on_display = InstantaneousAction("place_cake_on_display")
        place_cake_on_display.add_precondition(self.robot_at(self.display))
        place_cake_on_display.add_precondition(self.robot_has(self.cake))
        place_cake_on_display.add_precondition(Not(self.cake_decorated(self.cake)))
        place_cake_on_display.add_effect(self.cake_decorated(self.cake), True)
        place_cake_on_display.add_effect(self.robot_has(self.cake), False)

        use_utensil = InstantaneousAction("use_utensil")
        use_utensil.add_precondition(self.robot_has(self.utensil))
        use_utensil.add_precondition(self.robot_has(self.cake))
        use_utensil.add_precondition(Not(self.cake_clean(self.cake)))
        use_utensil.add_effect(self.cake_clean(self.cake), True)

        return navigate_to_counter, navigate_to_storage, navigate_to_display, grab_cake, grab_utensil, place_cake_on_display, use_utensil

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_cake_on_display": And([
                Not(self.cake_clean(self.cake)),  # Cake not cleaned
                self.robot_has(self.cake),  # Robot has cake
                self.robot_has_clean_utensil,  # Robot has clean utensil
                self.cake_boundary_detected  # Cake boundary detected
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.item_at(self.cake, self.counter), True)
        problem.set_initial_value(self.item_at(self.utensil, self.storage), True)
        problem.set_initial_value(self.robot_has_clean_utensil, True)
        problem.set_initial_value(self.cake_boundary_detected, True)
        problem.set_initial_value(self.robot_has_gloves, True)
        problem.set_initial_value(self.contaminant_present, True)
        problem.set_initial_value(self.wrapper_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.cake_decorated(self.cake))

if __name__ == "__main__":
    DomainPlanner().run_cli()