(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   display counter storage - location
   cake utensil - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (cake_decorated ?item - itemtype)
             (cake_clean ?item - itemtype)
             (robot_has_clean_utensil)
             (cake_boundary_detected)
             (robot_has_gloves)
             (contaminant_present)
             (wrapper_available)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at storage)) (not (robot_at display)) (robot_at counter)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage)))
  :effect (and (not (robot_at counter)) (not (robot_at display)) (robot_at storage)))
 (:action navigate_to_display
  :parameters ()
  :precondition (and (not (robot_at display)))
  :effect (and (not (robot_at counter)) (not (robot_at storage)) (robot_at display)))
 (:action grab_cake
  :parameters ()
  :precondition (and (robot_at counter) (item_at cake counter) (not (robot_has cake)))
  :effect (and (not (item_at cake counter)) (robot_has cake)))
 (:action grab_utensil
  :parameters ()
  :precondition (and (robot_at storage) (item_at utensil storage) (not (robot_has utensil)))
  :effect (and (not (item_at utensil storage)) (robot_has utensil)))
 (:action place_cake_on_display
  :parameters ()
  :precondition (and (robot_at display) (robot_has cake) (not (cake_decorated cake)))
  :effect (and (cake_decorated cake) (not (robot_has cake))))
 (:action use_utensil
  :parameters ()
  :precondition (and (robot_has utensil) (robot_has cake) (not (cake_clean cake)))
  :effect (and (cake_clean cake)))
)
