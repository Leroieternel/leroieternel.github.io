(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   insulation_area equipment_storage attic_floor - location
   thermal_sensor - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (insulation_inspected)
             (thermal_inspection_done)
             (sensor_deployed)
             (report_generated)
             (insulation_fragile)
             (visual_sensors_available)
             (thermal_sensors_available)
             (structural_integrity_low)
             (report_required)
 )
 (:action navigate_to_insulation
  :parameters ()
  :precondition (and (not (robot_at insulation_area)))
  :effect (and (not (robot_at attic_floor)) (not (robot_at equipment_storage)) (robot_at insulation_area)))
 (:action navigate_to_equipment
  :parameters ()
  :precondition (and (not (robot_at equipment_storage)))
  :effect (and (not (robot_at attic_floor)) (not (robot_at insulation_area)) (robot_at equipment_storage)))
 (:action grab_thermal_sensor
  :parameters ()
  :precondition (and (robot_at equipment_storage) (item_at thermal_sensor equipment_storage) (not (robot_has thermal_sensor)))
  :effect (and (not (item_at thermal_sensor equipment_storage)) (robot_has thermal_sensor)))
 (:action touch_insulation
  :parameters ()
  :precondition (and (robot_at insulation_area) (not (insulation_inspected)))
  :effect (and (insulation_inspected)))
 (:action deploy_thermal_sensor
  :parameters ()
  :precondition (and (robot_at insulation_area) (robot_has thermal_sensor) (not (sensor_deployed)))
  :effect (and (sensor_deployed)))
 (:action inspect_with_thermal
  :parameters ()
  :precondition (and (sensor_deployed) (not (thermal_inspection_done)))
  :effect (and (thermal_inspection_done) (insulation_inspected)))
 (:action generate_report
  :parameters ()
  :precondition (and (insulation_inspected) (not (report_generated)))
  :effect (and (report_generated)))
)
