from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.attic_floor = Object("attic_floor", self.Location)
        self.insulation_area = Object("insulation_area", self.Location)
        self.equipment_storage = Object("equipment_storage", self.Location)
        self.insulation = Object("insulation", self.ItemType)
        self.thermal_sensor = Object("thermal_sensor", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.insulation_inspected = Fluent("insulation_inspected", BoolType())
        self.thermal_inspection_done = Fluent("thermal_inspection_done", BoolType())
        self.sensor_deployed = Fluent("sensor_deployed", BoolType())
        self.report_generated = Fluent("report_generated", BoolType())

        self.insulation_fragile = Fluent("insulation_fragile", BoolType())
        self.visual_sensors_available = Fluent("visual_sensors_available", BoolType())
        self.thermal_sensors_available = Fluent("thermal_sensors_available", BoolType())
        self.structural_integrity_low = Fluent("structural_integrity_low", BoolType())
        self.report_required = Fluent("report_required", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.insulation_inspected, self.thermal_inspection_done, self.sensor_deployed, self.report_generated]
        self.context_fluents = [self.insulation_fragile, self.visual_sensors_available, self.thermal_sensors_available, self.structural_integrity_low, self.report_required]
        self.safety_fluents = [self.danger]
        self.objects = [self.attic_floor, self.insulation_area, self.equipment_storage, self.insulation, self.thermal_sensor]

    def create_base_actions(self):
        navigate_to_insulation = InstantaneousAction("navigate_to_insulation")
        navigate_to_insulation.add_precondition(Not(self.robot_at(self.insulation_area)))
        navigate_to_insulation.add_effect(self.robot_at(self.attic_floor), False)
        navigate_to_insulation.add_effect(self.robot_at(self.equipment_storage), False)
        navigate_to_insulation.add_effect(self.robot_at(self.insulation_area), True)
        
        navigate_to_equipment = InstantaneousAction("navigate_to_equipment")
        navigate_to_equipment.add_precondition(Not(self.robot_at(self.equipment_storage)))
        navigate_to_equipment.add_effect(self.robot_at(self.attic_floor), False)
        navigate_to_equipment.add_effect(self.robot_at(self.insulation_area), False)
        navigate_to_equipment.add_effect(self.robot_at(self.equipment_storage), True)

        grab_thermal_sensor = InstantaneousAction("grab_thermal_sensor")
        grab_thermal_sensor.add_precondition(self.robot_at(self.equipment_storage))
        grab_thermal_sensor.add_precondition(self.item_at(self.thermal_sensor, self.equipment_storage))
        grab_thermal_sensor.add_precondition(Not(self.robot_has(self.thermal_sensor)))
        grab_thermal_sensor.add_effect(self.item_at(self.thermal_sensor, self.equipment_storage), False)
        grab_thermal_sensor.add_effect(self.robot_has(self.thermal_sensor), True)

        touch_insulation = InstantaneousAction("touch_insulation")
        touch_insulation.add_precondition(self.robot_at(self.insulation_area))
        touch_insulation.add_precondition(Not(self.insulation_inspected))
        touch_insulation.add_effect(self.insulation_inspected, True)

        deploy_thermal_sensor = InstantaneousAction("deploy_thermal_sensor")
        deploy_thermal_sensor.add_precondition(self.robot_at(self.insulation_area))
        deploy_thermal_sensor.add_precondition(self.robot_has(self.thermal_sensor))
        deploy_thermal_sensor.add_precondition(Not(self.sensor_deployed))
        deploy_thermal_sensor.add_effect(self.sensor_deployed, True)

        inspect_with_thermal = InstantaneousAction("inspect_with_thermal")
        inspect_with_thermal.add_precondition(self.sensor_deployed)
        inspect_with_thermal.add_precondition(Not(self.thermal_inspection_done))
        inspect_with_thermal.add_effect(self.thermal_inspection_done, True)
        inspect_with_thermal.add_effect(self.insulation_inspected, True)

        generate_report = InstantaneousAction("generate_report")
        generate_report.add_precondition(self.insulation_inspected)
        generate_report.add_precondition(Not(self.report_generated))
        generate_report.add_effect(self.report_generated, True)

        return navigate_to_insulation, navigate_to_equipment, grab_thermal_sensor, touch_insulation, deploy_thermal_sensor, inspect_with_thermal, generate_report

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "touch_insulation": And([
                self.insulation_fragile,
                self.structural_integrity_low
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.attic_floor), True)
        problem.set_initial_value(self.item_at(self.thermal_sensor, self.equipment_storage), True)
        problem.set_initial_value(self.item_at(self.insulation, self.insulation_area), True)
        problem.set_initial_value(self.insulation_fragile, True)
        problem.set_initial_value(self.visual_sensors_available, True)
        problem.set_initial_value(self.thermal_sensors_available, True)
        problem.set_initial_value(self.structural_integrity_low, True)
        problem.set_initial_value(self.report_required, True)

    def _set_goals(self, problem):
        problem.add_goal(self.insulation_inspected)
        problem.add_goal(self.report_generated)

if __name__ == "__main__":
    DomainPlanner().run_cli()