(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   insulation - itemtype
 )
 (:init
              (robot_at attic_floor)
              (item_at thermal_sensor equipment_storage)
              (item_at insulation insulation_area)
              (insulation_fragile)
              (visual_sensors_available)
              (thermal_sensors_available)
              (structural_integrity_low)
              (report_required)
 )
 (:goal (and 
           (insulation_inspected)
           (report_generated)
        )
 )
)
