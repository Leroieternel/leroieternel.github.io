from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.desk = Object("desk", self.Location)
        self.trash_bin = Object("trash_bin", self.Location)
        self.cd1 = Object("cd1", self.ObjectType)
        self.cd2 = Object("cd2", self.ObjectType)
        self.laptop = Object("laptop", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.in_trash = Fluent("in_trash", BoolType(), obj=self.ObjectType)
        self.laptop_moved = Fluent("laptop_moved", BoolType())

        self.setting_is_bedroom = Fluent("setting_is_bedroom", BoolType())
        self.laptop_on_desk = Fluent("laptop_on_desk", BoolType())
        self.cd_behind_laptop = Fluent("cd_behind_laptop", BoolType())
        self.laptop_fragile = Fluent("laptop_fragile", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.in_trash, self.laptop_moved]
        self.context_fluents = [self.setting_is_bedroom, self.laptop_on_desk, self.cd_behind_laptop, self.laptop_fragile]
        self.safety_fluents = [self.danger]
        self.objects = [self.desk, self.trash_bin, self.cd1, self.cd2, self.laptop]

    def create_base_actions(self):
        navigate_to_desk = InstantaneousAction("navigate_to_desk")
        navigate_to_desk.add_precondition(Not(self.robot_at(self.desk)))
        navigate_to_desk.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_desk.add_effect(self.robot_at(self.desk), True)
        
        navigate_to_trash_bin = InstantaneousAction("navigate_to_trash_bin")
        navigate_to_trash_bin.add_precondition(Not(self.robot_at(self.trash_bin)))
        navigate_to_trash_bin.add_effect(self.robot_at(self.desk), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.trash_bin), True)

        grasp_cd1 = InstantaneousAction("grasp_cd1")
        grasp_cd1.add_precondition(self.robot_at(self.desk))
        grasp_cd1.add_precondition(self.object_at(self.cd1, self.desk))
        grasp_cd1.add_precondition(Not(self.robot_has(self.cd1)))
        grasp_cd1.add_effect(self.object_at(self.cd1, self.desk), False)
        grasp_cd1.add_effect(self.robot_has(self.cd1), True)

        grasp_cd2 = InstantaneousAction("grasp_cd2")
        grasp_cd2.add_precondition(self.robot_at(self.desk))
        grasp_cd2.add_precondition(self.object_at(self.cd2, self.desk))
        grasp_cd2.add_precondition(Not(self.robot_has(self.cd2)))
        grasp_cd2.add_effect(self.object_at(self.cd2, self.desk), False)
        grasp_cd2.add_effect(self.robot_has(self.cd2), True)

        place_cd1_in_trash = InstantaneousAction("place_cd1_in_trash")
        place_cd1_in_trash.add_precondition(self.robot_at(self.trash_bin))
        place_cd1_in_trash.add_precondition(self.robot_has(self.cd1))
        place_cd1_in_trash.add_effect(self.robot_has(self.cd1), False)
        place_cd1_in_trash.add_effect(self.in_trash(self.cd1), True)

        place_cd2_in_trash = InstantaneousAction("place_cd2_in_trash")
        place_cd2_in_trash.add_precondition(self.robot_at(self.trash_bin))
        place_cd2_in_trash.add_precondition(self.robot_has(self.cd2))
        place_cd2_in_trash.add_effect(self.robot_has(self.cd2), False)
        place_cd2_in_trash.add_effect(self.in_trash(self.cd2), True)

        move_laptop_aside = InstantaneousAction("move_laptop_aside")
        move_laptop_aside.add_precondition(self.robot_at(self.desk))
        move_laptop_aside.add_precondition(self.laptop_on_desk)
        move_laptop_aside.add_precondition(Not(self.laptop_moved))
        move_laptop_aside.add_effect(self.laptop_moved, True)

        return navigate_to_desk, navigate_to_trash_bin, grasp_cd1, grasp_cd2, place_cd1_in_trash, place_cd2_in_trash, move_laptop_aside

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grasp_cd1": And([
                self.laptop_on_desk,
                self.cd_behind_laptop,
                Not(self.laptop_moved)
            ]),
            "grasp_cd2": And([
                self.laptop_on_desk,
                self.cd_behind_laptop,
                Not(self.laptop_moved)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.desk), True)
        problem.set_initial_value(self.object_at(self.cd1, self.desk), True)
        problem.set_initial_value(self.object_at(self.cd2, self.desk), True)
        problem.set_initial_value(self.object_at(self.laptop, self.desk), True)
        problem.set_initial_value(self.setting_is_bedroom, True)
        problem.set_initial_value(self.laptop_on_desk, True)
        problem.set_initial_value(self.cd_behind_laptop, True)
        problem.set_initial_value(self.laptop_fragile, True)

    def _set_goals(self, problem):
        problem.add_goal(self.in_trash(self.cd1))
        problem.add_goal(self.in_trash(self.cd2))

if __name__ == "__main__":
    DomainPlanner().run_cli()