(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   laptop - objecttype
 )
 (:init
              (robot_at desk)
              (object_at cd1 desk)
              (object_at cd2 desk)
              (object_at laptop desk)
              (setting_is_bedroom)
              (laptop_on_desk)
              (cd_behind_laptop)
              (laptop_fragile)
 )
 (:goal (and 
           (in_trash cd1)
           (in_trash cd2)
        )
 )
)
