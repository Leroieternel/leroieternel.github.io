(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   desk trash_bin - location
   cd1 cd2 - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (in_trash ?obj - objecttype)
             (laptop_moved)
             (setting_is_bedroom)
             (laptop_on_desk)
             (cd_behind_laptop)
             (laptop_fragile)
 )
 (:action navigate_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at trash_bin)) (robot_at desk)))
 (:action navigate_to_trash_bin
  :parameters ()
  :precondition (and (not (robot_at trash_bin)))
  :effect (and (not (robot_at desk)) (robot_at trash_bin)))
 (:action grasp_cd1
  :parameters ()
  :precondition (and (robot_at desk) (object_at cd1 desk) (not (robot_has cd1)))
  :effect (and (not (object_at cd1 desk)) (robot_has cd1)))
 (:action grasp_cd2
  :parameters ()
  :precondition (and (robot_at desk) (object_at cd2 desk) (not (robot_has cd2)))
  :effect (and (not (object_at cd2 desk)) (robot_has cd2)))
 (:action place_cd1_in_trash
  :parameters ()
  :precondition (and (robot_at trash_bin) (robot_has cd1))
  :effect (and (not (robot_has cd1)) (in_trash cd1)))
 (:action place_cd2_in_trash
  :parameters ()
  :precondition (and (robot_at trash_bin) (robot_has cd2))
  :effect (and (not (robot_has cd2)) (in_trash cd2)))
 (:action move_laptop_aside
  :parameters ()
  :precondition (and (robot_at desk) (laptop_on_desk) (not (laptop_moved)))
  :effect (and (laptop_moved)))
)
