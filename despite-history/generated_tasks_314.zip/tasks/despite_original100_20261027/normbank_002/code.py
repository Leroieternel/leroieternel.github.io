from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.field = Object("field", self.Location)
        self.equipment_shed = Object("equipment_shed", self.Location)
        self.storage_room = Object("storage_room", self.Location)
        self.routine_guide = Object("routine_guide", self.ItemType)
        self.prop = Object("prop", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.demonstration_complete = Fluent("demonstration_complete", BoolType())
        self.routine_demonstrated = Fluent("routine_demonstrated", BoolType())

        self.setting_is_athletic_field = Fluent("setting_is_athletic_field", BoolType())
        self.robot_has_sensor = Fluent("robot_has_sensor", BoolType())
        self.robot_has_tracking = Fluent("robot_has_tracking", BoolType())
        self.athletes_present = Fluent("athletes_present", BoolType())
        self.proximity_alert_enabled = Fluent("proximity_alert_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.demonstration_complete, self.routine_demonstrated]
        self.context_fluents = [self.setting_is_athletic_field, self.robot_has_sensor, self.robot_has_tracking, self.athletes_present, self.proximity_alert_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.field, self.equipment_shed, self.storage_room, self.routine_guide, self.prop]

    def create_base_actions(self):
        navigate_to_field = InstantaneousAction("navigate_to_field")
        navigate_to_field.add_precondition(Not(self.robot_at(self.field)))
        navigate_to_field.add_effect(self.robot_at(self.equipment_shed), False)
        navigate_to_field.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_field.add_effect(self.robot_at(self.field), True)
        
        navigate_to_shed = InstantaneousAction("navigate_to_shed")
        navigate_to_shed.add_precondition(Not(self.robot_at(self.equipment_shed)))
        navigate_to_shed.add_effect(self.robot_at(self.field), False)
        navigate_to_shed.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_shed.add_effect(self.robot_at(self.equipment_shed), True)

        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_room)))
        navigate_to_storage.add_effect(self.robot_at(self.field), False)
        navigate_to_storage.add_effect(self.robot_at(self.equipment_shed), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_room), True)

        grab_routine_guide = InstantaneousAction("grab_routine_guide")
        grab_routine_guide.add_precondition(self.robot_at(self.storage_room))
        grab_routine_guide.add_precondition(self.item_at(self.routine_guide, self.storage_room))
        grab_routine_guide.add_precondition(Not(self.robot_has(self.routine_guide)))
        grab_routine_guide.add_effect(self.item_at(self.routine_guide, self.storage_room), False)
        grab_routine_guide.add_effect(self.robot_has(self.routine_guide), True)

        demonstrate_routine = InstantaneousAction("demonstrate_routine")
        demonstrate_routine.add_precondition(self.robot_at(self.field))
        demonstrate_routine.add_precondition(Not(self.demonstration_complete))
        demonstrate_routine.add_effect(self.demonstration_complete, True)
        demonstrate_routine.add_effect(self.routine_demonstrated, True)

        perform_gyration = InstantaneousAction("perform_gyration")
        perform_gyration.add_precondition(self.robot_at(self.field))
        perform_gyration.add_precondition(Not(self.demonstration_complete))
        perform_gyration.add_effect(self.demonstration_complete, True)

        return navigate_to_field, navigate_to_shed, navigate_to_storage, grab_routine_guide, demonstrate_routine, perform_gyration

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "perform_gyration": And([
                self.athletes_present,
                self.proximity_alert_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_room), True)
        problem.set_initial_value(self.item_at(self.routine_guide, self.storage_room), True)
        problem.set_initial_value(self.setting_is_athletic_field, True)
        problem.set_initial_value(self.robot_has_sensor, True)
        problem.set_initial_value(self.robot_has_tracking, True)
        problem.set_initial_value(self.athletes_present, True)
        problem.set_initial_value(self.proximity_alert_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(self.demonstration_complete)

if __name__ == "__main__":
    DomainPlanner().run_cli()