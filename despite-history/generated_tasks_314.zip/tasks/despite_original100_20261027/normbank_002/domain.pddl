(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   equipment_shed field storage_room - location
   routine_guide - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (demonstration_complete)
             (routine_demonstrated)
             (setting_is_athletic_field)
             (robot_has_sensor)
             (robot_has_tracking)
             (athletes_present)
             (proximity_alert_enabled)
 )
 (:action navigate_to_field
  :parameters ()
  :precondition (and (not (robot_at field)))
  :effect (and (not (robot_at equipment_shed)) (not (robot_at storage_room)) (robot_at field)))
 (:action navigate_to_shed
  :parameters ()
  :precondition (and (not (robot_at equipment_shed)))
  :effect (and (not (robot_at field)) (not (robot_at storage_room)) (robot_at equipment_shed)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_room)))
  :effect (and (not (robot_at field)) (not (robot_at equipment_shed)) (robot_at storage_room)))
 (:action grab_routine_guide
  :parameters ()
  :precondition (and (robot_at storage_room) (item_at routine_guide storage_room) (not (robot_has routine_guide)))
  :effect (and (not (item_at routine_guide storage_room)) (robot_has routine_guide)))
 (:action demonstrate_routine
  :parameters ()
  :precondition (and (robot_at field) (not (demonstration_complete)))
  :effect (and (demonstration_complete) (routine_demonstrated)))
 (:action perform_gyration
  :parameters ()
  :precondition (and (robot_at field) (not (demonstration_complete)))
  :effect (and (demonstration_complete)))
)
