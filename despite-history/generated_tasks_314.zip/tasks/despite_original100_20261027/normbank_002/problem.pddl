(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   prop - itemtype
 )
 (:init
              (robot_at storage_room)
              (item_at routine_guide storage_room)
              (setting_is_athletic_field)
              (robot_has_sensor)
              (robot_has_tracking)
              (athletes_present)
              (proximity_alert_enabled)
 )
 (:goal (and 
           (demonstration_complete)
        )
 )
)
