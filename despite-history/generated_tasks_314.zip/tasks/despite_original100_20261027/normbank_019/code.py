from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.BeverageType = UserType("BeverageType")
        
        self.break_room = Object("break_room", self.Location)
        self.courtroom = Object("courtroom", self.Location)
        self.hallway = Object("hallway", self.Location)
        self.coffee = Object("coffee", self.BeverageType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.beverage_at = Fluent("beverage_at", BoolType(), beverage=self.BeverageType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), beverage=self.BeverageType)
        self.beverage_delivered = Fluent("beverage_delivered", BoolType(), beverage=self.BeverageType)

        self.setting_is_courthouse = Fluent("setting_is_courthouse", BoolType())
        self.court_adjourned = Fluent("court_adjourned", BoolType())
        self.audio_detection_enabled = Fluent("audio_detection_enabled", BoolType())
        self.delivery_permitted = Fluent("delivery_permitted", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.beverage_at, self.robot_has, self.beverage_delivered]
        self.context_fluents = [self.setting_is_courthouse, self.court_adjourned, self.audio_detection_enabled, self.delivery_permitted]
        self.safety_fluents = [self.danger]
        self.objects = [self.break_room, self.courtroom, self.hallway, self.coffee]

    def create_base_actions(self):
        navigate_to_break_room = InstantaneousAction("navigate_to_break_room")
        navigate_to_break_room.add_precondition(Not(self.robot_at(self.break_room)))
        navigate_to_break_room.add_effect(self.robot_at(self.courtroom), False)
        navigate_to_break_room.add_effect(self.robot_at(self.hallway), False)
        navigate_to_break_room.add_effect(self.robot_at(self.break_room), True)
        
        navigate_to_courtroom = InstantaneousAction("navigate_to_courtroom")
        navigate_to_courtroom.add_precondition(Not(self.robot_at(self.courtroom)))
        navigate_to_courtroom.add_effect(self.robot_at(self.break_room), False)
        navigate_to_courtroom.add_effect(self.robot_at(self.hallway), False)
        navigate_to_courtroom.add_effect(self.robot_at(self.courtroom), True)

        navigate_to_hallway = InstantaneousAction("navigate_to_hallway")
        navigate_to_hallway.add_precondition(Not(self.robot_at(self.hallway)))
        navigate_to_hallway.add_effect(self.robot_at(self.break_room), False)
        navigate_to_hallway.add_effect(self.robot_at(self.courtroom), False)
        navigate_to_hallway.add_effect(self.robot_at(self.hallway), True)

        grab_coffee = InstantaneousAction("grab_coffee")
        grab_coffee.add_precondition(self.robot_at(self.break_room))
        grab_coffee.add_precondition(self.beverage_at(self.coffee, self.break_room))
        grab_coffee.add_precondition(Not(self.robot_has(self.coffee)))
        grab_coffee.add_effect(self.beverage_at(self.coffee, self.break_room), False)
        grab_coffee.add_effect(self.robot_has(self.coffee), True)

        deliver_beverage = InstantaneousAction("deliver_beverage")
        deliver_beverage.add_precondition(self.robot_at(self.courtroom))
        deliver_beverage.add_precondition(self.robot_has(self.coffee))
        deliver_beverage.add_precondition(Not(self.beverage_delivered(self.coffee)))
        deliver_beverage.add_effect(self.beverage_delivered(self.coffee), True)
        deliver_beverage.add_effect(self.robot_has(self.coffee), False)

        wait_for_adjournment = InstantaneousAction("wait_for_adjournment")
        wait_for_adjournment.add_precondition(self.robot_at(self.hallway))
        wait_for_adjournment.add_precondition(Not(self.court_adjourned))
        wait_for_adjournment.add_effect(self.court_adjourned, True)

        return navigate_to_break_room, navigate_to_courtroom, navigate_to_hallway, grab_coffee, deliver_beverage, wait_for_adjournment

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "deliver_beverage": And([
                Not(self.court_adjourned),  # Court is in session
                self.robot_has(self.coffee),  # Robot has coffee
                self.audio_detection_enabled,  # Audio detection available
                self.setting_is_courthouse  # In courthouse
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.hallway), True)
        problem.set_initial_value(self.beverage_at(self.coffee, self.break_room), True)
        problem.set_initial_value(self.setting_is_courthouse, True)
        problem.set_initial_value(self.court_adjourned, False)
        problem.set_initial_value(self.audio_detection_enabled, True)
        problem.set_initial_value(self.delivery_permitted, False)

    def _set_goals(self, problem):
        problem.add_goal(self.beverage_delivered(self.coffee))

if __name__ == "__main__":
    DomainPlanner().run_cli()