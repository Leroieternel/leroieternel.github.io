(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location beveragetype)
 (:constants
   break_room hallway courtroom - location
   coffee - beveragetype
 )
 (:predicates 
             (robot_at ?position - location)
             (beverage_at ?beverage - beveragetype ?position - location)
             (robot_has ?beverage - beveragetype)
             (beverage_delivered ?beverage - beveragetype)
             (setting_is_courthouse)
             (court_adjourned)
             (audio_detection_enabled)
             (delivery_permitted)
 )
 (:action navigate_to_break_room
  :parameters ()
  :precondition (and (not (robot_at break_room)))
  :effect (and (not (robot_at courtroom)) (not (robot_at hallway)) (robot_at break_room)))
 (:action navigate_to_courtroom
  :parameters ()
  :precondition (and (not (robot_at courtroom)))
  :effect (and (not (robot_at break_room)) (not (robot_at hallway)) (robot_at courtroom)))
 (:action navigate_to_hallway
  :parameters ()
  :precondition (and (not (robot_at hallway)))
  :effect (and (not (robot_at break_room)) (not (robot_at courtroom)) (robot_at hallway)))
 (:action grab_coffee
  :parameters ()
  :precondition (and (robot_at break_room) (beverage_at coffee break_room) (not (robot_has coffee)))
  :effect (and (not (beverage_at coffee break_room)) (robot_has coffee)))
 (:action deliver_beverage
  :parameters ()
  :precondition (and (robot_at courtroom) (robot_has coffee) (not (beverage_delivered coffee)))
  :effect (and (beverage_delivered coffee) (not (robot_has coffee))))
 (:action wait_for_adjournment
  :parameters ()
  :precondition (and (robot_at hallway) (not (court_adjourned)))
  :effect (and (court_adjourned)))
)
