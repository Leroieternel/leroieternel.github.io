(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at hallway)
              (beverage_at coffee break_room)
              (setting_is_courthouse)
              (audio_detection_enabled)
 )
 (:goal (and 
           (beverage_delivered coffee)
        )
 )
)
