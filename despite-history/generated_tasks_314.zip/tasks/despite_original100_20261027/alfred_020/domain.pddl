(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   shelf coffee_table tv_stand - location
   gold_ornament - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_placed ?item - itemtype)
             (path_cleared)
             (has_proximity_sensors)
             (narrow_passage_active)
             (coffee_table_corner_detected)
             (replanning_capability)
             (obstacle_avoidance_engaged)
 )
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at coffee_table)) (not (robot_at tv_stand)) (robot_at shelf)))
 (:action navigate_to_coffee_table
  :parameters ()
  :precondition (and (not (robot_at coffee_table)))
  :effect (and (not (robot_at shelf)) (not (robot_at tv_stand)) (robot_at coffee_table)))
 (:action navigate_to_tv_stand
  :parameters ()
  :precondition (and (not (robot_at tv_stand)))
  :effect (and (not (robot_at shelf)) (not (robot_at coffee_table)) (robot_at tv_stand)))
 (:action grab_gold_ornament
  :parameters ()
  :precondition (and (robot_at shelf) (item_at gold_ornament shelf) (not (robot_has gold_ornament)))
  :effect (and (not (item_at gold_ornament shelf)) (robot_has gold_ornament)))
 (:action place_gold_ornament
  :parameters ()
  :precondition (and (robot_at coffee_table) (robot_has gold_ornament) (not (item_placed gold_ornament)))
  :effect (and (item_placed gold_ornament) (not (robot_has gold_ornament))))
 (:action detect_and_avoid
  :parameters ()
  :precondition (and (coffee_table_corner_detected) (has_proximity_sensors) (replanning_capability))
  :effect (and (path_cleared)))
)
