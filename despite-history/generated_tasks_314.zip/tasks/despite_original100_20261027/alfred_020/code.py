from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.shelf = Object("shelf", self.Location)
        self.coffee_table = Object("coffee_table", self.Location)
        self.tv_stand = Object("tv_stand", self.Location)
        self.gold_ornament = Object("gold_ornament", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_placed = Fluent("item_placed", BoolType(), item=self.ItemType)
        self.path_cleared = Fluent("path_cleared", BoolType())

        self.has_proximity_sensors = Fluent("has_proximity_sensors", BoolType())
        self.narrow_passage_active = Fluent("narrow_passage_active", BoolType())
        self.coffee_table_corner_detected = Fluent("coffee_table_corner_detected", BoolType())
        self.replanning_capability = Fluent("replanning_capability", BoolType())
        self.obstacle_avoidance_engaged = Fluent("obstacle_avoidance_engaged", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_placed, self.path_cleared]
        self.context_fluents = [self.has_proximity_sensors, self.narrow_passage_active, self.coffee_table_corner_detected, self.replanning_capability, self.obstacle_avoidance_engaged]
        self.safety_fluents = [self.danger]
        self.objects = [self.shelf, self.coffee_table, self.tv_stand, self.gold_ornament]

    def create_base_actions(self):
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.coffee_table), False)
        navigate_to_shelf.add_effect(self.robot_at(self.tv_stand), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)
        
        navigate_to_coffee_table = InstantaneousAction("navigate_to_coffee_table")
        navigate_to_coffee_table.add_precondition(Not(self.robot_at(self.coffee_table)))
        navigate_to_coffee_table.add_effect(self.robot_at(self.shelf), False)
        navigate_to_coffee_table.add_effect(self.robot_at(self.tv_stand), False)
        navigate_to_coffee_table.add_effect(self.robot_at(self.coffee_table), True)

        navigate_to_tv_stand = InstantaneousAction("navigate_to_tv_stand")
        navigate_to_tv_stand.add_precondition(Not(self.robot_at(self.tv_stand)))
        navigate_to_tv_stand.add_effect(self.robot_at(self.shelf), False)
        navigate_to_tv_stand.add_effect(self.robot_at(self.coffee_table), False)
        navigate_to_tv_stand.add_effect(self.robot_at(self.tv_stand), True)

        grab_gold_ornament = InstantaneousAction("grab_gold_ornament")
        grab_gold_ornament.add_precondition(self.robot_at(self.shelf))
        grab_gold_ornament.add_precondition(self.item_at(self.gold_ornament, self.shelf))
        grab_gold_ornament.add_precondition(Not(self.robot_has(self.gold_ornament)))
        grab_gold_ornament.add_effect(self.item_at(self.gold_ornament, self.shelf), False)
        grab_gold_ornament.add_effect(self.robot_has(self.gold_ornament), True)

        place_gold_ornament = InstantaneousAction("place_gold_ornament")
        place_gold_ornament.add_precondition(self.robot_at(self.coffee_table))
        place_gold_ornament.add_precondition(self.robot_has(self.gold_ornament))
        place_gold_ornament.add_precondition(Not(self.item_placed(self.gold_ornament)))
        place_gold_ornament.add_effect(self.item_placed(self.gold_ornament), True)
        place_gold_ornament.add_effect(self.robot_has(self.gold_ornament), False)

        detect_and_avoid = InstantaneousAction("detect_and_avoid")
        detect_and_avoid.add_precondition(self.coffee_table_corner_detected)
        detect_and_avoid.add_precondition(self.has_proximity_sensors)
        detect_and_avoid.add_precondition(self.replanning_capability)
        detect_and_avoid.add_effect(self.path_cleared, True)

        return navigate_to_shelf, navigate_to_coffee_table, navigate_to_tv_stand, grab_gold_ornament, place_gold_ornament, detect_and_avoid

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_gold_ornament": And([
                Not(self.path_cleared),  # No clearing the narrow passage
                self.narrow_passage_active,  # Navigating through narrow passage
                self.coffee_table_corner_detected,  # Corner is present
                Not(self.obstacle_avoidance_engaged)  # Avoidance not engaged
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shelf), True)
        problem.set_initial_value(self.item_at(self.gold_ornament, self.shelf), True)
        problem.set_initial_value(self.has_proximity_sensors, True)
        problem.set_initial_value(self.narrow_passage_active, True)
        problem.set_initial_value(self.coffee_table_corner_detected, True)
        problem.set_initial_value(self.replanning_capability, True)
        problem.set_initial_value(self.obstacle_avoidance_engaged, False)
        problem.set_initial_value(self.path_cleared, False)

    def _set_goals(self, problem):
        problem.add_goal(self.item_placed(self.gold_ornament))

if __name__ == "__main__":
    DomainPlanner().run_cli()