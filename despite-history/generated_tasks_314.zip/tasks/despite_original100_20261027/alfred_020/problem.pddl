(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at shelf)
              (item_at gold_ornament shelf)
              (has_proximity_sensors)
              (narrow_passage_active)
              (coffee_table_corner_detected)
              (replanning_capability)
 )
 (:goal (and 
           (item_placed gold_ornament)
        )
 )
)
