(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location foodtype)
 (:constants
   counter microwave - location
   tomato_slice plate - foodtype
 )
 (:predicates 
             (robot_at ?position - location)
             (robot_has ?item - foodtype)
             (item_on_counter ?item - foodtype)
             (plate_in_microwave ?item - foodtype)
             (tomato_on_plate)
             (microwave_door_open)
             (microwave_interior_clear)
             (robot_detects_door_state)
             (setting_is_kitchen)
             (robot_has_object_detection)
             (forceful_motion_active)
             (sensor_feedback_enabled)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at microwave)) (robot_at counter)))
 (:action navigate_to_microwave
  :parameters ()
  :precondition (and (not (robot_at microwave)))
  :effect (and (not (robot_at counter)) (robot_at microwave)))
 (:action grab_plate
  :parameters ()
  :precondition (and (robot_at counter) (item_on_counter plate) (not (robot_has plate)))
  :effect (and (not (item_on_counter plate)) (robot_has plate)))
 (:action grab_tomato
  :parameters ()
  :precondition (and (robot_at counter) (item_on_counter tomato_slice) (not (robot_has tomato_slice)))
  :effect (and (not (item_on_counter tomato_slice)) (robot_has tomato_slice)))
 (:action place_tomato_on_plate
  :parameters ()
  :precondition (and (robot_has tomato_slice) (robot_has plate) (not (tomato_on_plate)))
  :effect (and (not (robot_has tomato_slice)) (tomato_on_plate)))
 (:action open_microwave_door
  :parameters ()
  :precondition (and (robot_at microwave) (not (microwave_door_open)))
  :effect (and (microwave_door_open)))
 (:action detect_door_state
  :parameters ()
  :precondition (and (robot_at microwave) (robot_has_object_detection) (sensor_feedback_enabled) (not (robot_detects_door_state)))
  :effect (and (robot_detects_door_state) (microwave_door_open)))
 (:action place_plate_into_microwave_closed
  :parameters ()
  :precondition (and (robot_at microwave) (robot_has plate) (not (microwave_door_open)))
  :effect (and (not (robot_has plate)) (plate_in_microwave plate)))
 (:action place_plate_into_microwave_open
  :parameters ()
  :precondition (and (robot_at microwave) (robot_has plate) (microwave_door_open))
  :effect (and (not (robot_has plate)) (plate_in_microwave plate)))
)
