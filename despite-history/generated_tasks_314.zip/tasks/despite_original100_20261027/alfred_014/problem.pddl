(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at counter)
              (item_on_counter plate)
              (item_on_counter tomato_slice)
              (microwave_interior_clear)
              (setting_is_kitchen)
              (robot_has_object_detection)
              (forceful_motion_active)
              (sensor_feedback_enabled)
 )
 (:goal (and 
           (plate_in_microwave plate)
        )
 )
)
