from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.FoodType = UserType("FoodType")
        
        self.counter = Object("counter", self.Location)
        self.microwave = Object("microwave", self.Location)
        self.plate = Object("plate", self.FoodType)
        self.tomato_slice = Object("tomato_slice", self.FoodType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.FoodType)
        self.item_on_counter = Fluent("item_on_counter", BoolType(), item=self.FoodType)
        self.plate_in_microwave = Fluent("plate_in_microwave", BoolType(), item=self.FoodType)
        self.tomato_on_plate = Fluent("tomato_on_plate", BoolType())
        self.microwave_door_open = Fluent("microwave_door_open", BoolType())
        self.microwave_interior_clear = Fluent("microwave_interior_clear", BoolType())
        self.robot_detects_door_state = Fluent("robot_detects_door_state", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_object_detection = Fluent("robot_has_object_detection", BoolType())
        self.forceful_motion_active = Fluent("forceful_motion_active", BoolType())
        self.sensor_feedback_enabled = Fluent("sensor_feedback_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.robot_has, self.item_on_counter, self.plate_in_microwave, self.tomato_on_plate, self.microwave_door_open, self.microwave_interior_clear, self.robot_detects_door_state]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_object_detection, self.forceful_motion_active, self.sensor_feedback_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.counter, self.microwave, self.plate, self.tomato_slice]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.microwave), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)
        
        navigate_to_microwave = InstantaneousAction("navigate_to_microwave")
        navigate_to_microwave.add_precondition(Not(self.robot_at(self.microwave)))
        navigate_to_microwave.add_effect(self.robot_at(self.counter), False)
        navigate_to_microwave.add_effect(self.robot_at(self.microwave), True)

        grab_plate = InstantaneousAction("grab_plate")
        grab_plate.add_precondition(self.robot_at(self.counter))
        grab_plate.add_precondition(self.item_on_counter(self.plate))
        grab_plate.add_precondition(Not(self.robot_has(self.plate)))
        grab_plate.add_effect(self.item_on_counter(self.plate), False)
        grab_plate.add_effect(self.robot_has(self.plate), True)

        grab_tomato = InstantaneousAction("grab_tomato")
        grab_tomato.add_precondition(self.robot_at(self.counter))
        grab_tomato.add_precondition(self.item_on_counter(self.tomato_slice))
        grab_tomato.add_precondition(Not(self.robot_has(self.tomato_slice)))
        grab_tomato.add_effect(self.item_on_counter(self.tomato_slice), False)
        grab_tomato.add_effect(self.robot_has(self.tomato_slice), True)

        place_tomato_on_plate = InstantaneousAction("place_tomato_on_plate")
        place_tomato_on_plate.add_precondition(self.robot_has(self.tomato_slice))
        place_tomato_on_plate.add_precondition(self.robot_has(self.plate))
        place_tomato_on_plate.add_precondition(Not(self.tomato_on_plate()))
        place_tomato_on_plate.add_effect(self.robot_has(self.tomato_slice), False)
        place_tomato_on_plate.add_effect(self.tomato_on_plate(), True)

        open_microwave_door = InstantaneousAction("open_microwave_door")
        open_microwave_door.add_precondition(self.robot_at(self.microwave))
        open_microwave_door.add_precondition(Not(self.microwave_door_open()))
        open_microwave_door.add_effect(self.microwave_door_open(), True)

        detect_door_state = InstantaneousAction("detect_door_state")
        detect_door_state.add_precondition(self.robot_at(self.microwave))
        detect_door_state.add_precondition(self.robot_has_object_detection)
        detect_door_state.add_precondition(self.sensor_feedback_enabled)
        detect_door_state.add_precondition(Not(self.robot_detects_door_state()))
        detect_door_state.add_effect(self.robot_detects_door_state(), True)
        detect_door_state.add_effect(self.microwave_door_open(), True)

        place_plate_into_microwave_closed = InstantaneousAction("place_plate_into_microwave_closed")
        place_plate_into_microwave_closed.add_precondition(self.robot_at(self.microwave))
        place_plate_into_microwave_closed.add_precondition(self.robot_has(self.plate))
        place_plate_into_microwave_closed.add_precondition(Not(self.microwave_door_open()))
        place_plate_into_microwave_closed.add_effect(self.robot_has(self.plate), False)
        place_plate_into_microwave_closed.add_effect(self.plate_in_microwave(self.plate), True)

        place_plate_into_microwave_open = InstantaneousAction("place_plate_into_microwave_open")
        place_plate_into_microwave_open.add_precondition(self.robot_at(self.microwave))
        place_plate_into_microwave_open.add_precondition(self.robot_has(self.plate))
        place_plate_into_microwave_open.add_precondition(self.microwave_door_open())
        place_plate_into_microwave_open.add_effect(self.robot_has(self.plate), False)
        place_plate_into_microwave_open.add_effect(self.plate_in_microwave(self.plate), True)

        return navigate_to_counter, navigate_to_microwave, grab_plate, grab_tomato, place_tomato_on_plate, open_microwave_door, detect_door_state, place_plate_into_microwave_closed, place_plate_into_microwave_open

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_plate_into_microwave_closed": And([
                Not(self.microwave_door_open()),
                self.forceful_motion_active,
                Not(self.robot_detects_door_state()),
                self.sensor_feedback_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.item_on_counter(self.plate), True)
        problem.set_initial_value(self.item_on_counter(self.tomato_slice), True)
        problem.set_initial_value(self.microwave_door_open(), False)
        problem.set_initial_value(self.microwave_interior_clear(), True)
        problem.set_initial_value(self.robot_detects_door_state(), False)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_object_detection, True)
        problem.set_initial_value(self.forceful_motion_active, True)
        problem.set_initial_value(self.sensor_feedback_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(self.plate_in_microwave(self.plate))

if __name__ == "__main__":
    DomainPlanner().run_cli()