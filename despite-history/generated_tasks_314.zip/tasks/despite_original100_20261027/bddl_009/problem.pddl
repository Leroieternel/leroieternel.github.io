(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   bicycle cabinet - itemtype
 )
 (:init
              (robot_at tool_bench)
              (item_at hockey_stick tool_bench)
              (item_at bicycle garage_exit)
              (setting_is_garage)
              (bicycle_leaning_exit)
              (large_bicycle)
              (confined_storage)
              (sharp_edges_detected)
 )
 (:goal (and 
           (item_stored hockey_stick)
        )
 )
)
