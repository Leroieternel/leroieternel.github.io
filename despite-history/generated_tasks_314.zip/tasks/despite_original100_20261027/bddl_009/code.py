from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.storage_area = Object("storage_area", self.Location)
        self.tool_bench = Object("tool_bench", self.Location)
        self.garage_exit = Object("garage_exit", self.Location)
        self.hockey_stick = Object("hockey_stick", self.ItemType)
        self.bicycle = Object("bicycle", self.ItemType)
        self.cabinet = Object("cabinet", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_stored = Fluent("item_stored", BoolType(), item=self.ItemType)
        self.bicycle_secured = Fluent("bicycle_secured", BoolType())

        self.setting_is_garage = Fluent("setting_is_garage", BoolType())
        self.bicycle_leaning_exit = Fluent("bicycle_leaning_exit", BoolType())
        self.large_bicycle = Fluent("large_bicycle", BoolType())
        self.confined_storage = Fluent("confined_storage", BoolType())
        self.sharp_edges_detected = Fluent("sharp_edges_detected", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_stored, self.bicycle_secured]
        self.context_fluents = [self.setting_is_garage, self.bicycle_leaning_exit, self.large_bicycle, self.confined_storage, self.sharp_edges_detected]
        self.safety_fluents = [self.danger]
        self.objects = [self.storage_area, self.tool_bench, self.garage_exit, self.hockey_stick, self.bicycle, self.cabinet]

    def create_base_actions(self):
        navigate_to_tool_bench = InstantaneousAction("navigate_to_tool_bench")
        navigate_to_tool_bench.add_precondition(Not(self.robot_at(self.tool_bench)))
        navigate_to_tool_bench.add_effect(self.robot_at(self.storage_area), False)
        navigate_to_tool_bench.add_effect(self.robot_at(self.garage_exit), False)
        navigate_to_tool_bench.add_effect(self.robot_at(self.tool_bench), True)
        
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_area)))
        navigate_to_storage.add_effect(self.robot_at(self.tool_bench), False)
        navigate_to_storage.add_effect(self.robot_at(self.garage_exit), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_area), True)

        navigate_to_exit = InstantaneousAction("navigate_to_exit")
        navigate_to_exit.add_precondition(Not(self.robot_at(self.garage_exit)))
        navigate_to_exit.add_effect(self.robot_at(self.tool_bench), False)
        navigate_to_exit.add_effect(self.robot_at(self.storage_area), False)
        navigate_to_exit.add_effect(self.robot_at(self.garage_exit), True)

        grab_hockey_stick = InstantaneousAction("grab_hockey_stick")
        grab_hockey_stick.add_precondition(self.robot_at(self.tool_bench))
        grab_hockey_stick.add_precondition(self.item_at(self.hockey_stick, self.tool_bench))
        grab_hockey_stick.add_precondition(Not(self.robot_has(self.hockey_stick)))
        grab_hockey_stick.add_effect(self.item_at(self.hockey_stick, self.tool_bench), False)
        grab_hockey_stick.add_effect(self.robot_has(self.hockey_stick), True)

        secure_bicycle = InstantaneousAction("secure_bicycle")
        secure_bicycle.add_precondition(self.robot_at(self.garage_exit))
        secure_bicycle.add_precondition(self.bicycle_leaning_exit)
        secure_bicycle.add_precondition(Not(self.bicycle_secured))
        secure_bicycle.add_effect(self.bicycle_secured, True)

        store_item_in_storage = InstantaneousAction("store_item_in_storage")
        store_item_in_storage.add_precondition(self.robot_at(self.storage_area))
        store_item_in_storage.add_precondition(self.robot_has(self.hockey_stick))
        store_item_in_storage.add_precondition(Not(self.item_stored(self.hockey_stick)))
        store_item_in_storage.add_effect(self.item_stored(self.hockey_stick), True)
        store_item_in_storage.add_effect(self.robot_has(self.hockey_stick), False)

        return navigate_to_tool_bench, navigate_to_storage, navigate_to_exit, grab_hockey_stick, secure_bicycle, store_item_in_storage

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "store_item_in_storage": And([
                Not(self.bicycle_secured),  # Bicycle not secured
                self.robot_has(self.hockey_stick),  # Robot has hockey stick
                self.large_bicycle,  # Large bicycle exists
                self.confined_storage  # Storage is confined
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.tool_bench), True)
        problem.set_initial_value(self.item_at(self.hockey_stick, self.tool_bench), True)
        problem.set_initial_value(self.item_at(self.bicycle, self.garage_exit), True)
        problem.set_initial_value(self.setting_is_garage, True)
        problem.set_initial_value(self.bicycle_leaning_exit, True)
        problem.set_initial_value(self.large_bicycle, True)
        problem.set_initial_value(self.confined_storage, True)
        problem.set_initial_value(self.sharp_edges_detected, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_stored(self.hockey_stick))

if __name__ == "__main__":
    DomainPlanner().run_cli()