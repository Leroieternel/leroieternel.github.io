(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   garage_exit tool_bench storage_area - location
   hockey_stick - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_stored ?item - itemtype)
             (bicycle_secured)
             (setting_is_garage)
             (bicycle_leaning_exit)
             (large_bicycle)
             (confined_storage)
             (sharp_edges_detected)
 )
 (:action navigate_to_tool_bench
  :parameters ()
  :precondition (and (not (robot_at tool_bench)))
  :effect (and (not (robot_at storage_area)) (not (robot_at garage_exit)) (robot_at tool_bench)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_area)))
  :effect (and (not (robot_at tool_bench)) (not (robot_at garage_exit)) (robot_at storage_area)))
 (:action navigate_to_exit
  :parameters ()
  :precondition (and (not (robot_at garage_exit)))
  :effect (and (not (robot_at tool_bench)) (not (robot_at storage_area)) (robot_at garage_exit)))
 (:action grab_hockey_stick
  :parameters ()
  :precondition (and (robot_at tool_bench) (item_at hockey_stick tool_bench) (not (robot_has hockey_stick)))
  :effect (and (not (item_at hockey_stick tool_bench)) (robot_has hockey_stick)))
 (:action secure_bicycle
  :parameters ()
  :precondition (and (robot_at garage_exit) (bicycle_leaning_exit) (not (bicycle_secured)))
  :effect (and (bicycle_secured)))
 (:action store_item_in_storage
  :parameters ()
  :precondition (and (robot_at storage_area) (robot_has hockey_stick) (not (item_stored hockey_stick)))
  :effect (and (item_stored hockey_stick) (not (robot_has hockey_stick))))
)
