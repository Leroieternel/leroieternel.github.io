(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   counter refrigerator pantry - location
   bowl_ice lime_juice sugar pitcher water ice_cubes - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (ingredient_in_pitcher ?ingredient - itemtype)
             (pitcher_ready)
             (setting_is_kitchen)
             (floor_surface_smooth)
             (humans_present)
             (container_stable)
             (large_container_on_counter)
 )
 (:action navigate_to_pantry
  :parameters ()
  :precondition (and (not (robot_at pantry)))
  :effect (and (not (robot_at counter)) (not (robot_at refrigerator)) (robot_at pantry)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at pantry)) (not (robot_at refrigerator)) (robot_at counter)))
 (:action navigate_to_refrigerator
  :parameters ()
  :precondition (and (not (robot_at refrigerator)))
  :effect (and (not (robot_at pantry)) (not (robot_at counter)) (robot_at refrigerator)))
 (:action grab_water
  :parameters ()
  :precondition (and (robot_at pantry) (item_at water pantry) (not (robot_has water)))
  :effect (and (not (item_at water pantry)) (robot_has water)))
 (:action grab_sugar
  :parameters ()
  :precondition (and (robot_at pantry) (item_at sugar pantry) (not (robot_has sugar)))
  :effect (and (not (item_at sugar pantry)) (robot_has sugar)))
 (:action grab_lime_juice
  :parameters ()
  :precondition (and (robot_at pantry) (item_at lime_juice pantry) (not (robot_has lime_juice)))
  :effect (and (not (item_at lime_juice pantry)) (robot_has lime_juice)))
 (:action grab_pitcher
  :parameters ()
  :precondition (and (robot_at pantry) (item_at pitcher pantry) (not (robot_has pitcher)))
  :effect (and (not (item_at pitcher pantry)) (robot_has pitcher)))
 (:action grab_bowl_ice
  :parameters ()
  :precondition (and (robot_at refrigerator) (item_at bowl_ice refrigerator) (not (robot_has bowl_ice)))
  :effect (and (not (item_at bowl_ice refrigerator)) (robot_has bowl_ice)))
 (:action pour_into_pitcher
  :parameters ()
  :precondition (and (robot_at counter) (robot_has water) (not (ingredient_in_pitcher water)))
  :effect (and (ingredient_in_pitcher water) (not (robot_has water))))
 (:action pour_sugar_into_pitcher
  :parameters ()
  :precondition (and (robot_at counter) (robot_has sugar) (not (ingredient_in_pitcher sugar)))
  :effect (and (ingredient_in_pitcher sugar) (not (robot_has sugar))))
 (:action pour_lime_juice_into_pitcher
  :parameters ()
  :precondition (and (robot_at counter) (robot_has lime_juice) (not (ingredient_in_pitcher lime_juice)))
  :effect (and (ingredient_in_pitcher lime_juice) (not (robot_has lime_juice))))
 (:action transfer_ice_into_pitcher
  :parameters ()
  :precondition (and (robot_at counter) (robot_has bowl_ice) (not (ingredient_in_pitcher ice_cubes)))
  :effect (and (ingredient_in_pitcher ice_cubes) (not (robot_has bowl_ice))))
 (:action place_large_container
  :parameters ()
  :precondition (and (robot_at counter) (not (large_container_on_counter)))
  :effect (and (large_container_on_counter)))
)
