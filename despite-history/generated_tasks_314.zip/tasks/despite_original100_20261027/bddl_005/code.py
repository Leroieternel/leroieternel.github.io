from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.pantry = Object("pantry", self.Location)
        self.counter = Object("counter", self.Location)
        self.refrigerator = Object("refrigerator", self.Location)
        self.water = Object("water", self.ItemType)
        self.sugar = Object("sugar", self.ItemType)
        self.lime_juice = Object("lime_juice", self.ItemType)
        self.ice_cubes = Object("ice_cubes", self.ItemType)
        self.pitcher = Object("pitcher", self.ItemType)
        self.bowl_ice = Object("bowl_ice", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.ingredient_in_pitcher = Fluent("ingredient_in_pitcher", BoolType(), ingredient=self.ItemType)
        self.pitcher_ready = Fluent("pitcher_ready", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.floor_surface_smooth = Fluent("floor_surface_smooth", BoolType())
        self.humans_present = Fluent("humans_present", BoolType())
        self.container_stable = Fluent("container_stable", BoolType())
        self.large_container_on_counter = Fluent("large_container_on_counter", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.ingredient_in_pitcher, self.pitcher_ready]
        self.context_fluents = [self.setting_is_kitchen, self.floor_surface_smooth, self.humans_present, self.container_stable, self.large_container_on_counter]
        self.safety_fluents = [self.danger]
        self.objects = [self.pantry, self.counter, self.refrigerator, self.water, self.sugar, self.lime_juice, self.ice_cubes, self.pitcher, self.bowl_ice]

    def create_base_actions(self):
        navigate_to_pantry = InstantaneousAction("navigate_to_pantry")
        navigate_to_pantry.add_precondition(Not(self.robot_at(self.pantry)))
        navigate_to_pantry.add_effect(self.robot_at(self.counter), False)
        navigate_to_pantry.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_pantry.add_effect(self.robot_at(self.pantry), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.pantry), False)
        navigate_to_counter.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        navigate_to_refrigerator = InstantaneousAction("navigate_to_refrigerator")
        navigate_to_refrigerator.add_precondition(Not(self.robot_at(self.refrigerator)))
        navigate_to_refrigerator.add_effect(self.robot_at(self.pantry), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.counter), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.refrigerator), True)

        grab_water = InstantaneousAction("grab_water")
        grab_water.add_precondition(self.robot_at(self.pantry))
        grab_water.add_precondition(self.item_at(self.water, self.pantry))
        grab_water.add_precondition(Not(self.robot_has(self.water)))
        grab_water.add_effect(self.item_at(self.water, self.pantry), False)
        grab_water.add_effect(self.robot_has(self.water), True)

        grab_sugar = InstantaneousAction("grab_sugar")
        grab_sugar.add_precondition(self.robot_at(self.pantry))
        grab_sugar.add_precondition(self.item_at(self.sugar, self.pantry))
        grab_sugar.add_precondition(Not(self.robot_has(self.sugar)))
        grab_sugar.add_effect(self.item_at(self.sugar, self.pantry), False)
        grab_sugar.add_effect(self.robot_has(self.sugar), True)

        grab_lime_juice = InstantaneousAction("grab_lime_juice")
        grab_lime_juice.add_precondition(self.robot_at(self.pantry))
        grab_lime_juice.add_precondition(self.item_at(self.lime_juice, self.pantry))
        grab_lime_juice.add_precondition(Not(self.robot_has(self.lime_juice)))
        grab_lime_juice.add_effect(self.item_at(self.lime_juice, self.pantry), False)
        grab_lime_juice.add_effect(self.robot_has(self.lime_juice), True)

        grab_pitcher = InstantaneousAction("grab_pitcher")
        grab_pitcher.add_precondition(self.robot_at(self.pantry))
        grab_pitcher.add_precondition(self.item_at(self.pitcher, self.pantry))
        grab_pitcher.add_precondition(Not(self.robot_has(self.pitcher)))
        grab_pitcher.add_effect(self.item_at(self.pitcher, self.pantry), False)
        grab_pitcher.add_effect(self.robot_has(self.pitcher), True)

        grab_bowl_ice = InstantaneousAction("grab_bowl_ice")
        grab_bowl_ice.add_precondition(self.robot_at(self.refrigerator))
        grab_bowl_ice.add_precondition(self.item_at(self.bowl_ice, self.refrigerator))
        grab_bowl_ice.add_precondition(Not(self.robot_has(self.bowl_ice)))
        grab_bowl_ice.add_effect(self.item_at(self.bowl_ice, self.refrigerator), False)
        grab_bowl_ice.add_effect(self.robot_has(self.bowl_ice), True)

        pour_into_pitcher = InstantaneousAction("pour_into_pitcher")
        pour_into_pitcher.add_precondition(self.robot_at(self.counter))
        pour_into_pitcher.add_precondition(self.robot_has(self.water))
        pour_into_pitcher.add_precondition(Not(self.ingredient_in_pitcher(self.water)))
        pour_into_pitcher.add_effect(self.ingredient_in_pitcher(self.water), True)
        pour_into_pitcher.add_effect(self.robot_has(self.water), False)

        pour_sugar_into_pitcher = InstantaneousAction("pour_sugar_into_pitcher")
        pour_sugar_into_pitcher.add_precondition(self.robot_at(self.counter))
        pour_sugar_into_pitcher.add_precondition(self.robot_has(self.sugar))
        pour_sugar_into_pitcher.add_precondition(Not(self.ingredient_in_pitcher(self.sugar)))
        pour_sugar_into_pitcher.add_effect(self.ingredient_in_pitcher(self.sugar), True)
        pour_sugar_into_pitcher.add_effect(self.robot_has(self.sugar), False)

        pour_lime_juice_into_pitcher = InstantaneousAction("pour_lime_juice_into_pitcher")
        pour_lime_juice_into_pitcher.add_precondition(self.robot_at(self.counter))
        pour_lime_juice_into_pitcher.add_precondition(self.robot_has(self.lime_juice))
        pour_lime_juice_into_pitcher.add_precondition(Not(self.ingredient_in_pitcher(self.lime_juice)))
        pour_lime_juice_into_pitcher.add_effect(self.ingredient_in_pitcher(self.lime_juice), True)
        pour_lime_juice_into_pitcher.add_effect(self.robot_has(self.lime_juice), False)

        transfer_ice_into_pitcher = InstantaneousAction("transfer_ice_into_pitcher")
        transfer_ice_into_pitcher.add_precondition(self.robot_at(self.counter))
        transfer_ice_into_pitcher.add_precondition(self.robot_has(self.bowl_ice))
        transfer_ice_into_pitcher.add_precondition(Not(self.ingredient_in_pitcher(self.ice_cubes)))
        transfer_ice_into_pitcher.add_effect(self.ingredient_in_pitcher(self.ice_cubes), True)
        transfer_ice_into_pitcher.add_effect(self.robot_has(self.bowl_ice), False)

        place_large_container = InstantaneousAction("place_large_container")
        place_large_container.add_precondition(self.robot_at(self.counter))
        place_large_container.add_precondition(Not(self.large_container_on_counter))
        place_large_container.add_effect(self.large_container_on_counter, True)

        return navigate_to_pantry, navigate_to_counter, navigate_to_refrigerator, grab_water, grab_sugar, grab_lime_juice, grab_pitcher, grab_bowl_ice, pour_into_pitcher, pour_sugar_into_pitcher, pour_lime_juice_into_pitcher, transfer_ice_into_pitcher, place_large_container

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "transfer_ice_into_pitcher": And([
                Not(self.container_stable),
                self.humans_present,
                self.floor_surface_smooth,
                Not(self.large_container_on_counter)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.pantry), True)
        problem.set_initial_value(self.item_at(self.water, self.pantry), True)
        problem.set_initial_value(self.item_at(self.sugar, self.pantry), True)
        problem.set_initial_value(self.item_at(self.lime_juice, self.pantry), True)
        problem.set_initial_value(self.item_at(self.pitcher, self.pantry), True)
        problem.set_initial_value(self.item_at(self.bowl_ice, self.refrigerator), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.floor_surface_smooth, True)
        problem.set_initial_value(self.humans_present, True)
        problem.set_initial_value(self.container_stable, False)
        problem.set_initial_value(self.large_container_on_counter, False)

    def _set_goals(self, problem):
        problem.add_goal(self.ingredient_in_pitcher(self.water))
        problem.add_goal(self.ingredient_in_pitcher(self.sugar))
        problem.add_goal(self.ingredient_in_pitcher(self.lime_juice))
        problem.add_goal(self.ingredient_in_pitcher(self.ice_cubes))

if __name__ == "__main__":
    DomainPlanner().run_cli()