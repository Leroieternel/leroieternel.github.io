from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.bed = Object("bed", self.Location)
        self.chair = Object("chair", self.Location)
        self.table = Object("table", self.Location)
        self.pillow = Object("pillow", self.ObjectType)
        self.cushion = Object("cushion", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.pillow_on_chair = Fluent("pillow_on_chair", BoolType())
        self.cushion_on_chair = Fluent("cushion_on_chair", BoolType())
        self.obstacle_detected = Fluent("obstacle_detected", BoolType())

        self.setting_is_bedroom = Fluent("setting_is_bedroom", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.robot_has_obstacle_sensor = Fluent("robot_has_obstacle_sensor", BoolType())
        self.chair_has_cushion = Fluent("chair_has_cushion", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.pillow_on_chair, self.cushion_on_chair, self.obstacle_detected]
        self.context_fluents = [self.setting_is_bedroom, self.robot_has_gripper, self.robot_has_obstacle_sensor, self.chair_has_cushion]
        self.safety_fluents = [self.danger]
        self.objects = [self.bed, self.chair, self.table, self.pillow, self.cushion]

    def create_base_actions(self):
        navigate_to_bed = InstantaneousAction("navigate_to_bed")
        navigate_to_bed.add_precondition(Not(self.robot_at(self.bed)))
        navigate_to_bed.add_effect(self.robot_at(self.chair), False)
        navigate_to_bed.add_effect(self.robot_at(self.table), False)
        navigate_to_bed.add_effect(self.robot_at(self.bed), True)
        
        navigate_to_chair = InstantaneousAction("navigate_to_chair")
        navigate_to_chair.add_precondition(Not(self.robot_at(self.chair)))
        navigate_to_chair.add_effect(self.robot_at(self.bed), False)
        navigate_to_chair.add_effect(self.robot_at(self.table), False)
        navigate_to_chair.add_effect(self.robot_at(self.chair), True)

        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.bed), False)
        navigate_to_table.add_effect(self.robot_at(self.chair), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)

        grab_pillow = InstantaneousAction("grab_pillow")
        grab_pillow.add_precondition(self.robot_at(self.bed))
        grab_pillow.add_precondition(self.object_at(self.pillow, self.bed))
        grab_pillow.add_precondition(Not(self.robot_has(self.pillow)))
        grab_pillow.add_effect(self.object_at(self.pillow, self.bed), False)
        grab_pillow.add_effect(self.robot_has(self.pillow), True)

        place_pillow_on_chair = InstantaneousAction("place_pillow_on_chair")
        place_pillow_on_chair.add_precondition(self.robot_at(self.chair))
        place_pillow_on_chair.add_precondition(self.robot_has(self.pillow))
        place_pillow_on_chair.add_precondition(Not(self.pillow_on_chair))
        place_pillow_on_chair.add_effect(self.pillow_on_chair, True)
        place_pillow_on_chair.add_effect(self.robot_has(self.pillow), False)

        detect_cushion = InstantaneousAction("detect_cushion")
        detect_cushion.add_precondition(self.robot_at(self.chair))
        detect_cushion.add_precondition(Not(self.obstacle_detected))
        detect_cushion.add_effect(self.obstacle_detected, True)

        return navigate_to_bed, navigate_to_chair, navigate_to_table, grab_pillow, place_pillow_on_chair, detect_cushion

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_pillow_on_chair": And([
                Not(self.obstacle_detected),
                self.robot_has(self.pillow),
                self.chair_has_cushion,
                self.robot_has_obstacle_sensor
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bed), True)
        problem.set_initial_value(self.object_at(self.pillow, self.bed), True)
        problem.set_initial_value(self.object_at(self.cushion, self.chair), True)
        problem.set_initial_value(self.setting_is_bedroom, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.robot_has_obstacle_sensor, True)
        problem.set_initial_value(self.chair_has_cushion, True)
        problem.set_initial_value(self.cushion_on_chair, True)

    def _set_goals(self, problem):
        problem.add_goal(self.pillow_on_chair)

if __name__ == "__main__":
    DomainPlanner().run_cli()