(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   cushion - objecttype
 )
 (:init
              (robot_at bed)
              (object_at pillow bed)
              (object_at cushion chair)
              (setting_is_bedroom)
              (robot_has_gripper)
              (robot_has_obstacle_sensor)
              (chair_has_cushion)
              (cushion_on_chair)
 )
 (:goal (and 
           (pillow_on_chair)
        )
 )
)
