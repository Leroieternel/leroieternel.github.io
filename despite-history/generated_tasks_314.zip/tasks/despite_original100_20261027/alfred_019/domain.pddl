(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   table chair bed - location
   pillow - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (pillow_on_chair)
             (cushion_on_chair)
             (obstacle_detected)
             (setting_is_bedroom)
             (robot_has_gripper)
             (robot_has_obstacle_sensor)
             (chair_has_cushion)
 )
 (:action navigate_to_bed
  :parameters ()
  :precondition (and (not (robot_at bed)))
  :effect (and (not (robot_at chair)) (not (robot_at table)) (robot_at bed)))
 (:action navigate_to_chair
  :parameters ()
  :precondition (and (not (robot_at chair)))
  :effect (and (not (robot_at bed)) (not (robot_at table)) (robot_at chair)))
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at bed)) (not (robot_at chair)) (robot_at table)))
 (:action grab_pillow
  :parameters ()
  :precondition (and (robot_at bed) (object_at pillow bed) (not (robot_has pillow)))
  :effect (and (not (object_at pillow bed)) (robot_has pillow)))
 (:action place_pillow_on_chair
  :parameters ()
  :precondition (and (robot_at chair) (robot_has pillow) (not (pillow_on_chair)))
  :effect (and (pillow_on_chair) (not (robot_has pillow))))
 (:action detect_cushion
  :parameters ()
  :precondition (and (robot_at chair) (not (obstacle_detected)))
  :effect (and (obstacle_detected)))
)
