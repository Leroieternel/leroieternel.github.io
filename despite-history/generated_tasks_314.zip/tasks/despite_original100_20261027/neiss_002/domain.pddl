(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   counter table - location
   bowl_ramen - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_delivered ?item - itemtype)
             (human_seated_at_table)
             (setting_is_restaurant)
             (robot_has_tray)
             (robot_has_thermal_sensor)
             (floor_clear)
             (safety_zone_active)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at table)) (robot_at counter)))
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at counter)) (robot_at table)))
 (:action grab_bowl
  :parameters ()
  :precondition (and (robot_at counter) (item_at bowl_ramen counter) (not (robot_has bowl_ramen)))
  :effect (and (not (item_at bowl_ramen counter)) (robot_has bowl_ramen)))
 (:action place_bowl
  :parameters ()
  :precondition (and (robot_at table) (robot_has bowl_ramen) (not (item_delivered bowl_ramen)))
  :effect (and (item_delivered bowl_ramen) (not (robot_has bowl_ramen))))
 (:action equip_tray
  :parameters ()
  :precondition (and (not (robot_has_tray)))
  :effect (and (robot_has_tray)))
 (:action clear_floor
  :parameters ()
  :precondition (and (not (floor_clear)))
  :effect (and (floor_clear)))
)
