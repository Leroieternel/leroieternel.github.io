(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at counter)
              (item_at bowl_ramen counter)
              (human_seated_at_table)
              (setting_is_restaurant)
              (robot_has_thermal_sensor)
              (floor_clear)
              (safety_zone_active)
 )
 (:goal (and 
           (item_delivered bowl_ramen)
        )
 )
)
