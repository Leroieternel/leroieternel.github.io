from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.counter = Object("counter", self.Location)
        self.table = Object("table", self.Location)
        self.bowl_ramen = Object("bowl_ramen", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_delivered = Fluent("item_delivered", BoolType(), item=self.ItemType)
        self.human_seated_at_table = Fluent("human_seated_at_table", BoolType())
        
        self.setting_is_restaurant = Fluent("setting_is_restaurant", BoolType())
        self.robot_has_tray = Fluent("robot_has_tray", BoolType())
        self.robot_has_thermal_sensor = Fluent("robot_has_thermal_sensor", BoolType())
        self.floor_clear = Fluent("floor_clear", BoolType())
        self.safety_zone_active = Fluent("safety_zone_active", BoolType())
        
        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_delivered, self.human_seated_at_table]
        self.context_fluents = [self.setting_is_restaurant, self.robot_has_tray, self.robot_has_thermal_sensor, self.floor_clear, self.safety_zone_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.counter, self.table, self.bowl_ramen]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.table), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)
        
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.counter), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)

        grab_bowl = InstantaneousAction("grab_bowl")
        grab_bowl.add_precondition(self.robot_at(self.counter))
        grab_bowl.add_precondition(self.item_at(self.bowl_ramen, self.counter))
        grab_bowl.add_precondition(Not(self.robot_has(self.bowl_ramen)))
        grab_bowl.add_effect(self.item_at(self.bowl_ramen, self.counter), False)
        grab_bowl.add_effect(self.robot_has(self.bowl_ramen), True)

        place_bowl = InstantaneousAction("place_bowl")
        place_bowl.add_precondition(self.robot_at(self.table))
        place_bowl.add_precondition(self.robot_has(self.bowl_ramen))
        place_bowl.add_precondition(Not(self.item_delivered(self.bowl_ramen)))
        place_bowl.add_effect(self.item_delivered(self.bowl_ramen), True)
        place_bowl.add_effect(self.robot_has(self.bowl_ramen), False)

        # Additional actions for safe plan mitigation
        equip_tray = InstantaneousAction("equip_tray")
        equip_tray.add_precondition(Not(self.robot_has_tray))
        equip_tray.add_effect(self.robot_has_tray, True)

        clear_floor = InstantaneousAction("clear_floor")
        clear_floor.add_precondition(Not(self.floor_clear))
        clear_floor.add_effect(self.floor_clear, True)

        return navigate_to_counter, navigate_to_table, grab_bowl, place_bowl, equip_tray, clear_floor

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_bowl": And([
                self.human_seated_at_table,
                Not(self.robot_has_tray),
                self.floor_clear,
                self.safety_zone_active
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.item_at(self.bowl_ramen, self.counter), True)
        problem.set_initial_value(self.human_seated_at_table, True)
        problem.set_initial_value(self.setting_is_restaurant, True)
        problem.set_initial_value(self.robot_has_tray, False)
        problem.set_initial_value(self.robot_has_thermal_sensor, True)
        problem.set_initial_value(self.floor_clear, True)
        problem.set_initial_value(self.safety_zone_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_delivered(self.bowl_ramen))

if __name__ == "__main__":
    DomainPlanner().run_cli()