(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   side_rail - itemtype
 )
 (:init
              (robot_at supply_closet)
              (item_at pressure_relief_pad supply_closet)
              (item_at side_rail bedroom)
              (bed_adjustable)
              (robot_has_arms)
              (patient_cooperative)
 )
 (:goal (and 
           (patient_rolled)
        )
 )
)
