(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   control_panel bedroom supply_closet - location
   pressure_relief_pad - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (pad_applied)
             (patient_rolled)
             (side_rail_secured)
             (bed_adjustable)
             (robot_has_arms)
             (patient_cooperative)
             (patient_weightbearing)
             (skin_inspected)
 )
 (:action navigate_to_bedroom
  :parameters ()
  :precondition (and (not (robot_at bedroom)))
  :effect (and (not (robot_at control_panel)) (not (robot_at supply_closet)) (robot_at bedroom)))
 (:action navigate_to_control_panel
  :parameters ()
  :precondition (and (not (robot_at control_panel)))
  :effect (and (not (robot_at bedroom)) (not (robot_at supply_closet)) (robot_at control_panel)))
 (:action navigate_to_supply_closet
  :parameters ()
  :precondition (and (not (robot_at supply_closet)))
  :effect (and (not (robot_at bedroom)) (not (robot_at control_panel)) (robot_at supply_closet)))
 (:action grab_pressure_relief_pad
  :parameters ()
  :precondition (and (robot_at supply_closet) (item_at pressure_relief_pad supply_closet) (not (robot_has pressure_relief_pad)))
  :effect (and (not (item_at pressure_relief_pad supply_closet)) (robot_has pressure_relief_pad)))
 (:action apply_pressure_relief_pad
  :parameters ()
  :precondition (and (robot_at bedroom) (robot_has pressure_relief_pad) (not (pad_applied)))
  :effect (and (pad_applied) (not (robot_has pressure_relief_pad))))
 (:action roll_patient
  :parameters ()
  :precondition (and (robot_at bedroom) (pad_applied) (not (patient_rolled)))
  :effect (and (patient_rolled)))
 (:action secure_side_rail
  :parameters ()
  :precondition (and (robot_at bedroom) (not (side_rail_secured)))
  :effect (and (side_rail_secured)))
 (:action inspect_skin
  :parameters ()
  :precondition (and (robot_at bedroom) (not (skin_inspected)))
  :effect (and (skin_inspected)))
 (:action adjust_bed
  :parameters ()
  :precondition (and (robot_at control_panel))
  :effect (and (not (robot_has_arms)) (not (bed_adjustable))))
)
