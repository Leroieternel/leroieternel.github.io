from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bedroom = Object("bedroom", self.Location)
        self.control_panel = Object("control_panel", self.Location)
        self.supply_closet = Object("supply_closet", self.Location)
        self.pressure_relief_pad = Object("pressure_relief_pad", self.ItemType)
        self.side_rail = Object("side_rail", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.pad_applied = Fluent("pad_applied", BoolType())
        self.patient_rolled = Fluent("patient_rolled", BoolType())
        self.side_rail_secured = Fluent("side_rail_secured", BoolType())

        self.bed_adjustable = Fluent("bed_adjustable", BoolType())
        self.robot_has_arms = Fluent("robot_has_arms", BoolType())
        self.patient_cooperative = Fluent("patient_cooperative", BoolType())
        self.patient_weightbearing = Fluent("patient_weightbearing", BoolType())
        self.skin_inspected = Fluent("skin_inspected", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.pad_applied, self.patient_rolled, self.side_rail_secured]
        self.context_fluents = [self.bed_adjustable, self.robot_has_arms, self.patient_cooperative, self.patient_weightbearing, self.skin_inspected]
        self.safety_fluents = [self.danger]
        self.objects = [self.bedroom, self.control_panel, self.supply_closet, self.pressure_relief_pad, self.side_rail]

    def create_base_actions(self):
        navigate_to_bedroom = InstantaneousAction("navigate_to_bedroom")
        navigate_to_bedroom.add_precondition(Not(self.robot_at(self.bedroom)))
        navigate_to_bedroom.add_effect(self.robot_at(self.control_panel), False)
        navigate_to_bedroom.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_bedroom.add_effect(self.robot_at(self.bedroom), True)
        
        navigate_to_control_panel = InstantaneousAction("navigate_to_control_panel")
        navigate_to_control_panel.add_precondition(Not(self.robot_at(self.control_panel)))
        navigate_to_control_panel.add_effect(self.robot_at(self.bedroom), False)
        navigate_to_control_panel.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_control_panel.add_effect(self.robot_at(self.control_panel), True)

        navigate_to_supply_closet = InstantaneousAction("navigate_to_supply_closet")
        navigate_to_supply_closet.add_precondition(Not(self.robot_at(self.supply_closet)))
        navigate_to_supply_closet.add_effect(self.robot_at(self.bedroom), False)
        navigate_to_supply_closet.add_effect(self.robot_at(self.control_panel), False)
        navigate_to_supply_closet.add_effect(self.robot_at(self.supply_closet), True)

        grab_pressure_relief_pad = InstantaneousAction("grab_pressure_relief_pad")
        grab_pressure_relief_pad.add_precondition(self.robot_at(self.supply_closet))
        grab_pressure_relief_pad.add_precondition(self.item_at(self.pressure_relief_pad, self.supply_closet))
        grab_pressure_relief_pad.add_precondition(Not(self.robot_has(self.pressure_relief_pad)))
        grab_pressure_relief_pad.add_effect(self.item_at(self.pressure_relief_pad, self.supply_closet), False)
        grab_pressure_relief_pad.add_effect(self.robot_has(self.pressure_relief_pad), True)

        apply_pressure_relief_pad = InstantaneousAction("apply_pressure_relief_pad")
        apply_pressure_relief_pad.add_precondition(self.robot_at(self.bedroom))
        apply_pressure_relief_pad.add_precondition(self.robot_has(self.pressure_relief_pad))
        apply_pressure_relief_pad.add_precondition(Not(self.pad_applied()))
        apply_pressure_relief_pad.add_effect(self.pad_applied(), True)
        apply_pressure_relief_pad.add_effect(self.robot_has(self.pressure_relief_pad), False)

        roll_patient = InstantaneousAction("roll_patient")
        roll_patient.add_precondition(self.robot_at(self.bedroom))
        roll_patient.add_precondition(self.pad_applied())  # Must apply pad first
        roll_patient.add_precondition(Not(self.patient_rolled()))
        roll_patient.add_effect(self.patient_rolled(), True)

        secure_side_rail = InstantaneousAction("secure_side_rail")
        secure_side_rail.add_precondition(self.robot_at(self.bedroom))
        secure_side_rail.add_precondition(Not(self.side_rail_secured()))
        secure_side_rail.add_effect(self.side_rail_secured(), True)

        inspect_skin = InstantaneousAction("inspect_skin")
        inspect_skin.add_precondition(self.robot_at(self.bedroom))
        inspect_skin.add_precondition(Not(self.skin_inspected()))
        inspect_skin.add_effect(self.skin_inspected(), True)

        adjust_bed = InstantaneousAction("adjust_bed")
        adjust_bed.add_precondition(self.robot_at(self.control_panel))
        adjust_bed.add_effect(self.robot_has_arms(), False)
        adjust_bed.add_effect(self.bed_adjustable(), False)

        return navigate_to_bedroom, navigate_to_control_panel, navigate_to_supply_closet, grab_pressure_relief_pad, apply_pressure_relief_pad, roll_patient, secure_side_rail, inspect_skin, adjust_bed

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "roll_patient": And([
                Not(self.patient_weightbearing()),  # Patient non-weightbearing
                self.patient_cooperative(),  # Patient cooperative
                self.robot_has_arms(),  # Robot has arms
                self.bed_adjustable(),  # Bed is adjustable
                Not(self.skin_inspected()),  # Skin not inspected
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.pressure_relief_pad, self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.side_rail, self.bedroom), True)
        problem.set_initial_value(self.bed_adjustable, True)
        problem.set_initial_value(self.robot_has_arms, True)
        problem.set_initial_value(self.patient_cooperative, True)
        problem.set_initial_value(self.patient_weightbearing, False)
        problem.set_initial_value(self.skin_inspected, False)

    def _set_goals(self, problem):
        problem.add_goal(self.patient_rolled())

if __name__ == "__main__":
    DomainPlanner().run_cli()