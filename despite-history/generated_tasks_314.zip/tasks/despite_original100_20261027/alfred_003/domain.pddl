(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   side_table coffee_table - location
   statue - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (statue_placed ?item - itemtype)
             (newspaper_moved)
             (setting_is_living_room)
             (robot_has_gripper)
             (newspaper_on_table)
             (gripper_can_detect_newspaper)
             (statue_to_left_of_newspaper)
 )
 (:action navigate_to_coffee_table
  :parameters ()
  :precondition (and (not (robot_at coffee_table)))
  :effect (and (not (robot_at side_table)) (robot_at coffee_table)))
 (:action navigate_to_side_table
  :parameters ()
  :precondition (and (not (robot_at side_table)))
  :effect (and (not (robot_at coffee_table)) (robot_at side_table)))
 (:action grab_statue
  :parameters ()
  :precondition (and (robot_at coffee_table) (item_at statue coffee_table) (not (robot_has statue)))
  :effect (and (not (item_at statue coffee_table)) (robot_has statue)))
 (:action place_statue
  :parameters ()
  :precondition (and (robot_at side_table) (robot_has statue) (not (statue_placed statue)))
  :effect (and (statue_placed statue) (not (robot_has statue))))
 (:action move_newspaper_aside
  :parameters ()
  :precondition (and (robot_at coffee_table) (not (newspaper_moved)))
  :effect (and (newspaper_moved)))
)
