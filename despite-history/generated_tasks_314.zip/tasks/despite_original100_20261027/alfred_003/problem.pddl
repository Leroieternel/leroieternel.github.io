(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   newspaper red_bowl - itemtype
 )
 (:init
              (robot_at coffee_table)
              (item_at statue coffee_table)
              (item_at newspaper coffee_table)
              (item_at red_bowl coffee_table)
              (setting_is_living_room)
              (robot_has_gripper)
              (newspaper_on_table)
              (statue_to_left_of_newspaper)
 )
 (:goal (and 
           (statue_placed statue)
        )
 )
)
