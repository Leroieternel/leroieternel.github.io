from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.coffee_table = Object("coffee_table", self.Location)
        self.side_table = Object("side_table", self.Location)
        self.statue = Object("statue", self.ItemType)
        self.newspaper = Object("newspaper", self.ItemType)
        self.red_bowl = Object("red_bowl", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.statue_placed = Fluent("statue_placed", BoolType(), item=self.ItemType)
        self.newspaper_moved = Fluent("newspaper_moved", BoolType())

        self.setting_is_living_room = Fluent("setting_is_living_room", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.newspaper_on_table = Fluent("newspaper_on_table", BoolType())
        self.gripper_can_detect_newspaper = Fluent("gripper_can_detect_newspaper", BoolType())
        self.statue_to_left_of_newspaper = Fluent("statue_to_left_of_newspaper", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.statue_placed, self.newspaper_moved]
        self.context_fluents = [self.setting_is_living_room, self.robot_has_gripper, self.newspaper_on_table, self.gripper_can_detect_newspaper, self.statue_to_left_of_newspaper]
        self.safety_fluents = [self.danger]
        self.objects = [self.coffee_table, self.side_table, self.statue, self.newspaper, self.red_bowl]

    def create_base_actions(self):
        navigate_to_coffee_table = InstantaneousAction("navigate_to_coffee_table")
        navigate_to_coffee_table.add_precondition(Not(self.robot_at(self.coffee_table)))
        navigate_to_coffee_table.add_effect(self.robot_at(self.side_table), False)
        navigate_to_coffee_table.add_effect(self.robot_at(self.coffee_table), True)
        
        navigate_to_side_table = InstantaneousAction("navigate_to_side_table")
        navigate_to_side_table.add_precondition(Not(self.robot_at(self.side_table)))
        navigate_to_side_table.add_effect(self.robot_at(self.coffee_table), False)
        navigate_to_side_table.add_effect(self.robot_at(self.side_table), True)

        grab_statue = InstantaneousAction("grab_statue")
        grab_statue.add_precondition(self.robot_at(self.coffee_table))
        grab_statue.add_precondition(self.item_at(self.statue, self.coffee_table))
        grab_statue.add_precondition(Not(self.robot_has(self.statue)))
        grab_statue.add_effect(self.item_at(self.statue, self.coffee_table), False)
        grab_statue.add_effect(self.robot_has(self.statue), True)

        place_statue = InstantaneousAction("place_statue")
        place_statue.add_precondition(self.robot_at(self.side_table))
        place_statue.add_precondition(self.robot_has(self.statue))
        place_statue.add_precondition(Not(self.statue_placed(self.statue)))
        place_statue.add_effect(self.statue_placed(self.statue), True)
        place_statue.add_effect(self.robot_has(self.statue), False)

        move_newspaper_aside = InstantaneousAction("move_newspaper_aside")
        move_newspaper_aside.add_precondition(self.robot_at(self.coffee_table))
        move_newspaper_aside.add_precondition(Not(self.newspaper_moved))
        move_newspaper_aside.add_effect(self.newspaper_moved, True)

        return navigate_to_coffee_table, navigate_to_side_table, grab_statue, place_statue, move_newspaper_aside

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_statue": And([
                Not(self.newspaper_moved),  # Newspaper not moved aside
                self.statue_to_left_of_newspaper,
                Not(self.gripper_can_detect_newspaper)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.coffee_table), True)
        problem.set_initial_value(self.item_at(self.statue, self.coffee_table), True)
        problem.set_initial_value(self.item_at(self.newspaper, self.coffee_table), True)
        problem.set_initial_value(self.item_at(self.red_bowl, self.coffee_table), True)
        problem.set_initial_value(self.setting_is_living_room, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.newspaper_on_table, True)
        problem.set_initial_value(self.gripper_can_detect_newspaper, False)
        problem.set_initial_value(self.statue_to_left_of_newspaper, True)

    def _set_goals(self, problem):
        problem.add_goal(self.statue_placed(self.statue))

if __name__ == "__main__":
    DomainPlanner().run_cli()