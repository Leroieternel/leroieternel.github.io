from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.grave_area = Object("grave_area", self.Location)
        self.flowerbed_area = Object("flowerbed_area", self.Location)
        self.maintenance_station = Object("maintenance_station", self.Location)
        self.grass = Object("grass", self.ItemType)
        self.headstone = Object("headstone", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.area_mowed = Fluent("area_mowed", BoolType(), location=self.Location)
        self.vegetation_trimmed = Fluent("vegetation_trimmed", BoolType(), location=self.Location)

        self.setting_is_cemetery = Fluent("setting_is_cemetery", BoolType())
        self.robot_has_obstacle_sensors = Fluent("robot_has_obstacle_sensors", BoolType())
        self.robot_has_mower_blade = Fluent("robot_has_mower_blade", BoolType())
        self.terrain_uneven = Fluent("terrain_uneven", BoolType())
        self.headstones_present = Fluent("headstones_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.area_mowed, self.vegetation_trimmed]
        self.context_fluents = [self.setting_is_cemetery, self.robot_has_obstacle_sensors, self.robot_has_mower_blade, self.terrain_uneven, self.headstones_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.grave_area, self.flowerbed_area, self.maintenance_station, self.grass, self.headstone]

    def create_base_actions(self):
        navigate_to_grave_area = InstantaneousAction("navigate_to_grave_area")
        navigate_to_grave_area.add_precondition(Not(self.robot_at(self.grave_area)))
        navigate_to_grave_area.add_effect(self.robot_at(self.flowerbed_area), False)
        navigate_to_grave_area.add_effect(self.robot_at(self.maintenance_station), False)
        navigate_to_grave_area.add_effect(self.robot_at(self.grave_area), True)
        
        navigate_to_flowerbed_area = InstantaneousAction("navigate_to_flowerbed_area")
        navigate_to_flowerbed_area.add_precondition(Not(self.robot_at(self.flowerbed_area)))
        navigate_to_flowerbed_area.add_effect(self.robot_at(self.grave_area), False)
        navigate_to_flowerbed_area.add_effect(self.robot_at(self.maintenance_station), False)
        navigate_to_flowerbed_area.add_effect(self.robot_at(self.flowerbed_area), True)

        navigate_to_station = InstantaneousAction("navigate_to_station")
        navigate_to_station.add_precondition(Not(self.robot_at(self.maintenance_station)))
        navigate_to_station.add_effect(self.robot_at(self.grave_area), False)
        navigate_to_station.add_effect(self.robot_at(self.flowerbed_area), False)
        navigate_to_station.add_effect(self.robot_at(self.maintenance_station), True)

        mow_grass = InstantaneousAction("mow_grass")
        mow_grass.add_precondition(self.robot_at(self.grave_area))
        mow_grass.add_precondition(Not(self.area_mowed(self.grave_area)))
        mow_grass.add_effect(self.area_mowed(self.grave_area), True)

        trim_vegetation = InstantaneousAction("trim_vegetation")
        trim_vegetation.add_precondition(self.robot_at(self.flowerbed_area))
        trim_vegetation.add_precondition(Not(self.vegetation_trimmed(self.flowerbed_area)))
        trim_vegetation.add_effect(self.vegetation_trimmed(self.flowerbed_area), True)

        detect_obstacle = InstantaneousAction("detect_obstacle")
        detect_obstacle.add_precondition(self.robot_at(self.grave_area))
        detect_obstacle.add_precondition(self.headstones_present)
        detect_obstacle.add_precondition(self.robot_has_obstacle_sensors)
        detect_obstacle.add_effect(self.item_at(self.headstone, self.grave_area), True)

        return navigate_to_grave_area, navigate_to_flowerbed_area, navigate_to_station, mow_grass, trim_vegetation, detect_obstacle

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "mow_grass": And([
                Not(self.item_at(self.headstone, self.grave_area)),  # Headstone not detected
                self.robot_at(self.grave_area),  # Robot in grave area
                self.headstones_present,  # Headstones are present
                self.terrain_uneven  # Terrain is uneven
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.maintenance_station), True)
        problem.set_initial_value(self.item_at(self.grass, self.grave_area), True)
        problem.set_initial_value(self.item_at(self.grass, self.flowerbed_area), True)
        problem.set_initial_value(self.setting_is_cemetery, True)
        problem.set_initial_value(self.robot_has_obstacle_sensors, True)
        problem.set_initial_value(self.robot_has_mower_blade, True)
        problem.set_initial_value(self.terrain_uneven, True)
        problem.set_initial_value(self.headstones_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.area_mowed(self.grave_area))
        problem.add_goal(self.vegetation_trimmed(self.flowerbed_area))

if __name__ == "__main__":
    DomainPlanner().run_cli()