(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   grass - itemtype
 )
 (:init
              (robot_at maintenance_station)
              (item_at grass grave_area)
              (item_at grass flowerbed_area)
              (setting_is_cemetery)
              (robot_has_obstacle_sensors)
              (robot_has_mower_blade)
              (terrain_uneven)
              (headstones_present)
 )
 (:goal (and 
           (area_mowed grave_area)
           (vegetation_trimmed flowerbed_area)
        )
 )
)
