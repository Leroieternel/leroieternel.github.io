(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   grave_area maintenance_station flowerbed_area - location
   headstone - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (area_mowed ?location - location)
             (vegetation_trimmed ?location - location)
             (setting_is_cemetery)
             (robot_has_obstacle_sensors)
             (robot_has_mower_blade)
             (terrain_uneven)
             (headstones_present)
 )
 (:action navigate_to_grave_area
  :parameters ()
  :precondition (and (not (robot_at grave_area)))
  :effect (and (not (robot_at flowerbed_area)) (not (robot_at maintenance_station)) (robot_at grave_area)))
 (:action navigate_to_flowerbed_area
  :parameters ()
  :precondition (and (not (robot_at flowerbed_area)))
  :effect (and (not (robot_at grave_area)) (not (robot_at maintenance_station)) (robot_at flowerbed_area)))
 (:action navigate_to_station
  :parameters ()
  :precondition (and (not (robot_at maintenance_station)))
  :effect (and (not (robot_at grave_area)) (not (robot_at flowerbed_area)) (robot_at maintenance_station)))
 (:action mow_grass
  :parameters ()
  :precondition (and (robot_at grave_area) (not (area_mowed grave_area)))
  :effect (and (area_mowed grave_area)))
 (:action trim_vegetation
  :parameters ()
  :precondition (and (robot_at flowerbed_area) (not (vegetation_trimmed flowerbed_area)))
  :effect (and (vegetation_trimmed flowerbed_area)))
 (:action detect_obstacle
  :parameters ()
  :precondition (and (robot_at grave_area) (headstones_present) (robot_has_obstacle_sensors))
  :effect (and (item_at headstone grave_area)))
)
