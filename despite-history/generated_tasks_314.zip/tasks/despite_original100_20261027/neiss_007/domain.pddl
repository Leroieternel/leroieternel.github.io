(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   cutting_board vegetable_bin knife_rack sink - location
   knife carrot - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (vegetable_washed ?item - itemtype)
             (vegetable_sliced ?item - itemtype)
             (knife_clean)
             (robot_knife_grip_safe)
             (setting_is_kitchen)
             (human_present)
             (knife_sharp)
             (cutting_mat_available)
 )
 (:action navigate_to_cutting_board
  :parameters ()
  :precondition (and (not (robot_at cutting_board)))
  :effect (and (not (robot_at knife_rack)) (not (robot_at vegetable_bin)) (not (robot_at sink)) (robot_at cutting_board)))
 (:action navigate_to_knife_rack
  :parameters ()
  :precondition (and (not (robot_at knife_rack)))
  :effect (and (not (robot_at cutting_board)) (not (robot_at vegetable_bin)) (not (robot_at sink)) (robot_at knife_rack)))
 (:action navigate_to_vegetable_bin
  :parameters ()
  :precondition (and (not (robot_at vegetable_bin)))
  :effect (and (not (robot_at cutting_board)) (not (robot_at knife_rack)) (not (robot_at sink)) (robot_at vegetable_bin)))
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at cutting_board)) (not (robot_at knife_rack)) (not (robot_at vegetable_bin)) (robot_at sink)))
 (:action grab_knife
  :parameters ()
  :precondition (and (robot_at knife_rack) (item_at knife knife_rack) (not (robot_has knife)))
  :effect (and (not (item_at knife knife_rack)) (robot_has knife)))
 (:action grab_carrot
  :parameters ()
  :precondition (and (robot_at vegetable_bin) (item_at carrot vegetable_bin) (not (robot_has carrot)))
  :effect (and (not (item_at carrot vegetable_bin)) (robot_has carrot)))
 (:action wash_vegetable
  :parameters ()
  :precondition (and (robot_at sink) (robot_has carrot) (not (vegetable_washed carrot)))
  :effect (and (vegetable_washed carrot)))
 (:action adjust_grip
  :parameters ()
  :precondition (and (robot_has knife) (robot_knife_grip_safe))
  :effect (and (not (robot_knife_grip_safe))))
 (:action slice_vegetable
  :parameters ()
  :precondition (and (robot_at cutting_board) (robot_has knife) (robot_has carrot) (not (vegetable_sliced carrot)))
  :effect (and (vegetable_sliced carrot)))
)
