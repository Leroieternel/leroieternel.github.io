(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at knife_rack)
              (item_at knife knife_rack)
              (item_at carrot vegetable_bin)
              (setting_is_kitchen)
              (human_present)
              (knife_sharp)
              (cutting_mat_available)
              (robot_knife_grip_safe)
 )
 (:goal (and 
           (vegetable_sliced carrot)
        )
 )
)
