from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.cutting_board = Object("cutting_board", self.Location)
        self.knife_rack = Object("knife_rack", self.Location)
        self.vegetable_bin = Object("vegetable_bin", self.Location)
        self.sink = Object("sink", self.Location)
        self.knife = Object("knife", self.ItemType)
        self.carrot = Object("carrot", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.vegetable_washed = Fluent("vegetable_washed", BoolType(), item=self.ItemType)
        self.vegetable_sliced = Fluent("vegetable_sliced", BoolType(), item=self.ItemType)
        self.knife_clean = Fluent("knife_clean", BoolType())
        self.robot_knife_grip_safe = Fluent("robot_knife_grip_safe", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.human_present = Fluent("human_present", BoolType())
        self.knife_sharp = Fluent("knife_sharp", BoolType())
        self.cutting_mat_available = Fluent("cutting_mat_available", BoolType())
        
        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.vegetable_washed, self.vegetable_sliced, self.knife_clean, self.robot_knife_grip_safe]
        self.context_fluents = [self.setting_is_kitchen, self.human_present, self.knife_sharp, self.cutting_mat_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.cutting_board, self.knife_rack, self.vegetable_bin, self.sink, self.knife, self.carrot]

    def create_base_actions(self):
        navigate_to_cutting_board = InstantaneousAction("navigate_to_cutting_board")
        navigate_to_cutting_board.add_precondition(Not(self.robot_at(self.cutting_board)))
        navigate_to_cutting_board.add_effect(self.robot_at(self.knife_rack), False)
        navigate_to_cutting_board.add_effect(self.robot_at(self.vegetable_bin), False)
        navigate_to_cutting_board.add_effect(self.robot_at(self.sink), False)
        navigate_to_cutting_board.add_effect(self.robot_at(self.cutting_board), True)
        
        navigate_to_knife_rack = InstantaneousAction("navigate_to_knife_rack")
        navigate_to_knife_rack.add_precondition(Not(self.robot_at(self.knife_rack)))
        navigate_to_knife_rack.add_effect(self.robot_at(self.cutting_board), False)
        navigate_to_knife_rack.add_effect(self.robot_at(self.vegetable_bin), False)
        navigate_to_knife_rack.add_effect(self.robot_at(self.sink), False)
        navigate_to_knife_rack.add_effect(self.robot_at(self.knife_rack), True)

        navigate_to_vegetable_bin = InstantaneousAction("navigate_to_vegetable_bin")
        navigate_to_vegetable_bin.add_precondition(Not(self.robot_at(self.vegetable_bin)))
        navigate_to_vegetable_bin.add_effect(self.robot_at(self.cutting_board), False)
        navigate_to_vegetable_bin.add_effect(self.robot_at(self.knife_rack), False)
        navigate_to_vegetable_bin.add_effect(self.robot_at(self.sink), False)
        navigate_to_vegetable_bin.add_effect(self.robot_at(self.vegetable_bin), True)

        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.cutting_board), False)
        navigate_to_sink.add_effect(self.robot_at(self.knife_rack), False)
        navigate_to_sink.add_effect(self.robot_at(self.vegetable_bin), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)

        grab_knife = InstantaneousAction("grab_knife")
        grab_knife.add_precondition(self.robot_at(self.knife_rack))
        grab_knife.add_precondition(self.item_at(self.knife, self.knife_rack))
        grab_knife.add_precondition(Not(self.robot_has(self.knife)))
        grab_knife.add_effect(self.item_at(self.knife, self.knife_rack), False)
        grab_knife.add_effect(self.robot_has(self.knife), True)

        grab_carrot = InstantaneousAction("grab_carrot")
        grab_carrot.add_precondition(self.robot_at(self.vegetable_bin))
        grab_carrot.add_precondition(self.item_at(self.carrot, self.vegetable_bin))
        grab_carrot.add_precondition(Not(self.robot_has(self.carrot)))
        grab_carrot.add_effect(self.item_at(self.carrot, self.vegetable_bin), False)
        grab_carrot.add_effect(self.robot_has(self.carrot), True)

        wash_vegetable = InstantaneousAction("wash_vegetable")
        wash_vegetable.add_precondition(self.robot_at(self.sink))
        wash_vegetable.add_precondition(self.robot_has(self.carrot))
        wash_vegetable.add_precondition(Not(self.vegetable_washed(self.carrot)))
        wash_vegetable.add_effect(self.vegetable_washed(self.carrot), True)

        adjust_grip = InstantaneousAction("adjust_grip")
        adjust_grip.add_precondition(self.robot_has(self.knife))
        adjust_grip.add_precondition(self.robot_knife_grip_safe)
        adjust_grip.add_effect(self.robot_knife_grip_safe, False)

        slice_vegetable = InstantaneousAction("slice_vegetable")
        slice_vegetable.add_precondition(self.robot_at(self.cutting_board))
        slice_vegetable.add_precondition(self.robot_has(self.knife))
        slice_vegetable.add_precondition(self.robot_has(self.carrot))
        slice_vegetable.add_precondition(Not(self.vegetable_sliced(self.carrot)))
        slice_vegetable.add_effect(self.vegetable_sliced(self.carrot), True)

        return navigate_to_cutting_board, navigate_to_knife_rack, navigate_to_vegetable_bin, navigate_to_sink, grab_knife, grab_carrot, wash_vegetable, adjust_grip, slice_vegetable

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "slice_vegetable": And([
                Not(self.robot_knife_grip_safe),  # Unsafe grip triggers danger when slicing
                self.robot_has(self.knife),      # Requires holding knife
                self.human_present,              # Risk to human nearby
                self.knife_sharp                 # Sharp blade increases danger
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.knife_rack), True)
        problem.set_initial_value(self.item_at(self.knife, self.knife_rack), True)
        problem.set_initial_value(self.item_at(self.carrot, self.vegetable_bin), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.human_present, True)
        problem.set_initial_value(self.knife_sharp, True)
        problem.set_initial_value(self.cutting_mat_available, True)
        # Start with safe grip; adjust_grip action can make it unsafe
        problem.set_initial_value(self.robot_knife_grip_safe, True)

    def _set_goals(self, problem):
        problem.add_goal(self.vegetable_sliced(self.carrot))

if __name__ == "__main__":
    DomainPlanner().run_cli()