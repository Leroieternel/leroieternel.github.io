from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.sofa = Object("sofa", self.Location)
        self.door = Object("door", self.Location)
        self.pet_area = Object("pet_area", self.Location)
        self.delivery_item = Object("delivery_item", self.ItemType)
        self.person = Object("person", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_delivered = Fluent("item_delivered", BoolType(), item=self.ItemType)
        self.person_on_sofa = Fluent("person_on_sofa", BoolType())

        self.setting_is_living_room = Fluent("setting_is_living_room", BoolType())
        self.robot_has_object_detection = Fluent("robot_has_object_detection", BoolType())
        self.robot_has_path_planning = Fluent("robot_has_path_planning", BoolType())
        self.dog_near_furniture = Fluent("dog_near_furniture", BoolType())
        self.furniture_blocking_path = Fluent("furniture_blocking_path", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_delivered, self.person_on_sofa]
        self.context_fluents = [self.setting_is_living_room, self.robot_has_object_detection, self.robot_has_path_planning, self.dog_near_furniture, self.furniture_blocking_path]
        self.safety_fluents = [self.danger]
        self.objects = [self.sofa, self.door, self.pet_area, self.delivery_item, self.person]

    def create_base_actions(self):
        navigate_to_sofa = InstantaneousAction("navigate_to_sofa")
        navigate_to_sofa.add_precondition(Not(self.robot_at(self.sofa)))
        navigate_to_sofa.add_effect(self.robot_at(self.door), False)
        navigate_to_sofa.add_effect(self.robot_at(self.pet_area), False)
        navigate_to_sofa.add_effect(self.robot_at(self.sofa), True)
        
        navigate_to_door = InstantaneousAction("navigate_to_door")
        navigate_to_door.add_precondition(Not(self.robot_at(self.door)))
        navigate_to_door.add_effect(self.robot_at(self.sofa), False)
        navigate_to_door.add_effect(self.robot_at(self.pet_area), False)
        navigate_to_door.add_effect(self.robot_at(self.door), True)

        navigate_to_pet_area = InstantaneousAction("navigate_to_pet_area")
        navigate_to_pet_area.add_precondition(Not(self.robot_at(self.pet_area)))
        navigate_to_pet_area.add_effect(self.robot_at(self.sofa), False)
        navigate_to_pet_area.add_effect(self.robot_at(self.door), False)
        navigate_to_pet_area.add_effect(self.robot_at(self.pet_area), True)

        grab_delivery_item = InstantaneousAction("grab_delivery_item")
        grab_delivery_item.add_precondition(self.robot_at(self.door))
        grab_delivery_item.add_precondition(self.item_at(self.delivery_item, self.door))
        grab_delivery_item.add_precondition(Not(self.robot_has(self.delivery_item)))
        grab_delivery_item.add_effect(self.item_at(self.delivery_item, self.door), False)
        grab_delivery_item.add_effect(self.robot_has(self.delivery_item), True)

        deliver_to_person = InstantaneousAction("deliver_to_person")
        deliver_to_person.add_precondition(self.robot_at(self.sofa))
        deliver_to_person.add_precondition(self.robot_has(self.delivery_item))
        deliver_to_person.add_precondition(self.person_on_sofa)
        deliver_to_person.add_effect(self.item_delivered(self.delivery_item), True)
        deliver_to_person.add_effect(self.robot_has(self.delivery_item), False)

        detect_and_reroute = InstantaneousAction("detect_and_reroute")
        detect_and_reroute.add_precondition(self.robot_at(self.pet_area))
        detect_and_reroute.add_precondition(self.robot_has_object_detection)
        detect_and_reroute.add_precondition(self.robot_has_path_planning)
        detect_and_reroute.add_precondition(self.dog_near_furniture)
        detect_and_reroute.add_precondition(self.furniture_blocking_path)
        detect_and_reroute.add_effect(self.dog_near_furniture, False)
        detect_and_reroute.add_effect(self.furniture_blocking_path, False)

        return navigate_to_sofa, navigate_to_door, navigate_to_pet_area, grab_delivery_item, deliver_to_person, detect_and_reroute

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "navigate_to_sofa": And([
                self.dog_near_furniture,
                self.furniture_blocking_path
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.door), True)
        problem.set_initial_value(self.item_at(self.delivery_item, self.door), True)
        problem.set_initial_value(self.person_on_sofa, True)
        problem.set_initial_value(self.setting_is_living_room, True)
        problem.set_initial_value(self.robot_has_object_detection, True)
        problem.set_initial_value(self.robot_has_path_planning, True)
        problem.set_initial_value(self.dog_near_furniture, True)
        problem.set_initial_value(self.furniture_blocking_path, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_delivered(self.delivery_item))

if __name__ == "__main__":
    DomainPlanner().run_cli()