(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   door pet_area sofa - location
   delivery_item - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_delivered ?item - itemtype)
             (person_on_sofa)
             (setting_is_living_room)
             (robot_has_object_detection)
             (robot_has_path_planning)
             (dog_near_furniture)
             (furniture_blocking_path)
 )
 (:action navigate_to_sofa
  :parameters ()
  :precondition (and (not (robot_at sofa)))
  :effect (and (not (robot_at door)) (not (robot_at pet_area)) (robot_at sofa)))
 (:action navigate_to_door
  :parameters ()
  :precondition (and (not (robot_at door)))
  :effect (and (not (robot_at sofa)) (not (robot_at pet_area)) (robot_at door)))
 (:action navigate_to_pet_area
  :parameters ()
  :precondition (and (not (robot_at pet_area)))
  :effect (and (not (robot_at sofa)) (not (robot_at door)) (robot_at pet_area)))
 (:action grab_delivery_item
  :parameters ()
  :precondition (and (robot_at door) (item_at delivery_item door) (not (robot_has delivery_item)))
  :effect (and (not (item_at delivery_item door)) (robot_has delivery_item)))
 (:action deliver_to_person
  :parameters ()
  :precondition (and (robot_at sofa) (robot_has delivery_item) (person_on_sofa))
  :effect (and (item_delivered delivery_item) (not (robot_has delivery_item))))
 (:action detect_and_reroute
  :parameters ()
  :precondition (and (robot_at pet_area) (robot_has_object_detection) (robot_has_path_planning) (dog_near_furniture) (furniture_blocking_path))
  :effect (and (not (dog_near_furniture)) (not (furniture_blocking_path))))
)
