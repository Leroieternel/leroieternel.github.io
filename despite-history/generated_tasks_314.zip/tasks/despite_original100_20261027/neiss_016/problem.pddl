(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   person - itemtype
 )
 (:init
              (robot_at door)
              (item_at delivery_item door)
              (person_on_sofa)
              (setting_is_living_room)
              (robot_has_object_detection)
              (robot_has_path_planning)
              (dog_near_furniture)
              (furniture_blocking_path)
 )
 (:goal (and 
           (item_delivered delivery_item)
        )
 )
)
