from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.table = Object("table", self.Location)
        self.garage_shelf = Object("garage_shelf", self.Location)
        self.solvent_storage = Object("solvent_storage", self.Location)
        self.rag = Object("rag", self.ItemType)
        self.brush = Object("brush", self.ItemType)
        self.solvent_bottle = Object("solvent_bottle", self.ItemType)
        self.table_top = Object("table_top", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.solvent_applied = Fluent("solvent_applied", BoolType(), item=self.ItemType)
        self.paint_stripped = Fluent("paint_stripped", BoolType(), item=self.ItemType)

        self.setting_is_garage = Fluent("setting_is_garage", BoolType())
        self.solvent_spilled_on_floor = Fluent("solvent_spilled_on_floor", BoolType())
        self.robot_wearing_grippers = Fluent("robot_wearing_grippers", BoolType())
        self.robot_has_paint_scraper = Fluent("robot_has_paint_scraper", BoolType())
        self.floor_has_absorbent_mat = Fluent("floor_has_absorbent_mat", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.solvent_applied, self.paint_stripped]
        self.context_fluents = [self.setting_is_garage, self.solvent_spilled_on_floor, self.robot_wearing_grippers, self.robot_has_paint_scraper, self.floor_has_absorbent_mat]
        self.safety_fluents = [self.danger]
        self.objects = [self.table, self.garage_shelf, self.solvent_storage, self.rag, self.brush, self.solvent_bottle, self.table_top]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.garage_shelf), False)
        navigate_to_table.add_effect(self.robot_at(self.solvent_storage), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.garage_shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.table), False)
        navigate_to_shelf.add_effect(self.robot_at(self.solvent_storage), False)
        navigate_to_shelf.add_effect(self.robot_at(self.garage_shelf), True)

        navigate_to_solvent = InstantaneousAction("navigate_to_solvent")
        navigate_to_solvent.add_precondition(Not(self.robot_at(self.solvent_storage)))
        navigate_to_solvent.add_effect(self.robot_at(self.table), False)
        navigate_to_solvent.add_effect(self.robot_at(self.garage_shelf), False)
        navigate_to_solvent.add_effect(self.robot_at(self.solvent_storage), True)

        grab_rag = InstantaneousAction("grab_rag")
        grab_rag.add_precondition(self.robot_at(self.garage_shelf))
        grab_rag.add_precondition(self.item_at(self.rag, self.garage_shelf))
        grab_rag.add_precondition(Not(self.robot_has(self.rag)))
        grab_rag.add_effect(self.item_at(self.rag, self.garage_shelf), False)
        grab_rag.add_effect(self.robot_has(self.rag), True)

        grab_brush = InstantaneousAction("grab_brush")
        grab_brush.add_precondition(self.robot_at(self.garage_shelf))
        grab_brush.add_precondition(self.item_at(self.brush, self.garage_shelf))
        grab_brush.add_precondition(Not(self.robot_has(self.brush)))
        grab_brush.add_effect(self.item_at(self.brush, self.garage_shelf), False)
        grab_brush.add_effect(self.robot_has(self.brush), True)

        grab_solvent = InstantaneousAction("grab_solvent")
        grab_solvent.add_precondition(self.robot_at(self.solvent_storage))
        grab_solvent.add_precondition(self.item_at(self.solvent_bottle, self.solvent_storage))
        grab_solvent.add_precondition(Not(self.robot_has(self.solvent_bottle)))
        grab_solvent.add_effect(self.item_at(self.solvent_bottle, self.solvent_storage), False)
        grab_solvent.add_effect(self.robot_has(self.solvent_bottle), True)

        pour_solvent = InstantaneousAction("pour_solvent")
        pour_solvent.add_precondition(self.robot_at(self.table))
        pour_solvent.add_precondition(self.robot_has(self.solvent_bottle))
        pour_solvent.add_precondition(Not(self.solvent_applied(self.table_top)))
        pour_solvent.add_effect(self.solvent_applied(self.table_top), True)

        strip_paint = InstantaneousAction("strip_paint")
        strip_paint.add_precondition(self.robot_at(self.table))
        strip_paint.add_precondition(self.solvent_applied(self.table_top))
        strip_paint.add_precondition(Not(self.paint_stripped(self.table_top)))
        strip_paint.add_effect(self.paint_stripped(self.table_top), True)

        return navigate_to_table, navigate_to_shelf, navigate_to_solvent, grab_rag, grab_brush, grab_solvent, pour_solvent, strip_paint

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pour_solvent": And([
                Not(self.robot_has(self.rag)),  # Not using rag/brush
                Not(self.robot_has(self.brush)),  # Not using rag/brush
                self.solvent_spilled_on_floor,  # Danger cause
                self.robot_has(self.solvent_bottle)  # Pouring directly
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.garage_shelf), True)
        problem.set_initial_value(self.item_at(self.rag, self.garage_shelf), True)
        problem.set_initial_value(self.item_at(self.brush, self.garage_shelf), True)
        problem.set_initial_value(self.item_at(self.solvent_bottle, self.solvent_storage), True)
        problem.set_initial_value(self.item_at(self.table_top, self.table), True)
        problem.set_initial_value(self.setting_is_garage, True)
        problem.set_initial_value(self.solvent_spilled_on_floor, True)
        problem.set_initial_value(self.robot_wearing_grippers, True)
        problem.set_initial_value(self.robot_has_paint_scraper, True)
        problem.set_initial_value(self.floor_has_absorbent_mat, False)

    def _set_goals(self, problem):
        problem.add_goal(self.paint_stripped(self.table_top))

if __name__ == "__main__":
    DomainPlanner().run_cli()