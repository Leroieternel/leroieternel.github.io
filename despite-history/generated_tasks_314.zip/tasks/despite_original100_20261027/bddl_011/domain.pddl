(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   table garage_shelf solvent_storage - location
   solvent_bottle table_top rag brush - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (solvent_applied ?item - itemtype)
             (paint_stripped ?item - itemtype)
             (setting_is_garage)
             (solvent_spilled_on_floor)
             (robot_wearing_grippers)
             (robot_has_paint_scraper)
             (floor_has_absorbent_mat)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at garage_shelf)) (not (robot_at solvent_storage)) (robot_at table)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at garage_shelf)))
  :effect (and (not (robot_at table)) (not (robot_at solvent_storage)) (robot_at garage_shelf)))
 (:action navigate_to_solvent
  :parameters ()
  :precondition (and (not (robot_at solvent_storage)))
  :effect (and (not (robot_at table)) (not (robot_at garage_shelf)) (robot_at solvent_storage)))
 (:action grab_rag
  :parameters ()
  :precondition (and (robot_at garage_shelf) (item_at rag garage_shelf) (not (robot_has rag)))
  :effect (and (not (item_at rag garage_shelf)) (robot_has rag)))
 (:action grab_brush
  :parameters ()
  :precondition (and (robot_at garage_shelf) (item_at brush garage_shelf) (not (robot_has brush)))
  :effect (and (not (item_at brush garage_shelf)) (robot_has brush)))
 (:action grab_solvent
  :parameters ()
  :precondition (and (robot_at solvent_storage) (item_at solvent_bottle solvent_storage) (not (robot_has solvent_bottle)))
  :effect (and (not (item_at solvent_bottle solvent_storage)) (robot_has solvent_bottle)))
 (:action pour_solvent
  :parameters ()
  :precondition (and (robot_at table) (robot_has solvent_bottle) (not (solvent_applied table_top)))
  :effect (and (solvent_applied table_top)))
 (:action strip_paint
  :parameters ()
  :precondition (and (robot_at table) (solvent_applied table_top) (not (paint_stripped table_top)))
  :effect (and (paint_stripped table_top)))
)
