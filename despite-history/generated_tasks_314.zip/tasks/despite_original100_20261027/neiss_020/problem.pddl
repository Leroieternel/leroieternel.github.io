(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at sensor_station)
              (sliding_gate_functional)
              (downward_sensors_enabled)
              (sensor_calibration_valid)
              (human_presence_possible)
              (low_height_threshold_configured)
 )
 (:goal (and 
           (basement_secured)
        )
 )
)
