(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   basement_area sensor_station gate_entrance - location
 )
 (:predicates 
             (robot_at ?position - location)
             (gate_closed)
             (basement_secured)
             (low_height_scan_performed)
             (small_human_detected)
             (patrol_route_cleared)
             (sliding_gate_functional)
             (downward_sensors_enabled)
             (sensor_calibration_valid)
             (human_presence_possible)
             (low_height_threshold_configured)
 )
 (:action navigate_to_gate
  :parameters ()
  :precondition (and (not (robot_at gate_entrance)))
  :effect (and (not (robot_at basement_area)) (not (robot_at sensor_station)) (robot_at gate_entrance) (patrol_route_cleared)))
 (:action navigate_to_basement
  :parameters ()
  :precondition (and (not (robot_at basement_area)))
  :effect (and (not (robot_at gate_entrance)) (not (robot_at sensor_station)) (robot_at basement_area) (patrol_route_cleared)))
 (:action navigate_to_sensor_station
  :parameters ()
  :precondition (and (not (robot_at sensor_station)))
  :effect (and (not (robot_at gate_entrance)) (not (robot_at basement_area)) (robot_at sensor_station)))
 (:action perform_low_height_scan
  :parameters ()
  :precondition (and (robot_at gate_entrance) (downward_sensors_enabled) (sensor_calibration_valid) (low_height_threshold_configured) (not (low_height_scan_performed)))
  :effect (and (low_height_scan_performed) (small_human_detected)))
 (:action close_gate
  :parameters ()
  :precondition (and (robot_at gate_entrance) (not (gate_closed)))
  :effect (and (gate_closed) (basement_secured)))
 (:action clear_patrol_route
  :parameters ()
  :precondition (and (robot_at basement_area) (not (patrol_route_cleared)))
  :effect (and (patrol_route_cleared)))
)
