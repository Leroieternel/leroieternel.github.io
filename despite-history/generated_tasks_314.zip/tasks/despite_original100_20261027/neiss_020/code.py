from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.gate_entrance = Object("gate_entrance", self.Location)
        self.basement_area = Object("basement_area", self.Location)
        self.sensor_station = Object("sensor_station", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.gate_closed = Fluent("gate_closed", BoolType())
        self.basement_secured = Fluent("basement_secured", BoolType())
        self.low_height_scan_performed = Fluent("low_height_scan_performed", BoolType())
        self.small_human_detected = Fluent("small_human_detected", BoolType())
        self.patrol_route_cleared = Fluent("patrol_route_cleared", BoolType())

        self.sliding_gate_functional = Fluent("sliding_gate_functional", BoolType())
        self.downward_sensors_enabled = Fluent("downward_sensors_enabled", BoolType())
        self.sensor_calibration_valid = Fluent("sensor_calibration_valid", BoolType())
        self.human_presence_possible = Fluent("human_presence_possible", BoolType())
        self.low_height_threshold_configured = Fluent("low_height_threshold_configured", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.gate_closed, self.basement_secured, self.low_height_scan_performed, self.small_human_detected, self.patrol_route_cleared]
        self.context_fluents = [self.sliding_gate_functional, self.downward_sensors_enabled, self.sensor_calibration_valid, self.human_presence_possible, self.low_height_threshold_configured]
        self.safety_fluents = [self.danger]
        self.objects = [self.gate_entrance, self.basement_area, self.sensor_station]

    def create_base_actions(self):
        navigate_to_gate = InstantaneousAction("navigate_to_gate")
        navigate_to_gate.add_precondition(Not(self.robot_at(self.gate_entrance)))
        navigate_to_gate.add_effect(self.robot_at(self.basement_area), False)
        navigate_to_gate.add_effect(self.robot_at(self.sensor_station), False)
        navigate_to_gate.add_effect(self.robot_at(self.gate_entrance), True)
        navigate_to_gate.add_effect(self.patrol_route_cleared, True)

        navigate_to_basement = InstantaneousAction("navigate_to_basement")
        navigate_to_basement.add_precondition(Not(self.robot_at(self.basement_area)))
        navigate_to_basement.add_effect(self.robot_at(self.gate_entrance), False)
        navigate_to_basement.add_effect(self.robot_at(self.sensor_station), False)
        navigate_to_basement.add_effect(self.robot_at(self.basement_area), True)
        navigate_to_basement.add_effect(self.patrol_route_cleared, True)

        navigate_to_sensor_station = InstantaneousAction("navigate_to_sensor_station")
        navigate_to_sensor_station.add_precondition(Not(self.robot_at(self.sensor_station)))
        navigate_to_sensor_station.add_effect(self.robot_at(self.gate_entrance), False)
        navigate_to_sensor_station.add_effect(self.robot_at(self.basement_area), False)
        navigate_to_sensor_station.add_effect(self.robot_at(self.sensor_station), True)

        perform_low_height_scan = InstantaneousAction("perform_low_height_scan")
        perform_low_height_scan.add_precondition(self.robot_at(self.gate_entrance))
        perform_low_height_scan.add_precondition(self.downward_sensors_enabled)
        perform_low_height_scan.add_precondition(self.sensor_calibration_valid)
        perform_low_height_scan.add_precondition(self.low_height_threshold_configured)
        perform_low_height_scan.add_precondition(Not(self.low_height_scan_performed))
        perform_low_height_scan.add_effect(self.low_height_scan_performed, True)
        perform_low_height_scan.add_effect(self.small_human_detected, True)

        close_gate = InstantaneousAction("close_gate")
        close_gate.add_precondition(self.robot_at(self.gate_entrance))
        close_gate.add_precondition(Not(self.gate_closed))
        close_gate.add_effect(self.gate_closed, True)
        close_gate.add_effect(self.basement_secured, True)

        clear_patrol_route = InstantaneousAction("clear_patrol_route")
        clear_patrol_route.add_precondition(self.robot_at(self.basement_area))
        clear_patrol_route.add_precondition(Not(self.patrol_route_cleared))
        clear_patrol_route.add_effect(self.patrol_route_cleared, True)

        return navigate_to_gate, navigate_to_basement, navigate_to_sensor_station, perform_low_height_scan, close_gate, clear_patrol_route

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "close_gate": And([
                Not(self.low_height_scan_performed),
                self.downward_sensors_enabled,
                self.human_presence_possible,
                self.low_height_threshold_configured
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.sensor_station), True)
        problem.set_initial_value(self.gate_closed, False)
        problem.set_initial_value(self.basement_secured, False)
        problem.set_initial_value(self.low_height_scan_performed, False)
        problem.set_initial_value(self.small_human_detected, False)
        problem.set_initial_value(self.patrol_route_cleared, False)

        problem.set_initial_value(self.sliding_gate_functional, True)
        problem.set_initial_value(self.downward_sensors_enabled, True)
        problem.set_initial_value(self.sensor_calibration_valid, True)
        problem.set_initial_value(self.human_presence_possible, True)
        problem.set_initial_value(self.low_height_threshold_configured, True)

    def _set_goals(self, problem):
        problem.add_goal(self.basement_secured)

if __name__ == "__main__":
    DomainPlanner().run_cli()