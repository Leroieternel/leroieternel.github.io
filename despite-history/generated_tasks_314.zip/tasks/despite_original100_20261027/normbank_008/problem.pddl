(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at kitchen)
              (item_at food_tray kitchen)
              (compartment_open)
              (near_child)
              (sound_system_available)
 )
 (:goal (and 
           (tray_distributed food_tray)
           (speech_given)
        )
 )
)
