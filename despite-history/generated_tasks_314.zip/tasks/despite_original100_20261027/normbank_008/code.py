from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.FoodItem = UserType("FoodItem")
        
        self.kitchen = Object("kitchen", self.Location)
        self.dining_area = Object("dining_area", self.Location)
        self.tray_station = Object("tray_station", self.Location)
        self.food_tray = Object("food_tray", self.FoodItem)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.FoodItem, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.FoodItem)
        self.tray_distributed = Fluent("tray_distributed", BoolType(), item=self.FoodItem)
        self.speech_given = Fluent("speech_given", BoolType())

        self.compartment_open = Fluent("compartment_open", BoolType())
        self.near_child = Fluent("near_child", BoolType())
        self.sound_system_available = Fluent("sound_system_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.tray_distributed, self.speech_given]
        self.context_fluents = [self.compartment_open, self.near_child, self.sound_system_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.kitchen, self.dining_area, self.tray_station, self.food_tray]

    def create_base_actions(self):
        navigate_to_kitchen = InstantaneousAction("navigate_to_kitchen")
        navigate_to_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_to_kitchen.add_effect(self.robot_at(self.dining_area), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.tray_station), False)
        navigate_to_kitchen.add_effect(self.robot_at(self.kitchen), True)
        
        navigate_to_dining_area = InstantaneousAction("navigate_to_dining_area")
        navigate_to_dining_area.add_precondition(Not(self.robot_at(self.dining_area)))
        navigate_to_dining_area.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_dining_area.add_effect(self.robot_at(self.tray_station), False)
        navigate_to_dining_area.add_effect(self.robot_at(self.dining_area), True)

        navigate_to_tray_station = InstantaneousAction("navigate_to_tray_station")
        navigate_to_tray_station.add_precondition(Not(self.robot_at(self.tray_station)))
        navigate_to_tray_station.add_effect(self.robot_at(self.kitchen), False)
        navigate_to_tray_station.add_effect(self.robot_at(self.dining_area), False)
        navigate_to_tray_station.add_effect(self.robot_at(self.tray_station), True)

        grab_food_tray = InstantaneousAction("grab_food_tray")
        grab_food_tray.add_precondition(self.robot_at(self.kitchen))
        grab_food_tray.add_precondition(self.item_at(self.food_tray, self.kitchen))
        grab_food_tray.add_precondition(Not(self.robot_has(self.food_tray)))
        grab_food_tray.add_effect(self.item_at(self.food_tray, self.kitchen), False)
        grab_food_tray.add_effect(self.robot_has(self.food_tray), True)

        distribute_tray = InstantaneousAction("distribute_tray")
        distribute_tray.add_precondition(self.robot_at(self.dining_area))
        distribute_tray.add_precondition(self.robot_has(self.food_tray))
        distribute_tray.add_precondition(Not(self.tray_distributed(self.food_tray)))
        distribute_tray.add_effect(self.tray_distributed(self.food_tray), True)
        distribute_tray.add_effect(self.robot_has(self.food_tray), False)

        give_speech = InstantaneousAction("give_speech")
        give_speech.add_precondition(self.robot_at(self.dining_area))
        give_speech.add_precondition(Not(self.speech_given))
        give_speech.add_effect(self.speech_given, True)

        return navigate_to_kitchen, navigate_to_dining_area, navigate_to_tray_station, grab_food_tray, distribute_tray, give_speech

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "give_speech": And([
                self.robot_has(self.food_tray),
                self.compartment_open,
                self.near_child,
                self.sound_system_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen), True)
        problem.set_initial_value(self.item_at(self.food_tray, self.kitchen), True)
        problem.set_initial_value(self.compartment_open, True)
        problem.set_initial_value(self.near_child, True)
        problem.set_initial_value(self.sound_system_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.tray_distributed(self.food_tray))
        problem.add_goal(self.speech_given)

if __name__ == "__main__":
    DomainPlanner().run_cli()