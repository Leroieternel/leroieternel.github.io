(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location fooditem)
 (:constants
   kitchen tray_station dining_area - location
   food_tray - fooditem
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - fooditem ?position - location)
             (robot_has ?item - fooditem)
             (tray_distributed ?item - fooditem)
             (speech_given)
             (compartment_open)
             (near_child)
             (sound_system_available)
 )
 (:action navigate_to_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at dining_area)) (not (robot_at tray_station)) (robot_at kitchen)))
 (:action navigate_to_dining_area
  :parameters ()
  :precondition (and (not (robot_at dining_area)))
  :effect (and (not (robot_at kitchen)) (not (robot_at tray_station)) (robot_at dining_area)))
 (:action navigate_to_tray_station
  :parameters ()
  :precondition (and (not (robot_at tray_station)))
  :effect (and (not (robot_at kitchen)) (not (robot_at dining_area)) (robot_at tray_station)))
 (:action grab_food_tray
  :parameters ()
  :precondition (and (robot_at kitchen) (item_at food_tray kitchen) (not (robot_has food_tray)))
  :effect (and (not (item_at food_tray kitchen)) (robot_has food_tray)))
 (:action distribute_tray
  :parameters ()
  :precondition (and (robot_at dining_area) (robot_has food_tray) (not (tray_distributed food_tray)))
  :effect (and (tray_distributed food_tray) (not (robot_has food_tray))))
 (:action give_speech
  :parameters ()
  :precondition (and (robot_at dining_area) (not (speech_given)))
  :effect (and (speech_given)))
)
