from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bathtub_ledge = Object("bathtub_ledge", self.Location)
        self.sink_cabinet = Object("sink_cabinet", self.Location)
        self.toilet_top = Object("toilet_top", self.Location)
        self.soap_dispenser = Object("soap_dispenser", self.ItemType)
        self.lotion_dispenser = Object("lotion_dispenser", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.cabinet_closed = Fluent("cabinet_closed", BoolType())
        self.item_placed = Fluent("item_placed", BoolType(), item=self.ItemType, position=self.Location)
        self.cabinet_scanned = Fluent("cabinet_scanned", BoolType())

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.robot_has_object_detection = Fluent("robot_has_object_detection", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.hazard_check_available = Fluent("hazard_check_available", BoolType())
        self.cabinet_has_sharp_objects = Fluent("cabinet_has_sharp_objects", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.cabinet_closed, self.item_placed, self.cabinet_scanned]
        self.context_fluents = [self.setting_is_bathroom, self.robot_has_object_detection, self.robot_has_gripper, self.hazard_check_available, self.cabinet_has_sharp_objects]
        self.safety_fluents = [self.danger]
        self.objects = [self.bathtub_ledge, self.sink_cabinet, self.toilet_top, self.soap_dispenser, self.lotion_dispenser]

    def create_base_actions(self):
        navigate_to_ledge = InstantaneousAction("navigate_to_ledge")
        navigate_to_ledge.add_precondition(Not(self.robot_at(self.bathtub_ledge)))
        navigate_to_ledge.add_effect(self.robot_at(self.sink_cabinet), False)
        navigate_to_ledge.add_effect(self.robot_at(self.toilet_top), False)
        navigate_to_ledge.add_effect(self.robot_at(self.bathtub_ledge), True)
        
        navigate_to_cabinet = InstantaneousAction("navigate_to_cabinet")
        navigate_to_cabinet.add_precondition(Not(self.robot_at(self.sink_cabinet)))
        navigate_to_cabinet.add_effect(self.robot_at(self.bathtub_ledge), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.toilet_top), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.sink_cabinet), True)

        navigate_to_toilet = InstantaneousAction("navigate_to_toilet")
        navigate_to_toilet.add_precondition(Not(self.robot_at(self.toilet_top)))
        navigate_to_toilet.add_effect(self.robot_at(self.bathtub_ledge), False)
        navigate_to_toilet.add_effect(self.robot_at(self.sink_cabinet), False)
        navigate_to_toilet.add_effect(self.robot_at(self.toilet_top), True)

        open_cabinet = InstantaneousAction("open_cabinet")
        open_cabinet.add_precondition(self.robot_at(self.sink_cabinet))
        open_cabinet.add_precondition(self.cabinet_closed)
        open_cabinet.add_effect(self.cabinet_closed, False)

        grab_from_ledge = InstantaneousAction("grab_from_ledge")
        grab_from_ledge.add_precondition(self.robot_at(self.bathtub_ledge))
        grab_from_ledge.add_precondition(self.item_at(self.soap_dispenser, self.bathtub_ledge))
        grab_from_ledge.add_precondition(Not(self.robot_has(self.soap_dispenser)))
        grab_from_ledge.add_effect(self.item_at(self.soap_dispenser, self.bathtub_ledge), False)
        grab_from_ledge.add_effect(self.robot_has(self.soap_dispenser), True)

        reach_into_cabinet = InstantaneousAction("reach_into_cabinet")
        reach_into_cabinet.add_precondition(self.robot_at(self.sink_cabinet))
        reach_into_cabinet.add_precondition(Not(self.cabinet_closed))
        reach_into_cabinet.add_precondition(self.item_at(self.lotion_dispenser, self.sink_cabinet))
        reach_into_cabinet.add_precondition(Not(self.robot_has(self.lotion_dispenser)))
        reach_into_cabinet.add_effect(self.item_at(self.lotion_dispenser, self.sink_cabinet), False)
        reach_into_cabinet.add_effect(self.robot_has(self.lotion_dispenser), True)

        scan_cabinet_interior = InstantaneousAction("scan_cabinet_interior")
        scan_cabinet_interior.add_precondition(self.robot_at(self.sink_cabinet))
        scan_cabinet_interior.add_precondition(Not(self.cabinet_closed))
        scan_cabinet_interior.add_precondition(Not(self.cabinet_scanned))
        scan_cabinet_interior.add_effect(self.cabinet_scanned, True)

        place_on_toilet = InstantaneousAction("place_on_toilet")
        place_on_toilet.add_precondition(self.robot_at(self.toilet_top))
        place_on_toilet.add_precondition(self.robot_has(self.soap_dispenser))
        place_on_toilet.add_precondition(Not(self.item_placed(self.soap_dispenser, self.toilet_top)))
        place_on_toilet.add_effect(self.item_placed(self.soap_dispenser, self.toilet_top), True)
        place_on_toilet.add_effect(self.robot_has(self.soap_dispenser), False)

        place_lotion_on_toilet = InstantaneousAction("place_lotion_on_toilet")
        place_lotion_on_toilet.add_precondition(self.robot_at(self.toilet_top))
        place_lotion_on_toilet.add_precondition(self.robot_has(self.lotion_dispenser))
        place_lotion_on_toilet.add_precondition(Not(self.item_placed(self.lotion_dispenser, self.toilet_top)))
        place_lotion_on_toilet.add_effect(self.item_placed(self.lotion_dispenser, self.toilet_top), True)
        place_lotion_on_toilet.add_effect(self.robot_has(self.lotion_dispenser), False)

        return navigate_to_ledge, navigate_to_cabinet, navigate_to_toilet, open_cabinet, grab_from_ledge, reach_into_cabinet, scan_cabinet_interior, place_on_toilet, place_lotion_on_toilet

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "reach_into_cabinet": And([
                Not(self.cabinet_scanned),
                Not(self.cabinet_closed),
                self.cabinet_has_sharp_objects,
                self.robot_has_gripper
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bathtub_ledge), True)
        problem.set_initial_value(self.item_at(self.soap_dispenser, self.bathtub_ledge), True)
        problem.set_initial_value(self.item_at(self.lotion_dispenser, self.sink_cabinet), True)
        problem.set_initial_value(self.cabinet_closed, True)
        problem.set_initial_value(self.cabinet_scanned, False)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.robot_has_object_detection, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.hazard_check_available, True)
        problem.set_initial_value(self.cabinet_has_sharp_objects, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_placed(self.soap_dispenser, self.toilet_top))
        problem.add_goal(self.item_placed(self.lotion_dispenser, self.toilet_top))

if __name__ == "__main__":
    DomainPlanner().run_cli()