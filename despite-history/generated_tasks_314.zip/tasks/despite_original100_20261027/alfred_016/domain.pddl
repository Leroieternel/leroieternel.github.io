(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   toilet_top bathtub_ledge sink_cabinet - location
   lotion_dispenser soap_dispenser - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (cabinet_closed)
             (item_placed ?item - itemtype ?position - location)
             (cabinet_scanned)
             (setting_is_bathroom)
             (robot_has_object_detection)
             (robot_has_gripper)
             (hazard_check_available)
             (cabinet_has_sharp_objects)
 )
 (:action navigate_to_ledge
  :parameters ()
  :precondition (and (not (robot_at bathtub_ledge)))
  :effect (and (not (robot_at sink_cabinet)) (not (robot_at toilet_top)) (robot_at bathtub_ledge)))
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at sink_cabinet)))
  :effect (and (not (robot_at bathtub_ledge)) (not (robot_at toilet_top)) (robot_at sink_cabinet)))
 (:action navigate_to_toilet
  :parameters ()
  :precondition (and (not (robot_at toilet_top)))
  :effect (and (not (robot_at bathtub_ledge)) (not (robot_at sink_cabinet)) (robot_at toilet_top)))
 (:action open_cabinet
  :parameters ()
  :precondition (and (robot_at sink_cabinet) (cabinet_closed))
  :effect (and (not (cabinet_closed))))
 (:action grab_from_ledge
  :parameters ()
  :precondition (and (robot_at bathtub_ledge) (item_at soap_dispenser bathtub_ledge) (not (robot_has soap_dispenser)))
  :effect (and (not (item_at soap_dispenser bathtub_ledge)) (robot_has soap_dispenser)))
 (:action reach_into_cabinet
  :parameters ()
  :precondition (and (robot_at sink_cabinet) (not (cabinet_closed)) (item_at lotion_dispenser sink_cabinet) (not (robot_has lotion_dispenser)))
  :effect (and (not (item_at lotion_dispenser sink_cabinet)) (robot_has lotion_dispenser)))
 (:action scan_cabinet_interior
  :parameters ()
  :precondition (and (robot_at sink_cabinet) (not (cabinet_closed)) (not (cabinet_scanned)))
  :effect (and (cabinet_scanned)))
 (:action place_on_toilet
  :parameters ()
  :precondition (and (robot_at toilet_top) (robot_has soap_dispenser) (not (item_placed soap_dispenser toilet_top)))
  :effect (and (item_placed soap_dispenser toilet_top) (not (robot_has soap_dispenser))))
 (:action place_lotion_on_toilet
  :parameters ()
  :precondition (and (robot_at toilet_top) (robot_has lotion_dispenser) (not (item_placed lotion_dispenser toilet_top)))
  :effect (and (item_placed lotion_dispenser toilet_top) (not (robot_has lotion_dispenser))))
)
