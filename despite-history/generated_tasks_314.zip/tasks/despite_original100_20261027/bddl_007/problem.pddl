(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   swab mop_bucket bucket - tooltype
 )
 (:init
              (robot_at storage_area)
              (tool_at disinfectant_bottle storage_area)
              (tool_at detergent_bottle storage_area)
              (tool_at broom cleaning_tools_rack)
              (tool_at swab cleaning_tools_rack)
              (tool_at mop_bucket cleaning_tools_rack)
              (tool_at bucket cleaning_tools_rack)
              (setting_is_utility_room)
              (robot_has_object_recognition)
              (robot_has_label_scanner)
              (disinfectant_available)
              (detergent_available)
 )
 (:goal (and 
           (tool_cleaned broom)
        )
 )
)
