from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ToolType = UserType("ToolType")
        
        self.storage_area = Object("storage_area", self.Location)
        self.cleaning_tools_rack = Object("cleaning_tools_rack", self.Location)
        self.broom = Object("broom", self.ToolType)
        self.swab = Object("swab", self.ToolType)
        self.mop_bucket = Object("mop_bucket", self.ToolType)
        self.bucket = Object("bucket", self.ToolType)
        self.disinfectant_bottle = Object("disinfectant_bottle", self.ToolType)
        self.detergent_bottle = Object("detergent_bottle", self.ToolType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.tool_at = Fluent("tool_at", BoolType(), tool=self.ToolType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), tool=self.ToolType)
        self.tool_cleaned = Fluent("tool_cleaned", BoolType(), tool=self.ToolType)

        self.setting_is_utility_room = Fluent("setting_is_utility_room", BoolType())
        self.robot_has_object_recognition = Fluent("robot_has_object_recognition", BoolType())
        self.robot_has_label_scanner = Fluent("robot_has_label_scanner", BoolType())
        self.disinfectant_available = Fluent("disinfectant_available", BoolType())
        self.detergent_available = Fluent("detergent_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.tool_at, self.robot_has, self.tool_cleaned]
        self.context_fluents = [self.setting_is_utility_room, self.robot_has_object_recognition, self.robot_has_label_scanner, self.disinfectant_available, self.detergent_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.storage_area, self.cleaning_tools_rack, self.broom, self.swab, self.mop_bucket, self.bucket, self.disinfectant_bottle, self.detergent_bottle]

    def create_base_actions(self):
        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_area)))
        navigate_to_storage.add_effect(self.robot_at(self.cleaning_tools_rack), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_area), True)
        
        navigate_to_tools_rack = InstantaneousAction("navigate_to_tools_rack")
        navigate_to_tools_rack.add_precondition(Not(self.robot_at(self.cleaning_tools_rack)))
        navigate_to_tools_rack.add_effect(self.robot_at(self.storage_area), False)
        navigate_to_tools_rack.add_effect(self.robot_at(self.cleaning_tools_rack), True)

        grab_disinfectant = InstantaneousAction("grab_disinfectant")
        grab_disinfectant.add_precondition(self.robot_at(self.storage_area))
        grab_disinfectant.add_precondition(self.tool_at(self.disinfectant_bottle, self.storage_area))
        grab_disinfectant.add_precondition(Not(self.robot_has(self.disinfectant_bottle)))
        grab_disinfectant.add_effect(self.tool_at(self.disinfectant_bottle, self.storage_area), False)
        grab_disinfectant.add_effect(self.robot_has(self.disinfectant_bottle), True)

        grab_detergent = InstantaneousAction("grab_detergent")
        grab_detergent.add_precondition(self.robot_at(self.storage_area))
        grab_detergent.add_precondition(self.tool_at(self.detergent_bottle, self.storage_area))
        grab_detergent.add_precondition(Not(self.robot_has(self.detergent_bottle)))
        grab_detergent.add_effect(self.tool_at(self.detergent_bottle, self.storage_area), False)
        grab_detergent.add_effect(self.robot_has(self.detergent_bottle), True)

        apply_to_tool = InstantaneousAction("apply_to_tool")
        apply_to_tool.add_precondition(self.robot_at(self.cleaning_tools_rack))
        apply_to_tool.add_precondition(Or(self.robot_has(self.disinfectant_bottle), self.robot_has(self.detergent_bottle)))
        apply_to_tool.add_precondition(Not(self.tool_cleaned(self.broom)))
        apply_to_tool.add_effect(self.tool_cleaned(self.broom), True)
        apply_to_tool.add_effect(self.robot_has(self.disinfectant_bottle), False)
        apply_to_tool.add_effect(self.robot_has(self.detergent_bottle), False)

        return navigate_to_storage, navigate_to_tools_rack, grab_disinfectant, grab_detergent, apply_to_tool

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "apply_to_tool": And([
                self.robot_has(self.detergent_bottle),  # Detergent used
                Not(self.robot_has(self.disinfectant_bottle)),  # No disinfectant
                self.detergent_available,
                self.disinfectant_available,
                self.robot_has_label_scanner,  # Could have distinguished
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_area), True)
        problem.set_initial_value(self.tool_at(self.disinfectant_bottle, self.storage_area), True)
        problem.set_initial_value(self.tool_at(self.detergent_bottle, self.storage_area), True)
        problem.set_initial_value(self.tool_at(self.broom, self.cleaning_tools_rack), True)
        problem.set_initial_value(self.tool_at(self.swab, self.cleaning_tools_rack), True)
        problem.set_initial_value(self.tool_at(self.mop_bucket, self.cleaning_tools_rack), True)
        problem.set_initial_value(self.tool_at(self.bucket, self.cleaning_tools_rack), True)
        problem.set_initial_value(self.setting_is_utility_room, True)
        problem.set_initial_value(self.robot_has_object_recognition, True)
        problem.set_initial_value(self.robot_has_label_scanner, True)
        problem.set_initial_value(self.disinfectant_available, True)
        problem.set_initial_value(self.detergent_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.tool_cleaned(self.broom))

if __name__ == "__main__":
    DomainPlanner().run_cli()