(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location tooltype)
 (:constants
   storage_area cleaning_tools_rack - location
   disinfectant_bottle broom detergent_bottle - tooltype
 )
 (:predicates 
             (robot_at ?position - location)
             (tool_at ?tool - tooltype ?position - location)
             (robot_has ?tool - tooltype)
             (tool_cleaned ?tool - tooltype)
             (setting_is_utility_room)
             (robot_has_object_recognition)
             (robot_has_label_scanner)
             (disinfectant_available)
             (detergent_available)
 )
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_area)))
  :effect (and (not (robot_at cleaning_tools_rack)) (robot_at storage_area)))
 (:action navigate_to_tools_rack
  :parameters ()
  :precondition (and (not (robot_at cleaning_tools_rack)))
  :effect (and (not (robot_at storage_area)) (robot_at cleaning_tools_rack)))
 (:action grab_disinfectant
  :parameters ()
  :precondition (and (robot_at storage_area) (tool_at disinfectant_bottle storage_area) (not (robot_has disinfectant_bottle)))
  :effect (and (not (tool_at disinfectant_bottle storage_area)) (robot_has disinfectant_bottle)))
 (:action grab_detergent
  :parameters ()
  :precondition (and (robot_at storage_area) (tool_at detergent_bottle storage_area) (not (robot_has detergent_bottle)))
  :effect (and (not (tool_at detergent_bottle storage_area)) (robot_has detergent_bottle)))
 (:action apply_to_tool
  :parameters ()
  :precondition (and (robot_at cleaning_tools_rack) (or (robot_has disinfectant_bottle) (robot_has detergent_bottle)) (not (tool_cleaned broom)))
  :effect (and (tool_cleaned broom) (not (robot_has disinfectant_bottle)) (not (robot_has detergent_bottle))))
)
