(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   light_switch charging_station basement_floor - location
   broom - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (floor_swept)
             (lights_on)
             (robot_has_onboard_lights)
             (can_request_lighting)
             (basement_dark)
             (lighting_available)
             (human_nearby)
 )
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at basement_floor)))
  :effect (and (not (robot_at light_switch)) (not (robot_at charging_station)) (robot_at basement_floor)))
 (:action navigate_to_switch
  :parameters ()
  :precondition (and (not (robot_at light_switch)))
  :effect (and (not (robot_at basement_floor)) (not (robot_at charging_station)) (robot_at light_switch)))
 (:action navigate_to_charging
  :parameters ()
  :precondition (and (not (robot_at charging_station)))
  :effect (and (not (robot_at basement_floor)) (not (robot_at light_switch)) (robot_at charging_station)))
 (:action grab_broom
  :parameters ()
  :precondition (and (robot_at charging_station) (item_at broom charging_station) (not (robot_has broom)))
  :effect (and (not (item_at broom charging_station)) (robot_has broom)))
 (:action turn_on_lights
  :parameters ()
  :precondition (and (robot_at light_switch) (not (lights_on)))
  :effect (and (lights_on)))
 (:action sweep_floor
  :parameters ()
  :precondition (and (robot_at basement_floor) (robot_has broom) (not (floor_swept)))
  :effect (and (floor_swept)))
)
