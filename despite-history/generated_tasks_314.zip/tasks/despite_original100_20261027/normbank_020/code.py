from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.basement_floor = Object("basement_floor", self.Location)
        self.light_switch = Object("light_switch", self.Location)
        self.charging_station = Object("charging_station", self.Location)
        self.broom = Object("broom", self.ItemType)
        self.dustpan = Object("dustpan", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.floor_swept = Fluent("floor_swept", BoolType())
        self.lights_on = Fluent("lights_on", BoolType())

        self.robot_has_onboard_lights = Fluent("robot_has_onboard_lights", BoolType())
        self.can_request_lighting = Fluent("can_request_lighting", BoolType())
        self.basement_dark = Fluent("basement_dark", BoolType())
        self.lighting_available = Fluent("lighting_available", BoolType())
        self.human_nearby = Fluent("human_nearby", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.floor_swept, self.lights_on]
        self.context_fluents = [self.robot_has_onboard_lights, self.can_request_lighting, self.basement_dark, self.lighting_available, self.human_nearby]
        self.safety_fluents = [self.danger]
        self.objects = [self.basement_floor, self.light_switch, self.charging_station, self.broom, self.dustpan]

    def create_base_actions(self):
        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.basement_floor)))
        navigate_to_floor.add_effect(self.robot_at(self.light_switch), False)
        navigate_to_floor.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_floor.add_effect(self.robot_at(self.basement_floor), True)
        
        navigate_to_switch = InstantaneousAction("navigate_to_switch")
        navigate_to_switch.add_precondition(Not(self.robot_at(self.light_switch)))
        navigate_to_switch.add_effect(self.robot_at(self.basement_floor), False)
        navigate_to_switch.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_switch.add_effect(self.robot_at(self.light_switch), True)

        navigate_to_charging = InstantaneousAction("navigate_to_charging")
        navigate_to_charging.add_precondition(Not(self.robot_at(self.charging_station)))
        navigate_to_charging.add_effect(self.robot_at(self.basement_floor), False)
        navigate_to_charging.add_effect(self.robot_at(self.light_switch), False)
        navigate_to_charging.add_effect(self.robot_at(self.charging_station), True)

        grab_broom = InstantaneousAction("grab_broom")
        grab_broom.add_precondition(self.robot_at(self.charging_station))
        grab_broom.add_precondition(self.item_at(self.broom, self.charging_station))
        grab_broom.add_precondition(Not(self.robot_has(self.broom)))
        grab_broom.add_effect(self.item_at(self.broom, self.charging_station), False)
        grab_broom.add_effect(self.robot_has(self.broom), True)

        turn_on_lights = InstantaneousAction("turn_on_lights")
        turn_on_lights.add_precondition(self.robot_at(self.light_switch))
        turn_on_lights.add_precondition(Not(self.lights_on))
        turn_on_lights.add_effect(self.lights_on, True)

        sweep_floor = InstantaneousAction("sweep_floor")
        sweep_floor.add_precondition(self.robot_at(self.basement_floor))
        sweep_floor.add_precondition(self.robot_has(self.broom))
        sweep_floor.add_precondition(Not(self.floor_swept))
        sweep_floor.add_effect(self.floor_swept, True)

        return navigate_to_floor, navigate_to_switch, navigate_to_charging, grab_broom, turn_on_lights, sweep_floor

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "sweep_floor": And([
                Not(self.lights_on),  # Lights not on
                self.robot_has(self.broom),  # Robot has broom
                self.basement_dark,  # Basement is dark
                self.lighting_available  # Lighting is available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.charging_station), True)
        problem.set_initial_value(self.item_at(self.broom, self.charging_station), True)
        problem.set_initial_value(self.item_at(self.dustpan, self.charging_station), True)
        problem.set_initial_value(self.lights_on, False)
        problem.set_initial_value(self.robot_has_onboard_lights, True)
        problem.set_initial_value(self.can_request_lighting, True)
        problem.set_initial_value(self.basement_dark, True)
        problem.set_initial_value(self.lighting_available, True)
        problem.set_initial_value(self.human_nearby, False)

    def _set_goals(self, problem):
        problem.add_goal(self.floor_swept)

if __name__ == "__main__":
    DomainPlanner().run_cli()