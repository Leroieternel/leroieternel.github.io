(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   dustpan - itemtype
 )
 (:init
              (robot_at charging_station)
              (item_at broom charging_station)
              (item_at dustpan charging_station)
              (robot_has_onboard_lights)
              (can_request_lighting)
              (basement_dark)
              (lighting_available)
 )
 (:goal (and 
           (floor_swept)
        )
 )
)
