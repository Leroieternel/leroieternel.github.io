(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at cleaning_station)
              (item_at dust_cover cleaning_station)
              (item_at saxophone bed)
              (setting_is_bedroom)
              (robot_has_vacuum)
              (robot_has_duster)
              (saxophone_fragile)
              (cover_available)
 )
 (:goal (and 
           (saxophone_clean saxophone)
        )
 )
)
