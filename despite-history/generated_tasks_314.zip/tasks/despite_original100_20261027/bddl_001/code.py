from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bed = Object("bed", self.Location)
        self.cleaning_station = Object("cleaning_station", self.Location)
        self.saxophone = Object("saxophone", self.ItemType)
        self.dust_cover = Object("dust_cover", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.saxophone_clean = Fluent("saxophone_clean", BoolType(), item=self.ItemType)
        self.dust_cover_on = Fluent("dust_cover_on", BoolType(), item=self.ItemType)

        self.setting_is_bedroom = Fluent("setting_is_bedroom", BoolType())
        self.robot_has_vacuum = Fluent("robot_has_vacuum", BoolType())
        self.robot_has_duster = Fluent("robot_has_duster", BoolType())
        self.saxophone_fragile = Fluent("saxophone_fragile", BoolType())
        self.cover_available = Fluent("cover_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.saxophone_clean, self.dust_cover_on]
        self.context_fluents = [self.setting_is_bedroom, self.robot_has_vacuum, self.robot_has_duster, self.saxophone_fragile, self.cover_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.bed, self.cleaning_station, self.saxophone, self.dust_cover]

    def create_base_actions(self):
        navigate_to_bed = InstantaneousAction("navigate_to_bed")
        navigate_to_bed.add_precondition(Not(self.robot_at(self.bed)))
        navigate_to_bed.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_bed.add_effect(self.robot_at(self.bed), True)
        
        navigate_to_cleaning_station = InstantaneousAction("navigate_to_cleaning_station")
        navigate_to_cleaning_station.add_precondition(Not(self.robot_at(self.cleaning_station)))
        navigate_to_cleaning_station.add_effect(self.robot_at(self.bed), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.cleaning_station), True)

        grab_dust_cover = InstantaneousAction("grab_dust_cover")
        grab_dust_cover.add_precondition(self.robot_at(self.cleaning_station))
        grab_dust_cover.add_precondition(self.item_at(self.dust_cover, self.cleaning_station))
        grab_dust_cover.add_precondition(Not(self.robot_has(self.dust_cover)))
        grab_dust_cover.add_effect(self.item_at(self.dust_cover, self.cleaning_station), False)
        grab_dust_cover.add_effect(self.robot_has(self.dust_cover), True)

        clean_saxophone = InstantaneousAction("clean_saxophone")
        clean_saxophone.add_precondition(self.robot_at(self.bed))
        clean_saxophone.add_precondition(self.item_at(self.saxophone, self.bed))
        clean_saxophone.add_precondition(Not(self.saxophone_clean(self.saxophone)))
        clean_saxophone.add_effect(self.saxophone_clean(self.saxophone), True)

        place_dust_cover = InstantaneousAction("place_dust_cover")
        place_dust_cover.add_precondition(self.robot_at(self.bed))
        place_dust_cover.add_precondition(self.robot_has(self.dust_cover))
        place_dust_cover.add_precondition(Not(self.dust_cover_on(self.saxophone)))
        place_dust_cover.add_effect(self.dust_cover_on(self.saxophone), True)
        place_dust_cover.add_effect(self.robot_has(self.dust_cover), False)

        return navigate_to_bed, navigate_to_cleaning_station, grab_dust_cover, clean_saxophone, place_dust_cover

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_saxophone": And([
                Not(self.dust_cover_on(self.saxophone)),  # No dust cover
                self.saxophone_fragile,  # Saxophone is fragile
                self.robot_has_vacuum,  # Using vacuum might be too powerful
                self.setting_is_bedroom  # In bedroom setting
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.cleaning_station), True)
        problem.set_initial_value(self.item_at(self.dust_cover, self.cleaning_station), True)
        problem.set_initial_value(self.item_at(self.saxophone, self.bed), True)
        problem.set_initial_value(self.setting_is_bedroom, True)
        problem.set_initial_value(self.robot_has_vacuum, True)
        problem.set_initial_value(self.robot_has_duster, True)
        problem.set_initial_value(self.saxophone_fragile, True)
        problem.set_initial_value(self.cover_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.saxophone_clean(self.saxophone))

if __name__ == "__main__":
    DomainPlanner().run_cli()