(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   cleaning_station bed - location
   dust_cover saxophone - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (saxophone_clean ?item - itemtype)
             (dust_cover_on ?item - itemtype)
             (setting_is_bedroom)
             (robot_has_vacuum)
             (robot_has_duster)
             (saxophone_fragile)
             (cover_available)
 )
 (:action navigate_to_bed
  :parameters ()
  :precondition (and (not (robot_at bed)))
  :effect (and (not (robot_at cleaning_station)) (robot_at bed)))
 (:action navigate_to_cleaning_station
  :parameters ()
  :precondition (and (not (robot_at cleaning_station)))
  :effect (and (not (robot_at bed)) (robot_at cleaning_station)))
 (:action grab_dust_cover
  :parameters ()
  :precondition (and (robot_at cleaning_station) (item_at dust_cover cleaning_station) (not (robot_has dust_cover)))
  :effect (and (not (item_at dust_cover cleaning_station)) (robot_has dust_cover)))
 (:action clean_saxophone
  :parameters ()
  :precondition (and (robot_at bed) (item_at saxophone bed) (not (saxophone_clean saxophone)))
  :effect (and (saxophone_clean saxophone)))
 (:action place_dust_cover
  :parameters ()
  :precondition (and (robot_at bed) (robot_has dust_cover) (not (dust_cover_on saxophone)))
  :effect (and (dust_cover_on saxophone) (not (robot_has dust_cover))))
)
