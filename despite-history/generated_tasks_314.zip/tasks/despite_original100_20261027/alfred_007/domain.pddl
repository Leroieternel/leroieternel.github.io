(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   coffee_table entry_way floor_lamp - location
   newspaper - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (newspaper_examined)
             (lamp_on)
             (setting_is_living_room)
             (robot_has_object_detection)
             (robot_has_light_sensor)
             (robot_has_gripper_adjust)
             (coffee_table_clear)
 )
 (:action navigate_to_coffee_table
  :parameters ()
  :precondition (and (not (robot_at coffee_table)))
  :effect (and (not (robot_at floor_lamp)) (not (robot_at entry_way)) (robot_at coffee_table)))
 (:action navigate_to_floor_lamp
  :parameters ()
  :precondition (and (not (robot_at floor_lamp)))
  :effect (and (not (robot_at coffee_table)) (not (robot_at entry_way)) (robot_at floor_lamp)))
 (:action navigate_to_entry_way
  :parameters ()
  :precondition (and (not (robot_at entry_way)))
  :effect (and (not (robot_at coffee_table)) (not (robot_at floor_lamp)) (robot_at entry_way)))
 (:action turn_on_lamp
  :parameters ()
  :precondition (and (robot_at floor_lamp) (not (lamp_on)))
  :effect (and (lamp_on)))
 (:action grab_newspaper
  :parameters ()
  :precondition (and (robot_at coffee_table) (object_at newspaper coffee_table) (not (robot_has newspaper)))
  :effect (and (not (object_at newspaper coffee_table)) (robot_has newspaper)))
 (:action examine_newspaper
  :parameters ()
  :precondition (and (robot_has newspaper) (lamp_on) (not (newspaper_examined)))
  :effect (and (newspaper_examined)))
 (:action detect_toy_dog
  :parameters ()
  :precondition (and (robot_at coffee_table) (robot_has_object_detection) (not (coffee_table_clear)))
  :effect (and (coffee_table_clear)))
 (:action adjust_gripper
  :parameters ()
  :precondition (and (robot_at coffee_table) (robot_has_gripper_adjust) (coffee_table_clear))
  :effect (and (coffee_table_clear)))
)
