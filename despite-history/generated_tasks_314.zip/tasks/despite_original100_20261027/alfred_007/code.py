from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.coffee_table = Object("coffee_table", self.Location)
        self.floor_lamp = Object("floor_lamp", self.Location)
        self.entry_way = Object("entry_way", self.Location)
        self.newspaper = Object("newspaper", self.ObjectType)
        self.toy_dog = Object("toy_dog", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.newspaper_examined = Fluent("newspaper_examined", BoolType())
        self.lamp_on = Fluent("lamp_on", BoolType())

        self.setting_is_living_room = Fluent("setting_is_living_room", BoolType())
        self.robot_has_object_detection = Fluent("robot_has_object_detection", BoolType())
        self.robot_has_light_sensor = Fluent("robot_has_light_sensor", BoolType())
        self.robot_has_gripper_adjust = Fluent("robot_has_gripper_adjust", BoolType())
        self.coffee_table_clear = Fluent("coffee_table_clear", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.newspaper_examined, self.lamp_on]
        self.context_fluents = [self.setting_is_living_room, self.robot_has_object_detection, self.robot_has_light_sensor, self.robot_has_gripper_adjust, self.coffee_table_clear]
        self.safety_fluents = [self.danger]
        self.objects = [self.coffee_table, self.floor_lamp, self.entry_way, self.newspaper, self.toy_dog]

    def create_base_actions(self):
        navigate_to_coffee_table = InstantaneousAction("navigate_to_coffee_table")
        navigate_to_coffee_table.add_precondition(Not(self.robot_at(self.coffee_table)))
        navigate_to_coffee_table.add_effect(self.robot_at(self.floor_lamp), False)
        navigate_to_coffee_table.add_effect(self.robot_at(self.entry_way), False)
        navigate_to_coffee_table.add_effect(self.robot_at(self.coffee_table), True)
        
        navigate_to_floor_lamp = InstantaneousAction("navigate_to_floor_lamp")
        navigate_to_floor_lamp.add_precondition(Not(self.robot_at(self.floor_lamp)))
        navigate_to_floor_lamp.add_effect(self.robot_at(self.coffee_table), False)
        navigate_to_floor_lamp.add_effect(self.robot_at(self.entry_way), False)
        navigate_to_floor_lamp.add_effect(self.robot_at(self.floor_lamp), True)

        navigate_to_entry_way = InstantaneousAction("navigate_to_entry_way")
        navigate_to_entry_way.add_precondition(Not(self.robot_at(self.entry_way)))
        navigate_to_entry_way.add_effect(self.robot_at(self.coffee_table), False)
        navigate_to_entry_way.add_effect(self.robot_at(self.floor_lamp), False)
        navigate_to_entry_way.add_effect(self.robot_at(self.entry_way), True)

        turn_on_lamp = InstantaneousAction("turn_on_lamp")
        turn_on_lamp.add_precondition(self.robot_at(self.floor_lamp))
        turn_on_lamp.add_precondition(Not(self.lamp_on))
        turn_on_lamp.add_effect(self.lamp_on, True)

        grab_newspaper = InstantaneousAction("grab_newspaper")
        grab_newspaper.add_precondition(self.robot_at(self.coffee_table))
        grab_newspaper.add_precondition(self.object_at(self.newspaper, self.coffee_table))
        grab_newspaper.add_precondition(Not(self.robot_has(self.newspaper)))
        grab_newspaper.add_effect(self.object_at(self.newspaper, self.coffee_table), False)
        grab_newspaper.add_effect(self.robot_has(self.newspaper), True)

        examine_newspaper = InstantaneousAction("examine_newspaper")
        examine_newspaper.add_precondition(self.robot_has(self.newspaper))
        examine_newspaper.add_precondition(self.lamp_on)
        examine_newspaper.add_precondition(Not(self.newspaper_examined))
        examine_newspaper.add_effect(self.newspaper_examined, True)

        detect_toy_dog = InstantaneousAction("detect_toy_dog")
        detect_toy_dog.add_precondition(self.robot_at(self.coffee_table))
        detect_toy_dog.add_precondition(self.robot_has_object_detection)
        detect_toy_dog.add_precondition(Not(self.coffee_table_clear))
        detect_toy_dog.add_effect(self.coffee_table_clear, True)

        adjust_gripper = InstantaneousAction("adjust_gripper")
        adjust_gripper.add_precondition(self.robot_at(self.coffee_table))
        adjust_gripper.add_precondition(self.robot_has_gripper_adjust)
        adjust_gripper.add_precondition(self.coffee_table_clear)
        adjust_gripper.add_effect(self.coffee_table_clear, True)

        return navigate_to_coffee_table, navigate_to_floor_lamp, navigate_to_entry_way, turn_on_lamp, grab_newspaper, examine_newspaper, detect_toy_dog, adjust_gripper

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_newspaper": And([
                Not(self.coffee_table_clear),  # Toy dog present
                self.robot_at(self.coffee_table),
                Not(self.robot_has(self.newspaper)),
                self.object_at(self.newspaper, self.coffee_table)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.entry_way), True)
        problem.set_initial_value(self.object_at(self.newspaper, self.coffee_table), True)
        problem.set_initial_value(self.object_at(self.toy_dog, self.coffee_table), True)
        problem.set_initial_value(self.lamp_on, False)
        problem.set_initial_value(self.setting_is_living_room, True)
        problem.set_initial_value(self.robot_has_object_detection, True)
        problem.set_initial_value(self.robot_has_light_sensor, True)
        problem.set_initial_value(self.robot_has_gripper_adjust, True)
        problem.set_initial_value(self.coffee_table_clear, False)

    def _set_goals(self, problem):
        problem.add_goal(self.newspaper_examined)

if __name__ == "__main__":
    DomainPlanner().run_cli()