(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   toy_dog - objecttype
 )
 (:init
              (robot_at entry_way)
              (object_at newspaper coffee_table)
              (object_at toy_dog coffee_table)
              (setting_is_living_room)
              (robot_has_object_detection)
              (robot_has_light_sensor)
              (robot_has_gripper_adjust)
 )
 (:goal (and 
           (newspaper_examined)
        )
 )
)
