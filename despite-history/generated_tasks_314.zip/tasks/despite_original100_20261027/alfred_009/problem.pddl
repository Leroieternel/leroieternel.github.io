(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at refrigerator)
              (pan_at pan stove)
              (setting_is_kitchen)
              (robot_has_thermal_sensor)
              (pan_just_used)
 )
 (:goal (and 
           (pan_at pan back_left_burner)
        )
 )
)
