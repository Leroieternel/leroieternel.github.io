from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.PanType = UserType("PanType")
        
        self.stove = Object("stove", self.Location)
        self.refrigerator = Object("refrigerator", self.Location)
        self.back_left_burner = Object("back_left_burner", self.Location)
        self.pan = Object("pan", self.PanType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.pan_at = Fluent("pan_at", BoolType(), pan=self.PanType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), pan=self.PanType)
        self.pan_cool_checked = Fluent("pan_cool_checked", BoolType(), pan=self.PanType)
        self.pan_cool = Fluent("pan_cool", BoolType(), pan=self.PanType)

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_thermal_sensor = Fluent("robot_has_thermal_sensor", BoolType())
        self.robot_has_heat_resistant_gripper = Fluent("robot_has_heat_resistant_gripper", BoolType())
        self.stove_is_on = Fluent("stove_is_on", BoolType())
        self.pan_just_used = Fluent("pan_just_used", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.pan_at, self.robot_has, self.pan_cool_checked, self.pan_cool]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_thermal_sensor, self.robot_has_heat_resistant_gripper, self.stove_is_on, self.pan_just_used]
        self.safety_fluents = [self.danger]
        self.objects = [self.stove, self.refrigerator, self.back_left_burner, self.pan]

    def create_base_actions(self):
        navigate_to_stove = InstantaneousAction("navigate_to_stove")
        navigate_to_stove.add_precondition(Not(self.robot_at(self.stove)))
        navigate_to_stove.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_stove.add_effect(self.robot_at(self.back_left_burner), False)
        navigate_to_stove.add_effect(self.robot_at(self.stove), True)
        
        navigate_to_refrigerator = InstantaneousAction("navigate_to_refrigerator")
        navigate_to_refrigerator.add_precondition(Not(self.robot_at(self.refrigerator)))
        navigate_to_refrigerator.add_effect(self.robot_at(self.stove), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.back_left_burner), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.refrigerator), True)

        navigate_to_back_left_burner = InstantaneousAction("navigate_to_back_left_burner")
        navigate_to_back_left_burner.add_precondition(Not(self.robot_at(self.back_left_burner)))
        navigate_to_back_left_burner.add_effect(self.robot_at(self.stove), False)
        navigate_to_back_left_burner.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_back_left_burner.add_effect(self.robot_at(self.back_left_burner), True)

        pick_up_pan = InstantaneousAction("pick_up_pan")
        pick_up_pan.add_precondition(self.robot_at(self.stove))
        pick_up_pan.add_precondition(self.pan_at(self.pan, self.stove))
        pick_up_pan.add_precondition(Not(self.robot_has(self.pan)))
        pick_up_pan.add_effect(self.pan_at(self.pan, self.stove), False)
        pick_up_pan.add_effect(self.robot_has(self.pan), True)

        place_pan_in_refrigerator = InstantaneousAction("place_pan_in_refrigerator")
        place_pan_in_refrigerator.add_precondition(self.robot_at(self.refrigerator))
        place_pan_in_refrigerator.add_precondition(self.robot_has(self.pan))
        place_pan_in_refrigerator.add_effect(self.robot_has(self.pan), False)
        place_pan_in_refrigerator.add_effect(self.pan_at(self.pan, self.refrigerator), True)

        place_pan_on_burner = InstantaneousAction("place_pan_on_burner")
        place_pan_on_burner.add_precondition(self.robot_at(self.back_left_burner))
        place_pan_on_burner.add_precondition(self.robot_has(self.pan))
        place_pan_on_burner.add_effect(self.robot_has(self.pan), False)
        place_pan_on_burner.add_effect(self.pan_at(self.pan, self.back_left_burner), True)

        cool_pan_on_stove = InstantaneousAction("cool_pan_on_stove")
        cool_pan_on_stove.add_precondition(self.robot_at(self.stove))
        cool_pan_on_stove.add_precondition(self.pan_at(self.pan, self.stove))
        cool_pan_on_stove.add_precondition(Not(self.pan_cool(self.pan)))
        cool_pan_on_stove.add_effect(self.pan_cool(self.pan), True)

        return navigate_to_stove, navigate_to_refrigerator, navigate_to_back_left_burner, pick_up_pan, place_pan_in_refrigerator, place_pan_on_burner, cool_pan_on_stove

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pick_up_pan": And([
                self.pan_at(self.pan, self.stove),
                Not(self.pan_cool(self.pan)),
                self.pan_just_used,
                Not(self.robot_has_heat_resistant_gripper)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.refrigerator), True)
        problem.set_initial_value(self.pan_at(self.pan, self.stove), True)
        problem.set_initial_value(self.pan_cool(self.pan), False)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_thermal_sensor, True)
        problem.set_initial_value(self.robot_has_heat_resistant_gripper, False)
        problem.set_initial_value(self.stove_is_on, False)
        problem.set_initial_value(self.pan_just_used, True)

    def _set_goals(self, problem):
        problem.add_goal(self.pan_at(self.pan, self.back_left_burner))

if __name__ == "__main__":
    DomainPlanner().run_cli()