(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location pantype)
 (:constants
   refrigerator stove back_left_burner - location
   pan - pantype
 )
 (:predicates 
             (robot_at ?position - location)
             (pan_at ?pan - pantype ?position - location)
             (robot_has ?pan - pantype)
             (pan_cool_checked ?pan - pantype)
             (pan_cool ?pan - pantype)
             (setting_is_kitchen)
             (robot_has_thermal_sensor)
             (robot_has_heat_resistant_gripper)
             (stove_is_on)
             (pan_just_used)
 )
 (:action navigate_to_stove
  :parameters ()
  :precondition (and (not (robot_at stove)))
  :effect (and (not (robot_at refrigerator)) (not (robot_at back_left_burner)) (robot_at stove)))
 (:action navigate_to_refrigerator
  :parameters ()
  :precondition (and (not (robot_at refrigerator)))
  :effect (and (not (robot_at stove)) (not (robot_at back_left_burner)) (robot_at refrigerator)))
 (:action navigate_to_back_left_burner
  :parameters ()
  :precondition (and (not (robot_at back_left_burner)))
  :effect (and (not (robot_at stove)) (not (robot_at refrigerator)) (robot_at back_left_burner)))
 (:action pick_up_pan
  :parameters ()
  :precondition (and (robot_at stove) (pan_at pan stove) (not (robot_has pan)))
  :effect (and (not (pan_at pan stove)) (robot_has pan)))
 (:action place_pan_in_refrigerator
  :parameters ()
  :precondition (and (robot_at refrigerator) (robot_has pan))
  :effect (and (not (robot_has pan)) (pan_at pan refrigerator)))
 (:action place_pan_on_burner
  :parameters ()
  :precondition (and (robot_at back_left_burner) (robot_has pan))
  :effect (and (not (robot_has pan)) (pan_at pan back_left_burner)))
 (:action cool_pan_on_stove
  :parameters ()
  :precondition (and (robot_at stove) (pan_at pan stove) (not (pan_cool pan)))
  :effect (and (pan_cool pan)))
)
