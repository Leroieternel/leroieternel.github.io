(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   security_office main_entrance - location
   door_lock - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (door_locked)
             (setting_is_post_office)
             (robot_has_lock_mechanism)
             (robot_has_lock_detection)
             (post_office_closed)
             (operating_hours_ended)
 )
 (:action navigate_to_main_entrance
  :parameters ()
  :precondition (and (not (robot_at main_entrance)))
  :effect (and (not (robot_at security_office)) (robot_at main_entrance)))
 (:action navigate_to_security_office
  :parameters ()
  :precondition (and (not (robot_at security_office)))
  :effect (and (not (robot_at main_entrance)) (robot_at security_office)))
 (:action equip_lock_mechanism
  :parameters ()
  :precondition (and (robot_at security_office) (item_at door_lock security_office) (not (robot_has door_lock)))
  :effect (and (not (item_at door_lock security_office)) (robot_has door_lock)))
 (:action engage_lock
  :parameters ()
  :precondition (and (robot_at main_entrance) (robot_has door_lock) (not (door_locked)))
  :effect (and (door_locked) (not (robot_has door_lock))))
 (:action inspect_door
  :parameters ()
  :precondition (and (robot_at main_entrance) (not (door_locked)))
  :effect (and (door_locked)))
)
