(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at security_office)
              (item_at door_lock security_office)
              (setting_is_post_office)
              (robot_has_lock_mechanism)
              (robot_has_lock_detection)
              (post_office_closed)
              (operating_hours_ended)
 )
 (:goal (and 
           (door_locked)
        )
 )
)
