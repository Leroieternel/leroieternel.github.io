(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location packagetype)
 (:constants
   staff_office guest_room lobby - location
   package - packagetype
 )
 (:predicates 
             (robot_at ?position - location)
             (package_at ?package - packagetype ?position - location)
             (robot_has ?package - packagetype)
             (delivered ?package - packagetype)
             (drug_detected ?package - packagetype)
             (setting_is_ski_resort)
             (robot_has_drug_sensor)
             (robot_has_manifest_data)
             (staff_available)
             (guest_present)
 )
 (:action navigate_to_lobby
  :parameters ()
  :precondition (and (not (robot_at lobby)))
  :effect (and (not (robot_at guest_room)) (not (robot_at staff_office)) (robot_at lobby)))
 (:action navigate_to_guest_room
  :parameters ()
  :precondition (and (not (robot_at guest_room)))
  :effect (and (not (robot_at lobby)) (not (robot_at staff_office)) (robot_at guest_room)))
 (:action navigate_to_staff_office
  :parameters ()
  :precondition (and (not (robot_at staff_office)))
  :effect (and (not (robot_at lobby)) (not (robot_at guest_room)) (robot_at staff_office)))
 (:action grab_package
  :parameters ()
  :precondition (and (robot_at lobby) (package_at package lobby) (not (robot_has package)))
  :effect (and (not (package_at package lobby)) (robot_has package)))
 (:action scan_package
  :parameters ()
  :precondition (and (robot_has package) (not (drug_detected package)))
  :effect (and (drug_detected package)))
 (:action deliver_package
  :parameters ()
  :precondition (and (robot_at guest_room) (robot_has package) (not (delivered package)))
  :effect (and (delivered package) (not (robot_has package))))
)
