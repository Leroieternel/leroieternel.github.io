from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.PackageType = UserType("PackageType")
        
        self.lobby = Object("lobby", self.Location)
        self.guest_room = Object("guest_room", self.Location)
        self.staff_office = Object("staff_office", self.Location)
        self.package = Object("package", self.PackageType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.package_at = Fluent("package_at", BoolType(), package=self.PackageType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), package=self.PackageType)
        self.delivered = Fluent("delivered", BoolType(), package=self.PackageType)
        self.drug_detected = Fluent("drug_detected", BoolType(), package=self.PackageType)

        self.setting_is_ski_resort = Fluent("setting_is_ski_resort", BoolType())
        self.robot_has_drug_sensor = Fluent("robot_has_drug_sensor", BoolType())
        self.robot_has_manifest_data = Fluent("robot_has_manifest_data", BoolType())
        self.staff_available = Fluent("staff_available", BoolType())
        self.guest_present = Fluent("guest_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.package_at, self.robot_has, self.delivered, self.drug_detected]
        self.context_fluents = [self.setting_is_ski_resort, self.robot_has_drug_sensor, self.robot_has_manifest_data, self.staff_available, self.guest_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.lobby, self.guest_room, self.staff_office, self.package]

    def create_base_actions(self):
        navigate_to_lobby = InstantaneousAction("navigate_to_lobby")
        navigate_to_lobby.add_precondition(Not(self.robot_at(self.lobby)))
        navigate_to_lobby.add_effect(self.robot_at(self.guest_room), False)
        navigate_to_lobby.add_effect(self.robot_at(self.staff_office), False)
        navigate_to_lobby.add_effect(self.robot_at(self.lobby), True)
        
        navigate_to_guest_room = InstantaneousAction("navigate_to_guest_room")
        navigate_to_guest_room.add_precondition(Not(self.robot_at(self.guest_room)))
        navigate_to_guest_room.add_effect(self.robot_at(self.lobby), False)
        navigate_to_guest_room.add_effect(self.robot_at(self.staff_office), False)
        navigate_to_guest_room.add_effect(self.robot_at(self.guest_room), True)

        navigate_to_staff_office = InstantaneousAction("navigate_to_staff_office")
        navigate_to_staff_office.add_precondition(Not(self.robot_at(self.staff_office)))
        navigate_to_staff_office.add_effect(self.robot_at(self.lobby), False)
        navigate_to_staff_office.add_effect(self.robot_at(self.guest_room), False)
        navigate_to_staff_office.add_effect(self.robot_at(self.staff_office), True)

        grab_package = InstantaneousAction("grab_package")
        grab_package.add_precondition(self.robot_at(self.lobby))
        grab_package.add_precondition(self.package_at(self.package, self.lobby))
        grab_package.add_precondition(Not(self.robot_has(self.package)))
        grab_package.add_effect(self.package_at(self.package, self.lobby), False)
        grab_package.add_effect(self.robot_has(self.package), True)

        scan_package = InstantaneousAction("scan_package")
        scan_package.add_precondition(self.robot_has(self.package))
        scan_package.add_precondition(Not(self.drug_detected(self.package)))
        scan_package.add_effect(self.drug_detected(self.package), True)

        deliver_package = InstantaneousAction("deliver_package")
        deliver_package.add_precondition(self.robot_at(self.guest_room))
        deliver_package.add_precondition(self.robot_has(self.package))
        deliver_package.add_precondition(Not(self.delivered(self.package)))
        deliver_package.add_effect(self.delivered(self.package), True)
        deliver_package.add_effect(self.robot_has(self.package), False)

        return navigate_to_lobby, navigate_to_guest_room, navigate_to_staff_office, grab_package, scan_package, deliver_package

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "deliver_package": And([
                Not(self.drug_detected(self.package)),  # Drug not detected
                self.robot_has(self.package),  # Robot has package
                self.guest_present,  # Guest is present
                self.robot_has_drug_sensor  # Robot has drug sensor
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.lobby), True)
        problem.set_initial_value(self.package_at(self.package, self.lobby), True)
        problem.set_initial_value(self.setting_is_ski_resort, True)
        problem.set_initial_value(self.robot_has_drug_sensor, True)
        problem.set_initial_value(self.robot_has_manifest_data, True)
        problem.set_initial_value(self.staff_available, True)
        problem.set_initial_value(self.guest_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.delivered(self.package))

if __name__ == "__main__":
    DomainPlanner().run_cli()