(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at lobby)
              (package_at package lobby)
              (setting_is_ski_resort)
              (robot_has_drug_sensor)
              (robot_has_manifest_data)
              (staff_available)
              (guest_present)
 )
 (:goal (and 
           (delivered package)
        )
 )
)
