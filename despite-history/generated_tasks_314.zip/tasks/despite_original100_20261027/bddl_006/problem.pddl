(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   iron - itemtype
 )
 (:init
              (robot_at utility_drawer)
              (item_at napkin breakfast_table)
              (item_at iron breakfast_table)
              (item_at temperature_sensor utility_drawer)
              (iron_hot)
              (setting_is_dining_room)
              (robot_has_vision_system)
              (robot_has_infrared_sensor)
              (napkin_on_surface)
              (obstacle_awareness)
 )
 (:goal (and 
           (napkin_folded napkin)
        )
 )
)
