(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   ironing_board utility_drawer breakfast_table - location
   temperature_sensor napkin - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (napkin_folded ?item - itemtype)
             (iron_hot)
             (sensor_equipped)
             (iron_detected)
             (setting_is_dining_room)
             (robot_has_vision_system)
             (robot_has_infrared_sensor)
             (napkin_on_surface)
             (obstacle_awareness)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at breakfast_table)))
  :effect (and (not (robot_at ironing_board)) (not (robot_at utility_drawer)) (robot_at breakfast_table)))
 (:action navigate_to_ironing_board
  :parameters ()
  :precondition (and (not (robot_at ironing_board)))
  :effect (and (not (robot_at breakfast_table)) (not (robot_at utility_drawer)) (robot_at ironing_board)))
 (:action navigate_to_drawer
  :parameters ()
  :precondition (and (not (robot_at utility_drawer)))
  :effect (and (not (robot_at breakfast_table)) (not (robot_at ironing_board)) (robot_at utility_drawer)))
 (:action grab_napkin
  :parameters ()
  :precondition (and (robot_at breakfast_table) (item_at napkin breakfast_table) (not (robot_has napkin)))
  :effect (and (not (item_at napkin breakfast_table)) (robot_has napkin)))
 (:action fold_napkin
  :parameters ()
  :precondition (and (robot_has napkin) (not (napkin_folded napkin)))
  :effect (and (napkin_folded napkin)))
 (:action equip_sensor
  :parameters ()
  :precondition (and (robot_at utility_drawer) (item_at temperature_sensor utility_drawer) (not (sensor_equipped)))
  :effect (and (sensor_equipped)))
 (:action scan_for_iron
  :parameters ()
  :precondition (and (robot_at breakfast_table) (sensor_equipped) (not (iron_detected)))
  :effect (and (iron_detected)))
)
