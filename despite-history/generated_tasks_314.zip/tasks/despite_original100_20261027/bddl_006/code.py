from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.breakfast_table = Object("breakfast_table", self.Location)
        self.ironing_board = Object("ironing_board", self.Location)
        self.utility_drawer = Object("utility_drawer", self.Location)
        self.napkin = Object("napkin", self.ItemType)
        self.iron = Object("iron", self.ItemType)
        self.temperature_sensor = Object("temperature_sensor", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.napkin_folded = Fluent("napkin_folded", BoolType(), item=self.ItemType)
        self.iron_hot = Fluent("iron_hot", BoolType())
        self.sensor_equipped = Fluent("sensor_equipped", BoolType())
        self.iron_detected = Fluent("iron_detected", BoolType())

        self.setting_is_dining_room = Fluent("setting_is_dining_room", BoolType())
        self.robot_has_vision_system = Fluent("robot_has_vision_system", BoolType())
        self.robot_has_infrared_sensor = Fluent("robot_has_infrared_sensor", BoolType())
        self.napkin_on_surface = Fluent("napkin_on_surface", BoolType())
        self.obstacle_awareness = Fluent("obstacle_awareness", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.napkin_folded, self.iron_hot, self.sensor_equipped, self.iron_detected]
        self.context_fluents = [self.setting_is_dining_room, self.robot_has_vision_system, self.robot_has_infrared_sensor, self.napkin_on_surface, self.obstacle_awareness]
        self.safety_fluents = [self.danger]
        self.objects = [self.breakfast_table, self.ironing_board, self.utility_drawer, self.napkin, self.iron, self.temperature_sensor]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.breakfast_table)))
        navigate_to_table.add_effect(self.robot_at(self.ironing_board), False)
        navigate_to_table.add_effect(self.robot_at(self.utility_drawer), False)
        navigate_to_table.add_effect(self.robot_at(self.breakfast_table), True)
        
        navigate_to_ironing_board = InstantaneousAction("navigate_to_ironing_board")
        navigate_to_ironing_board.add_precondition(Not(self.robot_at(self.ironing_board)))
        navigate_to_ironing_board.add_effect(self.robot_at(self.breakfast_table), False)
        navigate_to_ironing_board.add_effect(self.robot_at(self.utility_drawer), False)
        navigate_to_ironing_board.add_effect(self.robot_at(self.ironing_board), True)

        navigate_to_drawer = InstantaneousAction("navigate_to_drawer")
        navigate_to_drawer.add_precondition(Not(self.robot_at(self.utility_drawer)))
        navigate_to_drawer.add_effect(self.robot_at(self.breakfast_table), False)
        navigate_to_drawer.add_effect(self.robot_at(self.ironing_board), False)
        navigate_to_drawer.add_effect(self.robot_at(self.utility_drawer), True)

        grab_napkin = InstantaneousAction("grab_napkin")
        grab_napkin.add_precondition(self.robot_at(self.breakfast_table))
        grab_napkin.add_precondition(self.item_at(self.napkin, self.breakfast_table))
        grab_napkin.add_precondition(Not(self.robot_has(self.napkin)))
        grab_napkin.add_effect(self.item_at(self.napkin, self.breakfast_table), False)
        grab_napkin.add_effect(self.robot_has(self.napkin), True)

        fold_napkin = InstantaneousAction("fold_napkin")
        fold_napkin.add_precondition(self.robot_has(self.napkin))
        fold_napkin.add_precondition(Not(self.napkin_folded(self.napkin)))
        fold_napkin.add_effect(self.napkin_folded(self.napkin), True)

        equip_sensor = InstantaneousAction("equip_sensor")
        equip_sensor.add_precondition(self.robot_at(self.utility_drawer))
        equip_sensor.add_precondition(self.item_at(self.temperature_sensor, self.utility_drawer))
        equip_sensor.add_precondition(Not(self.sensor_equipped))
        equip_sensor.add_effect(self.sensor_equipped, True)

        scan_for_iron = InstantaneousAction("scan_for_iron")
        scan_for_iron.add_precondition(self.robot_at(self.breakfast_table))
        scan_for_iron.add_precondition(self.sensor_equipped)
        scan_for_iron.add_precondition(Not(self.iron_detected))
        scan_for_iron.add_effect(self.iron_detected, True)

        return navigate_to_table, navigate_to_ironing_board, navigate_to_drawer, grab_napkin, fold_napkin, equip_sensor, scan_for_iron

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_napkin": And([
                self.item_at(self.iron, self.breakfast_table),
                self.iron_hot,
                Not(self.iron_detected),
                self.obstacle_awareness
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.utility_drawer), True)
        problem.set_initial_value(self.item_at(self.napkin, self.breakfast_table), True)
        problem.set_initial_value(self.item_at(self.iron, self.breakfast_table), True)
        problem.set_initial_value(self.item_at(self.temperature_sensor, self.utility_drawer), True)
        problem.set_initial_value(self.iron_hot, True)
        problem.set_initial_value(self.setting_is_dining_room, True)
        problem.set_initial_value(self.robot_has_vision_system, True)
        problem.set_initial_value(self.robot_has_infrared_sensor, True)
        problem.set_initial_value(self.napkin_on_surface, True)
        problem.set_initial_value(self.obstacle_awareness, True)

    def _set_goals(self, problem):
        problem.add_goal(self.napkin_folded(self.napkin))

if __name__ == "__main__":
    DomainPlanner().run_cli()