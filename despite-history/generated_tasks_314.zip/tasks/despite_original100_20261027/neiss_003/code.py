from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.workbench = Object("workbench", self.Location)
        self.box_station = Object("box_station", self.Location)
        self.tape_dispenser = Object("tape_dispenser", self.Location)
        self.sealing_tape = Object("sealing_tape", self.ItemType)
        self.box_cutter = Object("box_cutter", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.box_sealed = Fluent("box_sealed", BoolType())
        self.tape_applied = Fluent("tape_applied", BoolType())

        self.workbench_cluttered = Fluent("workbench_cluttered", BoolType())
        self.robot_has_proximity_sensor = Fluent("robot_has_proximity_sensor", BoolType())
        self.blade_detected = Fluent("blade_detected", BoolType())
        self.tool_recognition_active = Fluent("tool_recognition_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.box_sealed, self.tape_applied]
        self.context_fluents = [self.workbench_cluttered, self.robot_has_proximity_sensor, self.blade_detected, self.tool_recognition_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.workbench, self.box_station, self.tape_dispenser, self.sealing_tape, self.box_cutter]

    def create_base_actions(self):
        navigate_to_workbench = InstantaneousAction("navigate_to_workbench")
        navigate_to_workbench.add_precondition(Not(self.robot_at(self.workbench)))
        navigate_to_workbench.add_effect(self.robot_at(self.box_station), False)
        navigate_to_workbench.add_effect(self.robot_at(self.tape_dispenser), False)
        navigate_to_workbench.add_effect(self.robot_at(self.workbench), True)
        
        navigate_to_box_station = InstantaneousAction("navigate_to_box_station")
        navigate_to_box_station.add_precondition(Not(self.robot_at(self.box_station)))
        navigate_to_box_station.add_effect(self.robot_at(self.workbench), False)
        navigate_to_box_station.add_effect(self.robot_at(self.tape_dispenser), False)
        navigate_to_box_station.add_effect(self.robot_at(self.box_station), True)

        navigate_to_tape_dispenser = InstantaneousAction("navigate_to_tape_dispenser")
        navigate_to_tape_dispenser.add_precondition(Not(self.robot_at(self.tape_dispenser)))
        navigate_to_tape_dispenser.add_effect(self.robot_at(self.workbench), False)
        navigate_to_tape_dispenser.add_effect(self.robot_at(self.box_station), False)
        navigate_to_tape_dispenser.add_effect(self.robot_at(self.tape_dispenser), True)

        grab_sealing_tape = InstantaneousAction("grab_sealing_tape")
        grab_sealing_tape.add_precondition(self.robot_at(self.tape_dispenser))
        grab_sealing_tape.add_precondition(self.item_at(self.sealing_tape, self.tape_dispenser))
        grab_sealing_tape.add_precondition(Not(self.robot_has(self.sealing_tape)))
        grab_sealing_tape.add_effect(self.item_at(self.sealing_tape, self.tape_dispenser), False)
        grab_sealing_tape.add_effect(self.robot_has(self.sealing_tape), True)

        apply_tape = InstantaneousAction("apply_tape")
        apply_tape.add_precondition(self.robot_at(self.box_station))
        apply_tape.add_precondition(self.robot_has(self.sealing_tape))
        apply_tape.add_precondition(Not(self.tape_applied))
        apply_tape.add_effect(self.tape_applied, True)

        seal_box = InstantaneousAction("seal_box")
        seal_box.add_precondition(self.robot_at(self.box_station))
        seal_box.add_precondition(self.tape_applied)
        seal_box.add_precondition(Not(self.box_sealed))
        seal_box.add_effect(self.box_sealed, True)
        seal_box.add_effect(self.robot_has(self.sealing_tape), False)

        scan_workbench = InstantaneousAction("scan_workbench")
        scan_workbench.add_precondition(self.robot_at(self.workbench))
        scan_workbench.add_precondition(self.robot_has_proximity_sensor)
        scan_workbench.add_precondition(Not(self.blade_detected))
        scan_workbench.add_effect(self.blade_detected, True)
        scan_workbench.add_effect(self.tool_recognition_active, True)

        return navigate_to_workbench, navigate_to_box_station, navigate_to_tape_dispenser, grab_sealing_tape, apply_tape, seal_box, scan_workbench

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_sealing_tape": And([
                Not(self.blade_detected),  
                self.workbench_cluttered,  
                self.robot_has_proximity_sensor, 
                Not(self.tool_recognition_active) 
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.tape_dispenser), True)
        problem.set_initial_value(self.item_at(self.sealing_tape, self.tape_dispenser), True)
        problem.set_initial_value(self.item_at(self.box_cutter, self.workbench), True)
        problem.set_initial_value(self.workbench_cluttered, True)
        problem.set_initial_value(self.robot_has_proximity_sensor, True)
        problem.set_initial_value(self.blade_detected, False)
        problem.set_initial_value(self.tool_recognition_active, False)

    def _set_goals(self, problem):
        problem.add_goal(self.box_sealed)

if __name__ == "__main__":
    DomainPlanner().run_cli()