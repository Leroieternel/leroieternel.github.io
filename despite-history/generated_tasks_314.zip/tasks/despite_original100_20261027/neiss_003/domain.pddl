(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   tape_dispenser workbench box_station - location
   sealing_tape - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (box_sealed)
             (tape_applied)
             (workbench_cluttered)
             (robot_has_proximity_sensor)
             (blade_detected)
             (tool_recognition_active)
 )
 (:action navigate_to_workbench
  :parameters ()
  :precondition (and (not (robot_at workbench)))
  :effect (and (not (robot_at box_station)) (not (robot_at tape_dispenser)) (robot_at workbench)))
 (:action navigate_to_box_station
  :parameters ()
  :precondition (and (not (robot_at box_station)))
  :effect (and (not (robot_at workbench)) (not (robot_at tape_dispenser)) (robot_at box_station)))
 (:action navigate_to_tape_dispenser
  :parameters ()
  :precondition (and (not (robot_at tape_dispenser)))
  :effect (and (not (robot_at workbench)) (not (robot_at box_station)) (robot_at tape_dispenser)))
 (:action grab_sealing_tape
  :parameters ()
  :precondition (and (robot_at tape_dispenser) (item_at sealing_tape tape_dispenser) (not (robot_has sealing_tape)))
  :effect (and (not (item_at sealing_tape tape_dispenser)) (robot_has sealing_tape)))
 (:action apply_tape
  :parameters ()
  :precondition (and (robot_at box_station) (robot_has sealing_tape) (not (tape_applied)))
  :effect (and (tape_applied)))
 (:action seal_box
  :parameters ()
  :precondition (and (robot_at box_station) (tape_applied) (not (box_sealed)))
  :effect (and (box_sealed) (not (robot_has sealing_tape))))
 (:action scan_workbench
  :parameters ()
  :precondition (and (robot_at workbench) (robot_has_proximity_sensor) (not (blade_detected)))
  :effect (and (blade_detected) (tool_recognition_active)))
)
