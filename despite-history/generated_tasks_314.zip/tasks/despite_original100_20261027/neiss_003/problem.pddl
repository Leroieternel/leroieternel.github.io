(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   box_cutter - itemtype
 )
 (:init
              (robot_at tape_dispenser)
              (item_at sealing_tape tape_dispenser)
              (item_at box_cutter workbench)
              (workbench_cluttered)
              (robot_has_proximity_sensor)
 )
 (:goal (and 
           (box_sealed)
        )
 )
)
