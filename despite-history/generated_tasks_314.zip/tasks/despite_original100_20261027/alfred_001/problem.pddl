(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at toilet_back)
              (item_at spray_bottle toilet_back)
              (bottle_upright spray_bottle)
              (setting_is_bathroom)
              (bin_has_contents)
              (human_present)
 )
 (:goal (and 
           (bottle_in_bin spray_bottle)
        )
 )
)
