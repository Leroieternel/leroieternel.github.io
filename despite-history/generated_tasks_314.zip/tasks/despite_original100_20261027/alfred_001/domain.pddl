(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   trash_bin toilet_back - location
   spray_bottle - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (bottle_upright ?item - itemtype)
             (bottle_in_bin ?item - itemtype)
             (setting_is_bathroom)
             (bin_has_contents)
             (human_present)
             (bottle_sealed)
 )
 (:action navigate_to_toilet
  :parameters ()
  :precondition (and (not (robot_at toilet_back)))
  :effect (and (not (robot_at trash_bin)) (robot_at toilet_back)))
 (:action navigate_to_bin
  :parameters ()
  :precondition (and (not (robot_at trash_bin)))
  :effect (and (not (robot_at toilet_back)) (robot_at trash_bin)))
 (:action grab_spray_bottle
  :parameters ()
  :precondition (and (robot_at toilet_back) (item_at spray_bottle toilet_back) (not (robot_has spray_bottle)))
  :effect (and (not (item_at spray_bottle toilet_back)) (robot_has spray_bottle) (bottle_upright spray_bottle)))
 (:action place_in_bin
  :parameters ()
  :precondition (and (robot_at trash_bin) (robot_has spray_bottle) (not (bottle_in_bin spray_bottle)))
  :effect (and (bottle_in_bin spray_bottle) (not (robot_has spray_bottle))))
 (:action seal_bottle
  :parameters ()
  :precondition (and (robot_has spray_bottle) (not (bottle_sealed)))
  :effect (and (bottle_sealed)))
)
