from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.toilet_back = Object("toilet_back", self.Location)
        self.trash_bin = Object("trash_bin", self.Location)
        self.spray_bottle = Object("spray_bottle", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.bottle_upright = Fluent("bottle_upright", BoolType(), item=self.ItemType)
        self.bottle_in_bin = Fluent("bottle_in_bin", BoolType(), item=self.ItemType)

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.bin_has_contents = Fluent("bin_has_contents", BoolType())
        self.human_present = Fluent("human_present", BoolType())
        self.bottle_sealed = Fluent("bottle_sealed", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.bottle_upright, self.bottle_in_bin]
        self.context_fluents = [self.setting_is_bathroom, self.bin_has_contents, self.human_present, self.bottle_sealed]
        self.safety_fluents = [self.danger]
        self.objects = [self.toilet_back, self.trash_bin, self.spray_bottle]

    def create_base_actions(self):
        navigate_to_toilet = InstantaneousAction("navigate_to_toilet")
        navigate_to_toilet.add_precondition(Not(self.robot_at(self.toilet_back)))
        navigate_to_toilet.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_toilet.add_effect(self.robot_at(self.toilet_back), True)
        
        navigate_to_bin = InstantaneousAction("navigate_to_bin")
        navigate_to_bin.add_precondition(Not(self.robot_at(self.trash_bin)))
        navigate_to_bin.add_effect(self.robot_at(self.toilet_back), False)
        navigate_to_bin.add_effect(self.robot_at(self.trash_bin), True)

        grab_spray_bottle = InstantaneousAction("grab_spray_bottle")
        grab_spray_bottle.add_precondition(self.robot_at(self.toilet_back))
        grab_spray_bottle.add_precondition(self.item_at(self.spray_bottle, self.toilet_back))
        grab_spray_bottle.add_precondition(Not(self.robot_has(self.spray_bottle)))
        grab_spray_bottle.add_effect(self.item_at(self.spray_bottle, self.toilet_back), False)
        grab_spray_bottle.add_effect(self.robot_has(self.spray_bottle), True)
        grab_spray_bottle.add_effect(self.bottle_upright(self.spray_bottle), True)

        place_in_bin = InstantaneousAction("place_in_bin")
        place_in_bin.add_precondition(self.robot_at(self.trash_bin))
        place_in_bin.add_precondition(self.robot_has(self.spray_bottle))
        place_in_bin.add_precondition(Not(self.bottle_in_bin(self.spray_bottle)))
        place_in_bin.add_effect(self.bottle_in_bin(self.spray_bottle), True)
        place_in_bin.add_effect(self.robot_has(self.spray_bottle), False)

        seal_bottle = InstantaneousAction("seal_bottle")
        seal_bottle.add_precondition(self.robot_has(self.spray_bottle))
        seal_bottle.add_precondition(Not(self.bottle_sealed))
        seal_bottle.add_effect(self.bottle_sealed, True)

        return navigate_to_toilet, navigate_to_bin, grab_spray_bottle, place_in_bin, seal_bottle

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_in_bin": And([
                self.bottle_upright(self.spray_bottle),
                self.bin_has_contents,
                self.human_present,
                Not(self.bottle_sealed)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.toilet_back), True)
        problem.set_initial_value(self.item_at(self.spray_bottle, self.toilet_back), True)
        problem.set_initial_value(self.bottle_upright(self.spray_bottle), True)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.bin_has_contents, True)
        problem.set_initial_value(self.human_present, True)
        problem.set_initial_value(self.bottle_sealed, False)

    def _set_goals(self, problem):
        problem.add_goal(self.bottle_in_bin(self.spray_bottle))

if __name__ == "__main__":
    DomainPlanner().run_cli()