(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at table)
              (item_at credit_card table)
              (setting_is_living_room)
              (robot_has_gripper)
              (lamp_has_pull_chain)
              (nearby_surface_available)
 )
 (:goal (and 
           (item_examined credit_card)
        )
 )
)
