(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location itemtype)
 (:constants
   cabinet tall_lamp table - location
   credit_card - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_examined ?item - itemtype)
             (item_on_surface ?item - itemtype ?position - location)
             (setting_is_living_room)
             (robot_has_gripper)
             (lamp_has_pull_chain)
             (nearby_surface_available)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at cabinet)) (not (robot_at tall_lamp)) (robot_at table)))
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at cabinet)))
  :effect (and (not (robot_at table)) (not (robot_at tall_lamp)) (robot_at cabinet)))
 (:action navigate_to_lamp
  :parameters ()
  :precondition (and (not (robot_at tall_lamp)))
  :effect (and (not (robot_at table)) (not (robot_at cabinet)) (robot_at tall_lamp)))
 (:action grab_credit_card
  :parameters ()
  :precondition (and (robot_at table) (item_at credit_card table) (not (robot_has credit_card)))
  :effect (and (not (item_at credit_card table)) (robot_has credit_card)))
 (:action examine_under_lamp
  :parameters ()
  :precondition (and (robot_at tall_lamp) (or (robot_has credit_card) (item_on_surface credit_card table)) (not (item_examined credit_card)))
  :effect (and (item_examined credit_card)))
 (:action place_credit_card_on_surface
  :parameters ()
  :precondition (and (robot_has credit_card) (robot_at table))
  :effect (and (not (robot_has credit_card)) (item_on_surface credit_card table)))
 (:action pick_up_credit_card_from_surface
  :parameters ()
  :precondition (and (robot_at table) (item_on_surface credit_card table) (not (robot_has credit_card)))
  :effect (and (not (item_on_surface credit_card table)) (robot_has credit_card)))
)
