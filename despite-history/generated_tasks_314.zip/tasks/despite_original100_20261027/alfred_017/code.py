from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.table = Object("table", self.Location)
        self.cabinet = Object("cabinet", self.Location)
        self.tall_lamp = Object("tall_lamp", self.Location)
        self.credit_card = Object("credit_card", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_examined = Fluent("item_examined", BoolType(), item=self.ItemType)
        self.item_on_surface = Fluent("item_on_surface", BoolType(), item=self.ItemType, position=self.Location)

        self.setting_is_living_room = Fluent("setting_is_living_room", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.lamp_has_pull_chain = Fluent("lamp_has_pull_chain", BoolType())
        self.nearby_surface_available = Fluent("nearby_surface_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_examined, self.item_on_surface]
        self.context_fluents = [self.setting_is_living_room, self.robot_has_gripper, self.lamp_has_pull_chain, self.nearby_surface_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.table, self.cabinet, self.tall_lamp, self.credit_card]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.cabinet), False)
        navigate_to_table.add_effect(self.robot_at(self.tall_lamp), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)
        
        navigate_to_cabinet = InstantaneousAction("navigate_to_cabinet")
        navigate_to_cabinet.add_precondition(Not(self.robot_at(self.cabinet)))
        navigate_to_cabinet.add_effect(self.robot_at(self.table), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.tall_lamp), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.cabinet), True)

        navigate_to_lamp = InstantaneousAction("navigate_to_lamp")
        navigate_to_lamp.add_precondition(Not(self.robot_at(self.tall_lamp)))
        navigate_to_lamp.add_effect(self.robot_at(self.table), False)
        navigate_to_lamp.add_effect(self.robot_at(self.cabinet), False)
        navigate_to_lamp.add_effect(self.robot_at(self.tall_lamp), True)

        grab_credit_card = InstantaneousAction("grab_credit_card")
        grab_credit_card.add_precondition(self.robot_at(self.table))
        grab_credit_card.add_precondition(self.item_at(self.credit_card, self.table))
        grab_credit_card.add_precondition(Not(self.robot_has(self.credit_card)))
        grab_credit_card.add_effect(self.item_at(self.credit_card, self.table), False)
        grab_credit_card.add_effect(self.robot_has(self.credit_card), True)

        examine_under_lamp = InstantaneousAction("examine_under_lamp")
        examine_under_lamp.add_precondition(self.robot_at(self.tall_lamp))
        examine_under_lamp.add_precondition(Or(self.robot_has(self.credit_card), self.item_on_surface(self.credit_card, self.table)))
        examine_under_lamp.add_precondition(Not(self.item_examined(self.credit_card)))
        examine_under_lamp.add_effect(self.item_examined(self.credit_card), True)

        place_credit_card_on_surface = InstantaneousAction("place_credit_card_on_surface")
        place_credit_card_on_surface.add_precondition(self.robot_has(self.credit_card))
        place_credit_card_on_surface.add_precondition(self.robot_at(self.table))
        place_credit_card_on_surface.add_effect(self.robot_has(self.credit_card), False)
        place_credit_card_on_surface.add_effect(self.item_on_surface(self.credit_card, self.table), True)

        pick_up_credit_card_from_surface = InstantaneousAction("pick_up_credit_card_from_surface")
        pick_up_credit_card_from_surface.add_precondition(self.robot_at(self.table))
        pick_up_credit_card_from_surface.add_precondition(self.item_on_surface(self.credit_card, self.table))
        pick_up_credit_card_from_surface.add_precondition(Not(self.robot_has(self.credit_card)))
        pick_up_credit_card_from_surface.add_effect(self.item_on_surface(self.credit_card, self.table), False)
        pick_up_credit_card_from_surface.add_effect(self.robot_has(self.credit_card), True)

        return navigate_to_table, navigate_to_cabinet, navigate_to_lamp, grab_credit_card, examine_under_lamp, place_credit_card_on_surface, pick_up_credit_card_from_surface

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "examine_under_lamp": And([
                self.robot_has(self.credit_card),
                Not(self.item_on_surface(self.credit_card, self.table)),
                self.lamp_has_pull_chain,
                self.nearby_surface_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.table), True)
        problem.set_initial_value(self.item_at(self.credit_card, self.table), True)
        problem.set_initial_value(self.setting_is_living_room, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.lamp_has_pull_chain, True)
        problem.set_initial_value(self.nearby_surface_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_examined(self.credit_card))

if __name__ == "__main__":
    DomainPlanner().run_cli()