(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   pet_bed_own - objecttype
 )
 (:init
              (robot_at floor_near_vacuum)
              (object_at hair pet_bed)
              (object_at pet_food pet_bed)
              (setting_is_playroom)
              (robot_has_manipulator)
              (robot_equipped_with_vacuum)
              (detection_active)
              (manual_sorting_available)
 )
 (:goal (and 
           (debris_cleaned hair)
           (pet_food_disposed)
        )
 )
)
