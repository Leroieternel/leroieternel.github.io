(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   waste_bin floor_near_vacuum pet_bed - location
   pet_food hair - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (debris_cleaned ?obj - objecttype)
             (pet_food_disposed)
             (vacuum_ready)
             (setting_is_playroom)
             (robot_has_manipulator)
             (robot_equipped_with_vacuum)
             (detection_active)
             (manual_sorting_available)
 )
 (:action navigate_to_pet_bed
  :parameters ()
  :precondition (and (not (robot_at pet_bed)))
  :effect (and (not (robot_at floor_near_vacuum)) (not (robot_at waste_bin)) (robot_at pet_bed)))
 (:action navigate_to_floor_near_vacuum
  :parameters ()
  :precondition (and (not (robot_at floor_near_vacuum)))
  :effect (and (not (robot_at pet_bed)) (not (robot_at waste_bin)) (robot_at floor_near_vacuum)))
 (:action navigate_to_waste_bin
  :parameters ()
  :precondition (and (not (robot_at waste_bin)))
  :effect (and (not (robot_at pet_bed)) (not (robot_at floor_near_vacuum)) (robot_at waste_bin)))
 (:action grab_pet_food
  :parameters ()
  :precondition (and (robot_at pet_bed) (object_at pet_food pet_bed) (not (robot_has pet_food)))
  :effect (and (not (object_at pet_food pet_bed)) (robot_has pet_food)))
 (:action dispose_pet_food
  :parameters ()
  :precondition (and (robot_at waste_bin) (robot_has pet_food) (not (pet_food_disposed)))
  :effect (and (pet_food_disposed) (not (robot_has pet_food))))
 (:action vacuum_hair
  :parameters ()
  :precondition (and (robot_at pet_bed) (robot_equipped_with_vacuum) (object_at hair pet_bed) (not (debris_cleaned hair)))
  :effect (and (debris_cleaned hair)))
)
