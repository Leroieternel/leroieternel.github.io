from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.pet_bed = Object("pet_bed", self.Location)
        self.floor_near_vacuum = Object("floor_near_vacuum", self.Location)
        self.waste_bin = Object("waste_bin", self.Location)
        self.hair = Object("hair", self.ObjectType)
        self.pet_food = Object("pet_food", self.ObjectType)
        self.pet_bed_own = Object("pet_bed_own", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.debris_cleaned = Fluent("debris_cleaned", BoolType(), obj=self.ObjectType)
        self.pet_food_disposed = Fluent("pet_food_disposed", BoolType())
        self.vacuum_ready = Fluent("vacuum_ready", BoolType())

        self.setting_is_playroom = Fluent("setting_is_playroom", BoolType())
        self.robot_has_manipulator = Fluent("robot_has_manipulator", BoolType())
        self.robot_equipped_with_vacuum = Fluent("robot_equipped_with_vacuum", BoolType())
        self.detection_active = Fluent("detection_active", BoolType())
        self.manual_sorting_available = Fluent("manual_sorting_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.debris_cleaned, self.pet_food_disposed, self.vacuum_ready]
        self.context_fluents = [self.setting_is_playroom, self.robot_has_manipulator, self.robot_equipped_with_vacuum, self.detection_active, self.manual_sorting_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.pet_bed, self.floor_near_vacuum, self.waste_bin, self.hair, self.pet_food, self.pet_bed_own]

    def create_base_actions(self):
        navigate_to_pet_bed = InstantaneousAction("navigate_to_pet_bed")
        navigate_to_pet_bed.add_precondition(Not(self.robot_at(self.pet_bed)))
        navigate_to_pet_bed.add_effect(self.robot_at(self.floor_near_vacuum), False)
        navigate_to_pet_bed.add_effect(self.robot_at(self.waste_bin), False)
        navigate_to_pet_bed.add_effect(self.robot_at(self.pet_bed), True)
        
        navigate_to_floor_near_vacuum = InstantaneousAction("navigate_to_floor_near_vacuum")
        navigate_to_floor_near_vacuum.add_precondition(Not(self.robot_at(self.floor_near_vacuum)))
        navigate_to_floor_near_vacuum.add_effect(self.robot_at(self.pet_bed), False)
        navigate_to_floor_near_vacuum.add_effect(self.robot_at(self.waste_bin), False)
        navigate_to_floor_near_vacuum.add_effect(self.robot_at(self.floor_near_vacuum), True)

        navigate_to_waste_bin = InstantaneousAction("navigate_to_waste_bin")
        navigate_to_waste_bin.add_precondition(Not(self.robot_at(self.waste_bin)))
        navigate_to_waste_bin.add_effect(self.robot_at(self.pet_bed), False)
        navigate_to_waste_bin.add_effect(self.robot_at(self.floor_near_vacuum), False)
        navigate_to_waste_bin.add_effect(self.robot_at(self.waste_bin), True)

        grab_pet_food = InstantaneousAction("grab_pet_food")
        grab_pet_food.add_precondition(self.robot_at(self.pet_bed))
        grab_pet_food.add_precondition(self.object_at(self.pet_food, self.pet_bed))
        grab_pet_food.add_precondition(Not(self.robot_has(self.pet_food)))
        grab_pet_food.add_effect(self.object_at(self.pet_food, self.pet_bed), False)
        grab_pet_food.add_effect(self.robot_has(self.pet_food), True)

        dispose_pet_food = InstantaneousAction("dispose_pet_food")
        dispose_pet_food.add_precondition(self.robot_at(self.waste_bin))
        dispose_pet_food.add_precondition(self.robot_has(self.pet_food))
        dispose_pet_food.add_precondition(Not(self.pet_food_disposed()))
        dispose_pet_food.add_effect(self.pet_food_disposed(), True)
        dispose_pet_food.add_effect(self.robot_has(self.pet_food), False)

        vacuum_hair = InstantaneousAction("vacuum_hair")
        vacuum_hair.add_precondition(self.robot_at(self.pet_bed))
        vacuum_hair.add_precondition(self.robot_equipped_with_vacuum)
        vacuum_hair.add_precondition(self.object_at(self.hair, self.pet_bed))
        vacuum_hair.add_precondition(Not(self.debris_cleaned(self.hair)))
        vacuum_hair.add_effect(self.debris_cleaned(self.hair), True)

        return navigate_to_pet_bed, navigate_to_floor_near_vacuum, navigate_to_waste_bin, grab_pet_food, dispose_pet_food, vacuum_hair

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "vacuum_hair": And([
                Not(self.pet_food_disposed()),
                self.object_at(self.pet_food, self.pet_bed),
                self.robot_equipped_with_vacuum,
                self.manual_sorting_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.floor_near_vacuum), True)
        problem.set_initial_value(self.object_at(self.hair, self.pet_bed), True)
        problem.set_initial_value(self.object_at(self.pet_food, self.pet_bed), True)
        problem.set_initial_value(self.setting_is_playroom, True)
        problem.set_initial_value(self.robot_has_manipulator, True)
        problem.set_initial_value(self.robot_equipped_with_vacuum, True)
        problem.set_initial_value(self.detection_active, True)
        problem.set_initial_value(self.manual_sorting_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.debris_cleaned(self.hair))
        problem.add_goal(self.pet_food_disposed())

if __name__ == "__main__":
    DomainPlanner().run_cli()