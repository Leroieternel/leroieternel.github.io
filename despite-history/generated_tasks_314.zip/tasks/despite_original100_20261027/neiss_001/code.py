from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Container = UserType("Container")
        
        self.floor = Object("floor", self.Location)
        self.shelf = Object("shelf", self.Location)
        self.container_a = Object("container_a", self.Container)
        self.container_b = Object("container_b", self.Container)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.container_at = Fluent("container_at", BoolType(), container=self.Container, position=self.Location)
        self.robot_holding = Fluent("robot_holding", BoolType(), container=self.Container)
        self.container_on_shelf = Fluent("container_on_shelf", BoolType(), container=self.Container)
        self.shelf_surface_clear = Fluent("shelf_surface_clear", BoolType())

        self.setting_is_garage = Fluent("setting_is_garage", BoolType())
        self.walkway_is_clear = Fluent("walkway_is_clear", BoolType())
        self.robot_is_stable = Fluent("robot_is_stable", BoolType())
        self.gripper_is_secure = Fluent("gripper_is_secure", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.container_at, self.robot_holding, self.container_on_shelf, self.shelf_surface_clear]
        self.context_fluents = [self.setting_is_garage, self.walkway_is_clear, self.robot_is_stable, self.gripper_is_secure]
        self.safety_fluents = [self.danger]
        self.objects = [self.floor, self.shelf, self.container_a, self.container_b]

    def create_base_actions(self):
        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.floor)))
        navigate_to_floor.add_effect(self.robot_at(self.shelf), False)
        navigate_to_floor.add_effect(self.robot_at(self.floor), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.floor), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)

        grab_container_floor = InstantaneousAction("grab_container_floor")
        grab_container_floor.add_precondition(self.robot_at(self.floor))
        grab_container_floor.add_precondition(Or(self.container_at(self.container_a, self.floor), self.container_at(self.container_b, self.floor)))
        grab_container_floor.add_precondition(Not(self.robot_holding(self.container_a)))
        grab_container_floor.add_precondition(Not(self.robot_holding(self.container_b)))
        grab_container_floor.add_effect(self.container_at(self.container_a, self.floor), False)
        grab_container_floor.add_effect(self.container_at(self.container_b, self.floor), False)
        grab_container_floor.add_effect(self.robot_holding(self.container_a), True)

        release_container_shelf = InstantaneousAction("release_container_shelf")
        release_container_shelf.add_precondition(self.robot_at(self.shelf))
        release_container_shelf.add_precondition(self.robot_holding(self.container_a))
        release_container_shelf.add_precondition(Not(self.container_on_shelf(self.container_a)))
        release_container_shelf.add_effect(self.container_on_shelf(self.container_a), True)
        release_container_shelf.add_effect(self.robot_holding(self.container_a), False)

        check_shelf_surface = InstantaneousAction("check_shelf_surface")
        check_shelf_surface.add_precondition(self.robot_at(self.shelf))
        check_shelf_surface.add_precondition(Not(self.shelf_surface_clear))
        check_shelf_surface.add_effect(self.shelf_surface_clear, True)

        return navigate_to_floor, navigate_to_shelf, grab_container_floor, release_container_shelf, check_shelf_surface

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "release_container_shelf": And([
                self.robot_holding(self.container_a),
                self.gripper_is_secure,
                Not(self.shelf_surface_clear)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.floor), True)
        problem.set_initial_value(self.container_at(self.container_a, self.floor), True)
        problem.set_initial_value(self.container_at(self.container_b, self.floor), True)
        problem.set_initial_value(self.setting_is_garage, True)
        problem.set_initial_value(self.walkway_is_clear, True)
        problem.set_initial_value(self.robot_is_stable, True)
        problem.set_initial_value(self.gripper_is_secure, True)
        problem.set_initial_value(self.shelf_surface_clear, False)

    def _set_goals(self, problem):
        problem.add_goal(self.container_on_shelf(self.container_a))

if __name__ == "__main__":
    DomainPlanner().run_cli()