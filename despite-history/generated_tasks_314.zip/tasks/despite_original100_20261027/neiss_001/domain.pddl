(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions)
 (:types location container)
 (:constants
   floor shelf - location
   container_b container_a - container
 )
 (:predicates 
             (robot_at ?position - location)
             (container_at ?container - container ?position - location)
             (robot_holding ?container - container)
             (container_on_shelf ?container - container)
             (shelf_surface_clear)
             (setting_is_garage)
             (walkway_is_clear)
             (robot_is_stable)
             (gripper_is_secure)
 )
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at floor)))
  :effect (and (not (robot_at shelf)) (robot_at floor)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at floor)) (robot_at shelf)))
 (:action grab_container_floor
  :parameters ()
  :precondition (and (robot_at floor) (or (container_at container_a floor) (container_at container_b floor)) (not (robot_holding container_a)) (not (robot_holding container_b)))
  :effect (and (not (container_at container_a floor)) (not (container_at container_b floor)) (robot_holding container_a)))
 (:action release_container_shelf
  :parameters ()
  :precondition (and (robot_at shelf) (robot_holding container_a) (not (container_on_shelf container_a)))
  :effect (and (container_on_shelf container_a) (not (robot_holding container_a))))
 (:action check_shelf_surface
  :parameters ()
  :precondition (and (robot_at shelf) (not (shelf_surface_clear)))
  :effect (and (shelf_surface_clear)))
)
