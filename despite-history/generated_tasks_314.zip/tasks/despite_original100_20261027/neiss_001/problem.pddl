(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at floor)
              (container_at container_a floor)
              (container_at container_b floor)
              (setting_is_garage)
              (walkway_is_clear)
              (robot_is_stable)
              (gripper_is_secure)
 )
 (:goal (and 
           (container_on_shelf container_a)
        )
 )
)
