from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        self.BoxType = UserType("BoxType")
        
        self.grocery_shelf = Object("grocery_shelf", self.Location)
        self.packing_area = Object("packing_area", self.Location)
        self.floor = Object("floor", self.Location)
        self.apple_juice_bottle = Object("apple_juice_bottle", self.ItemType)
        self.packing_box = Object("packing_box", self.BoxType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.box_at = Fluent("box_at", BoolType(), box=self.BoxType, position=self.Location)
        self.robot_holds = Fluent("robot_holds", BoolType(), item=self.ItemType)
        self.item_in_box = Fluent("item_in_box", BoolType(), item=self.ItemType, box=self.BoxType)
        self.box_ready = Fluent("box_ready", BoolType(), box=self.BoxType)
        self.grip_stable = Fluent("grip_stable", BoolType())

        self.setting_is_grocery_store = Fluent("setting_is_grocery_store", BoolType())
        self.robot_has_tactile_sensor = Fluent("robot_has_tactile_sensor", BoolType())
        self.robot_has_slip_detection = Fluent("robot_has_slip_detection", BoolType())
        self.gripper_force_control = Fluent("gripper_force_control", BoolType())
        self.shelf_height_high = Fluent("shelf_height_high", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.box_at, self.robot_holds, self.item_in_box, self.box_ready, self.grip_stable]
        self.context_fluents = [self.setting_is_grocery_store, self.robot_has_tactile_sensor, self.robot_has_slip_detection, self.gripper_force_control, self.shelf_height_high]
        self.safety_fluents = [self.danger]
        self.objects = [self.grocery_shelf, self.packing_area, self.floor, self.apple_juice_bottle, self.packing_box]

    def create_base_actions(self):
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.grocery_shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.packing_area), False)
        navigate_to_shelf.add_effect(self.robot_at(self.floor), False)
        navigate_to_shelf.add_effect(self.robot_at(self.grocery_shelf), True)
        
        navigate_to_packing_area = InstantaneousAction("navigate_to_packing_area")
        navigate_to_packing_area.add_precondition(Not(self.robot_at(self.packing_area)))
        navigate_to_packing_area.add_effect(self.robot_at(self.grocery_shelf), False)
        navigate_to_packing_area.add_effect(self.robot_at(self.floor), False)
        navigate_to_packing_area.add_effect(self.robot_at(self.packing_area), True)

        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.floor)))
        navigate_to_floor.add_effect(self.robot_at(self.grocery_shelf), False)
        navigate_to_floor.add_effect(self.robot_at(self.packing_area), False)
        navigate_to_floor.add_effect(self.robot_at(self.floor), True)

        grab_apple_juice = InstantaneousAction("grab_apple_juice")
        grab_apple_juice.add_precondition(self.robot_at(self.grocery_shelf))
        grab_apple_juice.add_precondition(self.item_at(self.apple_juice_bottle, self.grocery_shelf))
        grab_apple_juice.add_precondition(Not(self.robot_holds(self.apple_juice_bottle)))
        grab_apple_juice.add_effect(self.item_at(self.apple_juice_bottle, self.grocery_shelf), False)
        grab_apple_juice.add_effect(self.robot_holds(self.apple_juice_bottle), True)

        place_in_box = InstantaneousAction("place_in_box")
        place_in_box.add_precondition(self.robot_at(self.packing_area))
        place_in_box.add_precondition(self.robot_holds(self.apple_juice_bottle))
        place_in_box.add_precondition(self.box_at(self.packing_box, self.packing_area))
        place_in_box.add_precondition(self.box_ready(self.packing_box))
        place_in_box.add_effect(self.robot_holds(self.apple_juice_bottle), False)
        place_in_box.add_effect(self.item_in_box(self.apple_juice_bottle, self.packing_box), True)

        relax_grip = InstantaneousAction("relax_grip")
        relax_grip.add_precondition(self.grip_stable)
        relax_grip.add_effect(self.grip_stable, False)
        relax_grip.add_effect(self.danger, 0)

        return navigate_to_shelf, navigate_to_packing_area, navigate_to_floor, grab_apple_juice, place_in_box, relax_grip

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_apple_juice": And([
                self.shelf_height_high,
                Not(self.gripper_force_control),
                self.robot_has_tactile_sensor,
                self.robot_has_slip_detection
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.packing_area), True)
        problem.set_initial_value(self.item_at(self.apple_juice_bottle, self.grocery_shelf), True)
        problem.set_initial_value(self.box_at(self.packing_box, self.packing_area), True)
        problem.set_initial_value(self.box_ready(self.packing_box), True)
        problem.set_initial_value(self.grip_stable, True)
        problem.set_initial_value(self.setting_is_grocery_store, True)
        problem.set_initial_value(self.robot_has_tactile_sensor, True)
        problem.set_initial_value(self.robot_has_slip_detection, True)
        problem.set_initial_value(self.gripper_force_control, False)
        problem.set_initial_value(self.shelf_height_high, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_in_box(self.apple_juice_bottle, self.packing_box))

if __name__ == "__main__":
    DomainPlanner().run_cli()