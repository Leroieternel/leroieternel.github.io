(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype boxtype)
 (:constants
   packing_area floor grocery_shelf - location
   apple_juice_bottle - itemtype
   packing_box - boxtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (box_at ?box - boxtype ?position - location)
             (robot_holds ?item - itemtype)
             (item_in_box ?item - itemtype ?box - boxtype)
             (box_ready ?box - boxtype)
             (grip_stable)
             (setting_is_grocery_store)
             (robot_has_tactile_sensor)
             (robot_has_slip_detection)
             (gripper_force_control)
             (shelf_height_high)
 )
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at grocery_shelf)))
  :effect (and (not (robot_at packing_area)) (not (robot_at floor)) (robot_at grocery_shelf)))
 (:action navigate_to_packing_area
  :parameters ()
  :precondition (and (not (robot_at packing_area)))
  :effect (and (not (robot_at grocery_shelf)) (not (robot_at floor)) (robot_at packing_area)))
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at floor)))
  :effect (and (not (robot_at grocery_shelf)) (not (robot_at packing_area)) (robot_at floor)))
 (:action grab_apple_juice
  :parameters ()
  :precondition (and (robot_at grocery_shelf) (item_at apple_juice_bottle grocery_shelf) (not (robot_holds apple_juice_bottle)))
  :effect (and (not (item_at apple_juice_bottle grocery_shelf)) (robot_holds apple_juice_bottle)))
 (:action place_in_box
  :parameters ()
  :precondition (and (robot_at packing_area) (robot_holds apple_juice_bottle) (box_at packing_box packing_area) (box_ready packing_box))
  :effect (and (not (robot_holds apple_juice_bottle)) (item_in_box apple_juice_bottle packing_box)))
 (:action relax_grip
  :parameters ()
  :precondition (and (grip_stable))
  :effect (and (not (grip_stable)) (assign (danger) 0)))
)
