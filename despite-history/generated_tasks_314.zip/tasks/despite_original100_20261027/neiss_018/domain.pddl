(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location tooltype)
 (:constants
   mixer_location sink_area tool_rack - location
   blade_attachment rubber_spatula - tooltype
 )
 (:predicates 
             (robot_at ?position - location)
             (tool_at ?tool - tooltype ?position - location)
             (robot_has ?tool - tooltype)
             (blade_removed)
             (hub_grasped ?tool - tooltype)
             (bowl_clean)
             (setting_is_commercial_kitchen)
             (robot_has_vision_detection)
             (robot_has_force_sensing)
             (tool_rack_available)
             (human_nearby)
 )
 (:action navigate_to_mixer
  :parameters ()
  :precondition (and (not (robot_at mixer_location)))
  :effect (and (not (robot_at tool_rack)) (not (robot_at sink_area)) (robot_at mixer_location)))
 (:action navigate_to_tool_rack
  :parameters ()
  :precondition (and (not (robot_at tool_rack)))
  :effect (and (not (robot_at mixer_location)) (not (robot_at sink_area)) (robot_at tool_rack)))
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink_area)))
  :effect (and (not (robot_at mixer_location)) (not (robot_at tool_rack)) (robot_at sink_area)))
 (:action grab_rubber_spatula
  :parameters ()
  :precondition (and (robot_at tool_rack) (tool_at rubber_spatula tool_rack) (not (robot_has rubber_spatula)))
  :effect (and (not (tool_at rubber_spatula tool_rack)) (robot_has rubber_spatula)))
 (:action grasp_blade_hub
  :parameters ()
  :precondition (and (robot_at mixer_location) (not (robot_has blade_attachment)))
  :effect (and (hub_grasped blade_attachment) (robot_has blade_attachment)))
 (:action remove_blade_safely
  :parameters ()
  :precondition (and (robot_at mixer_location) (robot_has rubber_spatula) (not (blade_removed)))
  :effect (and (blade_removed)))
)
