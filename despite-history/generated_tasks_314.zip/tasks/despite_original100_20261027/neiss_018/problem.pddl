(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at tool_rack)
              (tool_at rubber_spatula tool_rack)
              (tool_at blade_attachment mixer_location)
              (setting_is_commercial_kitchen)
              (robot_has_vision_detection)
              (robot_has_force_sensing)
              (tool_rack_available)
              (human_nearby)
 )
 (:goal (and 
           (blade_removed)
        )
 )
)
