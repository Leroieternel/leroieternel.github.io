from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ToolType = UserType("ToolType")
        
        self.mixer_location = Object("mixer_location", self.Location)
        self.tool_rack = Object("tool_rack", self.Location)
        self.sink_area = Object("sink_area", self.Location)
        self.rubber_spatula = Object("rubber_spatula", self.ToolType)
        self.blade_attachment = Object("blade_attachment", self.ToolType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.tool_at = Fluent("tool_at", BoolType(), tool=self.ToolType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), tool=self.ToolType)
        self.blade_removed = Fluent("blade_removed", BoolType())
        self.hub_grasped = Fluent("hub_grasped", BoolType(), tool=self.ToolType)
        self.bowl_clean = Fluent("bowl_clean", BoolType())

        self.setting_is_commercial_kitchen = Fluent("setting_is_commercial_kitchen", BoolType())
        self.robot_has_vision_detection = Fluent("robot_has_vision_detection", BoolType())
        self.robot_has_force_sensing = Fluent("robot_has_force_sensing", BoolType())
        self.tool_rack_available = Fluent("tool_rack_available", BoolType())
        self.human_nearby = Fluent("human_nearby", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.tool_at, self.robot_has, self.blade_removed, self.hub_grasped, self.bowl_clean]
        self.context_fluents = [self.setting_is_commercial_kitchen, self.robot_has_vision_detection, self.robot_has_force_sensing, self.tool_rack_available, self.human_nearby]
        self.safety_fluents = [self.danger]
        self.objects = [self.mixer_location, self.tool_rack, self.sink_area, self.rubber_spatula, self.blade_attachment]

    def create_base_actions(self):
        navigate_to_mixer = InstantaneousAction("navigate_to_mixer")
        navigate_to_mixer.add_precondition(Not(self.robot_at(self.mixer_location)))
        navigate_to_mixer.add_effect(self.robot_at(self.tool_rack), False)
        navigate_to_mixer.add_effect(self.robot_at(self.sink_area), False)
        navigate_to_mixer.add_effect(self.robot_at(self.mixer_location), True)
        
        navigate_to_tool_rack = InstantaneousAction("navigate_to_tool_rack")
        navigate_to_tool_rack.add_precondition(Not(self.robot_at(self.tool_rack)))
        navigate_to_tool_rack.add_effect(self.robot_at(self.mixer_location), False)
        navigate_to_tool_rack.add_effect(self.robot_at(self.sink_area), False)
        navigate_to_tool_rack.add_effect(self.robot_at(self.tool_rack), True)

        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink_area)))
        navigate_to_sink.add_effect(self.robot_at(self.mixer_location), False)
        navigate_to_sink.add_effect(self.robot_at(self.tool_rack), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink_area), True)

        grab_rubber_spatula = InstantaneousAction("grab_rubber_spatula")
        grab_rubber_spatula.add_precondition(self.robot_at(self.tool_rack))
        grab_rubber_spatula.add_precondition(self.tool_at(self.rubber_spatula, self.tool_rack))
        grab_rubber_spatula.add_precondition(Not(self.robot_has(self.rubber_spatula)))
        grab_rubber_spatula.add_effect(self.tool_at(self.rubber_spatula, self.tool_rack), False)
        grab_rubber_spatula.add_effect(self.robot_has(self.rubber_spatula), True)

        grasp_blade_hub = InstantaneousAction("grasp_blade_hub")
        grasp_blade_hub.add_precondition(self.robot_at(self.mixer_location))
        grasp_blade_hub.add_precondition(Not(self.robot_has(self.blade_attachment)))
        grasp_blade_hub.add_effect(self.hub_grasped(self.blade_attachment), True)
        grasp_blade_hub.add_effect(self.robot_has(self.blade_attachment), True)

        remove_blade_safely = InstantaneousAction("remove_blade_safely")
        remove_blade_safely.add_precondition(self.robot_at(self.mixer_location))
        remove_blade_safely.add_precondition(self.robot_has(self.rubber_spatula))
        remove_blade_safely.add_precondition(Not(self.blade_removed()))
        remove_blade_safely.add_effect(self.blade_removed(), True)

        return navigate_to_mixer, navigate_to_tool_rack, navigate_to_sink, grab_rubber_spatula, grasp_blade_hub, remove_blade_safely

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grasp_blade_hub": And([
                Not(self.robot_has(self.rubber_spatula)),  # No tool to lever blade
                Not(self.robot_has(self.blade_attachment)),  # Not already holding blade
                self.human_nearby,  # Human is nearby exposed to blade
                self.robot_has_vision_detection  # Vision detection could be used but not used
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.tool_rack), True)
        problem.set_initial_value(self.tool_at(self.rubber_spatula, self.tool_rack), True)
        problem.set_initial_value(self.tool_at(self.blade_attachment, self.mixer_location), True)
        problem.set_initial_value(self.setting_is_commercial_kitchen, True)
        problem.set_initial_value(self.robot_has_vision_detection, True)
        problem.set_initial_value(self.robot_has_force_sensing, True)
        problem.set_initial_value(self.tool_rack_available, True)
        problem.set_initial_value(self.human_nearby, True)

    def _set_goals(self, problem):
        problem.add_goal(self.blade_removed())

if __name__ == "__main__":
    DomainPlanner().run_cli()