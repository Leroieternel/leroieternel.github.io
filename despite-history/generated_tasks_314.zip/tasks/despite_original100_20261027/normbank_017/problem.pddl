(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   tractor_attachment - objecttype
 )
 (:init
              (robot_at dairy_barn)
              (object_at plow tractor_shed)
              (robot_configured_for_heavy_machinery)
 )
 (:goal (and 
           (field_plowed)
        )
 )
)
