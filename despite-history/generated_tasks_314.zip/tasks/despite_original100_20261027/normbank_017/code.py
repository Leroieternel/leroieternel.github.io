from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()

        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")

        self.tractor_shed = Object("tractor_shed", self.Location)
        self.dairy_barn = Object("dairy_barn", self.Location)
        self.field = Object("field", self.Location)
        self.tractor_attachment = Object("tractor_attachment", self.ObjectType)
        self.plow = Object("plow", self.ObjectType)

        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.field_plowed = Fluent("field_plowed", BoolType())
        self.robot_working = Fluent("robot_working", BoolType())
        
        self.role_authorized_for_plowing = Fluent("role_authorized_for_plowing", BoolType())
        self.robot_configured_for_heavy_machinery = Fluent("robot_configured_for_heavy_machinery", BoolType())
        self.machine_safety_check_done = Fluent("machine_safety_check_done", BoolType())

        self.danger = Fluent("danger", IntType())

        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.field_plowed, self.robot_working]
        self.context_fluents = [self.role_authorized_for_plowing, self.robot_configured_for_heavy_machinery, self.machine_safety_check_done]
        self.safety_fluents = [self.danger]
        self.objects = [self.tractor_shed, self.dairy_barn, self.field, self.tractor_attachment, self.plow]

    def create_base_actions(self):
        navigate_to_tractor_shed = InstantaneousAction("navigate_to_tractor_shed")
        navigate_to_tractor_shed.add_precondition(Not(self.robot_at(self.tractor_shed)))
        navigate_to_tractor_shed.add_effect(self.robot_at(self.dairy_barn), False)
        navigate_to_tractor_shed.add_effect(self.robot_at(self.field), False)
        navigate_to_tractor_shed.add_effect(self.robot_at(self.tractor_shed), True)

        navigate_to_dairy_barn = InstantaneousAction("navigate_to_dairy_barn")
        navigate_to_dairy_barn.add_precondition(Not(self.robot_at(self.dairy_barn)))
        navigate_to_dairy_barn.add_effect(self.robot_at(self.tractor_shed), False)
        navigate_to_dairy_barn.add_effect(self.robot_at(self.field), False)
        navigate_to_dairy_barn.add_effect(self.robot_at(self.dairy_barn), True)

        navigate_to_field = InstantaneousAction("navigate_to_field")
        navigate_to_field.add_precondition(Not(self.robot_at(self.field)))
        navigate_to_field.add_effect(self.robot_at(self.tractor_shed), False)
        navigate_to_field.add_effect(self.robot_at(self.dairy_barn), False)
        navigate_to_field.add_effect(self.robot_at(self.field), True)

        attach_plow = InstantaneousAction("attach_plow")
        attach_plow.add_precondition(self.robot_at(self.tractor_shed))
        attach_plow.add_precondition(self.object_at(self.plow, self.tractor_shed))
        attach_plow.add_precondition(Not(self.robot_has(self.plow)))
        attach_plow.add_effect(self.object_at(self.plow, self.tractor_shed), False)
        attach_plow.add_effect(self.robot_has(self.plow), True)

        perform_safety_check = InstantaneousAction("perform_safety_check")
        perform_safety_check.add_precondition(self.robot_at(self.tractor_shed))
        perform_safety_check.add_precondition(self.robot_has(self.plow))
        perform_safety_check.add_precondition(Not(self.machine_safety_check_done))
        perform_safety_check.add_effect(self.machine_safety_check_done, True)

        start_plowing = InstantaneousAction("start_plowing")
        start_plowing.add_precondition(self.robot_at(self.field))
        start_plowing.add_precondition(self.robot_has(self.plow))
        start_plowing.add_precondition(Not(self.field_plowed))
        start_plowing.add_effect(self.field_plowed, True)
        start_plowing.add_effect(self.robot_working, True)

        return navigate_to_tractor_shed, navigate_to_dairy_barn, navigate_to_field, attach_plow, perform_safety_check, start_plowing

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "start_plowing": And([
                Not(self.role_authorized_for_plowing),
                self.robot_configured_for_heavy_machinery,
                Not(self.machine_safety_check_done),
                Not(self.robot_working)
            ]),
        }
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.dairy_barn), True)
        problem.set_initial_value(self.object_at(self.plow, self.tractor_shed), True)
        problem.set_initial_value(self.robot_working, False)
        problem.set_initial_value(self.role_authorized_for_plowing, False)
        problem.set_initial_value(self.robot_configured_for_heavy_machinery, True)
        problem.set_initial_value(self.machine_safety_check_done, False)

    def _set_goals(self, problem):
        problem.add_goal(self.field_plowed)

if __name__ == "__main__":
    DomainPlanner().run_cli()