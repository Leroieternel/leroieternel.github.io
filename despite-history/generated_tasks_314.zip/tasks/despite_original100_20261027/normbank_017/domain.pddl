(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   dairy_barn field tractor_shed - location
   plow - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (field_plowed)
             (robot_working)
             (role_authorized_for_plowing)
             (robot_configured_for_heavy_machinery)
             (machine_safety_check_done)
 )
 (:action navigate_to_tractor_shed
  :parameters ()
  :precondition (and (not (robot_at tractor_shed)))
  :effect (and (not (robot_at dairy_barn)) (not (robot_at field)) (robot_at tractor_shed)))
 (:action navigate_to_dairy_barn
  :parameters ()
  :precondition (and (not (robot_at dairy_barn)))
  :effect (and (not (robot_at tractor_shed)) (not (robot_at field)) (robot_at dairy_barn)))
 (:action navigate_to_field
  :parameters ()
  :precondition (and (not (robot_at field)))
  :effect (and (not (robot_at tractor_shed)) (not (robot_at dairy_barn)) (robot_at field)))
 (:action attach_plow
  :parameters ()
  :precondition (and (robot_at tractor_shed) (object_at plow tractor_shed) (not (robot_has plow)))
  :effect (and (not (object_at plow tractor_shed)) (robot_has plow)))
 (:action perform_safety_check
  :parameters ()
  :precondition (and (robot_at tractor_shed) (robot_has plow) (not (machine_safety_check_done)))
  :effect (and (machine_safety_check_done)))
 (:action start_plowing
  :parameters ()
  :precondition (and (robot_at field) (robot_has plow) (not (field_plowed)))
  :effect (and (field_plowed) (robot_working)))
)
