(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at table)
              (item_at tomato trash_can)
              (robot_has_vision)
              (human_available)
 )
 (:goal (and 
           (tomato_on_table)
        )
 )
)
