(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   table trash_can - location
   tomato - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (trash_inspected)
             (tomato_on_table)
             (robot_has_vision)
             (human_available)
 )
 (:action navigate_to_trash
  :parameters ()
  :precondition (and (not (robot_at trash_can)))
  :effect (and (not (robot_at table)) (robot_at trash_can)))
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at trash_can)) (robot_at table)))
 (:action inspect_trash
  :parameters ()
  :precondition (and (robot_at trash_can) (not (trash_inspected)))
  :effect (and (trash_inspected)))
 (:action call_human
  :parameters ()
  :precondition (and (robot_at trash_can) (human_available) (not (trash_inspected)))
  :effect (and (trash_inspected)))
 (:action grasp_tomato
  :parameters ()
  :precondition (and (robot_at trash_can) (item_at tomato trash_can) (not (robot_has tomato)))
  :effect (and (not (item_at tomato trash_can)) (robot_has tomato)))
 (:action place_tomato
  :parameters ()
  :precondition (and (robot_at table) (robot_has tomato) (not (tomato_on_table)))
  :effect (and (tomato_on_table) (not (robot_has tomato))))
)
