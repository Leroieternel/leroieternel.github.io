from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.trash_can = Object("trash_can", self.Location)
        self.table = Object("table", self.Location)
        self.tomato = Object("tomato", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.trash_inspected = Fluent("trash_inspected", BoolType())
        self.tomato_on_table = Fluent("tomato_on_table", BoolType())

        self.robot_has_vision = Fluent("robot_has_vision", BoolType())
        self.human_available = Fluent("human_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.trash_inspected, self.tomato_on_table]
        self.context_fluents = [self.robot_has_vision, self.human_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.trash_can, self.table, self.tomato]

    def create_base_actions(self):
        navigate_to_trash = InstantaneousAction("navigate_to_trash")
        navigate_to_trash.add_precondition(Not(self.robot_at(self.trash_can)))
        navigate_to_trash.add_effect(self.robot_at(self.table), False)
        navigate_to_trash.add_effect(self.robot_at(self.trash_can), True)
        
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.trash_can), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)

        inspect_trash = InstantaneousAction("inspect_trash")
        inspect_trash.add_precondition(self.robot_at(self.trash_can))
        inspect_trash.add_precondition(Not(self.trash_inspected))
        inspect_trash.add_effect(self.trash_inspected, True)

        call_human = InstantaneousAction("call_human")
        call_human.add_precondition(self.robot_at(self.trash_can))
        call_human.add_precondition(self.human_available)
        call_human.add_precondition(Not(self.trash_inspected))
        call_human.add_effect(self.trash_inspected, True)

        grasp_tomato = InstantaneousAction("grasp_tomato")
        grasp_tomato.add_precondition(self.robot_at(self.trash_can))
        grasp_tomato.add_precondition(self.item_at(self.tomato, self.trash_can))
        grasp_tomato.add_precondition(Not(self.robot_has(self.tomato)))
        grasp_tomato.add_effect(self.item_at(self.tomato, self.trash_can), False)
        grasp_tomato.add_effect(self.robot_has(self.tomato), True)

        place_tomato = InstantaneousAction("place_tomato")
        place_tomato.add_precondition(self.robot_at(self.table))
        place_tomato.add_precondition(self.robot_has(self.tomato))
        place_tomato.add_precondition(Not(self.tomato_on_table))
        place_tomato.add_effect(self.tomato_on_table, True)
        place_tomato.add_effect(self.robot_has(self.tomato), False)

        return navigate_to_trash, navigate_to_table, inspect_trash, call_human, grasp_tomato, place_tomato

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grasp_tomato": And([
                Not(self.trash_inspected),
                self.robot_has_vision,
                self.human_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.table), True)
        problem.set_initial_value(self.item_at(self.tomato, self.trash_can), True)
        problem.set_initial_value(self.trash_inspected, False)
        problem.set_initial_value(self.tomato_on_table, False)
        problem.set_initial_value(self.robot_has_vision, True)
        problem.set_initial_value(self.human_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.tomato_on_table)

if __name__ == "__main__":
    DomainPlanner().run_cli()