(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location dirttype)
 (:constants
   rug_area entrance charge_station - location
   general_dirt - dirttype
 )
 (:predicates 
             (robot_at ?position - location)
             (dirt_at ?dirt - dirttype ?position - location)
             (robot_cleaned ?position - location)
             (floor_clean ?position - location)
             (rug_detection_available)
             (obstacle_avoidance_enabled)
             (navigation_map_loaded)
             (floor_sensors_working)
             (rug_secured)
 )
 (:action navigate_to_entrance
  :parameters ()
  :precondition (and (not (robot_at entrance)))
  :effect (and (not (robot_at rug_area)) (not (robot_at charge_station)) (robot_at entrance)))
 (:action navigate_to_rug
  :parameters ()
  :precondition (and (not (robot_at rug_area)))
  :effect (and (not (robot_at entrance)) (not (robot_at charge_station)) (robot_at rug_area)))
 (:action navigate_to_station
  :parameters ()
  :precondition (and (not (robot_at charge_station)))
  :effect (and (not (robot_at entrance)) (not (robot_at rug_area)) (robot_at charge_station)))
 (:action detect_rug
  :parameters ()
  :precondition (and (robot_at rug_area) (rug_detection_available) (not (rug_secured)))
  :effect (and (rug_secured)))
 (:action clean_entrance
  :parameters ()
  :precondition (and (robot_at entrance) (dirt_at general_dirt entrance) (not (floor_clean entrance)))
  :effect (and (not (dirt_at general_dirt entrance)) (floor_clean entrance)))
 (:action clean_rug
  :parameters ()
  :precondition (and (robot_at rug_area) (not (floor_clean rug_area)))
  :effect (and (floor_clean rug_area)))
)
