(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   rug - dirttype
 )
 (:init
              (robot_at charge_station)
              (dirt_at general_dirt entrance)
              (rug_detection_available)
              (obstacle_avoidance_enabled)
              (navigation_map_loaded)
              (floor_sensors_working)
 )
 (:goal (and 
           (floor_clean entrance)
           (floor_clean rug_area)
        )
 )
)
