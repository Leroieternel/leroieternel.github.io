from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.DirtType = UserType("DirtType")
        
        self.entrance = Object("entrance", self.Location)
        self.rug_area = Object("rug_area", self.Location)
        self.charge_station = Object("charge_station", self.Location)
        self.general_dirt = Object("general_dirt", self.DirtType)
        self.rug = Object("rug", self.DirtType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.dirt_at = Fluent("dirt_at", BoolType(), dirt=self.DirtType, position=self.Location)
        self.robot_cleaned = Fluent("robot_cleaned", BoolType(), position=self.Location)
        self.floor_clean = Fluent("floor_clean", BoolType(), position=self.Location)

        self.rug_detection_available = Fluent("rug_detection_available", BoolType())
        self.obstacle_avoidance_enabled = Fluent("obstacle_avoidance_enabled", BoolType())
        self.navigation_map_loaded = Fluent("navigation_map_loaded", BoolType())
        self.floor_sensors_working = Fluent("floor_sensors_working", BoolType())
        self.rug_secured = Fluent("rug_secured", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.dirt_at, self.robot_cleaned, self.floor_clean]
        self.context_fluents = [self.rug_detection_available, self.obstacle_avoidance_enabled, self.navigation_map_loaded, self.floor_sensors_working, self.rug_secured]
        self.safety_fluents = [self.danger]
        self.objects = [self.entrance, self.rug_area, self.charge_station, self.general_dirt, self.rug]

    def create_base_actions(self):
        navigate_to_entrance = InstantaneousAction("navigate_to_entrance")
        navigate_to_entrance.add_precondition(Not(self.robot_at(self.entrance)))
        navigate_to_entrance.add_effect(self.robot_at(self.rug_area), False)
        navigate_to_entrance.add_effect(self.robot_at(self.charge_station), False)
        navigate_to_entrance.add_effect(self.robot_at(self.entrance), True)
        
        navigate_to_rug = InstantaneousAction("navigate_to_rug")
        navigate_to_rug.add_precondition(Not(self.robot_at(self.rug_area)))
        navigate_to_rug.add_effect(self.robot_at(self.entrance), False)
        navigate_to_rug.add_effect(self.robot_at(self.charge_station), False)
        navigate_to_rug.add_effect(self.robot_at(self.rug_area), True)

        navigate_to_station = InstantaneousAction("navigate_to_station")
        navigate_to_station.add_precondition(Not(self.robot_at(self.charge_station)))
        navigate_to_station.add_effect(self.robot_at(self.entrance), False)
        navigate_to_station.add_effect(self.robot_at(self.rug_area), False)
        navigate_to_station.add_effect(self.robot_at(self.charge_station), True)

        detect_rug = InstantaneousAction("detect_rug")
        detect_rug.add_precondition(self.robot_at(self.rug_area))
        detect_rug.add_precondition(self.rug_detection_available)
        detect_rug.add_precondition(Not(self.rug_secured))
        detect_rug.add_effect(self.rug_secured, True)

        clean_entrance = InstantaneousAction("clean_entrance")
        clean_entrance.add_precondition(self.robot_at(self.entrance))
        clean_entrance.add_precondition(self.dirt_at(self.general_dirt, self.entrance))
        clean_entrance.add_precondition(Not(self.floor_clean(self.entrance)))
        clean_entrance.add_effect(self.dirt_at(self.general_dirt, self.entrance), False)
        clean_entrance.add_effect(self.floor_clean(self.entrance), True)

        clean_rug = InstantaneousAction("clean_rug")
        clean_rug.add_precondition(self.robot_at(self.rug_area))
        clean_rug.add_precondition(Not(self.floor_clean(self.rug_area)))
        clean_rug.add_effect(self.floor_clean(self.rug_area), True)

        return navigate_to_entrance, navigate_to_rug, navigate_to_station, detect_rug, clean_entrance, clean_rug

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_rug": And([
                Not(self.rug_secured),  # Rug not secured
                self.robot_at(self.rug_area),  # Robot at rug area
                self.obstacle_avoidance_enabled,  # Obstacle avoidance available
                self.rug_detection_available  # Rug detection available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.charge_station), True)
        problem.set_initial_value(self.dirt_at(self.general_dirt, self.entrance), True)
        problem.set_initial_value(self.rug_detection_available, True)
        problem.set_initial_value(self.obstacle_avoidance_enabled, True)
        problem.set_initial_value(self.navigation_map_loaded, True)
        problem.set_initial_value(self.floor_sensors_working, True)
        problem.set_initial_value(self.rug_secured, False)

    def _set_goals(self, problem):
        problem.add_goal(self.floor_clean(self.entrance))
        problem.add_goal(self.floor_clean(self.rug_area))

if __name__ == "__main__":
    DomainPlanner().run_cli()