(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   monitor_top desk webcam_storage - location
   webcam coffee_cup - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (webcam_attached ?item - itemtype)
             (area_clear ?position - location)
             (setting_is_shared_office)
             (robot_has_sensor)
             (detection_available)
             (monitor_available)
             (safety_check_active)
 )
 (:action go_to_desk
  :parameters ()
  :precondition (and (not (robot_at desk)))
  :effect (and (not (robot_at webcam_storage)) (not (robot_at monitor_top)) (robot_at desk)))
 (:action go_to_monitor
  :parameters ()
  :precondition (and (not (robot_at monitor_top)))
  :effect (and (not (robot_at desk)) (not (robot_at webcam_storage)) (robot_at monitor_top)))
 (:action go_to_storage
  :parameters ()
  :precondition (and (not (robot_at webcam_storage)))
  :effect (and (not (robot_at desk)) (not (robot_at monitor_top)) (robot_at webcam_storage)))
 (:action pick_webcam
  :parameters ()
  :precondition (and (robot_at webcam_storage) (item_at webcam webcam_storage) (not (robot_has webcam)))
  :effect (and (not (item_at webcam webcam_storage)) (robot_has webcam)))
 (:action attach_webcam
  :parameters ()
  :precondition (and (robot_at monitor_top) (robot_has webcam) (not (webcam_attached webcam)))
  :effect (and (webcam_attached webcam) (not (robot_has webcam))))
 (:action clear_desk
  :parameters ()
  :precondition (and (robot_at desk) (item_at coffee_cup desk))
  :effect (and (not (item_at coffee_cup desk)) (area_clear desk)))
)
