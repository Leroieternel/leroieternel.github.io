(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at desk)
              (item_at webcam webcam_storage)
              (item_at coffee_cup desk)
              (setting_is_shared_office)
              (robot_has_sensor)
              (detection_available)
              (monitor_available)
              (safety_check_active)
 )
 (:goal (and 
           (webcam_attached webcam)
        )
 )
)
