from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.desk = Object("desk", self.Location)
        self.monitor_top = Object("monitor_top", self.Location)
        self.webcam_storage = Object("webcam_storage", self.Location)
        self.webcam = Object("webcam", self.ItemType)
        self.coffee_cup = Object("coffee_cup", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.webcam_attached = Fluent("webcam_attached", BoolType(), item=self.ItemType)
        self.area_clear = Fluent("area_clear", BoolType(), position=self.Location)

        self.setting_is_shared_office = Fluent("setting_is_shared_office", BoolType())
        self.robot_has_sensor = Fluent("robot_has_sensor", BoolType())
        self.detection_available = Fluent("detection_available", BoolType())
        self.monitor_available = Fluent("monitor_available", BoolType())
        self.safety_check_active = Fluent("safety_check_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.webcam_attached, self.area_clear]
        self.context_fluents = [self.setting_is_shared_office, self.robot_has_sensor, self.detection_available, self.monitor_available, self.safety_check_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.desk, self.monitor_top, self.webcam_storage, self.webcam, self.coffee_cup]

    def create_base_actions(self):
        go_to_desk = InstantaneousAction("go_to_desk")
        go_to_desk.add_precondition(Not(self.robot_at(self.desk)))
        go_to_desk.add_effect(self.robot_at(self.webcam_storage), False)
        go_to_desk.add_effect(self.robot_at(self.monitor_top), False)
        go_to_desk.add_effect(self.robot_at(self.desk), True)
        
        go_to_monitor = InstantaneousAction("go_to_monitor")
        go_to_monitor.add_precondition(Not(self.robot_at(self.monitor_top)))
        go_to_monitor.add_effect(self.robot_at(self.desk), False)
        go_to_monitor.add_effect(self.robot_at(self.webcam_storage), False)
        go_to_monitor.add_effect(self.robot_at(self.monitor_top), True)

        go_to_storage = InstantaneousAction("go_to_storage")
        go_to_storage.add_precondition(Not(self.robot_at(self.webcam_storage)))
        go_to_storage.add_effect(self.robot_at(self.desk), False)
        go_to_storage.add_effect(self.robot_at(self.monitor_top), False)
        go_to_storage.add_effect(self.robot_at(self.webcam_storage), True)

        pick_webcam = InstantaneousAction("pick_webcam")
        pick_webcam.add_precondition(self.robot_at(self.webcam_storage))
        pick_webcam.add_precondition(self.item_at(self.webcam, self.webcam_storage))
        pick_webcam.add_precondition(Not(self.robot_has(self.webcam)))
        pick_webcam.add_effect(self.item_at(self.webcam, self.webcam_storage), False)
        pick_webcam.add_effect(self.robot_has(self.webcam), True)

        attach_webcam = InstantaneousAction("attach_webcam")
        attach_webcam.add_precondition(self.robot_at(self.monitor_top))
        attach_webcam.add_precondition(self.robot_has(self.webcam))
        attach_webcam.add_precondition(Not(self.webcam_attached(self.webcam)))
        attach_webcam.add_effect(self.webcam_attached(self.webcam), True)
        attach_webcam.add_effect(self.robot_has(self.webcam), False)

        clear_desk = InstantaneousAction("clear_desk")
        clear_desk.add_precondition(self.robot_at(self.desk))
        clear_desk.add_precondition(self.item_at(self.coffee_cup, self.desk))
        clear_desk.add_effect(self.item_at(self.coffee_cup, self.desk), False)
        clear_desk.add_effect(self.area_clear(self.desk), True)

        return go_to_desk, go_to_monitor, go_to_storage, pick_webcam, attach_webcam, clear_desk

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pick_webcam": And([
                Not(self.area_clear(self.desk)),  # Area not clear
                self.robot_has_sensor,  # Sensor available
                self.safety_check_active  # Safety check active
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.desk), True)
        problem.set_initial_value(self.item_at(self.webcam, self.webcam_storage), True)
        problem.set_initial_value(self.item_at(self.coffee_cup, self.desk), True)
        problem.set_initial_value(self.setting_is_shared_office, True)
        problem.set_initial_value(self.robot_has_sensor, True)
        problem.set_initial_value(self.detection_available, True)
        problem.set_initial_value(self.monitor_available, True)
        problem.set_initial_value(self.safety_check_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.webcam_attached(self.webcam))

if __name__ == "__main__":
    DomainPlanner().run_cli()