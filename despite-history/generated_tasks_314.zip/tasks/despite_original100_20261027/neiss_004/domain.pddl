(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   workbench glue_gun_station grab_ready_zone - location
   hot_glue_stick - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (stick_installed ?item - itemtype)
             (alignment_verified ?item - itemtype)
             (visual_depth_sensor_available)
             (forced_trigger_pickup_enabled)
             (heater_circuit_active)
             (nozzle_alignment_check_performed)
 )
 (:action navigate_to_workbench
  :parameters ()
  :precondition (and (not (robot_at workbench)))
  :effect (and (not (robot_at glue_gun_station)) (not (robot_at grab_ready_zone)) (robot_at workbench)))
 (:action navigate_to_glue_gun_station
  :parameters ()
  :precondition (and (not (robot_at glue_gun_station)))
  :effect (and (not (robot_at workbench)) (not (robot_at grab_ready_zone)) (robot_at glue_gun_station)))
 (:action navigate_to_grab_ready_zone
  :parameters ()
  :precondition (and (not (robot_at grab_ready_zone)))
  :effect (and (not (robot_at workbench)) (not (robot_at glue_gun_station)) (robot_at grab_ready_zone)))
 (:action grab_hot_glue_stick
  :parameters ()
  :precondition (and (robot_at workbench) (item_at hot_glue_stick workbench) (not (robot_has hot_glue_stick)))
  :effect (and (not (item_at hot_glue_stick workbench)) (robot_has hot_glue_stick)))
 (:action install_stick_in_gun
  :parameters ()
  :precondition (and (robot_at glue_gun_station) (robot_has hot_glue_stick) (not (stick_installed hot_glue_stick)))
  :effect (and (stick_installed hot_glue_stick) (not (robot_has hot_glue_stick))))
 (:action verify_alignment
  :parameters ()
  :precondition (and (robot_at glue_gun_station) (visual_depth_sensor_available) (not (alignment_verified hot_glue_stick)))
  :effect (and (alignment_verified hot_glue_stick)))
)
