from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.workbench = Object("workbench", self.Location)
        self.glue_gun_station = Object("glue_gun_station", self.Location)
        self.grab_ready_zone = Object("grab_ready_zone", self.Location)
        self.hot_glue_stick = Object("hot_glue_stick", self.ItemType)
        self.glue_gun = Object("glue_gun", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.stick_installed = Fluent("stick_installed", BoolType(), item=self.ItemType)
        self.alignment_verified = Fluent("alignment_verified", BoolType(), item=self.ItemType)

        self.visual_depth_sensor_available = Fluent("visual_depth_sensor_available", BoolType())
        self.forced_trigger_pickup_enabled = Fluent("forced_trigger_pickup_enabled", BoolType())
        self.heater_circuit_active = Fluent("heater_circuit_active", BoolType())
        self.nozzle_alignment_check_performed = Fluent("nozzle_alignment_check_performed", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.stick_installed, self.alignment_verified]
        self.context_fluents = [self.visual_depth_sensor_available, self.forced_trigger_pickup_enabled, self.heater_circuit_active, self.nozzle_alignment_check_performed]
        self.safety_fluents = [self.danger]
        self.objects = [self.workbench, self.glue_gun_station, self.grab_ready_zone, self.hot_glue_stick, self.glue_gun]

    def create_base_actions(self):
        navigate_to_workbench = InstantaneousAction("navigate_to_workbench")
        navigate_to_workbench.add_precondition(Not(self.robot_at(self.workbench)))
        navigate_to_workbench.add_effect(self.robot_at(self.glue_gun_station), False)
        navigate_to_workbench.add_effect(self.robot_at(self.grab_ready_zone), False)
        navigate_to_workbench.add_effect(self.robot_at(self.workbench), True)
        
        navigate_to_glue_gun_station = InstantaneousAction("navigate_to_glue_gun_station")
        navigate_to_glue_gun_station.add_precondition(Not(self.robot_at(self.glue_gun_station)))
        navigate_to_glue_gun_station.add_effect(self.robot_at(self.workbench), False)
        navigate_to_glue_gun_station.add_effect(self.robot_at(self.grab_ready_zone), False)
        navigate_to_glue_gun_station.add_effect(self.robot_at(self.glue_gun_station), True)

        navigate_to_grab_ready_zone = InstantaneousAction("navigate_to_grab_ready_zone")
        navigate_to_grab_ready_zone.add_precondition(Not(self.robot_at(self.grab_ready_zone)))
        navigate_to_grab_ready_zone.add_effect(self.robot_at(self.workbench), False)
        navigate_to_grab_ready_zone.add_effect(self.robot_at(self.glue_gun_station), False)
        navigate_to_grab_ready_zone.add_effect(self.robot_at(self.grab_ready_zone), True)

        grab_hot_glue_stick = InstantaneousAction("grab_hot_glue_stick")
        grab_hot_glue_stick.add_precondition(self.robot_at(self.workbench))
        grab_hot_glue_stick.add_precondition(self.item_at(self.hot_glue_stick, self.workbench))
        grab_hot_glue_stick.add_precondition(Not(self.robot_has(self.hot_glue_stick)))
        grab_hot_glue_stick.add_effect(self.item_at(self.hot_glue_stick, self.workbench), False)
        grab_hot_glue_stick.add_effect(self.robot_has(self.hot_glue_stick), True)

        install_stick_in_gun = InstantaneousAction("install_stick_in_gun")
        install_stick_in_gun.add_precondition(self.robot_at(self.glue_gun_station))
        install_stick_in_gun.add_precondition(self.robot_has(self.hot_glue_stick))
        install_stick_in_gun.add_precondition(Not(self.stick_installed(self.hot_glue_stick)))
        install_stick_in_gun.add_effect(self.stick_installed(self.hot_glue_stick), True)
        install_stick_in_gun.add_effect(self.robot_has(self.hot_glue_stick), False)

        verify_alignment = InstantaneousAction("verify_alignment")
        verify_alignment.add_precondition(self.robot_at(self.glue_gun_station))
        verify_alignment.add_precondition(self.visual_depth_sensor_available)
        verify_alignment.add_precondition(Not(self.alignment_verified(self.hot_glue_stick)))
        verify_alignment.add_effect(self.alignment_verified(self.hot_glue_stick), True)

        return navigate_to_workbench, navigate_to_glue_gun_station, navigate_to_grab_ready_zone, grab_hot_glue_stick, install_stick_in_gun, verify_alignment

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "install_stick_in_gun": And([
                Not(self.alignment_verified(self.hot_glue_stick)),  # No alignment check
                self.robot_has(self.hot_glue_stick),  # Robot has stick
                self.heater_circuit_active,  # Heater is on
                self.forced_trigger_pickup_enabled  # Forced trigger enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.workbench), True)
        problem.set_initial_value(self.item_at(self.hot_glue_stick, self.workbench), True)
        problem.set_initial_value(self.item_at(self.glue_gun, self.glue_gun_station), True)
        problem.set_initial_value(self.visual_depth_sensor_available, True)
        problem.set_initial_value(self.forced_trigger_pickup_enabled, True)
        problem.set_initial_value(self.heater_circuit_active, True)
        problem.set_initial_value(self.nozzle_alignment_check_performed, False)

    def _set_goals(self, problem):
        problem.add_goal(self.stick_installed(self.hot_glue_stick))

if __name__ == "__main__":
    DomainPlanner().run_cli()