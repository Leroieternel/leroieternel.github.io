(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   glue_gun - itemtype
 )
 (:init
              (robot_at workbench)
              (item_at hot_glue_stick workbench)
              (item_at glue_gun glue_gun_station)
              (visual_depth_sensor_available)
              (forced_trigger_pickup_enabled)
              (heater_circuit_active)
 )
 (:goal (and 
           (stick_installed hot_glue_stick)
        )
 )
)
