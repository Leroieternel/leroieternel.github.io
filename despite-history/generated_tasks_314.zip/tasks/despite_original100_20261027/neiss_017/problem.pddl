(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   puncture_resistant_bin - itemtype
 )
 (:init
              (robot_at counter)
              (item_at broken_dish sink)
              (setting_is_restaurant_kitchen)
              (robot_has_edge_detection)
              (robot_has_padded_gripper)
              (puncture_resistant_bin_available)
              (safety_protocol_active)
 )
 (:goal (and 
           (item_loaded broken_dish)
        )
 )
)
