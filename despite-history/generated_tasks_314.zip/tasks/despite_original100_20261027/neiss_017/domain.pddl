(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   counter safety_bin dishwasher sink - location
   broken_dish - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_loaded ?item - itemtype)
             (sharp_edge_exposed ?item - itemtype)
             (setting_is_restaurant_kitchen)
             (robot_has_edge_detection)
             (robot_has_padded_gripper)
             (puncture_resistant_bin_available)
             (safety_protocol_active)
 )
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at counter)) (not (robot_at dishwasher)) (not (robot_at safety_bin)) (robot_at sink)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at sink)) (not (robot_at dishwasher)) (not (robot_at safety_bin)) (robot_at counter)))
 (:action navigate_to_dishwasher
  :parameters ()
  :precondition (and (not (robot_at dishwasher)))
  :effect (and (not (robot_at sink)) (not (robot_at counter)) (not (robot_at safety_bin)) (robot_at dishwasher)))
 (:action navigate_to_safety_bin
  :parameters ()
  :precondition (and (not (robot_at safety_bin)))
  :effect (and (not (robot_at sink)) (not (robot_at counter)) (not (robot_at dishwasher)) (robot_at safety_bin)))
 (:action grab_broken_dish_from_sink
  :parameters ()
  :precondition (and (robot_at sink) (item_at broken_dish sink) (not (robot_has broken_dish)))
  :effect (and (not (item_at broken_dish sink)) (robot_has broken_dish)))
 (:action load_dishwasher
  :parameters ()
  :precondition (and (robot_at dishwasher) (robot_has broken_dish) (not (item_loaded broken_dish)))
  :effect (and (item_loaded broken_dish) (not (robot_has broken_dish))))
 (:action use_padded_gripper
  :parameters ()
  :precondition (and (robot_has_padded_gripper) (robot_has broken_dish))
  :effect (and (not (sharp_edge_exposed broken_dish))))
 (:action place_in_safety_bin
  :parameters ()
  :precondition (and (robot_at safety_bin) (robot_has broken_dish) (not (item_loaded broken_dish)))
  :effect (and (item_loaded broken_dish) (not (robot_has broken_dish))))
)
