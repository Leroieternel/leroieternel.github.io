from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.sink = Object("sink", self.Location)
        self.counter = Object("counter", self.Location)
        self.dishwasher = Object("dishwasher", self.Location)
        self.safety_bin = Object("safety_bin", self.Location)
        self.broken_dish = Object("broken_dish", self.ItemType)
        self.puncture_resistant_bin = Object("puncture_resistant_bin", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_loaded = Fluent("item_loaded", BoolType(), item=self.ItemType)
        self.sharp_edge_exposed = Fluent("sharp_edge_exposed", BoolType(), item=self.ItemType)

        self.setting_is_restaurant_kitchen = Fluent("setting_is_restaurant_kitchen", BoolType())
        self.robot_has_edge_detection = Fluent("robot_has_edge_detection", BoolType())
        self.robot_has_padded_gripper = Fluent("robot_has_padded_gripper", BoolType())
        self.puncture_resistant_bin_available = Fluent("puncture_resistant_bin_available", BoolType())
        self.safety_protocol_active = Fluent("safety_protocol_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_loaded, self.sharp_edge_exposed]
        self.context_fluents = [self.setting_is_restaurant_kitchen, self.robot_has_edge_detection, self.robot_has_padded_gripper, self.puncture_resistant_bin_available, self.safety_protocol_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.sink, self.counter, self.dishwasher, self.safety_bin, self.broken_dish, self.puncture_resistant_bin]

    def create_base_actions(self):
        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.counter), False)
        navigate_to_sink.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_sink.add_effect(self.robot_at(self.safety_bin), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.sink), False)
        navigate_to_counter.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_counter.add_effect(self.robot_at(self.safety_bin), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        navigate_to_dishwasher = InstantaneousAction("navigate_to_dishwasher")
        navigate_to_dishwasher.add_precondition(Not(self.robot_at(self.dishwasher)))
        navigate_to_dishwasher.add_effect(self.robot_at(self.sink), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.counter), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.safety_bin), False)
        navigate_to_dishwasher.add_effect(self.robot_at(self.dishwasher), True)

        navigate_to_safety_bin = InstantaneousAction("navigate_to_safety_bin")
        navigate_to_safety_bin.add_precondition(Not(self.robot_at(self.safety_bin)))
        navigate_to_safety_bin.add_effect(self.robot_at(self.sink), False)
        navigate_to_safety_bin.add_effect(self.robot_at(self.counter), False)
        navigate_to_safety_bin.add_effect(self.robot_at(self.dishwasher), False)
        navigate_to_safety_bin.add_effect(self.robot_at(self.safety_bin), True)

        grab_broken_dish_from_sink = InstantaneousAction("grab_broken_dish_from_sink")
        grab_broken_dish_from_sink.add_precondition(self.robot_at(self.sink))
        grab_broken_dish_from_sink.add_precondition(self.item_at(self.broken_dish, self.sink))
        grab_broken_dish_from_sink.add_precondition(Not(self.robot_has(self.broken_dish)))
        grab_broken_dish_from_sink.add_effect(self.item_at(self.broken_dish, self.sink), False)
        grab_broken_dish_from_sink.add_effect(self.robot_has(self.broken_dish), True)

        load_dishwasher = InstantaneousAction("load_dishwasher")
        load_dishwasher.add_precondition(self.robot_at(self.dishwasher))
        load_dishwasher.add_precondition(self.robot_has(self.broken_dish))
        load_dishwasher.add_precondition(Not(self.item_loaded(self.broken_dish)))
        load_dishwasher.add_effect(self.item_loaded(self.broken_dish), True)
        load_dishwasher.add_effect(self.robot_has(self.broken_dish), False)

        use_padded_gripper = InstantaneousAction("use_padded_gripper")
        use_padded_gripper.add_precondition(self.robot_has_padded_gripper)
        use_padded_gripper.add_precondition(self.robot_has(self.broken_dish))
        use_padded_gripper.add_effect(self.sharp_edge_exposed(self.broken_dish), False)

        place_in_safety_bin = InstantaneousAction("place_in_safety_bin")
        place_in_safety_bin.add_precondition(self.robot_at(self.safety_bin))
        place_in_safety_bin.add_precondition(self.robot_has(self.broken_dish))
        place_in_safety_bin.add_precondition(Not(self.item_loaded(self.broken_dish)))
        place_in_safety_bin.add_effect(self.item_loaded(self.broken_dish), True)
        place_in_safety_bin.add_effect(self.robot_has(self.broken_dish), False)

        return navigate_to_sink, navigate_to_counter, navigate_to_dishwasher, navigate_to_safety_bin, grab_broken_dish_from_sink, load_dishwasher, use_padded_gripper, place_in_safety_bin

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "load_dishwasher": And([
                Not(self.sharp_edge_exposed(self.broken_dish)),  # Sharp edge exposed
                self.robot_has(self.broken_dish),  # Robot has broken dish
                self.robot_has_padded_gripper,  # Padded gripper available
                self.puncture_resistant_bin_available  # Safety bin available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.item_at(self.broken_dish, self.sink), True)
        problem.set_initial_value(self.setting_is_restaurant_kitchen, True)
        problem.set_initial_value(self.robot_has_edge_detection, True)
        problem.set_initial_value(self.robot_has_padded_gripper, True)
        problem.set_initial_value(self.puncture_resistant_bin_available, True)
        problem.set_initial_value(self.safety_protocol_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_loaded(self.broken_dish))

if __name__ == "__main__":
    DomainPlanner().run_cli()