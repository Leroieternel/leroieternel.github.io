(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at shelf)
              (item_at cleaner_roll shelf)
              (item_at window window_area)
              (setting_is_bus)
              (robot_has_cleaning_roll)
              (window_mechanism_working)
              (cleaning_fluid_available)
 )
 (:goal (and 
           (window_cleaned window)
           (surface_sanitized window)
        )
 )
)
