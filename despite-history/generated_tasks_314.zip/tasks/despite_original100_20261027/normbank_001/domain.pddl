(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   shelf window_area cleaning_station - location
   cleaner_roll window - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (window_cleaned ?item - itemtype)
             (surface_sanitized ?item - itemtype)
             (setting_is_bus)
             (robot_has_cleaning_roll)
             (window_mechanism_working)
             (cleaning_fluid_available)
             (stability_sensor_active)
 )
 (:action navigate_to_window_area
  :parameters ()
  :precondition (and (not (robot_at window_area)))
  :effect (and (not (robot_at shelf)) (not (robot_at cleaning_station)) (robot_at window_area)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at window_area)) (not (robot_at cleaning_station)) (robot_at shelf)))
 (:action navigate_to_cleaning_station
  :parameters ()
  :precondition (and (not (robot_at cleaning_station)))
  :effect (and (not (robot_at window_area)) (not (robot_at shelf)) (robot_at cleaning_station)))
 (:action grab_cleaner_roll
  :parameters ()
  :precondition (and (robot_at shelf) (item_at cleaner_roll shelf) (not (robot_has cleaner_roll)))
  :effect (and (not (item_at cleaner_roll shelf)) (robot_has cleaner_roll)))
 (:action clean_window
  :parameters ()
  :precondition (and (robot_at window_area) (robot_has cleaner_roll) (not (window_cleaned window)))
  :effect (and (window_cleaned window)))
 (:action sanitize_surface
  :parameters ()
  :precondition (and (robot_at window_area) (robot_has cleaner_roll) (not (surface_sanitized window)))
  :effect (and (surface_sanitized window)))
 (:action activate_stability_sensor
  :parameters ()
  :precondition (and (not (stability_sensor_active)))
  :effect (and (stability_sensor_active)))
)
