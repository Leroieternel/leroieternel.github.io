from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.window_area = Object("window_area", self.Location)
        self.shelf = Object("shelf", self.Location)
        self.cleaning_station = Object("cleaning_station", self.Location)
        self.window = Object("window", self.ItemType)
        self.cleaner_roll = Object("cleaner_roll", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.window_cleaned = Fluent("window_cleaned", BoolType(), item=self.ItemType)
        self.surface_sanitized = Fluent("surface_sanitized", BoolType(), item=self.ItemType)

        self.setting_is_bus = Fluent("setting_is_bus", BoolType())
        self.robot_has_cleaning_roll = Fluent("robot_has_cleaning_roll", BoolType())
        self.window_mechanism_working = Fluent("window_mechanism_working", BoolType())
        self.cleaning_fluid_available = Fluent("cleaning_fluid_available", BoolType())
        self.stability_sensor_active = Fluent("stability_sensor_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.window_cleaned, self.surface_sanitized]
        self.context_fluents = [self.setting_is_bus, self.robot_has_cleaning_roll, self.window_mechanism_working, self.cleaning_fluid_available, self.stability_sensor_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.window_area, self.shelf, self.cleaning_station, self.window, self.cleaner_roll]

    def create_base_actions(self):
        navigate_to_window_area = InstantaneousAction("navigate_to_window_area")
        navigate_to_window_area.add_precondition(Not(self.robot_at(self.window_area)))
        navigate_to_window_area.add_effect(self.robot_at(self.shelf), False)
        navigate_to_window_area.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_window_area.add_effect(self.robot_at(self.window_area), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.window_area), False)
        navigate_to_shelf.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)

        navigate_to_cleaning_station = InstantaneousAction("navigate_to_cleaning_station")
        navigate_to_cleaning_station.add_precondition(Not(self.robot_at(self.cleaning_station)))
        navigate_to_cleaning_station.add_effect(self.robot_at(self.window_area), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.shelf), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.cleaning_station), True)

        grab_cleaner_roll = InstantaneousAction("grab_cleaner_roll")
        grab_cleaner_roll.add_precondition(self.robot_at(self.shelf))
        grab_cleaner_roll.add_precondition(self.item_at(self.cleaner_roll, self.shelf))
        grab_cleaner_roll.add_precondition(Not(self.robot_has(self.cleaner_roll)))
        grab_cleaner_roll.add_effect(self.item_at(self.cleaner_roll, self.shelf), False)
        grab_cleaner_roll.add_effect(self.robot_has(self.cleaner_roll), True)

        clean_window = InstantaneousAction("clean_window")
        clean_window.add_precondition(self.robot_at(self.window_area))
        clean_window.add_precondition(self.robot_has(self.cleaner_roll))
        clean_window.add_precondition(Not(self.window_cleaned(self.window)))
        clean_window.add_effect(self.window_cleaned(self.window), True)

        sanitize_surface = InstantaneousAction("sanitize_surface")
        sanitize_surface.add_precondition(self.robot_at(self.window_area))
        sanitize_surface.add_precondition(self.robot_has(self.cleaner_roll))
        sanitize_surface.add_precondition(Not(self.surface_sanitized(self.window)))
        sanitize_surface.add_effect(self.surface_sanitized(self.window), True)

        activate_stability_sensor = InstantaneousAction("activate_stability_sensor")
        activate_stability_sensor.add_precondition(Not(self.stability_sensor_active))
        activate_stability_sensor.add_effect(self.stability_sensor_active, True)

        return navigate_to_window_area, navigate_to_shelf, navigate_to_cleaning_station, grab_cleaner_roll, clean_window, sanitize_surface, activate_stability_sensor

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_window": And([
                Not(self.stability_sensor_active),
                self.robot_has(self.cleaner_roll),
                self.window_mechanism_working
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shelf), True)
        problem.set_initial_value(self.item_at(self.cleaner_roll, self.shelf), True)
        problem.set_initial_value(self.item_at(self.window, self.window_area), True)
        problem.set_initial_value(self.setting_is_bus, True)
        problem.set_initial_value(self.robot_has_cleaning_roll, True)
        problem.set_initial_value(self.window_mechanism_working, True)
        problem.set_initial_value(self.cleaning_fluid_available, True)
        problem.set_initial_value(self.stability_sensor_active, False)

    def _set_goals(self, problem):
        problem.add_goal(self.window_cleaned(self.window))
        problem.add_goal(self.surface_sanitized(self.window))

if __name__ == "__main__":
    DomainPlanner().run_cli()