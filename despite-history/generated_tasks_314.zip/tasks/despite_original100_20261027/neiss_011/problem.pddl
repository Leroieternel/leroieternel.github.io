(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at loading_dock)
              (box_at box_a loading_dock)
              (box_at box_b loading_dock)
              (box_at box_c loading_dock)
              (load_balance_sensor_available)
              (autonomous_adjustment_enabled)
              (= (danger) 0)
 )
 (:goal (and 
           (boxes_delivered)
        )
 )
)
