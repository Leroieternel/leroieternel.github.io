(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location boxtype)
 (:constants
   staging_area destination_zone loading_dock - location
   box_b box_c box_a - boxtype
 )
 (:predicates 
             (robot_at ?position - location)
             (box_at ?box - boxtype ?position - location)
             (robot_has ?box - boxtype)
             (stack_even)
             (boxes_delivered)
             (stack_lifted)
             (load_balance_sensor_available)
             (sensor_used)
             (autonomous_adjustment_enabled)
 )
 (:action navigate_to_loading_dock
  :parameters ()
  :precondition (and (not (robot_at loading_dock)))
  :effect (and (not (robot_at staging_area)) (not (robot_at destination_zone)) (robot_at loading_dock)))
 (:action navigate_to_staging_area
  :parameters ()
  :precondition (and (not (robot_at staging_area)))
  :effect (and (not (robot_at loading_dock)) (not (robot_at destination_zone)) (robot_at staging_area)))
 (:action navigate_to_destination_zone
  :parameters ()
  :precondition (and (not (robot_at destination_zone)))
  :effect (and (not (robot_at loading_dock)) (not (robot_at staging_area)) (robot_at destination_zone)))
 (:action grab_box_a
  :parameters ()
  :precondition (and (robot_at loading_dock) (box_at box_a loading_dock) (not (robot_has box_a)))
  :effect (and (not (box_at box_a loading_dock)) (robot_has box_a)))
 (:action grab_box_b
  :parameters ()
  :precondition (and (robot_at loading_dock) (box_at box_b loading_dock) (not (robot_has box_b)))
  :effect (and (not (box_at box_b loading_dock)) (robot_has box_b)))
 (:action grab_box_c
  :parameters ()
  :precondition (and (robot_at loading_dock) (box_at box_c loading_dock) (not (robot_has box_c)))
  :effect (and (not (box_at box_c loading_dock)) (robot_has box_c)))
 (:action transport_to_staging_area
  :parameters ()
  :precondition (and (robot_at loading_dock) (robot_has box_a) (robot_has box_b) (robot_has box_c))
  :effect (and (not (robot_at loading_dock)) (robot_at staging_area) (not (robot_has box_a)) (not (robot_has box_b)) (not (robot_has box_c)) (box_at box_a staging_area) (box_at box_b staging_area) (box_at box_c staging_area)))
 (:action lift_stack
  :parameters ()
  :precondition (and (robot_at staging_area) (box_at box_a staging_area) (box_at box_b staging_area) (box_at box_c staging_area))
  :effect (and (not (box_at box_a staging_area)) (not (box_at box_b staging_area)) (not (box_at box_c staging_area)) (robot_has box_a) (robot_has box_b) (robot_has box_c) (stack_lifted)))
 (:action place_at_destination
  :parameters ()
  :precondition (and (robot_at destination_zone) (robot_has box_a) (robot_has box_b) (robot_has box_c) (stack_lifted))
  :effect (and (not (robot_has box_a)) (not (robot_has box_b)) (not (robot_has box_c)) (box_at box_a destination_zone) (box_at box_b destination_zone) (box_at box_c destination_zone) (boxes_delivered)))
 (:action detect_imbalance
  :parameters ()
  :precondition (and (robot_at staging_area) (box_at box_a staging_area) (box_at box_b staging_area) (box_at box_c staging_area) (load_balance_sensor_available) (not (sensor_used)))
  :effect (and (sensor_used)))
 (:action redistribute_boxes
  :parameters ()
  :precondition (and (robot_at staging_area) (box_at box_a staging_area) (box_at box_b staging_area) (box_at box_c staging_area) (sensor_used) (autonomous_adjustment_enabled))
  :effect (and (stack_even)))
)
