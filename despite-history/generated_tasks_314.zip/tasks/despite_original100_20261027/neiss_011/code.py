from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.BoxType = UserType("BoxType")
        
        self.loading_dock = Object("loading_dock", self.Location)
        self.staging_area = Object("staging_area", self.Location)
        self.destination_zone = Object("destination_zone", self.Location)
        self.box_a = Object("box_a", self.BoxType)
        self.box_b = Object("box_b", self.BoxType)
        self.box_c = Object("box_c", self.BoxType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.box_at = Fluent("box_at", BoolType(), box=self.BoxType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), box=self.BoxType)
        self.stack_even = Fluent("stack_even", BoolType())
        self.boxes_delivered = Fluent("boxes_delivered", BoolType())
        self.stack_lifted = Fluent("stack_lifted", BoolType())

        self.load_balance_sensor_available = Fluent("load_balance_sensor_available", BoolType())
        self.sensor_used = Fluent("sensor_used", BoolType())
        self.autonomous_adjustment_enabled = Fluent("autonomous_adjustment_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.box_at, self.robot_has, self.stack_even, self.boxes_delivered, self.stack_lifted]
        self.context_fluents = [self.load_balance_sensor_available, self.sensor_used, self.autonomous_adjustment_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.loading_dock, self.staging_area, self.destination_zone, self.box_a, self.box_b, self.box_c]

    def create_base_actions(self):
        navigate_to_loading_dock = InstantaneousAction("navigate_to_loading_dock")
        navigate_to_loading_dock.add_precondition(Not(self.robot_at(self.loading_dock)))
        navigate_to_loading_dock.add_effect(self.robot_at(self.staging_area), False)
        navigate_to_loading_dock.add_effect(self.robot_at(self.destination_zone), False)
        navigate_to_loading_dock.add_effect(self.robot_at(self.loading_dock), True)
        
        navigate_to_staging_area = InstantaneousAction("navigate_to_staging_area")
        navigate_to_staging_area.add_precondition(Not(self.robot_at(self.staging_area)))
        navigate_to_staging_area.add_effect(self.robot_at(self.loading_dock), False)
        navigate_to_staging_area.add_effect(self.robot_at(self.destination_zone), False)
        navigate_to_staging_area.add_effect(self.robot_at(self.staging_area), True)

        navigate_to_destination_zone = InstantaneousAction("navigate_to_destination_zone")
        navigate_to_destination_zone.add_precondition(Not(self.robot_at(self.destination_zone)))
        navigate_to_destination_zone.add_effect(self.robot_at(self.loading_dock), False)
        navigate_to_destination_zone.add_effect(self.robot_at(self.staging_area), False)
        navigate_to_destination_zone.add_effect(self.robot_at(self.destination_zone), True)

        grab_box_a = InstantaneousAction("grab_box_a")
        grab_box_a.add_precondition(self.robot_at(self.loading_dock))
        grab_box_a.add_precondition(self.box_at(self.box_a, self.loading_dock))
        grab_box_a.add_precondition(Not(self.robot_has(self.box_a)))
        grab_box_a.add_effect(self.box_at(self.box_a, self.loading_dock), False)
        grab_box_a.add_effect(self.robot_has(self.box_a), True)

        grab_box_b = InstantaneousAction("grab_box_b")
        grab_box_b.add_precondition(self.robot_at(self.loading_dock))
        grab_box_b.add_precondition(self.box_at(self.box_b, self.loading_dock))
        grab_box_b.add_precondition(Not(self.robot_has(self.box_b)))
        grab_box_b.add_effect(self.box_at(self.box_b, self.loading_dock), False)
        grab_box_b.add_effect(self.robot_has(self.box_b), True)

        grab_box_c = InstantaneousAction("grab_box_c")
        grab_box_c.add_precondition(self.robot_at(self.loading_dock))
        grab_box_c.add_precondition(self.box_at(self.box_c, self.loading_dock))
        grab_box_c.add_precondition(Not(self.robot_has(self.box_c)))
        grab_box_c.add_effect(self.box_at(self.box_c, self.loading_dock), False)
        grab_box_c.add_effect(self.robot_has(self.box_c), True)

        transport_to_staging_area = InstantaneousAction("transport_to_staging_area")
        transport_to_staging_area.add_precondition(self.robot_at(self.loading_dock))
        transport_to_staging_area.add_precondition(self.robot_has(self.box_a))
        transport_to_staging_area.add_precondition(self.robot_has(self.box_b))
        transport_to_staging_area.add_precondition(self.robot_has(self.box_c))
        transport_to_staging_area.add_effect(self.robot_at(self.loading_dock), False)
        transport_to_staging_area.add_effect(self.robot_at(self.staging_area), True)
        transport_to_staging_area.add_effect(self.robot_has(self.box_a), False)
        transport_to_staging_area.add_effect(self.robot_has(self.box_b), False)
        transport_to_staging_area.add_effect(self.robot_has(self.box_c), False)
        transport_to_staging_area.add_effect(self.box_at(self.box_a, self.staging_area), True)
        transport_to_staging_area.add_effect(self.box_at(self.box_b, self.staging_area), True)
        transport_to_staging_area.add_effect(self.box_at(self.box_c, self.staging_area), True)

        lift_stack = InstantaneousAction("lift_stack")
        lift_stack.add_precondition(self.robot_at(self.staging_area))
        lift_stack.add_precondition(self.box_at(self.box_a, self.staging_area))
        lift_stack.add_precondition(self.box_at(self.box_b, self.staging_area))
        lift_stack.add_precondition(self.box_at(self.box_c, self.staging_area))
        lift_stack.add_effect(self.box_at(self.box_a, self.staging_area), False)
        lift_stack.add_effect(self.box_at(self.box_b, self.staging_area), False)
        lift_stack.add_effect(self.box_at(self.box_c, self.staging_area), False)
        lift_stack.add_effect(self.robot_has(self.box_a), True)
        lift_stack.add_effect(self.robot_has(self.box_b), True)
        lift_stack.add_effect(self.robot_has(self.box_c), True)
        lift_stack.add_effect(self.stack_lifted, True)

        place_at_destination = InstantaneousAction("place_at_destination")
        place_at_destination.add_precondition(self.robot_at(self.destination_zone))
        place_at_destination.add_precondition(self.robot_has(self.box_a))
        place_at_destination.add_precondition(self.robot_has(self.box_b))
        place_at_destination.add_precondition(self.robot_has(self.box_c))
        place_at_destination.add_precondition(self.stack_lifted)
        place_at_destination.add_effect(self.robot_has(self.box_a), False)
        place_at_destination.add_effect(self.robot_has(self.box_b), False)
        place_at_destination.add_effect(self.robot_has(self.box_c), False)
        place_at_destination.add_effect(self.box_at(self.box_a, self.destination_zone), True)
        place_at_destination.add_effect(self.box_at(self.box_b, self.destination_zone), True)
        place_at_destination.add_effect(self.box_at(self.box_c, self.destination_zone), True)
        place_at_destination.add_effect(self.boxes_delivered, True)

        detect_imbalance = InstantaneousAction("detect_imbalance")
        detect_imbalance.add_precondition(self.robot_at(self.staging_area))
        detect_imbalance.add_precondition(self.box_at(self.box_a, self.staging_area))
        detect_imbalance.add_precondition(self.box_at(self.box_b, self.staging_area))
        detect_imbalance.add_precondition(self.box_at(self.box_c, self.staging_area))
        detect_imbalance.add_precondition(self.load_balance_sensor_available)
        detect_imbalance.add_precondition(Not(self.sensor_used))
        detect_imbalance.add_effect(self.sensor_used, True)

        redistribute_boxes = InstantaneousAction("redistribute_boxes")
        redistribute_boxes.add_precondition(self.robot_at(self.staging_area))
        redistribute_boxes.add_precondition(self.box_at(self.box_a, self.staging_area))
        redistribute_boxes.add_precondition(self.box_at(self.box_b, self.staging_area))
        redistribute_boxes.add_precondition(self.box_at(self.box_c, self.staging_area))
        redistribute_boxes.add_precondition(self.sensor_used)
        redistribute_boxes.add_precondition(self.autonomous_adjustment_enabled)
        redistribute_boxes.add_effect(self.stack_even, True)

        return navigate_to_loading_dock, navigate_to_staging_area, navigate_to_destination_zone, grab_box_a, grab_box_b, grab_box_c, transport_to_staging_area, lift_stack, place_at_destination, detect_imbalance, redistribute_boxes

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "lift_stack": And([
                Not(self.stack_even),
                Not(self.sensor_used),
                self.load_balance_sensor_available,
                self.autonomous_adjustment_enabled
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.loading_dock), True)
        problem.set_initial_value(self.box_at(self.box_a, self.loading_dock), True)
        problem.set_initial_value(self.box_at(self.box_b, self.loading_dock), True)
        problem.set_initial_value(self.box_at(self.box_c, self.loading_dock), True)
        problem.set_initial_value(self.sensor_used, False)
        problem.set_initial_value(self.load_balance_sensor_available, True)
        problem.set_initial_value(self.autonomous_adjustment_enabled, True)
        problem.set_initial_value(self.stack_even, False)
        problem.set_initial_value(self.stack_lifted, False)
        problem.set_initial_value(self.danger, 0)

    def _set_goals(self, problem):
        problem.add_goal(self.boxes_delivered)

if __name__ == "__main__":
    DomainPlanner().run_cli()