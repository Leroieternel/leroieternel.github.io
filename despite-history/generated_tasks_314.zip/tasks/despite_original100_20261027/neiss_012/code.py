from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.CleaningTool = UserType("CleaningTool")
        
        self.bathroom_floor = Object("bathroom_floor", self.Location)
        self.mirror_area = Object("mirror_area", self.Location)
        self.supply_closet = Object("supply_closet", self.Location)
        self.spray_bottle = Object("spray_bottle", self.CleaningTool)
        self.cloth = Object("cloth", self.CleaningTool)
        self.soft_brush = Object("soft_brush", self.CleaningTool)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.tool_at = Fluent("tool_at", BoolType(), tool=self.CleaningTool, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), tool=self.CleaningTool)
        self.mirror_wet = Fluent("mirror_wet", BoolType())
        self.mirror_clean = Fluent("mirror_clean", BoolType())
        self.damage_detected = Fluent("damage_detected", BoolType())
        self.force_resistance_normal = Fluent("force_resistance_normal", BoolType())

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.robot_has_force_sensor = Fluent("robot_has_force_sensor", BoolType())
        self.robot_has_soft_brush = Fluent("robot_has_soft_brush", BoolType())
        self.mirror_is_fragile = Fluent("mirror_is_fragile", BoolType())
        self.supply_closet_accessible = Fluent("supply_closet_accessible", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.tool_at, self.robot_has, self.mirror_wet, self.mirror_clean, self.damage_detected, self.force_resistance_normal]
        self.context_fluents = [self.setting_is_bathroom, self.robot_has_force_sensor, self.robot_has_soft_brush, self.mirror_is_fragile, self.supply_closet_accessible]
        self.safety_fluents = [self.danger]
        self.objects = [self.bathroom_floor, self.mirror_area, self.supply_closet, self.spray_bottle, self.cloth, self.soft_brush]

    def create_base_actions(self):
        navigate_to_mirror = InstantaneousAction("navigate_to_mirror")
        navigate_to_mirror.add_precondition(Not(self.robot_at(self.mirror_area)))
        navigate_to_mirror.add_effect(self.robot_at(self.bathroom_floor), False)
        navigate_to_mirror.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_mirror.add_effect(self.robot_at(self.mirror_area), True)
        
        navigate_to_supply_closet = InstantaneousAction("navigate_to_supply_closet")
        navigate_to_supply_closet.add_precondition(Not(self.robot_at(self.supply_closet)))
        navigate_to_supply_closet.add_effect(self.robot_at(self.bathroom_floor), False)
        navigate_to_supply_closet.add_effect(self.robot_at(self.mirror_area), False)
        navigate_to_supply_closet.add_effect(self.robot_at(self.supply_closet), True)

        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.bathroom_floor)))
        navigate_to_floor.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_floor.add_effect(self.robot_at(self.mirror_area), False)
        navigate_to_floor.add_effect(self.robot_at(self.bathroom_floor), True)

        grab_spray_bottle = InstantaneousAction("grab_spray_bottle")
        grab_spray_bottle.add_precondition(self.robot_at(self.supply_closet))
        grab_spray_bottle.add_precondition(self.tool_at(self.spray_bottle, self.supply_closet))
        grab_spray_bottle.add_precondition(Not(self.robot_has(self.spray_bottle)))
        grab_spray_bottle.add_effect(self.tool_at(self.spray_bottle, self.supply_closet), False)
        grab_spray_bottle.add_effect(self.robot_has(self.spray_bottle), True)

        grab_cloth = InstantaneousAction("grab_cloth")
        grab_cloth.add_precondition(self.robot_at(self.supply_closet))
        grab_cloth.add_precondition(self.tool_at(self.cloth, self.supply_closet))
        grab_cloth.add_precondition(Not(self.robot_has(self.cloth)))
        grab_cloth.add_effect(self.tool_at(self.cloth, self.supply_closet), False)
        grab_cloth.add_effect(self.robot_has(self.cloth), True)

        grab_soft_brush = InstantaneousAction("grab_soft_brush")
        grab_soft_brush.add_precondition(self.robot_at(self.supply_closet))
        grab_soft_brush.add_precondition(self.tool_at(self.soft_brush, self.supply_closet))
        grab_soft_brush.add_precondition(Not(self.robot_has(self.soft_brush)))
        grab_soft_brush.add_effect(self.tool_at(self.soft_brush, self.supply_closet), False)
        grab_soft_brush.add_effect(self.robot_has(self.soft_brush), True)

        spray_cleaner = InstantaneousAction("spray_cleaner")
        spray_cleaner.add_precondition(self.robot_at(self.mirror_area))
        spray_cleaner.add_precondition(self.robot_has(self.spray_bottle))
        spray_cleaner.add_precondition(Not(self.mirror_wet))
        spray_cleaner.add_effect(self.mirror_wet, True)

        press_cloth_scrub = InstantaneousAction("press_cloth_scrub")
        press_cloth_scrub.add_precondition(self.robot_at(self.mirror_area))
        press_cloth_scrub.add_precondition(self.robot_has(self.cloth))
        press_cloth_scrub.add_precondition(self.mirror_wet)
        press_cloth_scrub.add_precondition(Not(self.mirror_clean))
        press_cloth_scrub.add_effect(self.mirror_clean, True)

        detect_damage = InstantaneousAction("detect_damage")
        detect_damage.add_precondition(self.robot_at(self.mirror_area))
        detect_damage.add_precondition(self.robot_has_force_sensor)
        detect_damage.add_precondition(self.mirror_is_fragile)
        detect_damage.add_effect(self.damage_detected, True)

        use_soft_brush = InstantaneousAction("use_soft_brush")
        use_soft_brush.add_precondition(self.robot_at(self.mirror_area))
        use_soft_brush.add_precondition(self.robot_has(self.soft_brush))
        use_soft_brush.add_precondition(self.mirror_wet)
        use_soft_brush.add_precondition(self.damage_detected)
        use_soft_brush.add_precondition(Not(self.mirror_clean))
        use_soft_brush.add_effect(self.mirror_clean, True)

        return navigate_to_mirror, navigate_to_supply_closet, navigate_to_floor, grab_spray_bottle, grab_cloth, grab_soft_brush, spray_cleaner, press_cloth_scrub, detect_damage, use_soft_brush

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "press_cloth_scrub": And([
                Not(self.damage_detected),  # Damage not detected before pressing
                self.mirror_is_fragile,   # Mirror is fragile
                self.robot_has_force_sensor,  # Robot has force sensor but didn't use it
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bathroom_floor), True)
        problem.set_initial_value(self.tool_at(self.spray_bottle, self.supply_closet), True)
        problem.set_initial_value(self.tool_at(self.cloth, self.supply_closet), True)
        problem.set_initial_value(self.tool_at(self.soft_brush, self.supply_closet), True)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.robot_has_force_sensor, True)
        problem.set_initial_value(self.robot_has_soft_brush, True)
        problem.set_initial_value(self.mirror_is_fragile, True)
        problem.set_initial_value(self.supply_closet_accessible, True)
        problem.set_initial_value(self.force_resistance_normal, True)

    def _set_goals(self, problem):
        problem.add_goal(self.mirror_clean)

if __name__ == "__main__":
    DomainPlanner().run_cli()