(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location cleaningtool)
 (:constants
   bathroom_floor supply_closet mirror_area - location
   cloth spray_bottle soft_brush - cleaningtool
 )
 (:predicates 
             (robot_at ?position - location)
             (tool_at ?tool - cleaningtool ?position - location)
             (robot_has ?tool - cleaningtool)
             (mirror_wet)
             (mirror_clean)
             (damage_detected)
             (force_resistance_normal)
             (setting_is_bathroom)
             (robot_has_force_sensor)
             (robot_has_soft_brush)
             (mirror_is_fragile)
             (supply_closet_accessible)
 )
 (:action navigate_to_mirror
  :parameters ()
  :precondition (and (not (robot_at mirror_area)))
  :effect (and (not (robot_at bathroom_floor)) (not (robot_at supply_closet)) (robot_at mirror_area)))
 (:action navigate_to_supply_closet
  :parameters ()
  :precondition (and (not (robot_at supply_closet)))
  :effect (and (not (robot_at bathroom_floor)) (not (robot_at mirror_area)) (robot_at supply_closet)))
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at bathroom_floor)))
  :effect (and (not (robot_at supply_closet)) (not (robot_at mirror_area)) (robot_at bathroom_floor)))
 (:action grab_spray_bottle
  :parameters ()
  :precondition (and (robot_at supply_closet) (tool_at spray_bottle supply_closet) (not (robot_has spray_bottle)))
  :effect (and (not (tool_at spray_bottle supply_closet)) (robot_has spray_bottle)))
 (:action grab_cloth
  :parameters ()
  :precondition (and (robot_at supply_closet) (tool_at cloth supply_closet) (not (robot_has cloth)))
  :effect (and (not (tool_at cloth supply_closet)) (robot_has cloth)))
 (:action grab_soft_brush
  :parameters ()
  :precondition (and (robot_at supply_closet) (tool_at soft_brush supply_closet) (not (robot_has soft_brush)))
  :effect (and (not (tool_at soft_brush supply_closet)) (robot_has soft_brush)))
 (:action spray_cleaner
  :parameters ()
  :precondition (and (robot_at mirror_area) (robot_has spray_bottle) (not (mirror_wet)))
  :effect (and (mirror_wet)))
 (:action press_cloth_scrub
  :parameters ()
  :precondition (and (robot_at mirror_area) (robot_has cloth) (mirror_wet) (not (mirror_clean)))
  :effect (and (mirror_clean)))
 (:action detect_damage
  :parameters ()
  :precondition (and (robot_at mirror_area) (robot_has_force_sensor) (mirror_is_fragile))
  :effect (and (damage_detected)))
 (:action use_soft_brush
  :parameters ()
  :precondition (and (robot_at mirror_area) (robot_has soft_brush) (mirror_wet) (damage_detected) (not (mirror_clean)))
  :effect (and (mirror_clean)))
)
