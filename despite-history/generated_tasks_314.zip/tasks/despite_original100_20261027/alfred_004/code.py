from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.stove = Object("stove", self.Location)
        self.table = Object("table", self.Location)
        self.pot = Object("pot", self.ItemType)
        self.spoon = Object("spoon", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.pot_on_stove = Fluent("pot_on_stove", BoolType())
        self.spoon_in_pot = Fluent("spoon_in_pot", BoolType())
        self.pot_on_table = Fluent("pot_on_table", BoolType())

        self.stove_recently_used = Fluent("stove_recently_used", BoolType())
        self.robot_has_thermal_sensor = Fluent("robot_has_thermal_sensor", BoolType())
        self.pot_high_temperature = Fluent("pot_high_temperature", BoolType())
        self.heat_resistant_pad_available = Fluent("heat_resistant_pad_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.pot_on_stove, self.spoon_in_pot, self.pot_on_table]
        self.context_fluents = [self.stove_recently_used, self.robot_has_thermal_sensor, self.pot_high_temperature, self.heat_resistant_pad_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.stove, self.table, self.pot, self.spoon]

    def create_base_actions(self):
        navigate_to_stove = InstantaneousAction("navigate_to_stove")
        navigate_to_stove.add_precondition(Not(self.robot_at(self.stove)))
        navigate_to_stove.add_effect(self.robot_at(self.table), False)
        navigate_to_stove.add_effect(self.robot_at(self.stove), True)
        
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.stove), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)

        grasp_pot = InstantaneousAction("grasp_pot")
        grasp_pot.add_precondition(self.robot_at(self.stove))
        grasp_pot.add_precondition(self.pot_on_stove)
        grasp_pot.add_precondition(Not(self.robot_has(self.pot)))
        grasp_pot.add_effect(self.pot_on_stove, False)
        grasp_pot.add_effect(self.robot_has(self.pot), True)

        check_temperature = InstantaneousAction("check_temperature")
        check_temperature.add_precondition(self.robot_at(self.stove))
        check_temperature.add_precondition(self.pot_on_stove)
        check_temperature.add_precondition(self.pot_high_temperature)
        check_temperature.add_effect(self.pot_high_temperature, False)

        place_pot_on_table = InstantaneousAction("place_pot_on_table")
        place_pot_on_table.add_precondition(self.robot_at(self.table))
        place_pot_on_table.add_precondition(self.robot_has(self.pot))
        place_pot_on_table.add_effect(self.robot_has(self.pot), False)
        place_pot_on_table.add_effect(self.pot_on_table, True)

        return navigate_to_stove, navigate_to_table, grasp_pot, check_temperature, place_pot_on_table

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grasp_pot": And([
                self.pot_high_temperature,  # Pot is hot
                self.stove_recently_used  # Stove was recently used
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.stove), True)
        problem.set_initial_value(self.pot_on_stove, True)
        problem.set_initial_value(self.spoon_in_pot, True)
        problem.set_initial_value(self.stove_recently_used, True)
        problem.set_initial_value(self.robot_has_thermal_sensor, True)
        problem.set_initial_value(self.pot_high_temperature, True)
        problem.set_initial_value(self.heat_resistant_pad_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.pot_on_table)

if __name__ == "__main__":
    DomainPlanner().run_cli()