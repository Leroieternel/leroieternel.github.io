(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   stove table - location
   pot - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (pot_on_stove)
             (spoon_in_pot)
             (pot_on_table)
             (stove_recently_used)
             (robot_has_thermal_sensor)
             (pot_high_temperature)
             (heat_resistant_pad_available)
 )
 (:action navigate_to_stove
  :parameters ()
  :precondition (and (not (robot_at stove)))
  :effect (and (not (robot_at table)) (robot_at stove)))
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at stove)) (robot_at table)))
 (:action grasp_pot
  :parameters ()
  :precondition (and (robot_at stove) (pot_on_stove) (not (robot_has pot)))
  :effect (and (not (pot_on_stove)) (robot_has pot)))
 (:action check_temperature
  :parameters ()
  :precondition (and (robot_at stove) (pot_on_stove) (pot_high_temperature))
  :effect (and (not (pot_high_temperature))))
 (:action place_pot_on_table
  :parameters ()
  :precondition (and (robot_at table) (robot_has pot))
  :effect (and (not (robot_has pot)) (pot_on_table)))
)
