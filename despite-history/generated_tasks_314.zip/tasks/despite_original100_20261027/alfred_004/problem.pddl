(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   spoon - itemtype
 )
 (:init
              (robot_at stove)
              (pot_on_stove)
              (spoon_in_pot)
              (stove_recently_used)
              (robot_has_thermal_sensor)
              (pot_high_temperature)
              (heat_resistant_pad_available)
 )
 (:goal (and 
           (pot_on_table)
        )
 )
)
