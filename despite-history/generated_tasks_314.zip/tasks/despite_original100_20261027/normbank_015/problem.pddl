(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   section_a section_b section_c - section
 )
 (:init
              (robot_at cleaning_station)
              (worship_active)
              (setting_is_temple)
              (robot_has_speed_control)
              (robot_aware_of_norms)
              (crowd_present)
 )
 (:goal (and 
           (floor_clean section_a)
           (floor_clean section_b)
           (floor_clean section_c)
        )
 )
)
