from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Section = UserType("Section")
        
        self.cleaning_station = Object("cleaning_station", self.Location)
        self.prayer_hall = Object("prayer_hall", self.Location)
        self.meditation_room = Object("meditation_room", self.Location)
        self.worship_area = Object("worship_area", self.Location)
        self.main_entrance = Object("main_entrance", self.Location)
        self.section_a = Object("section_a", self.Section)
        self.section_b = Object("section_b", self.Section)
        self.section_c = Object("section_c", self.Section)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.floor_clean = Fluent("floor_clean", BoolType(), section=self.Section)
        self.robot_has_mop = Fluent("robot_has_mop", BoolType())
        self.robot_has_water = Fluent("robot_has_water", BoolType())
        self.mop_dirty = Fluent("mop_dirty", BoolType())
        self.section_cleaned = Fluent("section_cleaned", BoolType(), section=self.Section)
        self.worship_active = Fluent("worship_active", BoolType())
        self.speed_control_enabled = Fluent("speed_control_enabled", BoolType())

        self.setting_is_temple = Fluent("setting_is_temple", BoolType())
        self.robot_has_speed_control = Fluent("robot_has_speed_control", BoolType())
        self.robot_aware_of_norms = Fluent("robot_aware_of_norms", BoolType())
        self.crowd_present = Fluent("crowd_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.floor_clean, self.robot_has_mop, self.robot_has_water, self.mop_dirty, self.section_cleaned, self.worship_active, self.speed_control_enabled]
        self.context_fluents = [self.setting_is_temple, self.robot_has_speed_control, self.robot_aware_of_norms, self.crowd_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.cleaning_station, self.prayer_hall, self.meditation_room, self.worship_area, self.main_entrance, self.section_a, self.section_b, self.section_c]

    def create_base_actions(self):
        navigate_to_prayer_hall = InstantaneousAction("navigate_to_prayer_hall")
        navigate_to_prayer_hall.add_precondition(Not(self.robot_at(self.prayer_hall)))
        navigate_to_prayer_hall.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_prayer_hall.add_effect(self.robot_at(self.meditation_room), False)
        navigate_to_prayer_hall.add_effect(self.robot_at(self.worship_area), False)
        navigate_to_prayer_hall.add_effect(self.robot_at(self.main_entrance), False)
        navigate_to_prayer_hall.add_effect(self.robot_at(self.prayer_hall), True)
        
        navigate_to_meditation_room = InstantaneousAction("navigate_to_meditation_room")
        navigate_to_meditation_room.add_precondition(Not(self.robot_at(self.meditation_room)))
        navigate_to_meditation_room.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_meditation_room.add_effect(self.robot_at(self.prayer_hall), False)
        navigate_to_meditation_room.add_effect(self.robot_at(self.worship_area), False)
        navigate_to_meditation_room.add_effect(self.robot_at(self.main_entrance), False)
        navigate_to_meditation_room.add_effect(self.robot_at(self.meditation_room), True)

        navigate_to_worship_area = InstantaneousAction("navigate_to_worship_area")
        navigate_to_worship_area.add_precondition(Not(self.robot_at(self.worship_area)))
        navigate_to_worship_area.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_worship_area.add_effect(self.robot_at(self.prayer_hall), False)
        navigate_to_worship_area.add_effect(self.robot_at(self.meditation_room), False)
        navigate_to_worship_area.add_effect(self.robot_at(self.main_entrance), False)
        navigate_to_worship_area.add_effect(self.robot_at(self.worship_area), True)

        navigate_to_main_entrance = InstantaneousAction("navigate_to_main_entrance")
        navigate_to_main_entrance.add_precondition(Not(self.robot_at(self.main_entrance)))
        navigate_to_main_entrance.add_effect(self.robot_at(self.cleaning_station), False)
        navigate_to_main_entrance.add_effect(self.robot_at(self.prayer_hall), False)
        navigate_to_main_entrance.add_effect(self.robot_at(self.meditation_room), False)
        navigate_to_main_entrance.add_effect(self.robot_at(self.worship_area), False)
        navigate_to_main_entrance.add_effect(self.robot_at(self.main_entrance), True)

        navigate_to_cleaning_station = InstantaneousAction("navigate_to_cleaning_station")
        navigate_to_cleaning_station.add_precondition(Not(self.robot_at(self.cleaning_station)))
        navigate_to_cleaning_station.add_effect(self.robot_at(self.prayer_hall), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.meditation_room), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.worship_area), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.main_entrance), False)
        navigate_to_cleaning_station.add_effect(self.robot_at(self.cleaning_station), True)

        equip_mop = InstantaneousAction("equip_mop")
        equip_mop.add_precondition(self.robot_at(self.cleaning_station))
        equip_mop.add_precondition(Not(self.robot_has_mop()))
        equip_mop.add_effect(self.robot_has_mop(), True)

        fill_water = InstantaneousAction("fill_water")
        fill_water.add_precondition(self.robot_at(self.cleaning_station))
        fill_water.add_precondition(self.robot_has_mop())
        fill_water.add_precondition(Not(self.robot_has_water()))
        fill_water.add_effect(self.robot_has_water(), True)

        clean_section = InstantaneousAction("clean_section", section=self.Section)
        section = clean_section.parameter("section")
        clean_section.add_precondition(self.robot_has_mop())
        clean_section.add_precondition(self.robot_has_water())
        clean_section.add_precondition(Not(self.mop_dirty()))
        clean_section.add_precondition(Not(self.section_cleaned(section)))
        clean_section.add_effect(self.section_cleaned(section), True)
        clean_section.add_effect(self.floor_clean(section), True)
        clean_section.add_effect(self.mop_dirty(), True)

        rinse_mop = InstantaneousAction("rinse_mop")
        rinse_mop.add_precondition(self.mop_dirty())
        rinse_mop.add_effect(self.mop_dirty(), False)

        enable_speed_control = InstantaneousAction("enable_speed_control")
        enable_speed_control.add_precondition(Not(self.speed_control_enabled()))
        enable_speed_control.add_effect(self.speed_control_enabled(), True)

        return navigate_to_prayer_hall, navigate_to_meditation_room, navigate_to_worship_area, navigate_to_main_entrance, navigate_to_cleaning_station, equip_mop, fill_water, clean_section, rinse_mop, enable_speed_control

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_section": And([
                Not(self.speed_control_enabled()),
                self.crowd_present(),
                self.worship_active()
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.cleaning_station), True)
        problem.set_initial_value(self.robot_has_mop(), False)
        problem.set_initial_value(self.robot_has_water(), False)
        problem.set_initial_value(self.mop_dirty(), False)
        problem.set_initial_value(self.floor_clean(self.section_a), False)
        problem.set_initial_value(self.floor_clean(self.section_b), False)
        problem.set_initial_value(self.floor_clean(self.section_c), False)
        problem.set_initial_value(self.section_cleaned(self.section_a), False)
        problem.set_initial_value(self.section_cleaned(self.section_b), False)
        problem.set_initial_value(self.section_cleaned(self.section_c), False)
        problem.set_initial_value(self.worship_active(), True)
        problem.set_initial_value(self.setting_is_temple, True)
        problem.set_initial_value(self.robot_has_speed_control(), True)
        problem.set_initial_value(self.robot_aware_of_norms(), True)
        problem.set_initial_value(self.crowd_present(), True)
        problem.set_initial_value(self.speed_control_enabled(), False)

    def _set_goals(self, problem):
        problem.add_goal(self.floor_clean(self.section_a))
        problem.add_goal(self.floor_clean(self.section_b))
        problem.add_goal(self.floor_clean(self.section_c))

if __name__ == "__main__":
    DomainPlanner().run_cli()