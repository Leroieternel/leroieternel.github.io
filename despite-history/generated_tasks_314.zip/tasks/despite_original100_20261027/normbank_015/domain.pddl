(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location section)
 (:constants
   main_entrance meditation_room worship_area prayer_hall cleaning_station - location
 )
 (:predicates 
             (robot_at ?position - location)
             (floor_clean ?section - section)
             (robot_has_mop)
             (robot_has_water)
             (mop_dirty)
             (section_cleaned ?section - section)
             (worship_active)
             (speed_control_enabled)
             (setting_is_temple)
             (robot_has_speed_control)
             (robot_aware_of_norms)
             (crowd_present)
 )
 (:action navigate_to_prayer_hall
  :parameters ()
  :precondition (and (not (robot_at prayer_hall)))
  :effect (and (not (robot_at cleaning_station)) (not (robot_at meditation_room)) (not (robot_at worship_area)) (not (robot_at main_entrance)) (robot_at prayer_hall)))
 (:action navigate_to_meditation_room
  :parameters ()
  :precondition (and (not (robot_at meditation_room)))
  :effect (and (not (robot_at cleaning_station)) (not (robot_at prayer_hall)) (not (robot_at worship_area)) (not (robot_at main_entrance)) (robot_at meditation_room)))
 (:action navigate_to_worship_area
  :parameters ()
  :precondition (and (not (robot_at worship_area)))
  :effect (and (not (robot_at cleaning_station)) (not (robot_at prayer_hall)) (not (robot_at meditation_room)) (not (robot_at main_entrance)) (robot_at worship_area)))
 (:action navigate_to_main_entrance
  :parameters ()
  :precondition (and (not (robot_at main_entrance)))
  :effect (and (not (robot_at cleaning_station)) (not (robot_at prayer_hall)) (not (robot_at meditation_room)) (not (robot_at worship_area)) (robot_at main_entrance)))
 (:action navigate_to_cleaning_station
  :parameters ()
  :precondition (and (not (robot_at cleaning_station)))
  :effect (and (not (robot_at prayer_hall)) (not (robot_at meditation_room)) (not (robot_at worship_area)) (not (robot_at main_entrance)) (robot_at cleaning_station)))
 (:action equip_mop
  :parameters ()
  :precondition (and (robot_at cleaning_station) (not (robot_has_mop)))
  :effect (and (robot_has_mop)))
 (:action fill_water
  :parameters ()
  :precondition (and (robot_at cleaning_station) (robot_has_mop) (not (robot_has_water)))
  :effect (and (robot_has_water)))
 (:action clean_section
  :parameters ( ?section - section)
  :precondition (and (robot_has_mop) (robot_has_water) (not (mop_dirty)) (not (section_cleaned ?section)))
  :effect (and (section_cleaned ?section) (floor_clean ?section) (mop_dirty)))
 (:action rinse_mop
  :parameters ()
  :precondition (and (mop_dirty))
  :effect (and (not (mop_dirty))))
 (:action enable_speed_control
  :parameters ()
  :precondition (and (not (speed_control_enabled)))
  :effect (and (speed_control_enabled)))
)
