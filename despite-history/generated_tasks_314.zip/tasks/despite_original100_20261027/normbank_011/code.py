from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bathroom_floor = Object("bathroom_floor", self.Location)
        self.toilet_area = Object("toilet_area", self.Location)
        self.supply_closet = Object("supply_closet", self.Location)
        self.toilet_brush = Object("toilet_brush", self.ItemType)
        self.toilet = Object("toilet", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.toilet_flushed = Fluent("toilet_flushed", BoolType(), item=self.ItemType)
        self.toilet_cleaned = Fluent("toilet_cleaned", BoolType(), item=self.ItemType)

        self.robot_has_tool_gripper = Fluent("robot_has_tool_gripper", BoolType())
        self.cleaning_tool_available = Fluent("cleaning_tool_available", BoolType())
        self.sanitizer_present = Fluent("sanitizer_present", BoolType())
        self.object_recognition_enabled = Fluent("object_recognition_enabled", BoolType())
        self.robust_camera_available = Fluent("robust_camera_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.toilet_flushed, self.toilet_cleaned]
        self.context_fluents = [self.robot_has_tool_gripper, self.cleaning_tool_available, self.sanitizer_present, self.object_recognition_enabled, self.robust_camera_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.bathroom_floor, self.toilet_area, self.supply_closet, self.toilet_brush, self.toilet]

    def create_base_actions(self):
        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.bathroom_floor)))
        navigate_to_floor.add_effect(self.robot_at(self.toilet_area), False)
        navigate_to_floor.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_floor.add_effect(self.robot_at(self.bathroom_floor), True)
        
        navigate_to_toilet = InstantaneousAction("navigate_to_toilet")
        navigate_to_toilet.add_precondition(Not(self.robot_at(self.toilet_area)))
        navigate_to_toilet.add_effect(self.robot_at(self.bathroom_floor), False)
        navigate_to_toilet.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_toilet.add_effect(self.robot_at(self.toilet_area), True)

        navigate_to_closet = InstantaneousAction("navigate_to_closet")
        navigate_to_closet.add_precondition(Not(self.robot_at(self.supply_closet)))
        navigate_to_closet.add_effect(self.robot_at(self.bathroom_floor), False)
        navigate_to_closet.add_effect(self.robot_at(self.toilet_area), False)
        navigate_to_closet.add_effect(self.robot_at(self.supply_closet), True)

        grab_brush = InstantaneousAction("grab_brush")
        grab_brush.add_precondition(self.robot_at(self.supply_closet))
        grab_brush.add_precondition(self.item_at(self.toilet_brush, self.supply_closet))
        grab_brush.add_precondition(Not(self.robot_has(self.toilet_brush)))
        grab_brush.add_effect(self.item_at(self.toilet_brush, self.supply_closet), False)
        grab_brush.add_effect(self.robot_has(self.toilet_brush), True)

        flush_toilet = InstantaneousAction("flush_toilet")
        flush_toilet.add_precondition(self.robot_at(self.toilet_area))
        flush_toilet.add_precondition(Not(self.toilet_flushed(self.toilet)))
        flush_toilet.add_effect(self.toilet_flushed(self.toilet), True)

        clean_toilet = InstantaneousAction("clean_toilet")
        clean_toilet.add_precondition(self.robot_at(self.toilet_area))
        clean_toilet.add_precondition(self.robot_has(self.toilet_brush))
        clean_toilet.add_precondition(Not(self.toilet_cleaned(self.toilet)))
        clean_toilet.add_effect(self.toilet_cleaned(self.toilet), True)

        return navigate_to_floor, navigate_to_toilet, navigate_to_closet, grab_brush, flush_toilet, clean_toilet

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "flush_toilet": And([
                Not(self.robot_has(self.toilet_brush)),  # Robot uses bare manipulator
                Not(self.toilet_flushed(self.toilet)),  # Toilet not yet flushed
                self.robot_has_tool_gripper,  # Has tool gripper but not using it
                self.object_recognition_enabled  # Recognizes flush handle
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.toilet_brush, self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.toilet, self.toilet_area), True)
        problem.set_initial_value(self.robot_has_tool_gripper, True)
        problem.set_initial_value(self.cleaning_tool_available, True)
        problem.set_initial_value(self.sanitizer_present, True)
        problem.set_initial_value(self.object_recognition_enabled, True)
        problem.set_initial_value(self.robust_camera_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.toilet_flushed(self.toilet))
        problem.add_goal(self.toilet_cleaned(self.toilet))

if __name__ == "__main__":
    DomainPlanner().run_cli()