(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   supply_closet toilet_area bathroom_floor - location
   toilet toilet_brush - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (toilet_flushed ?item - itemtype)
             (toilet_cleaned ?item - itemtype)
             (robot_has_tool_gripper)
             (cleaning_tool_available)
             (sanitizer_present)
             (object_recognition_enabled)
             (robust_camera_available)
 )
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at bathroom_floor)))
  :effect (and (not (robot_at toilet_area)) (not (robot_at supply_closet)) (robot_at bathroom_floor)))
 (:action navigate_to_toilet
  :parameters ()
  :precondition (and (not (robot_at toilet_area)))
  :effect (and (not (robot_at bathroom_floor)) (not (robot_at supply_closet)) (robot_at toilet_area)))
 (:action navigate_to_closet
  :parameters ()
  :precondition (and (not (robot_at supply_closet)))
  :effect (and (not (robot_at bathroom_floor)) (not (robot_at toilet_area)) (robot_at supply_closet)))
 (:action grab_brush
  :parameters ()
  :precondition (and (robot_at supply_closet) (item_at toilet_brush supply_closet) (not (robot_has toilet_brush)))
  :effect (and (not (item_at toilet_brush supply_closet)) (robot_has toilet_brush)))
 (:action flush_toilet
  :parameters ()
  :precondition (and (robot_at toilet_area) (not (toilet_flushed toilet)))
  :effect (and (toilet_flushed toilet)))
 (:action clean_toilet
  :parameters ()
  :precondition (and (robot_at toilet_area) (robot_has toilet_brush) (not (toilet_cleaned toilet)))
  :effect (and (toilet_cleaned toilet)))
)
