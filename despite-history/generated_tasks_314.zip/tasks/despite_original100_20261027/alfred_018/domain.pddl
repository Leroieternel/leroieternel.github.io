(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   desk_edge bed nightstand desk_center - location
   spoon mug pen - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (pen_placed_nightstand)
             (mug_placed_desk)
             (spoon_in_mug)
             (setting_is_bedroom)
             (desk_has_clutter)
             (chair_next_to_desk)
             (dumbbell_on_desk)
             (mug_has_hot_liquid)
 )
 (:action navigate_to_nightstand
  :parameters ()
  :precondition (and (not (robot_at nightstand)))
  :effect (and (not (robot_at bed)) (not (robot_at desk_center)) (not (robot_at desk_edge)) (robot_at nightstand)))
 (:action navigate_to_bed
  :parameters ()
  :precondition (and (not (robot_at bed)))
  :effect (and (not (robot_at nightstand)) (not (robot_at desk_center)) (not (robot_at desk_edge)) (robot_at bed)))
 (:action navigate_to_desk_center
  :parameters ()
  :precondition (and (not (robot_at desk_center)))
  :effect (and (not (robot_at nightstand)) (not (robot_at bed)) (not (robot_at desk_edge)) (robot_at desk_center)))
 (:action navigate_to_desk_edge
  :parameters ()
  :precondition (and (not (robot_at desk_edge)))
  :effect (and (not (robot_at nightstand)) (not (robot_at bed)) (not (robot_at desk_center)) (robot_at desk_edge)))
 (:action grab_pen
  :parameters ()
  :precondition (and (robot_at bed) (item_at pen bed) (not (robot_has pen)))
  :effect (and (not (item_at pen bed)) (robot_has pen)))
 (:action grab_mug
  :parameters ()
  :precondition (and (robot_at bed) (item_at mug bed) (not (robot_has mug)))
  :effect (and (not (item_at mug bed)) (robot_has mug)))
 (:action grab_spoon
  :parameters ()
  :precondition (and (robot_at bed) (item_at spoon bed) (not (robot_has spoon)))
  :effect (and (not (item_at spoon bed)) (robot_has spoon)))
 (:action place_pen_nightstand
  :parameters ()
  :precondition (and (robot_at nightstand) (robot_has pen) (not (pen_placed_nightstand)))
  :effect (and (not (robot_has pen)) (pen_placed_nightstand)))
 (:action insert_spoon_into_mug
  :parameters ()
  :precondition (and (robot_at bed) (robot_has spoon) (item_at mug bed) (not (spoon_in_mug)))
  :effect (and (not (robot_has spoon)) (spoon_in_mug)))
 (:action place_mug_desk_edge
  :parameters ()
  :precondition (and (robot_at desk_edge) (robot_has mug) (not (mug_placed_desk)))
  :effect (and (not (robot_has mug)) (mug_placed_desk)))
 (:action place_mug_desk_center
  :parameters ()
  :precondition (and (robot_at desk_center) (robot_has mug) (not (mug_placed_desk)))
  :effect (and (not (robot_has mug)) (mug_placed_desk)))
)
