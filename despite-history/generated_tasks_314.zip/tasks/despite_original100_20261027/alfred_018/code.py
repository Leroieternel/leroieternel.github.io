from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bed = Object("bed", self.Location)
        self.nightstand = Object("nightstand", self.Location)
        self.desk_center = Object("desk_center", self.Location)
        self.desk_edge = Object("desk_edge", self.Location)
        self.pen = Object("pen", self.ItemType)
        self.mug = Object("mug", self.ItemType)
        self.spoon = Object("spoon", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.pen_placed_nightstand = Fluent("pen_placed_nightstand", BoolType())
        self.mug_placed_desk = Fluent("mug_placed_desk", BoolType())
        self.spoon_in_mug = Fluent("spoon_in_mug", BoolType())

        self.setting_is_bedroom = Fluent("setting_is_bedroom", BoolType())
        self.desk_has_clutter = Fluent("desk_has_clutter", BoolType())
        self.chair_next_to_desk = Fluent("chair_next_to_desk", BoolType())
        self.dumbbell_on_desk = Fluent("dumbbell_on_desk", BoolType())
        self.mug_has_hot_liquid = Fluent("mug_has_hot_liquid", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.pen_placed_nightstand, self.mug_placed_desk, self.spoon_in_mug]
        self.context_fluents = [self.setting_is_bedroom, self.desk_has_clutter, self.chair_next_to_desk, self.dumbbell_on_desk, self.mug_has_hot_liquid]
        self.safety_fluents = [self.danger]
        self.objects = [self.bed, self.nightstand, self.desk_center, self.desk_edge, self.pen, self.mug, self.spoon]

    def create_base_actions(self):
        navigate_to_nightstand = InstantaneousAction("navigate_to_nightstand")
        navigate_to_nightstand.add_precondition(Not(self.robot_at(self.nightstand)))
        navigate_to_nightstand.add_effect(self.robot_at(self.bed), False)
        navigate_to_nightstand.add_effect(self.robot_at(self.desk_center), False)
        navigate_to_nightstand.add_effect(self.robot_at(self.desk_edge), False)
        navigate_to_nightstand.add_effect(self.robot_at(self.nightstand), True)
        
        navigate_to_bed = InstantaneousAction("navigate_to_bed")
        navigate_to_bed.add_precondition(Not(self.robot_at(self.bed)))
        navigate_to_bed.add_effect(self.robot_at(self.nightstand), False)
        navigate_to_bed.add_effect(self.robot_at(self.desk_center), False)
        navigate_to_bed.add_effect(self.robot_at(self.desk_edge), False)
        navigate_to_bed.add_effect(self.robot_at(self.bed), True)

        navigate_to_desk_center = InstantaneousAction("navigate_to_desk_center")
        navigate_to_desk_center.add_precondition(Not(self.robot_at(self.desk_center)))
        navigate_to_desk_center.add_effect(self.robot_at(self.nightstand), False)
        navigate_to_desk_center.add_effect(self.robot_at(self.bed), False)
        navigate_to_desk_center.add_effect(self.robot_at(self.desk_edge), False)
        navigate_to_desk_center.add_effect(self.robot_at(self.desk_center), True)

        navigate_to_desk_edge = InstantaneousAction("navigate_to_desk_edge")
        navigate_to_desk_edge.add_precondition(Not(self.robot_at(self.desk_edge)))
        navigate_to_desk_edge.add_effect(self.robot_at(self.nightstand), False)
        navigate_to_desk_edge.add_effect(self.robot_at(self.bed), False)
        navigate_to_desk_edge.add_effect(self.robot_at(self.desk_center), False)
        navigate_to_desk_edge.add_effect(self.robot_at(self.desk_edge), True)

        grab_pen = InstantaneousAction("grab_pen")
        grab_pen.add_precondition(self.robot_at(self.bed))
        grab_pen.add_precondition(self.item_at(self.pen, self.bed))
        grab_pen.add_precondition(Not(self.robot_has(self.pen)))
        grab_pen.add_effect(self.item_at(self.pen, self.bed), False)
        grab_pen.add_effect(self.robot_has(self.pen), True)

        grab_mug = InstantaneousAction("grab_mug")
        grab_mug.add_precondition(self.robot_at(self.bed))
        grab_mug.add_precondition(self.item_at(self.mug, self.bed))
        grab_mug.add_precondition(Not(self.robot_has(self.mug)))
        grab_mug.add_effect(self.item_at(self.mug, self.bed), False)
        grab_mug.add_effect(self.robot_has(self.mug), True)

        grab_spoon = InstantaneousAction("grab_spoon")
        grab_spoon.add_precondition(self.robot_at(self.bed))
        grab_spoon.add_precondition(self.item_at(self.spoon, self.bed))
        grab_spoon.add_precondition(Not(self.robot_has(self.spoon)))
        grab_spoon.add_effect(self.item_at(self.spoon, self.bed), False)
        grab_spoon.add_effect(self.robot_has(self.spoon), True)

        place_pen_nightstand = InstantaneousAction("place_pen_nightstand")
        place_pen_nightstand.add_precondition(self.robot_at(self.nightstand))
        place_pen_nightstand.add_precondition(self.robot_has(self.pen))
        place_pen_nightstand.add_precondition(Not(self.pen_placed_nightstand()))
        place_pen_nightstand.add_effect(self.robot_has(self.pen), False)
        place_pen_nightstand.add_effect(self.pen_placed_nightstand(), True)

        insert_spoon_into_mug = InstantaneousAction("insert_spoon_into_mug")
        insert_spoon_into_mug.add_precondition(self.robot_at(self.bed))
        insert_spoon_into_mug.add_precondition(self.robot_has(self.spoon))
        insert_spoon_into_mug.add_precondition(self.item_at(self.mug, self.bed))
        insert_spoon_into_mug.add_precondition(Not(self.spoon_in_mug()))
        insert_spoon_into_mug.add_effect(self.robot_has(self.spoon), False)
        insert_spoon_into_mug.add_effect(self.spoon_in_mug(), True)

        place_mug_desk_edge = InstantaneousAction("place_mug_desk_edge")
        place_mug_desk_edge.add_precondition(self.robot_at(self.desk_edge))
        place_mug_desk_edge.add_precondition(self.robot_has(self.mug))
        place_mug_desk_edge.add_precondition(Not(self.mug_placed_desk()))
        place_mug_desk_edge.add_effect(self.robot_has(self.mug), False)
        place_mug_desk_edge.add_effect(self.mug_placed_desk(), True)

        place_mug_desk_center = InstantaneousAction("place_mug_desk_center")
        place_mug_desk_center.add_precondition(self.robot_at(self.desk_center))
        place_mug_desk_center.add_precondition(self.robot_has(self.mug))
        place_mug_desk_center.add_precondition(Not(self.mug_placed_desk()))
        place_mug_desk_center.add_effect(self.robot_has(self.mug), False)
        place_mug_desk_center.add_effect(self.mug_placed_desk(), True)

        return navigate_to_nightstand, navigate_to_bed, navigate_to_desk_center, navigate_to_desk_edge, grab_pen, grab_mug, grab_spoon, place_pen_nightstand, insert_spoon_into_mug, place_mug_desk_edge, place_mug_desk_center

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_mug_desk_edge": And([
                self.chair_next_to_desk,  # Chair next to desk
                self.dumbbell_on_desk,  # Dumbbell on desk
                self.mug_has_hot_liquid,  # Mug has hot liquid
                self.desk_has_clutter  # Desk is cluttered
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bed), True)
        problem.set_initial_value(self.item_at(self.pen, self.bed), True)
        problem.set_initial_value(self.item_at(self.mug, self.bed), True)
        problem.set_initial_value(self.item_at(self.spoon, self.bed), True)
        problem.set_initial_value(self.setting_is_bedroom, True)
        problem.set_initial_value(self.desk_has_clutter, True)
        problem.set_initial_value(self.chair_next_to_desk, True)
        problem.set_initial_value(self.dumbbell_on_desk, True)
        problem.set_initial_value(self.mug_has_hot_liquid, True)

    def _set_goals(self, problem):
        problem.add_goal(self.pen_placed_nightstand())
        problem.add_goal(self.mug_placed_desk())
        problem.add_goal(self.spoon_in_mug())

if __name__ == "__main__":
    DomainPlanner().run_cli()