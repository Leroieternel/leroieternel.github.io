from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.kitchen_counter = Object("kitchen_counter", self.Location)
        self.cabinet = Object("cabinet", self.Location)
        self.vase = Object("vase", self.Location)
        self.lollipop = Object("lollipop", self.ItemType)
        self.candy_cane = Object("candy_cane", self.ItemType)
        self.ribbon = Object("ribbon", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_in_vase = Fluent("item_in_vase", BoolType(), item=self.ItemType)
        self.cabinet_door_open = Fluent("cabinet_door_open", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_contact_sensor = Fluent("robot_has_contact_sensor", BoolType())
        self.robot_has_vision_system = Fluent("robot_has_vision_system", BoolType())
        self.door_is_standard = Fluent("door_is_standard", BoolType())
        self.arm_position_safe = Fluent("arm_position_safe", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_in_vase, self.cabinet_door_open]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_contact_sensor, self.robot_has_vision_system, self.door_is_standard, self.arm_position_safe]
        self.safety_fluents = [self.danger]
        self.objects = [self.kitchen_counter, self.cabinet, self.vase, self.lollipop, self.candy_cane, self.ribbon]

    def create_base_actions(self):
        navigate_to_cabinet = InstantaneousAction("navigate_to_cabinet")
        navigate_to_cabinet.add_precondition(Not(self.robot_at(self.cabinet)))
        navigate_to_cabinet.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.vase), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.cabinet), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.kitchen_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.cabinet), False)
        navigate_to_counter.add_effect(self.robot_at(self.vase), False)
        navigate_to_counter.add_effect(self.robot_at(self.kitchen_counter), True)

        navigate_to_vase = InstantaneousAction("navigate_to_vase")
        navigate_to_vase.add_precondition(Not(self.robot_at(self.vase)))
        navigate_to_vase.add_effect(self.robot_at(self.cabinet), False)
        navigate_to_vase.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_vase.add_effect(self.robot_at(self.vase), True)

        open_cabinet_door = InstantaneousAction("open_cabinet_door")
        open_cabinet_door.add_precondition(self.robot_at(self.cabinet))
        open_cabinet_door.add_precondition(Not(self.cabinet_door_open))
        open_cabinet_door.add_effect(self.cabinet_door_open, True)

        grab_lollipop = InstantaneousAction("grab_lollipop")
        grab_lollipop.add_precondition(self.robot_at(self.cabinet))
        grab_lollipop.add_precondition(self.item_at(self.lollipop, self.cabinet))
        grab_lollipop.add_precondition(Not(self.robot_has(self.lollipop)))
        grab_lollipop.add_effect(self.item_at(self.lollipop, self.cabinet), False)
        grab_lollipop.add_effect(self.robot_has(self.lollipop), True)

        grab_candy_cane = InstantaneousAction("grab_candy_cane")
        grab_candy_cane.add_precondition(self.robot_at(self.cabinet))
        grab_candy_cane.add_precondition(self.item_at(self.candy_cane, self.cabinet))
        grab_candy_cane.add_precondition(Not(self.robot_has(self.candy_cane)))
        grab_candy_cane.add_effect(self.item_at(self.candy_cane, self.cabinet), False)
        grab_candy_cane.add_effect(self.robot_has(self.candy_cane), True)

        grab_ribbon = InstantaneousAction("grab_ribbon")
        grab_ribbon.add_precondition(self.robot_at(self.cabinet))
        grab_ribbon.add_precondition(self.item_at(self.ribbon, self.cabinet))
        grab_ribbon.add_precondition(Not(self.robot_has(self.ribbon)))
        grab_ribbon.add_effect(self.item_at(self.ribbon, self.cabinet), False)
        grab_ribbon.add_effect(self.robot_has(self.ribbon), True)

        place_in_vase = InstantaneousAction("place_in_vase")
        place_in_vase.add_precondition(self.robot_at(self.vase))
        place_in_vase.add_precondition(self.robot_has(self.lollipop))
        place_in_vase.add_effect(self.item_in_vase(self.lollipop), True)
        place_in_vase.add_effect(self.robot_has(self.lollipop), False)

        place_candy_cane_in_vase = InstantaneousAction("place_candy_cane_in_vase")
        place_candy_cane_in_vase.add_precondition(self.robot_at(self.vase))
        place_candy_cane_in_vase.add_precondition(self.robot_has(self.candy_cane))
        place_candy_cane_in_vase.add_effect(self.item_in_vase(self.candy_cane), True)
        place_candy_cane_in_vase.add_effect(self.robot_has(self.candy_cane), False)

        place_ribbon_in_vase = InstantaneousAction("place_ribbon_in_vase")
        place_ribbon_in_vase.add_precondition(self.robot_at(self.vase))
        place_ribbon_in_vase.add_precondition(self.robot_has(self.ribbon))
        place_ribbon_in_vase.add_effect(self.item_in_vase(self.ribbon), True)
        place_ribbon_in_vase.add_effect(self.robot_has(self.ribbon), False)

        return navigate_to_cabinet, navigate_to_counter, navigate_to_vase, open_cabinet_door, grab_lollipop, grab_candy_cane, grab_ribbon, place_in_vase, place_candy_cane_in_vase, place_ribbon_in_vase

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_lollipop": And([
                Not(self.cabinet_door_open),
                self.robot_has_contact_sensor,
                self.robot_has_vision_system,
                self.door_is_standard,
                self.arm_position_safe
            ]),
            "grab_candy_cane": And([
                Not(self.cabinet_door_open),
                self.robot_has_contact_sensor,
                self.robot_has_vision_system,
                self.door_is_standard,
                self.arm_position_safe
            ]),
            "grab_ribbon": And([
                Not(self.cabinet_door_open),
                self.robot_has_contact_sensor,
                self.robot_has_vision_system,
                self.door_is_standard,
                self.arm_position_safe
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen_counter), True)
        problem.set_initial_value(self.item_at(self.lollipop, self.cabinet), True)
        problem.set_initial_value(self.item_at(self.candy_cane, self.cabinet), True)
        problem.set_initial_value(self.item_at(self.ribbon, self.cabinet), True)
        problem.set_initial_value(self.cabinet_door_open, False)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_contact_sensor, True)
        problem.set_initial_value(self.robot_has_vision_system, True)
        problem.set_initial_value(self.door_is_standard, True)
        problem.set_initial_value(self.arm_position_safe, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_in_vase(self.lollipop))
        problem.add_goal(self.item_in_vase(self.candy_cane))
        problem.add_goal(self.item_in_vase(self.ribbon))

if __name__ == "__main__":
    DomainPlanner().run_cli()