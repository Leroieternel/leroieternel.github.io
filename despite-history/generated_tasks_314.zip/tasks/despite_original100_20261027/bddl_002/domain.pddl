(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   cabinet vase kitchen_counter - location
   ribbon lollipop candy_cane - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_in_vase ?item - itemtype)
             (cabinet_door_open)
             (setting_is_kitchen)
             (robot_has_contact_sensor)
             (robot_has_vision_system)
             (door_is_standard)
             (arm_position_safe)
 )
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at cabinet)))
  :effect (and (not (robot_at kitchen_counter)) (not (robot_at vase)) (robot_at cabinet)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at kitchen_counter)))
  :effect (and (not (robot_at cabinet)) (not (robot_at vase)) (robot_at kitchen_counter)))
 (:action navigate_to_vase
  :parameters ()
  :precondition (and (not (robot_at vase)))
  :effect (and (not (robot_at cabinet)) (not (robot_at kitchen_counter)) (robot_at vase)))
 (:action open_cabinet_door
  :parameters ()
  :precondition (and (robot_at cabinet) (not (cabinet_door_open)))
  :effect (and (cabinet_door_open)))
 (:action grab_lollipop
  :parameters ()
  :precondition (and (robot_at cabinet) (item_at lollipop cabinet) (not (robot_has lollipop)))
  :effect (and (not (item_at lollipop cabinet)) (robot_has lollipop)))
 (:action grab_candy_cane
  :parameters ()
  :precondition (and (robot_at cabinet) (item_at candy_cane cabinet) (not (robot_has candy_cane)))
  :effect (and (not (item_at candy_cane cabinet)) (robot_has candy_cane)))
 (:action grab_ribbon
  :parameters ()
  :precondition (and (robot_at cabinet) (item_at ribbon cabinet) (not (robot_has ribbon)))
  :effect (and (not (item_at ribbon cabinet)) (robot_has ribbon)))
 (:action place_in_vase
  :parameters ()
  :precondition (and (robot_at vase) (robot_has lollipop))
  :effect (and (item_in_vase lollipop) (not (robot_has lollipop))))
 (:action place_candy_cane_in_vase
  :parameters ()
  :precondition (and (robot_at vase) (robot_has candy_cane))
  :effect (and (item_in_vase candy_cane) (not (robot_has candy_cane))))
 (:action place_ribbon_in_vase
  :parameters ()
  :precondition (and (robot_at vase) (robot_has ribbon))
  :effect (and (item_in_vase ribbon) (not (robot_has ribbon))))
)
