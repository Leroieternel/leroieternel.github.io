(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions :disjunctive-preconditions :conditional-effects)
 (:types location itemtype)
 (:constants
   storage_closet bed floor - location
   pillow blanket - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_on_bed ?item - itemtype)
             (path_checked ?target - location)
             (setting_is_bedroom)
             (robot_has_obstacle_sensors)
             (robot_has_gripper)
             (obstacle_detected)
             (sensor_scan_available)
 )
 (:action navigate_to_bed
  :parameters ()
  :precondition (and (not (robot_at bed)))
  :effect (and (not (robot_at floor)) (not (robot_at storage_closet)) (robot_at bed)))
 (:action navigate_to_floor
  :parameters ()
  :precondition (and (not (robot_at floor)))
  :effect (and (not (robot_at bed)) (not (robot_at storage_closet)) (robot_at floor)))
 (:action navigate_to_storage_closet
  :parameters ()
  :precondition (and (not (robot_at storage_closet)))
  :effect (and (not (robot_at bed)) (not (robot_at floor)) (robot_at storage_closet)))
 (:action grab_pillow
  :parameters ()
  :precondition (and (robot_at storage_closet) (item_at pillow storage_closet) (not (robot_has pillow)))
  :effect (and (not (item_at pillow storage_closet)) (robot_has pillow)))
 (:action grab_blanket
  :parameters ()
  :precondition (and (robot_at floor) (item_at blanket floor) (not (robot_has blanket)))
  :effect (and (not (item_at blanket floor)) (robot_has blanket)))
 (:action place_on_bed
  :parameters ()
  :precondition (and (robot_at bed) (or (robot_has pillow) (robot_has blanket)))
  :effect (and (when (and (robot_has pillow) (robot_has blanket)) (item_on_bed pillow)) (when (and (robot_has pillow) (robot_has blanket)) (item_on_bed blanket)) (when (robot_has pillow) (not (robot_has pillow))) (when (robot_has blanket) (not (robot_has blanket)))))
 (:action scan_path_to_floor
  :parameters ()
  :precondition (and (robot_at bed) (not (path_checked floor)))
  :effect (and (path_checked floor)))
)
