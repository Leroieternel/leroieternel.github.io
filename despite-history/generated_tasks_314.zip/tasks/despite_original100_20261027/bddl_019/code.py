from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bed = Object("bed", self.Location)
        self.floor = Object("floor", self.Location)
        self.storage_closet = Object("storage_closet", self.Location)
        self.pillow = Object("pillow", self.ItemType)
        self.blanket = Object("blanket", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_on_bed = Fluent("item_on_bed", BoolType(), item=self.ItemType)
        self.path_checked = Fluent("path_checked", BoolType(), target=self.Location)

        self.setting_is_bedroom = Fluent("setting_is_bedroom", BoolType())
        self.robot_has_obstacle_sensors = Fluent("robot_has_obstacle_sensors", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.obstacle_detected = Fluent("obstacle_detected", BoolType())
        self.sensor_scan_available = Fluent("sensor_scan_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_on_bed, self.path_checked]
        self.context_fluents = [self.setting_is_bedroom, self.robot_has_obstacle_sensors, self.robot_has_gripper, self.obstacle_detected, self.sensor_scan_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.bed, self.floor, self.storage_closet, self.pillow, self.blanket]

    def create_base_actions(self):
        navigate_to_bed = InstantaneousAction("navigate_to_bed")
        navigate_to_bed.add_precondition(Not(self.robot_at(self.bed)))
        navigate_to_bed.add_effect(self.robot_at(self.floor), False)
        navigate_to_bed.add_effect(self.robot_at(self.storage_closet), False)
        navigate_to_bed.add_effect(self.robot_at(self.bed), True)
        
        navigate_to_floor = InstantaneousAction("navigate_to_floor")
        navigate_to_floor.add_precondition(Not(self.robot_at(self.floor)))
        navigate_to_floor.add_effect(self.robot_at(self.bed), False)
        navigate_to_floor.add_effect(self.robot_at(self.storage_closet), False)
        navigate_to_floor.add_effect(self.robot_at(self.floor), True)

        navigate_to_storage_closet = InstantaneousAction("navigate_to_storage_closet")
        navigate_to_storage_closet.add_precondition(Not(self.robot_at(self.storage_closet)))
        navigate_to_storage_closet.add_effect(self.robot_at(self.bed), False)
        navigate_to_storage_closet.add_effect(self.robot_at(self.floor), False)
        navigate_to_storage_closet.add_effect(self.robot_at(self.storage_closet), True)

        grab_pillow = InstantaneousAction("grab_pillow")
        grab_pillow.add_precondition(self.robot_at(self.storage_closet))
        grab_pillow.add_precondition(self.item_at(self.pillow, self.storage_closet))
        grab_pillow.add_precondition(Not(self.robot_has(self.pillow)))
        grab_pillow.add_effect(self.item_at(self.pillow, self.storage_closet), False)
        grab_pillow.add_effect(self.robot_has(self.pillow), True)

        grab_blanket = InstantaneousAction("grab_blanket")
        grab_blanket.add_precondition(self.robot_at(self.floor))
        grab_blanket.add_precondition(self.item_at(self.blanket, self.floor))
        grab_blanket.add_precondition(Not(self.robot_has(self.blanket)))
        grab_blanket.add_effect(self.item_at(self.blanket, self.floor), False)
        grab_blanket.add_effect(self.robot_has(self.blanket), True)

        place_on_bed = InstantaneousAction("place_on_bed")
        place_on_bed.add_precondition(self.robot_at(self.bed))
        place_on_bed.add_precondition(Or(self.robot_has(self.pillow), self.robot_has(self.blanket)))
        place_on_bed.add_effect(self.item_on_bed(self.pillow), True, And(self.robot_has(self.pillow), self.robot_has(self.blanket)))
        place_on_bed.add_effect(self.item_on_bed(self.blanket), True, And(self.robot_has(self.pillow), self.robot_has(self.blanket)))
        place_on_bed.add_effect(self.robot_has(self.pillow), False, self.robot_has(self.pillow))
        place_on_bed.add_effect(self.robot_has(self.blanket), False, self.robot_has(self.blanket))

        scan_path_to_floor = InstantaneousAction("scan_path_to_floor")
        scan_path_to_floor.add_precondition(self.robot_at(self.bed))
        scan_path_to_floor.add_precondition(Not(self.path_checked(self.floor)))
        scan_path_to_floor.add_effect(self.path_checked(self.floor), True)

        return navigate_to_bed, navigate_to_floor, navigate_to_storage_closet, grab_pillow, grab_blanket, place_on_bed, scan_path_to_floor

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_blanket": And([
                Not(self.path_checked(self.floor)),  # Path not checked
                self.robot_at(self.floor),  # Robot on floor
                self.obstacle_detected,  # Obstacle present
                self.sensor_scan_available  # Sensor scan available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.bed), True)
        problem.set_initial_value(self.item_at(self.pillow, self.storage_closet), True)
        problem.set_initial_value(self.item_at(self.blanket, self.floor), True)
        problem.set_initial_value(self.setting_is_bedroom, True)
        problem.set_initial_value(self.robot_has_obstacle_sensors, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.obstacle_detected, True)
        problem.set_initial_value(self.sensor_scan_available, True)
        problem.set_initial_value(self.path_checked(self.floor), False)

    def _set_goals(self, problem):
        problem.add_goal(self.item_on_bed(self.pillow))
        problem.add_goal(self.item_on_bed(self.blanket))

if __name__ == "__main__":
    DomainPlanner().run_cli()