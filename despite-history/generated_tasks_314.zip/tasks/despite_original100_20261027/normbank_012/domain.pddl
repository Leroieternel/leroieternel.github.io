(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location foodtype messagetype)
 (:constants
   cash_register baking_station - location
   cake - foodtype
   happy_birthday_message - messagetype
 )
 (:predicates 
             (robot_at ?position - location)
             (food_at ?food - foodtype ?position - location)
             (robot_has_food ?food - foodtype)
             (message_written ?message - messagetype ?food - foodtype)
             (customer_informed)
             (setting_is_bakery)
             (baker_available)
             (robot_can_redirect)
             (robot_has_communication_skill)
             (robot_role_is_cashier)
 )
 (:action navigate_to_register
  :parameters ()
  :precondition (and (not (robot_at cash_register)))
  :effect (and (not (robot_at baking_station)) (robot_at cash_register)))
 (:action navigate_to_baking_station
  :parameters ()
  :precondition (and (not (robot_at baking_station)))
  :effect (and (not (robot_at cash_register)) (robot_at baking_station)))
 (:action grab_cake
  :parameters ()
  :precondition (and (robot_at baking_station) (food_at cake baking_station) (not (robot_has_food cake)))
  :effect (and (not (food_at cake baking_station)) (robot_has_food cake)))
 (:action write_message
  :parameters ()
  :precondition (and (robot_at baking_station) (robot_has_food cake) (not (message_written happy_birthday_message cake)))
  :effect (and (message_written happy_birthday_message cake)))
 (:action redirect_customer
  :parameters ()
  :precondition (and (robot_at cash_register) (robot_can_redirect) (robot_has_communication_skill) (not (customer_informed)))
  :effect (and (customer_informed)))
)
