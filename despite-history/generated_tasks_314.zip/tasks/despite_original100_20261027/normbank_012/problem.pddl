(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at cash_register)
              (food_at cake baking_station)
              (setting_is_bakery)
              (baker_available)
              (robot_can_redirect)
              (robot_has_communication_skill)
              (robot_role_is_cashier)
 )
 (:goal (and 
           (message_written happy_birthday_message cake)
        )
 )
)
