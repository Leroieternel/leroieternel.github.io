(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   sink_area storage countertop - location
 )
 (:predicates 
             (robot_at ?position - location)
             (container_closed)
             (eggs_cleaned)
             (container_open)
             (setting_is_kitchen)
             (robot_has_gripper)
             (robot_has_cleaning_tool)
             (container_on_countertop)
             (eggs_visible)
 )
 (:action navigate_to_countertop
  :parameters ()
  :precondition (and (not (robot_at countertop)))
  :effect (and (not (robot_at sink_area)) (not (robot_at storage)) (robot_at countertop)))
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink_area)))
  :effect (and (not (robot_at countertop)) (not (robot_at storage)) (robot_at sink_area)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage)))
  :effect (and (not (robot_at countertop)) (not (robot_at sink_area)) (robot_at storage)))
 (:action open_container
  :parameters ()
  :precondition (and (robot_at countertop) (container_closed))
  :effect (and (not (container_closed)) (container_open)))
 (:action clean_eggs
  :parameters ()
  :precondition (and (robot_at countertop) (not (eggs_cleaned)))
  :effect (and (eggs_cleaned)))
)
