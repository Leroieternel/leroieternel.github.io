(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at countertop)
              (container_closed)
              (setting_is_kitchen)
              (robot_has_gripper)
              (robot_has_cleaning_tool)
              (container_on_countertop)
 )
 (:goal (and 
           (eggs_cleaned)
        )
 )
)
