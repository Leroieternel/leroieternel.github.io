from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.countertop = Object("countertop", self.Location)
        self.sink_area = Object("sink_area", self.Location)
        self.storage = Object("storage", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.container_closed = Fluent("container_closed", BoolType())
        self.eggs_cleaned = Fluent("eggs_cleaned", BoolType())
        self.container_open = Fluent("container_open", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.robot_has_cleaning_tool = Fluent("robot_has_cleaning_tool", BoolType())
        self.container_on_countertop = Fluent("container_on_countertop", BoolType())
        self.eggs_visible = Fluent("eggs_visible", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.container_closed, self.eggs_cleaned, self.container_open]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_gripper, self.robot_has_cleaning_tool, self.container_on_countertop, self.eggs_visible]
        self.safety_fluents = [self.danger]
        self.objects = [self.countertop, self.sink_area, self.storage]

    def create_base_actions(self):
        navigate_to_countertop = InstantaneousAction("navigate_to_countertop")
        navigate_to_countertop.add_precondition(Not(self.robot_at(self.countertop)))
        navigate_to_countertop.add_effect(self.robot_at(self.sink_area), False)
        navigate_to_countertop.add_effect(self.robot_at(self.storage), False)
        navigate_to_countertop.add_effect(self.robot_at(self.countertop), True)
        
        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink_area)))
        navigate_to_sink.add_effect(self.robot_at(self.countertop), False)
        navigate_to_sink.add_effect(self.robot_at(self.storage), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink_area), True)

        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage)))
        navigate_to_storage.add_effect(self.robot_at(self.countertop), False)
        navigate_to_storage.add_effect(self.robot_at(self.sink_area), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage), True)

        open_container = InstantaneousAction("open_container")
        open_container.add_precondition(self.robot_at(self.countertop))
        open_container.add_precondition(self.container_closed)
        open_container.add_effect(self.container_closed, False)
        open_container.add_effect(self.container_open, True)

        clean_eggs = InstantaneousAction("clean_eggs")
        clean_eggs.add_precondition(self.robot_at(self.countertop))
        clean_eggs.add_precondition(Not(self.eggs_cleaned))
        clean_eggs.add_effect(self.eggs_cleaned, True)

        return navigate_to_countertop, navigate_to_sink, navigate_to_storage, open_container, clean_eggs

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_eggs": And([
                self.container_closed,  # Container is closed
                Not(self.eggs_cleaned),  # Eggs not yet cleaned
                self.robot_has_gripper,  # Robot has gripper
                self.robot_has_cleaning_tool,  # Robot has cleaning tool
                self.container_on_countertop  # Container is on countertop
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.countertop), True)
        problem.set_initial_value(self.container_closed, True)
        problem.set_initial_value(self.container_open, False)
        problem.set_initial_value(self.eggs_cleaned, False)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.robot_has_cleaning_tool, True)
        problem.set_initial_value(self.container_on_countertop, True)
        problem.set_initial_value(self.eggs_visible, False)

    def _set_goals(self, problem):
        problem.add_goal(self.eggs_cleaned)

if __name__ == "__main__":
    DomainPlanner().run_cli()