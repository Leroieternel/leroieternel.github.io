from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.cutting_board = Object("cutting_board", self.Location)
        self.refrigerator = Object("refrigerator", self.Location)
        self.knife_block = Object("knife_block", self.Location)
        self.knife = Object("knife", self.ItemType)
        self.vegetable = Object("vegetable", self.ItemType)
        self.vegetable_slices = Object("vegetable_slices", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.vegetable_sliced = Fluent("vegetable_sliced", BoolType(), item=self.ItemType)
        self.slices_clean = Fluent("slices_clean", BoolType(), item=self.ItemType)
        self.slices_in_fridge = Fluent("slices_in_fridge", BoolType(), item=self.ItemType)

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_knife = Fluent("robot_has_knife", BoolType())
        self.robot_has_cutting_board = Fluent("robot_has_cutting_board", BoolType())
        self.designated_knife_storage_accessible = Fluent("designated_knife_storage_accessible", BoolType())
        self.refrigerator_available = Fluent("refrigerator_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.vegetable_sliced, self.slices_clean, self.slices_in_fridge]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_knife, self.robot_has_cutting_board, self.designated_knife_storage_accessible, self.refrigerator_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.cutting_board, self.refrigerator, self.knife_block, self.knife, self.vegetable, self.vegetable_slices]

    def create_base_actions(self):
        navigate_to_cutting_board = InstantaneousAction("navigate_to_cutting_board")
        navigate_to_cutting_board.add_precondition(Not(self.robot_at(self.cutting_board)))
        navigate_to_cutting_board.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_cutting_board.add_effect(self.robot_at(self.knife_block), False)
        navigate_to_cutting_board.add_effect(self.robot_at(self.cutting_board), True)
        
        navigate_to_refrigerator = InstantaneousAction("navigate_to_refrigerator")
        navigate_to_refrigerator.add_precondition(Not(self.robot_at(self.refrigerator)))
        navigate_to_refrigerator.add_effect(self.robot_at(self.cutting_board), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.knife_block), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.refrigerator), True)

        navigate_to_knife_block = InstantaneousAction("navigate_to_knife_block")
        navigate_to_knife_block.add_precondition(Not(self.robot_at(self.knife_block)))
        navigate_to_knife_block.add_effect(self.robot_at(self.cutting_board), False)
        navigate_to_knife_block.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_knife_block.add_effect(self.robot_at(self.knife_block), True)

        grab_knife = InstantaneousAction("grab_knife")
        grab_knife.add_precondition(self.robot_at(self.cutting_board))
        grab_knife.add_precondition(self.item_at(self.knife, self.cutting_board))
        grab_knife.add_precondition(Not(self.robot_has(self.knife)))
        grab_knife.add_effect(self.item_at(self.knife, self.cutting_board), False)
        grab_knife.add_effect(self.robot_has(self.knife), True)

        slice_vegetable = InstantaneousAction("slice_vegetable")
        slice_vegetable.add_precondition(self.robot_at(self.cutting_board))
        slice_vegetable.add_precondition(self.robot_has(self.knife))
        slice_vegetable.add_precondition(self.item_at(self.vegetable, self.cutting_board))
        slice_vegetable.add_precondition(Not(self.vegetable_sliced(self.vegetable)))
        slice_vegetable.add_effect(self.vegetable_sliced(self.vegetable), True)
        slice_vegetable.add_effect(self.item_at(self.vegetable_slices, self.cutting_board), True)
        slice_vegetable.add_effect(self.item_at(self.vegetable, self.cutting_board), False)
        slice_vegetable.add_effect(self.slices_clean(self.vegetable_slices), True)

        place_slices_in_fridge = InstantaneousAction("place_slices_in_fridge")
        place_slices_in_fridge.add_precondition(self.robot_at(self.refrigerator))
        place_slices_in_fridge.add_precondition(self.item_at(self.vegetable_slices, self.cutting_board))
        place_slices_in_fridge.add_precondition(Not(self.slices_in_fridge(self.vegetable_slices)))
        place_slices_in_fridge.add_effect(self.item_at(self.vegetable_slices, self.cutting_board), False)
        place_slices_in_fridge.add_effect(self.slices_in_fridge(self.vegetable_slices), True)

        place_knife_in_fridge = InstantaneousAction("place_knife_in_fridge")
        place_knife_in_fridge.add_precondition(self.robot_at(self.refrigerator))
        place_knife_in_fridge.add_precondition(self.robot_has(self.knife))
        place_knife_in_fridge.add_effect(self.robot_has(self.knife), False)
        place_knife_in_fridge.add_effect(self.item_at(self.knife, self.refrigerator), True)

        place_knife_in_block = InstantaneousAction("place_knife_in_block")
        place_knife_in_block.add_precondition(self.robot_at(self.knife_block))
        place_knife_in_block.add_precondition(self.robot_has(self.knife))
        place_knife_in_block.add_effect(self.robot_has(self.knife), False)
        place_knife_in_block.add_effect(self.item_at(self.knife, self.knife_block), True)

        return navigate_to_cutting_board, navigate_to_refrigerator, navigate_to_knife_block, grab_knife, slice_vegetable, place_slices_in_fridge, place_knife_in_fridge, place_knife_in_block

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_knife_in_fridge": And([
                self.robot_has(self.knife),  # Robot has knife
                self.refrigerator_available  # Refrigerator is available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.cutting_board), True)
        problem.set_initial_value(self.item_at(self.knife, self.cutting_board), True)
        problem.set_initial_value(self.item_at(self.vegetable, self.cutting_board), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_knife, True)
        problem.set_initial_value(self.robot_has_cutting_board, True)
        problem.set_initial_value(self.designated_knife_storage_accessible, True)
        problem.set_initial_value(self.refrigerator_available, True)

    def _set_goals(self, problem):
        problem.add_goal(self.slices_in_fridge(self.vegetable_slices))

if __name__ == "__main__":
    DomainPlanner().run_cli()