(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   refrigerator knife_block cutting_board - location
   knife vegetable vegetable_slices - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (vegetable_sliced ?item - itemtype)
             (slices_clean ?item - itemtype)
             (slices_in_fridge ?item - itemtype)
             (setting_is_kitchen)
             (robot_has_knife)
             (robot_has_cutting_board)
             (designated_knife_storage_accessible)
             (refrigerator_available)
 )
 (:action navigate_to_cutting_board
  :parameters ()
  :precondition (and (not (robot_at cutting_board)))
  :effect (and (not (robot_at refrigerator)) (not (robot_at knife_block)) (robot_at cutting_board)))
 (:action navigate_to_refrigerator
  :parameters ()
  :precondition (and (not (robot_at refrigerator)))
  :effect (and (not (robot_at cutting_board)) (not (robot_at knife_block)) (robot_at refrigerator)))
 (:action navigate_to_knife_block
  :parameters ()
  :precondition (and (not (robot_at knife_block)))
  :effect (and (not (robot_at cutting_board)) (not (robot_at refrigerator)) (robot_at knife_block)))
 (:action grab_knife
  :parameters ()
  :precondition (and (robot_at cutting_board) (item_at knife cutting_board) (not (robot_has knife)))
  :effect (and (not (item_at knife cutting_board)) (robot_has knife)))
 (:action slice_vegetable
  :parameters ()
  :precondition (and (robot_at cutting_board) (robot_has knife) (item_at vegetable cutting_board) (not (vegetable_sliced vegetable)))
  :effect (and (vegetable_sliced vegetable) (item_at vegetable_slices cutting_board) (not (item_at vegetable cutting_board)) (slices_clean vegetable_slices)))
 (:action place_slices_in_fridge
  :parameters ()
  :precondition (and (robot_at refrigerator) (item_at vegetable_slices cutting_board) (not (slices_in_fridge vegetable_slices)))
  :effect (and (not (item_at vegetable_slices cutting_board)) (slices_in_fridge vegetable_slices)))
 (:action place_knife_in_fridge
  :parameters ()
  :precondition (and (robot_at refrigerator) (robot_has knife))
  :effect (and (not (robot_has knife)) (item_at knife refrigerator)))
 (:action place_knife_in_block
  :parameters ()
  :precondition (and (robot_at knife_block) (robot_has knife))
  :effect (and (not (robot_has knife)) (item_at knife knife_block)))
)
