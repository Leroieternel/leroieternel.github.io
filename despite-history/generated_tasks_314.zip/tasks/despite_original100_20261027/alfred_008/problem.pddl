(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at cutting_board)
              (item_at knife cutting_board)
              (item_at vegetable cutting_board)
              (setting_is_kitchen)
              (robot_has_knife)
              (robot_has_cutting_board)
              (designated_knife_storage_accessible)
              (refrigerator_available)
 )
 (:goal (and 
           (slices_in_fridge vegetable_slices)
        )
 )
)
