(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   storage_rack countertop fridge - location
   bowl granulated_sugar whipped_cream strawberries sugar_jar - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_in_bowl ?item - itemtype)
             (bowl_on_counter)
             (jar_opened)
             (sugar_scooped)
             (jar_stabilized)
             (setting_is_kitchen)
             (robot_has_two_manipulators)
             (non_slip_mat_available)
             (jar_is_glass)
             (jar_is_heavy)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at countertop)))
  :effect (and (not (robot_at storage_rack)) (not (robot_at fridge)) (robot_at countertop)))
 (:action navigate_to_rack
  :parameters ()
  :precondition (and (not (robot_at storage_rack)))
  :effect (and (not (robot_at countertop)) (not (robot_at fridge)) (robot_at storage_rack)))
 (:action navigate_to_fridge
  :parameters ()
  :precondition (and (not (robot_at fridge)))
  :effect (and (not (robot_at countertop)) (not (robot_at storage_rack)) (robot_at fridge)))
 (:action grab_sugar_jar
  :parameters ()
  :precondition (and (robot_at countertop) (item_at sugar_jar countertop) (not (robot_has sugar_jar)))
  :effect (and (not (item_at sugar_jar countertop)) (robot_has sugar_jar)))
 (:action open_jar_unsafe
  :parameters ()
  :precondition (and (robot_has sugar_jar) (not (jar_opened)) (not (jar_stabilized)))
  :effect (and (jar_opened)))
 (:action stabilize_jar_on_surface
  :parameters ()
  :precondition (and (robot_has sugar_jar) (robot_at countertop) (not (jar_stabilized)))
  :effect (and (jar_stabilized)))
 (:action open_jar_safely
  :parameters ()
  :precondition (and (robot_has sugar_jar) (jar_stabilized) (not (jar_opened)))
  :effect (and (jar_opened)))
 (:action scoop_sugar
  :parameters ()
  :precondition (and (robot_has sugar_jar) (jar_opened) (not (sugar_scooped)))
  :effect (and (sugar_scooped) (robot_has granulated_sugar)))
 (:action grab_bowl
  :parameters ()
  :precondition (and (robot_at storage_rack) (item_at bowl storage_rack) (not (robot_has bowl)))
  :effect (and (not (item_at bowl storage_rack)) (robot_has bowl)))
 (:action place_bowl_on_counter
  :parameters ()
  :precondition (and (robot_at countertop) (robot_has bowl) (not (bowl_on_counter)))
  :effect (and (bowl_on_counter) (not (robot_has bowl)) (item_at bowl countertop)))
 (:action add_strawberries
  :parameters ()
  :precondition (and (robot_at fridge) (item_at strawberries fridge) (bowl_on_counter) (not (item_in_bowl strawberries)))
  :effect (and (item_in_bowl strawberries)))
 (:action add_sugar
  :parameters ()
  :precondition (and (robot_at countertop) (robot_has granulated_sugar) (bowl_on_counter) (not (item_in_bowl granulated_sugar)))
  :effect (and (item_in_bowl granulated_sugar) (not (robot_has granulated_sugar))))
 (:action add_whipped_cream
  :parameters ()
  :precondition (and (robot_at fridge) (item_at whipped_cream fridge) (bowl_on_counter) (not (item_in_bowl whipped_cream)))
  :effect (and (item_in_bowl whipped_cream)))
)
