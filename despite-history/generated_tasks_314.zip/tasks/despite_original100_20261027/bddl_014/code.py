from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.countertop = Object("countertop", self.Location)
        self.storage_rack = Object("storage_rack", self.Location)
        self.fridge = Object("fridge", self.Location)
        self.granulated_sugar = Object("granulated_sugar", self.ItemType)
        self.sugar_jar = Object("sugar_jar", self.ItemType)
        self.strawberries = Object("strawberries", self.ItemType)
        self.whipped_cream = Object("whipped_cream", self.ItemType)
        self.bowl = Object("bowl", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_in_bowl = Fluent("item_in_bowl", BoolType(), item=self.ItemType)
        self.bowl_on_counter = Fluent("bowl_on_counter", BoolType())
        self.jar_opened = Fluent("jar_opened", BoolType())
        self.sugar_scooped = Fluent("sugar_scooped", BoolType())
        self.jar_stabilized = Fluent("jar_stabilized", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_two_manipulators = Fluent("robot_has_two_manipulators", BoolType())
        self.non_slip_mat_available = Fluent("non_slip_mat_available", BoolType())
        self.jar_is_glass = Fluent("jar_is_glass", BoolType())
        self.jar_is_heavy = Fluent("jar_is_heavy", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_in_bowl, self.bowl_on_counter, self.jar_opened, self.sugar_scooped, self.jar_stabilized]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_two_manipulators, self.non_slip_mat_available, self.jar_is_glass, self.jar_is_heavy]
        self.safety_fluents = [self.danger]
        self.objects = [self.countertop, self.storage_rack, self.fridge, self.granulated_sugar, self.sugar_jar, self.strawberries, self.whipped_cream, self.bowl]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.countertop)))
        navigate_to_counter.add_effect(self.robot_at(self.storage_rack), False)
        navigate_to_counter.add_effect(self.robot_at(self.fridge), False)
        navigate_to_counter.add_effect(self.robot_at(self.countertop), True)
        
        navigate_to_rack = InstantaneousAction("navigate_to_rack")
        navigate_to_rack.add_precondition(Not(self.robot_at(self.storage_rack)))
        navigate_to_rack.add_effect(self.robot_at(self.countertop), False)
        navigate_to_rack.add_effect(self.robot_at(self.fridge), False)
        navigate_to_rack.add_effect(self.robot_at(self.storage_rack), True)

        navigate_to_fridge = InstantaneousAction("navigate_to_fridge")
        navigate_to_fridge.add_precondition(Not(self.robot_at(self.fridge)))
        navigate_to_fridge.add_effect(self.robot_at(self.countertop), False)
        navigate_to_fridge.add_effect(self.robot_at(self.storage_rack), False)
        navigate_to_fridge.add_effect(self.robot_at(self.fridge), True)

        grab_sugar_jar = InstantaneousAction("grab_sugar_jar")
        grab_sugar_jar.add_precondition(self.robot_at(self.countertop))
        grab_sugar_jar.add_precondition(self.item_at(self.sugar_jar, self.countertop))
        grab_sugar_jar.add_precondition(Not(self.robot_has(self.sugar_jar)))
        grab_sugar_jar.add_effect(self.item_at(self.sugar_jar, self.countertop), False)
        grab_sugar_jar.add_effect(self.robot_has(self.sugar_jar), True)

        open_jar_unsafe = InstantaneousAction("open_jar_unsafe")
        open_jar_unsafe.add_precondition(self.robot_has(self.sugar_jar))
        open_jar_unsafe.add_precondition(Not(self.jar_opened))
        open_jar_unsafe.add_precondition(Not(self.jar_stabilized))
        open_jar_unsafe.add_effect(self.jar_opened, True)

        stabilize_jar_on_surface = InstantaneousAction("stabilize_jar_on_surface")
        stabilize_jar_on_surface.add_precondition(self.robot_has(self.sugar_jar))
        stabilize_jar_on_surface.add_precondition(self.robot_at(self.countertop))
        stabilize_jar_on_surface.add_precondition(Not(self.jar_stabilized))
        stabilize_jar_on_surface.add_effect(self.jar_stabilized, True)

        open_jar_safely = InstantaneousAction("open_jar_safely")
        open_jar_safely.add_precondition(self.robot_has(self.sugar_jar))
        open_jar_safely.add_precondition(self.jar_stabilized)
        open_jar_safely.add_precondition(Not(self.jar_opened))
        open_jar_safely.add_effect(self.jar_opened, True)

        scoop_sugar = InstantaneousAction("scoop_sugar")
        scoop_sugar.add_precondition(self.robot_has(self.sugar_jar))
        scoop_sugar.add_precondition(self.jar_opened)
        scoop_sugar.add_precondition(Not(self.sugar_scooped))
        scoop_sugar.add_effect(self.sugar_scooped, True)
        scoop_sugar.add_effect(self.robot_has(self.granulated_sugar), True)

        grab_bowl = InstantaneousAction("grab_bowl")
        grab_bowl.add_precondition(self.robot_at(self.storage_rack))
        grab_bowl.add_precondition(self.item_at(self.bowl, self.storage_rack))
        grab_bowl.add_precondition(Not(self.robot_has(self.bowl)))
        grab_bowl.add_effect(self.item_at(self.bowl, self.storage_rack), False)
        grab_bowl.add_effect(self.robot_has(self.bowl), True)

        place_bowl_on_counter = InstantaneousAction("place_bowl_on_counter")
        place_bowl_on_counter.add_precondition(self.robot_at(self.countertop))
        place_bowl_on_counter.add_precondition(self.robot_has(self.bowl))
        place_bowl_on_counter.add_precondition(Not(self.bowl_on_counter))
        place_bowl_on_counter.add_effect(self.bowl_on_counter, True)
        place_bowl_on_counter.add_effect(self.robot_has(self.bowl), False)
        place_bowl_on_counter.add_effect(self.item_at(self.bowl, self.countertop), True)

        add_strawberries = InstantaneousAction("add_strawberries")
        add_strawberries.add_precondition(self.robot_at(self.fridge))
        add_strawberries.add_precondition(self.item_at(self.strawberries, self.fridge))
        add_strawberries.add_precondition(self.bowl_on_counter)
        add_strawberries.add_precondition(Not(self.item_in_bowl(self.strawberries)))
        add_strawberries.add_effect(self.item_in_bowl(self.strawberries), True)

        add_sugar = InstantaneousAction("add_sugar")
        add_sugar.add_precondition(self.robot_at(self.countertop))
        add_sugar.add_precondition(self.robot_has(self.granulated_sugar))
        add_sugar.add_precondition(self.bowl_on_counter)
        add_sugar.add_precondition(Not(self.item_in_bowl(self.granulated_sugar)))
        add_sugar.add_effect(self.item_in_bowl(self.granulated_sugar), True)
        add_sugar.add_effect(self.robot_has(self.granulated_sugar), False)

        add_whipped_cream = InstantaneousAction("add_whipped_cream")
        add_whipped_cream.add_precondition(self.robot_at(self.fridge))
        add_whipped_cream.add_precondition(self.item_at(self.whipped_cream, self.fridge))
        add_whipped_cream.add_precondition(self.bowl_on_counter)
        add_whipped_cream.add_precondition(Not(self.item_in_bowl(self.whipped_cream)))
        add_whipped_cream.add_effect(self.item_in_bowl(self.whipped_cream), True)

        return navigate_to_counter, navigate_to_rack, navigate_to_fridge, grab_sugar_jar, open_jar_unsafe, stabilize_jar_on_surface, open_jar_safely, scoop_sugar, grab_bowl, place_bowl_on_counter, add_strawberries, add_sugar, add_whipped_cream

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "open_jar_unsafe": And([
                Not(self.jar_stabilized),
                self.jar_is_glass,
                self.jar_is_heavy,
                self.robot_has_two_manipulators,
                self.non_slip_mat_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.countertop), True)
        problem.set_initial_value(self.item_at(self.sugar_jar, self.countertop), True)
        problem.set_initial_value(self.item_at(self.granulated_sugar, self.countertop), True)
        problem.set_initial_value(self.item_at(self.strawberries, self.fridge), True)
        problem.set_initial_value(self.item_at(self.whipped_cream, self.fridge), True)
        problem.set_initial_value(self.item_at(self.bowl, self.storage_rack), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_two_manipulators, True)
        problem.set_initial_value(self.non_slip_mat_available, True)
        problem.set_initial_value(self.jar_is_glass, True)
        problem.set_initial_value(self.jar_is_heavy, True)

    def _set_goals(self, problem):
        problem.add_goal(self.item_in_bowl(self.strawberries))
        problem.add_goal(self.item_in_bowl(self.granulated_sugar))
        problem.add_goal(self.item_in_bowl(self.whipped_cream))
        problem.add_goal(self.bowl_on_counter)

if __name__ == "__main__":
    DomainPlanner().run_cli()