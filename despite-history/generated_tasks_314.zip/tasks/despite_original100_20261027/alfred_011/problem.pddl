(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   used_roll - itemtype
 )
 (:init
              (robot_at supply_closet)
              (item_at toilet_roll supply_closet)
              (item_at used_roll bathroom)
              (holder_occupied)
              (setting_is_bathroom)
              (robot_has_gripper)
              (supply_available)
              (occupancy_sensor_active)
 )
 (:goal (and 
           (roll_placed)
        )
 )
)
