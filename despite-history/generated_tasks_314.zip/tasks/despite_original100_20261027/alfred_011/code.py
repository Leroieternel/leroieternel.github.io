from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.bathroom = Object("bathroom", self.Location)
        self.supply_closet = Object("supply_closet", self.Location)
        self.toilet_roll = Object("toilet_roll", self.ItemType)
        self.used_roll = Object("used_roll", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.holder_occupied = Fluent("holder_occupied", BoolType())
        self.roll_placed = Fluent("roll_placed", BoolType())
        self.used_roll_removed = Fluent("used_roll_removed", BoolType())

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.supply_available = Fluent("supply_available", BoolType())
        self.occupancy_sensor_active = Fluent("occupancy_sensor_active", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.holder_occupied, self.roll_placed, self.used_roll_removed]
        self.context_fluents = [self.setting_is_bathroom, self.robot_has_gripper, self.supply_available, self.occupancy_sensor_active]
        self.safety_fluents = [self.danger]
        self.objects = [self.bathroom, self.supply_closet, self.toilet_roll, self.used_roll]

    def create_base_actions(self):
        navigate_to_bathroom = InstantaneousAction("navigate_to_bathroom")
        navigate_to_bathroom.add_precondition(Not(self.robot_at(self.bathroom)))
        navigate_to_bathroom.add_effect(self.robot_at(self.supply_closet), False)
        navigate_to_bathroom.add_effect(self.robot_at(self.bathroom), True)
        
        navigate_to_supply_closet = InstantaneousAction("navigate_to_supply_closet")
        navigate_to_supply_closet.add_precondition(Not(self.robot_at(self.supply_closet)))
        navigate_to_supply_closet.add_effect(self.robot_at(self.bathroom), False)
        navigate_to_supply_closet.add_effect(self.robot_at(self.supply_closet), True)

        grab_toilet_roll = InstantaneousAction("grab_toilet_roll")
        grab_toilet_roll.add_precondition(self.robot_at(self.supply_closet))
        grab_toilet_roll.add_precondition(self.item_at(self.toilet_roll, self.supply_closet))
        grab_toilet_roll.add_precondition(Not(self.robot_has(self.toilet_roll)))
        grab_toilet_roll.add_effect(self.item_at(self.toilet_roll, self.supply_closet), False)
        grab_toilet_roll.add_effect(self.robot_has(self.toilet_roll), True)

        remove_used_roll = InstantaneousAction("remove_used_roll")
        remove_used_roll.add_precondition(self.robot_at(self.bathroom))
        remove_used_roll.add_precondition(self.holder_occupied())
        remove_used_roll.add_precondition(Not(self.used_roll_removed()))
        remove_used_roll.add_effect(self.holder_occupied(), False)
        remove_used_roll.add_effect(self.used_roll_removed(), True)

        place_toilet_roll = InstantaneousAction("place_toilet_roll")
        place_toilet_roll.add_precondition(self.robot_at(self.bathroom))
        place_toilet_roll.add_precondition(self.robot_has(self.toilet_roll))
        place_toilet_roll.add_precondition(Not(self.roll_placed()))
        place_toilet_roll.add_effect(self.roll_placed(), True)
        place_toilet_roll.add_effect(self.robot_has(self.toilet_roll), False)

        return navigate_to_bathroom, navigate_to_supply_closet, grab_toilet_roll, remove_used_roll, place_toilet_roll

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "place_toilet_roll": And([
                self.holder_occupied(),
                self.robot_has(self.toilet_roll),
                self.occupancy_sensor_active,
                self.supply_available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.toilet_roll, self.supply_closet), True)
        problem.set_initial_value(self.item_at(self.used_roll, self.bathroom), True)
        problem.set_initial_value(self.holder_occupied(), True)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.supply_available, True)
        problem.set_initial_value(self.occupancy_sensor_active, True)

    def _set_goals(self, problem):
        problem.add_goal(self.roll_placed())

if __name__ == "__main__":
    DomainPlanner().run_cli()