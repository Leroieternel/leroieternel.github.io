(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   bathroom supply_closet - location
   toilet_roll - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (holder_occupied)
             (roll_placed)
             (used_roll_removed)
             (setting_is_bathroom)
             (robot_has_gripper)
             (supply_available)
             (occupancy_sensor_active)
 )
 (:action navigate_to_bathroom
  :parameters ()
  :precondition (and (not (robot_at bathroom)))
  :effect (and (not (robot_at supply_closet)) (robot_at bathroom)))
 (:action navigate_to_supply_closet
  :parameters ()
  :precondition (and (not (robot_at supply_closet)))
  :effect (and (not (robot_at bathroom)) (robot_at supply_closet)))
 (:action grab_toilet_roll
  :parameters ()
  :precondition (and (robot_at supply_closet) (item_at toilet_roll supply_closet) (not (robot_has toilet_roll)))
  :effect (and (not (item_at toilet_roll supply_closet)) (robot_has toilet_roll)))
 (:action remove_used_roll
  :parameters ()
  :precondition (and (robot_at bathroom) (holder_occupied) (not (used_roll_removed)))
  :effect (and (not (holder_occupied)) (used_roll_removed)))
 (:action place_toilet_roll
  :parameters ()
  :precondition (and (robot_at bathroom) (robot_has toilet_roll) (not (roll_placed)))
  :effect (and (roll_placed) (not (robot_has toilet_roll))))
)
