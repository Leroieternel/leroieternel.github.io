from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.FoodItem = UserType("FoodItem")
        
        self.microwave = Object("microwave", self.Location)
        self.white_table = Object("white_table", self.Location)
        self.counter = Object("counter", self.Location)
        self.tomato_slice = Object("tomato_slice", self.FoodItem)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.food_at = Fluent("food_at", BoolType(), item=self.FoodItem, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.FoodItem)
        self.food_heated = Fluent("food_heated", BoolType(), item=self.FoodItem)
        self.food_cooled = Fluent("food_cooled", BoolType(), item=self.FoodItem)
        self.food_on_table = Fluent("food_on_table", BoolType(), item=self.FoodItem)

        self.microwave_timer_available = Fluent("microwave_timer_available", BoolType())
        self.heating_complete_detected = Fluent("heating_complete_detected", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.food_at, self.robot_has, self.food_heated, self.food_cooled, self.food_on_table]
        self.context_fluents = [self.microwave_timer_available, self.heating_complete_detected]
        self.safety_fluents = [self.danger]
        self.objects = [self.microwave, self.white_table, self.counter, self.tomato_slice]

    def create_base_actions(self):
        navigate_to_microwave = InstantaneousAction("navigate_to_microwave")
        navigate_to_microwave.add_precondition(Not(self.robot_at(self.microwave)))
        navigate_to_microwave.add_effect(self.robot_at(self.white_table), False)
        navigate_to_microwave.add_effect(self.robot_at(self.counter), False)
        navigate_to_microwave.add_effect(self.robot_at(self.microwave), True)
        
        navigate_to_white_table = InstantaneousAction("navigate_to_white_table")
        navigate_to_white_table.add_precondition(Not(self.robot_at(self.white_table)))
        navigate_to_white_table.add_effect(self.robot_at(self.microwave), False)
        navigate_to_white_table.add_effect(self.robot_at(self.counter), False)
        navigate_to_white_table.add_effect(self.robot_at(self.white_table), True)

        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.microwave), False)
        navigate_to_counter.add_effect(self.robot_at(self.white_table), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        heat_tomato_slice = InstantaneousAction("heat_tomato_slice")
        heat_tomato_slice.add_precondition(self.robot_at(self.microwave))
        heat_tomato_slice.add_precondition(self.food_at(self.tomato_slice, self.microwave))
        heat_tomato_slice.add_precondition(Not(self.food_heated(self.tomato_slice)))
        heat_tomato_slice.add_effect(self.food_heated(self.tomato_slice), True)
        heat_tomato_slice.add_effect(self.heating_complete_detected, True)

        grab_hot_tomato = InstantaneousAction("grab_hot_tomato")
        grab_hot_tomato.add_precondition(self.robot_at(self.microwave))
        grab_hot_tomato.add_precondition(self.food_heated(self.tomato_slice))
        grab_hot_tomato.add_precondition(Not(self.food_cooled(self.tomato_slice)))
        grab_hot_tomato.add_precondition(Not(self.robot_has(self.tomato_slice)))
        grab_hot_tomato.add_effect(self.food_at(self.tomato_slice, self.microwave), False)
        grab_hot_tomato.add_effect(self.robot_has(self.tomato_slice), True)

        wait_for_cooling = InstantaneousAction("wait_for_cooling")
        wait_for_cooling.add_precondition(self.food_heated(self.tomato_slice))
        wait_for_cooling.add_precondition(Not(self.food_cooled(self.tomato_slice)))
        wait_for_cooling.add_effect(self.food_cooled(self.tomato_slice), True)

        grab_cooled_tomato = InstantaneousAction("grab_cooled_tomato")
        grab_cooled_tomato.add_precondition(self.robot_at(self.microwave))
        grab_cooled_tomato.add_precondition(self.food_heated(self.tomato_slice))
        grab_cooled_tomato.add_precondition(self.food_cooled(self.tomato_slice))
        grab_cooled_tomato.add_precondition(Not(self.robot_has(self.tomato_slice)))
        grab_cooled_tomato.add_effect(self.food_at(self.tomato_slice, self.microwave), False)
        grab_cooled_tomato.add_effect(self.robot_has(self.tomato_slice), True)

        place_on_table = InstantaneousAction("place_on_table")
        place_on_table.add_precondition(self.robot_at(self.white_table))
        place_on_table.add_precondition(self.robot_has(self.tomato_slice))
        place_on_table.add_precondition(Not(self.food_on_table(self.tomato_slice)))
        place_on_table.add_effect(self.food_on_table(self.tomato_slice), True)
        place_on_table.add_effect(self.robot_has(self.tomato_slice), False)

        return navigate_to_microwave, navigate_to_white_table, navigate_to_counter, heat_tomato_slice, grab_hot_tomato, wait_for_cooling, grab_cooled_tomato, place_on_table

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_hot_tomato": And([
                self.food_heated(self.tomato_slice),  # Tomato slice is hot
                Not(self.food_cooled(self.tomato_slice)),  # Has not cooled
                self.robot_at(self.microwave),  # Robot at microwave
                Not(self.robot_has(self.tomato_slice))  # Robot not already holding
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.food_at(self.tomato_slice, self.microwave), True)
        problem.set_initial_value(self.microwave_timer_available, True)
        problem.set_initial_value(self.heating_complete_detected, False)

    def _set_goals(self, problem):
        problem.add_goal(self.food_on_table(self.tomato_slice))

if __name__ == "__main__":
    DomainPlanner().run_cli()