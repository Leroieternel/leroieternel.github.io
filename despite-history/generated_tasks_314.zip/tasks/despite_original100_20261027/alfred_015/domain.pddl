(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location fooditem)
 (:constants
   counter microwave white_table - location
   tomato_slice - fooditem
 )
 (:predicates 
             (robot_at ?position - location)
             (food_at ?item - fooditem ?position - location)
             (robot_has ?item - fooditem)
             (food_heated ?item - fooditem)
             (food_cooled ?item - fooditem)
             (food_on_table ?item - fooditem)
             (microwave_timer_available)
             (heating_complete_detected)
 )
 (:action navigate_to_microwave
  :parameters ()
  :precondition (and (not (robot_at microwave)))
  :effect (and (not (robot_at white_table)) (not (robot_at counter)) (robot_at microwave)))
 (:action navigate_to_white_table
  :parameters ()
  :precondition (and (not (robot_at white_table)))
  :effect (and (not (robot_at microwave)) (not (robot_at counter)) (robot_at white_table)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at microwave)) (not (robot_at white_table)) (robot_at counter)))
 (:action heat_tomato_slice
  :parameters ()
  :precondition (and (robot_at microwave) (food_at tomato_slice microwave) (not (food_heated tomato_slice)))
  :effect (and (food_heated tomato_slice) (heating_complete_detected)))
 (:action grab_hot_tomato
  :parameters ()
  :precondition (and (robot_at microwave) (food_heated tomato_slice) (not (food_cooled tomato_slice)) (not (robot_has tomato_slice)))
  :effect (and (not (food_at tomato_slice microwave)) (robot_has tomato_slice)))
 (:action wait_for_cooling
  :parameters ()
  :precondition (and (food_heated tomato_slice) (not (food_cooled tomato_slice)))
  :effect (and (food_cooled tomato_slice)))
 (:action grab_cooled_tomato
  :parameters ()
  :precondition (and (robot_at microwave) (food_heated tomato_slice) (food_cooled tomato_slice) (not (robot_has tomato_slice)))
  :effect (and (not (food_at tomato_slice microwave)) (robot_has tomato_slice)))
 (:action place_on_table
  :parameters ()
  :precondition (and (robot_at white_table) (robot_has tomato_slice) (not (food_on_table tomato_slice)))
  :effect (and (food_on_table tomato_slice) (not (robot_has tomato_slice))))
)
