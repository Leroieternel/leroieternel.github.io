(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at counter)
              (food_at tomato_slice microwave)
              (microwave_timer_available)
 )
 (:goal (and 
           (food_on_table tomato_slice)
        )
 )
)
