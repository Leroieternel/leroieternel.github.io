(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   medical_kit - itemtype
 )
 (:init
              (robot_at supply_room)
              (item_at supplies supply_room)
              (item_at medical_kit supply_room)
              (setting_is_military)
              (robot_has_cargo_bay)
              (designated_route_known)
              (obstacle_avoidance_enabled)
 )
 (:goal (and 
           (supplies_delivered supplies)
        )
 )
)
