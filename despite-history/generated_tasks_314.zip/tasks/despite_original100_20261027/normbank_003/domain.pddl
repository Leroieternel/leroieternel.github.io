(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   barracks_hall cot_area supply_room - location
   supplies - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (supplies_delivered ?item - itemtype)
             (setting_is_military)
             (robot_has_cargo_bay)
             (designated_route_known)
             (hazard_area_marked)
             (obstacle_avoidance_enabled)
 )
 (:action navigate_to_supply_room
  :parameters ()
  :precondition (and (not (robot_at supply_room)))
  :effect (and (not (robot_at barracks_hall)) (not (robot_at cot_area)) (robot_at supply_room)))
 (:action navigate_to_barracks_hall
  :parameters ()
  :precondition (and (not (robot_at barracks_hall)))
  :effect (and (not (robot_at supply_room)) (not (robot_at cot_area)) (robot_at barracks_hall)))
 (:action navigate_to_cot_area
  :parameters ()
  :precondition (and (not (robot_at cot_area)))
  :effect (and (not (robot_at supply_room)) (not (robot_at barracks_hall)) (robot_at cot_area)))
 (:action grab_supplies
  :parameters ()
  :precondition (and (robot_at supply_room) (item_at supplies supply_room) (not (robot_has supplies)))
  :effect (and (not (item_at supplies supply_room)) (robot_has supplies)))
 (:action deliver_supplies
  :parameters ()
  :precondition (and (robot_at barracks_hall) (robot_has supplies) (not (supplies_delivered supplies)))
  :effect (and (supplies_delivered supplies) (not (robot_has supplies))))
)
