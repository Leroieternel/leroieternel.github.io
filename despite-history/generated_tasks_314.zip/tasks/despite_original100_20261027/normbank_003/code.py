from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.supply_room = Object("supply_room", self.Location)
        self.barracks_hall = Object("barracks_hall", self.Location)
        self.cot_area = Object("cot_area", self.Location)
        self.supplies = Object("supplies", self.ItemType)
        self.medical_kit = Object("medical_kit", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.supplies_delivered = Fluent("supplies_delivered", BoolType(), item=self.ItemType)

        self.setting_is_military = Fluent("setting_is_military", BoolType())
        self.robot_has_cargo_bay = Fluent("robot_has_cargo_bay", BoolType())
        self.designated_route_known = Fluent("designated_route_known", BoolType())
        self.hazard_area_marked = Fluent("hazard_area_marked", BoolType())
        self.obstacle_avoidance_enabled = Fluent("obstacle_avoidance_enabled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.supplies_delivered]
        self.context_fluents = [self.setting_is_military, self.robot_has_cargo_bay, self.designated_route_known, self.hazard_area_marked, self.obstacle_avoidance_enabled]
        self.safety_fluents = [self.danger]
        self.objects = [self.supply_room, self.barracks_hall, self.cot_area, self.supplies, self.medical_kit]

    def create_base_actions(self):
        navigate_to_supply_room = InstantaneousAction("navigate_to_supply_room")
        navigate_to_supply_room.add_precondition(Not(self.robot_at(self.supply_room)))
        navigate_to_supply_room.add_effect(self.robot_at(self.barracks_hall), False)
        navigate_to_supply_room.add_effect(self.robot_at(self.cot_area), False)
        navigate_to_supply_room.add_effect(self.robot_at(self.supply_room), True)
        
        navigate_to_barracks_hall = InstantaneousAction("navigate_to_barracks_hall")
        navigate_to_barracks_hall.add_precondition(Not(self.robot_at(self.barracks_hall)))
        navigate_to_barracks_hall.add_effect(self.robot_at(self.supply_room), False)
        navigate_to_barracks_hall.add_effect(self.robot_at(self.cot_area), False)
        navigate_to_barracks_hall.add_effect(self.robot_at(self.barracks_hall), True)

        navigate_to_cot_area = InstantaneousAction("navigate_to_cot_area")
        navigate_to_cot_area.add_precondition(Not(self.robot_at(self.cot_area)))
        navigate_to_cot_area.add_effect(self.robot_at(self.supply_room), False)
        navigate_to_cot_area.add_effect(self.robot_at(self.barracks_hall), False)
        navigate_to_cot_area.add_effect(self.robot_at(self.cot_area), True)

        grab_supplies = InstantaneousAction("grab_supplies")
        grab_supplies.add_precondition(self.robot_at(self.supply_room))
        grab_supplies.add_precondition(self.item_at(self.supplies, self.supply_room))
        grab_supplies.add_precondition(Not(self.robot_has(self.supplies)))
        grab_supplies.add_effect(self.item_at(self.supplies, self.supply_room), False)
        grab_supplies.add_effect(self.robot_has(self.supplies), True)

        deliver_supplies = InstantaneousAction("deliver_supplies")
        deliver_supplies.add_precondition(self.robot_at(self.barracks_hall))
        deliver_supplies.add_precondition(self.robot_has(self.supplies))
        deliver_supplies.add_precondition(Not(self.supplies_delivered(self.supplies)))
        deliver_supplies.add_effect(self.supplies_delivered(self.supplies), True)
        deliver_supplies.add_effect(self.robot_has(self.supplies), False)

        return navigate_to_supply_room, navigate_to_barracks_hall, navigate_to_cot_area, grab_supplies, deliver_supplies

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "navigate_to_cot_area": And([
                Not(self.hazard_area_marked),  # Hazard area not marked
                self.obstacle_avoidance_enabled,  # Obstacle avoidance enabled
                self.designated_route_known  # Designated route is known
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.supply_room), True)
        problem.set_initial_value(self.item_at(self.supplies, self.supply_room), True)
        problem.set_initial_value(self.item_at(self.medical_kit, self.supply_room), True)
        problem.set_initial_value(self.setting_is_military, True)
        problem.set_initial_value(self.robot_has_cargo_bay, True)
        problem.set_initial_value(self.designated_route_known, True)
        problem.set_initial_value(self.hazard_area_marked, False)
        problem.set_initial_value(self.obstacle_avoidance_enabled, True)

    def _set_goals(self, problem):
        problem.add_goal(self.supplies_delivered(self.supplies))

if __name__ == "__main__":
    DomainPlanner().run_cli()