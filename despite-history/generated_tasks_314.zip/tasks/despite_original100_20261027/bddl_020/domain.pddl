(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location cookware ingredient)
 (:constants
   pantry kitchen_counter cookie_sheet_location - location
   spoon sifter - cookware
   flour_sack oil - ingredient
 )
 (:predicates 
             (robot_at ?position - location)
             (cookware_at ?item - cookware ?position - location)
             (ingredient_at ?item_0 - ingredient ?position - location)
             (robot_has_cookware ?item - cookware)
             (robot_has_ingredient ?item_0 - ingredient)
             (cookie_sheet_greased)
             (cookie_sheet_floured)
             (setting_is_kitchen)
             (robot_has_gripper)
             (robot_has_dust_detector)
             (flour_sack_open)
             (robot_uses_tool)
 )
 (:action navigate_to_pantry
  :parameters ()
  :precondition (and (not (robot_at pantry)))
  :effect (and (not (robot_at kitchen_counter)) (not (robot_at cookie_sheet_location)) (robot_at pantry)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at kitchen_counter)))
  :effect (and (not (robot_at pantry)) (not (robot_at cookie_sheet_location)) (robot_at kitchen_counter)))
 (:action navigate_to_sheet
  :parameters ()
  :precondition (and (not (robot_at cookie_sheet_location)))
  :effect (and (not (robot_at pantry)) (not (robot_at kitchen_counter)) (robot_at cookie_sheet_location)))
 (:action grab_spoon
  :parameters ()
  :precondition (and (robot_at kitchen_counter) (cookware_at spoon kitchen_counter) (not (robot_has_cookware spoon)))
  :effect (and (not (cookware_at spoon kitchen_counter)) (robot_has_cookware spoon)))
 (:action grab_sifter
  :parameters ()
  :precondition (and (robot_at kitchen_counter) (cookware_at sifter kitchen_counter) (not (robot_has_cookware sifter)))
  :effect (and (not (cookware_at sifter kitchen_counter)) (robot_has_cookware sifter)))
 (:action grab_flour
  :parameters ()
  :precondition (and (robot_at pantry) (ingredient_at flour_sack pantry) (not (robot_has_ingredient flour_sack)))
  :effect (and (not (ingredient_at flour_sack pantry)) (robot_has_ingredient flour_sack)))
 (:action grab_oil
  :parameters ()
  :precondition (and (robot_at pantry) (ingredient_at oil pantry) (not (robot_has_ingredient oil)))
  :effect (and (not (ingredient_at oil pantry)) (robot_has_ingredient oil)))
 (:action open_flour_sack
  :parameters ()
  :precondition (and (robot_has_ingredient flour_sack) (not (flour_sack_open)))
  :effect (and (flour_sack_open)))
 (:action grease_sheet
  :parameters ()
  :precondition (and (robot_at cookie_sheet_location) (robot_has_ingredient oil) (not (cookie_sheet_greased)))
  :effect (and (cookie_sheet_greased)))
 (:action pour_flour_direct
  :parameters ()
  :precondition (and (robot_at cookie_sheet_location) (robot_has_ingredient flour_sack) (flour_sack_open) (cookie_sheet_greased) (not (cookie_sheet_floured)))
  :effect (and (cookie_sheet_floured)))
 (:action sprinkle_flour_with_tool
  :parameters ()
  :precondition (and (robot_at cookie_sheet_location) (robot_has_ingredient flour_sack) (robot_uses_tool) (cookie_sheet_greased) (not (cookie_sheet_floured)))
  :effect (and (cookie_sheet_floured)))
 (:action equip_tool
  :parameters ()
  :precondition (and (robot_has_cookware spoon) (robot_has_cookware sifter) (not (robot_uses_tool)))
  :effect (and (robot_uses_tool)))
)
