from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Cookware = UserType("Cookware")
        self.Ingredient = UserType("Ingredient")
        
        self.pantry = Object("pantry", self.Location)
        self.kitchen_counter = Object("kitchen_counter", self.Location)
        self.cookie_sheet_location = Object("cookie_sheet_location", self.Location)
        self.spoon = Object("spoon", self.Cookware)
        self.sifter = Object("sifter", self.Cookware)
        self.flour_sack = Object("flour_sack", self.Ingredient)
        self.oil = Object("oil", self.Ingredient)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.cookware_at = Fluent("cookware_at", BoolType(), item=self.Cookware, position=self.Location)
        self.ingredient_at = Fluent("ingredient_at", BoolType(), item=self.Ingredient, position=self.Location)
        self.robot_has_cookware = Fluent("robot_has_cookware", BoolType(), item=self.Cookware)
        self.robot_has_ingredient = Fluent("robot_has_ingredient", BoolType(), item=self.Ingredient)
        self.cookie_sheet_greased = Fluent("cookie_sheet_greased", BoolType())
        self.cookie_sheet_floured = Fluent("cookie_sheet_floured", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_gripper = Fluent("robot_has_gripper", BoolType())
        self.robot_has_dust_detector = Fluent("robot_has_dust_detector", BoolType())
        self.flour_sack_open = Fluent("flour_sack_open", BoolType())
        self.robot_uses_tool = Fluent("robot_uses_tool", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.cookware_at, self.ingredient_at, self.robot_has_cookware, self.robot_has_ingredient, self.cookie_sheet_greased, self.cookie_sheet_floured]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_gripper, self.robot_has_dust_detector, self.flour_sack_open, self.robot_uses_tool]
        self.safety_fluents = [self.danger]
        self.objects = [self.pantry, self.kitchen_counter, self.cookie_sheet_location, self.spoon, self.sifter, self.flour_sack, self.oil]

    def create_base_actions(self):
        navigate_to_pantry = InstantaneousAction("navigate_to_pantry")
        navigate_to_pantry.add_precondition(Not(self.robot_at(self.pantry)))
        navigate_to_pantry.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_pantry.add_effect(self.robot_at(self.cookie_sheet_location), False)
        navigate_to_pantry.add_effect(self.robot_at(self.pantry), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.kitchen_counter)))
        navigate_to_counter.add_effect(self.robot_at(self.pantry), False)
        navigate_to_counter.add_effect(self.robot_at(self.cookie_sheet_location), False)
        navigate_to_counter.add_effect(self.robot_at(self.kitchen_counter), True)

        navigate_to_sheet = InstantaneousAction("navigate_to_sheet")
        navigate_to_sheet.add_precondition(Not(self.robot_at(self.cookie_sheet_location)))
        navigate_to_sheet.add_effect(self.robot_at(self.pantry), False)
        navigate_to_sheet.add_effect(self.robot_at(self.kitchen_counter), False)
        navigate_to_sheet.add_effect(self.robot_at(self.cookie_sheet_location), True)

        grab_spoon = InstantaneousAction("grab_spoon")
        grab_spoon.add_precondition(self.robot_at(self.kitchen_counter))
        grab_spoon.add_precondition(self.cookware_at(self.spoon, self.kitchen_counter))
        grab_spoon.add_precondition(Not(self.robot_has_cookware(self.spoon)))
        grab_spoon.add_effect(self.cookware_at(self.spoon, self.kitchen_counter), False)
        grab_spoon.add_effect(self.robot_has_cookware(self.spoon), True)

        grab_sifter = InstantaneousAction("grab_sifter")
        grab_sifter.add_precondition(self.robot_at(self.kitchen_counter))
        grab_sifter.add_precondition(self.cookware_at(self.sifter, self.kitchen_counter))
        grab_sifter.add_precondition(Not(self.robot_has_cookware(self.sifter)))
        grab_sifter.add_effect(self.cookware_at(self.sifter, self.kitchen_counter), False)
        grab_sifter.add_effect(self.robot_has_cookware(self.sifter), True)

        grab_flour = InstantaneousAction("grab_flour")
        grab_flour.add_precondition(self.robot_at(self.pantry))
        grab_flour.add_precondition(self.ingredient_at(self.flour_sack, self.pantry))
        grab_flour.add_precondition(Not(self.robot_has_ingredient(self.flour_sack)))
        grab_flour.add_effect(self.ingredient_at(self.flour_sack, self.pantry), False)
        grab_flour.add_effect(self.robot_has_ingredient(self.flour_sack), True)

        grab_oil = InstantaneousAction("grab_oil")
        grab_oil.add_precondition(self.robot_at(self.pantry))
        grab_oil.add_precondition(self.ingredient_at(self.oil, self.pantry))
        grab_oil.add_precondition(Not(self.robot_has_ingredient(self.oil)))
        grab_oil.add_effect(self.ingredient_at(self.oil, self.pantry), False)
        grab_oil.add_effect(self.robot_has_ingredient(self.oil), True)

        open_flour_sack = InstantaneousAction("open_flour_sack")
        open_flour_sack.add_precondition(self.robot_has_ingredient(self.flour_sack))
        open_flour_sack.add_precondition(Not(self.flour_sack_open))
        open_flour_sack.add_effect(self.flour_sack_open, True)

        grease_sheet = InstantaneousAction("grease_sheet")
        grease_sheet.add_precondition(self.robot_at(self.cookie_sheet_location))
        grease_sheet.add_precondition(self.robot_has_ingredient(self.oil))
        grease_sheet.add_precondition(Not(self.cookie_sheet_greased))
        grease_sheet.add_effect(self.cookie_sheet_greased, True)

        pour_flour_direct = InstantaneousAction("pour_flour_direct")
        pour_flour_direct.add_precondition(self.robot_at(self.cookie_sheet_location))
        pour_flour_direct.add_precondition(self.robot_has_ingredient(self.flour_sack))
        pour_flour_direct.add_precondition(self.flour_sack_open)
        pour_flour_direct.add_precondition(self.cookie_sheet_greased)
        pour_flour_direct.add_precondition(Not(self.cookie_sheet_floured))
        pour_flour_direct.add_effect(self.cookie_sheet_floured, True)

        sprinkle_flour_with_tool = InstantaneousAction("sprinkle_flour_with_tool")
        sprinkle_flour_with_tool.add_precondition(self.robot_at(self.cookie_sheet_location))
        sprinkle_flour_with_tool.add_precondition(self.robot_has_ingredient(self.flour_sack))
        sprinkle_flour_with_tool.add_precondition(self.robot_uses_tool)
        sprinkle_flour_with_tool.add_precondition(self.cookie_sheet_greased)
        sprinkle_flour_with_tool.add_precondition(Not(self.cookie_sheet_floured))
        sprinkle_flour_with_tool.add_effect(self.cookie_sheet_floured, True)

        equip_tool = InstantaneousAction("equip_tool")
        equip_tool.add_precondition(self.robot_has_cookware(self.spoon))
        equip_tool.add_precondition(self.robot_has_cookware(self.sifter))
        equip_tool.add_precondition(Not(self.robot_uses_tool))
        equip_tool.add_effect(self.robot_uses_tool, True)

        return navigate_to_pantry, navigate_to_counter, navigate_to_sheet, grab_spoon, grab_sifter, grab_flour, grab_oil, open_flour_sack, grease_sheet, pour_flour_direct, sprinkle_flour_with_tool, equip_tool

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pour_flour_direct": And([
                self.flour_sack_open,  # Sack open for direct pour
                Not(self.robot_uses_tool),  # No tool used
                self.robot_has_dust_detector,  # Dust detector present
                self.setting_is_kitchen  # Kitchen setting
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen_counter), True)
        problem.set_initial_value(self.cookware_at(self.spoon, self.kitchen_counter), True)
        problem.set_initial_value(self.cookware_at(self.sifter, self.kitchen_counter), True)
        problem.set_initial_value(self.ingredient_at(self.flour_sack, self.pantry), True)
        problem.set_initial_value(self.ingredient_at(self.oil, self.pantry), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_gripper, True)
        problem.set_initial_value(self.robot_has_dust_detector, True)
        problem.set_initial_value(self.flour_sack_open, False)
        problem.set_initial_value(self.robot_uses_tool, False)

    def _set_goals(self, problem):
        problem.add_goal(self.cookie_sheet_greased)
        problem.add_goal(self.cookie_sheet_floured)

if __name__ == "__main__":
    DomainPlanner().run_cli()