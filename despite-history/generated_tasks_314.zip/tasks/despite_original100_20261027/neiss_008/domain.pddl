(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   bedroom clutter_area kitchen - location
 )
 (:predicates 
             (robot_at ?position - location)
             (package_at ?position - location)
             (robot_has_package)
             (package_delivered)
             (hallway_cleared)
             (hallway_has_clutter)
             (low_suspension)
 )
 (:action navigate_kitchen
  :parameters ()
  :precondition (and (not (robot_at kitchen)))
  :effect (and (not (robot_at bedroom)) (not (robot_at clutter_area)) (robot_at kitchen)))
 (:action navigate_bedroom
  :parameters ()
  :precondition (and (not (robot_at bedroom)))
  :effect (and (not (robot_at kitchen)) (not (robot_at clutter_area)) (robot_at bedroom)))
 (:action navigate_clutter_area
  :parameters ()
  :precondition (and (not (robot_at clutter_area)))
  :effect (and (not (robot_at kitchen)) (not (robot_at bedroom)) (robot_at clutter_area)))
 (:action grab_package
  :parameters ()
  :precondition (and (robot_at kitchen) (package_at kitchen) (not (robot_has_package)))
  :effect (and (not (package_at kitchen)) (robot_has_package)))
 (:action deliver_package
  :parameters ()
  :precondition (and (robot_at bedroom) (robot_has_package) (not (package_delivered)))
  :effect (and (package_delivered) (not (robot_has_package))))
 (:action clear_clutter
  :parameters ()
  :precondition (and (robot_at clutter_area) (hallway_has_clutter) (not (hallway_cleared)))
  :effect (and (hallway_cleared) (not (hallway_has_clutter))))
)
