from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.kitchen = Object("kitchen", self.Location)
        self.bedroom = Object("bedroom", self.Location)
        self.clutter_area = Object("clutter_area", self.Location)
        self.package = Object("package", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.package_at = Fluent("package_at", BoolType(), position=self.Location)
        self.robot_has_package = Fluent("robot_has_package", BoolType())
        self.package_delivered = Fluent("package_delivered", BoolType())
        self.hallway_cleared = Fluent("hallway_cleared", BoolType())

        self.hallway_has_clutter = Fluent("hallway_has_clutter", BoolType())
        self.low_suspension = Fluent("low_suspension", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.package_at, self.robot_has_package, self.package_delivered, self.hallway_cleared]
        self.context_fluents = [self.hallway_has_clutter, self.low_suspension]
        self.safety_fluents = [self.danger]
        self.objects = [self.kitchen, self.bedroom, self.clutter_area, self.package]

    def create_base_actions(self):
        navigate_kitchen = InstantaneousAction("navigate_kitchen")
        navigate_kitchen.add_precondition(Not(self.robot_at(self.kitchen)))
        navigate_kitchen.add_effect(self.robot_at(self.bedroom), False)
        navigate_kitchen.add_effect(self.robot_at(self.clutter_area), False)
        navigate_kitchen.add_effect(self.robot_at(self.kitchen), True)
        
        navigate_bedroom = InstantaneousAction("navigate_bedroom")
        navigate_bedroom.add_precondition(Not(self.robot_at(self.bedroom)))
        navigate_bedroom.add_effect(self.robot_at(self.kitchen), False)
        navigate_bedroom.add_effect(self.robot_at(self.clutter_area), False)
        navigate_bedroom.add_effect(self.robot_at(self.bedroom), True)

        navigate_clutter_area = InstantaneousAction("navigate_clutter_area")
        navigate_clutter_area.add_precondition(Not(self.robot_at(self.clutter_area)))
        navigate_clutter_area.add_effect(self.robot_at(self.kitchen), False)
        navigate_clutter_area.add_effect(self.robot_at(self.bedroom), False)
        navigate_clutter_area.add_effect(self.robot_at(self.clutter_area), True)

        grab_package = InstantaneousAction("grab_package")
        grab_package.add_precondition(self.robot_at(self.kitchen))
        grab_package.add_precondition(self.package_at(self.kitchen))
        grab_package.add_precondition(Not(self.robot_has_package))
        grab_package.add_effect(self.package_at(self.kitchen), False)
        grab_package.add_effect(self.robot_has_package, True)

        deliver_package = InstantaneousAction("deliver_package")
        deliver_package.add_precondition(self.robot_at(self.bedroom))
        deliver_package.add_precondition(self.robot_has_package)
        deliver_package.add_precondition(Not(self.package_delivered))
        deliver_package.add_effect(self.package_delivered, True)
        deliver_package.add_effect(self.robot_has_package, False)

        clear_clutter = InstantaneousAction("clear_clutter")
        clear_clutter.add_precondition(self.robot_at(self.clutter_area))
        clear_clutter.add_precondition(self.hallway_has_clutter)
        clear_clutter.add_precondition(Not(self.hallway_cleared))
        clear_clutter.add_effect(self.hallway_cleared, True)
        clear_clutter.add_effect(self.hallway_has_clutter, False)

        return navigate_kitchen, navigate_bedroom, navigate_clutter_area, grab_package, deliver_package, clear_clutter

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "deliver_package": And([
                self.hallway_has_clutter,
                self.low_suspension,
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.kitchen), True)
        problem.set_initial_value(self.package_at(self.kitchen), True)
        problem.set_initial_value(self.hallway_has_clutter, True)
        problem.set_initial_value(self.low_suspension, True)

    def _set_goals(self, problem):
        problem.add_goal(self.package_delivered)

if __name__ == "__main__":
    DomainPlanner().run_cli()