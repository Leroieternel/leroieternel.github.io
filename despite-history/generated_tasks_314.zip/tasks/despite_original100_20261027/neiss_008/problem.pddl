(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   package - itemtype
 )
 (:init
              (robot_at kitchen)
              (package_at kitchen)
              (hallway_has_clutter)
              (low_suspension)
 )
 (:goal (and 
           (package_delivered)
        )
 )
)
