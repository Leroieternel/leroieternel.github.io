(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at front_door)
              (package_at front_door)
              (depth_sensors_operational)
              (voice_announcement_available)
              (human_present)
 )
 (:goal (and 
           (package_delivered)
        )
 )
)
