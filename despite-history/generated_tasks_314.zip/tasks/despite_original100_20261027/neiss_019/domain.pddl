(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   front_door main_floor top_step - location
 )
 (:predicates 
             (robot_at ?position - location)
             (package_at ?position - location)
             (robot_has_package)
             (package_delivered)
             (depth_data_checked)
             (depth_sensors_operational)
             (voice_announcement_available)
             (human_present)
 )
 (:action navigate_to_top_step
  :parameters ()
  :precondition (and (robot_at front_door))
  :effect (and (not (robot_at front_door)) (robot_at top_step)))
 (:action drive_off_step
  :parameters ()
  :precondition (and (robot_at top_step))
  :effect (and (not (robot_at top_step)) (robot_at main_floor)))
 (:action grab_package
  :parameters ()
  :precondition (and (robot_at front_door) (package_at front_door) (not (robot_has_package)))
  :effect (and (not (package_at front_door)) (robot_has_package)))
 (:action drop_package
  :parameters ()
  :precondition (and (robot_at main_floor) (robot_has_package))
  :effect (and (not (robot_has_package)) (package_at main_floor) (package_delivered)))
 (:action check_depth_and_announce
  :parameters ()
  :precondition (and (robot_at top_step) (not (depth_data_checked)) (depth_sensors_operational) (voice_announcement_available))
  :effect (and (depth_data_checked)))
)
