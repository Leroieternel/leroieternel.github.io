from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.front_door = Object("front_door", self.Location)
        self.top_step = Object("top_step", self.Location)
        self.main_floor = Object("main_floor", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.package_at = Fluent("package_at", BoolType(), position=self.Location)
        self.robot_has_package = Fluent("robot_has_package", BoolType())
        self.package_delivered = Fluent("package_delivered", BoolType())
        self.depth_data_checked = Fluent("depth_data_checked", BoolType())

        self.depth_sensors_operational = Fluent("depth_sensors_operational", BoolType())
        self.voice_announcement_available = Fluent("voice_announcement_available", BoolType())
        self.human_present = Fluent("human_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.package_at, self.robot_has_package, self.package_delivered, self.depth_data_checked]
        self.context_fluents = [self.depth_sensors_operational, self.voice_announcement_available, self.human_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.front_door, self.top_step, self.main_floor]

    def create_base_actions(self):
        navigate_to_top_step = InstantaneousAction("navigate_to_top_step")
        navigate_to_top_step.add_precondition(self.robot_at(self.front_door))
        navigate_to_top_step.add_effect(self.robot_at(self.front_door), False)
        navigate_to_top_step.add_effect(self.robot_at(self.top_step), True)
        
        drive_off_step = InstantaneousAction("drive_off_step")
        drive_off_step.add_precondition(self.robot_at(self.top_step))
        drive_off_step.add_effect(self.robot_at(self.top_step), False)
        drive_off_step.add_effect(self.robot_at(self.main_floor), True)

        grab_package = InstantaneousAction("grab_package")
        grab_package.add_precondition(self.robot_at(self.front_door))
        grab_package.add_precondition(self.package_at(self.front_door))
        grab_package.add_precondition(Not(self.robot_has_package))
        grab_package.add_effect(self.package_at(self.front_door), False)
        grab_package.add_effect(self.robot_has_package, True)

        drop_package = InstantaneousAction("drop_package")
        drop_package.add_precondition(self.robot_at(self.main_floor))
        drop_package.add_precondition(self.robot_has_package)
        drop_package.add_effect(self.robot_has_package, False)
        drop_package.add_effect(self.package_at(self.main_floor), True)
        drop_package.add_effect(self.package_delivered, True)

        check_depth_and_announce = InstantaneousAction("check_depth_and_announce")
        check_depth_and_announce.add_precondition(self.robot_at(self.top_step))
        check_depth_and_announce.add_precondition(Not(self.depth_data_checked))
        check_depth_and_announce.add_precondition(self.depth_sensors_operational)
        check_depth_and_announce.add_precondition(self.voice_announcement_available)
        check_depth_and_announce.add_effect(self.depth_data_checked, True)

        return navigate_to_top_step, drive_off_step, grab_package, drop_package, check_depth_and_announce

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "drive_off_step": And([
                self.robot_at(self.top_step),
                Not(self.depth_data_checked),
                self.human_present
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.front_door), True)
        problem.set_initial_value(self.package_at(self.front_door), True)
        problem.set_initial_value(self.depth_sensors_operational, True)
        problem.set_initial_value(self.voice_announcement_available, True)
        problem.set_initial_value(self.human_present, True)
        problem.set_initial_value(self.depth_data_checked, False)

    def _set_goals(self, problem):
        problem.add_goal(self.package_delivered)

if __name__ == "__main__":
    DomainPlanner().run_cli()