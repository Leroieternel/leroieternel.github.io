(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   trash_bin counter fridge stove - location
   pot apple - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (robot_has_knife)
             (item_sliced ?item - itemtype)
             (apple_in_pot)
             (pot_on_stove)
             (pot_in_fridge)
             (on_clean_surface ?item - itemtype)
             (cutting_board_available)
             (trash_bin_identified)
             (knife_clean)
             (apple_washed)
 )
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at trash_bin)) (not (robot_at stove)) (not (robot_at fridge)) (robot_at counter)))
 (:action navigate_to_trash_bin
  :parameters ()
  :precondition (and (not (robot_at trash_bin)))
  :effect (and (not (robot_at counter)) (not (robot_at stove)) (not (robot_at fridge)) (robot_at trash_bin)))
 (:action navigate_to_stove
  :parameters ()
  :precondition (and (not (robot_at stove)))
  :effect (and (not (robot_at counter)) (not (robot_at trash_bin)) (not (robot_at fridge)) (robot_at stove)))
 (:action navigate_to_fridge
  :parameters ()
  :precondition (and (not (robot_at fridge)))
  :effect (and (not (robot_at counter)) (not (robot_at trash_bin)) (not (robot_at stove)) (robot_at fridge)))
 (:action grab_apple
  :parameters ()
  :precondition (and (robot_at counter) (item_at apple counter) (not (robot_has apple)))
  :effect (and (not (item_at apple counter)) (robot_has apple)))
 (:action grab_knife
  :parameters ()
  :precondition (and (robot_at counter) (not (robot_has_knife)))
  :effect (and (robot_has_knife)))
 (:action slice_apple_on_counter
  :parameters ()
  :precondition (and (robot_has apple) (robot_has_knife) (not (item_sliced apple)) (robot_at counter))
  :effect (and (item_sliced apple) (on_clean_surface apple)))
 (:action slice_apple_in_trash
  :parameters ()
  :precondition (and (robot_has apple) (robot_has_knife) (not (item_sliced apple)) (robot_at trash_bin))
  :effect (and (item_sliced apple) (not (on_clean_surface apple))))
 (:action place_apple_in_pot
  :parameters ()
  :precondition (and (robot_has apple) (item_sliced apple) (not (apple_in_pot)))
  :effect (and (apple_in_pot) (not (robot_has apple))))
 (:action grab_pot
  :parameters ()
  :precondition (and (robot_at stove) (item_at pot stove) (not (robot_has pot)))
  :effect (and (not (item_at pot stove)) (robot_has pot)))
 (:action put_pot_in_fridge
  :parameters ()
  :precondition (and (robot_has pot) (apple_in_pot) (robot_at fridge))
  :effect (and (pot_in_fridge) (not (robot_has pot))))
)
