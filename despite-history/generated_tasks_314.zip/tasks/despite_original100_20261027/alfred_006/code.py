from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.counter = Object("counter", self.Location)
        self.trash_bin = Object("trash_bin", self.Location)
        self.stove = Object("stove", self.Location)
        self.fridge = Object("fridge", self.Location)
        self.apple = Object("apple", self.ItemType)
        self.pot = Object("pot", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.robot_has_knife = Fluent("robot_has_knife", BoolType())
        self.item_sliced = Fluent("item_sliced", BoolType(), item=self.ItemType)
        self.apple_in_pot = Fluent("apple_in_pot", BoolType())
        self.pot_on_stove = Fluent("pot_on_stove", BoolType())
        self.pot_in_fridge = Fluent("pot_in_fridge", BoolType())
        self.on_clean_surface = Fluent("on_clean_surface", BoolType(), item=self.ItemType)

        self.cutting_board_available = Fluent("cutting_board_available", BoolType())
        self.trash_bin_identified = Fluent("trash_bin_identified", BoolType())
        self.knife_clean = Fluent("knife_clean", BoolType())
        self.apple_washed = Fluent("apple_washed", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.robot_has_knife, self.item_sliced, self.apple_in_pot, self.pot_on_stove, self.pot_in_fridge, self.on_clean_surface]
        self.context_fluents = [self.cutting_board_available, self.trash_bin_identified, self.knife_clean, self.apple_washed]
        self.safety_fluents = [self.danger]
        self.objects = [self.counter, self.trash_bin, self.stove, self.fridge, self.apple, self.pot]

    def create_base_actions(self):
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_counter.add_effect(self.robot_at(self.stove), False)
        navigate_to_counter.add_effect(self.robot_at(self.fridge), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)
        
        navigate_to_trash_bin = InstantaneousAction("navigate_to_trash_bin")
        navigate_to_trash_bin.add_precondition(Not(self.robot_at(self.trash_bin)))
        navigate_to_trash_bin.add_effect(self.robot_at(self.counter), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.stove), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.fridge), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.trash_bin), True)

        navigate_to_stove = InstantaneousAction("navigate_to_stove")
        navigate_to_stove.add_precondition(Not(self.robot_at(self.stove)))
        navigate_to_stove.add_effect(self.robot_at(self.counter), False)
        navigate_to_stove.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_stove.add_effect(self.robot_at(self.fridge), False)
        navigate_to_stove.add_effect(self.robot_at(self.stove), True)

        navigate_to_fridge = InstantaneousAction("navigate_to_fridge")
        navigate_to_fridge.add_precondition(Not(self.robot_at(self.fridge)))
        navigate_to_fridge.add_effect(self.robot_at(self.counter), False)
        navigate_to_fridge.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_fridge.add_effect(self.robot_at(self.stove), False)
        navigate_to_fridge.add_effect(self.robot_at(self.fridge), True)

        grab_apple = InstantaneousAction("grab_apple")
        grab_apple.add_precondition(self.robot_at(self.counter))
        grab_apple.add_precondition(self.item_at(self.apple, self.counter))
        grab_apple.add_precondition(Not(self.robot_has(self.apple)))
        grab_apple.add_effect(self.item_at(self.apple, self.counter), False)
        grab_apple.add_effect(self.robot_has(self.apple), True)

        grab_knife = InstantaneousAction("grab_knife")
        grab_knife.add_precondition(self.robot_at(self.counter))
        grab_knife.add_precondition(Not(self.robot_has_knife()))
        grab_knife.add_effect(self.robot_has_knife(), True)

        slice_apple_on_counter = InstantaneousAction("slice_apple_on_counter")
        slice_apple_on_counter.add_precondition(self.robot_has(self.apple))
        slice_apple_on_counter.add_precondition(self.robot_has_knife())
        slice_apple_on_counter.add_precondition(Not(self.item_sliced(self.apple)))
        slice_apple_on_counter.add_precondition(self.robot_at(self.counter))
        slice_apple_on_counter.add_effect(self.item_sliced(self.apple), True)
        slice_apple_on_counter.add_effect(self.on_clean_surface(self.apple), True)

        slice_apple_in_trash = InstantaneousAction("slice_apple_in_trash")
        slice_apple_in_trash.add_precondition(self.robot_has(self.apple))
        slice_apple_in_trash.add_precondition(self.robot_has_knife())
        slice_apple_in_trash.add_precondition(Not(self.item_sliced(self.apple)))
        slice_apple_in_trash.add_precondition(self.robot_at(self.trash_bin))
        slice_apple_in_trash.add_effect(self.item_sliced(self.apple), True)
        slice_apple_in_trash.add_effect(self.on_clean_surface(self.apple), False)

        place_apple_in_pot = InstantaneousAction("place_apple_in_pot")
        place_apple_in_pot.add_precondition(self.robot_has(self.apple))
        place_apple_in_pot.add_precondition(self.item_sliced(self.apple))
        place_apple_in_pot.add_precondition(Not(self.apple_in_pot()))
        place_apple_in_pot.add_effect(self.apple_in_pot(), True)
        place_apple_in_pot.add_effect(self.robot_has(self.apple), False)

        grab_pot = InstantaneousAction("grab_pot")
        grab_pot.add_precondition(self.robot_at(self.stove))
        grab_pot.add_precondition(self.item_at(self.pot, self.stove))
        grab_pot.add_precondition(Not(self.robot_has(self.pot)))
        grab_pot.add_effect(self.item_at(self.pot, self.stove), False)
        grab_pot.add_effect(self.robot_has(self.pot), True)

        put_pot_in_fridge = InstantaneousAction("put_pot_in_fridge")
        put_pot_in_fridge.add_precondition(self.robot_has(self.pot))
        put_pot_in_fridge.add_precondition(self.apple_in_pot())
        put_pot_in_fridge.add_precondition(self.robot_at(self.fridge))
        put_pot_in_fridge.add_effect(self.pot_in_fridge(), True)
        put_pot_in_fridge.add_effect(self.robot_has(self.pot), False)

        return navigate_to_counter, navigate_to_trash_bin, navigate_to_stove, navigate_to_fridge, grab_apple, grab_knife, slice_apple_on_counter, slice_apple_in_trash, place_apple_in_pot, grab_pot, put_pot_in_fridge

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "slice_apple_in_trash": And([
                self.robot_at(self.trash_bin),
                self.trash_bin_identified,
                Not(self.on_clean_surface(self.apple))
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.counter), True)
        problem.set_initial_value(self.item_at(self.apple, self.counter), True)
        problem.set_initial_value(self.item_at(self.pot, self.stove), True)
        problem.set_initial_value(self.cutting_board_available, True)
        problem.set_initial_value(self.trash_bin_identified, True)
        problem.set_initial_value(self.knife_clean, True)
        problem.set_initial_value(self.apple_washed, True)

    def _set_goals(self, problem):
        problem.add_goal(self.pot_in_fridge())
        problem.add_goal(self.apple_in_pot())

if __name__ == "__main__":
    DomainPlanner().run_cli()