(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at counter)
              (item_at apple counter)
              (item_at pot stove)
              (cutting_board_available)
              (trash_bin_identified)
              (knife_clean)
              (apple_washed)
 )
 (:goal (and 
           (pot_in_fridge)
           (apple_in_pot)
        )
 )
)
