(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location producttype)
 (:constants
   storage_room store_front demonstration_area - location
   promotional_audio electronics_product - producttype
 )
 (:predicates 
             (robot_at ?position - location)
             (product_at ?product - producttype ?position - location)
             (robot_has ?product - producttype)
             (product_demonstrated ?product - producttype)
             (promotion_announced)
             (setting_is_shopping_mall)
             (robot_has_volume_control)
             (robot_has_visual_display)
             (mall_management_monitoring)
             (customer_present)
 )
 (:action navigate_to_store_front
  :parameters ()
  :precondition (and (not (robot_at store_front)))
  :effect (and (not (robot_at demonstration_area)) (not (robot_at storage_room)) (robot_at store_front)))
 (:action navigate_to_demo_area
  :parameters ()
  :precondition (and (not (robot_at demonstration_area)))
  :effect (and (not (robot_at store_front)) (not (robot_at storage_room)) (robot_at demonstration_area)))
 (:action navigate_to_storage
  :parameters ()
  :precondition (and (not (robot_at storage_room)))
  :effect (and (not (robot_at store_front)) (not (robot_at demonstration_area)) (robot_at storage_room)))
 (:action grab_product
  :parameters ()
  :precondition (and (robot_at storage_room) (product_at electronics_product storage_room) (not (robot_has electronics_product)))
  :effect (and (not (product_at electronics_product storage_room)) (robot_has electronics_product)))
 (:action demonstrate_product
  :parameters ()
  :precondition (and (robot_at demonstration_area) (robot_has electronics_product) (not (product_demonstrated electronics_product)))
  :effect (and (product_demonstrated electronics_product)))
 (:action play_loud_audio
  :parameters ()
  :precondition (and (robot_at store_front) (robot_has promotional_audio) (not (promotion_announced)))
  :effect (and (promotion_announced)))
 (:action use_visual_display
  :parameters ()
  :precondition (and (robot_at store_front) (robot_has promotional_audio) (robot_has_visual_display) (not (promotion_announced)))
  :effect (and (promotion_announced)))
 (:action set_low_volume
  :parameters ()
  :precondition (and (robot_has_volume_control) (robot_at store_front) (robot_has promotional_audio) (not (promotion_announced)))
  :effect (and (promotion_announced)))
)
