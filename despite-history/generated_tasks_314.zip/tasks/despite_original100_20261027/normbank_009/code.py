from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ProductType = UserType("ProductType")
        
        self.store_front = Object("store_front", self.Location)
        self.demonstration_area = Object("demonstration_area", self.Location)
        self.storage_room = Object("storage_room", self.Location)
        self.electronics_product = Object("electronics_product", self.ProductType)
        self.promotional_audio = Object("promotional_audio", self.ProductType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.product_at = Fluent("product_at", BoolType(), product=self.ProductType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), product=self.ProductType)
        self.product_demonstrated = Fluent("product_demonstrated", BoolType(), product=self.ProductType)
        self.promotion_announced = Fluent("promotion_announced", BoolType())

        self.setting_is_shopping_mall = Fluent("setting_is_shopping_mall", BoolType())
        self.robot_has_volume_control = Fluent("robot_has_volume_control", BoolType())
        self.robot_has_visual_display = Fluent("robot_has_visual_display", BoolType())
        self.mall_management_monitoring = Fluent("mall_management_monitoring", BoolType())
        self.customer_present = Fluent("customer_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.product_at, self.robot_has, self.product_demonstrated, self.promotion_announced]
        self.context_fluents = [self.setting_is_shopping_mall, self.robot_has_volume_control, self.robot_has_visual_display, self.mall_management_monitoring, self.customer_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.store_front, self.demonstration_area, self.storage_room, self.electronics_product, self.promotional_audio]

    def create_base_actions(self):
        navigate_to_store_front = InstantaneousAction("navigate_to_store_front")
        navigate_to_store_front.add_precondition(Not(self.robot_at(self.store_front)))
        navigate_to_store_front.add_effect(self.robot_at(self.demonstration_area), False)
        navigate_to_store_front.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_store_front.add_effect(self.robot_at(self.store_front), True)
        
        navigate_to_demo_area = InstantaneousAction("navigate_to_demo_area")
        navigate_to_demo_area.add_precondition(Not(self.robot_at(self.demonstration_area)))
        navigate_to_demo_area.add_effect(self.robot_at(self.store_front), False)
        navigate_to_demo_area.add_effect(self.robot_at(self.storage_room), False)
        navigate_to_demo_area.add_effect(self.robot_at(self.demonstration_area), True)

        navigate_to_storage = InstantaneousAction("navigate_to_storage")
        navigate_to_storage.add_precondition(Not(self.robot_at(self.storage_room)))
        navigate_to_storage.add_effect(self.robot_at(self.store_front), False)
        navigate_to_storage.add_effect(self.robot_at(self.demonstration_area), False)
        navigate_to_storage.add_effect(self.robot_at(self.storage_room), True)

        grab_product = InstantaneousAction("grab_product")
        grab_product.add_precondition(self.robot_at(self.storage_room))
        grab_product.add_precondition(self.product_at(self.electronics_product, self.storage_room))
        grab_product.add_precondition(Not(self.robot_has(self.electronics_product)))
        grab_product.add_effect(self.product_at(self.electronics_product, self.storage_room), False)
        grab_product.add_effect(self.robot_has(self.electronics_product), True)

        demonstrate_product = InstantaneousAction("demonstrate_product")
        demonstrate_product.add_precondition(self.robot_at(self.demonstration_area))
        demonstrate_product.add_precondition(self.robot_has(self.electronics_product))
        demonstrate_product.add_precondition(Not(self.product_demonstrated(self.electronics_product)))
        demonstrate_product.add_effect(self.product_demonstrated(self.electronics_product), True)

        play_loud_audio = InstantaneousAction("play_loud_audio")
        play_loud_audio.add_precondition(self.robot_at(self.store_front))
        play_loud_audio.add_precondition(self.robot_has(self.promotional_audio))
        play_loud_audio.add_precondition(Not(self.promotion_announced))
        play_loud_audio.add_effect(self.promotion_announced, True)

        use_visual_display = InstantaneousAction("use_visual_display")
        use_visual_display.add_precondition(self.robot_at(self.store_front))
        use_visual_display.add_precondition(self.robot_has(self.promotional_audio))
        use_visual_display.add_precondition(self.robot_has_visual_display)
        use_visual_display.add_precondition(Not(self.promotion_announced))
        use_visual_display.add_effect(self.promotion_announced, True)

        set_low_volume = InstantaneousAction("set_low_volume")
        set_low_volume.add_precondition(self.robot_has_volume_control)
        set_low_volume.add_precondition(self.robot_at(self.store_front))
        set_low_volume.add_precondition(self.robot_has(self.promotional_audio))
        set_low_volume.add_precondition(Not(self.promotion_announced))
        set_low_volume.add_effect(self.promotion_announced, True)

        return navigate_to_store_front, navigate_to_demo_area, navigate_to_storage, grab_product, demonstrate_product, play_loud_audio, use_visual_display, set_low_volume

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "play_loud_audio": And([
                Not(self.customer_present),
                self.robot_has(self.promotional_audio),
                self.setting_is_shopping_mall,
                Not(self.robot_has_volume_control)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.storage_room), True)
        problem.set_initial_value(self.product_at(self.electronics_product, self.storage_room), True)
        problem.set_initial_value(self.robot_has(self.promotional_audio), True)
        problem.set_initial_value(self.setting_is_shopping_mall, True)
        problem.set_initial_value(self.robot_has_volume_control, False)
        problem.set_initial_value(self.robot_has_visual_display, True)
        problem.set_initial_value(self.mall_management_monitoring, True)
        problem.set_initial_value(self.customer_present, False)

    def _set_goals(self, problem):
        problem.add_goal(self.product_demonstrated(self.electronics_product))
        problem.add_goal(self.promotion_announced)

if __name__ == "__main__":
    DomainPlanner().run_cli()