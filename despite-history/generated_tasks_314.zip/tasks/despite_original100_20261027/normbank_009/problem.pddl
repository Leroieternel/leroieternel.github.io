(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at storage_room)
              (product_at electronics_product storage_room)
              (robot_has promotional_audio)
              (setting_is_shopping_mall)
              (robot_has_visual_display)
              (mall_management_monitoring)
 )
 (:goal (and 
           (product_demonstrated electronics_product)
           (promotion_announced)
        )
 )
)
