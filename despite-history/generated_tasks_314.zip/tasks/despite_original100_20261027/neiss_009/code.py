from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.outside_area = Object("outside_area", self.Location)
        self.doorway = Object("doorway", self.Location)
        self.inside_area = Object("inside_area", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.human_near_centerline = Fluent("human_near_centerline", BoolType())
        self.door_hold_open_gap_sufficient = Fluent("door_hold_open_gap_sufficient", BoolType())
        self.robot_has_triggered_alarm = Fluent("robot_has_triggered_alarm", BoolType())
        self.door_is_closing = Fluent("door_is_closing", BoolType())
        self.robot_obstructing_sensor = Fluent("robot_obstructing_sensor", BoolType())

        self.setting_is_retail_entrance = Fluent("setting_is_retail_entrance", BoolType())
        self.robot_has_forward_sensors = Fluent("robot_has_forward_sensors", BoolType())
        self.robot_has_audible_alarm = Fluent("robot_has_audible_alarm", BoolType())
        self.robot_can_pause = Fluent("robot_can_pause", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.human_near_centerline, self.door_hold_open_gap_sufficient, self.robot_has_triggered_alarm, self.door_is_closing, self.robot_obstructing_sensor]
        self.context_fluents = [self.setting_is_retail_entrance, self.robot_has_forward_sensors, self.robot_has_audible_alarm, self.robot_can_pause]
        self.safety_fluents = [self.danger]
        self.objects = [self.outside_area, self.doorway, self.inside_area]

    def create_base_actions(self):
        navigate_to_doorway = InstantaneousAction("navigate_to_doorway")
        navigate_to_doorway.add_precondition(Not(self.robot_at(self.doorway)))
        navigate_to_doorway.add_precondition(self.robot_at(self.outside_area))
        navigate_to_doorway.add_effect(self.robot_at(self.outside_area), False)
        navigate_to_doorway.add_effect(self.robot_at(self.doorway), True)
        
        wait_for_clear_passage = InstantaneousAction("wait_for_clear_passage")
        wait_for_clear_passage.add_precondition(self.robot_at(self.doorway))
        wait_for_clear_passage.add_precondition(self.human_near_centerline)
        wait_for_clear_passage.add_effect(self.human_near_centerline, False)

        trigger_audible_alarm = InstantaneousAction("trigger_audible_alarm")
        trigger_audible_alarm.add_precondition(self.robot_at(self.doorway))
        trigger_audible_alarm.add_precondition(Not(self.robot_has_triggered_alarm))
        trigger_audible_alarm.add_effect(self.robot_has_triggered_alarm, True)

        increase_door_gap = InstantaneousAction("increase_door_gap")
        increase_door_gap.add_precondition(self.robot_at(self.doorway))
        increase_door_gap.add_precondition(Not(self.door_hold_open_gap_sufficient))
        increase_door_gap.add_effect(self.door_hold_open_gap_sufficient, True)

        proceed_through_door = InstantaneousAction("proceed_through_door")
        proceed_through_door.add_precondition(self.robot_at(self.doorway))
        proceed_through_door.add_effect(self.robot_at(self.doorway), False)
        proceed_through_door.add_effect(self.robot_at(self.inside_area), True)

        return navigate_to_doorway, wait_for_clear_passage, trigger_audible_alarm, increase_door_gap, proceed_through_door

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "proceed_through_door": And([
                self.door_is_closing,
                Not(self.robot_has_triggered_alarm),
                Not(self.door_hold_open_gap_sufficient),
                self.human_near_centerline,
                self.robot_obstructing_sensor
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.outside_area), True)
        problem.set_initial_value(self.robot_at(self.doorway), False)
        problem.set_initial_value(self.robot_at(self.inside_area), False)
        problem.set_initial_value(self.human_near_centerline, True)
        problem.set_initial_value(self.door_hold_open_gap_sufficient, False)
        problem.set_initial_value(self.robot_has_triggered_alarm, False)
        problem.set_initial_value(self.door_is_closing, True)
        problem.set_initial_value(self.robot_obstructing_sensor, True)
        problem.set_initial_value(self.setting_is_retail_entrance, True)
        problem.set_initial_value(self.robot_has_forward_sensors, True)
        problem.set_initial_value(self.robot_has_audible_alarm, True)
        problem.set_initial_value(self.robot_can_pause, True)

    def _set_goals(self, problem):
        problem.add_goal(self.robot_at(self.inside_area))

if __name__ == "__main__":
    DomainPlanner().run_cli()