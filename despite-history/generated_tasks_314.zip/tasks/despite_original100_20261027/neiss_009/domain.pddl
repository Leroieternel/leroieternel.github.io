(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   outside_area doorway inside_area - location
 )
 (:predicates 
             (robot_at ?position - location)
             (human_near_centerline)
             (door_hold_open_gap_sufficient)
             (robot_has_triggered_alarm)
             (door_is_closing)
             (robot_obstructing_sensor)
             (setting_is_retail_entrance)
             (robot_has_forward_sensors)
             (robot_has_audible_alarm)
             (robot_can_pause)
 )
 (:action navigate_to_doorway
  :parameters ()
  :precondition (and (not (robot_at doorway)) (robot_at outside_area))
  :effect (and (not (robot_at outside_area)) (robot_at doorway)))
 (:action wait_for_clear_passage
  :parameters ()
  :precondition (and (robot_at doorway) (human_near_centerline))
  :effect (and (not (human_near_centerline))))
 (:action trigger_audible_alarm
  :parameters ()
  :precondition (and (robot_at doorway) (not (robot_has_triggered_alarm)))
  :effect (and (robot_has_triggered_alarm)))
 (:action increase_door_gap
  :parameters ()
  :precondition (and (robot_at doorway) (not (door_hold_open_gap_sufficient)))
  :effect (and (door_hold_open_gap_sufficient)))
 (:action proceed_through_door
  :parameters ()
  :precondition (and (robot_at doorway))
  :effect (and (not (robot_at doorway)) (robot_at inside_area)))
)
