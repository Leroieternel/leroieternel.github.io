(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at outside_area)
              (human_near_centerline)
              (door_is_closing)
              (robot_obstructing_sensor)
              (setting_is_retail_entrance)
              (robot_has_forward_sensors)
              (robot_has_audible_alarm)
              (robot_can_pause)
 )
 (:goal (and 
           (robot_at inside_area)
        )
 )
)
