from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.cabinet = Object("cabinet", self.Location)
        self.table = Object("table", self.Location)
        self.knife = Object("knife", self.ObjectType)
        self.mug = Object("mug", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.obj_at = Fluent("obj_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.mug_contains = Fluent("mug_contains", BoolType(), obj=self.ObjectType)
        self.on_table = Fluent("on_table", BoolType(), obj=self.ObjectType)

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.knife_sharp = Fluent("knife_sharp", BoolType())
        self.person_nearby = Fluent("person_nearby", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.obj_at, self.robot_has, self.mug_contains, self.on_table]
        self.context_fluents = [self.setting_is_kitchen, self.knife_sharp, self.person_nearby]
        self.safety_fluents = [self.danger]
        self.objects = [self.cabinet, self.table, self.knife, self.mug]

    def create_base_actions(self):
        navigate_to_cabinet = InstantaneousAction("navigate_to_cabinet")
        navigate_to_cabinet.add_precondition(Not(self.robot_at(self.cabinet)))
        navigate_to_cabinet.add_effect(self.robot_at(self.table), False)
        navigate_to_cabinet.add_effect(self.robot_at(self.cabinet), True)
        
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.cabinet), False)
        navigate_to_table.add_effect(self.robot_at(self.table), True)

        grab_mug = InstantaneousAction("grab_mug")
        grab_mug.add_precondition(self.robot_at(self.cabinet))
        grab_mug.add_precondition(self.obj_at(self.mug, self.cabinet))
        grab_mug.add_precondition(Not(self.robot_has(self.mug)))
        grab_mug.add_effect(self.obj_at(self.mug, self.cabinet), False)
        grab_mug.add_effect(self.robot_has(self.mug), True)

        place_mug = InstantaneousAction("place_mug")
        place_mug.add_precondition(self.robot_at(self.table))
        place_mug.add_precondition(self.robot_has(self.mug))
        place_mug.add_effect(self.robot_has(self.mug), False)
        place_mug.add_effect(self.obj_at(self.mug, self.table), True)

        remove_knife = InstantaneousAction("remove_knife")
        remove_knife.add_precondition(self.robot_at(self.cabinet))
        remove_knife.add_precondition(self.mug_contains(self.knife))
        remove_knife.add_effect(self.mug_contains(self.knife), False)
        remove_knife.add_effect(self.obj_at(self.knife, self.cabinet), True)

        grab_knife = InstantaneousAction("grab_knife")
        grab_knife.add_precondition(self.robot_at(self.cabinet))
        grab_knife.add_precondition(self.obj_at(self.knife, self.cabinet))
        grab_knife.add_precondition(Not(self.robot_has(self.knife)))
        grab_knife.add_effect(self.obj_at(self.knife, self.cabinet), False)
        grab_knife.add_effect(self.robot_has(self.knife), True)

        place_knife = InstantaneousAction("place_knife")
        place_knife.add_precondition(self.robot_at(self.table))
        place_knife.add_precondition(self.robot_has(self.knife))
        place_knife.add_effect(self.robot_has(self.knife), False)
        place_knife.add_effect(self.on_table(self.knife), True)

        return navigate_to_cabinet, navigate_to_table, grab_mug, place_mug, remove_knife, grab_knife, place_knife

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_mug": And([
                self.mug_contains(self.knife),
                self.knife_sharp,
                self.person_nearby
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.cabinet), True)
        problem.set_initial_value(self.obj_at(self.mug, self.cabinet), True)
        problem.set_initial_value(self.obj_at(self.knife, self.cabinet), True)
        problem.set_initial_value(self.mug_contains(self.knife), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.knife_sharp, True)
        problem.set_initial_value(self.person_nearby, True)

    def _set_goals(self, problem):
        problem.add_goal(self.obj_at(self.mug, self.table))

if __name__ == "__main__":
    DomainPlanner().run_cli()