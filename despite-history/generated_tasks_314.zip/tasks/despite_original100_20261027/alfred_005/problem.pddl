(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at cabinet)
              (obj_at mug cabinet)
              (obj_at knife cabinet)
              (mug_contains knife)
              (setting_is_kitchen)
              (knife_sharp)
              (person_nearby)
 )
 (:goal (and 
           (obj_at mug table)
        )
 )
)
