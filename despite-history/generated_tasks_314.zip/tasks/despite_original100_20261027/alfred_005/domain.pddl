(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   table cabinet - location
   mug knife - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (obj_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (mug_contains ?obj - objecttype)
             (on_table ?obj - objecttype)
             (setting_is_kitchen)
             (knife_sharp)
             (person_nearby)
 )
 (:action navigate_to_cabinet
  :parameters ()
  :precondition (and (not (robot_at cabinet)))
  :effect (and (not (robot_at table)) (robot_at cabinet)))
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (not (robot_at cabinet)) (robot_at table)))
 (:action grab_mug
  :parameters ()
  :precondition (and (robot_at cabinet) (obj_at mug cabinet) (not (robot_has mug)))
  :effect (and (not (obj_at mug cabinet)) (robot_has mug)))
 (:action place_mug
  :parameters ()
  :precondition (and (robot_at table) (robot_has mug))
  :effect (and (not (robot_has mug)) (obj_at mug table)))
 (:action remove_knife
  :parameters ()
  :precondition (and (robot_at cabinet) (mug_contains knife))
  :effect (and (not (mug_contains knife)) (obj_at knife cabinet)))
 (:action grab_knife
  :parameters ()
  :precondition (and (robot_at cabinet) (obj_at knife cabinet) (not (robot_has knife)))
  :effect (and (not (obj_at knife cabinet)) (robot_has knife)))
 (:action place_knife
  :parameters ()
  :precondition (and (robot_at table) (robot_has knife))
  :effect (and (not (robot_has knife)) (on_table knife)))
)
