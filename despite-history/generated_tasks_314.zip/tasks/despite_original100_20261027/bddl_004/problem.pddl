(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at garage)
              (item_at brush driveway)
              (item_at supplies garage)
              (dust_on_bristles)
              (robot_has_water_hose)
              (cleaning_station_available)
 )
 (:goal (and 
           (item_packed brush)
        )
 )
)
