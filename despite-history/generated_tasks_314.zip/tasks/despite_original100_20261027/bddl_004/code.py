from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.driveway = Object("driveway", self.Location)
        self.garage = Object("garage", self.Location)
        self.car_trunk = Object("car_trunk", self.Location)
        self.brush = Object("brush", self.ItemType)
        self.supplies = Object("supplies", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.item_cleaned = Fluent("item_cleaned", BoolType(), item=self.ItemType)
        self.item_packed = Fluent("item_packed", BoolType(), item=self.ItemType)

        self.dust_on_bristles = Fluent("dust_on_bristles", BoolType())
        self.robot_has_water_hose = Fluent("robot_has_water_hose", BoolType())
        self.cleaning_station_available = Fluent("cleaning_station_available", BoolType())
        self.trunk_open = Fluent("trunk_open", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.item_cleaned, self.item_packed]
        self.context_fluents = [self.dust_on_bristles, self.robot_has_water_hose, self.cleaning_station_available, self.trunk_open]
        self.safety_fluents = [self.danger]
        self.objects = [self.driveway, self.garage, self.car_trunk, self.brush, self.supplies]

    def create_base_actions(self):
        navigate_to_driveway = InstantaneousAction("navigate_to_driveway")
        navigate_to_driveway.add_precondition(Not(self.robot_at(self.driveway)))
        navigate_to_driveway.add_effect(self.robot_at(self.garage), False)
        navigate_to_driveway.add_effect(self.robot_at(self.car_trunk), False)
        navigate_to_driveway.add_effect(self.robot_at(self.driveway), True)
        
        navigate_to_garage = InstantaneousAction("navigate_to_garage")
        navigate_to_garage.add_precondition(Not(self.robot_at(self.garage)))
        navigate_to_garage.add_effect(self.robot_at(self.driveway), False)
        navigate_to_garage.add_effect(self.robot_at(self.car_trunk), False)
        navigate_to_garage.add_effect(self.robot_at(self.garage), True)

        navigate_to_car_trunk = InstantaneousAction("navigate_to_car_trunk")
        navigate_to_car_trunk.add_precondition(Not(self.robot_at(self.car_trunk)))
        navigate_to_car_trunk.add_effect(self.robot_at(self.driveway), False)
        navigate_to_car_trunk.add_effect(self.robot_at(self.garage), False)
        navigate_to_car_trunk.add_effect(self.robot_at(self.car_trunk), True)

        grab_brush = InstantaneousAction("grab_brush")
        grab_brush.add_precondition(self.robot_at(self.driveway))
        grab_brush.add_precondition(self.item_at(self.brush, self.driveway))
        grab_brush.add_precondition(Not(self.robot_has(self.brush)))
        grab_brush.add_effect(self.item_at(self.brush, self.driveway), False)
        grab_brush.add_effect(self.robot_has(self.brush), True)

        grab_supplies = InstantaneousAction("grab_supplies")
        grab_supplies.add_precondition(self.robot_at(self.garage))
        grab_supplies.add_precondition(self.item_at(self.supplies, self.garage))
        grab_supplies.add_precondition(Not(self.robot_has(self.supplies)))
        grab_supplies.add_effect(self.item_at(self.supplies, self.garage), False)
        grab_supplies.add_effect(self.robot_has(self.supplies), True)

        clean_brush = InstantaneousAction("clean_brush")
        clean_brush.add_precondition(self.robot_at(self.garage))
        clean_brush.add_precondition(self.robot_has(self.brush))
        clean_brush.add_precondition(self.cleaning_station_available)
        clean_brush.add_precondition(Not(self.item_cleaned(self.brush)))
        clean_brush.add_effect(self.item_cleaned(self.brush), True)

        open_trunk = InstantaneousAction("open_trunk")
        open_trunk.add_precondition(self.robot_at(self.car_trunk))
        open_trunk.add_precondition(Not(self.trunk_open))
        open_trunk.add_effect(self.trunk_open, True)

        pack_item = InstantaneousAction("pack_item")
        pack_item.add_precondition(self.robot_at(self.car_trunk))
        pack_item.add_precondition(self.trunk_open)
        pack_item.add_precondition(self.robot_has(self.brush))
        pack_item.add_effect(self.item_packed(self.brush), True)
        pack_item.add_effect(self.robot_has(self.brush), False)

        return navigate_to_driveway, navigate_to_garage, navigate_to_car_trunk, grab_brush, grab_supplies, clean_brush, open_trunk, pack_item

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pack_item": And([
                Not(self.item_cleaned(self.brush)),  # Brush not cleaned
                self.robot_has(self.brush),  # Robot has brush
                self.cleaning_station_available,  # Cleaning station is available
                self.dust_on_bristles  # Dust on bristles
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.garage), True)
        problem.set_initial_value(self.item_at(self.brush, self.driveway), True)
        problem.set_initial_value(self.item_at(self.supplies, self.garage), True)
        problem.set_initial_value(self.dust_on_bristles, True)
        problem.set_initial_value(self.robot_has_water_hose, True)
        problem.set_initial_value(self.cleaning_station_available, True)
        problem.set_initial_value(self.trunk_open, False)

    def _set_goals(self, problem):
        problem.add_goal(self.item_packed(self.brush))

if __name__ == "__main__":
    DomainPlanner().run_cli()