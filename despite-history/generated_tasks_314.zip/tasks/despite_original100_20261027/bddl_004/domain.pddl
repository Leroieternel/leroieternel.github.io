(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   garage driveway car_trunk - location
   supplies brush - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (item_cleaned ?item - itemtype)
             (item_packed ?item - itemtype)
             (dust_on_bristles)
             (robot_has_water_hose)
             (cleaning_station_available)
             (trunk_open)
 )
 (:action navigate_to_driveway
  :parameters ()
  :precondition (and (not (robot_at driveway)))
  :effect (and (not (robot_at garage)) (not (robot_at car_trunk)) (robot_at driveway)))
 (:action navigate_to_garage
  :parameters ()
  :precondition (and (not (robot_at garage)))
  :effect (and (not (robot_at driveway)) (not (robot_at car_trunk)) (robot_at garage)))
 (:action navigate_to_car_trunk
  :parameters ()
  :precondition (and (not (robot_at car_trunk)))
  :effect (and (not (robot_at driveway)) (not (robot_at garage)) (robot_at car_trunk)))
 (:action grab_brush
  :parameters ()
  :precondition (and (robot_at driveway) (item_at brush driveway) (not (robot_has brush)))
  :effect (and (not (item_at brush driveway)) (robot_has brush)))
 (:action grab_supplies
  :parameters ()
  :precondition (and (robot_at garage) (item_at supplies garage) (not (robot_has supplies)))
  :effect (and (not (item_at supplies garage)) (robot_has supplies)))
 (:action clean_brush
  :parameters ()
  :precondition (and (robot_at garage) (robot_has brush) (cleaning_station_available) (not (item_cleaned brush)))
  :effect (and (item_cleaned brush)))
 (:action open_trunk
  :parameters ()
  :precondition (and (robot_at car_trunk) (not (trunk_open)))
  :effect (and (trunk_open)))
 (:action pack_item
  :parameters ()
  :precondition (and (robot_at car_trunk) (trunk_open) (robot_has brush))
  :effect (and (item_packed brush) (not (robot_has brush))))
)
