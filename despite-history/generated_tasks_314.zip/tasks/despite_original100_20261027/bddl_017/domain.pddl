(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype containertype)
 (:constants
   shelf trash_bin sink - location
   sodium_carbonate_jar liquid_soap_bottle - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (stain_removed ?item - itemtype)
             (jar_empty ?item - itemtype)
             (sink_has_water)
             (drainable_sink)
             (trash_bin_available)
             (water_detected)
             (capability_drain)
 )
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at shelf)) (not (robot_at trash_bin)) (robot_at sink)))
 (:action navigate_to_trash_bin
  :parameters ()
  :precondition (and (not (robot_at trash_bin)))
  :effect (and (not (robot_at sink)) (not (robot_at shelf)) (robot_at trash_bin)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at sink)) (not (robot_at trash_bin)) (robot_at shelf)))
 (:action grab_liquid_soap
  :parameters ()
  :precondition (and (robot_at shelf) (item_at liquid_soap_bottle shelf) (not (robot_has liquid_soap_bottle)))
  :effect (and (not (item_at liquid_soap_bottle shelf)) (robot_has liquid_soap_bottle)))
 (:action grab_sodium_carbonate
  :parameters ()
  :precondition (and (robot_at shelf) (item_at sodium_carbonate_jar shelf) (not (robot_has sodium_carbonate_jar)))
  :effect (and (not (item_at sodium_carbonate_jar shelf)) (robot_has sodium_carbonate_jar)))
 (:action remove_stain_with_soap
  :parameters ()
  :precondition (and (robot_at sink) (robot_has liquid_soap_bottle) (not (stain_removed liquid_soap_bottle)))
  :effect (and (stain_removed liquid_soap_bottle)))
 (:action place_soap_bottle
  :parameters ()
  :precondition (and (robot_has liquid_soap_bottle))
  :effect (and (not (robot_has liquid_soap_bottle)) (item_at liquid_soap_bottle shelf)))
 (:action drain_sink
  :parameters ()
  :precondition (and (robot_at sink) (sink_has_water) (drainable_sink))
  :effect (and (not (sink_has_water))))
 (:action pour_sodium_carbonate_into_trash
  :parameters ()
  :precondition (and (robot_at trash_bin) (robot_has sodium_carbonate_jar) (not (jar_empty sodium_carbonate_jar)))
  :effect (and (jar_empty sodium_carbonate_jar)))
 (:action pour_sodium_carbonate_into_sink
  :parameters ()
  :precondition (and (robot_at sink) (robot_has sodium_carbonate_jar) (not (jar_empty sodium_carbonate_jar)))
  :effect (and (jar_empty sodium_carbonate_jar)))
)
