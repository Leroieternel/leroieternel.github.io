(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   stain water - containertype
 )
 (:init
              (robot_at shelf)
              (item_at liquid_soap_bottle shelf)
              (item_at sodium_carbonate_jar shelf)
              (sink_has_water)
              (drainable_sink)
              (trash_bin_available)
              (water_detected)
              (capability_drain)
 )
 (:goal (and 
           (stain_removed liquid_soap_bottle)
           (jar_empty sodium_carbonate_jar)
        )
 )
)
