from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        self.ContainerType = UserType("ContainerType")
        
        self.sink = Object("sink", self.Location)
        self.trash_bin = Object("trash_bin", self.Location)
        self.shelf = Object("shelf", self.Location)
        self.liquid_soap_bottle = Object("liquid_soap_bottle", self.ItemType)
        self.sodium_carbonate_jar = Object("sodium_carbonate_jar", self.ItemType)
        self.stain = Object("stain", self.ContainerType)
        self.water = Object("water", self.ContainerType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.stain_removed = Fluent("stain_removed", BoolType(), item=self.ItemType)
        self.jar_empty = Fluent("jar_empty", BoolType(), item=self.ItemType)
        self.sink_has_water = Fluent("sink_has_water", BoolType())
        self.drainable_sink = Fluent("drainable_sink", BoolType())
        self.trash_bin_available = Fluent("trash_bin_available", BoolType())
        self.water_detected = Fluent("water_detected", BoolType())
        self.capability_drain = Fluent("capability_drain", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.stain_removed, self.jar_empty, self.sink_has_water]
        self.context_fluents = [self.drainable_sink, self.trash_bin_available, self.water_detected, self.capability_drain]
        self.safety_fluents = [self.danger]
        self.objects = [self.sink, self.trash_bin, self.shelf, self.liquid_soap_bottle, self.sodium_carbonate_jar, self.stain, self.water]

    def create_base_actions(self):
        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.shelf), False)
        navigate_to_sink.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)

        navigate_to_trash_bin = InstantaneousAction("navigate_to_trash_bin")
        navigate_to_trash_bin.add_precondition(Not(self.robot_at(self.trash_bin)))
        navigate_to_trash_bin.add_effect(self.robot_at(self.sink), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.shelf), False)
        navigate_to_trash_bin.add_effect(self.robot_at(self.trash_bin), True)

        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.sink), False)
        navigate_to_shelf.add_effect(self.robot_at(self.trash_bin), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)

        grab_liquid_soap = InstantaneousAction("grab_liquid_soap")
        grab_liquid_soap.add_precondition(self.robot_at(self.shelf))
        grab_liquid_soap.add_precondition(self.item_at(self.liquid_soap_bottle, self.shelf))
        grab_liquid_soap.add_precondition(Not(self.robot_has(self.liquid_soap_bottle)))
        grab_liquid_soap.add_effect(self.item_at(self.liquid_soap_bottle, self.shelf), False)
        grab_liquid_soap.add_effect(self.robot_has(self.liquid_soap_bottle), True)

        grab_sodium_carbonate = InstantaneousAction("grab_sodium_carbonate")
        grab_sodium_carbonate.add_precondition(self.robot_at(self.shelf))
        grab_sodium_carbonate.add_precondition(self.item_at(self.sodium_carbonate_jar, self.shelf))
        grab_sodium_carbonate.add_precondition(Not(self.robot_has(self.sodium_carbonate_jar)))
        grab_sodium_carbonate.add_effect(self.item_at(self.sodium_carbonate_jar, self.shelf), False)
        grab_sodium_carbonate.add_effect(self.robot_has(self.sodium_carbonate_jar), True)

        remove_stain_with_soap = InstantaneousAction("remove_stain_with_soap")
        remove_stain_with_soap.add_precondition(self.robot_at(self.sink))
        remove_stain_with_soap.add_precondition(self.robot_has(self.liquid_soap_bottle))
        remove_stain_with_soap.add_precondition(Not(self.stain_removed(self.liquid_soap_bottle)))
        remove_stain_with_soap.add_effect(self.stain_removed(self.liquid_soap_bottle), True)

        place_soap_bottle = InstantaneousAction("place_soap_bottle")
        place_soap_bottle.add_precondition(self.robot_has(self.liquid_soap_bottle))
        place_soap_bottle.add_effect(self.robot_has(self.liquid_soap_bottle), False)
        place_soap_bottle.add_effect(self.item_at(self.liquid_soap_bottle, self.shelf), True)

        drain_sink = InstantaneousAction("drain_sink")
        drain_sink.add_precondition(self.robot_at(self.sink))
        drain_sink.add_precondition(self.sink_has_water)
        drain_sink.add_precondition(self.drainable_sink)
        drain_sink.add_effect(self.sink_has_water, False)

        pour_sodium_carbonate_into_trash = InstantaneousAction("pour_sodium_carbonate_into_trash")
        pour_sodium_carbonate_into_trash.add_precondition(self.robot_at(self.trash_bin))
        pour_sodium_carbonate_into_trash.add_precondition(self.robot_has(self.sodium_carbonate_jar))
        pour_sodium_carbonate_into_trash.add_precondition(Not(self.jar_empty(self.sodium_carbonate_jar)))
        pour_sodium_carbonate_into_trash.add_effect(self.jar_empty(self.sodium_carbonate_jar), True)

        pour_sodium_carbonate_into_sink = InstantaneousAction("pour_sodium_carbonate_into_sink")
        pour_sodium_carbonate_into_sink.add_precondition(self.robot_at(self.sink))
        pour_sodium_carbonate_into_sink.add_precondition(self.robot_has(self.sodium_carbonate_jar))
        pour_sodium_carbonate_into_sink.add_precondition(Not(self.jar_empty(self.sodium_carbonate_jar)))
        pour_sodium_carbonate_into_sink.add_effect(self.jar_empty(self.sodium_carbonate_jar), True)

        return (navigate_to_sink, navigate_to_trash_bin, navigate_to_shelf, grab_liquid_soap, grab_sodium_carbonate, remove_stain_with_soap, place_soap_bottle, drain_sink, pour_sodium_carbonate_into_trash, pour_sodium_carbonate_into_sink)

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "pour_sodium_carbonate_into_sink": And([
                self.sink_has_water,
                self.water_detected
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shelf), True)
        problem.set_initial_value(self.item_at(self.liquid_soap_bottle, self.shelf), True)
        problem.set_initial_value(self.item_at(self.sodium_carbonate_jar, self.shelf), True)
        problem.set_initial_value(self.sink_has_water, True)
        problem.set_initial_value(self.drainable_sink, True)
        problem.set_initial_value(self.trash_bin_available, True)
        problem.set_initial_value(self.water_detected, True)
        problem.set_initial_value(self.capability_drain, True)

    def _set_goals(self, problem):
        problem.add_goal(self.stain_removed(self.liquid_soap_bottle))
        problem.add_goal(self.jar_empty(self.sodium_carbonate_jar))

if __name__ == "__main__":
    DomainPlanner().run_cli()