(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at loading_area)
              (payload_at heavy_box loading_area)
              (alarm_system_available)
              (worker_present_in_zone)
 )
 (:goal (and 
           (lifting_platform_raised)
           (load_secured heavy_box)
        )
 )
)
