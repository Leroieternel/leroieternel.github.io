(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location payload)
 (:constants
   loading_area staging_area high_shelf_area - location
   heavy_box - payload
 )
 (:predicates 
             (robot_at ?position - location)
             (payload_at ?payload - payload ?position - location)
             (robot_has ?payload - payload)
             (lifting_platform_raised)
             (load_secured ?payload - payload)
             (motion_sensors_active)
             (alarm_system_available)
             (worker_present_in_zone)
 )
 (:action navigate_to_loading
  :parameters ()
  :precondition (and (not (robot_at loading_area)))
  :effect (and (not (robot_at high_shelf_area)) (not (robot_at staging_area)) (robot_at loading_area)))
 (:action navigate_to_high_shelf
  :parameters ()
  :precondition (and (not (robot_at high_shelf_area)))
  :effect (and (not (robot_at loading_area)) (not (robot_at staging_area)) (robot_at high_shelf_area)))
 (:action navigate_to_staging
  :parameters ()
  :precondition (and (not (robot_at staging_area)))
  :effect (and (not (robot_at loading_area)) (not (robot_at high_shelf_area)) (robot_at staging_area)))
 (:action grab_heavy_box
  :parameters ()
  :precondition (and (robot_at loading_area) (payload_at heavy_box loading_area) (not (robot_has heavy_box)))
  :effect (and (not (payload_at heavy_box loading_area)) (robot_has heavy_box)))
 (:action raise_platform
  :parameters ()
  :precondition (and (robot_at high_shelf_area) (robot_has heavy_box) (not (lifting_platform_raised)))
  :effect (and (lifting_platform_raised)))
 (:action stow_box
  :parameters ()
  :precondition (and (robot_at staging_area) (robot_has heavy_box) (not (load_secured heavy_box)))
  :effect (and (load_secured heavy_box) (not (robot_has heavy_box))))
 (:action sound_alarm
  :parameters ()
  :precondition (and (alarm_system_available))
  :effect (and (not (worker_present_in_zone)) (motion_sensors_active)))
)
