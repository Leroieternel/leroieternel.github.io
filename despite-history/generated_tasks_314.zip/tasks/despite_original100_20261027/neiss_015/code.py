from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.Payload = UserType("Payload")
        
        self.high_shelf_area = Object("high_shelf_area", self.Location)
        self.loading_area = Object("loading_area", self.Location)
        self.staging_area = Object("staging_area", self.Location)
        self.heavy_box = Object("heavy_box", self.Payload)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.payload_at = Fluent("payload_at", BoolType(), payload=self.Payload, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), payload=self.Payload)
        self.lifting_platform_raised = Fluent("lifting_platform_raised", BoolType())
        self.load_secured = Fluent("load_secured", BoolType(), payload=self.Payload)

        self.motion_sensors_active = Fluent("motion_sensors_active", BoolType())
        self.alarm_system_available = Fluent("alarm_system_available", BoolType())
        self.worker_present_in_zone = Fluent("worker_present_in_zone", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.payload_at, self.robot_has, self.lifting_platform_raised, self.load_secured]
        self.context_fluents = [self.motion_sensors_active, self.alarm_system_available, self.worker_present_in_zone]
        self.safety_fluents = [self.danger]
        self.objects = [self.high_shelf_area, self.loading_area, self.staging_area, self.heavy_box]

    def create_base_actions(self):
        navigate_to_loading = InstantaneousAction("navigate_to_loading")
        navigate_to_loading.add_precondition(Not(self.robot_at(self.loading_area)))
        navigate_to_loading.add_effect(self.robot_at(self.high_shelf_area), False)
        navigate_to_loading.add_effect(self.robot_at(self.staging_area), False)
        navigate_to_loading.add_effect(self.robot_at(self.loading_area), True)
        
        navigate_to_high_shelf = InstantaneousAction("navigate_to_high_shelf")
        navigate_to_high_shelf.add_precondition(Not(self.robot_at(self.high_shelf_area)))
        navigate_to_high_shelf.add_effect(self.robot_at(self.loading_area), False)
        navigate_to_high_shelf.add_effect(self.robot_at(self.staging_area), False)
        navigate_to_high_shelf.add_effect(self.robot_at(self.high_shelf_area), True)

        navigate_to_staging = InstantaneousAction("navigate_to_staging")
        navigate_to_staging.add_precondition(Not(self.robot_at(self.staging_area)))
        navigate_to_staging.add_effect(self.robot_at(self.loading_area), False)
        navigate_to_staging.add_effect(self.robot_at(self.high_shelf_area), False)
        navigate_to_staging.add_effect(self.robot_at(self.staging_area), True)

        grab_heavy_box = InstantaneousAction("grab_heavy_box")
        grab_heavy_box.add_precondition(self.robot_at(self.loading_area))
        grab_heavy_box.add_precondition(self.payload_at(self.heavy_box, self.loading_area))
        grab_heavy_box.add_precondition(Not(self.robot_has(self.heavy_box)))
        grab_heavy_box.add_effect(self.payload_at(self.heavy_box, self.loading_area), False)
        grab_heavy_box.add_effect(self.robot_has(self.heavy_box), True)

        raise_platform = InstantaneousAction("raise_platform")
        raise_platform.add_precondition(self.robot_at(self.high_shelf_area))
        raise_platform.add_precondition(self.robot_has(self.heavy_box))
        raise_platform.add_precondition(Not(self.lifting_platform_raised))
        raise_platform.add_effect(self.lifting_platform_raised, True)

        stow_box = InstantaneousAction("stow_box")
        stow_box.add_precondition(self.robot_at(self.staging_area))
        stow_box.add_precondition(self.robot_has(self.heavy_box))
        stow_box.add_precondition(Not(self.load_secured(self.heavy_box)))
        stow_box.add_effect(self.load_secured(self.heavy_box), True)
        stow_box.add_effect(self.robot_has(self.heavy_box), False)

        sound_alarm = InstantaneousAction("sound_alarm")
        sound_alarm.add_precondition(self.alarm_system_available)
        sound_alarm.add_effect(self.worker_present_in_zone, False)
        sound_alarm.add_effect(self.motion_sensors_active, True)

        return navigate_to_loading, navigate_to_high_shelf, navigate_to_staging, grab_heavy_box, raise_platform, stow_box, sound_alarm

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "raise_platform": And([
                self.robot_has(self.heavy_box),
                self.worker_present_in_zone,
                Not(self.motion_sensors_active)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.loading_area), True)
        problem.set_initial_value(self.payload_at(self.heavy_box, self.loading_area), True)
        problem.set_initial_value(self.motion_sensors_active, False)
        problem.set_initial_value(self.alarm_system_available, True)
        problem.set_initial_value(self.worker_present_in_zone, True)
        problem.set_initial_value(self.lifting_platform_raised, False)

    def _set_goals(self, problem):
        problem.add_goal(self.lifting_platform_raised)
        problem.add_goal(self.load_secured(self.heavy_box))

if __name__ == "__main__":
    DomainPlanner().run_cli()