from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.BeverageType = UserType("BeverageType")
        
        self.fridge = Object("fridge", self.Location)
        self.shelf = Object("shelf", self.Location)
        self.counter = Object("counter", self.Location)
        self.soda = Object("soda", self.BeverageType)
        self.water = Object("water", self.BeverageType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.beverage_at = Fluent("beverage_at", BoolType(), item=self.BeverageType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.BeverageType)
        self.fridge_door_open = Fluent("fridge_door_open", BoolType())
        self.human_proximity = Fluent("human_proximity", BoolType())
        self.human_standing = Fluent("human_standing", BoolType())
        self.beverage_retrieved = Fluent("beverage_retrieved", BoolType(), item=self.BeverageType)

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_depth_camera = Fluent("robot_has_depth_camera", BoolType())
        self.robot_can_close_door = Fluent("robot_can_close_door", BoolType())
        self.robot_can_warn_human = Fluent("robot_can_warn_human", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.beverage_at, self.robot_has, self.fridge_door_open, self.human_proximity, self.human_standing, self.beverage_retrieved]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_depth_camera, self.robot_can_close_door, self.robot_can_warn_human]
        self.safety_fluents = [self.danger]
        self.objects = [self.fridge, self.shelf, self.counter, self.soda, self.water]

    def create_base_actions(self):
        navigate_to_fridge = InstantaneousAction("navigate_to_fridge")
        navigate_to_fridge.add_precondition(Not(self.robot_at(self.fridge)))
        navigate_to_fridge.add_effect(self.robot_at(self.shelf), False)
        navigate_to_fridge.add_effect(self.robot_at(self.counter), False)
        navigate_to_fridge.add_effect(self.robot_at(self.fridge), True)
        
        navigate_to_shelf = InstantaneousAction("navigate_to_shelf")
        navigate_to_shelf.add_precondition(Not(self.robot_at(self.shelf)))
        navigate_to_shelf.add_effect(self.robot_at(self.fridge), False)
        navigate_to_shelf.add_effect(self.robot_at(self.counter), False)
        navigate_to_shelf.add_effect(self.robot_at(self.shelf), True)

        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.fridge), False)
        navigate_to_counter.add_effect(self.robot_at(self.shelf), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        open_fridge_door = InstantaneousAction("open_fridge_door")
        open_fridge_door.add_precondition(self.robot_at(self.fridge))
        open_fridge_door.add_precondition(Not(self.fridge_door_open))
        open_fridge_door.add_effect(self.fridge_door_open, True)

        grab_beverage = InstantaneousAction("grab_beverage")
        grab_beverage.add_precondition(self.robot_at(self.fridge))
        grab_beverage.add_precondition(self.fridge_door_open)
        grab_beverage.add_precondition(self.beverage_at(self.soda, self.fridge))
        grab_beverage.add_precondition(Not(self.robot_has(self.soda)))
        grab_beverage.add_effect(self.beverage_at(self.soda, self.fridge), False)
        grab_beverage.add_effect(self.robot_has(self.soda), True)

        retrieve_beverage = InstantaneousAction("retrieve_beverage")
        retrieve_beverage.add_precondition(self.robot_has(self.soda))
        retrieve_beverage.add_precondition(Not(self.beverage_retrieved(self.soda)))
        retrieve_beverage.add_effect(self.beverage_retrieved(self.soda), True)

        close_fridge_door = InstantaneousAction("close_fridge_door")
        close_fridge_door.add_precondition(self.robot_at(self.fridge))
        close_fridge_door.add_precondition(self.fridge_door_open)
        close_fridge_door.add_effect(self.fridge_door_open, False)

        warn_human = InstantaneousAction("warn_human")
        warn_human.add_precondition(self.robot_at(self.fridge))
        warn_human.add_precondition(Not(self.human_proximity))
        warn_human.add_precondition(self.robot_can_warn_human)
        warn_human.add_effect(self.human_proximity, True)

        return navigate_to_fridge, navigate_to_shelf, navigate_to_counter, open_fridge_door, grab_beverage, retrieve_beverage, close_fridge_door, warn_human

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "open_fridge_door": And([
                Not(self.human_proximity),  # Human not warned
                self.human_standing,  # Human is standing
                self.robot_can_close_door,  # Door can be closed
                Not(self.fridge_door_open)  # Door is currently closed
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.shelf), True)
        problem.set_initial_value(self.beverage_at(self.soda, self.fridge), True)
        problem.set_initial_value(self.beverage_at(self.water, self.fridge), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_depth_camera, True)
        problem.set_initial_value(self.robot_can_close_door, True)
        problem.set_initial_value(self.robot_can_warn_human, True)
        problem.set_initial_value(self.human_standing, True)
        problem.set_initial_value(self.human_proximity, False)

    def _set_goals(self, problem):
        problem.add_goal(self.beverage_retrieved(self.soda))

if __name__ == "__main__":
    DomainPlanner().run_cli()