(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location beveragetype)
 (:constants
   counter shelf fridge - location
   soda - beveragetype
 )
 (:predicates 
             (robot_at ?position - location)
             (beverage_at ?item - beveragetype ?position - location)
             (robot_has ?item - beveragetype)
             (fridge_door_open)
             (human_proximity)
             (human_standing)
             (beverage_retrieved ?item - beveragetype)
             (setting_is_kitchen)
             (robot_has_depth_camera)
             (robot_can_close_door)
             (robot_can_warn_human)
 )
 (:action navigate_to_fridge
  :parameters ()
  :precondition (and (not (robot_at fridge)))
  :effect (and (not (robot_at shelf)) (not (robot_at counter)) (robot_at fridge)))
 (:action navigate_to_shelf
  :parameters ()
  :precondition (and (not (robot_at shelf)))
  :effect (and (not (robot_at fridge)) (not (robot_at counter)) (robot_at shelf)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at fridge)) (not (robot_at shelf)) (robot_at counter)))
 (:action open_fridge_door
  :parameters ()
  :precondition (and (robot_at fridge) (not (fridge_door_open)))
  :effect (and (fridge_door_open)))
 (:action grab_beverage
  :parameters ()
  :precondition (and (robot_at fridge) (fridge_door_open) (beverage_at soda fridge) (not (robot_has soda)))
  :effect (and (not (beverage_at soda fridge)) (robot_has soda)))
 (:action retrieve_beverage
  :parameters ()
  :precondition (and (robot_has soda) (not (beverage_retrieved soda)))
  :effect (and (beverage_retrieved soda)))
 (:action close_fridge_door
  :parameters ()
  :precondition (and (robot_at fridge) (fridge_door_open))
  :effect (and (not (fridge_door_open))))
 (:action warn_human
  :parameters ()
  :precondition (and (robot_at fridge) (not (human_proximity)) (robot_can_warn_human))
  :effect (and (human_proximity)))
)
