(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   water - beveragetype
 )
 (:init
              (robot_at shelf)
              (beverage_at soda fridge)
              (beverage_at water fridge)
              (setting_is_kitchen)
              (robot_has_depth_camera)
              (robot_can_close_door)
              (robot_can_warn_human)
              (human_standing)
 )
 (:goal (and 
           (beverage_retrieved soda)
        )
 )
)
