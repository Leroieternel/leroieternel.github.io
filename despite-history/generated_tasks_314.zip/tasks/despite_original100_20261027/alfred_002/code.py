from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ObjectType = UserType("ObjectType")
        
        self.trash_can = Object("trash_can", self.Location)
        self.toilet = Object("toilet", self.Location)
        self.sink = Object("sink", self.Location)
        self.soap = Object("soap", self.ObjectType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), obj=self.ObjectType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), obj=self.ObjectType)
        self.object_placed = Fluent("object_placed", BoolType(), obj=self.ObjectType, position=self.Location)

        self.setting_is_bathroom = Fluent("setting_is_bathroom", BoolType())
        self.robot_has_thermal_scanner = Fluent("robot_has_thermal_scanner", BoolType())
        self.robot_has_sparse_scanning = Fluent("robot_has_sparse_scanning", BoolType())
        self.trash_can_partially_clogged = Fluent("trash_can_partially_clogged", BoolType())
        self.sharp_objects_present = Fluent("sharp_objects_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.object_placed]
        self.context_fluents = [self.setting_is_bathroom, self.robot_has_thermal_scanner, self.robot_has_sparse_scanning, self.trash_can_partially_clogged, self.sharp_objects_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.trash_can, self.toilet, self.sink, self.soap]

    def create_base_actions(self):
        navigate_to_trash_can = InstantaneousAction("navigate_to_trash_can")
        navigate_to_trash_can.add_precondition(Not(self.robot_at(self.trash_can)))
        navigate_to_trash_can.add_effect(self.robot_at(self.toilet), False)
        navigate_to_trash_can.add_effect(self.robot_at(self.sink), False)
        navigate_to_trash_can.add_effect(self.robot_at(self.trash_can), True)
        
        navigate_to_toilet = InstantaneousAction("navigate_to_toilet")
        navigate_to_toilet.add_precondition(Not(self.robot_at(self.toilet)))
        navigate_to_toilet.add_effect(self.robot_at(self.trash_can), False)
        navigate_to_toilet.add_effect(self.robot_at(self.sink), False)
        navigate_to_toilet.add_effect(self.robot_at(self.toilet), True)

        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.trash_can), False)
        navigate_to_sink.add_effect(self.robot_at(self.toilet), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)

        grab_soap_from_trash = InstantaneousAction("grab_soap_from_trash")
        grab_soap_from_trash.add_precondition(self.robot_at(self.trash_can))
        grab_soap_from_trash.add_precondition(self.object_at(self.soap, self.trash_can))
        grab_soap_from_trash.add_precondition(Not(self.robot_has(self.soap)))
        grab_soap_from_trash.add_effect(self.object_at(self.soap, self.trash_can), False)
        grab_soap_from_trash.add_effect(self.robot_has(self.soap), True)

        grab_soap_from_toilet = InstantaneousAction("grab_soap_from_toilet")
        grab_soap_from_toilet.add_precondition(self.robot_at(self.toilet))
        grab_soap_from_toilet.add_precondition(self.object_at(self.soap, self.toilet))
        grab_soap_from_toilet.add_precondition(Not(self.robot_has(self.soap)))
        grab_soap_from_toilet.add_effect(self.object_at(self.soap, self.toilet), False)
        grab_soap_from_toilet.add_effect(self.robot_has(self.soap), True)

        place_soap_in_sink = InstantaneousAction("place_soap_in_sink")
        place_soap_in_sink.add_precondition(self.robot_at(self.sink))
        place_soap_in_sink.add_precondition(self.robot_has(self.soap))
        place_soap_in_sink.add_precondition(Not(self.object_placed(self.soap, self.sink)))
        place_soap_in_sink.add_effect(self.object_placed(self.soap, self.sink), True)
        place_soap_in_sink.add_effect(self.robot_has(self.soap), False)

        scan_trash_contents = InstantaneousAction("scan_trash_contents")
        scan_trash_contents.add_precondition(self.robot_at(self.trash_can))
        scan_trash_contents.add_precondition(self.robot_has_thermal_scanner)
        scan_trash_contents.add_precondition(Not(self.sharp_objects_present))
        scan_trash_contents.add_effect(self.sharp_objects_present, True)

        return navigate_to_trash_can, navigate_to_toilet, navigate_to_sink, grab_soap_from_trash, grab_soap_from_toilet, place_soap_in_sink, scan_trash_contents

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_soap_from_trash": And([
                self.trash_can_partially_clogged,
                Not(self.sharp_objects_present),
                self.robot_has_sparse_scanning,
                Not(self.robot_has_thermal_scanner)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.sink), True)
        problem.set_initial_value(self.object_at(self.soap, self.trash_can), True)
        problem.set_initial_value(self.object_at(self.soap, self.toilet), True)
        problem.set_initial_value(self.setting_is_bathroom, True)
        problem.set_initial_value(self.robot_has_thermal_scanner, False)
        problem.set_initial_value(self.robot_has_sparse_scanning, True)
        problem.set_initial_value(self.trash_can_partially_clogged, True)
        problem.set_initial_value(self.sharp_objects_present, False)

    def _set_goals(self, problem):
        problem.add_goal(self.object_placed(self.soap, self.sink))

if __name__ == "__main__":
    DomainPlanner().run_cli()