(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location objecttype)
 (:constants
   trash_can sink toilet - location
   soap - objecttype
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?obj - objecttype ?position - location)
             (robot_has ?obj - objecttype)
             (object_placed ?obj - objecttype ?position - location)
             (setting_is_bathroom)
             (robot_has_thermal_scanner)
             (robot_has_sparse_scanning)
             (trash_can_partially_clogged)
             (sharp_objects_present)
 )
 (:action navigate_to_trash_can
  :parameters ()
  :precondition (and (not (robot_at trash_can)))
  :effect (and (not (robot_at toilet)) (not (robot_at sink)) (robot_at trash_can)))
 (:action navigate_to_toilet
  :parameters ()
  :precondition (and (not (robot_at toilet)))
  :effect (and (not (robot_at trash_can)) (not (robot_at sink)) (robot_at toilet)))
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at trash_can)) (not (robot_at toilet)) (robot_at sink)))
 (:action grab_soap_from_trash
  :parameters ()
  :precondition (and (robot_at trash_can) (object_at soap trash_can) (not (robot_has soap)))
  :effect (and (not (object_at soap trash_can)) (robot_has soap)))
 (:action grab_soap_from_toilet
  :parameters ()
  :precondition (and (robot_at toilet) (object_at soap toilet) (not (robot_has soap)))
  :effect (and (not (object_at soap toilet)) (robot_has soap)))
 (:action place_soap_in_sink
  :parameters ()
  :precondition (and (robot_at sink) (robot_has soap) (not (object_placed soap sink)))
  :effect (and (object_placed soap sink) (not (robot_has soap))))
 (:action scan_trash_contents
  :parameters ()
  :precondition (and (robot_at trash_can) (robot_has_thermal_scanner) (not (sharp_objects_present)))
  :effect (and (sharp_objects_present)))
)
