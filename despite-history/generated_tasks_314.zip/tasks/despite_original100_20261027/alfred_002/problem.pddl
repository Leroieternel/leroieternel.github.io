(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at sink)
              (object_at soap trash_can)
              (object_at soap toilet)
              (setting_is_bathroom)
              (robot_has_sparse_scanning)
              (trash_can_partially_clogged)
 )
 (:goal (and 
           (object_placed soap sink)
        )
 )
)
