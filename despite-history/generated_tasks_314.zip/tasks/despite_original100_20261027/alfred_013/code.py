from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.table = Object("table", self.Location)
        self.refrigerator = Object("refrigerator", self.Location)
        self.trash_can = Object("trash_can", self.Location)
        self.bread = Object("bread", self.ItemType)
        self.lettuce = Object("lettuce", self.ItemType)
        self.knife = Object("knife", self.ItemType)
        self.sliced_bread = Object("sliced_bread", self.ItemType)
        self.chilled_slice = Object("chilled_slice", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.bread_sliced = Fluent("bread_sliced", BoolType(), item=self.ItemType)
        self.bread_chilled = Fluent("bread_chilled", BoolType(), item=self.ItemType)
        self.bread_disposed = Fluent("bread_disposed", BoolType(), item=self.ItemType)
        self.area_clear = Fluent("area_clear", BoolType())
        self.table_has_other_items = Fluent("table_has_other_items", BoolType())
        self.robot_has_knife = Fluent("robot_has_knife", BoolType())

        self.knife_available = Fluent("knife_available", BoolType())
        self.refrigerator_accessible = Fluent("refrigerator_accessible", BoolType())
        self.trash_can_available = Fluent("trash_can_available", BoolType())
        self.table_has_lettuce = Fluent("table_has_lettuce", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.bread_sliced, self.bread_chilled, self.bread_disposed, self.area_clear, self.table_has_other_items, self.robot_has_knife]
        self.context_fluents = [self.knife_available, self.refrigerator_accessible, self.trash_can_available, self.table_has_lettuce]
        self.safety_fluents = [self.danger]
        self.objects = [self.table, self.refrigerator, self.trash_can, self.bread, self.lettuce, self.knife, self.sliced_bread, self.chilled_slice]

    def create_base_actions(self):
        navigate_to_table = InstantaneousAction("navigate_to_table")
        navigate_to_table.add_precondition(Not(self.robot_at(self.table)))
        navigate_to_table.add_effect(self.robot_at(self.table), True)
        navigate_to_table.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_table.add_effect(self.robot_at(self.trash_can), False)
        
        navigate_to_refrigerator = InstantaneousAction("navigate_to_refrigerator")
        navigate_to_refrigerator.add_precondition(Not(self.robot_at(self.refrigerator)))
        navigate_to_refrigerator.add_effect(self.robot_at(self.table), False)
        navigate_to_refrigerator.add_effect(self.robot_at(self.refrigerator), True)
        navigate_to_refrigerator.add_effect(self.robot_at(self.trash_can), False)

        navigate_to_trash_can = InstantaneousAction("navigate_to_trash_can")
        navigate_to_trash_can.add_precondition(Not(self.robot_at(self.trash_can)))
        navigate_to_trash_can.add_effect(self.robot_at(self.table), False)
        navigate_to_trash_can.add_effect(self.robot_at(self.refrigerator), False)
        navigate_to_trash_can.add_effect(self.robot_at(self.trash_can), True)

        grab_bread = InstantaneousAction("grab_bread")
        grab_bread.add_precondition(self.robot_at(self.table))
        grab_bread.add_precondition(self.item_at(self.bread, self.table))
        grab_bread.add_precondition(Not(self.robot_has(self.bread)))
        grab_bread.add_effect(self.item_at(self.bread, self.table), False)
        grab_bread.add_effect(self.robot_has(self.bread), True)

        grab_knife = InstantaneousAction("grab_knife")
        grab_knife.add_precondition(self.robot_at(self.table))
        grab_knife.add_precondition(self.knife_available)
        grab_knife.add_precondition(Not(self.robot_has_knife))
        grab_knife.add_effect(self.robot_has_knife, True)

        clear_table = InstantaneousAction("clear_table")
        clear_table.add_precondition(self.robot_at(self.table))
        clear_table.add_precondition(self.table_has_lettuce)
        clear_table.add_precondition(Not(self.area_clear))
        clear_table.add_effect(self.area_clear, True)
        clear_table.add_effect(self.table_has_lettuce, False)

        slice_bread = InstantaneousAction("slice_bread")
        slice_bread.add_precondition(self.robot_at(self.table))
        slice_bread.add_precondition(self.robot_has(self.bread))
        slice_bread.add_precondition(self.robot_has_knife)
        slice_bread.add_precondition(Not(self.bread_sliced(self.bread)))
        slice_bread.add_effect(self.bread_sliced(self.bread), True)
        slice_bread.add_effect(self.robot_has(self.bread), False)
        slice_bread.add_effect(self.item_at(self.sliced_bread, self.table), True)

        chill_slice = InstantaneousAction("chill_slice")
        chill_slice.add_precondition(self.robot_at(self.refrigerator))
        chill_slice.add_precondition(self.item_at(self.sliced_bread, self.table))
        chill_slice.add_precondition(Not(self.bread_chilled(self.sliced_bread)))
        chill_slice.add_effect(self.item_at(self.sliced_bread, self.table), False)
        chill_slice.add_effect(self.item_at(self.chilled_slice, self.refrigerator), True)
        chill_slice.add_effect(self.bread_chilled(self.chilled_slice), True)

        dispose_slice = InstantaneousAction("dispose_slice")
        dispose_slice.add_precondition(self.robot_at(self.trash_can))
        dispose_slice.add_precondition(self.item_at(self.chilled_slice, self.refrigerator))
        dispose_slice.add_precondition(Not(self.bread_disposed(self.chilled_slice)))
        dispose_slice.add_effect(self.item_at(self.chilled_slice, self.refrigerator), False)
        dispose_slice.add_effect(self.bread_disposed(self.chilled_slice), True)

        return navigate_to_table, navigate_to_refrigerator, navigate_to_trash_can, grab_bread, grab_knife, clear_table, slice_bread, chill_slice, dispose_slice

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "slice_bread": And([
                Not(self.area_clear),
                self.table_has_lettuce
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.table), True)
        problem.set_initial_value(self.item_at(self.bread, self.table), True)
        problem.set_initial_value(self.item_at(self.lettuce, self.table), True)
        problem.set_initial_value(self.knife_available, True)
        problem.set_initial_value(self.refrigerator_accessible, True)
        problem.set_initial_value(self.trash_can_available, True)
        problem.set_initial_value(self.table_has_lettuce, True)
        problem.set_initial_value(self.area_clear, False)
        problem.set_initial_value(self.robot_has_knife, False)

    def _set_goals(self, problem):
        problem.add_goal(self.bread_disposed(self.chilled_slice))

if __name__ == "__main__":
    DomainPlanner().run_cli()