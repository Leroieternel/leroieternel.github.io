(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   refrigerator trash_can table - location
   bread chilled_slice sliced_bread - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (bread_sliced ?item - itemtype)
             (bread_chilled ?item - itemtype)
             (bread_disposed ?item - itemtype)
             (area_clear)
             (table_has_other_items)
             (robot_has_knife)
             (knife_available)
             (refrigerator_accessible)
             (trash_can_available)
             (table_has_lettuce)
 )
 (:action navigate_to_table
  :parameters ()
  :precondition (and (not (robot_at table)))
  :effect (and (robot_at table) (not (robot_at refrigerator)) (not (robot_at trash_can))))
 (:action navigate_to_refrigerator
  :parameters ()
  :precondition (and (not (robot_at refrigerator)))
  :effect (and (not (robot_at table)) (robot_at refrigerator) (not (robot_at trash_can))))
 (:action navigate_to_trash_can
  :parameters ()
  :precondition (and (not (robot_at trash_can)))
  :effect (and (not (robot_at table)) (not (robot_at refrigerator)) (robot_at trash_can)))
 (:action grab_bread
  :parameters ()
  :precondition (and (robot_at table) (item_at bread table) (not (robot_has bread)))
  :effect (and (not (item_at bread table)) (robot_has bread)))
 (:action grab_knife
  :parameters ()
  :precondition (and (robot_at table) (knife_available) (not (robot_has_knife)))
  :effect (and (robot_has_knife)))
 (:action clear_table
  :parameters ()
  :precondition (and (robot_at table) (table_has_lettuce) (not (area_clear)))
  :effect (and (area_clear) (not (table_has_lettuce))))
 (:action slice_bread
  :parameters ()
  :precondition (and (robot_at table) (robot_has bread) (robot_has_knife) (not (bread_sliced bread)))
  :effect (and (bread_sliced bread) (not (robot_has bread)) (item_at sliced_bread table)))
 (:action chill_slice
  :parameters ()
  :precondition (and (robot_at refrigerator) (item_at sliced_bread table) (not (bread_chilled sliced_bread)))
  :effect (and (not (item_at sliced_bread table)) (item_at chilled_slice refrigerator) (bread_chilled chilled_slice)))
 (:action dispose_slice
  :parameters ()
  :precondition (and (robot_at trash_can) (item_at chilled_slice refrigerator) (not (bread_disposed chilled_slice)))
  :effect (and (not (item_at chilled_slice refrigerator)) (bread_disposed chilled_slice)))
)
