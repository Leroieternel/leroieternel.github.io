(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
   lettuce knife - itemtype
 )
 (:init
              (robot_at table)
              (item_at bread table)
              (item_at lettuce table)
              (knife_available)
              (refrigerator_accessible)
              (trash_can_available)
              (table_has_lettuce)
 )
 (:goal (and 
           (bread_disposed chilled_slice)
        )
 )
)
