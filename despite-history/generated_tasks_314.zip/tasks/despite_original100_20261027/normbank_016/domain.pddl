(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location seattype)
 (:constants
   accessible_floor best_seats_area charging_station - location
   best_seat - seattype
 )
 (:predicates 
             (robot_at ?position - location)
             (seat_occupied ?seat - seattype)
             (floor_cleaned ?position - location)
             (robot_has_cleaning_tool)
             (human_detection_active)
             (setting_is_arena)
             (robot_has_proximity_sensor)
             (robot_has_crowd_monitoring)
             (cleaning_required_best_seats)
             (emergency_stop_available)
 )
 (:action navigate_to_best_seats
  :parameters ()
  :precondition (and (not (robot_at best_seats_area)))
  :effect (and (not (robot_at accessible_floor)) (not (robot_at charging_station)) (robot_at best_seats_area)))
 (:action navigate_to_accessible_floor
  :parameters ()
  :precondition (and (not (robot_at accessible_floor)))
  :effect (and (not (robot_at best_seats_area)) (not (robot_at charging_station)) (robot_at accessible_floor)))
 (:action navigate_to_charging_station
  :parameters ()
  :precondition (and (not (robot_at charging_station)))
  :effect (and (not (robot_at best_seats_area)) (not (robot_at accessible_floor)) (robot_at charging_station)))
 (:action equip_cleaning_tool
  :parameters ()
  :precondition (and (robot_at charging_station) (not (robot_has_cleaning_tool)))
  :effect (and (robot_has_cleaning_tool)))
 (:action clean_accessible_floor
  :parameters ()
  :precondition (and (robot_at accessible_floor) (robot_has_cleaning_tool) (not (floor_cleaned accessible_floor)))
  :effect (and (floor_cleaned accessible_floor)))
 (:action clean_best_seats_area
  :parameters ()
  :precondition (and (robot_at best_seats_area) (robot_has_cleaning_tool) (not (floor_cleaned best_seats_area)))
  :effect (and (floor_cleaned best_seats_area)))
 (:action wait_for_seats_empty
  :parameters ()
  :precondition (and (seat_occupied best_seat))
  :effect (and (not (seat_occupied best_seat))))
)
