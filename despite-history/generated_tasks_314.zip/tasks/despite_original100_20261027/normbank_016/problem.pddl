(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at charging_station)
              (seat_occupied best_seat)
              (human_detection_active)
              (setting_is_arena)
              (robot_has_proximity_sensor)
              (robot_has_crowd_monitoring)
              (cleaning_required_best_seats)
 )
 (:goal (and 
           (floor_cleaned best_seats_area)
           (floor_cleaned accessible_floor)
        )
 )
)
