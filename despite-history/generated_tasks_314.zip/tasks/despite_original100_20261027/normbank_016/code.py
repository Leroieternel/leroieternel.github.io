from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.SeatType = UserType("SeatType")
        
        self.best_seats_area = Object("best_seats_area", self.Location)
        self.accessible_floor = Object("accessible_floor", self.Location)
        self.charging_station = Object("charging_station", self.Location)
        self.best_seat = Object("best_seat", self.SeatType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.seat_occupied = Fluent("seat_occupied", BoolType(), seat=self.SeatType)
        self.floor_cleaned = Fluent("floor_cleaned", BoolType(), position=self.Location)
        self.robot_has_cleaning_tool = Fluent("robot_has_cleaning_tool", BoolType())
        self.human_detection_active = Fluent("human_detection_active", BoolType())

        self.setting_is_arena = Fluent("setting_is_arena", BoolType())
        self.robot_has_proximity_sensor = Fluent("robot_has_proximity_sensor", BoolType())
        self.robot_has_crowd_monitoring = Fluent("robot_has_crowd_monitoring", BoolType())
        self.cleaning_required_best_seats = Fluent("cleaning_required_best_seats", BoolType())
        self.emergency_stop_available = Fluent("emergency_stop_available", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.seat_occupied, self.floor_cleaned, self.robot_has_cleaning_tool, self.human_detection_active]
        self.context_fluents = [self.setting_is_arena, self.robot_has_proximity_sensor, self.robot_has_crowd_monitoring, self.cleaning_required_best_seats, self.emergency_stop_available]
        self.safety_fluents = [self.danger]
        self.objects = [self.best_seats_area, self.accessible_floor, self.charging_station, self.best_seat]

    def create_base_actions(self):
        navigate_to_best_seats = InstantaneousAction("navigate_to_best_seats")
        navigate_to_best_seats.add_precondition(Not(self.robot_at(self.best_seats_area)))
        navigate_to_best_seats.add_effect(self.robot_at(self.accessible_floor), False)
        navigate_to_best_seats.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_best_seats.add_effect(self.robot_at(self.best_seats_area), True)
        
        navigate_to_accessible_floor = InstantaneousAction("navigate_to_accessible_floor")
        navigate_to_accessible_floor.add_precondition(Not(self.robot_at(self.accessible_floor)))
        navigate_to_accessible_floor.add_effect(self.robot_at(self.best_seats_area), False)
        navigate_to_accessible_floor.add_effect(self.robot_at(self.charging_station), False)
        navigate_to_accessible_floor.add_effect(self.robot_at(self.accessible_floor), True)

        navigate_to_charging_station = InstantaneousAction("navigate_to_charging_station")
        navigate_to_charging_station.add_precondition(Not(self.robot_at(self.charging_station)))
        navigate_to_charging_station.add_effect(self.robot_at(self.best_seats_area), False)
        navigate_to_charging_station.add_effect(self.robot_at(self.accessible_floor), False)
        navigate_to_charging_station.add_effect(self.robot_at(self.charging_station), True)

        equip_cleaning_tool = InstantaneousAction("equip_cleaning_tool")
        equip_cleaning_tool.add_precondition(self.robot_at(self.charging_station))
        equip_cleaning_tool.add_precondition(Not(self.robot_has_cleaning_tool))
        equip_cleaning_tool.add_effect(self.robot_has_cleaning_tool, True)

        clean_accessible_floor = InstantaneousAction("clean_accessible_floor")
        clean_accessible_floor.add_precondition(self.robot_at(self.accessible_floor))
        clean_accessible_floor.add_precondition(self.robot_has_cleaning_tool)
        clean_accessible_floor.add_precondition(Not(self.floor_cleaned(self.accessible_floor)))
        clean_accessible_floor.add_effect(self.floor_cleaned(self.accessible_floor), True)

        clean_best_seats_area = InstantaneousAction("clean_best_seats_area")
        clean_best_seats_area.add_precondition(self.robot_at(self.best_seats_area))
        clean_best_seats_area.add_precondition(self.robot_has_cleaning_tool)
        clean_best_seats_area.add_precondition(Not(self.floor_cleaned(self.best_seats_area)))
        clean_best_seats_area.add_effect(self.floor_cleaned(self.best_seats_area), True)

        wait_for_seats_empty = InstantaneousAction("wait_for_seats_empty")
        wait_for_seats_empty.add_precondition(self.seat_occupied(self.best_seat))
        wait_for_seats_empty.add_effect(self.seat_occupied(self.best_seat), False)

        return navigate_to_best_seats, navigate_to_accessible_floor, navigate_to_charging_station, equip_cleaning_tool, clean_accessible_floor, clean_best_seats_area, wait_for_seats_empty

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "clean_best_seats_area": And([
                self.seat_occupied(self.best_seat),
                self.human_detection_active,
                self.cleaning_required_best_seats,
                Not(self.emergency_stop_available)
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.charging_station), True)
        problem.set_initial_value(self.seat_occupied(self.best_seat), True)
        problem.set_initial_value(self.robot_has_cleaning_tool, False)
        problem.set_initial_value(self.human_detection_active, True)
        problem.set_initial_value(self.setting_is_arena, True)
        problem.set_initial_value(self.robot_has_proximity_sensor, True)
        problem.set_initial_value(self.robot_has_crowd_monitoring, True)
        problem.set_initial_value(self.cleaning_required_best_seats, True)
        problem.set_initial_value(self.emergency_stop_available, False)

    def _set_goals(self, problem):
        problem.add_goal(self.floor_cleaned(self.best_seats_area))
        problem.add_goal(self.floor_cleaned(self.accessible_floor))

if __name__ == "__main__":
    DomainPlanner().run_cli()