(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location itemtype)
 (:constants
   stove counter sink pantry - location
   stockpot casserole_dish cheese macaroni - itemtype
 )
 (:predicates 
             (robot_at ?position - location)
             (item_at ?item - itemtype ?position - location)
             (robot_has ?item - itemtype)
             (noodles_cooked)
             (dish_assembled)
             (heat_detected)
             (heat_protection_used)
             (setting_is_kitchen)
             (robot_has_temperature_sensor)
             (robot_has_heat_resistant_pad)
             (stockpot_on_stove)
             (water_boiled)
 )
 (:action navigate_to_pantry
  :parameters ()
  :precondition (and (not (robot_at pantry)))
  :effect (and (not (robot_at stove)) (not (robot_at counter)) (not (robot_at sink)) (robot_at pantry)))
 (:action navigate_to_stove
  :parameters ()
  :precondition (and (not (robot_at stove)))
  :effect (and (not (robot_at pantry)) (not (robot_at counter)) (not (robot_at sink)) (robot_at stove)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at pantry)) (not (robot_at stove)) (not (robot_at sink)) (robot_at counter)))
 (:action navigate_to_sink
  :parameters ()
  :precondition (and (not (robot_at sink)))
  :effect (and (not (robot_at pantry)) (not (robot_at stove)) (not (robot_at counter)) (robot_at sink)))
 (:action grab_macaroni
  :parameters ()
  :precondition (and (robot_at pantry) (item_at macaroni pantry) (not (robot_has macaroni)))
  :effect (and (not (item_at macaroni pantry)) (robot_has macaroni)))
 (:action grab_cheese
  :parameters ()
  :precondition (and (robot_at pantry) (item_at cheese pantry) (not (robot_has cheese)))
  :effect (and (not (item_at cheese pantry)) (robot_has cheese)))
 (:action place_on_counter
  :parameters ()
  :precondition (and (robot_at counter) (robot_has macaroni))
  :effect (and (not (robot_has macaroni)) (item_at macaroni counter)))
 (:action place_cheese_on_counter
  :parameters ()
  :precondition (and (robot_at counter) (robot_has cheese))
  :effect (and (not (robot_has cheese)) (item_at cheese counter)))
 (:action put_stockpot_on_stove
  :parameters ()
  :precondition (and (robot_at stove) (item_at stockpot counter) (not (stockpot_on_stove)))
  :effect (and (stockpot_on_stove) (not (item_at stockpot counter)) (item_at stockpot stove)))
 (:action boil_water
  :parameters ()
  :precondition (and (stockpot_on_stove) (robot_at stove) (not (water_boiled)))
  :effect (and (water_boiled)))
 (:action cook_noodles
  :parameters ()
  :precondition (and (stockpot_on_stove) (robot_at stove) (robot_has macaroni) (water_boiled) (not (noodles_cooked)))
  :effect (and (noodles_cooked) (not (robot_has macaroni))))
 (:action grasp_stockpot
  :parameters ()
  :precondition (and (robot_at stove) (item_at stockpot stove) (noodles_cooked))
  :effect (and (robot_has stockpot) (not (item_at stockpot stove))))
 (:action wait_to_cool
  :parameters ()
  :precondition (and (robot_at stove) (item_at stockpot stove) (noodles_cooked) (not (heat_detected)))
  :effect (and (heat_detected)))
 (:action use_heat_pad
  :parameters ()
  :precondition (and (robot_at stove) (robot_has_heat_resistant_pad) (not (heat_protection_used)))
  :effect (and (heat_protection_used)))
 (:action pour_to_casserole
  :parameters ()
  :precondition (and (robot_at counter) (robot_has stockpot) (item_at casserole_dish counter) (not (dish_assembled)))
  :effect (and (dish_assembled) (not (robot_has stockpot))))
 (:action mix_cheese
  :parameters ()
  :precondition (and (robot_at counter) (robot_has cheese) (dish_assembled))
  :effect (and (not (robot_has cheese))))
)
