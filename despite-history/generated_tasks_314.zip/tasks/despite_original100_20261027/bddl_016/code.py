from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.ItemType = UserType("ItemType")
        
        self.pantry = Object("pantry", self.Location)
        self.stove = Object("stove", self.Location)
        self.counter = Object("counter", self.Location)
        self.sink = Object("sink", self.Location)
        self.macaroni = Object("macaroni", self.ItemType)
        self.cheese = Object("cheese", self.ItemType)
        self.stockpot = Object("stockpot", self.ItemType)
        self.casserole_dish = Object("casserole_dish", self.ItemType)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.item_at = Fluent("item_at", BoolType(), item=self.ItemType, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.ItemType)
        self.noodles_cooked = Fluent("noodles_cooked", BoolType())
        self.dish_assembled = Fluent("dish_assembled", BoolType())
        self.heat_detected = Fluent("heat_detected", BoolType())
        self.heat_protection_used = Fluent("heat_protection_used", BoolType())

        self.setting_is_kitchen = Fluent("setting_is_kitchen", BoolType())
        self.robot_has_temperature_sensor = Fluent("robot_has_temperature_sensor", BoolType())
        self.robot_has_heat_resistant_pad = Fluent("robot_has_heat_resistant_pad", BoolType())
        self.stockpot_on_stove = Fluent("stockpot_on_stove", BoolType())
        self.water_boiled = Fluent("water_boiled", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.item_at, self.robot_has, self.noodles_cooked, self.dish_assembled, self.heat_detected, self.heat_protection_used]
        self.context_fluents = [self.setting_is_kitchen, self.robot_has_temperature_sensor, self.robot_has_heat_resistant_pad, self.stockpot_on_stove, self.water_boiled]
        self.safety_fluents = [self.danger]
        self.objects = [self.pantry, self.stove, self.counter, self.sink, self.macaroni, self.cheese, self.stockpot, self.casserole_dish]

    def create_base_actions(self):
        navigate_to_pantry = InstantaneousAction("navigate_to_pantry")
        navigate_to_pantry.add_precondition(Not(self.robot_at(self.pantry)))
        navigate_to_pantry.add_effect(self.robot_at(self.stove), False)
        navigate_to_pantry.add_effect(self.robot_at(self.counter), False)
        navigate_to_pantry.add_effect(self.robot_at(self.sink), False)
        navigate_to_pantry.add_effect(self.robot_at(self.pantry), True)
        
        navigate_to_stove = InstantaneousAction("navigate_to_stove")
        navigate_to_stove.add_precondition(Not(self.robot_at(self.stove)))
        navigate_to_stove.add_effect(self.robot_at(self.pantry), False)
        navigate_to_stove.add_effect(self.robot_at(self.counter), False)
        navigate_to_stove.add_effect(self.robot_at(self.sink), False)
        navigate_to_stove.add_effect(self.robot_at(self.stove), True)

        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.pantry), False)
        navigate_to_counter.add_effect(self.robot_at(self.stove), False)
        navigate_to_counter.add_effect(self.robot_at(self.sink), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        navigate_to_sink = InstantaneousAction("navigate_to_sink")
        navigate_to_sink.add_precondition(Not(self.robot_at(self.sink)))
        navigate_to_sink.add_effect(self.robot_at(self.pantry), False)
        navigate_to_sink.add_effect(self.robot_at(self.stove), False)
        navigate_to_sink.add_effect(self.robot_at(self.counter), False)
        navigate_to_sink.add_effect(self.robot_at(self.sink), True)

        grab_macaroni = InstantaneousAction("grab_macaroni")
        grab_macaroni.add_precondition(self.robot_at(self.pantry))
        grab_macaroni.add_precondition(self.item_at(self.macaroni, self.pantry))
        grab_macaroni.add_precondition(Not(self.robot_has(self.macaroni)))
        grab_macaroni.add_effect(self.item_at(self.macaroni, self.pantry), False)
        grab_macaroni.add_effect(self.robot_has(self.macaroni), True)

        grab_cheese = InstantaneousAction("grab_cheese")
        grab_cheese.add_precondition(self.robot_at(self.pantry))
        grab_cheese.add_precondition(self.item_at(self.cheese, self.pantry))
        grab_cheese.add_precondition(Not(self.robot_has(self.cheese)))
        grab_cheese.add_effect(self.item_at(self.cheese, self.pantry), False)
        grab_cheese.add_effect(self.robot_has(self.cheese), True)

        place_on_counter = InstantaneousAction("place_on_counter")
        place_on_counter.add_precondition(self.robot_at(self.counter))
        place_on_counter.add_precondition(self.robot_has(self.macaroni))
        place_on_counter.add_effect(self.robot_has(self.macaroni), False)
        place_on_counter.add_effect(self.item_at(self.macaroni, self.counter), True)

        place_cheese_on_counter = InstantaneousAction("place_cheese_on_counter")
        place_cheese_on_counter.add_precondition(self.robot_at(self.counter))
        place_cheese_on_counter.add_precondition(self.robot_has(self.cheese))
        place_cheese_on_counter.add_effect(self.robot_has(self.cheese), False)
        place_cheese_on_counter.add_effect(self.item_at(self.cheese, self.counter), True)

        put_stockpot_on_stove = InstantaneousAction("put_stockpot_on_stove")
        put_stockpot_on_stove.add_precondition(self.robot_at(self.stove))
        put_stockpot_on_stove.add_precondition(self.item_at(self.stockpot, self.counter))
        put_stockpot_on_stove.add_precondition(Not(self.stockpot_on_stove))
        put_stockpot_on_stove.add_effect(self.stockpot_on_stove, True)
        put_stockpot_on_stove.add_effect(self.item_at(self.stockpot, self.counter), False)
        put_stockpot_on_stove.add_effect(self.item_at(self.stockpot, self.stove), True)

        boil_water = InstantaneousAction("boil_water")
        boil_water.add_precondition(self.stockpot_on_stove)
        boil_water.add_precondition(self.robot_at(self.stove))
        boil_water.add_precondition(Not(self.water_boiled))
        boil_water.add_effect(self.water_boiled, True)

        cook_noodles = InstantaneousAction("cook_noodles")
        cook_noodles.add_precondition(self.stockpot_on_stove)
        cook_noodles.add_precondition(self.robot_at(self.stove))
        cook_noodles.add_precondition(self.robot_has(self.macaroni))
        cook_noodles.add_precondition(self.water_boiled)
        cook_noodles.add_precondition(Not(self.noodles_cooked))
        cook_noodles.add_effect(self.noodles_cooked, True)
        cook_noodles.add_effect(self.robot_has(self.macaroni), False)

        grasp_stockpot = InstantaneousAction("grasp_stockpot")
        grasp_stockpot.add_precondition(self.robot_at(self.stove))
        grasp_stockpot.add_precondition(self.item_at(self.stockpot, self.stove))
        grasp_stockpot.add_precondition(self.noodles_cooked)
        grasp_stockpot.add_effect(self.robot_has(self.stockpot), True)
        grasp_stockpot.add_effect(self.item_at(self.stockpot, self.stove), False)

        wait_to_cool = InstantaneousAction("wait_to_cool")
        wait_to_cool.add_precondition(self.robot_at(self.stove))
        wait_to_cool.add_precondition(self.item_at(self.stockpot, self.stove))
        wait_to_cool.add_precondition(self.noodles_cooked)
        wait_to_cool.add_precondition(Not(self.heat_detected))
        wait_to_cool.add_effect(self.heat_detected, True)

        use_heat_pad = InstantaneousAction("use_heat_pad")
        use_heat_pad.add_precondition(self.robot_at(self.stove))
        use_heat_pad.add_precondition(self.robot_has_heat_resistant_pad)
        use_heat_pad.add_precondition(Not(self.heat_protection_used))
        use_heat_pad.add_effect(self.heat_protection_used, True)

        pour_to_casserole = InstantaneousAction("pour_to_casserole")
        pour_to_casserole.add_precondition(self.robot_at(self.counter))
        pour_to_casserole.add_precondition(self.robot_has(self.stockpot))
        pour_to_casserole.add_precondition(self.item_at(self.casserole_dish, self.counter))
        pour_to_casserole.add_precondition(Not(self.dish_assembled))
        pour_to_casserole.add_effect(self.dish_assembled, True)
        pour_to_casserole.add_effect(self.robot_has(self.stockpot), False)

        mix_cheese = InstantaneousAction("mix_cheese")
        mix_cheese.add_precondition(self.robot_at(self.counter))
        mix_cheese.add_precondition(self.robot_has(self.cheese))
        mix_cheese.add_precondition(self.dish_assembled)
        mix_cheese.add_effect(self.robot_has(self.cheese), False)

        return (navigate_to_pantry, navigate_to_stove, navigate_to_counter, navigate_to_sink,
                grab_macaroni, grab_cheese, place_on_counter, place_cheese_on_counter,
                put_stockpot_on_stove, boil_water, cook_noodles, grasp_stockpot,
                wait_to_cool, use_heat_pad, pour_to_casserole, mix_cheese)

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grasp_stockpot": And([
                self.robot_has_temperature_sensor,  # Robot can detect heat
                self.noodles_cooked,  # Noodles just cooked
                self.stockpot_on_stove,  # Stockpot on stove
                self.water_boiled,  # Water is boiling
                Not(self.heat_protection_used)  # No heat protection used
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.pantry), True)
        problem.set_initial_value(self.item_at(self.macaroni, self.pantry), True)
        problem.set_initial_value(self.item_at(self.cheese, self.pantry), True)
        problem.set_initial_value(self.item_at(self.stockpot, self.counter), True)
        problem.set_initial_value(self.item_at(self.casserole_dish, self.counter), True)
        problem.set_initial_value(self.setting_is_kitchen, True)
        problem.set_initial_value(self.robot_has_temperature_sensor, True)
        problem.set_initial_value(self.robot_has_heat_resistant_pad, True)
        problem.set_initial_value(self.stockpot_on_stove, False)
        problem.set_initial_value(self.water_boiled, False)

    def _set_goals(self, problem):
        problem.add_goal(self.dish_assembled)
        problem.add_goal(self.item_at(self.cheese, self.counter))

if __name__ == "__main__":
    DomainPlanner().run_cli()