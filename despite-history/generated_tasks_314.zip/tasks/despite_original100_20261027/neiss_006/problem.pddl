(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at hallway_start)
              (polishing_pad_retracted)
              (setting_is_public_hallway)
              (robot_has_wet_floor_sign)
              (robot_has_polishing_pad)
              (floor_recently_mopped)
              (pedestrian_present)
 )
 (:goal (and 
           (floor_dry tile_row)
           (floor_polished tile_row)
        )
 )
)
