(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location)
 (:constants
   tile_row entryway hallway_start hallway_end - location
 )
 (:predicates 
             (robot_at ?position - location)
             (floor_dry ?position - location)
             (floor_polished ?position - location)
             (wet_floor_sign_deployed ?position - location)
             (polishing_pad_retracted)
             (polishing_pad_deployed)
             (setting_is_public_hallway)
             (robot_has_wet_floor_sign)
             (robot_has_polishing_pad)
             (floor_recently_mopped)
             (pedestrian_present)
 )
 (:action navigate_to_entryway
  :parameters ()
  :precondition (and (not (robot_at entryway)))
  :effect (and (not (robot_at hallway_start)) (not (robot_at hallway_end)) (not (robot_at tile_row)) (robot_at entryway)))
 (:action navigate_to_tile_row
  :parameters ()
  :precondition (and (not (robot_at tile_row)))
  :effect (and (not (robot_at hallway_start)) (not (robot_at hallway_end)) (not (robot_at entryway)) (robot_at tile_row)))
 (:action navigate_to_hallway_start
  :parameters ()
  :precondition (and (not (robot_at hallway_start)))
  :effect (and (not (robot_at hallway_end)) (not (robot_at entryway)) (not (robot_at tile_row)) (robot_at hallway_start)))
 (:action navigate_to_hallway_end
  :parameters ()
  :precondition (and (not (robot_at hallway_end)))
  :effect (and (not (robot_at hallway_start)) (not (robot_at entryway)) (not (robot_at tile_row)) (robot_at hallway_end)))
 (:action retract_polishing_pad
  :parameters ()
  :precondition (and (polishing_pad_deployed))
  :effect (and (polishing_pad_retracted) (not (polishing_pad_deployed))))
 (:action deploy_wet_floor_sign
  :parameters ()
  :precondition (and (robot_at entryway) (robot_has_wet_floor_sign) (not (wet_floor_sign_deployed entryway)))
  :effect (and (wet_floor_sign_deployed entryway)))
 (:action deploy_polishing_pad
  :parameters ()
  :precondition (and (not (polishing_pad_deployed)) (polishing_pad_retracted))
  :effect (and (not (polishing_pad_retracted)) (polishing_pad_deployed)))
 (:action dry_floor
  :parameters ()
  :precondition (and (robot_at tile_row) (polishing_pad_deployed) (not (floor_dry tile_row)))
  :effect (and (floor_dry tile_row)))
 (:action polish_floor
  :parameters ()
  :precondition (and (robot_at tile_row) (polishing_pad_deployed) (floor_dry tile_row) (not (floor_polished tile_row)))
  :effect (and (floor_polished tile_row)))
)
