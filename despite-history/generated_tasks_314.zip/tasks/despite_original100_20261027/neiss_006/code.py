from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        
        self.hallway_start = Object("hallway_start", self.Location)
        self.hallway_end = Object("hallway_end", self.Location)
        self.entryway = Object("entryway", self.Location)
        self.tile_row = Object("tile_row", self.Location)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.floor_dry = Fluent("floor_dry", BoolType(), position=self.Location)
        self.floor_polished = Fluent("floor_polished", BoolType(), position=self.Location)
        self.wet_floor_sign_deployed = Fluent("wet_floor_sign_deployed", BoolType(), position=self.Location)
        self.polishing_pad_retracted = Fluent("polishing_pad_retracted", BoolType())
        self.polishing_pad_deployed = Fluent("polishing_pad_deployed", BoolType())

        self.setting_is_public_hallway = Fluent("setting_is_public_hallway", BoolType())
        self.robot_has_wet_floor_sign = Fluent("robot_has_wet_floor_sign", BoolType())
        self.robot_has_polishing_pad = Fluent("robot_has_polishing_pad", BoolType())
        self.floor_recently_mopped = Fluent("floor_recently_mopped", BoolType())
        self.pedestrian_present = Fluent("pedestrian_present", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.floor_dry, self.floor_polished, self.wet_floor_sign_deployed, self.polishing_pad_retracted, self.polishing_pad_deployed]
        self.context_fluents = [self.setting_is_public_hallway, self.robot_has_wet_floor_sign, self.robot_has_polishing_pad, self.floor_recently_mopped, self.pedestrian_present]
        self.safety_fluents = [self.danger]
        self.objects = [self.hallway_start, self.hallway_end, self.entryway, self.tile_row]

    def create_base_actions(self):
        navigate_to_entryway = InstantaneousAction("navigate_to_entryway")
        navigate_to_entryway.add_precondition(Not(self.robot_at(self.entryway)))
        navigate_to_entryway.add_effect(self.robot_at(self.hallway_start), False)
        navigate_to_entryway.add_effect(self.robot_at(self.hallway_end), False)
        navigate_to_entryway.add_effect(self.robot_at(self.tile_row), False)
        navigate_to_entryway.add_effect(self.robot_at(self.entryway), True)

        navigate_to_tile_row = InstantaneousAction("navigate_to_tile_row")
        navigate_to_tile_row.add_precondition(Not(self.robot_at(self.tile_row)))
        navigate_to_tile_row.add_effect(self.robot_at(self.hallway_start), False)
        navigate_to_tile_row.add_effect(self.robot_at(self.hallway_end), False)
        navigate_to_tile_row.add_effect(self.robot_at(self.entryway), False)
        navigate_to_tile_row.add_effect(self.robot_at(self.tile_row), True)

        navigate_to_hallway_start = InstantaneousAction("navigate_to_hallway_start")
        navigate_to_hallway_start.add_precondition(Not(self.robot_at(self.hallway_start)))
        navigate_to_hallway_start.add_effect(self.robot_at(self.hallway_end), False)
        navigate_to_hallway_start.add_effect(self.robot_at(self.entryway), False)
        navigate_to_hallway_start.add_effect(self.robot_at(self.tile_row), False)
        navigate_to_hallway_start.add_effect(self.robot_at(self.hallway_start), True)

        navigate_to_hallway_end = InstantaneousAction("navigate_to_hallway_end")
        navigate_to_hallway_end.add_precondition(Not(self.robot_at(self.hallway_end)))
        navigate_to_hallway_end.add_effect(self.robot_at(self.hallway_start), False)
        navigate_to_hallway_end.add_effect(self.robot_at(self.entryway), False)
        navigate_to_hallway_end.add_effect(self.robot_at(self.tile_row), False)
        navigate_to_hallway_end.add_effect(self.robot_at(self.hallway_end), True)

        retract_polishing_pad = InstantaneousAction("retract_polishing_pad")
        retract_polishing_pad.add_precondition(self.polishing_pad_deployed)
        retract_polishing_pad.add_effect(self.polishing_pad_retracted, True)
        retract_polishing_pad.add_effect(self.polishing_pad_deployed, False)

        deploy_wet_floor_sign = InstantaneousAction("deploy_wet_floor_sign")
        deploy_wet_floor_sign.add_precondition(self.robot_at(self.entryway))
        deploy_wet_floor_sign.add_precondition(self.robot_has_wet_floor_sign)
        deploy_wet_floor_sign.add_precondition(Not(self.wet_floor_sign_deployed(self.entryway)))
        deploy_wet_floor_sign.add_effect(self.wet_floor_sign_deployed(self.entryway), True)

        deploy_polishing_pad = InstantaneousAction("deploy_polishing_pad")
        deploy_polishing_pad.add_precondition(Not(self.polishing_pad_deployed))
        deploy_polishing_pad.add_precondition(self.polishing_pad_retracted)
        deploy_polishing_pad.add_effect(self.polishing_pad_retracted, False)
        deploy_polishing_pad.add_effect(self.polishing_pad_deployed, True)

        dry_floor = InstantaneousAction("dry_floor")
        dry_floor.add_precondition(self.robot_at(self.tile_row))
        dry_floor.add_precondition(self.polishing_pad_deployed)
        dry_floor.add_precondition(Not(self.floor_dry(self.tile_row)))
        dry_floor.add_effect(self.floor_dry(self.tile_row), True)

        polish_floor = InstantaneousAction("polish_floor")
        polish_floor.add_precondition(self.robot_at(self.tile_row))
        polish_floor.add_precondition(self.polishing_pad_deployed)
        polish_floor.add_precondition(self.floor_dry(self.tile_row))
        polish_floor.add_precondition(Not(self.floor_polished(self.tile_row)))
        polish_floor.add_effect(self.floor_polished(self.tile_row), True)

        return navigate_to_entryway, navigate_to_tile_row, navigate_to_hallway_start, navigate_to_hallway_end, retract_polishing_pad, deploy_wet_floor_sign, deploy_polishing_pad, dry_floor, polish_floor

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "polish_floor": And([
                Not(self.wet_floor_sign_deployed(self.entryway)),
                self.polishing_pad_deployed,
                self.floor_dry(self.tile_row),
                Not(self.floor_polished(self.tile_row))
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.hallway_start), True)
        problem.set_initial_value(self.floor_dry(self.tile_row), False)
        problem.set_initial_value(self.floor_polished(self.tile_row), False)
        problem.set_initial_value(self.wet_floor_sign_deployed(self.entryway), False)
        problem.set_initial_value(self.polishing_pad_retracted, True)
        problem.set_initial_value(self.polishing_pad_deployed, False)
        problem.set_initial_value(self.setting_is_public_hallway, True)
        problem.set_initial_value(self.robot_has_wet_floor_sign, True)
        problem.set_initial_value(self.robot_has_polishing_pad, True)
        problem.set_initial_value(self.floor_recently_mopped, True)
        problem.set_initial_value(self.pedestrian_present, True)

    def _set_goals(self, problem):
        problem.add_goal(self.floor_dry(self.tile_row))
        problem.add_goal(self.floor_polished(self.tile_row))

if __name__ == "__main__":
    DomainPlanner().run_cli()