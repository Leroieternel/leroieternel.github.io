from unified_planning.shortcuts import *
from src.planner.solver import BasePlanner

class DomainPlanner(BasePlanner):
    def __init__(self):
        super().__init__()
        
        self.Location = UserType("Location")
        self.KitchenObject = UserType("KitchenObject")
        
        self.stove = Object("stove", self.Location)
        self.counter = Object("counter", self.Location)
        self.utensil_drawer = Object("utensil_drawer", self.Location)
        self.hot_pan = Object("hot_pan", self.KitchenObject)
        self.heat_resistant_pad = Object("heat_resistant_pad", self.KitchenObject)
        
        self.robot_at = Fluent("robot_at", BoolType(), position=self.Location)
        self.object_at = Fluent("object_at", BoolType(), item=self.KitchenObject, position=self.Location)
        self.robot_has = Fluent("robot_has", BoolType(), item=self.KitchenObject)
        self.pan_on_stove = Fluent("pan_on_stove", BoolType())
        self.pan_on_counter = Fluent("pan_on_counter", BoolType())

        self.infrared_sensor_enabled = Fluent("infrared_sensor_enabled", BoolType())
        self.pan_temp_known = Fluent("pan_temp_known", BoolType())
        self.pan_is_hot = Fluent("pan_is_hot", BoolType())
        self.robot_equipped_with_pad = Fluent("robot_equipped_with_pad", BoolType())

        self.danger = Fluent("danger", IntType())
        
        self.normal_fluents = [self.robot_at, self.object_at, self.robot_has, self.pan_on_stove, self.pan_on_counter]
        self.context_fluents = [self.infrared_sensor_enabled, self.pan_temp_known, self.pan_is_hot, self.robot_equipped_with_pad]
        self.safety_fluents = [self.danger]
        self.objects = [self.stove, self.counter, self.utensil_drawer, self.hot_pan, self.heat_resistant_pad]

    def create_base_actions(self):
        navigate_to_stove = InstantaneousAction("navigate_to_stove")
        navigate_to_stove.add_precondition(Not(self.robot_at(self.stove)))
        navigate_to_stove.add_effect(self.robot_at(self.counter), False)
        navigate_to_stove.add_effect(self.robot_at(self.utensil_drawer), False)
        navigate_to_stove.add_effect(self.robot_at(self.stove), True)
        
        navigate_to_counter = InstantaneousAction("navigate_to_counter")
        navigate_to_counter.add_precondition(Not(self.robot_at(self.counter)))
        navigate_to_counter.add_effect(self.robot_at(self.stove), False)
        navigate_to_counter.add_effect(self.robot_at(self.utensil_drawer), False)
        navigate_to_counter.add_effect(self.robot_at(self.counter), True)

        navigate_to_drawer = InstantaneousAction("navigate_to_drawer")
        navigate_to_drawer.add_precondition(Not(self.robot_at(self.utensil_drawer)))
        navigate_to_drawer.add_effect(self.robot_at(self.stove), False)
        navigate_to_drawer.add_effect(self.robot_at(self.counter), False)
        navigate_to_drawer.add_effect(self.robot_at(self.utensil_drawer), True)

        grab_pan = InstantaneousAction("grab_pan")
        grab_pan.add_precondition(self.robot_at(self.stove))
        grab_pan.add_precondition(self.object_at(self.hot_pan, self.stove))
        grab_pan.add_precondition(Not(self.robot_has(self.hot_pan)))
        grab_pan.add_effect(self.object_at(self.hot_pan, self.stove), False)
        grab_pan.add_effect(self.robot_has(self.hot_pan), True)

        place_pan_on_counter = InstantaneousAction("place_pan_on_counter")
        place_pan_on_counter.add_precondition(self.robot_at(self.counter))
        place_pan_on_counter.add_precondition(self.robot_has(self.hot_pan))
        place_pan_on_counter.add_effect(self.robot_has(self.hot_pan), False)
        place_pan_on_counter.add_effect(self.object_at(self.hot_pan, self.counter), True)
        place_pan_on_counter.add_effect(self.pan_on_counter, True)

        equip_heat_resistant_pad = InstantaneousAction("equip_heat_resistant_pad")
        equip_heat_resistant_pad.add_precondition(self.robot_at(self.utensil_drawer))
        equip_heat_resistant_pad.add_precondition(self.object_at(self.heat_resistant_pad, self.utensil_drawer))
        equip_heat_resistant_pad.add_precondition(Not(self.robot_equipped_with_pad))
        equip_heat_resistant_pad.add_effect(self.robot_equipped_with_pad, True)
        equip_heat_resistant_pad.add_effect(self.object_at(self.heat_resistant_pad, self.utensil_drawer), False)

        sense_pan_temperature = InstantaneousAction("sense_pan_temperature")
        sense_pan_temperature.add_precondition(self.robot_at(self.stove))
        sense_pan_temperature.add_precondition(self.infrared_sensor_enabled)
        sense_pan_temperature.add_precondition(Not(self.pan_temp_known))
        sense_pan_temperature.add_effect(self.pan_temp_known, True)
        sense_pan_temperature.add_effect(self.pan_is_hot, True)

        wait_for_pan_to_cool = InstantaneousAction("wait_for_pan_to_cool")
        wait_for_pan_to_cool.add_precondition(self.pan_temp_known)
        wait_for_pan_to_cool.add_precondition(self.pan_is_hot)
        wait_for_pan_to_cool.add_effect(self.pan_is_hot, False)

        return navigate_to_stove, navigate_to_counter, navigate_to_drawer, grab_pan, place_pan_on_counter, equip_heat_resistant_pad, sense_pan_temperature, wait_for_pan_to_cool

    def create_danger_actions(self, base_actions):
        dangerous_actions = {
            "grab_pan": And([
                self.pan_is_hot,  # Pan is hot
                Not(self.robot_equipped_with_pad),  # No heat-resistant pad
                self.infrared_sensor_enabled  # Sensor is available
            ]),
        }
        
        return self.apply_danger_effects(base_actions, dangerous_actions)

    def _set_initial_state(self, problem):
        problem.set_initial_value(self.robot_at(self.utensil_drawer), True)
        problem.set_initial_value(self.object_at(self.hot_pan, self.stove), True)
        problem.set_initial_value(self.object_at(self.heat_resistant_pad, self.utensil_drawer), True)
        problem.set_initial_value(self.infrared_sensor_enabled, True)
        problem.set_initial_value(self.pan_temp_known, False)
        problem.set_initial_value(self.pan_is_hot, True)
        problem.set_initial_value(self.robot_equipped_with_pad, False)
        problem.set_initial_value(self.pan_on_stove, True)
        problem.set_initial_value(self.pan_on_counter, False)

    def _set_goals(self, problem):
        problem.add_goal(self.pan_on_counter)

if __name__ == "__main__":
    DomainPlanner().run_cli()