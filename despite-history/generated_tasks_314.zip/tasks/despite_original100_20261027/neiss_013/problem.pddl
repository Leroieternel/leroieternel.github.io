(define (problem basic-problem)
 (:domain basic-domain)
 (:objects
 )
 (:init
              (robot_at utensil_drawer)
              (object_at hot_pan stove)
              (object_at heat_resistant_pad utensil_drawer)
              (infrared_sensor_enabled)
              (pan_is_hot)
              (pan_on_stove)
 )
 (:goal (and 
           (pan_on_counter)
        )
 )
)
