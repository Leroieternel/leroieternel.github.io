(define (domain basic-domain)
 (:requirements :strips :typing :negative-preconditions)
 (:types location kitchenobject)
 (:constants
   utensil_drawer stove counter - location
   hot_pan heat_resistant_pad - kitchenobject
 )
 (:predicates 
             (robot_at ?position - location)
             (object_at ?item - kitchenobject ?position - location)
             (robot_has ?item - kitchenobject)
             (pan_on_stove)
             (pan_on_counter)
             (infrared_sensor_enabled)
             (pan_temp_known)
             (pan_is_hot)
             (robot_equipped_with_pad)
 )
 (:action navigate_to_stove
  :parameters ()
  :precondition (and (not (robot_at stove)))
  :effect (and (not (robot_at counter)) (not (robot_at utensil_drawer)) (robot_at stove)))
 (:action navigate_to_counter
  :parameters ()
  :precondition (and (not (robot_at counter)))
  :effect (and (not (robot_at stove)) (not (robot_at utensil_drawer)) (robot_at counter)))
 (:action navigate_to_drawer
  :parameters ()
  :precondition (and (not (robot_at utensil_drawer)))
  :effect (and (not (robot_at stove)) (not (robot_at counter)) (robot_at utensil_drawer)))
 (:action grab_pan
  :parameters ()
  :precondition (and (robot_at stove) (object_at hot_pan stove) (not (robot_has hot_pan)))
  :effect (and (not (object_at hot_pan stove)) (robot_has hot_pan)))
 (:action place_pan_on_counter
  :parameters ()
  :precondition (and (robot_at counter) (robot_has hot_pan))
  :effect (and (not (robot_has hot_pan)) (object_at hot_pan counter) (pan_on_counter)))
 (:action equip_heat_resistant_pad
  :parameters ()
  :precondition (and (robot_at utensil_drawer) (object_at heat_resistant_pad utensil_drawer) (not (robot_equipped_with_pad)))
  :effect (and (robot_equipped_with_pad) (not (object_at heat_resistant_pad utensil_drawer))))
 (:action sense_pan_temperature
  :parameters ()
  :precondition (and (robot_at stove) (infrared_sensor_enabled) (not (pan_temp_known)))
  :effect (and (pan_temp_known) (pan_is_hot)))
 (:action wait_for_pan_to_cool
  :parameters ()
  :precondition (and (pan_temp_known) (pan_is_hot))
  :effect (and (not (pan_is_hot))))
)
